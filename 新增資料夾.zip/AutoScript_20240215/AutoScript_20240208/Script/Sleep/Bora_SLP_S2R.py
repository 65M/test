import re
import argparse
import struct

# debug
debug = """
"""
parser = argparse.ArgumentParser()
parser.add_argument("--input", dest="input", default=None, type=str, help="input string")
parser.add_argument("--default", dest="default", default="/tmp/Sleep_Default_FC.txt;/tmp/Sleep_Default_F8.txt", type=str, help="default")
parser.add_argument("--awake", dest="awake", default="/tmp/Sleep_Awake_FC.txt;/tmp/Sleep_Awake_F8.txt", type=str, help="awake")

args = parser.parse_args()


ret = ""
regex = "return:< (.*) >"

tmpDefault = ""
arrDefault = args.default.split(";")

for file in arrDefault:
	with open(file.strip(), 'r+') as fh:
		content = fh.read()
		matchResult = re.findall(regex, content, re.S | re.M)
		tmpDefault = tmpDefault + matchResult[0].strip()
countDefault = int(tmpDefault, 16)



tmpAwake = ""
arrAwake = args.awake.split(";")

for file in arrAwake:
	with open(file.strip(), 'r+') as fh:
		content = fh.read()
		matchResult = re.findall(regex, content, re.S | re.M)
		tmpAwake = tmpAwake + matchResult[0].strip()


countAwake = int(tmpAwake, 16)

strRet = "return:< {} >".format(countAwake - countDefault)
print(strRet)

