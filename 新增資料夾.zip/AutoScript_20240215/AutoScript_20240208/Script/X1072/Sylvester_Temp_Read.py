import re
import argparse
import struct

# debug
debug = """
0x10002F7C => 0xEC
0x10002F7D => 0xA7
0x10002F7E => 0x95
0x10002F7F => 0x43
OK
[0012386C:0107401E] :-)
"""
parser = argparse.ArgumentParser()
parser.add_argument("--input", dest="input", default=None, type=str, help="input string")
args = parser.parse_args()


ret = ""
regex = "=>\\s+(\\w+)"
matchResult = re.findall(regex, args.input, re.S | re.M)
# matchResult = re.findall(regex, debug, re.S | re.M)

X1072_Temp_Data = [int(matchResult[3], 16),int(matchResult[2], 16),int(matchResult[1], 16),int(matchResult[0], 16)]
s = struct.unpack(">f",bytes(X1072_Temp_Data))[0]
ret = s - 273

print("return:< {} >".format(round(ret, 3)))



