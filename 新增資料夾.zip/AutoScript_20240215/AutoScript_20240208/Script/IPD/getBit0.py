import re
import argparse


# debug
debug = """
0x23C100208 => 0x00030387
OK
0x23C100300 => 0x00030384
OK
[000A15C1:00C3A91E] :-)
"""

regex = "0x23C100208 => (\w+)\s+OK"

parser = argparse.ArgumentParser()
parser.add_argument("--input", dest="input", default=None, type=str, help="input string")
parser.add_argument("--regex", dest="regex", default=None, type=str, help="regex string")
args = parser.parse_args()


ret = ""
matchResult = re.findall(args.regex, args.input, re.S | re.M)
# matchResult = re.findall(regex, debug, re.S | re.M)

ret = int(matchResult[0], 16) & 0x00000001

print("return:< {} >".format(ret))