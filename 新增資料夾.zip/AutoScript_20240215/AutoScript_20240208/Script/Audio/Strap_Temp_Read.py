import re
import argparse

# debug
debug = """
Reading 2 bytes from register offset 0x00 into 0xC7E8B298, buffer read:	
Data:  0x1C  0x40 
[001431AC:0107401E] :-) 
"""
parser = argparse.ArgumentParser()
parser.add_argument("--input", dest="input", default=None, type=str, help="input string")
args = parser.parse_args()


ret = ""
regex = "Data:\\s+(\\w+\\s+\\w+)"
matchResult = re.findall(regex, args.input, re.S | re.M)
arr = matchResult[0].split("  ")
ret = (int(arr[1], 16)>>4)/16.0+int(arr[0], 16)

print("return:< {} >".format(ret))



