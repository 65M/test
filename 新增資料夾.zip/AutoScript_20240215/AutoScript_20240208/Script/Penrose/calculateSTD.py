import re
import argparse
import struct
import numpy as np
import soundfile as sf

parser = argparse.ArgumentParser()
parser.add_argument("--input", dest="input", default=None, type=str, help="input string")
parser.add_argument("--file", dest="file", default="/tmp/penrose_dark.wav", type=str, help="file")
args = parser.parse_args()

ret = ""

data, samplerate = sf.read(args.file)
din = data[:, 6] # suppose to be VIS+IR channel
din_ir = data[:, 7] # suppose to be IR channel

# Raw data to voltage calculation
VoltageOut_VIS_CH = (1.8 - 0) / (0.636795520907916*2) * din + 0.9 
VoltageOut_IR_CH = (1.8 - 0) / (0.636795520907916*2) * din_ir + 0.9 
Penrose_Light_Off_VIS_CH_STD = np.std(VoltageOut_VIS_CH)*1e6 
Penrose_Light_Off_IR_CH_STD = np.std(VoltageOut_IR_CH)*1e6 

strRet = "return:< {};{} >".format(Penrose_Light_Off_VIS_CH_STD, Penrose_Light_Off_IR_CH_STD)
print(strRet)
