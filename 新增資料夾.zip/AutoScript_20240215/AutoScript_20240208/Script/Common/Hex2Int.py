import re
import argparse


# debug
debug = """
Reading 1 bytes from register offset 0x1A into 0xC7ED6F98, buffer read:	
Data:  0x28 
[001431AC:0107401E] :-) 
"""

regex = "Data:\\s+(\\w+)"

parser = argparse.ArgumentParser()
parser.add_argument("--input", dest="input", default=None, type=str, help="input string")
parser.add_argument("--regex", dest="regex", default=None, type=str, help="regex string")
args = parser.parse_args()


ret = ""
matchResult = re.findall(args.regex, args.input, re.S | re.M)
ret = int(matchResult[0], 16)

print("return:< {} >".format(ret))