import re
import argparse
import struct

# debug
debug = """
"""
parser = argparse.ArgumentParser()
parser.add_argument("--input", dest="input", default=None, type=str, help="input string")
parser.add_argument("--files", dest="files", default="/tmp/X1072_R_Display_SN_Part1.txt;/tmp/X1072_R_Display_SN_Part1.txt", type=str, help="files")
args = parser.parse_args()


ret = ""
regex = "return:< (.*) >"

arrFile = args.files.split(";")

for file in arrFile:
	with open(file.strip(), 'r+') as fh:
		content = fh.read()
		matchResult = re.findall(regex, content, re.S | re.M)
		ret = ret + matchResult[0]

strRet = "return:< {} >".format(ret)
print(strRet)

