import re
import argparse
import struct

# debug
debug = """

"""
parser = argparse.ArgumentParser()
parser.add_argument("--input", dest="input", default=None, type=str, help="input string")
parser.add_argument("--regex", dest="regex", default=None, type=str, help="regex string")
parser.add_argument("--writeFile", dest="writeFile", default=None, type=str, help="writeFile")
args = parser.parse_args()


ret = ""
matchResult = re.findall(args.regex, args.input, re.S | re.M)
ret = matchResult[0]
strRet = "return:< {} >".format(ret)
print(strRet)

with open("{}".format(args.writeFile), 'w') as fh:
	fh.write(strRet)


