import re
import argparse
import struct

# debug
debug = """
"""
parser = argparse.ArgumentParser()
parser.add_argument("--input", dest="input", default=None, type=str, help="input string")
parser.add_argument("--files", dest="files", default="/tmp/X1072_R_Display_SN_Part1.txt;/tmp/X1072_R_Display_SN_Part1.txt", type=str, help="files")
parser.add_argument("--type", dest="type", default="plus", type=str, help="type in [plus, minus, multiply, divide]")
parser.add_argument("--intOrFloat", dest="intOrFloat", default="float", type=str, help="[int, float]")

args = parser.parse_args()


ret = ""
regex = "return:< (.*) >"

tmp = []
arrFile = args.files.split(";")

for file in arrFile:
	with open(file.strip(), 'r+') as fh:
		content = fh.read()
		matchResult = re.findall(regex, content, re.S | re.M)
		tmp.append(matchResult[0])

ret = float(tmp[0])
if args.type == "minus":
	for idx in range(len(tmp)):
		if idx+1 == len(tmp):
			break
		ret = ret - float(tmp[idx+1])

ret = round(ret, 3)

if args.intOrFloat == "int":
	ret = int(ret)

strRet = "return:< {} >".format(ret)
print(strRet)

