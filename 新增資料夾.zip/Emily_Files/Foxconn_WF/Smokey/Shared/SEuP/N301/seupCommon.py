from shell import run
import re
import sys
from colored import style,fore,back,colored,colors
import time
import plistlib
from ucollections import OrderedDict
import uio
# run()

SEUPVER="2023-05-19-01"



print("SystemEE uPython library")
print("SEuP VERSION: "+SEUPVER)


def setSEUPDCB(muteLogs=False,raiseException=False):
    run("var --set SEUP_DCB "+str(int(muteLogs))+str(int(raiseException)),True)
try:
    getSEUPDCB()
except:
    setSEUPDCB()
def getSEUPDCB():
    rct=run("var --get SEUP_DCB",True)
    vals=rct.split("=")[1].strip()
    return int(vals[0]),int(vals[1])


def helloWorld():
    print("HELLO from your favorate System EEs!")

def printVersion():
    print("SEuP VERSION: "+SEUPVER)

def getSN():
    rct = diags("sn")
    if "Error" in rct:
        raise NameError("No SN found on Unit!")
    sn=rct.split(":")[1].strip()
    return sn
def getMLBNum():
    diags("syscfg init")
    rct = diags("syscfg print MLB#")
    if "Not Found" in rct:
        raise NameError("No MLB# found on Unit!")
    return rct

class HardwareError(Exception):
    pass
class DiagsError(Exception):
    pass
# def getDiagsVersion():
#     print("SEuP VERSION: "+SEUPVER)
def diags(cmd):
    MUTE,SEuPDiagsRaiseException=getSEUPDCB()
    if not MUTE:
        print(">>>"+cmd)
    rct=run(cmd,MUTE)
    if SEuPDiagsRaiseException:
        print("Diags Exception Catching Enabled")
        if "ERROR"  in rct.upper() or "FAIL" in rct.upper():
            print("Diags Command Returned Error\n Log below")
            raise DiagsError("Diags Command Returned Error: "+cmd+"\nLog below --------\n "+rct)
    return rct

def dirname(filepath):
    lst=filepath.split('\\')
    lst.pop()
    outpath=''
    for seg in lst:
        outpath+=seg+"\\"
    return outpath
class PDCAGenerator():
    _data=OrderedDict({"0":OrderedDict({"Attributes":{},
            "Tests":[],
            "overallresult":"FAIL",
            "startTime":'2000-01-01 00:00:00+0000',
            "stopTime":'2000-01-01 00:00:00+0000'})})
    _errorList=[]
    _fileName="PDCA.plist"
    overallPass=True
    path="nandfs:\\"
    def __init__(self,suite,log=False,result=True):
        self.suite=suite
        self._data["0"]["startTime"]=self.getTime()
        self._data["0"]["stopTime"]=self.getTime()
        self._data["0"]["Attributes"]={
            "serialnumber":self.attemptSNs(),
            "softwarename":"Default",
            "softwareversion":SEUPVER
        }
        self.log=log
        self.result=result
    def setFileName(self,fn):
        self._fileName=fn
    def setPath(self,path):
        self.path=path
    def setSuite(self,suite):
        self.suite=suite
        self._data["0"]["Attributes"]["softwarename"]=self.suite
    def clearAttributes(self):
        self._data["0"]["Attributes"]={}
    def attemptSNs(self):
        sn=''
        try:
            sn=getSN()
        except NameError:
            sn=getMLBNum()
        return sn

    def getTime(self):
        try:
            return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        except Exception:
            return "2021-01-01 00:00:00+0000"
    def writePreflightFiles(self):
        # self.append("SequenceVersion","PASS",SEUPVER,None,None,None)
        self.append("SequenceProgress","FAIL",'Crash, hang, power loss, reset, etc',None,None,None,globalMercy=True)
        if self.result:
            plistlib.dump(self._data,open(self.path+self._fileName,'w+'))
        self._data["0"]["Tests"].pop()

        open(self.path+"Smokey.log",'w+').write("")

        if self.log:
            diags("filelog --on "+self.path+"Smokey.log")

    def writePostflightFiles(self):
        self._data["0"]["stopTime"]=self.getTime()
        self._data["0"]["overallresult"]="PASS" if self.overallPass else "FAIL"
        if self.result:
            plistlib.dump(self._data,open(self.path+self._fileName,'w+'))
        if self.log:
            diags("filelog --off")
#       PDCA.append(Name,PFstr,Value,LowerLimit,UpperLimit,Units)
    def append(self,test,result,value,lsl,usl,units,priority=0,errorMessage="",globalMercy=False):
        if str(result)=="FAIL" and not globalMercy:
            self.overallPass=False
            print("Marking overall result as Fail")
        payload=OrderedDict({       "testname"      : self.suite,
                                    "subtestname"   : test,
                                    "subsubtestname": "Iteration 1",
                                    "result"        : str(result),
                                    "value"         : str(value),
                                    "lowerlimit"    : str(lsl),
                                    "upperlimit"    : str(usl),
                                    "units"         : str(units),
                                    "priority"      : str(priority)})
        if errorMessage !="":
            payload["failure_message"]=errorMessage
        self._data["0"]["Tests"].append(payload)

    def appendError(self,error):
        self._errorList.append(error)
    def reportErrors(self):
        print("All errors from Python session:")
        for idx,error in enumerate(self._errorList):
            print("Error "+str(idx)+":\n")
            sys.print_exception(error)

PDCA=PDCAGenerator("Default")

resultStr=[]

def writeResults(file):
    with open(file,"w") as f:
        for row in resultStr:
            f.write(row)


def ReportDataToStationAndPDCA(Name, Value, Units, LowerLimit, UpperLimit, errorMessage=""):
    if Value==0 and LowerLimit is None and UpperLimit is None and errorMessage != "":
        print("Reporting execution error")
        PDCA.append(Name,"FAIL",0,"NA",'NA',"NA",errorMessage=errorMessage)
        print(back.RED+"FAIL"+style.RESET)
        return

    print("Hark, Station! Behold the data I present you!")
    print(Name + "," + str(Value) + "," + str(Units) + "," +str(LowerLimit) + "," + str(UpperLimit))
## revamp this shit to detect None

    if Units is None:
        Units = "NA"
    if not(type(Value)==type(1) or type(Value)==type(1.1) or type(Value)==type(True) or type(Value)==type("A")): # if value is not numerical
        PFstr="FAIL"
        print(back.RED+"FAIL"+style.RESET)
        errorMessage="Result is non-numerical"
    elif LowerLimit is not None and UpperLimit is not None:
        if LowerLimit <= Value <= UpperLimit:
            PFstr="PASS"
            print(back.GREEN+"PASS"+style.RESET)
            errorMessage=""
        elif Value<LowerLimit:
            PFstr="FAIL"
            errorMessage="Exceeded lower limit "+str(LowerLimit)
            print(back.RED+"FAIL"+style.RESET)
        elif Value>UpperLimit:
            PFstr="FAIL"
            errorMessage="Exceeded upper limit "+str(UpperLimit)
            print(back.RED+"FAIL"+style.RESET)
    elif LowerLimit is None and UpperLimit is not None:
        LowerLimit = "NA"
        if Value <= UpperLimit :
            PFstr="PASS"
            print(back.GREEN+"PASS"+style.RESET)
            errorMessage=""
        elif Value>UpperLimit:
            PFstr="FAIL"
            errorMessage="Exceeded lower limit "+str(LowerLimit)
            print(back.RED+"FAIL"+style.RESET)
    elif LowerLimit is not None and UpperLimit is None:
        UpperLimit = "NA"
        if  Value >= LowerLimit:
            PFstr="PASS"
            print(back.GREEN+"PASS"+style.RESET)
            errorMessage=""
        elif Value<LowerLimit:
            PFstr="FAIL"
            errorMessage="Exceeded upper limit "+str(UpperLimit)
            print(back.RED+"FAIL"+style.RESET)
    elif LowerLimit is None and UpperLimit is  None:
        PFstr="PASS"
        LowerLimit = "NA"
        UpperLimit = "NA"
        print(back.GREEN+"PASS"+style.RESET)

    PDCA.append(Name,PFstr,Value,LowerLimit,UpperLimit,Units,errorMessage=errorMessage)
    resultStr.append(Name + "," + PFstr + "," + str(Value) + "," + str(LowerLimit) + "," + str(UpperLimit) + "\n")


def getOverallResults(test_category=None, results=None):
    if not results:
        results = resultStr
    if not test_category:
        failures = [r.strip() for r in results if r.split(',')[1]!="PASS"]
    else:
        failures = [r.strip() for r in results if (r.split(',')[1]!="PASS") and (test_category in r.split(',')[0])]

    overall = len(failures) == 0

    return failures, overall


class N301SuperFrame():
    streaming=False
    streamID={0:3,1:9,2:23,3:14,4:38}
    linkID={0:0,1:4,2:2,3:1,4:3}
    def __init__(self,ch):
        self.channel = ch
    def startStreaming(self,force=False):
        if not self.streaming or force:
            diags("camisp --pick "+str(self.channel))
            rct=diags("camisp --sf start "+str(self.channel)+" "+str(self.streamID[self.channel]))
            if "Pass" not in rct:
                raise HardwareError("Streaming failed for SF"+str(self.channel))
            else:
                rct=diags('camisp --rmcsendcommand "dptx LT '+str(self.linkID[self.channel])+' on"')
                self.streaming=True
    def stopStreaming(self,force=False):
        if self.streaming or force:
            diags("camisp --pick "+str(self.channel))
            rct=diags('camisp --rmcsendcommand "dptx LT '+str(self.linkID[self.channel])+' off"')
            time.sleep(3)
            rct=diags("camisp --sf stop "+str(self.channel)+" "+str(self.streamID[self.channel]))

            if "Pass" not in rct:
                raise HardwareError("Streaming stop failed for SF"+str(self.channel))
            else:
                diags("camisp --exit")
                diags("camisp --dbgfw on")
                diags("camisp --setfirmwarebootarg 16 0x00040000")
                diags("camisp --find")
                self.streaming=False
        else:
            print("Not streaming already, nothing to stop")

class N301Camera():
    def __init__(self,ch):
        self.channel = ch
        self.streaming=False
        self.nvmIntegrityDict = None
    def externalSyncMode(self,external):
        if external:
            diags("camisp --pick "+str(self.channel))
            rct=diags("camisp --method setmasterslavesyncmode 3")
            if "Pass" not in rct:
                raise HardwareError("Setting sync mode failed for cam"+str(self.channel)+"\n double check ISP, it might be dead from a previous failed command")
        else:
            diags("camisp --pick "+str(self.channel))
            rct=diags("camisp --method setmasterslavesyncmode 0")
            if "Pass" not in rct:
                raise HardwareError("Setting sync mode failed for cam"+str(self.channel)+"\n double check ISP, it might be dead from a previous failed command")
    def startStreaming(self,force=False,isExternal=True):
        if not self.streaming or force:
            diags("camisp --dbgfw on")
            diags("camisp --setfirmwarebootarg 16 0x00010000")
            diags("camisp --pick "+str(self.channel))
            diags("camisp --method sfsetlayouttype 1")
            diags('camisp --rmcsendcommand "sffmt 1"')
            diags("camisp --sn")
            if not isExternal:
                diags('camisp --method setmasterslavesyncmode 0')
            rct=diags("camisp --sf start")
            if "Pass" not in rct:
                raise HardwareError("Streaming failed for cam"+str(self.channel))
            else:
                self.streaming=True
    def stopStreaming(self,force=False):
        if self.streaming or force:
            diags("camisp --pick "+str(self.channel))
            rct=diags("camisp --sf stop")
            if "Pass" not in rct:
                raise HardwareError("Streaming stop failed for cam"+str(self.channel))
            else:
                diags("camisp --exit")
                diags("camisp --dbgfw on")
                diags("camisp --setfirmwarebootarg 16 0x00010000")
                diags("camisp --find")
                self.streaming=False
        else:
            print("Not streaming already, nothing to stop")

    def getSN(self):
        diags("camisp --pick "+str(self.channel))
        rct = diags('camisp --sn')
        if "Pass" not in rct:
            raise HardwareError("Unable to read module SN for cam"+str(self.channel))
        else:
            match = re.match(r"Serial Number: *[0-9|A-Z]{17,18}", rct)
            if match:
                return match.group(0).split()[-1]
            else:
                raise HardwareError("Unable to read module SN for cam"+str(self.channel))

    def getFusing(self):
        fuse_type = "N/A"
        if self.__class__.__name__ in ["Oahu", "Lanai"]:
            fusing = self.i2cread(0x1303, datalen=1)
            if fusing == 0x8:
                fuse_type = "PROD"
            elif fusing == 0x4:
                fuse_type = "DEV"

        return fuse_type


    def isProdFused(self):
        if self.getFusing() == 0x8 and self.__class__.__name__ in ["Oahu", "Lanai"]:
            return True
        return False

    def enterNVMReadMode(self):
        # Implement in camDeviceModels
        return True

    def gotoNVMPage(self, page):
        # Implement in camDeviceModels
        return True

    def getNVMreg(self, page):
        # Implement in camDeviceModels
        return True

    def nvmIntegrityTest(self, target=""):
        if target is not "":
            target += "_"

        if not self.nvmIntegrityDict:
            raise HardwareError("No camera NVM integrity table set for cam"+str(self.channel))

        if not self.enterNVMReadMode():
            raise HardwareError("Unable to enter NVM read sequence on cam"+str(self.channel))

        for item in self.nvmIntegrityDict:
            # Kauai, Oahu, Lanai NVM values are stored in "OTP" pages
            page = item["Page"]
            # self.gotoNVMPage(page)
            otp_reg = self.getNVMreg(item["Reg"])

            payload = self.i2cread(otp_reg,datalen=item["NumofBytes"])
            bits=item["NumofBytes"]*8
            print(hex(payload))

            for otpItem in item["NVMDetails"]:
                Start = otpItem["StartBit"]
                Length = otpItem["Len"]
                Limits = otpItem["Result"]
                lsl, usl = Limits, Limits
                if isinstance(Limits, list):
                    lsl, usl = Limits[0], Limits[1]
                shift=(bits-Start-Length)
                print("Shift ",shift)
                Output = (payload & ((2**Length-1)<<shift) ) >> shift

                print(target+otpItem["Name"], hex(Output))
                ReportDataToStationAndPDCA(target+otpItem["Name"] , Output, None, None, None)

    def nvmDump(self):
        diags("camisp --pick "+str(self.channel))
        return diags("camisp --nvmdump")


class N301Projector():
    firing=False
    def __init__(self,ch):
        self.channel = ch
    def enableProjector(self,force=False):
        if not self.firing or force:
            rct=diags("camisp --method projector en "+str(self.channel))
            if "Pass" not in rct:
                raise HardwareError("Projector on failed for ch"+str(self.channel))
            else:
                self.firing=True
    def disableProjector(self,force=False):
        if self.firing or force:
            rct=diags("camisp --method projector dis "+str(self.channel))
            if "Pass" not in rct:
                raise HardwareError("Projector off failed for ch"+str(self.channel))
            else:
                self.firing=False


class I2CDevice():
    def __init__(self,config,addr,addrlen=1,datalen=1,reverse=True):
        self.channel=config.channel
        self.dev=config.dev
        self.addr=addr
        self.addrlen=addrlen
        self.datalen=datalen
        self.reverse=reverse
    def i2cread(self,reg,datalen=0,reverse=True):
        if self.__class__.__name__ == "Oahu":
            if not self.streaming:
                ch = "0x0{:x}ffffff".format(self.channel)
                diags("camisp --method powerdevice on "+str(ch))

        if datalen==0:
            datalen=self.datalen
        def flipBytes(data,bytes):
            outData=0
            for byte in range(bytes):
                outData=outData<<8
                outData+= ( data & (0xff<<(byte*8)) ) >>(byte*8)
            return outData
        diags("camisp --pick "+str(self.channel))

        cmd="camisp --i2cread "+str(self.dev)+" "+hex(self.addr)+" "+hex(reg)+" "+str(self.addrlen)+" "+str(datalen)
        MUTE,SEuPDiagsRaiseException=getSEUPDCB()
        if not MUTE:
            print(cmd)
        rct=diags(cmd)
        match=re.match(r"RunI2cRead.*\n(0x[0-9|A-F]*)",rct)
        # print("DEBUG",int(match.group(1)))
        if reverse & self.reverse:
            return flipBytes(int(match.group(1)),datalen)
        else:
            return int(match.group(1))
    def i2cwrite(self,reg,data,datalen=0):
        if self.__class__.__name__ == "Oahu":
            if not self.streaming:
                ch = "0x0{:x}ffffff".format(self.channel)
                diags("camisp --method powerdevice on "+str(ch))

        if datalen==0:
            datalen=self.datalen # use default
        else:
            pass
        diags("camisp --pick "+str(self.channel))
        rct=diags("camisp --i2cwrite "+str(self.dev)+" "+hex(self.addr)+" "+hex(reg)+" "+str(self.addrlen)+" "+str(datalen)+" "+hex(data))
class Stopwatch():
    def __init__(self):
        self.tiks=0
        self.toks=0
        self.tikms=0
        self.tokms=0
        self.deltams=0
    def tik(self):
        self.tiks=time.time()
        self.tikms=time.ticks_ms()
    def tok(self):
        self.toks=time.time()
        self.tokms=time.ticks_ms()

        return self.runtime()
    def runtime(self):
        if self.toks-self.tiks<60:
            if self.tokms >= self.tikms:
                deltams = self.tokms - self.tikms
            else:
                deltams =(60000-self.tikms) + self.tokms
            return deltams
        else:
            if self.tokms > self.tikms:
                deltams = self.tokms - self.tikms
            else:
                deltams =(60000-self.tikms) + self.tokms
            return (self.toks-self.tiks)*1000 + (deltams%1000)
