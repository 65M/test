from shell import run
import re
import time
from camDeviceModels import *

REGTGT="PMU"

def regRead(addr):
    rct = diags("memrw --32 "+hex(addr))
    # print(rct)
    match=re.match(r"0x[0-9|A-F]+: (0x[0-9|A-F]+)",rct)
    # print(match.group(1))
    return int(match.group(1))


def regWrite(addr,data):
    cmd="memrw --32 "+hex(addr)+" "+hex(data)
    rct = diags(cmd)
    # print("\n",cmd,rct,"\n")

def regAssert(addr,data):
    regWrite(addr,data)
    datarb=regRead(addr)
    if datarb==data:
        print("Asserted "+hex(data)+" into "+hex(addr))
    else:
        print("Failed to assert "+hex(data)+" into "+hex(addr)+" got "+hex(datarb))




class BoraI2Cconfig():
    def __init__(self,channel,dev):
        self.channel=channel
        self.dev=dev


class BoraGenericCore():
    def __init__(self,name,bootTimeout=5):
        self.name=name
        self.bootTimeout=bootTimeout
    def powerOn(self, oslog=False):
        diags("csi pick CSOC-"+self.name)
        if oslog:
            diags(f"csi set_log_dir {oslog}")
        rct=diags("csi on")
        if ("CSOC-" + self.name + " is already powered on" not in rct):
            print(self.name+" Booting... waiting "+str(self.bootTimeout)+" seconds")
            time.sleep(self.bootTimeout)

class BoraMSG():
    MAP={
    "MCAML":12,
    "MCAMR":13,
    "NECAML":16,
    "NECAMR":16,
    "DCAML":20,
    "DCAMR":20,
    "BECAML":19,
    "BECAMR":19,
    "SCAML":17,
    "SCAMR":17,
    "JCAML":18,
    "JCAMR":18,
    "XCAM":15,
    "PCAM":14
    }
    def __init__(self):
        pass
    def initMaster(self,ch,duration=266657): # 24MHz / duration = MSG Sync framerate
        diags("msg --id "+str(ch)+" --init-master")
        diags("msg --id "+str(ch)+" --intr-en")
        diags("msg --id "+str(ch)+" --set-config master --assert-dur 24 --frame-dur "+str(duration))
        diags("msg --id "+str(ch)+" --sync-start")
    def configChannel(self,ch,master,frame_skip=0):
        diags("msg --id "+str(ch)+" --init-slave "+str(master))
        if ch == 15:
            diags("msg --id 15 --config-seq --test=3")
        else:
            diags("msg --id "+str(ch)+" --set-config slave --offset 0 --frame-skip "+str(frame_skip)+" --assert-dur 1000")
        diags("msg --id "+str(ch)+" --sync-start")

class BoraISP():
    def __init__(self):
        self.MCAML=Waimea(BoraI2Cconfig(0,0))
        self.MCAMR=Waimea(BoraI2Cconfig(1,0))
        self.NECAML=Lanai(BoraI2Cconfig(2,0))
        self.DCAML=Oahu(BoraI2Cconfig(3,0))
        self.PCAM=Juliet(BoraI2Cconfig(4,0))
        self.NECAMR=Lanai(BoraI2Cconfig(5,0))
        self.BECAML=Lanai(BoraI2Cconfig(6,0))
        self.BECAMR=Lanai(BoraI2Cconfig(7,0))
        self.DCAMR=Oahu(BoraI2Cconfig(8,0))
        self.SCAML=Oahu(BoraI2Cconfig(9,0))
        self.SCAMR=Oahu(BoraI2Cconfig(10,0))
        self.JCAML=Oahu(BoraI2Cconfig(11,0))
        self.JCAMR=Oahu(BoraI2Cconfig(12,0))
        self.XCAM=JasperPeriscope(BoraI2Cconfig(13,0))
        self.XMEM=JasperEEPROM(BoraI2Cconfig(13,0))
        self.XDRV=Riker(BoraI2Cconfig(13,0))
        self.XPMU=Will(BoraI2Cconfig(13,0))


        self.MOKUL=Moku(BoraI2Cconfig(2,2))
        self.LEXL=Lex(BoraI2Cconfig(2,2))
        self.MOKUR=Moku(BoraI2Cconfig(5,2))
        self.LEXR=Lex(BoraI2Cconfig(5,2))

        self.PDRV=Rigel(BoraI2Cconfig(8,0))
        self.PPRJ=Romeo(BoraI2Cconfig(4,0))

        self.ODRV=Rigel(BoraI2Cconfig(10,0))

        self.XPMU=Will(BoraI2Cconfig(13,2))

        self.ADAMSOL=Adams("cpmu")
        self.ADAMSCL=Adams("cpmu2")
        self.ADAMSOR=Adams("cpmu3")
        self.ADAMSCR=Adams("cpmu4")

        self.SF0=N301SuperFrame(0)
        self.SF1=N301SuperFrame(1)
        self.SF2=N301SuperFrame(2)
        self.SF3=N301SuperFrame(3)
        self.SF4=N301SuperFrame(4)

    def powerOn(self, oslog=False):
        if not self.isBooted(oslog):
            print("ISP Booting...")
            # time.sleep(12)
            #diags('camisp --rmcsendcommand "oslogEnable 0"')
        else:
            print("ISP Already booted")
        diags("camisp --dbgfw on")
        diags("camisp --setfirmwarebootarg 16 0x00010000")
        diags("camisp --find")

    def isBooted(self, oslog=False):
        diags("csi pick CSOC-ISP ")
        if oslog:
            diags(f"csi set_log_dir {oslog}")
        rct = diags("csi on ")
        self.booted = "CSOC-ISP is already powered on" in rct
        return self.booted


class RegDevice():
    def __init__(self,deviceName):
        self.deviceName=deviceName
    def regWrite(self,addr,data):
        currentDevice=self.getCurrentRegDevice()
        if currentDevice is not self.deviceName:
            self.setRegDevice(self.deviceName)

        rct = diags("reg write "+hex(addr)+" "+hex(data))
        print(rct)
        #put it back
        if currentDevice is not self.deviceName:
            self.setRegDevice(currentDevice)
        if "OK" not in rct:
            raise(Exception(self.deviceName+" Register write failed"))

    def regRead(self,addr,len=1):
        currentDevice=self.getCurrentRegDevice()
        if currentDevice is not self.deviceName:
            self.setRegDevice(self.deviceName)

        rct = diags("reg read "+hex(addr)+" "+str(len))
        #put it back
        # print(rct)
        matchStr=hex(addr).upper()+".*(0X[0-9|A-F]*)"
        # print(matchStr,rct.upper())
        match=re.match(matchStr,rct.upper(),re.I)
        # print("DEBUG",int(match.group(1)))

        if currentDevice is not self.deviceName:
            self.setRegDevice(currentDevice)
        if "OK" not in rct:
                raise(Exception(self.deviceName+" Register read failed"))
        return int(match.group(1))

    def listRegDevices(self):
        rct=diags("reg list")
        outlst=[]
        for line in rct.split("\r\n"):
            if "--->" in line:
                currentDevice=line.strip("--->").strip("\t")
            elif ":" not  in  line and "OK" not  in  line and line is not "":
                outlst.append(line.strip("\t"))
        outlst.insert(0,currentDevice)
        return outlst

    def getCurrentRegDevice(self):
        return self.listRegDevices()[0]

    def setRegDevice(self,device):
        avalLst=self.listRegDevices()
        if device in avalLst:
            diags("reg select "+device)
        else:
            raise Exception("Selected Register Device is Not Avaliable")


class Adams(RegDevice):
    def __init__(self,regDeviceName):
        RegDevice.__init__(self,regDeviceName)
    def setIO(self,ID,state):# GPIO ID count start at 1
        self.regWrite(0x1d01+3*(ID-1),0x80+state)

    def getIO(self,ID):
        val1=self.regRead(0x1DC2)
        val2=self.regRead(0x1DC3)
        IOStates= val2 << 8 + val1
        state = (0x01 << ID) & IOStates !=0
        return state

class SEP:
    def __init__(self):
        diags("sep --init")
        diags("sep --wait_for_ep_ready soys")
    def secureIO(self,LR,state):
        if LR == "L":
            diags("egpio --pick sep --pin 0 --write "+str(int(state)))
            diags("egpio --pick sep --pin 0 --write "+str(int(state)))
        elif LR == "R":
            diags("egpio --pick sep --pin 1 --write "+str(int(state)))
            diags("egpio --pick sep --pin 1 --write "+str(int(state)))
class Fan:
    def __init__(self,LR):
        if LR == "L":
            self.fanID="F1"
        elif LR == 'R':
            self.fanID="F0"
        else:
            raise NameError("supply L or R to LR argument")


    def enablePWM(self):
        diags("smc write "+self.fanID+"Md 1")
    def readTach(self):
        rct=diags("smc fread "+self.fanID+"Ac")
        regex = re.compile("Ac = ([0-9|.]*)")
        return float(regex.match(rct).group(1))
    def setRPM(self,rpm):
        diags("smc fwrite "+self.fanID+"Tg "+str(int(rpm)))
    def gotoRPM(self,target):
        maxIter=10
        iter=0
        delta=10000
        self.setRPM(target)
        while delta>100:
            time.sleep(1)
            delta=abs(target-self.readTach())
            iter = iter+1
            if iter>maxIter:
                print("Timed out waiting to reach RPM")
                return


class XMOT:
    def __init__(self,LR):
        if LR == "L":
            self.motID="motor1"
        elif LR == 'R':
            self.motID="motor2"
        else:
            raise NameError("supply L or R to LR argument")

        # diags("reg select csoc")
        # diags("reg write 0x23C10001C 0xC44A81")
    def init(self):
        diags("sensor --sel motor1   --init")
        diags("sensor --sel motor2   --init")
        diags("sensor --sel motor1  --exectest set --testopts 0x4A 1 0")
        diags("sensor --sel motor2  --exectest set --testopts 0x4A 1 0")

    def gotoHardStop(self,dir):
        fullrange=16000
        cumSteps=0
        step=500
        posDelta=step
        while posDelta > 50:
            st,en=self.move(dir,step)
            posDelta=abs(st-en)
            print("----------------",posDelta)
            cumSteps+=step
            if cumSteps > fullrange:
                return
            time.sleep(1)

    def gocmd(self,pos):
        rct=diags('sensor --sel '+self.motID+' --exectest go --testopts "--pos '+str(pos)+' --timeout 40000ms"')

    def move(self,dir,dist):

        if dir=="T":
            dir="rev"
        else:
            dir="fwd"

        rct=diags('sensor --sel '+self.motID+' --exectest move --testopts "--pos '+str(dist)+' --dir '+dir+'"')
        regexStr = r"encoder data ([0-9]*)"
        regex = re.compile(regexStr)
        matchNum=0
        locs=[]
        for line in rct.split("\n"):
            if regex.match(line):
                # print("lined matched",line)
                locs.append(float(regex.match(line).group(1)))

        startPos=locs[0]
        endPos=locs[-1]
        return startPos,endPos

class Bora(RegDevice):
    booted=False
    isp=BoraISP()
    msg=BoraMSG()
    ccpu=BoraGenericCore("CCPU",bootTimeout=5)
    aop=BoraGenericCore("AOP",bootTimeout=0)
    dcp=BoraGenericCore("DCP",bootTimeout=0)
    dcp2=BoraGenericCore("DCP2",bootTimeout=0)
    dcp3=BoraGenericCore("DCP3",bootTimeout=0)

    xmotl=XMOT("L")
    xmotr=XMOT("R")

    def __init__(self,fwpath=""):
        RegDevice.__init__(self,"csoc")


    def isBooted(self):
        rct=diags("csoc --on")
        #self.booted="APCIE Enumerate on completed" not in rct
        self.booted="Bora already booted..." in rct
        return self.booted


    def boot(self,path=""):
        if not self.isBooted():
            print("Bora not booted, booting...")
            diags("csoc --on")
            diags("csoc --load_firmware "+path)
            # diags("csi pick CSOC-CCPU ")
            # diags("csi on ")
            # diags("csi pick CSOC-AOP ")
            # diags("csi on ")
        else:
            print("Bora already booted...")
        self.ccpu.powerOn()
        self.aop.powerOn()



    def listCSIs(self):
        rct = diags("csi list")
        # print(rct)
        CSIs=[]
        for line in rct.split("\r\n"):
            if  "OK" not in line and line is not "":
                CSIs.append(line)
        return CSIs

    def rxFrameCounter(self,ch):
        if ch == 0:
            return self.regRead(0x265840040)
        if ch == 1:
            return self.regRead(0x261840040)
        if ch == 2:
            return self.regRead(0x265890040)
        if ch == 3:
            return self.regRead(0x265870040)
        if ch == 4:
            return self.regRead(0x2618a0040)
        if ch == 5:
            return self.regRead(0x261890040)
        if ch == 6:
            return self.regRead(0x265880040)
        if ch == 7:
            return self.regRead(0x261880040)
        if ch == 8:
            return self.regRead(0x261870040)
        if ch == 9:
            return self.regRead(0x265850040)
        if ch == 10:
            return self.regRead(0x261850040)
        if ch == 11:
            return self.regRead(0x265860040)
        if ch == 12:
            return self.regRead(0x261860040)


def getBoardId(print_en):
    cmd = 'boardid'
    resp = diags(cmd)
    a = resp.split()
    for i in range(len(a)):
        if(a[i][0:2] == '0x'):
            if(a[i] == '0x47'):
                if(print_en == True):
                    print("INFO: BOARD TYPE = DEV")
                return 'DEV'
            else:
                if(print_en == True):
                    print("INFO: BOARD TYPE = HMD")
                return 'HMD'
    print("INFO: BOARD ID READ FAIL")
    return 'FAIL'

def setGPIO(port,pin,state):
    if(pin_state > 0):
        resp = diags('socgpio --port '+str(port)+' --pin '+str(pin)+' --output 1')
    else:
        resp = diags('socgpio --port '+str(port)+' --pin '+str(pin)+' --output 0')
    return

bora=Bora()
cota=RegDevice("rpmu")
sep=SEP()
fanl=Fan("L")
fanr=Fan("R")
