
from seup import *

import os


PDCA.setSuite("Test")
# PDCA.setPath(dirname(sys.argv[0]))
PDCA.setPath("nandfs:\\")

PDCA.writePreflightFiles()


ReportDataToStationAndPDCA('INT In Range',      5,None,1,10)
ReportDataToStationAndPDCA('INT Out of Range',  15,None,1,10)
ReportDataToStationAndPDCA('FLOAT In Range',      5.11,None,1,10)
ReportDataToStationAndPDCA('FLOAT Out of Range',  15.11,None,1,10)

ReportDataToStationAndPDCA('strUnit INT In Range',      5,'W',1,10)
ReportDataToStationAndPDCA('strUnit INT Out of Range',  15,'W',1,10)
ReportDataToStationAndPDCA('strUnit FLOAT In Range',      5.11,'W',1,10)
ReportDataToStationAndPDCA('strUnit FLOAT Out of Range',  15.11,'W',1,10)

ReportDataToStationAndPDCA('strval',  "hell ya", None,None,None)
ReportDataToStationAndPDCA('strvallim',  "hell ya",None, "hell ya","hell ya")
ReportDataToStationAndPDCA('strvallim',  "hell ya",None, "hell no","hell no")

PDCA.writePostflightFiles()
