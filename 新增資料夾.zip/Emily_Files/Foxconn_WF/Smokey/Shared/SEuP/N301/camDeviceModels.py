import time, sys
import math
# from tqdm import tqdm
from seupCommon import *
VERBOSE=True

CAMDEVICEMODELS_VER = "2023-06-23-01"
print("camDeviceModels Version: "+CAMDEVICEMODELS_VER)


class EEPROM(I2CDevice):
    def __init__(self,sib):
        I2CDevice.__init__(self,sib,0x50,1,1)

class Rigel(I2CDevice):
    def __init__(self,sib):
        I2CDevice.__init__(self,sib,0x55,1,1)
        if sib.channel == 8:    # PDRV OPRJ-L, Rigel L I2C shared bus
            self.side = 1

        elif sib.channel == 10: # ODRV OPRJ-R, Rigel R I2C shared bus
            self.side = 2
        else:
            self.side = ""

    def getChipID(self):
        dat1=int(self.i2cread(0x00))
        dat2=int(self.i2cread(0x01))
        return (dat1<<8)+dat2

    def getChipRev(self):
        return self.i2cread(0x02)

    def getState(self):
        if sys.platform == "uefi":
            self.i2cread(0x00)#dummy read
            rct=diags("camisp --method prewitt rigel{} status".format(self.side))

            match=re.match("Rigel State 0x07:0x([0-9|A-F]{2})",rct)
            statusStr=match.group(1)
            print("Rigel State:"+statusStr)
            return (int(match.group(1),16))
        else:
            return self.i2cread(0x07)

    def getOTPCheckSum(self):
        dat1=int(self.i2cread(0xEC))
        dat2=int(self.i2cread(0xED))
        dat3=int(self.i2cread(0xEE))
        return dat1<<16+dat2<<8+dat3

    def gotoPage(self,page):
        self.i2cwrite(0x24,page)
        self.i2cwrite(0xBF,page)

    def getOTPVer(self):
        data=int(self.i2cread(0xEF))
        return data & 0x3F

    # Ref Rigel6_ERS
    def OTPValidation(self, RigelSafetyParamTable, ExpectedOTP):
        ExpectedRigelRev = 0x00
        #read rigel device_id + device_revision.
        Device_ID = self.getChipID()
        Device_Rev = self.getChipRev()

        print("Rigel Device Revision is "+hex(Device_Rev)+" and Device ID is "+hex(Device_ID))
        ReportDataToStationAndPDCA("Rigel_Device_Revision", Device_Rev, None, None, None)
        ReportDataToStationAndPDCA("Rigel_Device_ID", Device_ID, None, None, None)

        self.gotoPage(1)
        OTP_ver = self.getOTPVer()
        OTP_limits = ExpectedOTP

        #Get expected OTP version from Rigel (Device ID LSB)
        if OTP_ver != ExpectedOTP:
            print("Did not find correct OTP version for this Rigel revision")

        print("Rigel OTP version is "+ hex(OTP_ver))
        ReportDataToStationAndPDCA("Rigel_OTP_Version", OTP_ver, "hex", OTP_limits, OTP_limits)

        self.SafetyParamCheck(RigelSafetyParamTable)
        self.gotoPage(0)


    def IsOTPWritable(self):
        # CameraRamlogInit()
        IsSensorConnected=True# impllement juliet connection
        if IsSensorConnected :
            diags("camisp --method projectortestmode en")
        else:
            # i2cwrite <busnum> 0x55 0xBC 1 1 0x31” for enable, and “i2cwrite <busnum> 0x55 0xBC 1 1 0” for disable.
            self.i2cwrite(0xBC,0x31)
            # diags("camisp --i2cwrite "+RigelBus+" 0x55 0xBC 1 1 0x31")

        #Read back OTP status register to check if we entered in debug mode or not.
        OTP_Reg = self.i2cread(0x20)
        if OTP_Reg == 0x0 :
            OTP_Status = 0
        else:
            OTP_Status = 1

        if IsSensorConnected :
            diags("camisp --method projectortestmode dis")
        else:
            self.i2cwrite(0xBC,0x00)
            # diags("camisp --i2cwrite "+RigelBus+" 0x55 0xBC 1 1 0x0")

        ReportDataToStationAndPDCA("RIGEL_Is_OTP_Writable", OTP_Status, None, 0, 0)


    def SafetyParamCheck(self, RigelSafetyParamTable):
        for item in RigelSafetyParamTable:
            payload = self.i2cread(item["Reg"],datalen=item["NumofBytes"])
            bits=item["NumofBytes"]*8
            print(hex(payload))

            for otpItem in item["OTPDetails"]:
                Start = otpItem["StartBit"]
                Length = otpItem["Len"]
                Limits = otpItem["Result"]
                lsl, usl = Limits, Limits
                if isinstance(Limits, list):
                    lsl, usl = Limits[0], Limits[1]
                shift=(bits-Start-Length)
                print("Shift ",shift)
                Output = (payload & ((2**Length-1)<<shift) ) >> shift

                print(otpItem["Name"], hex(Output))
                ReportDataToStationAndPDCA(otpItem["Name"].upper(), Output, None, lsl, usl)

    def RigelTestModeTest(self):
        TestModeResult = 0
        # Write 0x31 -> reg 0xBC
        self.i2cwrite(0xBC, 0x31)
        self.i2cread(0xBC)
        # Expect reg 0x20 [2:0] = 0
        debug_status = self.i2cread(0x20) & 0x7
        TestModeResult = 1 if debug_status==0 else 0
        ReportDataToStationAndPDCA("RIGEL_TESTMODE_TEST", TestModeResult, None, 1, 1)

    def IdleStatusCheck(self):
        Passed = True
        Rigel_State_Expected = 0
        # Rigel_State_Limits = [0x24, 0x29, 0x3A] # Expected values for Rigel_State

        # Based on the conversation with ISP FW team, manually forcing Rigel out of standby bypasses the ISP FW logic to use the SW timer to tickle the rigel watchdog. Instead, a combination of projector en and sf start will let ISP FW handle the steps to exit standby and sw timer + watchdog.
        self.configureStrobe(2)
        Rigel_Fault_Status = self.getFaultStatus()
        Rigel_CC1_Status, Rigel_CC2_Status = self.getCCStatus()
        # Rigel_State = bora.isp.PDRV.i2cread(0x07)
        Rigel_State = self.getState()

        # reg 0x07, main state machine:
        # bit[7]: RESERVED
        # bit[6:2] status_mfsm_main
        # bit[1:0] status_msfm_ana
        if (Rigel_State & 0b01111100) > 0x0:
            Rigel_State_Expected = 1

        Passed = ReportDataToStationAndPDCA("Rigel_Fault_Status", Rigel_Fault_Status, None, 0, 0) and Passed
        Passed = ReportDataToStationAndPDCA("Rigel_CC1_Status", Rigel_CC1_Status, None, 0, 0) and Passed
        Passed = ReportDataToStationAndPDCA("Rigel_CC2_Status", Rigel_CC2_Status, None, 0, 0) and Passed
        Passed = ReportDataToStationAndPDCA("Rigel_State_Expected", Rigel_State_Expected, None, 1, 1) and Passed
        Passed = ReportDataToStationAndPDCA("Rigel_State", Rigel_State, None, 0x24, None) and Passed

        return Passed


    def getFaultStatus(self, live=False):
        if (sys.platform == "uefi") and (live == False):
            self.i2cread(0x00)#dummy read
            rct=diags("camisp --method prewitt rigel{} status".format(self.side))

            match=re.match("Fault Status 0x7C,0x7E,0x80,0x82,0x84:(0x[0-9|A-F]{2}) 0x([0-9|A-F]{2}) 0x([0-9|A-F]{2}) 0x([0-9|A-F]{2}) 0x([0-9|A-F]{2})",rct)
            statusStr=match.group(1)+match.group(2)+match.group(3)+match.group(4)+match.group(5)
            print("Rigel Status :"+statusStr)
            return int(statusStr,16)
        else:
            Rigel_Fault_Status=0
            Rigel_Fault_Status = Rigel_Fault_Status<<8  + self.i2cread(0x7C)
            Rigel_Fault_Status = Rigel_Fault_Status<<8  + self.i2cread(0x7E)
            Rigel_Fault_Status = Rigel_Fault_Status<<8  + self.i2cread(0x80)
            Rigel_Fault_Status = Rigel_Fault_Status<<8  + self.i2cread(0x82)
            Rigel_Fault_Status = Rigel_Fault_Status<<8  + self.i2cread(0x84)
            return Rigel_Fault_Status

    def getCCStatus(self):
        if sys.platform == "uefi":
            self.i2cread(0x00)#dummy read
            rct=diags("camisp --method prewitt rigel{} status".format(self.side))

            match=re.match("CC State 0x1C,0xF0:0x([0-9|A-F]{2}) (0x[0-9|A-F]{2})",rct)
            statusStr=match.group(1)+match.group(2)
            print("Rigel CC Status :"+statusStr)
            return (int(match.group(1),16),int(match.group(2),16))
        else:

            CC1=int(self.i2cread(0x1C))
            CC2=int(self.i2cread(0xF0))
            return CC1,CC2

    def configureStrobe(self, source, current=None):
        # Refer to Rigel6C/Rigel6D IOUT characteristics for LUT
        if source == 1:
            iout = 0x02
            iout_ctx = 0x4C
            if not current:
                current = 0x9B

        elif source == 2:
            iout = 0x04
            iout_ctx = 0x4D
            if not current:
                current = 0x3A
        else:
            return -1

        self.i2cwrite(0x24, 0x01)
        self.i2cwrite(0xFA, 0x62)
        self.i2cwrite(0x24, 0x00)
        self.i2cwrite(0x5F, 0x01)
        self.i2cwrite(0x60, 0x06)
        self.i2cwrite(0x85, 0x40)
        self.i2cwrite(iout_ctx, current) # prewitt 398.3mA = 0x3A / 58d
        self.i2cwrite(0x49, iout) # prewitts on IOUT2 = 0x04
        self.i2cwrite(0x54, 0x01)

        self.i2cwrite(0x61, 0x01) # strobe_count = 1, 0 is broken
        self.i2cwrite(0x62, 0x00)
        self.i2cwrite(0x63, 0x00)
        self.i2cwrite(0x57, 0xF0) # delay_ctxa = 54000d, 0xD2F0 = 4.5ms
        self.i2cwrite(0x58, 0xD2)
        self.i2cwrite(0x59, 0x00)
        diags('wait 100')
        self.i2cwrite(0x2E, 0x69)
        self.i2cwrite(0x46, 0x05)

    def OahuStrobeTest(self):
        StrobeResult = 0

        start_pcnt = self.i2cread(0x14)

        # bora.isp.DCAML.primeStrobe(ton=illegal_drive_us)
        # if not camera.streaming:
        #     startExternalStream(camera)
        # Based on the conversation with ISP FW team, manually forcing Rigel out of standby bypasses the ISP FW logic to use the SW timer to tickle the rigel watchdog. Instead, a combination of projector en and sf start will let ISP FW handle the steps to exit standby and sw timer + watchdog.
        # self.configureStrobe(2)
        time.sleep(0.5)

        stop_pcnt = self.i2cread(0x14)
        state = self.getState()
        if stop_pcnt > start_pcnt or (state & 0b00000011) > 0x0:
            StrobeResult = 1

        ReportDataToStationAndPDCA("RIGEL_Oahu_Strobe_Test", StrobeResult, None, 1, 1)


    def ThrottleTest(self):
        rct = diags('i2c -d 12 0x08 0xE4 1')
        if "Data:  0x00" in rct:
            print("Silego is unlocked")
        else:
            print("Silego access is locked, skipping ThrottleTest")
            return

        ThrottleFaultResult = 0
        Rigel_Fault_Status = self.getFaultStatus()

        # if not camera.streaming:
        #     startExternalStream(camera)

        if (Rigel_Fault_Status >> 24 & 0x04) != 0:
            print("Rigel already throttled!")
        else:
            self.configureStrobe(2)
            # Trigger throttle signals from PMSM
            diags('i2c -v 12 0x08 0x7A 0xE0')
            diags('wait 1000')

            Rigel_Fault_Status = self.getFaultStatus()
            if (Rigel_Fault_Status >> 24 & 0x04) != 0: 
                ThrottleFaultResult = 1

            # Reset throttle signal
            diags('i2c -v 12 0x08 0x7A 0xA0')

        ReportDataToStationAndPDCA("RIGEL_Throttle_Test", ThrottleFaultResult, None, 1, 1)

    def ThrottleStrobeTest(self):
        ThrottleStrobeFaultResult = 0
        Rigel_Fault_Status = self.getFaultStatus()

        # if not camera.streaming:
        #     startExternalStream(camera)
        self.configureStrobe(2)

        if (Rigel_Fault_Status >> 24 & 0x04) != 0:
            print("Rigel already throttled!")
        else:
            # Trigger throttle signals from PMSM
            diags('i2c -v 12 0x08 0x7A 0xE0')
            diags('wait 1000')

            Rigel_Fault_Status = self.getFaultStatus()
            throt_pcnt = self.i2cread(0x0A, datalen=4)
            if (Rigel_Fault_Status >> 24 & 0x04) != 0 and throt_pcnt > 0:
                ThrottleStrobeFaultResult = 1

            # Reset throttle signal
            diags('i2c -v 12 0x08 0x7A 0xA0')

        ReportDataToStationAndPDCA("RIGEL_ThrottleStrobe_Test", ThrottleStrobeFaultResult, None, 1, 1)


class Oahu(I2CDevice,N301Camera):
    def __init__(self,sib):
        I2CDevice.__init__(self,sib,0x10,2,1)
        N301Camera.__init__(self,sib.channel)
        # Refer to Oahu VSR / NVM Map: rdar://70429454, rdar://97055076
        # Limits listed are for historical reference, not enforced in pass/fail
        self.nvmIntegrityDict = [
            {"Reg" : 0x0000, "Page": 0, "NumofBytes" : 3, "NVMDetails" : [
                {"Name" : "OAHU_NVM_FLAG",                  "StartBit" : 0,    "Len" : 8,   "Result" : 0xFF},
                {"Name" : "OAHU_NVM_TYPE",                  "StartBit" : 8,    "Len" : 8,   "Result" : 0x00},
                {"Name" : "OAHU_NVM_HEADER_REVISION",       "StartBit" : 16,   "Len" : 8,   "Result" : 0x01},
            ]},
            {"Reg" : 0x0022, "Page": 0, "NumofBytes" : 4, "NVMDetails" : [
                {"Name" : "OAHU_NVM_CAMERA_PROJECT",        "StartBit" : 0,   "Len" : 8,   "Result" : [0x01,0x37]},
                {"Name" : "OAHU_NVM_PROJECT_VERSION",       "StartBit" : 8,   "Len" : 8,   "Result" : 0x01},
                {"Name" : "OAHU_NVM_INTEGRATOR",            "StartBit" : 16,  "Len" : 8,   "Result" : 0x28},
                {"Name" : "OAHU_NVM_CAMERA_BUILD",          "StartBit" : 24,  "Len" : 8,   "Result" : [0x10,0x31]},
            ]},
            {"Reg" : 0x0026, "Page": 0, "NumofBytes" : 1, "NVMDetails" : [
                {"Name" : "OAHU_NVM_CONFIG_NUMBER",         "StartBit" : 0,  "Len" : 8,   "Result" : [0x00,0x99]},
            ]},
            {"Reg" : 0x0032, "Page": 0, "NumofBytes" : 3, "NVMDetails" : [
                {"Name" : "OAHU_NVM_IRCF",                  "StartBit" : 0,   "Len" : 8,   "Result" : [0x25,0x27]},
                {"Name" : "OAHU_NVM_SUBSTRATE",             "StartBit" : 8,   "Len" : 8,   "Result" : 0x65},
                {"Name" : "OAHU_NVM_SENSOR",                "StartBit" : 16,  "Len" : 8,   "Result" : [0x20,0x26]},
            ]},
            {"Reg" : 0x0036, "Page": 0, "NumofBytes" : 1, "NVMDetails" : [
                {"Name" : "OAHU_NVM_LENS",                  "StartBit" : 0,   "Len" : 8,   "Result" : [0x60,0x6F]},
            ]},
            {"Reg" : 0x003A, "Page": 0, "NumofBytes" : 3, "NVMDetails" : [
                {"Name" : "OAHU_NVM_FLEX",                  "StartBit" : 0,   "Len" : 8,   "Result" : 0x61},
                {"Name" : "OAHU_NVM_STIFFENER",             "StartBit" : 8,   "Len" : 8,   "Result" : [0x08,0x0B]},
                {"Name" : "OAHU_NVM_TRIM_SOMA",             "StartBit" : 16,  "Len" : 8,   "Result" : [0x08,0x21]},
            ]},
        ]

    def getChipSerial(self):
        dat1=int(self.i2cread(0xfad3))
        dat2=int(self.i2cread(0xfad4))
        return (dat1<<8)+dat2
    def getChipID(self):
        dat1=int(self.i2cread(0xfAC7))
        # print(hex(dat1))
        dat2=int(self.i2cread(0xfAC8))
        # print(hex(dat2))
        return (dat1<<8)+dat2
    def getFrameCounter(self):
        return self.i2cread(0x0018)
    def getLotCode(self):
        return self.i2creadChunk([0xfacb,0xfacc,0xfacd,0xface,0xfacf,0xfad0,0xfad1,0xfad2,0xfad3,0xfad4])
    def getFabID(self):
        return self.i2creadChunk([0xfac9,0xface,0xfad5,0xfaca])

    # def gotoNVMPage(self, page):
    #     # Context switch to OTPIF_PAGE_SELECT (0x3202) -> 0x0-0x57
    #     self.i2cwrite(0xE002, page)
    #     # Set read mode by OTPIF_CTRL (0x3200) -> 1
    #     self.i2cwrite(0xE000, 0x1)

    def getNVMreg(self, reg):
        # convert "0x0020" to NVM-readable register, i.e. 0x3224
        otp_offset = 0xF000
        # otpif_dt_63 = 0xE043
        otp_reg = otp_offset + reg

        return otp_reg

    def stream(self):
        self.i2cwrite(0x30eb,  0x05 )
        self.i2cwrite(0x30eb,  0x0c )
        self.i2cwrite(0x300a,  0xffff )
        self.i2cwrite(0x0110,  0x0101 )
        self.i2cwrite(0x0124,  0x1800 )
        self.i2cwrite(0x014d,  0x0000f4 )
        self.i2cwrite(0x0155,  0x000aa1 )
        self.i2cwrite(0x016e,  0x00 )
        self.i2cwrite(0x0170,  0x00 )
        self.i2cwrite(0x0172,  0x00 )
        self.i2cwrite(0x0174,  0x0000000005000500 )
        self.i2cwrite(0x0180,  0x0100 )
        self.i2cwrite(0x018a,  0x00 )
        self.i2cwrite(0x018d,  0x000000 )
        self.i2cwrite(0x0195,  0x000008 )
        self.i2cwrite(0x01c8,  0x00 )
        self.i2cwrite(0x01d0,  0x00 )
        self.i2cwrite(0x01e8,  0x00 )
        self.i2cwrite(0x01f0,  0x8280 )
        self.i2cwrite(0x0301,  0x08 )
        self.i2cwrite(0x0304,  0x02 )
        self.i2cwrite(0x0306,  0x00aa )
        self.i2cwrite(0x0311,  0x03 )
        self.i2cwrite(0x03e0,  0x00 )
        self.i2cwrite(0x03e2,  0x0100 )
        self.i2cwrite(0x0511,  0x81 )
        self.i2cwrite(0x0528,  0x55f000 )
        self.i2cwrite(0x0598,  0x02 )
        self.i2cwrite(0x0624,  0x05000500 )
        self.i2cwrite(0x0550,  0x01 )
        self.i2cwrite(0x0518,  0x0c0c0202 )
        self.i2cwrite(0x0514,  0x03 )
        self.i2cwrite(0x0551,  0x02 )
        self.i2cwrite(0x0554,  0x03e803e8 )
        self.i2cwrite(0x0564,  0x3e )
        self.i2cwrite(0x0567,  0x02 )
        self.i2cwrite(0x0553,  0x00 )
        self.i2cwrite(0x0552,  0x02 )
        self.i2cwrite(0x0560,  0x03e803e8 )
        self.i2cwrite(0x0524,  0x0101 )
        self.i2cwrite(0x0108,  0x02 )
        self.i2cwrite(0x0149,  0x00 )
        self.i2cwrite(0x0600,  0x0000 )
        self.i2cwrite(0x0550,  0x00 )
        self.i2cwrite(0x0600,  0x0000 )
        self.i2cwrite(0x0511,  0x81 )
        self.i2cwrite(0x052c,  0x20 )
        self.i2cwrite(0x052d,  0x07 )
        self.i2cwrite(0x051d,  0x00 )
        self.i2cwrite(0x05ec,  0x01 )
        self.i2cwrite(0x05ed,  0x3c )
        self.i2cwrite(0x0554,  0x04 )
        self.i2cwrite(0x0555,  0x65 )
        self.i2cwrite(0x0560,  0x04 )
        self.i2cwrite(0x0561,  0x65 )
        self.i2cwrite(0x0553,  0x00 )
        self.i2cwrite(0x0550,  0x01 )
        self.i2cwrite(0x0524,  0x01 )
        self.i2cwrite(0x0525,  0x01 )
        self.i2cwrite(0x0500,  0x01 )
        self.i2cwrite(0x0510,  0x01 )
        self.i2cwrite(0x0518,  0x0c )
        self.i2cwrite(0x0519,  0x0c )
        self.i2cwrite(0x052d,  0x03 )
        self.i2cwrite(0x052d,  0x02 )
        self.i2cwrite(0x052d,  0x00 )
        self.i2cwrite(0x0178,  0x0500 )
        self.i2cwrite(0x017a,  0x0500 )
        self.i2cwrite(0x0155,  0x000aa0 )
        self.i2cwrite(0x014d,  0x0007f8 )
        self.i2cwrite(0x0180,  0x01)
        self.i2cwrite(0x0181,  0x00)
        self.i2cwrite(0x0108,  0x00)
        self.i2cwrite(0x0100,  0x01 )
        self.i2cwrite(0x012c,  0x0101 )

    def primeStrobe(self,ton=4500):#ton in us
        tonval=int(ton/4.083)
        print("Ton reg",hex(tonval))
        self.i2cwrite(0x0681,0x00,1)
        self.i2cwrite(0x0650,0x01,1)
        self.i2cwrite(0x0651,0x04,1)
        self.i2cwrite(0x0680,0x00,1)
        self.i2cwrite(0x0685,0x00,3)
        self.i2cwrite(0x068c,tonval,4)
        self.i2cwrite(0x0670,0x01,1)

    def setExposure(self):
        # set exposure to 8 ms
        self.i2cwrite(0x014D, 0x00)
        self.i2cwrite(0x014E, 0x07)
        self.i2cwrite(0x014F, 0xD0)
        self.i2cread(0x014D)

    def setBlackLevelGain(self, gain):
        ana_gain = 256 * (1 - 1 / gain)
        self.i2cwrite(0x0149, int(ana_gain))
        self.i2cread(0x0149)

    def opticalBlackRegDump(self,prefix=""):
        opticalBlackSum = 0
        for i in range (10):
            test_name = "ROUND_"+str(i)+"_"+prefix+"_OPTICAL_BLACK_"
            breg1 = self.i2cread(0x0400, 2)
            breg2 = self.i2cread(0x0404, 4)
            breg3 = self.i2cread(0x0408, 4)
            breg4 = self.i2cread(0x0414, 4)
            breg5 = self.i2cread(0x0418, 4)
            diags("wait 8")
            opticalBlackSum += sum([breg1, breg2, breg3, breg4, breg5])
        return opticalBlackSum


class Will(I2CDevice):
    def __init__(self,sib):
        I2CDevice.__init__(self,sib,0x40,1,1)
    def getChipID(self):
        dat1=int(self.i2cread(0x1c))
        dat2=int(self.i2cread(0x1d))
        return (dat1<<8)+dat2
    def getChipRev(self):
        return self.i2cread(0x42)
    def getState(self):
        return self.i2cread(0x49)
    def enableOutput(self):
        self.i2cwrite(0x1e,0xff)
        self.i2cwrite(0x1f,0x29)
        self.i2cwrite(0x20,0x80)
        self.i2cwrite(0x21,0x00)
        self.i2cwrite(0x22,0x00)
        self.i2cwrite(0x23,0x01)
        self.i2cwrite(0x24,0xff)
        self.i2cwrite(0x25,0x0e)
        self.i2cwrite(0x26,0xaf)
        self.i2cwrite(0x27,0xff)
        self.i2cwrite(0x28,0xff)
        self.i2cwrite(0x29,0x84)
        self.i2cwrite(0x30,0x8e)


class Riker(I2CDevice):
    def __init__(self,sib):
        I2CDevice.__init__(self,sib,0x33,1,1)
    def getDeviceID(self):
        dat1=int(self.i2cread(0x00))
        dat2=int(self.i2cread(0x01))
        return (dat1<<8)+dat2
    def getDeviceRev(self):
        dat1=int(self.i2cread(0x02))
        dat2=int(self.i2cread(0x03))
        return (dat1<<8)+dat2
    def getTraceID(self):
        dat1=int(self.i2cread(0x0004))
        dat2=int(self.i2cread(0x0005))
        dat3=int(self.i2cread(0x0006))
        dat4=int(self.i2cread(0x0007))
        return ((dat1<<24)+(dat2<<16)+(dat3<<8)+dat4)
    def getOTPVer(self):
        dat1=int(self.i2cread(0x40))
        return dat1
    def getTrimOTPVer(self):
        dat1=int(self.i2cread(0x08))
        dat2=int(self.i2cread(0x09))
        return (dat1<<8)+dat2
    def getArmingStatus(self):
        dat1=int(self.i2cread(0x3D))
        return dat1
    def getRDFResistance(self):
        rct=diags("camisp --method riker-status")
        match=re.match("RDF resistance: ([0-9]*)",rct)
        return int(match.group(1))
    def interruptDump(self,prefix=""):
        regs=[0x43,0x44,0x45,0x46]
        dats=[]
        for reg in regs:
            dats.append(self.i2cread(reg))

        return dats


class JasperEEPROM(I2CDevice):
    def __init__(self,sib):
        I2CDevice.__init__(self,sib,0x51,2,1)
    # Refer to Jasper NVM Integrity Check
    def getVersion(self):
        return int(self.i2cread(0x0000))
    def getProject(self):
        return int(self.i2cread(0x0001))
    def getProjectVersion(self):
        return int(self.i2cread(0x0002))
    def getIntegrator(self):
        return int(self.i2cread(0x0003))
    def getBuild(self):
        return int(self.i2cread(0x0004))
    def getConfig(self):
        return int(self.i2cread(0x0005))
    def getSubstrate(self):
        return int(self.i2cread(0x0006))
    def getDriver(self):
        return int(self.i2cread(0x0007))
    def getKirk(self):
        return int(self.i2cread(0x0008))
    def getPeriscope(self):
        return int(self.i2cread(0x0009))
    def getIRFilter(self):
        return int(self.i2cread(0x000A))
    def getTXLens(self):
        return int(self.i2cread(0x000B))
    def getRXLens(self):
        return int(self.i2cread(0x000C))
    def getDOE(self):
        return int(self.i2cread(0x000D))
    def getLensHolder(self):
        return int(self.i2cread(0x000E))
    def getShieldCan(self):
        return int(self.i2cread(0x000F))
    def getFlex(self):
        return int(self.i2cread(0x0010))
    def getStiffener(self):
        return int(self.i2cread(0x0011))
    def getDriverShield(self):
        return int(self.i2cread(0x0012))
    def getLiner(self):
        return int(self.i2cread(0x001E))

    def getEEPROM(self):
        dat1=int(self.i2cread(0x0002))
        dat2=int(self.i2cread(0x0004))
        dat3=int(self.i2cread(0x0005))
        return ((dat1<<16)+(dat2<<8)+dat3)
    def getFrameCounter(self):
        return self.i2cread(0x01D1)


class JasperPeriscope(I2CDevice,N301Camera,N301Projector):
    def __init__(self,sib):
        I2CDevice.__init__(self,sib,0x10,2,1)
        N301Camera.__init__(self,sib.channel)
        N301Projector.__init__(self,sib.channel)

    def getChipID(self):
        dat=0
        for i in range(16):
            dat=(dat << 8) + self.i2cread(0x7e0+i)
        return dat
    def getTBCCNT(self):
        return int(self.i2cread(0x01D1))
    def getTMSTAMP(self):
        return int(self.i2cread(0x0118, datalen=4))
    def setComplianceMode(self,mode):
        diags("camisp --pick "+str(self.channel))
        diags("camisp --method settofcompliance "+str(self.channel)+" "+str(mode))
        diags("camisp --sf opts 5")
# function jasperDLI()
#   Shell("camisp #exit") # reduncant exit
#   Shell("camisp #find")
#   reg2C4,reg2C5,reg2C6,reg2C7=checkJasperStatus()
#
#   print("JASPER_INIT_STATE",   reg2C4,"0x", 0x42, 0x42)
#   print("JASPER_INIT_AUX",     reg2C5,"0x",nil,nil)
#   print("JASPER_INIT_LNKTRN",  reg2C6,"0x",nil,nil)
#   print("JASPER_INIT_ERRCODE", reg2C7,"0x",nil,nil)
#
#   if reg2C4 == 0x42 :
#     print("Jasper Initial State Check Passed!")
#   else
#     print("Jasper Initial State Check Failed!")
#     Shell("camisp #exit")
#     return false
#     #TODO: start steam!!
#   reg2C4,reg2C5,reg2C6,reg2C7=checkJasperStatus()
#
#   if (reg2C4 ~= 0x41) :
#     print("Resampling status")
#     hw.time.ustall(10000)
#     reg2C4,reg2C5,reg2C6,reg2C7=checkJasperStatus()
#
#
#   print("JASPER_FINAL_STATE",   reg2C4,"0x", 0x41, 0x41)
#   print("JASPER_FINAL_AUX",     reg2C5,"0x",0,0)
#   print("JASPER_FINAL_LNKTRN",  reg2C6,"0x",0,0)
#   print("JASPER_FINAL_ERRCODE", reg2C7,"0x",0,0)
#
#   if (reg2C4 == 0x41) and reg2C5+reg2C6+reg2C7 == 0x00 :
#     print("Jasper Streaming State Check Passed!")
#   else
#     print("Jasper Streaming State Check Failed!")
#     Shell("camisp #exit")
#     return false

    def checkJasperStatus(self):
        reg2C4=int(self.i2cread(0x2c4))
        reg2C5=int(self.i2cread(0x2c5))
        reg2C6=int(self.i2cread(0x2c6))
        reg2C7=int(self.i2cread(0x2c7))

        if (reg2C4 == 0x72):
            print("IMX590 Fault Decode 0x2C4: State Reset");
        elif (reg2C4 == 0x42):
            print("IMX590 Fault Decode 0x2C4: State Boot");
        elif (reg2C4 == 0x56):
            print("IMX590 Fault Decode 0x2C4: State VT-PLL Start");
        elif (reg2C4 == 0x76):
            print("IMX590 Fault Decode 0x2C4: State VT-PLL Stop");
        elif (reg2C4 == 0x4F):
            print("IMX590 Fault Decode 0x2C4: State OT-PLL Start");
        elif (reg2C4 == 0x6F):
            print("IMX590 Fault Decode 0x2C4: State OT-PLL Stop");
        elif (reg2C4 == 0x52):
            print("IMX590 Fault Decode 0x2C4: State Re-Training");
        elif (reg2C4 == 0x4C):
            print("IMX590 Fault Decode 0x2C4: State Link-Training");
        elif (reg2C4 == 0x4D):
            print("IMX590 Fault Decode 0x2C4: State Link Maintenance");
        elif (reg2C4 == 0x41):
            print("IMX590 Fault Decode 0x2C4: State ALPM");
        elif (reg2C4 == 0x43):
            print("IMX590 Fault Decode 0x2C4: State VC Change");
        elif (reg2C4 == 0x47):
            print("IMX590 Fault Decode 0x2C4: State PLL Agile");
        elif (reg2C4 == 0x44):
            print("IMX590 Fault Decode 0x2C4: State Manual DPCD");
        elif (reg2C4 == 0x59):
            print("IMX590 Fault Decode 0x2C4: State Standby");
        elif (reg2C4 == 0x45):
            print("IMX590 Fault Decode 0x2C4: State Error");


        if reg2C5 == 0x00 :
            print("AUX Success")
        elif reg2C5 == 0xFF	:
            print("AUX Write error (transaction timeout retry of count become maximum)")
        elif reg2C5 == 0xFE	:
            print("AUX Write error (defer retry of count become maximum) ")
        elif reg2C5 == 0xFD	:
            print("AUX Write error (NACK reply)")
        elif reg2C5 == 0xFC	:
            print("AUX Write error (other reply than ACK,NACK,DEFER)")
        elif reg2C5 == 0xFB	:
            print("AUX Write error (No reply of count become maximum) ")
        elif reg2C5 == 0xFA	:
            print("AUX Write error (transaction bit size is not multiple of 8)")
        elif reg2C5 == 0xF9	:
            print("AUX Write error (interrupt error)")
        elif reg2C5 == 0xF8	:
            print("AUX Write error (transaction bit field violation)")
        elif reg2C5 == 0xF7	:
            print("AUX Write error (transaction byte size error)")
        elif reg2C5 == 0xF6	:
            print("AUX Write error (FW timeout) ")
        elif reg2C5 == 0xEF	:
            print("AUX READ error (transaction timeout retry of count become maximum)")
        elif reg2C5 == 0xEE	:
            print("AUX READ error (defer retry of count become maximum)")
        elif reg2C5 == 0xED	:
            print("AUX READ error (NACK reply)")
        elif reg2C5 == 0xEC	:
            print("AUX READ error (other reply than ACK,NACK,DEFER)")
        elif reg2C5 == 0xEB	:
            print("AUX READ error (No reply of count become maximum) ")
        elif reg2C5 == 0xEA	:
            print("AUX READ error (0 size read retry of count become maximum)")
        elif reg2C5 == 0xE9	:
            print("AUX READ error (transaction bit size is not multiple of 8)")
        elif reg2C5 == 0xE8	:
            print("AUX READ error (interrupt error) ")
        elif reg2C5 == 0xE7	:
            print("AUX READ error (transaction bit field violation)")
        elif reg2C5 == 0xE6	:
            print("AUX READ error (transaction byte size error) ")
        elif reg2C5 == 0xE5	:
            print("AUX READ error (FW timeout)")


        if reg2C6 == 0x00 :
            print("Link Training is OK")
        elif reg2C6 == 0x11	:
            print("Full Link Training is NG (CR error)")
        elif reg2C6 == 0x12	:
            print("Full Link Training is NG (EQ error)")
        elif reg2C6 == 0x13	:
            print("Full Link Training is NG (IRQ_HPD occur in CR)")
        elif reg2C6 == 0x14	:
            print("Full Link Training is NG (IRQ_HPD occur in EQ)")
        elif reg2C6 == 0x15	:
            print("Full Link Training is NG (Link Rate error)")
        elif reg2C6 == 0x16	:
            print("Full Link Training is NG (Link Enable Low in CR) ")
        elif reg2C6 == 0x17	:
            print("Full Link Training is NG (Link Enable Low in EQ)")
        elif reg2C6 == 0x21	:
            print("Test Automation is NG (CR error)")
        elif reg2C6 == 0x22	:
            print("Test Automation is NG (EQ error)")
        elif reg2C6 == 0x23	:
            print("Test Automation is NG (IRQ_HPD occur in CR)")
        elif reg2C6 == 0x24	:
            print("Test Automation is NG (IRQ_HPD occur in EQ)")
        elif reg2C6 == 0x25	:
            print("Test Automation is NG (Link Rate error, Lane Count error) ")
        elif reg2C6 == 0x26	:
            print("Test Automation is NG (Link Enable Low in CR)")
        elif reg2C6 == 0x27	:
            print("Test Automation is NG (Link Enable Low in EQ)")
        elif reg2C6 == 0x33	:
            print("Fast Link Training is NG (IRQ_HPD)")
        elif reg2C6 == 0x36	:
            print("FAST_LT_NG_PARAM_ERROR")
        elif reg2C6 == 0x71	:
            print("AUX CH error in Link Training")
        elif reg2C6 == 0x72	:
            print("Lane Count error in Link Training")
        elif reg2C6 == 0x73	:
            print("Lane Swap error in Link Training ")


        if (reg2C7 == 0x00) :
            print("IMX590 Fault Decode 0x2C7: No Errors");
        elif (reg2C7 == 0x11) :
            print("IMX590 Fault Decode 0x2C7: Full Link Training is NG (CR error)");
        elif (reg2C7 == 0x12) :
            print("IMX590 Fault Decode 0x2C7: Full Link Training is NG (EQ error)");
        elif (reg2C7 == 0x15) :
            print("IMX590 Fault Decode 0x2C7: Full Link Training is NG (Link Rate error)");
        elif (reg2C7 == 0x21) :
            print("IMX590 Fault Decode 0x2C7: Test Automation is NG (CR error)");
        elif (reg2C7 == 0x22) :
            print("IMX590 Fault Decode 0x2C7: Test Automation is NG (EQ error)");
        elif (reg2C7 == 0x25) :
            print("IMX590 Fault Decode 0x2C7: Test Automation is NG (Link Rate error, Lane Count error)");
        elif (reg2C7 == 0x36) :
            print("IMX590 Fault Decode 0x2C7: FAST_LT_NG_PARAM_ERROR");
        elif (reg2C7 == 0x71) :
            print("IMX590 Fault Decode 0x2C7: AUX CH error in Link Training");
        elif (reg2C7 == 0x72) :
            print("IMX590 Fault Decode 0x2C7: Lane Count error in Link Training");
        elif (reg2C7 == 0x73) :
            print("IMX590 Fault Decode 0x2C7: Lane Swap error in Link Training");

        return reg2C4,reg2C5,reg2C6,reg2C7



class Waimea(I2CDevice,N301Camera):
    def __init__(self,sib):
        I2CDevice.__init__(self,sib,0x20,2,2)
        N301Camera.__init__(self,sib.channel)
        # Refer to Kauai VSR / NVM Map: rdar://52359320
        # Limits listed are for historical reference, not enforced in pass/fail
        self.nvmIntegrityDict = [
            {"Reg" : 0x0020, "Page": 0, "NumofBytes" : 4, "NVMDetails" : [
                {"Name" : "KAUAI_NVM_REVISION",             "StartBit" : 0,    "Len" : 8,   "Result" : 0x02},
                {"Name" : "KAUAI_NVM_CAMERA_PROJECT",       "StartBit" : 16,   "Len" : 8,   "Result" : [0x01,0x36]},
                {"Name" : "KAUAI_NVM_PROJECT_VERSION",      "StartBit" : 24,   "Len" : 8,   "Result" : 0x01},
            ]},
            {"Reg" : 0x0024, "Page": 0, "NumofBytes" : 3, "NVMDetails" : [
                {"Name" : "KAUAI_NVM_INTEGRATOR_PLANT",     "StartBit" : 0,   "Len" : 8,   "Result" : 0x28},
                {"Name" : "KAUAI_NVM_CAMERA_BUILD",         "StartBit" : 8,   "Len" : 8,   "Result" : [0x10,0x31]},
                {"Name" : "KAUAI_NVM_CONFIG_NUMBER",        "StartBit" : 16,  "Len" : 8,   "Result" : [0x00,0x9E]},
            ]},
            {"Reg" : 0x0032, "Page": 0, "NumofBytes" : 3, "NVMDetails" : [
                {"Name" : "KAUAI_NVM_IRCF",                 "StartBit" : 0,   "Len" : 8,   "Result" : 0x20},
                {"Name" : "KAUAI_NVM_SUBSTRATE",            "StartBit" : 8,   "Len" : 8,   "Result" : 0x20},
                {"Name" : "KAUAI_NVM_SENSOR",               "StartBit" : 16,  "Len" : 8,   "Result" : 0x20},
            ]},
            {"Reg" : 0x0036, "Page": 0, "NumofBytes" : 1, "NVMDetails" : [
                {"Name" : "KAUAI_NVM_LENS",                 "StartBit" : 0,   "Len" : 8,   "Result" : [0x00,0x2D]},
            ]},
            {"Reg" : 0x003A, "Page": 0, "NumofBytes" : 3, "NVMDetails" : [
                {"Name" : "KAUAI_NVM_FLEX",                 "StartBit" : 0,   "Len" : 8,   "Result" : 0x10},
                {"Name" : "KAUAI_NVM_STIFFENER",            "StartBit" : 8,   "Len" : 8,   "Result" : 0x08},
                {"Name" : "KAUAI_NVM_TRIM",                 "StartBit" : 16,  "Len" : 8,   "Result" : [0x08,0x10]},
            ]},
        ]

    def getChipID(self):
        dat1=int(self.i2cread(0x0000))
        dat2=int(self.i2cread(0x0001))
        return (dat1<<8)+dat2
    def getFrameCounter(self):
        return self.i2cread(0x0018)

    def enterNVMReadMode(self):
        # self.i2cwrite(0x0510, 0x00, datalen=1)
        # self.i2cwrite(0x0500, 0x00, datalen=1)
        # self.i2cwrite(0x0100, 0x00, datalen=1)
        self.i2cwrite(0x3300, 0x29, datalen=1)
        self.i2cwrite(0x3202, 0x00, datalen=1)
        self.i2cwrite(0x3200, 0x01, datalen=1)
        otpif_status = self.i2cread(0x3201, datalen=1)
        self.i2cwrite(0x3200, 0x04, datalen=1)
        self.i2cread(0x3204, datalen=4)

        if otpif_status & 0x1 == 1:
            return True

        return False
        # Read NVM data starting from 0x3204 - 0x3243
        # self.i2cread(0x3204, datalen=4)

    # def gotoNVMPage(self, page):
    #     # Context switch to OTPIF_PAGE_SELECT (0x3202) -> 0x0-0x57
    #     self.i2cwrite(0x3202, page, datalen=1)
    #     # Set read mode by OTPIF_CTRL (0x3200) -> 1
    #     self.i2cwrite(0x3200, 0x1, datalen=1)

    def getNVMreg(self, reg, direct=False):
        # convert "0x0020" to NVM-readable register, i.e. 0x3224
        otp_offset = 0x3204
        if direct:
            otp_offset = 0x8000
        # otpif_dt_63 = 0x3243
        otp_reg = otp_offset + reg

        return otp_reg



class Juliet(I2CDevice,N301Camera):
    def __init__(self,sib):
        I2CDevice.__init__(self,sib,0x18,2,1)
        N301Camera.__init__(self,sib.channel)
        # Limits listed are for historical reference, not enforced in pass/fail
        self.nvmIntegrityDict = [
            {"Reg" : 0x019C, "Page": 0, "NumofBytes" : 4, "NVMDetails" : [
                {"Name" : "JULIET_NVM_REVISION",             "StartBit" : 0,    "Len" : 8,   "Result" : 0xC1},
                {"Name" : "JULIET_NVM_CAMERA_PROJECT",       "StartBit" : 8,    "Len" : 8,   "Result" : 0x16},
                {"Name" : "JULIET_NVM_PROJECT_VERSION",      "StartBit" : 16,   "Len" : 8,   "Result" : 0x30},
                {"Name" : "JULIET_NVM_INTEGRATOR_PLANT",     "StartBit" : 24,   "Len" : 8,   "Result" : 0x30},
            ]},
            {"Reg" : 0x01A0, "Page": 0, "NumofBytes" : 4, "NVMDetails" : [
                {"Name" : "JULIET_NVM_CAMERA_BUILD",         "StartBit" : 0,   "Len" : 8,   "Result" : [0x10,0x60]},
                {"Name" : "JULIET_NVM_CONFIG_NUMBER",        "StartBit" : 8,   "Len" : 8,   "Result" : [0x0C,0x0E]},
                {"Name" : "JULIET_NVM_FILTER",               "StartBit" : 16,  "Len" : 8,   "Result" : [0x64,0xAC]},
                {"Name" : "JULIET_NVM_SUBSTRATE",            "StartBit" : 24,  "Len" : 8,   "Result" : [0x34,0x54]},
            ]},
            {"Reg" : 0x01A4, "Page": 0, "NumofBytes" : 3, "NVMDetails" : [
                {"Name" : "JULIET_NVM_SENSOR",               "StartBit" : 0,   "Len" : 8,   "Result" : 0xBA},
                {"Name" : "JULIET_NVM_SENSOR_DOE_LOT",       "StartBit" : 8,   "Len" : 8,   "Result" : None},
                {"Name" : "JULIET_NVM_LENS",                 "StartBit" : 16,  "Len" : 8,   "Result" : [0x2E,0x4E]},
            ]},
            {"Reg" : 0x01AA, "Page": 0, "NumofBytes" : 2, "NVMDetails" : [
                {"Name" : "JULIET_NVM_FLEX",                 "StartBit" : 0,   "Len" : 8,   "Result" : 0x1C},
                {"Name" : "JULIET_NVM_STIFFENER",            "StartBit" : 8,   "Len" : 8,   "Result" : [0x26,0x46]},
            ]},
        ]

    def getChipID(self):
        dat1=int(self.i2cread(0x0000))
        return dat1
    def getFrameCounter(self):
        return self.i2cread(0xc1)

    def getNVMreg(self, reg):
        # convert "0x019C" to NVM-readable register, i.e. 0x04AC
        otp_offset = 0x0310
        otpif_dt_max = 0x070F
        otp_reg = otp_offset + reg

        return otp_reg





class Romeo(I2CDevice,N301Projector):
    def __init__(self,sib):
        I2CDevice.__init__(self,sib,0x66,2,4,reverse=True)
    def getChipID(self):
        dat1=int(self.i2cread(0x4480))
        return dat1
    def getStatus(self):
        dat1=int(self.i2cread(0x8860))
        return dat1
    def OTPDump(self):
        baseAddr=0x800
        OTPTable={}
        for i in range(0,28):
            OTPTable[baseAddr+(4*i)]=int(self.i2cread((baseAddr+(4*i))<<3))
        return OTPTable

class Lex(I2CDevice):
    def __init__(self,sib):
        I2CDevice.__init__(self,sib,0x75,2,1)
    def getChipID(self):
        dat1=int(self.i2cread(0x0000))
        return dat1
    def setV(self,voltage):
        self.i2cread(0x2000)
        if (voltage>=1.44 and voltage <=3.352):
            VSEL=int((voltage-1.44)/0.0075)
            print("Setting VSEL to ",hex(VSEL))
            self.i2cwrite(0x2000,VSEL)
        else:
            print("Invalid VSEL value")


class Moku(I2CDevice):
    DEVICE_ID=0x40a10
    def __init__(self,sib):
        I2CDevice.__init__(self,sib,0x38,2,2)
        self.LR="L" if sib.channel == 2 else "R"

    def getChipID(self):
        did1 = int(self.i2cread(0x0000))
        did2 = int(self.i2cread(0x0002)) << 16
        did = (did1) + did2
        print(did)
        return did

    def getStat(self):
        dat1=int(self.i2cread(0x0400))
        return dat1
    def I2CCheck(self):
            did=self.getChipID()
            if did == self.DEVICE_ID:
                print("Moku Device ID "+hex(did))
                ReportDataToStationAndPDCA("Moku"+self.LR+"_I2C_DID",did,"hex",self.DEVICE_ID,self.DEVICE_ID)
                return True
            else:
                return False
                ReportDataToStationAndPDCA("Moku"+self.LR+"_I2C_DID",did,"hex",self.DEVICE_ID,self.DEVICE_ID)


    def MokuSiliconRev(self):
        dat = self.i2cread(0x0004)
        if dat == 0x00:
            dat = 0xA0
            print("Moku A0 detected, DO NOT USE this")
        if dat == 0xB0:
            print("Moku B0 detected, DO NOT USE this")

        ReportDataToStationAndPDCA("MOKU" + self.LR + "_CTS_SILICON_REV", dat, "hex", 0xB1, 0xB1)

    def vendorATEpass_preburn(self):
        si_rev = self.i2cread(0x0004)
        dat = self.i2cread(0x409C)
        if (si_rev == 0x00):
            ReportDataToStationAndPDCA("MOKU" + self.LR + "_CTS_ATE_PASS_BYTE", dat, "hex", 0x00, 0x6D)
        else:
            if dat != 0x6D:  # 0x6D locked state
                print("Failed Vendor ATE test! Do not use this Moku!!!")
            ReportDataToStationAndPDCA("MOKU" + self.LR + "_CTS_ATE_PASS_BYTE", dat, "hex", 0x6D, 0x6D)

    def vendorATEpass_postburn(self):
        dat = self.i2cread(0x409C)
        device = self.i2cread(0x0024)
        # determine which moku config
        OTP_CTRL_6 = self.i2cread(0x4218)
        OTPID_STS = (OTP_CTRL_6 & 0x0F00) >> 8;  # bits 11:8 of OTP_CTRL_6

        if OTPID_STS < 12:
            if device == 0x7b:
                ReportDataToStationAndPDCA("MOKU" + self.LR + "_CTS_ATE_PASS_BYTE", dat, "hex", 0x6D, 0x6D)
            else:
                ReportDataToStationAndPDCA("MOKU" + self.LR + "_CTS_ATE_PASS_BYTE", dat, "hex", 0x00, 0x00)
        else:
            if dat != 0x6D:  # 0x6D locked state
                print("Failed Vendor ATE test! Do not use this Moku!!!")
            ReportDataToStationAndPDCA("MOKU" + self.LR + "_CTS_ATE_PASS_BYTE", dat, "hex", 0x6D, 0x6D)

    def MokuOperationMode(self):
        dat = self.i2cread(0x066E)
        otpmode= dat & 0x04 == 0x04
        dat = self.i2cread(0x06F2)
        mode_status = dat & 0x8000 == 0x8000
        if (otpmode & mode_status):
            ReportDataToStationAndPDCA("MOKU" + self.LR + "_CTS_MOKU_OPMODE", 0xB0, "hex", 0xA0, 0xB0)
        else:
            ReportDataToStationAndPDCA("MOKU" + self.LR + "_CTS_MOKU_OPMODE", 0xA0, "hex", 0xA0, 0xB0)

    def vendorIDDump(self,prefix=""):
        #trail
        outstr="0x%04x%04x%04x%04x%02x%04x" % (self.i2cread(0x38,reverse=False),
                                               self.i2cread(0x3a,reverse=False),
                                               self.i2cread(0x3c,reverse=False),
                                               self.i2cread(0x3e,reverse=False),
                                               self.i2cread(0x40,reverse=True),
                                               self.i2cread(0x44,reverse=False))

        ReportDataToStationAndPDCA(prefix+"MOKU"+self.LR+"_TRACKING_ID",outstr,"SN",None,None)

    def vendorLockStateRead(self):
        dat=self.i2cread(0x4800)
        ReportDataToStationAndPDCA("MOKU"+self.LR+"_CTS_VENDOR_LOCK_BYTE",dat,"hex",0x6C,0x6C)
        if (dat != 0x6C):
            print("Unlocked Moku! Do NOT use this Moku!")
            sys.exit(0)
    def appleLockStateRead(self):
        dat=self.i2cread(0x4804)
        ReportDataToStationAndPDCA("MOKU"+self.LR+"_CTS_APPLE_LOCK_BYTE",dat,"hex",0x6C,0x6C)
        if (dat != 0x6C):
            print("Unlocked Moku! Do NOT use this Moku!")
            sys.exit(0)
    def vendorDebugModeCheck(self):
        dat=self.i2cread(0x2018)

        debug_enabled = dat & 0x100 == 0x100
        ret = 1
        if not debug_enabled:
            ret = 0
        ReportDataToStationAndPDCA("MOKU"+self.LR+"_CTS_VENDOR_DEBUG_MODE",ret,"hex",0,0)

    def mokuOTPID(self):
        OTP_CTRL_6 = self.i2cread(0x4218)
        OTPID_STS = (OTP_CTRL_6 & 0x0F00) >> 8;  # bits 11:8 of OTP_CTRL_6
        ReportDataToStationAndPDCA("MOKU"+self.LR+"_OTPID",OTPID_STS,"hex",0xF,0xF)

    def OTPDump(self,prefix=""):
        OTPMap = {
            # Moku OTP should not contain registers 0x08 to 0x34 - Beign OTP logging at register 0x100
            "MOKU_CTS_OTP_CCM.OSC_BIST_THRES_0": 0x100,
            "MOKU_CTS_OTP_CCM.OSC_TRIM_CTRL_0": 0x108,
            "MOKU_CTS_OTP_MSM.MSM_CTRL_1": 0x40A,
            "MOKU_CTS_OTP_MSM.MSM_VIOLATION_MASK_0": 0x40C,
            "MOKU_CTS_OTP_MSM.MSM_VIOLATION_MASK_1": 0x40E,
            "MOKU_CTS_OTP_MSM.MSM_OVV_VIOLATION_MASK_0": 0x410,
            "MOKU_CTS_OTP_MSM.MSM_OVV_VIOLATION_MASK_1": 0x412,
            "MOKU_CTS_OTP_MSM.MSM_FLT_MASK_1_0": 0x0414,
            "MOKU_CTS_OTP_MSM.MSM_FLT_MASK_1_1": 0x0416,
            "MOKU_CTS_OTP_MSM.MSM_FLT_MASK_2_0": 0x0418,
            "MOKU_CTS_OTP_MSM.MSM_FLT_MASK_2_1": 0x041A,
            # Added MSM_FLT_Masks
            "MOKU_CTS_OTP_MSM.COMPL_CFG4": 0x41C,
            "MOKU_CTS_OTP_MSM.MSM_ANA_CTRL_0": 0x420,
            "MOKU_CTS_OTP_MSM.MSM_ANA_CTRL_1": 0x422,
            "MOKU_CTS_OTP_MSM.ISRC_MM_CTRL": 0x43C,
            # Added ISRC_MM_CTRL
            "MOKU_CTS_OTP_SWCTRL.COMPL1_CFG1": 0x600,
            "MOKU_CTS_OTP_SWCTRL.COMPL1_CFG2_0": 0x604,
            "MOKU_CTS_OTP_SWCTRL.COMPL1_CFG2_1": 0x606,
            "MOKU_CTS_OTP_SWCTRL.COMPL2_CFG1": 0x608,
            "MOKU_CTS_OTP_SWCTRL.COMPL2_CFG2_0": 0x60C,
            "MOKU_CTS_OTP_SWCTRL.COMPL2_CFG2_1": 0x60E,
            "MOKU_CTS_OTP_SWCTRL.COMPL3_CFG1": 0x610,
            "MOKU_CTS_OTP_SWCTRL.COMPL3_CFG2_0": 0x614,
            "MOKU_CTS_OTP_SWCTRL.COMPL3_CFG2_1": 0x616,
            "MOKU_CTS_OTP_SWCTRL.COMPL4_CFG1": 0x618,
            "MOKU_CTS_OTP_SWCTRL.COMPL4_CFG2_0": 0x61C,
            "MOKU_CTS_OTP_SWCTRL.COMPL4_CFG2_1": 0x61E,
            "MOKU_CTS_OTP_SWCTRL.COMPL5_CFG1": 0x620,
            "MOKU_CTS_OTP_SWCTRL.COMPL5_CFG2_0": 0x624,
            "MOKU_CTS_OTP_SWCTRL.COMPL5_CFG2_1": 0x626,
            "MOKU_CTS_OTP_SWCTRL.COMPL6_CFG1": 0x628,
            "MOKU_CTS_OTP_SWCTRL.COMPL6_CFG2_0": 0x62C,
            "MOKU_CTS_OTP_SWCTRL.COMPL6_CFG2_1": 0x62E,
            "MOKU_CTS_OTP_SWCTRL.COMPL7_CFG1": 0x630,
            "MOKU_CTS_OTP_SWCTRL.COMPL7_CFG2_0": 0x634,
            "MOKU_CTS_OTP_SWCTRL.COMPL7_CFG2_1": 0x636,
            "MOKU_CTS_OTP_SWCTRL.COMPL8_CFG1": 0x638,
            "MOKU_CTS_OTP_SWCTRL.COMPL8_CFG2_0": 0x63C,
            "MOKU_CTS_OTP_SWCTRL.COMPL8_CFG2_1": 0x63E,
            "MOKU_CTS_OTP_SWCTRL.COMPL1_PULSE_CFG_0": 0x640,
            "MOKU_CTS_OTP_SWCTRL.COMPL1_PULSE_CFG_1": 0x642,
            "MOKU_CTS_OTP_SWCTRL.COMPL2_PULSE_CFG_0": 0x644,
            "MOKU_CTS_OTP_SWCTRL.COMPL2_PULSE_CFG_1": 0x646,
            "MOKU_CTS_OTP_SWCTRL.COMPL3_PULSE_CFG_0": 0x648,
            "MOKU_CTS_OTP_SWCTRL.COMPL3_PULSE_CFG_1": 0x64A,
            "MOKU_CTS_OTP_SWCTRL.COMPL4_PULSE_CFG_0": 0x64C,
            "MOKU_CTS_OTP_SWCTRL.COMPL4_PULSE_CFG_1": 0x64E,
            "MOKU_CTS_OTP_SWCTRL.COMPL5_PULSE_CFG_0": 0x650,
            "MOKU_CTS_OTP_SWCTRL.COMPL5_PULSE_CFG_1": 0x652,
            "MOKU_CTS_OTP_SWCTRL.COMPL6_PULSE_CFG_0": 0x654,
            "MOKU_CTS_OTP_SWCTRL.COMPL6_PULSE_CFG_1": 0x656,
            "MOKU_CTS_OTP_SWCTRL.COMPL7_PULSE_CFG_0": 0x658,
            "MOKU_CTS_OTP_SWCTRL.COMPL7_PULSE_CFG_1": 0x65A,
            "MOKU_CTS_OTP_SWCTRL.COMPL8_PULSE_CFG_0": 0x65C,
            "MOKU_CTS_OTP_SWCTRL.COMPL8_PULSE_CFG_1": 0x65E,
            "MOKU_CTS_OTP_SWCTRL.COMPL_CFG5": 0x660,
            "MOKU_CTS_OTP_SWCTRL.SELECT_CFG_0": 0x664,
            "MOKU_CTS_OTP_SWCTRL.SELECT_CFG_1": 0x666,
            "MOKU_CTS_OTP_SWCTRL.SLEW_CFG": 0x668,
            "MOKU_CTS_OTP_SWCTRL.ERROR_CFG": 0x66C,
            "MOKU_CTS_OTP_SWCTRL.ERROR_CFG_1": 0x66E,
            "MOKU_CTS_OTP_SWCTRL.BIST_CFG_0": 0x670,
            "MOKU_CTS_OTP_SWCTRL.BIST_CFG_1": 0x672,
            "MOKU_CTS_OTP_SWCTRL.TOLERANCE_CFG1_0": 0x700,
            # added TOLERANCE_CFG1_0
            "MOKU_CTS_OTP_SWCTRL.TOLERANCE_CFG1_1": 0x702,
            # added TOLERANCE_CFG1_1
            "MOKU_CTS_OTP_SARADC_MON.DIAG_ADC_MON_CFG_3_0": 0x808,
            "MOKU_CTS_OTP_SARADC_MON.DIAG_ADC_MON_CFG_5_0": 0x88C,
            "MOKU_CTS_OTP_SARADC_MON.DIAG_ADC_MON_CFG_5_1": 0x88E,
            "MOKU_CTS_OTP_SARADC_SENSE.ADC_SENS_CFG_4_1": 0xC0E,
            "MOKU_CTS_OTP_EXT_TEMP.LOW_TEMP_THRES": 0x1208,
            "MOKU_CTS_OTP_EXT_TEMP.HIGH_TEMP_THRES": 0x120C,
            "MOKU_CTS_OTP_EXT_TEMP.EXTTMP_CTRL": 0x1210,
            "MOKU_CTS_OTP_EXT_TEMP.TEMP_FILT_SAMPLES": 0x1214,
            "MOKU_CTS_OTP_PAD_INTERFACE.PAD_CTRL_0": 0x6004,
            # added PAD_CTRL_0
            "MOKU_CTS_OTP_ANALOG_CTRL.OVV_THRESHOLD_CTRL": 0x6254,
        }
        OTP3Val={
        "MOKU_CTS_OTP_CCM.OSC_BIST_THRES_0": 0x01FD,
        "MOKU_CTS_OTP_CCM.OSC_TRIM_CTRL_0": 0x00,
        "MOKU_CTS_OTP_MSM.MSM_CTRL_1": 0x01FF,
        "MOKU_CTS_OTP_MSM.MSM_VIOLATION_MASK_0": 0x4000,
        "MOKU_CTS_OTP_MSM.MSM_VIOLATION_MASK_1": 0x0002,
        "MOKU_CTS_OTP_MSM.MSM_OVV_VIOLATION_MASK_0": 0x0000,
        "MOKU_CTS_OTP_MSM.MSM_OVV_VIOLATION_MASK_1": 0x0000,
        "MOKU_CTS_OTP_MSM.MSM_FLT_MASK_1_0": 0x0002,
        "MOKU_CTS_OTP_MSM.MSM_FLT_MASK_1_1": 0x0000,
        "MOKU_CTS_OTP_MSM.MSM_FLT_MASK_2_0": 0x0000,
        "MOKU_CTS_OTP_MSM.MSM_FLT_MASK_2_1": 0x0000,
        "MOKU_CTS_OTP_MSM.COMPL_CFG4": 0x0384,
        "MOKU_CTS_OTP_MSM.MSM_ANA_CTRL_0": 0xFFFF,
        "MOKU_CTS_OTP_MSM.MSM_ANA_CTRL_1": 0x07FF,
        "MOKU_CTS_OTP_MSM.ISRC_MM_CTRL": 0x001F,
        "MOKU_CTS_OTP_SWCTRL.COMPL1_CFG1": 0x8CCF,
        "MOKU_CTS_OTP_SWCTRL.COMPL1_CFG2_0": 0xFFFF,
        "MOKU_CTS_OTP_SWCTRL.COMPL1_CFG2_1": 0x001B,
        "MOKU_CTS_OTP_SWCTRL.COMPL2_CFG1": 0x892B,
        "MOKU_CTS_OTP_SWCTRL.COMPL2_CFG2_0": 0x030C,
        "MOKU_CTS_OTP_SWCTRL.COMPL2_CFG2_1": 0x0159,
        "MOKU_CTS_OTP_SWCTRL.COMPL3_CFG1": 0x898F,
        "MOKU_CTS_OTP_SWCTRL.COMPL3_CFG2_0": 0x023E,
        "MOKU_CTS_OTP_SWCTRL.COMPL3_CFG2_1": 0x0212,
        "MOKU_CTS_OTP_SWCTRL.COMPL4_CFG1": 0x89F3,
        "MOKU_CTS_OTP_SWCTRL.COMPL4_CFG2_0": 0x01C7,
        "MOKU_CTS_OTP_SWCTRL.COMPL4_CFG2_1": 0x027F,
        "MOKU_CTS_OTP_SWCTRL.COMPL5_CFG1": 0x8A57,
        "MOKU_CTS_OTP_SWCTRL.COMPL5_CFG2_0": 0x0178,
        "MOKU_CTS_OTP_SWCTRL.COMPL5_CFG2_1": 0x02C5,
        "MOKU_CTS_OTP_SWCTRL.COMPL6_CFG1": 0x8ABB,
        "MOKU_CTS_OTP_SWCTRL.COMPL6_CFG2_0": 0x0140,
        "MOKU_CTS_OTP_SWCTRL.COMPL6_CFG2_1": 0x02F5,
        "MOKU_CTS_OTP_SWCTRL.COMPL7_CFG1": 0x8B1F,
        "MOKU_CTS_OTP_SWCTRL.COMPL7_CFG2_0": 0x0118,
        "MOKU_CTS_OTP_SWCTRL.COMPL7_CFG2_1": 0x031D,
        "MOKU_CTS_OTP_SWCTRL.COMPL8_CFG1": 0x8B83,
        "MOKU_CTS_OTP_SWCTRL.COMPL8_CFG2_0": 0x00F8,
        "MOKU_CTS_OTP_SWCTRL.COMPL8_CFG2_1": 0x0339,
        "MOKU_CTS_OTP_SWCTRL.COMPL1_PULSE_CFG_0": 0x1919,
        "MOKU_CTS_OTP_SWCTRL.COMPL1_PULSE_CFG_1": 0x0104,
        "MOKU_CTS_OTP_SWCTRL.COMPL2_PULSE_CFG_0": 0x2424,
        "MOKU_CTS_OTP_SWCTRL.COMPL2_PULSE_CFG_1": 0x0104,
        "MOKU_CTS_OTP_SWCTRL.COMPL3_PULSE_CFG_0": 0x3131,
        "MOKU_CTS_OTP_SWCTRL.COMPL3_PULSE_CFG_1": 0x0104,
        "MOKU_CTS_OTP_SWCTRL.COMPL4_PULSE_CFG_0": 0x3D3D,
        "MOKU_CTS_OTP_SWCTRL.COMPL4_PULSE_CFG_1": 0x0104,
        "MOKU_CTS_OTP_SWCTRL.COMPL5_PULSE_CFG_0": 0x4A4A,
        "MOKU_CTS_OTP_SWCTRL.COMPL5_PULSE_CFG_1": 0x0104,
        "MOKU_CTS_OTP_SWCTRL.COMPL6_PULSE_CFG_0": 0x5656,
        "MOKU_CTS_OTP_SWCTRL.COMPL6_PULSE_CFG_1": 0x0104,
        "MOKU_CTS_OTP_SWCTRL.COMPL7_PULSE_CFG_0": 0x6363,
        "MOKU_CTS_OTP_SWCTRL.COMPL7_PULSE_CFG_1": 0x0104,
        "MOKU_CTS_OTP_SWCTRL.COMPL8_PULSE_CFG_0": 0x6F6F,
        "MOKU_CTS_OTP_SWCTRL.COMPL8_PULSE_CFG_1": 0x0104,
        "MOKU_CTS_OTP_SWCTRL.COMPL_CFG5": 0x0080,
        "MOKU_CTS_OTP_SWCTRL.SELECT_CFG_0": 0x0000,
        "MOKU_CTS_OTP_SWCTRL.SELECT_CFG_1": 0x0001,
        "MOKU_CTS_OTP_SWCTRL.SLEW_CFG": 0x1C,
        "MOKU_CTS_OTP_SWCTRL.ERROR_CFG": 0xFFFF,
        "MOKU_CTS_OTP_SWCTRL.ERROR_CFG_1": 0x03,
        "MOKU_CTS_OTP_SWCTRL.BIST_CFG_0": 0x0F,
        "MOKU_CTS_OTP_SWCTRL.BIST_CFG_1": 0x0000,
        "MOKU_CTS_OTP_SWCTRL.TOLERANCE_CFG1_0": 0x4210,
        "MOKU_CTS_OTP_SWCTRL.TOLERANCE_CFG1_1": 0x798A,
        "MOKU_CTS_OTP_SARADC_MON.DIAG_ADC_MON_CFG_3_0": 0x00,
        "MOKU_CTS_OTP_SARADC_MON.DIAG_ADC_MON_CFG_5_0": 0x0000,
        "MOKU_CTS_OTP_SARADC_MON.DIAG_ADC_MON_CFG_5_1": 0x00,
        "MOKU_CTS_OTP_SARADC_SENSE.ADC_SENS_CFG_4_1": 0x01,
        "MOKU_CTS_OTP_EXT_TEMP.LOW_TEMP_THRES": 0x4232,
        "MOKU_CTS_OTP_EXT_TEMP.HIGH_TEMP_THRES": 0x0315,
        "MOKU_CTS_OTP_EXT_TEMP.EXTTMP_CTRL": 0x60,
        "MOKU_CTS_OTP_EXT_TEMP.TEMP_FILT_SAMPLES": 0x24,
        "MOKU_CTS_OTP_PAD_INTERFACE.PAD_CTRL_0": 0x89,
        "MOKU_CTS_OTP_ANALOG_CTRL.OVV_THRESHOLD_CTRL": 0xF5,
        "MOKU_CTS_OTP_CTRL_IF.CTRL_IF0":0x6C,
        "MOKU_CTS_OTP_CTRL_IF.CTRL_IF1":0x6C
        }

        OTP4Val={
        "MOKU_CTS_OTP_CCM.OSC_BIST_THRES_0": 0x01FD,
        "MOKU_CTS_OTP_CCM.OSC_TRIM_CTRL_0": 0x00,
        "MOKU_CTS_OTP_MSM.MSM_CTRL_1": 0x01FF,
        "MOKU_CTS_OTP_MSM.MSM_VIOLATION_MASK_0": 0x4800,
        "MOKU_CTS_OTP_MSM.MSM_VIOLATION_MASK_1": 0x0200,
        "MOKU_CTS_OTP_MSM.MSM_OVV_VIOLATION_MASK_0": 0x0000,
        "MOKU_CTS_OTP_MSM.MSM_OVV_VIOLATION_MASK_1": 0x0000,
        "MOKU_CTS_OTP_MSM.MSM_FLT_MASK_1_0": 0x0002,
        "MOKU_CTS_OTP_MSM.MSM_FLT_MASK_1_1": 0x0000,
        "MOKU_CTS_OTP_MSM.MSM_FLT_MASK_2_0": 0x0000,
        "MOKU_CTS_OTP_MSM.MSM_FLT_MASK_2_1": 0x0000,
        "MOKU_CTS_OTP_MSM.COMPL_CFG4": 0x0384,
        "MOKU_CTS_OTP_MSM.MSM_ANA_CTRL_0": 0xFFFF,
        "MOKU_CTS_OTP_MSM.MSM_ANA_CTRL_1": 0x07FF,
        "MOKU_CTS_OTP_MSM.ISRC_MM_CTRL": 0x001F,
        "MOKU_CTS_OTP_SWCTRL.COMPL1_CFG1": 0x8CCF,
        "MOKU_CTS_OTP_SWCTRL.COMPL1_CFG2_0": 0xFFFF,
        "MOKU_CTS_OTP_SWCTRL.COMPL1_CFG2_1": 0x001B,
        "MOKU_CTS_OTP_SWCTRL.COMPL2_CFG1": 0x8D2B,
        "MOKU_CTS_OTP_SWCTRL.COMPL2_CFG2_0": 0x030C,
        "MOKU_CTS_OTP_SWCTRL.COMPL2_CFG2_1": 0x0159,
        "MOKU_CTS_OTP_SWCTRL.COMPL3_CFG1": 0x8D8F,
        "MOKU_CTS_OTP_SWCTRL.COMPL3_CFG2_0": 0x023E,
        "MOKU_CTS_OTP_SWCTRL.COMPL3_CFG2_1": 0x0212,
        "MOKU_CTS_OTP_SWCTRL.COMPL4_CFG1": 0x8DF3,
        "MOKU_CTS_OTP_SWCTRL.COMPL4_CFG2_0": 0x01C7,
        "MOKU_CTS_OTP_SWCTRL.COMPL4_CFG2_1": 0x027F,
        "MOKU_CTS_OTP_SWCTRL.COMPL5_CFG1": 0x8E57,
        "MOKU_CTS_OTP_SWCTRL.COMPL5_CFG2_0": 0x0178,
        "MOKU_CTS_OTP_SWCTRL.COMPL5_CFG2_1": 0x02C5,
        "MOKU_CTS_OTP_SWCTRL.COMPL6_CFG1": 0x8EBB,
        "MOKU_CTS_OTP_SWCTRL.COMPL6_CFG2_0": 0x0140,
        "MOKU_CTS_OTP_SWCTRL.COMPL6_CFG2_1": 0x02F5,
        "MOKU_CTS_OTP_SWCTRL.COMPL7_CFG1": 0x8F1F,
        "MOKU_CTS_OTP_SWCTRL.COMPL7_CFG2_0": 0x0118,
        "MOKU_CTS_OTP_SWCTRL.COMPL7_CFG2_1": 0x031D,
        "MOKU_CTS_OTP_SWCTRL.COMPL8_CFG1": 0x8F83,
        "MOKU_CTS_OTP_SWCTRL.COMPL8_CFG2_0": 0x00F8,
        "MOKU_CTS_OTP_SWCTRL.COMPL8_CFG2_1": 0x0339,
        "MOKU_CTS_OTP_SWCTRL.COMPL1_PULSE_CFG_0": 0x0404,
        "MOKU_CTS_OTP_SWCTRL.COMPL1_PULSE_CFG_1": 0xFF06,
        "MOKU_CTS_OTP_SWCTRL.COMPL2_PULSE_CFG_0": 0x0606,
        "MOKU_CTS_OTP_SWCTRL.COMPL2_PULSE_CFG_1": 0xFF06,
        "MOKU_CTS_OTP_SWCTRL.COMPL3_PULSE_CFG_0": 0x0909,
        "MOKU_CTS_OTP_SWCTRL.COMPL3_PULSE_CFG_1": 0xFF06,
        "MOKU_CTS_OTP_SWCTRL.COMPL4_PULSE_CFG_0": 0x0B0B,
        "MOKU_CTS_OTP_SWCTRL.COMPL4_PULSE_CFG_1": 0xFE06,
        "MOKU_CTS_OTP_SWCTRL.COMPL5_PULSE_CFG_0": 0x0E0E,
        "MOKU_CTS_OTP_SWCTRL.COMPL5_PULSE_CFG_1": 0xFE06,
        "MOKU_CTS_OTP_SWCTRL.COMPL6_PULSE_CFG_0": 0x0101,
        "MOKU_CTS_OTP_SWCTRL.COMPL6_PULSE_CFG_1": 0xFD06,
        "MOKU_CTS_OTP_SWCTRL.COMPL7_PULSE_CFG_0": 0x1313,
        "MOKU_CTS_OTP_SWCTRL.COMPL7_PULSE_CFG_1": 0xFD06,
        "MOKU_CTS_OTP_SWCTRL.COMPL8_PULSE_CFG_0": 0x1515,
        "MOKU_CTS_OTP_SWCTRL.COMPL8_PULSE_CFG_1": 0xFC07,
        "MOKU_CTS_OTP_SWCTRL.COMPL_CFG5": 0x0080,
        "MOKU_CTS_OTP_SWCTRL.SELECT_CFG_0": 0x0000,
        "MOKU_CTS_OTP_SWCTRL.SELECT_CFG_1": 0x7801,
        "MOKU_CTS_OTP_SWCTRL.SLEW_CFG": 0x1C,
        "MOKU_CTS_OTP_SWCTRL.ERROR_CFG": 0xFFFF,
        "MOKU_CTS_OTP_SWCTRL.ERROR_CFG_1": 0x03,
        "MOKU_CTS_OTP_SWCTRL.BIST_CFG_0": 0x0F,
        "MOKU_CTS_OTP_SWCTRL.BIST_CFG_1": 0x0000,
        "MOKU_CTS_OTP_SWCTRL.TOLERANCE_CFG1_0": 0x4210,
        "MOKU_CTS_OTP_SWCTRL.TOLERANCE_CFG1_1": 0x798A,
        "MOKU_CTS_OTP_SARADC_MON.DIAG_ADC_MON_CFG_3_0": 0x00,
        "MOKU_CTS_OTP_SARADC_MON.DIAG_ADC_MON_CFG_5_0": 0x0000,
        "MOKU_CTS_OTP_SARADC_MON.DIAG_ADC_MON_CFG_5_1": 0x00,
        "MOKU_CTS_OTP_SARADC_SENSE.ADC_SENS_CFG_4_1": 0x01,
        "MOKU_CTS_OTP_EXT_TEMP.LOW_TEMP_THRES": 0x4232,
        "MOKU_CTS_OTP_EXT_TEMP.HIGH_TEMP_THRES": 0x0315,
        "MOKU_CTS_OTP_EXT_TEMP.EXTTMP_CTRL": 0x60,
        "MOKU_CTS_OTP_EXT_TEMP.TEMP_FILT_SAMPLES": 0x24,
        "MOKU_CTS_OTP_PAD_INTERFACE.PAD_CTRL_0": 0x89,
        "MOKU_CTS_OTP_ANALOG_CTRL.OVV_THRESHOLD_CTRL": 0xF5,
        "MOKU_CTS_OTP_CTRL_IF.CTRL_IF0":0x6C,
        "MOKU_CTS_OTP_CTRL_IF.CTRL_IF1":0x6C
        }

        OTP2Val={
        "MOKU_CTS_OTP_CCM.OSC_BIST_THRES_0": 0x01FF,
        "MOKU_CTS_OTP_CCM.OSC_TRIM_CTRL_0": 0x00,
        "MOKU_CTS_OTP_MSM.MSM_CTRL_1": 0x01FF,
        "MOKU_CTS_OTP_MSM.MSM_VIOLATION_MASK_0": 0x4119,
        "MOKU_CTS_OTP_MSM.MSM_VIOLATION_MASK_1": 0x00B3,
        "MOKU_CTS_OTP_MSM.MSM_OVV_VIOLATION_MASK_0": 0x0030,
        "MOKU_CTS_OTP_MSM.MSM_OVV_VIOLATION_MASK_1": 0x0000,
        "MOKU_CTS_OTP_MSM.MSM_FLT_MASK_1_0": 0x0002,
        "MOKU_CTS_OTP_MSM.MSM_FLT_MASK_1_1": 0x0000,
        "MOKU_CTS_OTP_MSM.MSM_FLT_MASK_2_0": 0x0000,
        "MOKU_CTS_OTP_MSM.MSM_FLT_MASK_2_1": 0x0000,
        "MOKU_CTS_OTP_MSM.COMPL_CFG4": 0x03E8,
        "MOKU_CTS_OTP_MSM.MSM_ANA_CTRL_0": 0xFFFF,
        "MOKU_CTS_OTP_MSM.MSM_ANA_CTRL_1": 0x07FF,
        "MOKU_CTS_OTP_MSM.ISRC_MM_CTRL": 0x003F,
        "MOKU_CTS_OTP_SWCTRL.COMPL1_CFG1": 0x8CB3,
        "MOKU_CTS_OTP_SWCTRL.COMPL1_CFG2_0": 0xFFFF,
        "MOKU_CTS_OTP_SWCTRL.COMPL1_CFG2_1": 0x0032,
        "MOKU_CTS_OTP_SWCTRL.COMPL2_CFG1": 0x00B3,
        "MOKU_CTS_OTP_SWCTRL.COMPL2_CFG2_0": 0x0000,
        "MOKU_CTS_OTP_SWCTRL.COMPL2_CFG2_1": 0x0000,
        "MOKU_CTS_OTP_SWCTRL.COMPL3_CFG1": 0x0000,
        "MOKU_CTS_OTP_SWCTRL.COMPL3_CFG2_0": 0x0000,
        "MOKU_CTS_OTP_SWCTRL.COMPL3_CFG2_1": 0x0000,
        "MOKU_CTS_OTP_SWCTRL.COMPL4_CFG1": 0x0000,
        "MOKU_CTS_OTP_SWCTRL.COMPL4_CFG2_0": 0x0000,
        "MOKU_CTS_OTP_SWCTRL.COMPL4_CFG2_1": 0x0000,
        "MOKU_CTS_OTP_SWCTRL.COMPL5_CFG1": 0x0000,
        "MOKU_CTS_OTP_SWCTRL.COMPL5_CFG2_0": 0x0000,
        "MOKU_CTS_OTP_SWCTRL.COMPL5_CFG2_1": 0x0000,
        "MOKU_CTS_OTP_SWCTRL.COMPL6_CFG1": 0x0000,
        "MOKU_CTS_OTP_SWCTRL.COMPL6_CFG2_0": 0x0000,
        "MOKU_CTS_OTP_SWCTRL.COMPL6_CFG2_1": 0x0000,
        "MOKU_CTS_OTP_SWCTRL.COMPL7_CFG1": 0x0000,
        "MOKU_CTS_OTP_SWCTRL.COMPL7_CFG2_0": 0x0000,
        "MOKU_CTS_OTP_SWCTRL.COMPL7_CFG2_1": 0x0000,
        "MOKU_CTS_OTP_SWCTRL.COMPL8_CFG1": 0x0000,
        "MOKU_CTS_OTP_SWCTRL.COMPL8_CFG2_0": 0x0000,
        "MOKU_CTS_OTP_SWCTRL.COMPL8_CFG2_1": 0x0000,
        "MOKU_CTS_OTP_SWCTRL.COMPL1_PULSE_CFG_0": 0x1616,
        "MOKU_CTS_OTP_SWCTRL.COMPL1_PULSE_CFG_1": 0x0104,
        "MOKU_CTS_OTP_SWCTRL.COMPL2_PULSE_CFG_0": 0x1616,
        "MOKU_CTS_OTP_SWCTRL.COMPL2_PULSE_CFG_1": 0x0104,
        "MOKU_CTS_OTP_SWCTRL.COMPL3_PULSE_CFG_0": 0x0000,
        "MOKU_CTS_OTP_SWCTRL.COMPL3_PULSE_CFG_1": 0x0000,
        "MOKU_CTS_OTP_SWCTRL.COMPL4_PULSE_CFG_0": 0x0000,
        "MOKU_CTS_OTP_SWCTRL.COMPL4_PULSE_CFG_1": 0x0000,
        "MOKU_CTS_OTP_SWCTRL.COMPL5_PULSE_CFG_0": 0x0000,
        "MOKU_CTS_OTP_SWCTRL.COMPL5_PULSE_CFG_1": 0x0000,
        "MOKU_CTS_OTP_SWCTRL.COMPL6_PULSE_CFG_0": 0x0000,
        "MOKU_CTS_OTP_SWCTRL.COMPL6_PULSE_CFG_1": 0x0000,
        "MOKU_CTS_OTP_SWCTRL.COMPL7_PULSE_CFG_0": 0x0000,
        "MOKU_CTS_OTP_SWCTRL.COMPL7_PULSE_CFG_1": 0x0000,
        "MOKU_CTS_OTP_SWCTRL.COMPL8_PULSE_CFG_0": 0x0000,
        "MOKU_CTS_OTP_SWCTRL.COMPL8_PULSE_CFG_1": 0x0000,
        "MOKU_CTS_OTP_SWCTRL.COMPL_CFG5": 0x0080,
        "MOKU_CTS_OTP_SWCTRL.SELECT_CFG_0": 0x0200,
        "MOKU_CTS_OTP_SWCTRL.SELECT_CFG_1": 0x0001,
        "MOKU_CTS_OTP_SWCTRL.SLEW_CFG": 0x1C,
        "MOKU_CTS_OTP_SWCTRL.ERROR_CFG": 0xFFE7,
        "MOKU_CTS_OTP_SWCTRL.ERROR_CFG_1": 0x02,
        "MOKU_CTS_OTP_SWCTRL.BIST_CFG_0": 0x0F,
        "MOKU_CTS_OTP_SWCTRL.BIST_CFG_1": 0x0000,
        "MOKU_CTS_OTP_SWCTRL.TOLERANCE_CFG1_0": 0x4210,
        "MOKU_CTS_OTP_SWCTRL.TOLERANCE_CFG1_1": 0x798A,
        "MOKU_CTS_OTP_SARADC_MON.DIAG_ADC_MON_CFG_3_0": 0x00,
        "MOKU_CTS_OTP_SARADC_MON.DIAG_ADC_MON_CFG_5_0": 0x0000,
        "MOKU_CTS_OTP_SARADC_MON.DIAG_ADC_MON_CFG_5_1": 0x00,
        "MOKU_CTS_OTP_SARADC_SENSE.ADC_SENS_CFG_4_1": 0x01,
        "MOKU_CTS_OTP_EXT_TEMP.LOW_TEMP_THRES": 0x4232,
        "MOKU_CTS_OTP_EXT_TEMP.HIGH_TEMP_THRES": 0x038C,
        "MOKU_CTS_OTP_EXT_TEMP.EXTTMP_CTRL": 0x60,
        "MOKU_CTS_OTP_EXT_TEMP.TEMP_FILT_SAMPLES": 0x24,
        "MOKU_CTS_OTP_PAD_INTERFACE.PAD_CTRL_0": 0x89,
        "MOKU_CTS_OTP_ANALOG_CTRL.OVV_THRESHOLD_CTRL": 0xF5,
        "MOKU_CTS_OTP_CTRL_IF.CTRL_IF0":0x6C,
        "MOKU_CTS_OTP_CTRL_IF.CTRL_IF1":0x6C
        }

        OTP5Val={
        "MOKU_CTS_OTP_CCM.OSC_BIST_THRES_0":0x1FD,
        "MOKU_CTS_OTP_CCM.OSC_TRIM_CTRL_0":0x0,
        "MOKU_CTS_OTP_MSM.MSM_CTRL_1":0x1FF,
        "MOKU_CTS_OTP_MSM.MSM_VIOLATION_MASK_0":0x5000,
        "MOKU_CTS_OTP_MSM.MSM_VIOLATION_MASK_1":0x2,
        "MOKU_CTS_OTP_MSM.MSM_OVV_VIOLATION_MASK_0":0x0,
        "MOKU_CTS_OTP_MSM.MSM_OVV_VIOLATION_MASK_1":0x0,
        "MOKU_CTS_OTP_MSM.MSM_FLT_MASK_1_0":0x0,
        "MOKU_CTS_OTP_MSM.MSM_FLT_MASK_1_1":0x0,
        "MOKU_CTS_OTP_MSM.MSM_FLT_MASK_2_0":0x0,
        "MOKU_CTS_OTP_MSM.MSM_FLT_MASK_2_1":0x0,
        "MOKU_CTS_OTP_MSM.COMPL_CFG4":0x384,
        "MOKU_CTS_OTP_MSM.MSM_ANA_CTRL_0":0xFFFF,
        "MOKU_CTS_OTP_MSM.MSM_ANA_CTRL_1":0x7FF,
        "MOKU_CTS_OTP_MSM.ISRC_MM_CTRL":0x1F,
        "MOKU_CTS_OTP_SWCTRL.COMPL1_CFG1":0x8CCF,
        "MOKU_CTS_OTP_SWCTRL.COMPL1_CFG2_0":0xFFFF,
        "MOKU_CTS_OTP_SWCTRL.COMPL1_CFG2_1":0x1B,
        "MOKU_CTS_OTP_SWCTRL.COMPL2_CFG1":0x8D2B,
        "MOKU_CTS_OTP_SWCTRL.COMPL2_CFG2_0":0x30C,
        "MOKU_CTS_OTP_SWCTRL.COMPL2_CFG2_1":0x159,
        "MOKU_CTS_OTP_SWCTRL.COMPL3_CFG1":0x8D8F,
        "MOKU_CTS_OTP_SWCTRL.COMPL3_CFG2_0":0x23E,
        "MOKU_CTS_OTP_SWCTRL.COMPL3_CFG2_1":0x212,
        "MOKU_CTS_OTP_SWCTRL.COMPL4_CFG1":0x8DF3,
        "MOKU_CTS_OTP_SWCTRL.COMPL4_CFG2_0":0x1C7,
        "MOKU_CTS_OTP_SWCTRL.COMPL4_CFG2_1":0x27F,
        "MOKU_CTS_OTP_SWCTRL.COMPL5_CFG1":0x8E57,
        "MOKU_CTS_OTP_SWCTRL.COMPL5_CFG2_0":0x178,
        "MOKU_CTS_OTP_SWCTRL.COMPL5_CFG2_1":0x2C5,
        "MOKU_CTS_OTP_SWCTRL.COMPL6_CFG1":0x8EBB,
        "MOKU_CTS_OTP_SWCTRL.COMPL6_CFG2_0":0x140,
        "MOKU_CTS_OTP_SWCTRL.COMPL6_CFG2_1":0x2F5,
        "MOKU_CTS_OTP_SWCTRL.COMPL7_CFG1":0x8F1F,
        "MOKU_CTS_OTP_SWCTRL.COMPL7_CFG2_0":0x118,
        "MOKU_CTS_OTP_SWCTRL.COMPL7_CFG2_1":0x31D,
        "MOKU_CTS_OTP_SWCTRL.COMPL8_CFG1":0x8F83,
        "MOKU_CTS_OTP_SWCTRL.COMPL8_CFG2_0":0xF8,
        "MOKU_CTS_OTP_SWCTRL.COMPL8_CFG2_1":0x339,
        "MOKU_CTS_OTP_SWCTRL.COMPL1_PULSE_CFG_0":0x404,
        "MOKU_CTS_OTP_SWCTRL.COMPL1_PULSE_CFG_1":0xFF06,
        "MOKU_CTS_OTP_SWCTRL.COMPL2_PULSE_CFG_0":0x606,
        "MOKU_CTS_OTP_SWCTRL.COMPL2_PULSE_CFG_1":0xFF06,
        "MOKU_CTS_OTP_SWCTRL.COMPL3_PULSE_CFG_0":0x909,
        "MOKU_CTS_OTP_SWCTRL.COMPL3_PULSE_CFG_1":0xFF06,
        "MOKU_CTS_OTP_SWCTRL.COMPL4_PULSE_CFG_0":0xB0B,
        "MOKU_CTS_OTP_SWCTRL.COMPL4_PULSE_CFG_1":0xFE06,
        "MOKU_CTS_OTP_SWCTRL.COMPL5_PULSE_CFG_0":0xE0E,
        "MOKU_CTS_OTP_SWCTRL.COMPL5_PULSE_CFG_1":0xFE06,
        "MOKU_CTS_OTP_SWCTRL.COMPL6_PULSE_CFG_0":0x1010,
        "MOKU_CTS_OTP_SWCTRL.COMPL6_PULSE_CFG_1":0xFD06,
        "MOKU_CTS_OTP_SWCTRL.COMPL7_PULSE_CFG_0":0x1313,
        "MOKU_CTS_OTP_SWCTRL.COMPL7_PULSE_CFG_1":0xFD06,
        "MOKU_CTS_OTP_SWCTRL.COMPL8_PULSE_CFG_0":0x1515,
        "MOKU_CTS_OTP_SWCTRL.COMPL8_PULSE_CFG_1":0xFC07,
        "MOKU_CTS_OTP_SWCTRL.COMPL_CFG5":0x80,
        "MOKU_CTS_OTP_SWCTRL.SELECT_CFG_0":0x0,
        "MOKU_CTS_OTP_SWCTRL.SELECT_CFG_1":0x7801,
        "MOKU_CTS_OTP_SWCTRL.SLEW_CFG":0x1C,
        "MOKU_CTS_OTP_SWCTRL.ERROR_CFG":0xFFFF,
        "MOKU_CTS_OTP_SWCTRL.ERROR_CFG_1":0x3,
        "MOKU_CTS_OTP_SWCTRL.BIST_CFG_0":0xF,
        "MOKU_CTS_OTP_SWCTRL.BIST_CFG_1":0x0,
        "MOKU_CTS_OTP_SWCTRL.TOLERANCE_CFG1_0":0x4210,
        "MOKU_CTS_OTP_SWCTRL.TOLERANCE_CFG1_1":0x798A,
        "MOKU_CTS_OTP_SARADC_MON.DIAG_ADC_MON_CFG_3_0":0x0,
        "MOKU_CTS_OTP_SARADC_MON.DIAG_ADC_MON_CFG_5_0":0x0,
        "MOKU_CTS_OTP_SARADC_MON.DIAG_ADC_MON_CFG_5_1":0x0,
        "MOKU_CTS_OTP_SARADC_SENSE.ADC_SENS_CFG_4_1":0x1,
        "MOKU_CTS_OTP_EXT_TEMP.LOW_TEMP_THRES":0x4232,
        "MOKU_CTS_OTP_EXT_TEMP.HIGH_TEMP_THRES":0x315,
        "MOKU_CTS_OTP_EXT_TEMP.EXTTMP_CTRL":0x60,
        "MOKU_CTS_OTP_EXT_TEMP.TEMP_FILT_SAMPLES":0x24,
        "MOKU_CTS_OTP_PAD_INTERFACE.PAD_CTRL_0":0x89,
        "MOKU_CTS_OTP_ANALOG_CTRL.OVV_THRESHOLD_CTRL":0xF5,
        "MOKU_CTS_OTP_CTRL_IF.CTRL_IF0":0x6C,
        "MOKU_CTS_OTP_CTRL_IF.CTRL_IF1":0x6C
        }

        OTP6Val={
        'MOKU_CTS_OTP_CCM.OSC_BIST_THRES_0' : 0x1fd ,
        'MOKU_CTS_OTP_CCM.OSC_TRIM_CTRL_0' : 0x0 ,
        'MOKU_CTS_OTP_MSM.MSM_CTRL_1' : 0x1ff ,
        'MOKU_CTS_OTP_MSM.MSM_VIOLATION_MASK_0' : 0x5000 ,
        'MOKU_CTS_OTP_MSM.MSM_VIOLATION_MASK_1' : 0x2 ,
        'MOKU_CTS_OTP_MSM.MSM_OVV_VIOLATION_MASK_0' : 0x0 ,
        'MOKU_CTS_OTP_MSM.MSM_OVV_VIOLATION_MASK_1' : 0x0 ,
        'MOKU_CTS_OTP_MSM.MSM_FLT_MASK_1_0' : 0x0 ,
        'MOKU_CTS_OTP_MSM.MSM_FLT_MASK_1_1' : 0x0 ,
        'MOKU_CTS_OTP_MSM.MSM_FLT_MASK_2_0' : 0x0 ,
        'MOKU_CTS_OTP_MSM.MSM_FLT_MASK_2_1' : 0x0 ,
        'MOKU_CTS_OTP_MSM.COMPL_CFG4' : 0x8fc ,
        'MOKU_CTS_OTP_MSM.MSM_ANA_CTRL_0' : 0xffff ,
        'MOKU_CTS_OTP_MSM.MSM_ANA_CTRL_1' : 0x7ff ,
        'MOKU_CTS_OTP_MSM.ISRC_MM_CTRL' : 0x1f ,
        'MOKU_CTS_OTP_SWCTRL.COMPL1_CFG1' : 0x8cef ,
        'MOKU_CTS_OTP_SWCTRL.COMPL1_CFG2_0' : 0x2bc ,
        'MOKU_CTS_OTP_SWCTRL.COMPL1_CFG2_1' : 0x120 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL2_CFG1' : 0x8ddf ,
        'MOKU_CTS_OTP_SWCTRL.COMPL2_CFG2_0' : 0x15e ,
        'MOKU_CTS_OTP_SWCTRL.COMPL2_CFG2_1' : 0x27e ,
        'MOKU_CTS_OTP_SWCTRL.COMPL3_CFG1' : 0x8ebb ,
        'MOKU_CTS_OTP_SWCTRL.COMPL3_CFG2_0' : 0x294 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL3_CFG2_1' : 0x80a ,
        'MOKU_CTS_OTP_SWCTRL.COMPL4_CFG1' : 0x8ef7 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL4_CFG2_0' : 0x294 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL4_CFG2_1' : 0x8f3 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL5_CFG1' : 0x8f1f ,
        'MOKU_CTS_OTP_SWCTRL.COMPL5_CFG2_0' : 0x214 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL5_CFG2_1' : 0x7b4 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL6_CFG1' : 0x8f5b ,
        'MOKU_CTS_OTP_SWCTRL.COMPL6_CFG2_0' : 0x181 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL6_CFG2_1' : 0x61b ,
        'MOKU_CTS_OTP_SWCTRL.COMPL7_CFG1' : 0x8d3f ,
        'MOKU_CTS_OTP_SWCTRL.COMPL7_CFG2_0' : 0x23a ,
        'MOKU_CTS_OTP_SWCTRL.COMPL7_CFG2_1' : 0x1f7 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL8_CFG1' : 0x8d2b ,
        'MOKU_CTS_OTP_SWCTRL.COMPL8_CFG2_0' : 0x226 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL8_CFG2_1' : 0x1a5 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL1_PULSE_CFG_0' : 0x505 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL1_PULSE_CFG_1' : 0xff06 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL2_PULSE_CFG_0' : 0xb0b ,
        'MOKU_CTS_OTP_SWCTRL.COMPL2_PULSE_CFG_1' : 0xfe06 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL3_PULSE_CFG_0' : 0x1010 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL3_PULSE_CFG_1' : 0xfd06 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL4_PULSE_CFG_0' : 0x1212 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL4_PULSE_CFG_1' : 0xfd06 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL5_PULSE_CFG_0' : 0x1313 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL5_PULSE_CFG_1' : 0xfd06 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL6_PULSE_CFG_0' : 0x1414 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL6_PULSE_CFG_1' : 0xfc07 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL7_PULSE_CFG_0' : 0x707 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL7_PULSE_CFG_1' : 0xff06 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL8_PULSE_CFG_0' : 0x606 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL8_PULSE_CFG_1' : 0xff06 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL_CFG5' : 0xc0 ,
        'MOKU_CTS_OTP_SWCTRL.SELECT_CFG_0' : 0x1200 ,
        'MOKU_CTS_OTP_SWCTRL.SELECT_CFG_1' : 0x7801 ,
        'MOKU_CTS_OTP_SWCTRL.SLEW_CFG' : 0x1c ,
        'MOKU_CTS_OTP_SWCTRL.ERROR_CFG' : 0xffff ,
        'MOKU_CTS_OTP_SWCTRL.ERROR_CFG_1' : 0x3 ,
        'MOKU_CTS_OTP_SWCTRL.BIST_CFG_0' : 0xf ,
        'MOKU_CTS_OTP_SWCTRL.BIST_CFG_1' : 0x0 ,
        'MOKU_CTS_OTP_SWCTRL.TOLERANCE_CFG1_0' : 0x4210 ,
        'MOKU_CTS_OTP_SWCTRL.TOLERANCE_CFG1_1' : 0x798a ,
        'MOKU_CTS_OTP_SARADC_MON.DIAG_ADC_MON_CFG_3_0' : 0x0 ,
        'MOKU_CTS_OTP_SARADC_MON.DIAG_ADC_MON_CFG_5_0' : 0x0 ,
        'MOKU_CTS_OTP_SARADC_MON.DIAG_ADC_MON_CFG_5_1' : 0x0 ,
        'MOKU_CTS_OTP_SARADC_SENSE.ADC_SENS_CFG_4_1' : 0x1 ,
        'MOKU_CTS_OTP_EXT_TEMP.LOW_TEMP_THRES' : 0x4232 ,
        'MOKU_CTS_OTP_EXT_TEMP.HIGH_TEMP_THRES' : 0x315 ,
        'MOKU_CTS_OTP_EXT_TEMP.EXTTMP_CTRL' : 0x60 ,
        'MOKU_CTS_OTP_EXT_TEMP.TEMP_FILT_SAMPLES' : 0x24 ,
        'MOKU_CTS_OTP_PAD_INTERFACE.PAD_CTRL_0' : 0x89 ,
        'MOKU_CTS_OTP_ANALOG_CTRL.OVV_THRESHOLD_CTRL' : 0xf5 ,
        }
        OTP7Val={
        'MOKU_CTS_OTP_CCM.OSC_BIST_THRES_0' : 0x1fd ,
        'MOKU_CTS_OTP_CCM.OSC_TRIM_CTRL_0' : 0x0 ,
        'MOKU_CTS_OTP_MSM.MSM_CTRL_1' : 0x1ff ,
        'MOKU_CTS_OTP_MSM.MSM_VIOLATION_MASK_0' : 0x5000 ,
        'MOKU_CTS_OTP_MSM.MSM_VIOLATION_MASK_1' : 0x2 ,
        'MOKU_CTS_OTP_MSM.MSM_OVV_VIOLATION_MASK_0' : 0x0 ,
        'MOKU_CTS_OTP_MSM.MSM_OVV_VIOLATION_MASK_1' : 0x0 ,
        'MOKU_CTS_OTP_MSM.MSM_FLT_MASK_1_0' : 0x0 ,
        'MOKU_CTS_OTP_MSM.MSM_FLT_MASK_1_1' : 0x0 ,
        'MOKU_CTS_OTP_MSM.MSM_FLT_MASK_2_0' : 0x0 ,
        'MOKU_CTS_OTP_MSM.MSM_FLT_MASK_2_1' : 0x0 ,
        'MOKU_CTS_OTP_MSM.COMPL_CFG4' : 0x8fc ,
        'MOKU_CTS_OTP_MSM.MSM_ANA_CTRL_0' : 0xffff ,
        'MOKU_CTS_OTP_MSM.MSM_ANA_CTRL_1' : 0x7ff ,
        'MOKU_CTS_OTP_MSM.ISRC_MM_CTRL' : 0x1f ,
        'MOKU_CTS_OTP_SWCTRL.COMPL1_CFG1' : 0x8cef ,
        'MOKU_CTS_OTP_SWCTRL.COMPL1_CFG2_0' : 0x2bc ,
        'MOKU_CTS_OTP_SWCTRL.COMPL1_CFG2_1' : 0x120 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL2_CFG1' : 0x8ddf ,
        'MOKU_CTS_OTP_SWCTRL.COMPL2_CFG2_0' : 0x15e ,
        'MOKU_CTS_OTP_SWCTRL.COMPL2_CFG2_1' : 0x27e ,
        'MOKU_CTS_OTP_SWCTRL.COMPL3_CFG1' : 0x8ebb ,
        'MOKU_CTS_OTP_SWCTRL.COMPL3_CFG2_0' : 0x294 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL3_CFG2_1' : 0x80a ,
        'MOKU_CTS_OTP_SWCTRL.COMPL4_CFG1' : 0x8ef7 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL4_CFG2_0' : 0x294 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL4_CFG2_1' : 0x8f3 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL5_CFG1' : 0x8f1f ,
        'MOKU_CTS_OTP_SWCTRL.COMPL5_CFG2_0' : 0x214 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL5_CFG2_1' : 0x7b4 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL6_CFG1' : 0x8f5b ,
        'MOKU_CTS_OTP_SWCTRL.COMPL6_CFG2_0' : 0x181 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL6_CFG2_1' : 0x61b ,
        'MOKU_CTS_OTP_SWCTRL.COMPL7_CFG1' : 0x8d3f ,
        'MOKU_CTS_OTP_SWCTRL.COMPL7_CFG2_0' : 0x23a ,
        'MOKU_CTS_OTP_SWCTRL.COMPL7_CFG2_1' : 0x1f7 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL8_CFG1' : 0x8d2b ,
        'MOKU_CTS_OTP_SWCTRL.COMPL8_CFG2_0' : 0x226 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL8_CFG2_1' : 0x1a5 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL1_PULSE_CFG_0' : 0x505 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL1_PULSE_CFG_1' : 0xff06 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL2_PULSE_CFG_0' : 0xb0b ,
        'MOKU_CTS_OTP_SWCTRL.COMPL2_PULSE_CFG_1' : 0xfe06 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL3_PULSE_CFG_0' : 0x1010 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL3_PULSE_CFG_1' : 0xfd06 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL4_PULSE_CFG_0' : 0x1212 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL4_PULSE_CFG_1' : 0xfd06 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL5_PULSE_CFG_0' : 0x1313 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL5_PULSE_CFG_1' : 0xfd06 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL6_PULSE_CFG_0' : 0x1414 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL6_PULSE_CFG_1' : 0xfc07 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL7_PULSE_CFG_0' : 0x707 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL7_PULSE_CFG_1' : 0xff06 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL8_PULSE_CFG_0' : 0x606 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL8_PULSE_CFG_1' : 0xff06 ,
        'MOKU_CTS_OTP_SWCTRL.COMPL_CFG5' : 0xc0 ,
        'MOKU_CTS_OTP_SWCTRL.SELECT_CFG_0' : 0x0 ,
        'MOKU_CTS_OTP_SWCTRL.SELECT_CFG_1' : 0x7801 ,
        'MOKU_CTS_OTP_SWCTRL.SLEW_CFG' : 0x1c ,
        'MOKU_CTS_OTP_SWCTRL.ERROR_CFG' : 0xffff ,
        'MOKU_CTS_OTP_SWCTRL.ERROR_CFG_1' : 0x3 ,
        'MOKU_CTS_OTP_SWCTRL.BIST_CFG_0' : 0xf ,
        'MOKU_CTS_OTP_SWCTRL.BIST_CFG_1' : 0x0 ,
        'MOKU_CTS_OTP_SWCTRL.TOLERANCE_CFG1_0' : 0x4210 ,
        'MOKU_CTS_OTP_SWCTRL.TOLERANCE_CFG1_1' : 0x798a ,
        'MOKU_CTS_OTP_SARADC_MON.DIAG_ADC_MON_CFG_3_0' : 0x0 ,
        'MOKU_CTS_OTP_SARADC_MON.DIAG_ADC_MON_CFG_5_0' : 0x0 ,
        'MOKU_CTS_OTP_SARADC_MON.DIAG_ADC_MON_CFG_5_1' : 0x0 ,
        'MOKU_CTS_OTP_SARADC_SENSE.ADC_SENS_CFG_4_1' : 0x1 ,
        'MOKU_CTS_OTP_EXT_TEMP.LOW_TEMP_THRES' : 0x4232 ,
        'MOKU_CTS_OTP_EXT_TEMP.HIGH_TEMP_THRES' : 0x315 ,
        'MOKU_CTS_OTP_EXT_TEMP.EXTTMP_CTRL' : 0x60 ,
        'MOKU_CTS_OTP_EXT_TEMP.TEMP_FILT_SAMPLES' : 0x24 ,
        'MOKU_CTS_OTP_PAD_INTERFACE.PAD_CTRL_0' : 0x89 ,
        'MOKU_CTS_OTP_ANALOG_CTRL.OVV_THRESHOLD_CTRL' : 0xf5 ,
        }

        OTP8Val = {
            'MOKU_CTS_OTP_CCM.OSC_BIST_THRES_0': 0x1fd,
            'MOKU_CTS_OTP_CCM.OSC_TRIM_CTRL_0': 0x0,
            'MOKU_CTS_OTP_MSM.MSM_CTRL_1': 0x1ff,
            'MOKU_CTS_OTP_MSM.MSM_VIOLATION_MASK_0': 0x1000,
            'MOKU_CTS_OTP_MSM.MSM_VIOLATION_MASK_1': 0x2,
            'MOKU_CTS_OTP_MSM.MSM_OVV_VIOLATION_MASK_0': 0x0,
            'MOKU_CTS_OTP_MSM.MSM_OVV_VIOLATION_MASK_1': 0x0,
            'MOKU_CTS_OTP_MSM.MSM_FLT_MASK_1_0': 0x0,
            'MOKU_CTS_OTP_MSM.MSM_FLT_MASK_1_1': 0x0,
            'MOKU_CTS_OTP_MSM.MSM_FLT_MASK_2_0': 0x0,
            'MOKU_CTS_OTP_MSM.MSM_FLT_MASK_2_1': 0x0,
            'MOKU_CTS_OTP_MSM.COMPL_CFG4': 0x8fc,
            'MOKU_CTS_OTP_MSM.MSM_ANA_CTRL_0': 0xffff,
            'MOKU_CTS_OTP_MSM.MSM_ANA_CTRL_1': 0x7ff,
            'MOKU_CTS_OTP_MSM.ISRC_MM_CTRL': 0x1f,
            'MOKU_CTS_OTP_SWCTRL.COMPL1_CFG1': 0x8cef,
            'MOKU_CTS_OTP_SWCTRL.COMPL1_CFG2_0': 0x2bc,
            'MOKU_CTS_OTP_SWCTRL.COMPL1_CFG2_1': 0x120,
            'MOKU_CTS_OTP_SWCTRL.COMPL2_CFG1': 0x8ddf,
            'MOKU_CTS_OTP_SWCTRL.COMPL2_CFG2_0': 0x15e,
            'MOKU_CTS_OTP_SWCTRL.COMPL2_CFG2_1': 0x27e,
            'MOKU_CTS_OTP_SWCTRL.COMPL3_CFG1': 0x8ebb,
            'MOKU_CTS_OTP_SWCTRL.COMPL3_CFG2_0': 0x294,
            'MOKU_CTS_OTP_SWCTRL.COMPL3_CFG2_1': 0x80a,
            'MOKU_CTS_OTP_SWCTRL.COMPL4_CFG1': 0x8ef7,
            'MOKU_CTS_OTP_SWCTRL.COMPL4_CFG2_0': 0x294,
            'MOKU_CTS_OTP_SWCTRL.COMPL4_CFG2_1': 0x8f3,
            'MOKU_CTS_OTP_SWCTRL.COMPL5_CFG1': 0x8f1f,
            'MOKU_CTS_OTP_SWCTRL.COMPL5_CFG2_0': 0x214,
            'MOKU_CTS_OTP_SWCTRL.COMPL5_CFG2_1': 0x7b4,
            'MOKU_CTS_OTP_SWCTRL.COMPL6_CFG1': 0x8f5b,
            'MOKU_CTS_OTP_SWCTRL.COMPL6_CFG2_0': 0x181,
            'MOKU_CTS_OTP_SWCTRL.COMPL6_CFG2_1': 0x61b,
            'MOKU_CTS_OTP_SWCTRL.COMPL7_CFG1': 0x8d3f,
            'MOKU_CTS_OTP_SWCTRL.COMPL7_CFG2_0': 0x23a,
            'MOKU_CTS_OTP_SWCTRL.COMPL7_CFG2_1': 0x1f7,
            'MOKU_CTS_OTP_SWCTRL.COMPL8_CFG1': 0x8d2b,
            'MOKU_CTS_OTP_SWCTRL.COMPL8_CFG2_0': 0x226,
            'MOKU_CTS_OTP_SWCTRL.COMPL8_CFG2_1': 0x1a5,
            'MOKU_CTS_OTP_SWCTRL.COMPL1_PULSE_CFG_0': 0x505,
            'MOKU_CTS_OTP_SWCTRL.COMPL1_PULSE_CFG_1': 0xff06,
            'MOKU_CTS_OTP_SWCTRL.COMPL2_PULSE_CFG_0': 0xb0b,
            'MOKU_CTS_OTP_SWCTRL.COMPL2_PULSE_CFG_1': 0xfe06,
            'MOKU_CTS_OTP_SWCTRL.COMPL3_PULSE_CFG_0': 0x1010,
            'MOKU_CTS_OTP_SWCTRL.COMPL3_PULSE_CFG_1': 0xfd06,
            'MOKU_CTS_OTP_SWCTRL.COMPL4_PULSE_CFG_0': 0x1212,
            'MOKU_CTS_OTP_SWCTRL.COMPL4_PULSE_CFG_1': 0xfd06,
            'MOKU_CTS_OTP_SWCTRL.COMPL5_PULSE_CFG_0': 0x1313,
            'MOKU_CTS_OTP_SWCTRL.COMPL5_PULSE_CFG_1': 0xfd06,
            'MOKU_CTS_OTP_SWCTRL.COMPL6_PULSE_CFG_0': 0x1414,
            'MOKU_CTS_OTP_SWCTRL.COMPL6_PULSE_CFG_1': 0xfc07,
            'MOKU_CTS_OTP_SWCTRL.COMPL7_PULSE_CFG_0': 0x707,
            'MOKU_CTS_OTP_SWCTRL.COMPL7_PULSE_CFG_1': 0xff06,
            'MOKU_CTS_OTP_SWCTRL.COMPL8_PULSE_CFG_0': 0x606,
            'MOKU_CTS_OTP_SWCTRL.COMPL8_PULSE_CFG_1': 0xff06,
            'MOKU_CTS_OTP_SWCTRL.COMPL_CFG5': 0x30c0,
            'MOKU_CTS_OTP_SWCTRL.SELECT_CFG_0': 0x100,
            'MOKU_CTS_OTP_SWCTRL.SELECT_CFG_1': 0x7801,
            'MOKU_CTS_OTP_SWCTRL.SLEW_CFG': 0x1c,
            'MOKU_CTS_OTP_SWCTRL.ERROR_CFG': 0xffff,
            'MOKU_CTS_OTP_SWCTRL.ERROR_CFG_1': 0x3,
            'MOKU_CTS_OTP_SWCTRL.BIST_CFG_0': 0xf,
            'MOKU_CTS_OTP_SWCTRL.BIST_CFG_1': 0x0,
            'MOKU_CTS_OTP_SWCTRL.TOLERANCE_CFG1_0': 0x4210,
            'MOKU_CTS_OTP_SWCTRL.TOLERANCE_CFG1_1': 0x798a,
            'MOKU_CTS_OTP_SARADC_MON.DIAG_ADC_MON_CFG_3_0': 0x0,
            'MOKU_CTS_OTP_SARADC_MON.DIAG_ADC_MON_CFG_5_0': 0x0,
            'MOKU_CTS_OTP_SARADC_MON.DIAG_ADC_MON_CFG_5_1': 0x0,
            'MOKU_CTS_OTP_SARADC_SENSE.ADC_SENS_CFG_4_1': 0x1,
            'MOKU_CTS_OTP_EXT_TEMP.LOW_TEMP_THRES': 0x4232,
            'MOKU_CTS_OTP_EXT_TEMP.HIGH_TEMP_THRES': 0x315,
            'MOKU_CTS_OTP_EXT_TEMP.EXTTMP_CTRL': 0x60,
            'MOKU_CTS_OTP_EXT_TEMP.TEMP_FILT_SAMPLES': 0x24,
            'MOKU_CTS_OTP_PAD_INTERFACE.PAD_CTRL_0': 0x89,
            'MOKU_CTS_OTP_ANALOG_CTRL.OVV_THRESHOLD_CTRL': 0xf5,

        }

        OTP9Val = {
            'MOKU_CTS_OTP_CCM.OSC_BIST_THRES_0': 0x1fd,
            'MOKU_CTS_OTP_CCM.OSC_TRIM_CTRL_0': 0x0,
            'MOKU_CTS_OTP_MSM.MSM_CTRL_1': 0x1ff,
            'MOKU_CTS_OTP_MSM.MSM_VIOLATION_MASK_0': 0x1000,
            'MOKU_CTS_OTP_MSM.MSM_VIOLATION_MASK_1': 0x2,
            'MOKU_CTS_OTP_MSM.MSM_OVV_VIOLATION_MASK_0': 0x0,
            'MOKU_CTS_OTP_MSM.MSM_OVV_VIOLATION_MASK_1': 0x0,
            'MOKU_CTS_OTP_MSM.MSM_FLT_MASK_1_0': 0x0,
            'MOKU_CTS_OTP_MSM.MSM_FLT_MASK_1_1': 0x0,
            'MOKU_CTS_OTP_MSM.MSM_FLT_MASK_2_0': 0x0,
            'MOKU_CTS_OTP_MSM.MSM_FLT_MASK_2_1': 0x0,
            'MOKU_CTS_OTP_MSM.COMPL_CFG4': 0x834,
            'MOKU_CTS_OTP_MSM.MSM_ANA_CTRL_0': 0xffff,
            'MOKU_CTS_OTP_MSM.MSM_ANA_CTRL_1': 0x7ff,
            'MOKU_CTS_OTP_MSM.ISRC_MM_CTRL': 0x1f,
            'MOKU_CTS_OTP_SWCTRL.COMPL1_CFG1': 0x8cef,
            'MOKU_CTS_OTP_SWCTRL.COMPL1_CFG2_0': 0x2bc,
            'MOKU_CTS_OTP_SWCTRL.COMPL1_CFG2_1': 0x120,
            'MOKU_CTS_OTP_SWCTRL.COMPL2_CFG1': 0x8ddf,
            'MOKU_CTS_OTP_SWCTRL.COMPL2_CFG2_0': 0x15e,
            'MOKU_CTS_OTP_SWCTRL.COMPL2_CFG2_1': 0x27e,
            'MOKU_CTS_OTP_SWCTRL.COMPL3_CFG1': 0x8f33,
            'MOKU_CTS_OTP_SWCTRL.COMPL3_CFG2_0': 0x1d4,
            'MOKU_CTS_OTP_SWCTRL.COMPL3_CFG2_1': 0x6fd,
            'MOKU_CTS_OTP_SWCTRL.COMPL4_CFG1': 0x8f27,
            'MOKU_CTS_OTP_SWCTRL.COMPL4_CFG2_0': 0x1fd,
            'MOKU_CTS_OTP_SWCTRL.COMPL4_CFG2_1': 0x776,
            'MOKU_CTS_OTP_SWCTRL.COMPL5_CFG1': 0x8f0b,
            'MOKU_CTS_OTP_SWCTRL.COMPL5_CFG2_0': 0x243,
            'MOKU_CTS_OTP_SWCTRL.COMPL5_CFG2_1': 0x81e,
            'MOKU_CTS_OTP_SWCTRL.COMPL6_CFG1': 0x8f5b,
            'MOKU_CTS_OTP_SWCTRL.COMPL6_CFG2_0': 0x181,
            'MOKU_CTS_OTP_SWCTRL.COMPL6_CFG2_1': 0x61b,
            'MOKU_CTS_OTP_SWCTRL.COMPL7_CFG1': 0x8d3f,
            'MOKU_CTS_OTP_SWCTRL.COMPL7_CFG2_0': 0x23a,
            'MOKU_CTS_OTP_SWCTRL.COMPL7_CFG2_1': 0x1f7,
            'MOKU_CTS_OTP_SWCTRL.COMPL8_CFG1': 0x8d2b,
            'MOKU_CTS_OTP_SWCTRL.COMPL8_CFG2_0': 0x226,
            'MOKU_CTS_OTP_SWCTRL.COMPL8_CFG2_1': 0x1a5,
            'MOKU_CTS_OTP_SWCTRL.COMPL1_PULSE_CFG_0': 0x505,
            'MOKU_CTS_OTP_SWCTRL.COMPL1_PULSE_CFG_1': 0xff06,
            'MOKU_CTS_OTP_SWCTRL.COMPL2_PULSE_CFG_0': 0xb0b,
            'MOKU_CTS_OTP_SWCTRL.COMPL2_PULSE_CFG_1': 0xfe06,
            'MOKU_CTS_OTP_SWCTRL.COMPL3_PULSE_CFG_0': 0x1313,
            'MOKU_CTS_OTP_SWCTRL.COMPL3_PULSE_CFG_1': 0xfc07,
            'MOKU_CTS_OTP_SWCTRL.COMPL4_PULSE_CFG_0': 0x1313,
            'MOKU_CTS_OTP_SWCTRL.COMPL4_PULSE_CFG_1': 0xfc07,
            'MOKU_CTS_OTP_SWCTRL.COMPL5_PULSE_CFG_0': 0x1212,
            'MOKU_CTS_OTP_SWCTRL.COMPL5_PULSE_CFG_1': 0xfd06,
            'MOKU_CTS_OTP_SWCTRL.COMPL6_PULSE_CFG_0': 0x1414,
            'MOKU_CTS_OTP_SWCTRL.COMPL6_PULSE_CFG_1': 0xfc07,
            'MOKU_CTS_OTP_SWCTRL.COMPL7_PULSE_CFG_0': 0x707,
            'MOKU_CTS_OTP_SWCTRL.COMPL7_PULSE_CFG_1': 0xff06,
            'MOKU_CTS_OTP_SWCTRL.COMPL8_PULSE_CFG_0': 0x606,
            'MOKU_CTS_OTP_SWCTRL.COMPL8_PULSE_CFG_1': 0xff06,
            'MOKU_CTS_OTP_SWCTRL.COMPL_CFG5': 0x30c0,
            'MOKU_CTS_OTP_SWCTRL.SELECT_CFG_0': 0x100,
            'MOKU_CTS_OTP_SWCTRL.SELECT_CFG_1': 0x7801,
            'MOKU_CTS_OTP_SWCTRL.SLEW_CFG': 0x1c,
            'MOKU_CTS_OTP_SWCTRL.ERROR_CFG': 0xffff,
            'MOKU_CTS_OTP_SWCTRL.ERROR_CFG_1': 0x7,
            'MOKU_CTS_OTP_SWCTRL.BIST_CFG_0': 0xf,
            'MOKU_CTS_OTP_SWCTRL.BIST_CFG_1': 0x0,
            'MOKU_CTS_OTP_SWCTRL.TOLERANCE_CFG1_0': 0x4210,
            'MOKU_CTS_OTP_SWCTRL.TOLERANCE_CFG1_1': 0x798a,
            'MOKU_CTS_OTP_SARADC_MON.DIAG_ADC_MON_CFG_3_0': 0x0,
            'MOKU_CTS_OTP_SARADC_MON.DIAG_ADC_MON_CFG_5_0': 0x0,
            'MOKU_CTS_OTP_SARADC_MON.DIAG_ADC_MON_CFG_5_1': 0x0,
            'MOKU_CTS_OTP_SARADC_SENSE.ADC_SENS_CFG_4_1': 0x1,
            'MOKU_CTS_OTP_EXT_TEMP.LOW_TEMP_THRES': 0x4232,
            'MOKU_CTS_OTP_EXT_TEMP.HIGH_TEMP_THRES': 0x315,
            'MOKU_CTS_OTP_EXT_TEMP.EXTTMP_CTRL': 0x60,
            'MOKU_CTS_OTP_EXT_TEMP.TEMP_FILT_SAMPLES': 0x24,
            'MOKU_CTS_OTP_PAD_INTERFACE.PAD_CTRL_0': 0x89,
            'MOKU_CTS_OTP_ANALOG_CTRL.OVV_THRESHOLD_CTRL': 0xf5,
        }

        OTP10Val = {
            'MOKU_CTS_OTP_CCM.OSC_BIST_THRES_0': 0x1fd,
            'MOKU_CTS_OTP_CCM.OSC_TRIM_CTRL_0': 0x0,
            'MOKU_CTS_OTP_MSM.MSM_CTRL_1': 0x1ff,
            'MOKU_CTS_OTP_MSM.MSM_VIOLATION_MASK_0': 0x1000,
            'MOKU_CTS_OTP_MSM.MSM_VIOLATION_MASK_1': 0x2,
            'MOKU_CTS_OTP_MSM.MSM_OVV_VIOLATION_MASK_0': 0x0,
            'MOKU_CTS_OTP_MSM.MSM_OVV_VIOLATION_MASK_1': 0x0,
            'MOKU_CTS_OTP_MSM.MSM_FLT_MASK_1_0': 0x0,
            'MOKU_CTS_OTP_MSM.MSM_FLT_MASK_1_1': 0x0,
            'MOKU_CTS_OTP_MSM.MSM_FLT_MASK_2_0': 0x0,
            'MOKU_CTS_OTP_MSM.MSM_FLT_MASK_2_1': 0x0,
            'MOKU_CTS_OTP_MSM.COMPL_CFG4': 0x834,
            'MOKU_CTS_OTP_MSM.MSM_ANA_CTRL_0': 0xffff,
            'MOKU_CTS_OTP_MSM.MSM_ANA_CTRL_1': 0x7ff,
            'MOKU_CTS_OTP_MSM.ISRC_MM_CTRL': 0x1f,
            'MOKU_CTS_OTP_SWCTRL.COMPL1_CFG1': 0x8cef,
            'MOKU_CTS_OTP_SWCTRL.COMPL1_CFG2_0': 0x2bc,
            'MOKU_CTS_OTP_SWCTRL.COMPL1_CFG2_1': 0x120,
            'MOKU_CTS_OTP_SWCTRL.COMPL2_CFG1': 0x8ddf,
            'MOKU_CTS_OTP_SWCTRL.COMPL2_CFG2_0': 0x15e,
            'MOKU_CTS_OTP_SWCTRL.COMPL2_CFG2_1': 0x27e,
            'MOKU_CTS_OTP_SWCTRL.COMPL3_CFG1': 0x8f33,
            'MOKU_CTS_OTP_SWCTRL.COMPL3_CFG2_0': 0x1d4,
            'MOKU_CTS_OTP_SWCTRL.COMPL3_CFG2_1': 0x6fd,
            'MOKU_CTS_OTP_SWCTRL.COMPL4_CFG1': 0x8f27,
            'MOKU_CTS_OTP_SWCTRL.COMPL4_CFG2_0': 0x1fd,
            'MOKU_CTS_OTP_SWCTRL.COMPL4_CFG2_1': 0x776,
            'MOKU_CTS_OTP_SWCTRL.COMPL5_CFG1': 0x8f0b,
            'MOKU_CTS_OTP_SWCTRL.COMPL5_CFG2_0': 0x243,
            'MOKU_CTS_OTP_SWCTRL.COMPL5_CFG2_1': 0x81e,
            'MOKU_CTS_OTP_SWCTRL.COMPL6_CFG1': 0x8f5b,
            'MOKU_CTS_OTP_SWCTRL.COMPL6_CFG2_0': 0x181,
            'MOKU_CTS_OTP_SWCTRL.COMPL6_CFG2_1': 0x61b,
            'MOKU_CTS_OTP_SWCTRL.COMPL7_CFG1': 0x8d3f,
            'MOKU_CTS_OTP_SWCTRL.COMPL7_CFG2_0': 0x23a,
            'MOKU_CTS_OTP_SWCTRL.COMPL7_CFG2_1': 0x1f7,
            'MOKU_CTS_OTP_SWCTRL.COMPL8_CFG1': 0x8d2b,
            'MOKU_CTS_OTP_SWCTRL.COMPL8_CFG2_0': 0x226,
            'MOKU_CTS_OTP_SWCTRL.COMPL8_CFG2_1': 0x1a5,
            'MOKU_CTS_OTP_SWCTRL.COMPL1_PULSE_CFG_0': 0x505,
            'MOKU_CTS_OTP_SWCTRL.COMPL1_PULSE_CFG_1': 0xff06,
            'MOKU_CTS_OTP_SWCTRL.COMPL2_PULSE_CFG_0': 0xb0b,
            'MOKU_CTS_OTP_SWCTRL.COMPL2_PULSE_CFG_1': 0xfe06,
            'MOKU_CTS_OTP_SWCTRL.COMPL3_PULSE_CFG_0': 0x1313,
            'MOKU_CTS_OTP_SWCTRL.COMPL3_PULSE_CFG_1': 0xfc07,
            'MOKU_CTS_OTP_SWCTRL.COMPL4_PULSE_CFG_0': 0x1313,
            'MOKU_CTS_OTP_SWCTRL.COMPL4_PULSE_CFG_1': 0xfc07,
            'MOKU_CTS_OTP_SWCTRL.COMPL5_PULSE_CFG_0': 0x1212,
            'MOKU_CTS_OTP_SWCTRL.COMPL5_PULSE_CFG_1': 0xfd06,
            'MOKU_CTS_OTP_SWCTRL.COMPL6_PULSE_CFG_0': 0x1414,
            'MOKU_CTS_OTP_SWCTRL.COMPL6_PULSE_CFG_1': 0xfc07,
            'MOKU_CTS_OTP_SWCTRL.COMPL7_PULSE_CFG_0': 0x707,
            'MOKU_CTS_OTP_SWCTRL.COMPL7_PULSE_CFG_1': 0xff06,
            'MOKU_CTS_OTP_SWCTRL.COMPL8_PULSE_CFG_0': 0x606,
            'MOKU_CTS_OTP_SWCTRL.COMPL8_PULSE_CFG_1': 0xff06,
            'MOKU_CTS_OTP_SWCTRL.COMPL_CFG5': 0x30c0,
            'MOKU_CTS_OTP_SWCTRL.SELECT_CFG_0': 0x1100,
            'MOKU_CTS_OTP_SWCTRL.SELECT_CFG_1': 0x7801,
            'MOKU_CTS_OTP_SWCTRL.SLEW_CFG': 0x1c,
            'MOKU_CTS_OTP_SWCTRL.ERROR_CFG': 0xffff,
            'MOKU_CTS_OTP_SWCTRL.ERROR_CFG_1': 0x7,
            'MOKU_CTS_OTP_SWCTRL.BIST_CFG_0': 0xf,
            'MOKU_CTS_OTP_SWCTRL.BIST_CFG_1': 0x0,
            'MOKU_CTS_OTP_SWCTRL.TOLERANCE_CFG1_0': 0x4210,
            'MOKU_CTS_OTP_SWCTRL.TOLERANCE_CFG1_1': 0x798a,
            'MOKU_CTS_OTP_SARADC_MON.DIAG_ADC_MON_CFG_3_0': 0x0,
            'MOKU_CTS_OTP_SARADC_MON.DIAG_ADC_MON_CFG_5_0': 0x0,
            'MOKU_CTS_OTP_SARADC_MON.DIAG_ADC_MON_CFG_5_1': 0x0,
            'MOKU_CTS_OTP_SARADC_SENSE.ADC_SENS_CFG_4_1': 0x1,
            'MOKU_CTS_OTP_EXT_TEMP.LOW_TEMP_THRES': 0x4232,
            'MOKU_CTS_OTP_EXT_TEMP.HIGH_TEMP_THRES': 0x315,
            'MOKU_CTS_OTP_EXT_TEMP.EXTTMP_CTRL': 0x60,
            'MOKU_CTS_OTP_EXT_TEMP.TEMP_FILT_SAMPLES': 0x24,
            'MOKU_CTS_OTP_PAD_INTERFACE.PAD_CTRL_0': 0x89,
            'MOKU_CTS_OTP_ANALOG_CTRL.OVV_THRESHOLD_CTRL': 0xf5,
        }

        OTP11Val = {
            'MOKU_CTS_OTP_CCM.OSC_BIST_THRES_0': 0x1fd,
            'MOKU_CTS_OTP_CCM.OSC_TRIM_CTRL_0': 0x0,
            'MOKU_CTS_OTP_MSM.MSM_CTRL_1': 0x1ff,
            'MOKU_CTS_OTP_MSM.MSM_VIOLATION_MASK_0': 0x1000,
            'MOKU_CTS_OTP_MSM.MSM_VIOLATION_MASK_1': 0x2,
            'MOKU_CTS_OTP_MSM.MSM_OVV_VIOLATION_MASK_0': 0x0,
            'MOKU_CTS_OTP_MSM.MSM_OVV_VIOLATION_MASK_1': 0x0,
            'MOKU_CTS_OTP_MSM.MSM_FLT_MASK_1_0': 0x0,
            'MOKU_CTS_OTP_MSM.MSM_FLT_MASK_1_1': 0x0,
            'MOKU_CTS_OTP_MSM.MSM_FLT_MASK_2_0': 0x0,
            'MOKU_CTS_OTP_MSM.MSM_FLT_MASK_2_1': 0x0,
            'MOKU_CTS_OTP_MSM.COMPL_CFG4': 0x834,
            'MOKU_CTS_OTP_MSM.MSM_ANA_CTRL_0': 0xffff,
            'MOKU_CTS_OTP_MSM.MSM_ANA_CTRL_1': 0x7ff,
            'MOKU_CTS_OTP_MSM.ISRC_MM_CTRL': 0x1f,
            'MOKU_CTS_OTP_SWCTRL.COMPL1_CFG1': 0x8cef,
            'MOKU_CTS_OTP_SWCTRL.COMPL1_CFG2_0': 0x2bc,
            'MOKU_CTS_OTP_SWCTRL.COMPL1_CFG2_1': 0x120,
            'MOKU_CTS_OTP_SWCTRL.COMPL2_CFG1': 0x8ddf,
            'MOKU_CTS_OTP_SWCTRL.COMPL2_CFG2_0': 0x15e,
            'MOKU_CTS_OTP_SWCTRL.COMPL2_CFG2_1': 0x27e,
            'MOKU_CTS_OTP_SWCTRL.COMPL3_CFG1': 0x8fff,
            'MOKU_CTS_OTP_SWCTRL.COMPL3_CFG2_0': 0x009d,
            'MOKU_CTS_OTP_SWCTRL.COMPL3_CFG2_1': 0x315,
            'MOKU_CTS_OTP_SWCTRL.COMPL4_CFG1': 0x8f69,
            'MOKU_CTS_OTP_SWCTRL.COMPL4_CFG2_0': 0x172,
            'MOKU_CTS_OTP_SWCTRL.COMPL4_CFG2_1': 0x5fc,
            'MOKU_CTS_OTP_SWCTRL.COMPL5_CFG1': 0x8f0b,
            'MOKU_CTS_OTP_SWCTRL.COMPL5_CFG2_0': 0x243,
            'MOKU_CTS_OTP_SWCTRL.COMPL5_CFG2_1': 0x81e,
            'MOKU_CTS_OTP_SWCTRL.COMPL6_CFG1': 0x8f5b,
            'MOKU_CTS_OTP_SWCTRL.COMPL6_CFG2_0': 0x181,
            'MOKU_CTS_OTP_SWCTRL.COMPL6_CFG2_1': 0x61b,
            'MOKU_CTS_OTP_SWCTRL.COMPL7_CFG1': 0x8d3f,
            'MOKU_CTS_OTP_SWCTRL.COMPL7_CFG2_0': 0x23a,
            'MOKU_CTS_OTP_SWCTRL.COMPL7_CFG2_1': 0x1f7,
            'MOKU_CTS_OTP_SWCTRL.COMPL8_CFG1': 0x8d2b,
            'MOKU_CTS_OTP_SWCTRL.COMPL8_CFG2_0': 0x226,
            'MOKU_CTS_OTP_SWCTRL.COMPL8_CFG2_1': 0x1a5,
            'MOKU_CTS_OTP_SWCTRL.COMPL1_PULSE_CFG_0': 0x505,
            'MOKU_CTS_OTP_SWCTRL.COMPL1_PULSE_CFG_1': 0xff06,
            'MOKU_CTS_OTP_SWCTRL.COMPL2_PULSE_CFG_0': 0xb0b,
            'MOKU_CTS_OTP_SWCTRL.COMPL2_PULSE_CFG_1': 0xfe06,
            'MOKU_CTS_OTP_SWCTRL.COMPL3_PULSE_CFG_0': 0x1818,
            'MOKU_CTS_OTP_SWCTRL.COMPL3_PULSE_CFG_1': 0xfb07,
            'MOKU_CTS_OTP_SWCTRL.COMPL4_PULSE_CFG_0': 0x1414,
            'MOKU_CTS_OTP_SWCTRL.COMPL4_PULSE_CFG_1': 0xfc07,
            'MOKU_CTS_OTP_SWCTRL.COMPL5_PULSE_CFG_0': 0x1212,
            'MOKU_CTS_OTP_SWCTRL.COMPL5_PULSE_CFG_1': 0xfd06,
            'MOKU_CTS_OTP_SWCTRL.COMPL6_PULSE_CFG_0': 0x1414,
            'MOKU_CTS_OTP_SWCTRL.COMPL6_PULSE_CFG_1': 0xfc07,
            'MOKU_CTS_OTP_SWCTRL.COMPL7_PULSE_CFG_0': 0x707,
            'MOKU_CTS_OTP_SWCTRL.COMPL7_PULSE_CFG_1': 0xff06,
            'MOKU_CTS_OTP_SWCTRL.COMPL8_PULSE_CFG_0': 0x606,
            'MOKU_CTS_OTP_SWCTRL.COMPL8_PULSE_CFG_1': 0xff06,
            'MOKU_CTS_OTP_SWCTRL.COMPL_CFG5': 0x31c4,
            'MOKU_CTS_OTP_SWCTRL.SELECT_CFG_0': 0x1100,
            'MOKU_CTS_OTP_SWCTRL.SELECT_CFG_1': 0x7801,
            'MOKU_CTS_OTP_SWCTRL.SLEW_CFG': 0x1c,
            'MOKU_CTS_OTP_SWCTRL.ERROR_CFG': 0xffff,
            'MOKU_CTS_OTP_SWCTRL.ERROR_CFG_1': 0x7,
            'MOKU_CTS_OTP_SWCTRL.BIST_CFG_0': 0xf,
            'MOKU_CTS_OTP_SWCTRL.BIST_CFG_1': 0x0,
            'MOKU_CTS_OTP_SWCTRL.TOLERANCE_CFG1_0': 0x4210,
            'MOKU_CTS_OTP_SWCTRL.TOLERANCE_CFG1_1': 0x798a,
            'MOKU_CTS_OTP_SARADC_MON.DIAG_ADC_MON_CFG_3_0': 0x0,
            'MOKU_CTS_OTP_SARADC_MON.DIAG_ADC_MON_CFG_5_0': 0x0,
            'MOKU_CTS_OTP_SARADC_MON.DIAG_ADC_MON_CFG_5_1': 0x0,
            'MOKU_CTS_OTP_SARADC_SENSE.ADC_SENS_CFG_4_1': 0x1,
            'MOKU_CTS_OTP_EXT_TEMP.LOW_TEMP_THRES': 0x4232,
            'MOKU_CTS_OTP_EXT_TEMP.HIGH_TEMP_THRES': 0x315,
            'MOKU_CTS_OTP_EXT_TEMP.EXTTMP_CTRL': 0x60,
            'MOKU_CTS_OTP_EXT_TEMP.TEMP_FILT_SAMPLES': 0x24,
            'MOKU_CTS_OTP_PAD_INTERFACE.PAD_CTRL_0': 0x89,
            'MOKU_CTS_OTP_ANALOG_CTRL.OVV_THRESHOLD_CTRL': 0xf5,
        }

        # determine which moku config
        OTP_CTRL_6 = self.i2cread(0x4218)
        # print("DEBUG!!",hex(OTP_CTRL_6))
        OTPID_STS = (OTP_CTRL_6 & 0x0F00) >> 8 #bits 11:8 of OTP_CTRL_6
        # print("DEBUG2!!",hex(OTPID_STS))
        tracking_ID_2 = self.i2cread(0x0028)
        otp_max = 11
        otp_min = 11

        if OTPID_STS == 4:
            print("Moku Config2 Detected  - reject this moku!")
            ReportDataToStationAndPDCA(prefix + "MOKU" + self.LR + "_Config", 2, "Config", otp_min, otp_max)
            selectedOTP = OTP2Val
        elif OTPID_STS == 7:
            print("Moku Config3 Detected - reject this moku!")
            ReportDataToStationAndPDCA(prefix + "MOKU" + self.LR + "_Config", 3, "Config",otp_min, otp_max)
            selectedOTP = OTP3Val
        elif OTPID_STS == 8:
            # either config 4 or 4b
            if tracking_ID_2 == 0x0904:
                # Config 4b - good for the build.
                print("Moku Config4B Detected - reject this moku!")
                ReportDataToStationAndPDCA(prefix + "MOKU" + self.LR + "_Config", 4, "Config", otp_min, otp_max)
                selectedOTP = OTP4Val
            elif tracking_ID_2 == 0x0804:
                # config 4 - reject
                print("Moku Config4 Detected - reject this moku!")
                # Report Config 4 as 4.5 to PDCA  ensures proper rejection of Moku
                ReportDataToStationAndPDCA(prefix + "MOKU" + self.LR + "_Config", 4.5, "Config", otp_min, otp_max)
                selectedOTP = OTP4Val
            else:
                print("unknown config  - reject this moku!")
                ReportDataToStationAndPDCA(prefix + "MOKU" + self.LR + "_Config", 0, "Config", otp_min, otp_max)
                selectedOTP = OTP2Val
        elif OTPID_STS == 9:
            print("Moku Config5 Detected - reject this moku!")
            ReportDataToStationAndPDCA(prefix + "MOKU" + self.LR + "_Config", 5, "Config", otp_min, otp_max)
            selectedOTP = OTP5Val
        elif OTPID_STS == 10:
            print("Moku Config6 Detected - reject this moku!")
            ReportDataToStationAndPDCA(prefix + "MOKU" + self.LR + "_Config", 6, "Config", otp_min, otp_max)
            selectedOTP = OTP6Val

        elif OTPID_STS == 11:
            device = self.i2cread(0x0024)
            if device == 0x7B:
                print("Moku Config7b Detected - reject this moku!")
                ReportDataToStationAndPDCA(prefix + "MOKU" + self.LR + "_Config", 7.5, "Config", otp_min, otp_max)
            else:
                print("Moku Config7 Detected - reject this moku!")
                ReportDataToStationAndPDCA(prefix + "MOKU" + self.LR + "_Config", 7, "Config", otp_min, otp_max)

            selectedOTP=OTP7Val

        elif OTPID_STS == 12:
            print("Moku Config8 Detected - reject this moku!")
            ReportDataToStationAndPDCA(prefix + "MOKU" + self.LR + "_Config", 8, "Config", otp_min, otp_max)
            selectedOTP = OTP8Val

        elif OTPID_STS == 13:
            print("Moku Config9 Detected - reject this moku!")
            ReportDataToStationAndPDCA(prefix + "MOKU" + self.LR + "_Config", 9, "Config", otp_min, otp_max)
            selectedOTP = OTP9Val

        elif OTPID_STS == 14:
            print("Moku Config10 Detected - pass this moku!")
            ReportDataToStationAndPDCA(prefix + "MOKU" + self.LR + "_Config", 10, "Config", otp_min, otp_max)
            selectedOTP = OTP10Val

        elif OTPID_STS == 15:
            print("Moku Config11 Detected - pass this moku!")
            ReportDataToStationAndPDCA(prefix + "MOKU" + self.LR + "_Config", 11, "Config", otp_min, otp_max)
            selectedOTP = OTP11Val

        else:
            print("unknown config  - reject this moku!")
            ReportDataToStationAndPDCA(prefix + "MOKU" + self.LR + "_Config", 0, "Config", otp_min, otp_max)
            selectedOTP = OTP2Val

        # Check OTP
        for key in OTPMap:
            val=OTPMap[key]
            dat=self.i2cread(val)
            ReportDataToStationAndPDCA(prefix+key.split("_CTS_")[0]+self.LR+"_CTS_"+key.split("_CTS_")[1],dat,"hex",selectedOTP[key],selectedOTP[key])

    def internalTempRead(self):
        self.i2cwrite(0x0406,0x0000)
        self.i2cwrite(0x0800,0x0000)
        self.i2cwrite(0x2014,0x0140)
        # self.i2cwrite(0x2094,0x0000)
        # nterrupt signal get asserted due to the ADC_data_info get unmasked here.
        # (remove this line if you do not want to assert INT for diagnostic data available)
        self.i2cwrite(0x0804,0x0000)
        self.i2cwrite(0x0806,0x0000)
        self.i2cwrite(0x080A,0x0001)
        self.i2cwrite(0x0804,0xFFFF)
        self.i2cwrite(0x0806,0x000F)
        time.sleep(0.0002)
        self.i2cwrite(0x0800,0x0802)
        # it should be => self.i2cwrite(0x0800, 0x0802)
        # write 0x0800 with value 0x0802 (you want 2^8 (256 samples) from the ADC, so for this you may have to wait 200us per sample
        # before you read out to get accurate number (so total ~51ms)
        time.sleep(0.1)
        dat=int(self.i2cread(0x1400))

		## Pei : added the conversion here
        if dat < 2 ** 16 / 2:
            int_temp_v = dat * 2 ** (-7)
        else:
            int_temp_v = (dat - 2 ** 16) * 2 ** (-7)

        ReportDataToStationAndPDCA("MOKU"+self.LR+"_INT_TEMP",dat,"hex",0x00,0xffff)

        state = self.i2cread(0x0400)
        if state != 0x08: # 0x08 is idle state -
            print("Not in Idle state test after internal temperature check - BAD!")
        ReportDataToStationAndPDCA("MOKU"+self.LR+"_INT_TEMP_BIST_STATUS", state, "hex", 0x08, 0x08)



    def specialSause(self):
        self.i2cwrite(0x040c,0x800)

    def externalTempRead(self):
        self.i2cwrite(0x0406,0x0000)
        self.i2cwrite(0x0800,0x0000)
        self.i2cwrite(0x2014,0x0140)
        # self.i2cwrite(0x2094,0x0000)
        # nterrupt signal get asserted due to the ADC_data_info get unmasked here.
        # (remove this line if you do not want to assert INT for diagnostic data available)
        self.i2cwrite(0x0804,0x0000)
        self.i2cwrite(0x0806,0x0000)
        self.i2cwrite(0x080A,0x0001)
        self.i2cwrite(0x0804,0xFFFF)
        self.i2cwrite(0x0806,0x000F)
        time.sleep(0.0002)
        self.i2cwrite(0x0800,0x0802)
        # it should be => self.i2cwrite(0x0800, 0x0802)
        # write 0x0800 with value 0x0802 (you want 2^8 (256 samples) from the ADC, so for this you may have to wait 200us per sample
        # before you read out to get accurate number (so total ~51ms)
        time.sleep(0.2)
        dat=int(self.i2cread(0x1204))  #Pei : multiply this by 2. I fixed this in line 563
        beta_constant = 3380
        kelvin_offset = 273.15
        standard_state = 298.15
        try:
            external_temp_c = (beta_constant / math.log(2*dat / (10000 * math.exp(-1*beta_constant / standard_state)))) - kelvin_offset
        except:
            external_temp_c=0
        # external_temp_c = (beta_constant / math.log(dat / (10000 * math.exp(-1*beta_constant / standard_state)))) - kelvin_offset
        ReportDataToStationAndPDCA("KILAUEA"+self.LR+"_EXT_TEMP",external_temp_c,"deg_c",15,45)

        state = self.i2cread(0x0400)
        if state != 0x08: # 0x08 is idle state
            print("Not in Idle state test after exteranl temperature check - BAD!")
        ReportDataToStationAndPDCA("KILAUEA"+self.LR+"_EXT_TEMP_BIST_STATUS", state, "hex", 0x08, 0x08)


    def BISTCheck(self,prefix="",dump=True):

        #dummy read to clear the FIFO
        self.i2cread(0x0000)

        state=int(self.i2cread(0x0400))
        if state!=0x02:
            print("BIST entry state is not standby, BAD!")
        ReportDataToStationAndPDCA(prefix+"MOKU"+self.LR+"_BIST_ENTRY_STATE",state,"hex",0x02,0x02)

        self.i2cwrite(0x0408,0x01) #state transition
        time.sleep(0.01)

        state=int(self.i2cread(0x0400))
        if state!=0x08:
            print("BIST exit state is not standby, BAD!")
        ReportDataToStationAndPDCA(prefix+"MOKU"+self.LR+"_BIST_EXIT_STATE",state,"hex",0x08,0x08)
        if dump:
            self.interruptDump(prefix=prefix)

    def interruptDump(self,prefix=""):
        IRQ_INT_0=int(self.i2cread(0x2010))
        ReportDataToStationAndPDCA(prefix+"MOKU"+self.LR+"_BIST_IRQ_INT_0",IRQ_INT_0,"hex",0x0000,0xffff)
        IRQ_INT_1=int(self.i2cread(0x2012))
        ReportDataToStationAndPDCA(prefix+"MOKU"+self.LR+"_BIST_IRQ_INT_1",IRQ_INT_1,"hex",0x0000,0xffff)
        IRQ_INT_2=int(self.i2cread(0x2014))
        ReportDataToStationAndPDCA(prefix+"MOKU"+self.LR+"_BIST_IRQ_INT_2",IRQ_INT_2,"hex",0x0000,0xffff)
        IRQ_INT_3=int(self.i2cread(0x2016))
        ReportDataToStationAndPDCA(prefix+"MOKU"+self.LR+"_BIST_IRQ_INT_3",IRQ_INT_3,"hex",0x0000,0xffff)
        IRQ_INT_4=int(self.i2cread(0x2018))
        ReportDataToStationAndPDCA(prefix+"MOKU"+self.LR+"_BIST_IRQ_INT_4",IRQ_INT_4,"hex",0x0000,0xffff)
        IRQ_INT_5=int(self.i2cread(0x201A))
        ReportDataToStationAndPDCA(prefix+"MOKU"+self.LR+"_BIST_IRQ_INT_5",IRQ_INT_5,"hex",0x0000,0x0004)
        IRQ_INT_6=int(self.i2cread(0x201C))
        ReportDataToStationAndPDCA(prefix+"MOKU"+self.LR+"_BIST_IRQ_INT_6",IRQ_INT_6,"hex",0x0000,0x0000)

        IRQ_INT_7=int(self.i2cread(0x201E))
        OTP_CTRL_6 = self.i2cread(0x4218)
        OTPID_STS = (OTP_CTRL_6 & 0x0F00) >> 8;  # bits 11:8 of OTP_CTRL_6

        if OTPID_STS < 12:
            ReportDataToStationAndPDCA(prefix+"MOKU"+self.LR+"_BIST_IRQ_INT_7",IRQ_INT_7,"hex",0x3000,0x3000)
        else:
            ReportDataToStationAndPDCA(prefix+"MOKU"+self.LR+"_BIST_IRQ_INT_7",IRQ_INT_7,"hex",0x0000,0x0000)

        IRQ_INT_8=int(self.i2cread(0x2020))
        ReportDataToStationAndPDCA(prefix+"MOKU"+self.LR+"_BIST_IRQ_INT_8",IRQ_INT_8,"hex",0x0000,0x0000)
        IRQ_INT_9=int(self.i2cread(0x2022))
        ReportDataToStationAndPDCA(prefix+"MOKU"+self.LR+"_BIST_IRQ_INT_9",IRQ_INT_9,"hex",0x0000,0x0000)
        IRQ_INT_10=int(self.i2cread(0x2024))
        ReportDataToStationAndPDCA(prefix+"MOKU"+self.LR+"_BIST_IRQ_INT_10",IRQ_INT_10,"hex",0x0000,0x0000)
        IRQ_INT_11=int(self.i2cread(0x2026))
        ReportDataToStationAndPDCA(prefix+"MOKU"+self.LR+"_BIST_IRQ_INT_11",IRQ_INT_11,"hex",0x0000,0x0000)
        IRQ_INT_12=int(self.i2cread(0x2028))
        ReportDataToStationAndPDCA(prefix+"MOKU"+self.LR+"_BIST_IRQ_INT_12",IRQ_INT_12,"hex",0x0000,0x0000)
        IRQ_INT_13=int(self.i2cread(0x202A))
        ReportDataToStationAndPDCA(prefix+"MOKU"+self.LR+"_BIST_IRQ_INT_13",IRQ_INT_13,"hex",0x0000,0x0000)
        IRQ_INT_14=int(self.i2cread(0x202C))
        ReportDataToStationAndPDCA(prefix+"MOKU"+self.LR+"_BIST_IRQ_INT_14",IRQ_INT_14,"hex",0x0000,0x0000)
        IRQ_INT_15=int(self.i2cread(0x202E))
        ReportDataToStationAndPDCA(prefix+"MOKU"+self.LR+"_BIST_IRQ_INT_15",IRQ_INT_15,"hex",0x0000,0x0000)
        IRQ_INT_16=int(self.i2cread(0x2030))
        ReportDataToStationAndPDCA(prefix+"MOKU"+self.LR+"_BIST_IRQ_INT_16",IRQ_INT_16,"hex",0x0000,0x0000)
        IRQ_INT_17=int(self.i2cread(0x2032))
        ReportDataToStationAndPDCA(prefix+"MOKU"+self.LR+"_BIST_IRQ_INT_17",IRQ_INT_17,"hex",0x0000,0x0000)
        IRQ_INT_18=int(self.i2cread(0x2034))
        ReportDataToStationAndPDCA(prefix+"MOKU"+self.LR+"_BIST_IRQ_INT_18",IRQ_INT_18,"hex",0x2a0,0x2a0)
        IRQ_INT_19=int(self.i2cread(0x2036))
        ReportDataToStationAndPDCA(prefix+"MOKU"+self.LR+"_BIST_IRQ_INT_19",IRQ_INT_19,"hex",0x0000,0x0000)
        ERROR_STS=int(self.i2cread(0x06EC))
        ReportDataToStationAndPDCA(prefix+"KILAUEA"+self.LR+"_ERROR_STS",ERROR_STS,"hex",0x0000,0x0000)


    def setupStrobe(self,source):
        self.i2cwrite(0x0680,0x0000) # Copmliance Rule 0
        self.i2cwrite(0x0682,0x000F) # Signals on TRIG 1,2,3,4 all enable Moku Strobe 1
        # Above line shold write to 0x000F, per Pei's comment
        if source == 1:
            self.i2cwrite(0x0684,0x04ff) # SRC 1: write 0x04ff
        elif source == 2:
            self.i2cwrite(0x0684,0x08ff) # SRC 2: write 0x08ff
        else:
            self.i2cwrite(0x0684,0x0000) # no srcs
        self.i2cwrite(0x0686,0x0000)
        self.i2cwrite(0x0688,0x0000)
        self.i2cwrite(0x068a,0x0000)
        self.i2cwrite(0x0694,0x009F) # SNK1: 8mA drive current
        self.i2cwrite(0x0696,0x009F) # SNK2: 8mA drive current
        self.i2cwrite(0x0698,0x009F) # SNK3: 8mA drive current
        self.i2cwrite(0x069a,0x009F) # SNK4: 8mA drive current
        self.i2cwrite(0x069c,0x009F) # SNK5: 8mA drive current
        self.i2cwrite(0x069e,0x009F) # SNK6: 8mA drive current
        self.i2cwrite(0x06a0,0x009F) # SNK7: 8mA drive current
        self.i2cwrite(0x06a2,0x009F) # SNK8: 8mA drive current


    def sause(self):
        print("Pouring on some sause")
        val=int(self.i2cread(0x040C))
        self.i2cwrite(0x040C,val|0x4000)
        self.i2cwrite(0x209E,0x1000)
    def setISNK(self,ISNK,percent):
        full=0x9c
        baseAddr=0x0694

        self.i2cwrite(baseAddr+(ISNK-1)*2,int(full*(percent/100)))

    def configureStrobes(self,source,nine=False,current=6):
        # Program Moku src/snk
        hexCurrent=current/0.05
        self.i2cwrite(0x0680,0x0000)
        self.i2cwrite(0x0682,0x000f)
        if source == 1:
            self.i2cwrite(0x0684,0x04ff+(nine*0x100)) # SRC 1: write 0x04ff
            print("Configuring Source 1",hex(0x04ff+(nine*0x100)))
        elif source == 2:
            self.i2cwrite(0x0684,0x08ff+(nine*0x100)) # SRC 2: write 0x08ff
            print("Configuring Source 2",hex(0x08ff+(nine*0x100)))
        else:
            self.i2cwrite(0x0684,0x0000) # no srcs
        self.i2cwrite(0x0686,0x0000)
        self.i2cwrite(0x0688,0x0000)
        self.i2cwrite(0x068a,0x0000)
        # self.i2cwrite(0x068c,0x0000)
        # self.i2cwrite(0x068e,0x0000)
        # self.i2cwrite(0x0690,0x0000)
        # self.i2cwrite(0x0692,0x0000)
        self.i2cwrite(0x0694,int(hexCurrent))
        self.i2cwrite(0x0696,int(hexCurrent))
        self.i2cwrite(0x0698,int(hexCurrent))
        self.i2cwrite(0x069a,int(hexCurrent))
        self.i2cwrite(0x069c,int(hexCurrent))
        self.i2cwrite(0x069e,int(hexCurrent))
        self.i2cwrite(0x06a0,int(hexCurrent))
        self.i2cwrite(0x06a2,int(hexCurrent))
        if nine:
            self.i2cwrite(0x06a4,int(hexCurrent))
        else:
            self.i2cwrite(0x06a4,0x0000)
        self.i2cwrite(0x06a6,0x0000)


    def compliancePatch(self):
        # write config 3 settings into empty config 2
        self.i2cwrite(0x600,	0x8CB3)
        self.i2cwrite(0x604,	0xFFFF)
        self.i2cwrite(0x606,	0x32)
        self.i2cwrite(0x608,	0xB3)
        self.i2cwrite(0x640,	0x1616)
        self.i2cwrite(0x642,	0x104)
        self.i2cwrite(0x644,	0x1616)
        self.i2cwrite(0x646,	0x104)
        self.i2cwrite(0x660,	0x80)
        self.i2cwrite(0x664,	0x200)
        self.i2cwrite(0x666,	0x1)




class Lanai(I2CDevice,N301Camera):
    def __init__(self,sib):
        I2CDevice.__init__(self,sib,0x10,2,1)
        N301Camera.__init__(self,sib.channel)
        # self.setPermission()
        # Refer to Lanai VSR / NVM Map: rdar://94679838
        # Limits listed are for historical reference, not enforced in pass/fail
        self.nvmIntegrityDict = [
            {"Reg" : 0x0000, "Page": 0, "NumofBytes" : 3, "NVMDetails" : [
                {"Name" : "LANAI_NVM_FLAG",                 "StartBit" : 0,   "Len" : 8,   "Result" : 0xFF},
                {"Name" : "LANAI_NVM_TYPE",                 "StartBit" : 8,   "Len" : 8,   "Result" : 0x00},
                {"Name" : "LANAI_NVM_HEADER_REVISION",      "StartBit" : 16,  "Len" : 8,   "Result" : 0x02},
            ]},
            {"Reg" : 0x0022, "Page": 0, "NumofBytes" : 4, "NVMDetails" : [
                {"Name" : "LANAI_NVM_CAMERA_PROJECT",       "StartBit" : 0,   "Len" : 8,   "Result" : 0x38},
                {"Name" : "LANAI_NVM_PROJECT_VERSION",      "StartBit" : 8,   "Len" : 8,   "Result" : [0x00,0x03]},
                {"Name" : "LANAI_NVM_INTEGRATOR",           "StartBit" : 16,  "Len" : 8,   "Result" : 0x28},
                {"Name" : "LANAI_NVM_CAMERA_BUILD",         "StartBit" : 24,  "Len" : 8,   "Result" : [0x10,0x30]},
            ]},
            {"Reg" : 0x0026, "Page": 0, "NumofBytes" : 1, "NVMDetails" : [
                {"Name" : "LANAI_NVM_CONFIG_NUMBER",        "StartBit" : 0,  "Len" : 8,   "Result" : [0x00,0xFF]},
            ]},
            {"Reg" : 0x0032, "Page": 0, "NumofBytes" : 4, "NVMDetails" : [
                {"Name" : "LANAI_NVM_IRCF",                 "StartBit" : 0,   "Len" : 8,   "Result" : 0x00},
                {"Name" : "LANAI_NVM_SUBSTRATE",            "StartBit" : 8,   "Len" : 8,   "Result" : [0x40,0x65]},
                {"Name" : "LANAI_NVM_SENSOR",               "StartBit" : 16,  "Len" : 8,   "Result" : [0x20,0x3E]},
                {"Name" : "LANAI_NVM_ACTUATOR",             "StartBit" : 24,  "Len" : 8,   "Result" : 0x00},
            ]},
            {"Reg" : 0x0036, "Page": 0, "NumofBytes" : 4, "NVMDetails" : [
                {"Name" : "LANAI_NVM_LENS",                 "StartBit" : 0,   "Len" : 8,   "Result" : [0x20,0x28]},
                {"Name" : "LANAI_NVM_DRIVER",               "StartBit" : 8,   "Len" : 8,   "Result" : 0x00},
                {"Name" : "LANAI_NVM_SPHERE",               "StartBit" : 16,  "Len" : 8,   "Result" : 0x00},
                {"Name" : "LANAI_NVM_APS",                  "StartBit" : 24,  "Len" : 8,   "Result" : 0x00},
            ]},
            {"Reg" : 0x003A, "Page": 0, "NumofBytes" : 3, "NVMDetails" : [
                {"Name" : "LANAI_NVM_FLEX",                 "StartBit" : 0,   "Len" : 8,   "Result" : [0x10,0x50]},
                {"Name" : "LANAI_NVM_STIFFENER",            "StartBit" : 8,   "Len" : 8,   "Result" : [0x08,0x70]},
                {"Name" : "LANAI_NVM_TRIM",                 "StartBit" : 16,  "Len" : 8,   "Result" : [0x00,0x01]},
            ]},
        ]

    def getChipID(self):
        dat1=int(self.i2cread(0xfAC7))
        # print(hex(dat1))
        dat2=int(self.i2cread(0xfAC8))
        # print(hex(dat2))
        return (dat1<<8)+dat2
    def getLotCode(self):
        return self.i2creadChunk([0xfacb,0xfacc,0xfacd,0xface,0xfacf,0xfad0,0xfad1,0xfad2,0xfad3,0xfad4])
    def getFabID(self):
        return self.i2creadChunk([0xfac9,0xface,0xfad5,0xfaca])
    def getFrameCounter(self):
        return self.i2cread(0x0018)

    # def gotoNVMPage(self, page):
    #     # Context switch to OTPIF_PAGE_SELECT (0x3202) -> 0x0-0x57
    #     self.i2cwrite(0xE002, page)
    #     # Set read mode by OTPIF_CTRL (0x3200) -> 1
    #     self.i2cwrite(0xE000, 0x1)

    def getNVMreg(self, reg):
        # convert "0x0020" to NVM-readable register, i.e. 0x3224
        otp_offset = 0xF000
        otp_reg = otp_offset + reg

        return otp_reg

    def setupSync(self):
        self.i2cwrite(0x0681,0x00) # Continous output
        self.i2cwrite(0x0650,0x01) # mid-exposure drive
        self.i2cwrite(0x0651,0x04) # Strobe on GPO0: 0x04, Strobe on GPO1 for BECAM: 0x???
        # Need GPO 1 configuration from Ashish
        self.i2cwrite(0x0680,0x00) # use shutter as reference point
        self.i2cwrite(0x0685,0x000000,3) # Zero delay from reference point
        self.i2cwrite(0x068c,0x000003D4,4) #4000us strobe signal to match exposure time of 4000us
        self.i2cwrite(0x0670,0x01,1) #enable

    #
    #     frameTxt=ISPShell("SFSTART "+str(self.cam),prompt="framereceived:",timeout=10)
    #     print(frameTxt)
    # def stopStreaming(self):
    #     ISPShell("SFSTOP "+str(self.cam))
    #
    # def primeStrobe(self,ton=5500):#ton in us
    #     tonval=int(ton/4.083)
    #     print("Ton reg",hex(tonval))
    #     self.i2cwrite(0x0681,0x00,1)
    #     self.i2cwrite(0x0650,0x01,1)
    #     self.i2cwrite(0x0651,0x04,1)
    #     self.i2cwrite(0x0680,0x00,1)
    #     self.i2cwrite(0x0685,0x00,3)
    #     self.i2cwrite(0x068c,tonval,4)
    #     self.i2cwrite(0x0670,0x01,1)

    def primeStrobe1(self,ton=5500):#ton in us
        tonval=int(ton/4.083)
        print("Ton reg",hex(tonval))
        self.i2cwrite(0x0681,0x00,1) #single or continuous pulse (0x00 is continuous)

        self.i2cwrite(0x0650,0x01,1) #corresponds to GPIO1
        self.i2cwrite(0x0651,0x04,1) # connect GPIO1 to GPO1 (setting to 0x03 will be GPO2)
        self.i2cwrite(0x0659, 0x00, 1) #disable GPIO3

        self.i2cwrite(0x0680,0x00,1) #reference point read or shhutter (0x00 = shutter)
        self.i2cwrite(0x0685,0x00,3) #strobe delay
        self.i2cwrite(0x068c,tonval,4) #strobe width
        self.i2cwrite(0x0670,0x01,1) # generate strobe for GPO1

    def primeStrobe2(self, ton=5500):  # ton in us
        tonval = int(ton / 4.083)
        print("Ton reg", hex(tonval))
        self.i2cwrite(0x0681, 0x00, 1)

        self.i2cwrite(0x0658, 0x01, 1) # connect GPIO3 to GPO2 (setting to 0x03 will be GPO2)
        self.i2cwrite(0x0659, 0x04, 1) #connect GPIO3 to GPO1
        self.i2cwrite(0x0651, 0x00, 1) #disable GPIO1

        self.i2cwrite(0x0680, 0x00, 1)
        self.i2cwrite(0x0685, 0x00, 3)
        self.i2cwrite(0x068c, tonval, 4)
        self.i2cwrite(0x0670, 0x01, 1)

    def setPermission(self):
        self.i2cwrite(0x30eb,0x05)
        self.i2cwrite(0x30eb,0x0c)
        self.i2cwrite(0x300a,0xff)
        self.i2cwrite(0x300b,0xff)
        self.i2cwrite(0x30eb,0x05)
        self.i2cwrite(0x30eb,0x09)
    def boot(self):

        self.setupClock()
        if self.bootSuccess()==0:
            print("Secure Boot Failed!")
            self.writeManifest()
            self.applyPatch()
        if self.bootSuccess()==1:
            print("Secure Boot Success!")
            print("Writing sause")
            self.sause()
            print("Starting Linktraning")
            self.linkTrain()

        else:
            print("Secure Boot Failed!")
            self.setupClock()
            self.writeManifest()
            self.applyPatch()

            if self.bootSuccess() == 1:
                print("Secure Boot Success!")
            else:
                print("Secure Boot Failed!")
            self.sause()
            self.linkTrain()

    def setupClock(self):
        success = True
        #setup clock
        print("Setting up clock")
        self.i2cwrite( 0x1218,  0x18)
        self.i2cwrite( 0x1219,  0x00)
        self.i2cwrite( 0x121A,  0xFF)
        self.i2cwrite( 0x121B,  0xFF)


    def bootSuccess(self):
        result = self.i2cread(0x0528) #left
        if result !=0 :
            return 1
        else:
            return 0

    def linkTrain(self):
        print("Link training...")
        #start link training?
        self.i2cwrite( 0x052D, 0x03) #left
        time.sleep(0.2)
        # SNL_SpiWriteRegister(SIMPLELPDPRXCFG_SIMPLELPDPRXCFGREGS_TPS1_START(cameraInterfaceInfo[device]["LRSEL"]), 0x01)
        time.sleep(2)
        self.i2cwrite( 0x052D, 0x02) #left
        time.sleep(0.2)
        self.i2cwrite( 0x052D, 0x00) #left
        time.sleep(0.2)
        self.i2cwrite( 0x0100, 0x01) #left
        time.sleep(0.2)
        # SNL_SpiWriteRegister(SIMPLELPDPRXCFG_SIMPLELPDPRXCFGREGS_ENABLE(cameraInterfaceInfo[device]["LRSEL"]), 0x01)

    def setExposure(self):
        # set exposure to 8 ms
        self.i2cwrite(0x014D, 0x00)
        self.i2cwrite(0x014E, 0x07)
        self.i2cwrite(0x014F, 0xD0)
        self.i2cread(0x014D)
    def setBlackLevelGain(self, gain):
        ana_gain = 256 * (1 - 1 / gain)
        self.i2cwrite(0x0149, int(ana_gain))
        self.i2cread(0x0149)
    def opticalBlackRegDump(self,prefix=""):
        opticalBlackSum = 0
        for i in range (10):
            test_name = "ROUND_"+str(i)+"_"+prefix+"_OPTICAL_BLACK_"
            breg1 = self.i2cread(0x0400, 2)
            breg2 = self.i2cread(0x0404, 4)
            breg3 = self.i2cread(0x0408, 4)
            breg4 = self.i2cread(0x0414, 4)
            breg5 = self.i2cread(0x0418, 4)
            diags("wait 8")
            opticalBlackSum += sum([breg1, breg2, breg3, breg4, breg5])
        return opticalBlackSum

# def strobeSause()
#   self.i2cwrite( 0x0660, 0x03)   #external sync
#   self.i2cwrite( 0x0681, 0x00)    #continous mode
#   self.i2cwrite( 0x0651, 0x04)    #select GPO1 as source
#   self.i2cwrite( 0x0650, 0x01)    #drive strengh normal
#   self.i2cwrite( 0x068D, 0x00)    #255 x 4us width
#   self.i2cwrite( 0x068E, 0x00)    #255 x 4us width
#   self.i2cwrite( 0x068F, 0xff)    #255 x 4us width
#   self.i2cwrite( 0x0670, 0x01)    #strobe start
#
    def stream(self):
        self.i2cwrite(0x30eb,  0x05 )
        self.i2cwrite(0x30eb,  0x0c )
        self.i2cwrite(0x300a,  0xffff )
        self.i2cwrite(0x0110,  0x0101 )
        self.i2cwrite(0x0124,  0x1800 )
        self.i2cwrite(0x014d,  0x0000f4 )
        self.i2cwrite(0x0155,  0x000aa1 )
        self.i2cwrite(0x016e,  0x00 )
        self.i2cwrite(0x0170,  0x00 )
        self.i2cwrite(0x0172,  0x00 )
        self.i2cwrite(0x0174,  0x0000000005000500 )
        self.i2cwrite(0x0180,  0x0100 )
        self.i2cwrite(0x018a,  0x00 )
        self.i2cwrite(0x018d,  0x000000 )
        self.i2cwrite(0x0195,  0x000008 )
        self.i2cwrite(0x01c8,  0x00 )
        self.i2cwrite(0x01d0,  0x00 )
        self.i2cwrite(0x01e8,  0x00 )
        self.i2cwrite(0x01f0,  0x8280 )
        self.i2cwrite(0x0301,  0x08 )
        self.i2cwrite(0x0304,  0x02 )
        self.i2cwrite(0x0306,  0x00aa )
        self.i2cwrite(0x0311,  0x03 )
        self.i2cwrite(0x03e0,  0x00 )
        self.i2cwrite(0x03e2,  0x0100 )
        self.i2cwrite(0x0511,  0x81 )
        self.i2cwrite(0x0528,  0x55f000 )
        self.i2cwrite(0x0598,  0x02 )
        self.i2cwrite(0x0624,  0x05000500 )
        self.i2cwrite(0x0550,  0x01 )
        self.i2cwrite(0x0518,  0x0c0c0202 )
        self.i2cwrite(0x0514,  0x03 )
        self.i2cwrite(0x0551,  0x02 )
        self.i2cwrite(0x0554,  0x03e803e8 )
        self.i2cwrite(0x0564,  0x3e )
        self.i2cwrite(0x0567,  0x02 )
        self.i2cwrite(0x0553,  0x00 )
        self.i2cwrite(0x0552,  0x02 )
        self.i2cwrite(0x0560,  0x03e803e8 )
        self.i2cwrite(0x0524,  0x0101 )
        self.i2cwrite(0x0108,  0x02 )
        self.i2cwrite(0x0149,  0x00 )
        self.i2cwrite(0x0600,  0x0000 )
        self.i2cwrite(0x0550,  0x00 )
        self.i2cwrite(0x0600,  0x0000 )
        self.i2cwrite(0x0511,  0x81 )
        self.i2cwrite(0x052c,  0x20 )
        self.i2cwrite(0x052d,  0x07 )
        self.i2cwrite(0x051d,  0x00 )
        self.i2cwrite(0x05ec,  0x01 )
        self.i2cwrite(0x05ed,  0x3c )
        self.i2cwrite(0x0554,  0x04 )
        self.i2cwrite(0x0555,  0x65 )
        self.i2cwrite(0x0560,  0x04 )
        self.i2cwrite(0x0561,  0x65 )
        self.i2cwrite(0x0553,  0x00 )
        self.i2cwrite(0x0550,  0x01 )
        self.i2cwrite(0x0524,  0x01 )
        self.i2cwrite(0x0525,  0x01 )
        self.i2cwrite(0x0500,  0x01 )
        self.i2cwrite(0x0510,  0x01 )
        self.i2cwrite(0x0518,  0x0c )
        self.i2cwrite(0x0519,  0x0c )
        self.i2cwrite(0x052d,  0x03 )
        self.i2cwrite(0x052d,  0x02 )
        self.i2cwrite(0x052d,  0x00 )
        self.i2cwrite(0x0178,  0x0500 )
        self.i2cwrite(0x017a,  0x0500 )
        self.i2cwrite(0x0155,  0x000aa0 )
        self.i2cwrite(0x014d,  0x0007f8 )
        self.i2cwrite(0x0180,  0x01)
        self.i2cwrite(0x0181,  0x00)
        self.i2cwrite(0x0108,  0x00)
        self.i2cwrite(0x0100,  0x01 )
        self.i2cwrite(0x012c,  0x0101 )
    def writeManifest(self):
        #secure boot firmware
        print("Writing Manifest Information")
        self.i2cwrite( 0x1200,  0x00)    #Manifest Information
        self.i2cwrite( 0x1201,  0x00)    #Manifest Information
        self.i2cwrite( 0x1202,  0x20)    #Manifest Information
        self.i2cwrite( 0x1203,  0x00)    #Manifest Information
        self.i2cwrite( 0x1204,  0x00)    #Manifest Information
        self.i2cwrite( 0x1205,  0x00)    #Manifest Information
        self.i2cwrite( 0x1206,  0x04)    #Manifest Information
        self.i2cwrite( 0x1207,  0xD2)    #Manifest Information
        print("Writing FWP")
        self.i2cwrite( 0x1208,  0x00)    #FWP Information
        self.i2cwrite( 0x1209,  0x00)    #FWP Information
        self.i2cwrite( 0x120A,  0x24)    #FWP Information
        self.i2cwrite( 0x120B,  0xE0)    #FWP Information
        self.i2cwrite( 0x120C,  0x00)    #FWP Information
        self.i2cwrite( 0x120D,  0x00)    #FWP Information
        self.i2cwrite( 0x120E,  0x06)    #FWP Information
        self.i2cwrite( 0x120F,  0x94)    #FWP Information
        print("Writing Manifest")
        manifest=[[0x2000,  0x30],    #Manifest
        [0x2001,  0x82],    #Manifest
        [0x2002,  0x04],    #Manifest
        [0x2003,  0xCE],    #Manifest
        [0x2004,  0x16],    #Manifest
        [0x2005,  0x04],    #Manifest
        [0x2006,  0x49],    #Manifest
        [0x2007,  0x4D],    #Manifest
        [0x2008,  0x34],    #Manifest
        [0x2009,  0x4D],    #Manifest
        [0x200A,  0x02],    #Manifest
        [0x200B,  0x01],    #Manifest
        [0x200C,  0x00],    #Manifest
        [0x200D,  0x31],    #Manifest
        [0x200E,  0x82],    #Manifest
        [0x200F,  0x02],    #Manifest
        [0x2010,  0xDB],    #Manifest
        [0x2011,  0xFF],    #Manifest
        [0x2012,  0x84],    #Manifest
        [0x2013,  0xEA],    #Manifest
        [0x2014,  0x85],    #Manifest
        [0x2015,  0x9C],    #Manifest
        [0x2016,  0x42],    #Manifest
        [0x2017,  0x82],    #Manifest
        [0x2018,  0x02],    #Manifest
        [0x2019,  0xD2],    #Manifest
        [0x201A,  0x30],    #Manifest
        [0x201B,  0x82],    #Manifest
        [0x201C,  0x02],    #Manifest
        [0x201D,  0xCE],    #Manifest
        [0x201E,  0x16],    #Manifest
        [0x201F,  0x04],    #Manifest
        [0x2020,  0x4D],    #Manifest
        [0x2021,  0x41],    #Manifest
        [0x2022,  0x4E],    #Manifest
        [0x2023,  0x42],    #Manifest
        [0x2024,  0x31],    #Manifest
        [0x2025,  0x82],    #Manifest
        [0x2026,  0x02],    #Manifest
        [0x2027,  0xC4],    #Manifest
        [0x2028,  0xFF],    #Manifest
        [0x2029,  0x84],    #Manifest
        [0x202A,  0xEA],    #Manifest
        [0x202B,  0x85],    #Manifest
        [0x202C,  0x9C],    #Manifest
        [0x202D,  0x50],    #Manifest
        [0x202E,  0x82],    #Manifest
        [0x202F,  0x01],    #Manifest
        [0x2030,  0x20],    #Manifest
        [0x2031,  0x30],    #Manifest
        [0x2032,  0x82],    #Manifest
        [0x2033,  0x01],    #Manifest
        [0x2034,  0x1C],    #Manifest
        [0x2035,  0x16],    #Manifest
        [0x2036,  0x04],    #Manifest
        [0x2037,  0x4D],    #Manifest
        [0x2038,  0x41],    #Manifest
        [0x2039,  0x4E],    #Manifest
        [0x203A,  0x50],    #Manifest
        [0x203B,  0x31],    #Manifest
        [0x203C,  0x82],    #Manifest
        [0x203D,  0x01],    #Manifest
        [0x203E,  0x12],    #Manifest
        [0x203F,  0xFF],    #Manifest
        [0x2040,  0x86],    #Manifest
        [0x2041,  0xB3],    #Manifest
        [0x2042,  0xC9],    #Manifest
        [0x2043,  0xC6],    #Manifest
        [0x2044,  0x61],    #Manifest
        [0x2045,  0x4A],    #Manifest
        [0x2046,  0x30],    #Manifest
        [0x2047,  0x48],    #Manifest
        [0x2048,  0x16],    #Manifest
        [0x2049,  0x04],    #Manifest
        [0x204A,  0x66],    #Manifest
        [0x204B,  0x72],    #Manifest
        [0x204C,  0x63],    #Manifest
        [0x204D,  0x61],    #Manifest
        [0x204E,  0x04],    #Manifest
        [0x204F,  0x40],    #Manifest
        [0x2050,  0x00],    #Manifest
        [0x2051,  0x00],    #Manifest
        [0x2052,  0x00],    #Manifest
        [0x2053,  0x00],    #Manifest
        [0x2054,  0x00],    #Manifest
        [0x2055,  0x00],    #Manifest
        [0x2056,  0x00],    #Manifest
        [0x2057,  0x00],    #Manifest
        [0x2058,  0x00],    #Manifest
        [0x2059,  0x00],    #Manifest
        [0x205A,  0x00],    #Manifest
        [0x205B,  0x00],    #Manifest
        [0x205C,  0x00],    #Manifest
        [0x205D,  0x00],    #Manifest
        [0x205E,  0x00],    #Manifest
        [0x205F,  0x00],    #Manifest
        [0x2060,  0x00],    #Manifest
        [0x2061,  0x00],    #Manifest
        [0x2062,  0x00],    #Manifest
        [0x2063,  0x00],    #Manifest
        [0x2064,  0x00],    #Manifest
        [0x2065,  0x00],    #Manifest
        [0x2066,  0x00],    #Manifest
        [0x2067,  0x00],    #Manifest
        [0x2068,  0x00],    #Manifest
        [0x2069,  0x00],    #Manifest
        [0x206A,  0x00],    #Manifest
        [0x206B,  0x00],    #Manifest
        [0x206C,  0x00],    #Manifest
        [0x206D,  0x00],    #Manifest
        [0x206E,  0x00],    #Manifest
        [0x206F,  0x00],    #Manifest
        [0x2070,  0x00],    #Manifest
        [0x2071,  0x00],    #Manifest
        [0x2072,  0x00],    #Manifest
        [0x2073,  0x00],    #Manifest
        [0x2074,  0x00],    #Manifest
        [0x2075,  0x00],    #Manifest
        [0x2076,  0x00],    #Manifest
        [0x2077,  0x00],    #Manifest
        [0x2078,  0x00],    #Manifest
        [0x2079,  0x00],    #Manifest
        [0x207A,  0x00],    #Manifest
        [0x207B,  0x00],    #Manifest
        [0x207C,  0x00],    #Manifest
        [0x207D,  0x00],    #Manifest
        [0x207E,  0x00],    #Manifest
        [0x207F,  0x00],    #Manifest
        [0x2080,  0x00],    #Manifest
        [0x2081,  0x00],    #Manifest
        [0x2082,  0x00],    #Manifest
        [0x2083,  0x00],    #Manifest
        [0x2084,  0x00],    #Manifest
        [0x2085,  0x00],    #Manifest
        [0x2086,  0x00],    #Manifest
        [0x2087,  0x00],    #Manifest
        [0x2088,  0x00],    #Manifest
        [0x2089,  0x00],    #Manifest
        [0x208A,  0x00],    #Manifest
        [0x208B,  0x00],    #Manifest
        [0x208C,  0x00],    #Manifest
        [0x208D,  0x00],    #Manifest
        [0x208E,  0x00],    #Manifest
        [0x208F,  0x00],    #Manifest
        [0x2090,  0xFF],    #Manifest
        [0x2091,  0x86],    #Manifest
        [0x2092,  0xFB],    #Manifest
        [0x2093,  0xB1],    #Manifest
        [0x2094,  0xC4],    #Manifest
        [0x2095,  0x74],    #Manifest
        [0x2096,  0x0B],    #Manifest
        [0x2097,  0x30],    #Manifest
        [0x2098,  0x09],    #Manifest
        [0x2099,  0x16],    #Manifest
        [0x209A,  0x04],    #Manifest
        [0x209B,  0x6F],    #Manifest
        [0x209C,  0x6C],    #Manifest
        [0x209D,  0x62],    #Manifest
        [0x209E,  0x74],    #Manifest
        [0x209F,  0x01],    #Manifest
        [0x20A0,  0x01],    #Manifest
        [0x20A1,  0xFF],    #Manifest
        [0x20A2,  0xFF],    #Manifest
        [0x20A3,  0x87],    #Manifest
        [0x20A4,  0x83],    #Manifest
        [0x20A5,  0x95],    #Manifest
        [0x20A6,  0xE0],    #Manifest
        [0x20A7,  0x6F],    #Manifest
        [0x20A8,  0x0B],    #Manifest
        [0x20A9,  0x30],    #Manifest
        [0x20AA,  0x09],    #Manifest
        [0x20AB,  0x16],    #Manifest
        [0x20AC,  0x04],    #Manifest
        [0x20AD,  0x70],    #Manifest
        [0x20AE,  0x65],    #Manifest
        [0x20AF,  0x70],    #Manifest
        [0x20B0,  0x6F],    #Manifest
        [0x20B1,  0x02],    #Manifest
        [0x20B2,  0x01],    #Manifest
        [0x20B3,  0x00],    #Manifest
        [0x20B4,  0xFF],    #Manifest
        [0x20B5,  0x87],    #Manifest
        [0x20B6,  0x83],    #Manifest
        [0x20B7,  0xC9],    #Manifest
        [0x20B8,  0xDE],    #Manifest
        [0x20B9,  0x76],    #Manifest
        [0x20BA,  0x0B],    #Manifest
        [0x20BB,  0x30],    #Manifest
        [0x20BC,  0x09],    #Manifest
        [0x20BD,  0x16],    #Manifest
        [0x20BE,  0x04],    #Manifest
        [0x20BF,  0x70],    #Manifest
        [0x20C0,  0x72],    #Manifest
        [0x20C1,  0x6F],    #Manifest
        [0x20C2,  0x76],    #Manifest
        [0x20C3,  0x01],    #Manifest
        [0x20C4,  0x01],    #Manifest
        [0x20C5,  0xFF],    #Manifest
        [0x20C6,  0xFF],    #Manifest
        [0x20C7,  0x87],    #Manifest
        [0x20C8,  0xCB],    #Manifest
        [0x20C9,  0x89],    #Manifest
        [0x20CA,  0xE4],    #Manifest
        [0x20CB,  0x64],    #Manifest
        [0x20CC,  0x0B],    #Manifest
        [0x20CD,  0x30],    #Manifest
        [0x20CE,  0x09],    #Manifest
        [0x20CF,  0x16],    #Manifest
        [0x20D0,  0x04],    #Manifest
        [0x20D1,  0x79],    #Manifest
        [0x20D2,  0x62],    #Manifest
        [0x20D3,  0x72],    #Manifest
        [0x20D4,  0x64],    #Manifest
        [0x20D5,  0x02],    #Manifest
        [0x20D6,  0x01],    #Manifest
        [0x20D7,  0x00],    #Manifest
        [0x20D8,  0xFF],    #Manifest
        [0x20D9,  0x87],    #Manifest
        [0x20DA,  0xCB],    #Manifest
        [0x20DB,  0x8D],    #Manifest
        [0x20DC,  0xD2],    #Manifest
        [0x20DD,  0x64],    #Manifest
        [0x20DE,  0x0C],    #Manifest
        [0x20DF,  0x30],    #Manifest
        [0x20E0,  0x0A],    #Manifest
        [0x20E1,  0x16],    #Manifest
        [0x20E2,  0x04],    #Manifest
        [0x20E3,  0x79],    #Manifest
        [0x20E4,  0x63],    #Manifest
        [0x20E5,  0x69],    #Manifest
        [0x20E6,  0x64],    #Manifest
        [0x20E7,  0x02],    #Manifest
        [0x20E8,  0x02],    #Manifest
        [0x20E9,  0x05],    #Manifest
        [0x20EA,  0x73],    #Manifest
        [0x20EB,  0xFF],    #Manifest
        [0x20EC,  0x87],    #Manifest
        [0x20ED,  0xCB],    #Manifest
        [0x20EE,  0x95],    #Manifest
        [0x20EF,  0xD2],    #Manifest
        [0x20F0,  0x64],    #Manifest
        [0x20F1,  0x1A],    #Manifest
        [0x20F2,  0x30],    #Manifest
        [0x20F3,  0x18],    #Manifest
        [0x20F4,  0x16],    #Manifest
        [0x20F5,  0x04],    #Manifest
        [0x20F6,  0x79],    #Manifest
        [0x20F7,  0x65],    #Manifest
        [0x20F8,  0x69],    #Manifest
        [0x20F9,  0x64],    #Manifest
        [0x20FA,  0x04],    #Manifest
        [0x20FB,  0x10],    #Manifest
        [0x20FC,  0x00],    #Manifest
        [0x20FD,  0x00],    #Manifest
        [0x20FE,  0x00],    #Manifest
        [0x20FF,  0x00],    #Manifest
        [0x2100,  0x00],    #Manifest
        [0x2101,  0x00],    #Manifest
        [0x2102,  0x00],    #Manifest
        [0x2103,  0x00],    #Manifest
        [0x2104,  0x00],    #Manifest
        [0x2105,  0x00],    #Manifest
        [0x2106,  0x00],    #Manifest
        [0x2107,  0x00],    #Manifest
        [0x2108,  0x00],    #Manifest
        [0x2109,  0x00],    #Manifest
        [0x210A,  0x00],    #Manifest
        [0x210B,  0x00],    #Manifest
        [0x210C,  0xFF],    #Manifest
        [0x210D,  0x87],    #Manifest
        [0x210E,  0xCB],    #Manifest
        [0x210F,  0x95],    #Manifest
        [0x2110,  0xE0],    #Manifest
        [0x2111,  0x6F],    #Manifest
        [0x2112,  0x0B],    #Manifest
        [0x2113,  0x30],    #Manifest
        [0x2114,  0x09],    #Manifest
        [0x2115,  0x16],    #Manifest
        [0x2116,  0x04],    #Manifest
        [0x2117,  0x79],    #Manifest
        [0x2118,  0x65],    #Manifest
        [0x2119,  0x70],    #Manifest
        [0x211A,  0x6F],    #Manifest
        [0x211B,  0x02],    #Manifest
        [0x211C,  0x01],    #Manifest
        [0x211D,  0x00],    #Manifest
        [0x211E,  0xFF],    #Manifest
        [0x211F,  0x87],    #Manifest
        [0x2120,  0xCB],    #Manifest
        [0x2121,  0xB9],    #Manifest
        [0x2122,  0xDE],    #Manifest
        [0x2123,  0x6E],    #Manifest
        [0x2124,  0x1A],    #Manifest
        [0x2125,  0x30],    #Manifest
        [0x2126,  0x18],    #Manifest
        [0x2127,  0x16],    #Manifest
        [0x2128,  0x04],    #Manifest
        [0x2129,  0x79],    #Manifest
        [0x212A,  0x6E],    #Manifest
        [0x212B,  0x6F],    #Manifest
        [0x212C,  0x6E],    #Manifest
        [0x212D,  0x04],    #Manifest
        [0x212E,  0x10],    #Manifest
        [0x212F,  0x00],    #Manifest
        [0x2130,  0x00],    #Manifest
        [0x2131,  0x00],    #Manifest
        [0x2132,  0x00],    #Manifest
        [0x2133,  0x00],    #Manifest
        [0x2134,  0x00],    #Manifest
        [0x2135,  0x00],    #Manifest
        [0x2136,  0x00],    #Manifest
        [0x2137,  0x00],    #Manifest
        [0x2138,  0x00],    #Manifest
        [0x2139,  0x00],    #Manifest
        [0x213A,  0x00],    #Manifest
        [0x213B,  0x00],    #Manifest
        [0x213C,  0x00],    #Manifest
        [0x213D,  0x00],    #Manifest
        [0x213E,  0x00],    #Manifest
        [0x213F,  0xFF],    #Manifest
        [0x2140,  0x87],    #Manifest
        [0x2141,  0xCB],    #Manifest
        [0x2142,  0xC1],    #Manifest
        [0x2143,  0xE4],    #Manifest
        [0x2144,  0x6F],    #Manifest
        [0x2145,  0x0B],    #Manifest
        [0x2146,  0x30],    #Manifest
        [0x2147,  0x09],    #Manifest
        [0x2148,  0x16],    #Manifest
        [0x2149,  0x04],    #Manifest
        [0x214A,  0x79],    #Manifest
        [0x214B,  0x70],    #Manifest
        [0x214C,  0x72],    #Manifest
        [0x214D,  0x6F],    #Manifest
        [0x214E,  0x01],    #Manifest
        [0x214F,  0x01],    #Manifest
        [0x2150,  0x00],    #Manifest
        [0x2151,  0xFF],    #Manifest
        [0x2152,  0x87],    #Manifest
        [0x2153,  0xCB],    #Manifest
        [0x2154,  0xCD],    #Manifest
        [0x2155,  0xF2],    #Manifest
        [0x2156,  0x30],    #Manifest
        [0x2157,  0x5F],    #Manifest
        [0x2158,  0x30],    #Manifest
        [0x2159,  0x5D],    #Manifest
        [0x215A,  0x16],    #Manifest
        [0x215B,  0x04],    #Manifest
        [0x215C,  0x79],    #Manifest
        [0x215D,  0x73],    #Manifest
        [0x215E,  0x79],    #Manifest
        [0x215F,  0x30],    #Manifest
        [0x2160,  0x31],    #Manifest
        [0x2161,  0x55],    #Manifest
        [0x2162,  0xFF],    #Manifest
        [0x2163,  0x84],    #Manifest
        [0x2164,  0xA2],    #Manifest
        [0x2165,  0x9D],    #Manifest
        [0x2166,  0xA6],    #Manifest
        [0x2167,  0x54],    #Manifest
        [0x2168,  0x2A],    #Manifest
        [0x2169,  0x30],    #Manifest
        [0x216A,  0x28],    #Manifest
        [0x216B,  0x16],    #Manifest
        [0x216C,  0x04],    #Manifest
        [0x216D,  0x44],    #Manifest
        [0x216E,  0x47],    #Manifest
        [0x216F,  0x53],    #Manifest
        [0x2170,  0x54],    #Manifest
        [0x2171,  0x04],    #Manifest
        [0x2172,  0x20],    #Manifest
        [0x2173,  0xF6],    #Manifest
        [0x2174,  0x41],    #Manifest
        [0x2175,  0x7E],    #Manifest
        [0x2176,  0x2D],    #Manifest
        [0x2177,  0x44],    #Manifest
        [0x2178,  0xBA],    #Manifest
        [0x2179,  0xE1],    #Manifest
        [0x217A,  0x7F],    #Manifest
        [0x217B,  0x2E],    #Manifest
        [0x217C,  0x51],    #Manifest
        [0x217D,  0xC2],    #Manifest
        [0x217E,  0xED],    #Manifest
        [0x217F,  0x2D],    #Manifest
        [0x2180,  0xFF],    #Manifest
        [0x2181,  0x27],    #Manifest
        [0x2182,  0x8C],    #Manifest
        [0x2183,  0x48],    #Manifest
        [0x2184,  0xC9],    #Manifest
        [0x2185,  0x1C],    #Manifest
        [0x2186,  0xA0],    #Manifest
        [0x2187,  0x96],    #Manifest
        [0x2188,  0x45],    #Manifest
        [0x2189,  0x85],    #Manifest
        [0x218A,  0xD1],    #Manifest
        [0x218B,  0x7D],    #Manifest
        [0x218C,  0x47],    #Manifest
        [0x218D,  0xB8],    #Manifest
        [0x218E,  0x79],    #Manifest
        [0x218F,  0x40],    #Manifest
        [0x2190,  0xD2],    #Manifest
        [0x2191,  0x97],    #Manifest
        [0x2192,  0x64],    #Manifest
        [0x2193,  0xFF],    #Manifest
        [0x2194,  0x84],    #Manifest
        [0x2195,  0xAA],    #Manifest
        [0x2196,  0xC1],    #Manifest
        [0x2197,  0xA4],    #Manifest
        [0x2198,  0x4F],    #Manifest
        [0x2199,  0x0B],    #Manifest
        [0x219A,  0x30],    #Manifest
        [0x219B,  0x09],    #Manifest
        [0x219C,  0x16],    #Manifest
        [0x219D,  0x04],    #Manifest
        [0x219E,  0x45],    #Manifest
        [0x219F,  0x50],    #Manifest
        [0x21A0,  0x52],    #Manifest
        [0x21A1,  0x4F],    #Manifest
        [0x21A2,  0x01],    #Manifest
        [0x21A3,  0x01],    #Manifest
        [0x21A4,  0x00],    #Manifest
        [0x21A5,  0xFF],    #Manifest
        [0x21A6,  0x86],    #Manifest
        [0x21A7,  0xB3],    #Manifest
        [0x21A8,  0xC9],    #Manifest
        [0x21A9,  0xCA],    #Manifest
        [0x21AA,  0x76],    #Manifest
        [0x21AB,  0x0B],    #Manifest
        [0x21AC,  0x30],    #Manifest
        [0x21AD,  0x09],    #Manifest
        [0x21AE,  0x16],    #Manifest
        [0x21AF,  0x04],    #Manifest
        [0x21B0,  0x66],    #Manifest
        [0x21B1,  0x72],    #Manifest
        [0x21B2,  0x65],    #Manifest
        [0x21B3,  0x76],    #Manifest
        [0x21B4,  0x02],    #Manifest
        [0x21B5,  0x01],    #Manifest
        [0x21B6,  0x01],    #Manifest
        [0x21B7,  0xFF],    #Manifest
        [0x21B8,  0x87],    #Manifest
        [0x21B9,  0xCB],    #Manifest
        [0x21BA,  0xCD],    #Manifest
        [0x21BB,  0xF2],    #Manifest
        [0x21BC,  0x31],    #Manifest
        [0x21BD,  0x60],    #Manifest
        [0x21BE,  0x30],    #Manifest
        [0x21BF,  0x5E],    #Manifest
        [0x21C0,  0x16],    #Manifest
        [0x21C1,  0x04],    #Manifest
        [0x21C2,  0x79],    #Manifest
        [0x21C3,  0x73],    #Manifest
        [0x21C4,  0x79],    #Manifest
        [0x21C5,  0x31],    #Manifest
        [0x21C6,  0x31],    #Manifest
        [0x21C7,  0x56],    #Manifest
        [0x21C8,  0xFF],    #Manifest
        [0x21C9,  0x84],    #Manifest
        [0x21CA,  0xA2],    #Manifest
        [0x21CB,  0x9D],    #Manifest
        [0x21CC,  0xA6],    #Manifest
        [0x21CD,  0x54],    #Manifest
        [0x21CE,  0x2A],    #Manifest
        [0x21CF,  0x30],    #Manifest
        [0x21D0,  0x28],    #Manifest
        [0x21D1,  0x16],    #Manifest
        [0x21D2,  0x04],    #Manifest
        [0x21D3,  0x44],    #Manifest
        [0x21D4,  0x47],    #Manifest
        [0x21D5,  0x53],    #Manifest
        [0x21D6,  0x54],    #Manifest
        [0x21D7,  0x04],    #Manifest
        [0x21D8,  0x20],    #Manifest
        [0x21D9,  0xF6],    #Manifest
        [0x21DA,  0x41],    #Manifest
        [0x21DB,  0x7E],    #Manifest
        [0x21DC,  0x2D],    #Manifest
        [0x21DD,  0x44],    #Manifest
        [0x21DE,  0xBA],    #Manifest
        [0x21DF,  0xE1],    #Manifest
        [0x21E0,  0x7F],    #Manifest
        [0x21E1,  0x2E],    #Manifest
        [0x21E2,  0x51],    #Manifest
        [0x21E3,  0xC2],    #Manifest
        [0x21E4,  0xED],    #Manifest
        [0x21E5,  0x2D],    #Manifest
        [0x21E6,  0xFF],    #Manifest
        [0x21E7,  0x27],    #Manifest
        [0x21E8,  0x8C],    #Manifest
        [0x21E9,  0x48],    #Manifest
        [0x21EA,  0xC9],    #Manifest
        [0x21EB,  0x1C],    #Manifest
        [0x21EC,  0xA0],    #Manifest
        [0x21ED,  0x96],    #Manifest
        [0x21EE,  0x45],    #Manifest
        [0x21EF,  0x85],    #Manifest
        [0x21F0,  0xD1],    #Manifest
        [0x21F1,  0x7D],    #Manifest
        [0x21F2,  0x47],    #Manifest
        [0x21F3,  0xB8],    #Manifest
        [0x21F4,  0x79],    #Manifest
        [0x21F5,  0x40],    #Manifest
        [0x21F6,  0xD2],    #Manifest
        [0x21F7,  0x97],    #Manifest
        [0x21F8,  0x64],    #Manifest
        [0x21F9,  0xFF],    #Manifest
        [0x21FA,  0x84],    #Manifest
        [0x21FB,  0xAA],    #Manifest
        [0x21FC,  0xC1],    #Manifest
        [0x21FD,  0xA4],    #Manifest
        [0x21FE,  0x4F],    #Manifest
        [0x21FF,  0x0B],    #Manifest
        [0x2200,  0x30],    #Manifest
        [0x2201,  0x09],    #Manifest
        [0x2202,  0x16],    #Manifest
        [0x2203,  0x04],    #Manifest
        [0x2204,  0x45],    #Manifest
        [0x2205,  0x50],    #Manifest
        [0x2206,  0x52],    #Manifest
        [0x2207,  0x4F],    #Manifest
        [0x2208,  0x01],    #Manifest
        [0x2209,  0x01],    #Manifest
        [0x220A,  0x00],    #Manifest
        [0x220B,  0xFF],    #Manifest
        [0x220C,  0x86],    #Manifest
        [0x220D,  0xB3],    #Manifest
        [0x220E,  0xC9],    #Manifest
        [0x220F,  0xCA],    #Manifest
        [0x2210,  0x76],    #Manifest
        [0x2211,  0x0C],    #Manifest
        [0x2212,  0x30],    #Manifest
        [0x2213,  0x0A],    #Manifest
        [0x2214,  0x16],    #Manifest
        [0x2215,  0x04],    #Manifest
        [0x2216,  0x66],    #Manifest
        [0x2217,  0x72],    #Manifest
        [0x2218,  0x65],    #Manifest
        [0x2219,  0x76],    #Manifest
        [0x221A,  0x02],    #Manifest
        [0x221B,  0x02],    #Manifest
        [0x221C,  0x01],    #Manifest
        [0x221D,  0x01],    #Manifest
        [0x221E,  0xFF],    #Manifest
        [0x221F,  0x87],    #Manifest
        [0x2220,  0xCB],    #Manifest
        [0x2221,  0xCD],    #Manifest
        [0x2222,  0xF2],    #Manifest
        [0x2223,  0x32],    #Manifest
        [0x2224,  0x60],    #Manifest
        [0x2225,  0x30],    #Manifest
        [0x2226,  0x5E],    #Manifest
        [0x2227,  0x16],    #Manifest
        [0x2228,  0x04],    #Manifest
        [0x2229,  0x79],    #Manifest
        [0x222A,  0x73],    #Manifest
        [0x222B,  0x79],    #Manifest
        [0x222C,  0x32],    #Manifest
        [0x222D,  0x31],    #Manifest
        [0x222E,  0x56],    #Manifest
        [0x222F,  0xFF],    #Manifest
        [0x2230,  0x84],    #Manifest
        [0x2231,  0xA2],    #Manifest
        [0x2232,  0x9D],    #Manifest
        [0x2233,  0xA6],    #Manifest
        [0x2234,  0x54],    #Manifest
        [0x2235,  0x2A],    #Manifest
        [0x2236,  0x30],    #Manifest
        [0x2237,  0x28],    #Manifest
        [0x2238,  0x16],    #Manifest
        [0x2239,  0x04],    #Manifest
        [0x223A,  0x44],    #Manifest
        [0x223B,  0x47],    #Manifest
        [0x223C,  0x53],    #Manifest
        [0x223D,  0x54],    #Manifest
        [0x223E,  0x04],    #Manifest
        [0x223F,  0x20],    #Manifest
        [0x2240,  0xF6],    #Manifest
        [0x2241,  0x41],    #Manifest
        [0x2242,  0x7E],    #Manifest
        [0x2243,  0x2D],    #Manifest
        [0x2244,  0x44],    #Manifest
        [0x2245,  0xBA],    #Manifest
        [0x2246,  0xE1],    #Manifest
        [0x2247,  0x7F],    #Manifest
        [0x2248,  0x2E],    #Manifest
        [0x2249,  0x51],    #Manifest
        [0x224A,  0xC2],    #Manifest
        [0x224B,  0xED],    #Manifest
        [0x224C,  0x2D],    #Manifest
        [0x224D,  0xFF],    #Manifest
        [0x224E,  0x27],    #Manifest
        [0x224F,  0x8C],    #Manifest
        [0x2250,  0x48],    #Manifest
        [0x2251,  0xC9],    #Manifest
        [0x2252,  0x1C],    #Manifest
        [0x2253,  0xA0],    #Manifest
        [0x2254,  0x96],    #Manifest
        [0x2255,  0x45],    #Manifest
        [0x2256,  0x85],    #Manifest
        [0x2257,  0xD1],    #Manifest
        [0x2258,  0x7D],    #Manifest
        [0x2259,  0x47],    #Manifest
        [0x225A,  0xB8],    #Manifest
        [0x225B,  0x79],    #Manifest
        [0x225C,  0x40],    #Manifest
        [0x225D,  0xD2],    #Manifest
        [0x225E,  0x97],    #Manifest
        [0x225F,  0x64],    #Manifest
        [0x2260,  0xFF],    #Manifest
        [0x2261,  0x84],    #Manifest
        [0x2262,  0xAA],    #Manifest
        [0x2263,  0xC1],    #Manifest
        [0x2264,  0xA4],    #Manifest
        [0x2265,  0x4F],    #Manifest
        [0x2266,  0x0B],    #Manifest
        [0x2267,  0x30],    #Manifest
        [0x2268,  0x09],    #Manifest
        [0x2269,  0x16],    #Manifest
        [0x226A,  0x04],    #Manifest
        [0x226B,  0x45],    #Manifest
        [0x226C,  0x50],    #Manifest
        [0x226D,  0x52],    #Manifest
        [0x226E,  0x4F],    #Manifest
        [0x226F,  0x01],    #Manifest
        [0x2270,  0x01],    #Manifest
        [0x2271,  0x00],    #Manifest
        [0x2272,  0xFF],    #Manifest
        [0x2273,  0x86],    #Manifest
        [0x2274,  0xB3],    #Manifest
        [0x2275,  0xC9],    #Manifest
        [0x2276,  0xCA],    #Manifest
        [0x2277,  0x76],    #Manifest
        [0x2278,  0x0C],    #Manifest
        [0x2279,  0x30],    #Manifest
        [0x227A,  0x0A],    #Manifest
        [0x227B,  0x16],    #Manifest
        [0x227C,  0x04],    #Manifest
        [0x227D,  0x66],    #Manifest
        [0x227E,  0x72],    #Manifest
        [0x227F,  0x65],    #Manifest
        [0x2280,  0x76],    #Manifest
        [0x2281,  0x02],    #Manifest
        [0x2282,  0x02],    #Manifest
        [0x2283,  0x0A],    #Manifest
        [0x2284,  0x01],    #Manifest
        [0x2285,  0xFF],    #Manifest
        [0x2286,  0x87],    #Manifest
        [0x2287,  0xCB],    #Manifest
        [0x2288,  0xCD],    #Manifest
        [0x2289,  0xF2],    #Manifest
        [0x228A,  0x33],    #Manifest
        [0x228B,  0x60],    #Manifest
        [0x228C,  0x30],    #Manifest
        [0x228D,  0x5E],    #Manifest
        [0x228E,  0x16],    #Manifest
        [0x228F,  0x04],    #Manifest
        [0x2290,  0x79],    #Manifest
        [0x2291,  0x73],    #Manifest
        [0x2292,  0x79],    #Manifest
        [0x2293,  0x33],    #Manifest
        [0x2294,  0x31],    #Manifest
        [0x2295,  0x56],    #Manifest
        [0x2296,  0xFF],    #Manifest
        [0x2297,  0x84],    #Manifest
        [0x2298,  0xA2],    #Manifest
        [0x2299,  0x9D],    #Manifest
        [0x229A,  0xA6],    #Manifest
        [0x229B,  0x54],    #Manifest
        [0x229C,  0x2A],    #Manifest
        [0x229D,  0x30],    #Manifest
        [0x229E,  0x28],    #Manifest
        [0x229F,  0x16],    #Manifest
        [0x22A0,  0x04],    #Manifest
        [0x22A1,  0x44],    #Manifest
        [0x22A2,  0x47],    #Manifest
        [0x22A3,  0x53],    #Manifest
        [0x22A4,  0x54],    #Manifest
        [0x22A5,  0x04],    #Manifest
        [0x22A6,  0x20],    #Manifest
        [0x22A7,  0xF6],    #Manifest
        [0x22A8,  0x41],    #Manifest
        [0x22A9,  0x7E],    #Manifest
        [0x22AA,  0x2D],    #Manifest
        [0x22AB,  0x44],    #Manifest
        [0x22AC,  0xBA],    #Manifest
        [0x22AD,  0xE1],    #Manifest
        [0x22AE,  0x7F],    #Manifest
        [0x22AF,  0x2E],    #Manifest
        [0x22B0,  0x51],    #Manifest
        [0x22B1,  0xC2],    #Manifest
        [0x22B2,  0xED],    #Manifest
        [0x22B3,  0x2D],    #Manifest
        [0x22B4,  0xFF],    #Manifest
        [0x22B5,  0x27],    #Manifest
        [0x22B6,  0x8C],    #Manifest
        [0x22B7,  0x48],    #Manifest
        [0x22B8,  0xC9],    #Manifest
        [0x22B9,  0x1C],    #Manifest
        [0x22BA,  0xA0],    #Manifest
        [0x22BB,  0x96],    #Manifest
        [0x22BC,  0x45],    #Manifest
        [0x22BD,  0x85],    #Manifest
        [0x22BE,  0xD1],    #Manifest
        [0x22BF,  0x7D],    #Manifest
        [0x22C0,  0x47],    #Manifest
        [0x22C1,  0xB8],    #Manifest
        [0x22C2,  0x79],    #Manifest
        [0x22C3,  0x40],    #Manifest
        [0x22C4,  0xD2],    #Manifest
        [0x22C5,  0x97],    #Manifest
        [0x22C6,  0x64],    #Manifest
        [0x22C7,  0xFF],    #Manifest
        [0x22C8,  0x84],    #Manifest
        [0x22C9,  0xAA],    #Manifest
        [0x22CA,  0xC1],    #Manifest
        [0x22CB,  0xA4],    #Manifest
        [0x22CC,  0x4F],    #Manifest
        [0x22CD,  0x0B],    #Manifest
        [0x22CE,  0x30],    #Manifest
        [0x22CF,  0x09],    #Manifest
        [0x22D0,  0x16],    #Manifest
        [0x22D1,  0x04],    #Manifest
        [0x22D2,  0x45],    #Manifest
        [0x22D3,  0x50],    #Manifest
        [0x22D4,  0x52],    #Manifest
        [0x22D5,  0x4F],    #Manifest
        [0x22D6,  0x01],    #Manifest
        [0x22D7,  0x01],    #Manifest
        [0x22D8,  0x00],    #Manifest
        [0x22D9,  0xFF],    #Manifest
        [0x22DA,  0x86],    #Manifest
        [0x22DB,  0xB3],    #Manifest
        [0x22DC,  0xC9],    #Manifest
        [0x22DD,  0xCA],    #Manifest
        [0x22DE,  0x76],    #Manifest
        [0x22DF,  0x0C],    #Manifest
        [0x22E0,  0x30],    #Manifest
        [0x22E1,  0x0A],    #Manifest
        [0x22E2,  0x16],    #Manifest
        [0x22E3,  0x04],    #Manifest
        [0x22E4,  0x66],    #Manifest
        [0x22E5,  0x72],    #Manifest
        [0x22E6,  0x65],    #Manifest
        [0x22E7,  0x76],    #Manifest
        [0x22E8,  0x02],    #Manifest
        [0x22E9,  0x02],    #Manifest
        [0x22EA,  0x13],    #Manifest
        [0x22EB,  0x01],    #Manifest
        [0x22EC,  0x04],    #Manifest
        [0x22ED,  0x47],    #Manifest
        [0x22EE,  0x30],    #Manifest
        [0x22EF,  0x45],    #Manifest
        [0x22F0,  0x02],    #Manifest
        [0x22F1,  0x21],    #Manifest
        [0x22F2,  0x00],    #Manifest
        [0x22F3,  0xD5],    #Manifest
        [0x22F4,  0x48],    #Manifest
        [0x22F5,  0xFF],    #Manifest
        [0x22F6,  0x68],    #Manifest
        [0x22F7,  0xBB],    #Manifest
        [0x22F8,  0xD4],    #Manifest
        [0x22F9,  0x69],    #Manifest
        [0x22FA,  0x96],    #Manifest
        [0x22FB,  0xD4],    #Manifest
        [0x22FC,  0x15],    #Manifest
        [0x22FD,  0x6E],    #Manifest
        [0x22FE,  0x6E],    #Manifest
        [0x22FF,  0xF5],    #Manifest
        [0x2300,  0x94],    #Manifest
        [0x2301,  0x89],    #Manifest
        [0x2302,  0x62],    #Manifest
        [0x2303,  0x13],    #Manifest
        [0x2304,  0xE3],    #Manifest
        [0x2305,  0xAC],    #Manifest
        [0x2306,  0xA3],    #Manifest
        [0x2307,  0xAE],    #Manifest
        [0x2308,  0xF7],    #Manifest
        [0x2309,  0x7B],    #Manifest
        [0x230A,  0xF0],    #Manifest
        [0x230B,  0x67],    #Manifest
        [0x230C,  0xE5],    #Manifest
        [0x230D,  0x15],    #Manifest
        [0x230E,  0xC6],    #Manifest
        [0x230F,  0x06],    #Manifest
        [0x2310,  0x96],    #Manifest
        [0x2311,  0xB8],    #Manifest
        [0x2312,  0x6D],    #Manifest
        [0x2313,  0x02],    #Manifest
        [0x2314,  0x20],    #Manifest
        [0x2315,  0x27],    #Manifest
        [0x2316,  0x21],    #Manifest
        [0x2317,  0x57],    #Manifest
        [0x2318,  0xD7],    #Manifest
        [0x2319,  0x72],    #Manifest
        [0x231A,  0x11],    #Manifest
        [0x231B,  0xA0],    #Manifest
        [0x231C,  0x92],    #Manifest
        [0x231D,  0x31],    #Manifest
        [0x231E,  0x4E],    #Manifest
        [0x231F,  0x64],    #Manifest
        [0x2320,  0xE4],    #Manifest
        [0x2321,  0xF2],    #Manifest
        [0x2322,  0xC2],    #Manifest
        [0x2323,  0x0C],    #Manifest
        [0x2324,  0x49],    #Manifest
        [0x2325,  0x9B],    #Manifest
        [0x2326,  0xD9],    #Manifest
        [0x2327,  0xFD],    #Manifest
        [0x2328,  0x4E],    #Manifest
        [0x2329,  0x47],    #Manifest
        [0x232A,  0x0C],    #Manifest
        [0x232B,  0x8A],    #Manifest
        [0x232C,  0x1D],    #Manifest
        [0x232D,  0xF4],    #Manifest
        [0x232E,  0x5D],    #Manifest
        [0x232F,  0xEC],    #Manifest
        [0x2330,  0x81],    #Manifest
        [0x2331,  0xA6],    #Manifest
        [0x2332,  0xAD],    #Manifest
        [0x2333,  0x54],    #Manifest
        [0x2334,  0xD0],    #Manifest
        [0x2335,  0x30],    #Manifest
        [0x2336,  0x82],    #Manifest
        [0x2337,  0x01],    #Manifest
        [0x2338,  0x99],    #Manifest
        [0x2339,  0x30],    #Manifest
        [0x233A,  0x82],    #Manifest
        [0x233B,  0x01],    #Manifest
        [0x233C,  0x95],    #Manifest
        [0x233D,  0x16],    #Manifest
        [0x233E,  0x04],    #Manifest
        [0x233F,  0x49],    #Manifest
        [0x2340,  0x4D],    #Manifest
        [0x2341,  0x34],    #Manifest
        [0x2342,  0x43],    #Manifest
        [0x2343,  0x02],    #Manifest
        [0x2344,  0x01],    #Manifest
        [0x2345,  0x00],    #Manifest
        [0x2346,  0x31],    #Manifest
        [0x2347,  0x82],    #Manifest
        [0x2348,  0x01],    #Manifest
        [0x2349,  0x3E],    #Manifest
        [0x234A,  0xFF],    #Manifest
        [0x234B,  0x84],    #Manifest
        [0x234C,  0x9A],    #Manifest
        [0x234D,  0xC9],    #Manifest
        [0x234E,  0xA8],    #Manifest
        [0x234F,  0x50],    #Manifest
        [0x2350,  0x81],    #Manifest
        [0x2351,  0xED],    #Manifest
        [0x2352,  0x30],    #Manifest
        [0x2353,  0x81],    #Manifest
        [0x2354,  0xEA],    #Manifest
        [0x2355,  0x16],    #Manifest
        [0x2356,  0x04],    #Manifest
        [0x2357,  0x43],    #Manifest
        [0x2358,  0x52],    #Manifest
        [0x2359,  0x54],    #Manifest
        [0x235A,  0x50],    #Manifest
        [0x235B,  0x31],    #Manifest
        [0x235C,  0x81],    #Manifest
        [0x235D,  0xE1],    #Manifest
        [0x235E,  0xFF],    #Manifest
        [0x235F,  0x84],    #Manifest
        [0x2360,  0xEA],    #Manifest
        [0x2361,  0x85],    #Manifest
        [0x2362,  0x9C],    #Manifest
        [0x2363,  0x50],    #Manifest
        [0x2364,  0x81],    #Manifest
        [0x2365,  0x8F],    #Manifest
        [0x2366,  0x30],    #Manifest
        [0x2367,  0x81],    #Manifest
        [0x2368,  0x8C],    #Manifest
        [0x2369,  0x16],    #Manifest
        [0x236A,  0x04],    #Manifest
        [0x236B,  0x4D],    #Manifest
        [0x236C,  0x41],    #Manifest
        [0x236D,  0x4E],    #Manifest
        [0x236E,  0x50],    #Manifest
        [0x236F,  0x31],    #Manifest
        [0x2370,  0x81],    #Manifest
        [0x2371,  0x83],    #Manifest
        [0x2372,  0xFF],    #Manifest
        [0x2373,  0x87],    #Manifest
        [0x2374,  0x83],    #Manifest
        [0x2375,  0x95],    #Manifest
        [0x2376,  0xE0],    #Manifest
        [0x2377,  0x6F],    #Manifest
        [0x2378,  0x0C],    #Manifest
        [0x2379,  0x30],    #Manifest
        [0x237A,  0x0A],    #Manifest
        [0x237B,  0x16],    #Manifest
        [0x237C,  0x04],    #Manifest
        [0x237D,  0x70],    #Manifest
        [0x237E,  0x65],    #Manifest
        [0x237F,  0x70],    #Manifest
        [0x2380,  0x6F],    #Manifest
        [0x2381,  0xA0],    #Manifest
        [0x2382,  0x02],    #Manifest
        [0x2383,  0x05],    #Manifest
        [0x2384,  0x00],    #Manifest
        [0x2385,  0xFF],    #Manifest
        [0x2386,  0x87],    #Manifest
        [0x2387,  0xCB],    #Manifest
        [0x2388,  0x89],    #Manifest
        [0x2389,  0xE4],    #Manifest
        [0x238A,  0x64],    #Manifest
        [0x238B,  0x0C],    #Manifest
        [0x238C,  0x30],    #Manifest
        [0x238D,  0x0A],    #Manifest
        [0x238E,  0x16],    #Manifest
        [0x238F,  0x04],    #Manifest
        [0x2390,  0x79],    #Manifest
        [0x2391,  0x62],    #Manifest
        [0x2392,  0x72],    #Manifest
        [0x2393,  0x64],    #Manifest
        [0x2394,  0xA0],    #Manifest
        [0x2395,  0x02],    #Manifest
        [0x2396,  0x05],    #Manifest
        [0x2397,  0x00],    #Manifest
        [0x2398,  0xFF],    #Manifest
        [0x2399,  0x87],    #Manifest
        [0x239A,  0xCB],    #Manifest
        [0x239B,  0x8D],    #Manifest
        [0x239C,  0xD2],    #Manifest
        [0x239D,  0x64],    #Manifest
        [0x239E,  0x0C],    #Manifest
        [0x239F,  0x30],    #Manifest
        [0x23A0,  0x0A],    #Manifest
        [0x23A1,  0x16],    #Manifest
        [0x23A2,  0x04],    #Manifest
        [0x23A3,  0x79],    #Manifest
        [0x23A4,  0x63],    #Manifest
        [0x23A5,  0x69],    #Manifest
        [0x23A6,  0x64],    #Manifest
        [0x23A7,  0x02],    #Manifest
        [0x23A8,  0x02],    #Manifest
        [0x23A9,  0x05],    #Manifest
        [0x23AA,  0x73],    #Manifest
        [0x23AB,  0xFF],    #Manifest
        [0x23AC,  0x87],    #Manifest
        [0x23AD,  0xCB],    #Manifest
        [0x23AE,  0x95],    #Manifest
        [0x23AF,  0xD2],    #Manifest
        [0x23B0,  0x64],    #Manifest
        [0x23B1,  0x0C],    #Manifest
        [0x23B2,  0x30],    #Manifest
        [0x23B3,  0x0A],    #Manifest
        [0x23B4,  0x16],    #Manifest
        [0x23B5,  0x04],    #Manifest
        [0x23B6,  0x79],    #Manifest
        [0x23B7,  0x65],    #Manifest
        [0x23B8,  0x69],    #Manifest
        [0x23B9,  0x64],    #Manifest
        [0x23BA,  0xA0],    #Manifest
        [0x23BB,  0x02],    #Manifest
        [0x23BC,  0x05],    #Manifest
        [0x23BD,  0x00],    #Manifest
        [0x23BE,  0xFF],    #Manifest
        [0x23BF,  0x87],    #Manifest
        [0x23C0,  0xCB],    #Manifest
        [0x23C1,  0x95],    #Manifest
        [0x23C2,  0xE0],    #Manifest
        [0x23C3,  0x6F],    #Manifest
        [0x23C4,  0x0B],    #Manifest
        [0x23C5,  0x30],    #Manifest
        [0x23C6,  0x09],    #Manifest
        [0x23C7,  0x16],    #Manifest
        [0x23C8,  0x04],    #Manifest
        [0x23C9,  0x79],    #Manifest
        [0x23CA,  0x65],    #Manifest
        [0x23CB,  0x70],    #Manifest
        [0x23CC,  0x6F],    #Manifest
        [0x23CD,  0x02],    #Manifest
        [0x23CE,  0x01],    #Manifest
        [0x23CF,  0x00],    #Manifest
        [0x23D0,  0xFF],    #Manifest
        [0x23D1,  0x87],    #Manifest
        [0x23D2,  0xCB],    #Manifest
        [0x23D3,  0xB9],    #Manifest
        [0x23D4,  0xDE],    #Manifest
        [0x23D5,  0x6E],    #Manifest
        [0x23D6,  0x0C],    #Manifest
        [0x23D7,  0x30],    #Manifest
        [0x23D8,  0x0A],    #Manifest
        [0x23D9,  0x16],    #Manifest
        [0x23DA,  0x04],    #Manifest
        [0x23DB,  0x79],    #Manifest
        [0x23DC,  0x6E],    #Manifest
        [0x23DD,  0x6F],    #Manifest
        [0x23DE,  0x6E],    #Manifest
        [0x23DF,  0xA0],    #Manifest
        [0x23E0,  0x02],    #Manifest
        [0x23E1,  0x05],    #Manifest
        [0x23E2,  0x00],    #Manifest
        [0x23E3,  0xFF],    #Manifest
        [0x23E4,  0x87],    #Manifest
        [0x23E5,  0xCB],    #Manifest
        [0x23E6,  0xC1],    #Manifest
        [0x23E7,  0xE4],    #Manifest
        [0x23E8,  0x6F],    #Manifest
        [0x23E9,  0x0B],    #Manifest
        [0x23EA,  0x30],    #Manifest
        [0x23EB,  0x09],    #Manifest
        [0x23EC,  0x16],    #Manifest
        [0x23ED,  0x04],    #Manifest
        [0x23EE,  0x79],    #Manifest
        [0x23EF,  0x70],    #Manifest
        [0x23F0,  0x72],    #Manifest
        [0x23F1,  0x6F],    #Manifest
        [0x23F2,  0x01],    #Manifest
        [0x23F3,  0x01],    #Manifest
        [0x23F4,  0x00],    #Manifest
        [0x23F5,  0xFF],    #Manifest
        [0x23F6,  0x84],    #Manifest
        [0x23F7,  0xFA],    #Manifest
        [0x23F8,  0x89],    #Manifest
        [0x23F9,  0x94],    #Manifest
        [0x23FA,  0x50],    #Manifest
        [0x23FB,  0x43],    #Manifest
        [0x23FC,  0x30],    #Manifest
        [0x23FD,  0x41],    #Manifest
        [0x23FE,  0x16],    #Manifest
        [0x23FF,  0x04],    #Manifest
        [0x2400,  0x4F],    #Manifest
        [0x2401,  0x42],    #Manifest
        [0x2402,  0x4A],    #Manifest
        [0x2403,  0x50],    #Manifest
        [0x2404,  0x31],    #Manifest
        [0x2405,  0x39],    #Manifest
        [0x2406,  0xFF],    #Manifest
        [0x2407,  0x84],    #Manifest
        [0x2408,  0xA2],    #Manifest
        [0x2409,  0x9D],    #Manifest
        [0x240A,  0xA6],    #Manifest
        [0x240B,  0x54],    #Manifest
        [0x240C,  0x0C],    #Manifest
        [0x240D,  0x30],    #Manifest
        [0x240E,  0x0A],    #Manifest
        [0x240F,  0x16],    #Manifest
        [0x2410,  0x04],    #Manifest
        [0x2411,  0x44],    #Manifest
        [0x2412,  0x47],    #Manifest
        [0x2413,  0x53],    #Manifest
        [0x2414,  0x54],    #Manifest
        [0x2415,  0xA0],    #Manifest
        [0x2416,  0x02],    #Manifest
        [0x2417,  0x05],    #Manifest
        [0x2418,  0x00],    #Manifest
        [0x2419,  0xFF],    #Manifest
        [0x241A,  0x84],    #Manifest
        [0x241B,  0xAA],    #Manifest
        [0x241C,  0xC1],    #Manifest
        [0x241D,  0xA4],    #Manifest
        [0x241E,  0x4F],    #Manifest
        [0x241F,  0x0C],    #Manifest
        [0x2420,  0x30],    #Manifest
        [0x2421,  0x0A],    #Manifest
        [0x2422,  0x16],    #Manifest
        [0x2423,  0x04],    #Manifest
        [0x2424,  0x45],    #Manifest
        [0x2425,  0x50],    #Manifest
        [0x2426,  0x52],    #Manifest
        [0x2427,  0x4F],    #Manifest
        [0x2428,  0xA0],    #Manifest
        [0x2429,  0x02],    #Manifest
        [0x242A,  0x05],    #Manifest
        [0x242B,  0x00],    #Manifest
        [0x242C,  0xFF],    #Manifest
        [0x242D,  0x86],    #Manifest
        [0x242E,  0xB3],    #Manifest
        [0x242F,  0xC9],    #Manifest
        [0x2430,  0xCA],    #Manifest
        [0x2431,  0x76],    #Manifest
        [0x2432,  0x0C],    #Manifest
        [0x2433,  0x30],    #Manifest
        [0x2434,  0x0A],    #Manifest
        [0x2435,  0x16],    #Manifest
        [0x2436,  0x04],    #Manifest
        [0x2437,  0x66],    #Manifest
        [0x2438,  0x72],    #Manifest
        [0x2439,  0x65],    #Manifest
        [0x243A,  0x76],    #Manifest
        [0x243B,  0xA0],    #Manifest
        [0x243C,  0x02],    #Manifest
        [0x243D,  0x05],    #Manifest
        [0x243E,  0x00],    #Manifest
        [0x243F,  0xFF],    #Manifest
        [0x2440,  0x85],    #Manifest
        [0x2441,  0x82],    #Manifest
        [0x2442,  0xD5],    #Manifest
        [0x2443,  0x84],    #Manifest
        [0x2444,  0x4B],    #Manifest
        [0x2445,  0x42],    #Manifest
        [0x2446,  0x04],    #Manifest
        [0x2447,  0x40],    #Manifest
        [0x2448,  0xAF],    #Manifest
        [0x2449,  0x4C],    #Manifest
        [0x244A,  0xE0],    #Manifest
        [0x244B,  0x0C],    #Manifest
        [0x244C,  0xC4],    #Manifest
        [0x244D,  0xAD],    #Manifest
        [0x244E,  0x1B],    #Manifest
        [0x244F,  0x21],    #Manifest
        [0x2450,  0x61],    #Manifest
        [0x2451,  0x1C],    #Manifest
        [0x2452,  0x00],    #Manifest
        [0x2453,  0x54],    #Manifest
        [0x2454,  0x6B],    #Manifest
        [0x2455,  0x0B],    #Manifest
        [0x2456,  0x12],    #Manifest
        [0x2457,  0xDA],    #Manifest
        [0x2458,  0xBF],    #Manifest
        [0x2459,  0x22],    #Manifest
        [0x245A,  0x72],    #Manifest
        [0x245B,  0x15],    #Manifest
        [0x245C,  0xDA],    #Manifest
        [0x245D,  0x8E],    #Manifest
        [0x245E,  0x52],    #Manifest
        [0x245F,  0x02],    #Manifest
        [0x2460,  0xAB],    #Manifest
        [0x2461,  0xD8],    #Manifest
        [0x2462,  0xB8],    #Manifest
        [0x2463,  0x13],    #Manifest
        [0x2464,  0x83],    #Manifest
        [0x2465,  0x12],    #Manifest
        [0x2466,  0xF1],    #Manifest
        [0x2467,  0xA0],    #Manifest
        [0x2468,  0xDB],    #Manifest
        [0x2469,  0xAD],    #Manifest
        [0x246A,  0x54],    #Manifest
        [0x246B,  0x88],    #Manifest
        [0x246C,  0xB6],    #Manifest
        [0x246D,  0x36],    #Manifest
        [0x246E,  0x95],    #Manifest
        [0x246F,  0x1E],    #Manifest
        [0x2470,  0x90],    #Manifest
        [0x2471,  0x2D],    #Manifest
        [0x2472,  0x9F],    #Manifest
        [0x2473,  0x6F],    #Manifest
        [0x2474,  0xE1],    #Manifest
        [0x2475,  0x03],    #Manifest
        [0x2476,  0x09],    #Manifest
        [0x2477,  0x41],    #Manifest
        [0x2478,  0xC0],    #Manifest
        [0x2479,  0xE5],    #Manifest
        [0x247A,  0x3C],    #Manifest
        [0x247B,  0xAC],    #Manifest
        [0x247C,  0x83],    #Manifest
        [0x247D,  0x2A],    #Manifest
        [0x247E,  0xD8],    #Manifest
        [0x247F,  0xDE],    #Manifest
        [0x2480,  0xCA],    #Manifest
        [0x2481,  0x58],    #Manifest
        [0x2482,  0x30],    #Manifest
        [0x2483,  0x9B],    #Manifest
        [0x2484,  0x89],    #Manifest
        [0x2485,  0x44],    #Manifest
        [0x2486,  0x9B],    #Manifest
        [0x2487,  0xA5],    #Manifest
        [0x2488,  0x04],    #Manifest
        [0x2489,  0x48],    #Manifest
        [0x248A,  0x30],    #Manifest
        [0x248B,  0x46],    #Manifest
        [0x248C,  0x02],    #Manifest
        [0x248D,  0x21],    #Manifest
        [0x248E,  0x00],    #Manifest
        [0x248F,  0xB4],    #Manifest
        [0x2490,  0xC7],    #Manifest
        [0x2491,  0x92],    #Manifest
        [0x2492,  0x95],    #Manifest
        [0x2493,  0xB0],    #Manifest
        [0x2494,  0xCA],    #Manifest
        [0x2495,  0x0B],    #Manifest
        [0x2496,  0xC2],    #Manifest
        [0x2497,  0xF2],    #Manifest
        [0x2498,  0x26],    #Manifest
        [0x2499,  0xF8],    #Manifest
        [0x249A,  0x8E],    #Manifest
        [0x249B,  0x9F],    #Manifest
        [0x249C,  0xDF],    #Manifest
        [0x249D,  0x60],    #Manifest
        [0x249E,  0x78],    #Manifest
        [0x249F,  0xC7],    #Manifest
        [0x24A0,  0xFF],    #Manifest
        [0x24A1,  0x99],    #Manifest
        [0x24A2,  0xA8],    #Manifest
        [0x24A3,  0xDD],    #Manifest
        [0x24A4,  0xFE],    #Manifest
        [0x24A5,  0x97],    #Manifest
        [0x24A6,  0x43],    #Manifest
        [0x24A7,  0x7C],    #Manifest
        [0x24A8,  0x08],    #Manifest
        [0x24A9,  0x80],    #Manifest
        [0x24AA,  0x95],    #Manifest
        [0x24AB,  0x27],    #Manifest
        [0x24AC,  0x10],    #Manifest
        [0x24AD,  0x9F],    #Manifest
        [0x24AE,  0x3A],    #Manifest
        [0x24AF,  0x02],    #Manifest
        [0x24B0,  0x21],    #Manifest
        [0x24B1,  0x00],    #Manifest
        [0x24B2,  0xC4],    #Manifest
        [0x24B3,  0x59],    #Manifest
        [0x24B4,  0xF0],    #Manifest
        [0x24B5,  0x34],    #Manifest
        [0x24B6,  0x88],    #Manifest
        [0x24B7,  0x42],    #Manifest
        [0x24B8,  0x01],    #Manifest
        [0x24B9,  0x7B],    #Manifest
        [0x24BA,  0x5B],    #Manifest
        [0x24BB,  0x84],    #Manifest
        [0x24BC,  0x88],    #Manifest
        [0x24BD,  0x56],    #Manifest
        [0x24BE,  0x9B],    #Manifest
        [0x24BF,  0xF2],    #Manifest
        [0x24C0,  0x53],    #Manifest
        [0x24C1,  0xD7],    #Manifest
        [0x24C2,  0x0F],    #Manifest
        [0x24C3,  0xF1],    #Manifest
        [0x24C4,  0x27],    #Manifest
        [0x24C5,  0xD1],    #Manifest
        [0x24C6,  0xC6],    #Manifest
        [0x24C7,  0x6E],    #Manifest
        [0x24C8,  0x86],    #Manifest
        [0x24C9,  0xC5],    #Manifest
        [0x24CA,  0xF8],    #Manifest
        [0x24CB,  0xE7],    #Manifest
        [0x24CC,  0xAF],    #Manifest
        [0x24CD,  0xC0],    #Manifest
        [0x24CE,  0x2C],    #Manifest
        [0x24CF,  0xF7],    #Manifest
        [0x24D0,  0xD1],    #Manifest
        [0x24D1,  0xBD]]   #Manifest

        for pair in manifest:
            try:
                self.i2cwrite(pair[0],pair[1])
            except:
                print("SPMI error, retrying...")
                self.i2cwrite(pair[0],pair[1])

    def applyPatch(self):
        print("Applying Patch")
        patch=[[ 0x24E0,  0x02],    #Patch
        [ 0x24E1,  0x00],    #Patch
        [ 0x24E2,  0x00],    #Patch
        [ 0x24E3,  0x00],    #Patch
        [ 0x24E4,  0x48],    #Patch
        [ 0x24E5,  0x00],    #Patch
        [ 0x24E6,  0x00],    #Patch
        [ 0x24E7,  0x00],    #Patch
        [ 0x24E8,  0x94],    #Patch
        [ 0x24E9,  0x06],    #Patch
        [ 0x24EA,  0x00],    #Patch
        [ 0x24EB,  0x00],    #Patch
        [ 0x24EC,  0x01],    #Patch
        [ 0x24ED,  0x00],    #Patch
        [ 0x24EE,  0x00],    #Patch
        [ 0x24EF,  0x00],    #Patch
        [ 0x24F0,  0x01],    #Patch
        [ 0x24F1,  0x00],    #Patch
        [ 0x24F2,  0x00],    #Patch
        [ 0x24F3,  0x00],    #Patch
        [ 0x24F4,  0x06],    #Patch
        [ 0x24F5,  0x00],    #Patch
        [ 0x24F6,  0x00],    #Patch
        [ 0x24F7,  0x00],    #Patch
        [ 0x24F8,  0x00],    #Patch
        [ 0x24F9,  0x00],    #Patch
        [ 0x24FA,  0x00],    #Patch
        [ 0x24FB,  0x00],    #Patch
        [ 0x24FC,  0x00],    #Patch
        [ 0x24FD,  0x00],    #Patch
        [ 0x24FE,  0x00],    #Patch
        [ 0x24FF,  0x00],    #Patch
        [ 0x2500,  0x00],    #Patch
        [ 0x2501,  0x00],    #Patch
        [ 0x2502,  0x00],    #Patch
        [ 0x2503,  0x00],    #Patch
        [ 0x2504,  0x00],    #Patch
        [ 0x2505,  0x00],    #Patch
        [ 0x2506,  0x00],    #Patch
        [ 0x2507,  0x00],    #Patch
        [ 0x2508,  0x00],    #Patch
        [ 0x2509,  0x00],    #Patch
        [ 0x250A,  0x00],    #Patch
        [ 0x250B,  0x00],    #Patch
        [ 0x250C,  0x00],    #Patch
        [ 0x250D,  0x00],    #Patch
        [ 0x250E,  0x00],    #Patch
        [ 0x250F,  0x00],    #Patch
        [ 0x2510,  0x00],    #Patch
        [ 0x2511,  0x00],    #Patch
        [ 0x2512,  0x00],    #Patch
        [ 0x2513,  0x00],    #Patch
        [ 0x2514,  0x00],    #Patch
        [ 0x2515,  0x00],    #Patch
        [ 0x2516,  0x00],    #Patch
        [ 0x2517,  0x00],    #Patch
        [ 0x2518,  0x00],    #Patch
        [ 0x2519,  0x00],    #Patch
        [ 0x251A,  0x00],    #Patch
        [ 0x251B,  0x00],    #Patch
        [ 0x251C,  0x10],    #Patch
        [ 0x251D,  0x00],    #Patch
        [ 0x251E,  0x00],    #Patch
        [ 0x251F,  0x10],    #Patch
        [ 0x2520,  0x00],    #Patch
        [ 0x2521,  0x00],    #Patch
        [ 0x2522,  0x00],    #Patch
        [ 0x2523,  0x00],    #Patch
        [ 0x2524,  0x10],    #Patch
        [ 0x2525,  0x01],    #Patch
        [ 0x2526,  0x00],    #Patch
        [ 0x2527,  0x10],    #Patch
        [ 0x2528,  0x49],    #Patch
        [ 0x2529,  0x53],    #Patch
        [ 0x252A,  0x50],    #Patch
        [ 0x252B,  0x46],    #Patch
        [ 0x252C,  0x20],    #Patch
        [ 0x252D,  0x00],    #Patch
        [ 0x252E,  0x00],    #Patch
        [ 0x252F,  0x00],    #Patch
        [ 0x2530,  0x01],    #Patch
        [ 0x2531,  0x00],    #Patch
        [ 0x2532,  0x00],    #Patch
        [ 0x2533,  0x00],    #Patch
        [ 0x2534,  0x01],    #Patch
        [ 0x2535,  0x00],    #Patch
        [ 0x2536,  0x00],    #Patch
        [ 0x2537,  0x00],    #Patch
        [ 0x2538,  0x20],    #Patch
        [ 0x2539,  0x00],    #Patch
        [ 0x253A,  0x00],    #Patch
        [ 0x253B,  0x00],    #Patch
        [ 0x253C,  0x01],    #Patch
        [ 0x253D,  0x00],    #Patch
        [ 0x253E,  0x00],    #Patch
        [ 0x253F,  0x00],    #Patch
        [ 0x2540,  0xA4],    #Patch
        [ 0x2541,  0x05],    #Patch
        [ 0x2542,  0x00],    #Patch
        [ 0x2543,  0x00],    #Patch
        [ 0x2544,  0x07],    #Patch
        [ 0x2545,  0x00],    #Patch
        [ 0x2546,  0x00],    #Patch
        [ 0x2547,  0x00],    #Patch
        [ 0x2548,  0x01],    #Patch
        [ 0x2549,  0x00],    #Patch
        [ 0x254A,  0x00],    #Patch
        [ 0x254B,  0x00],    #Patch
        [ 0x254C,  0x30],    #Patch
        [ 0x254D,  0x00],    #Patch
        [ 0x254E,  0x00],    #Patch
        [ 0x254F,  0x00],    #Patch
        [ 0x2550,  0x00],    #Patch
        [ 0x2551,  0x00],    #Patch
        [ 0x2552,  0x4C],    #Patch
        [ 0x2553,  0x00],    #Patch
        [ 0x2554,  0x74],    #Patch
        [ 0x2555,  0x05],    #Patch
        [ 0x2556,  0x00],    #Patch
        [ 0x2557,  0x00],    #Patch
        [ 0x2558,  0x2A],    #Patch
        [ 0x2559,  0x2B],    #Patch
        [ 0x255A,  0x2C],    #Patch
        [ 0x255B,  0x2C],    #Patch
        [ 0x255C,  0x2D],    #Patch
        [ 0x255D,  0x2E],    #Patch
        [ 0x255E,  0x2F],    #Patch
        [ 0x255F,  0x30],    #Patch
        [ 0x2560,  0x30],    #Patch
        [ 0x2561,  0x31],    #Patch
        [ 0x2562,  0x32],    #Patch
        [ 0x2563,  0x33],    #Patch
        [ 0x2564,  0x34],    #Patch
        [ 0x2565,  0x34],    #Patch
        [ 0x2566,  0x35],    #Patch
        [ 0x2567,  0x36],    #Patch
        [ 0x2568,  0x37],    #Patch
        [ 0x2569,  0x38],    #Patch
        [ 0x256A,  0x38],    #Patch
        [ 0x256B,  0x39],    #Patch
        [ 0x256C,  0x3A],    #Patch
        [ 0x256D,  0x3B],    #Patch
        [ 0x256E,  0x3C],    #Patch
        [ 0x256F,  0x3D],    #Patch
        [ 0x2570,  0x3D],    #Patch
        [ 0x2571,  0x3E],    #Patch
        [ 0x2572,  0x40],    #Patch
        [ 0x2573,  0x41],    #Patch
        [ 0x2574,  0x41],    #Patch
        [ 0x2575,  0x42],    #Patch
        [ 0x2576,  0x43],    #Patch
        [ 0x2577,  0x44],    #Patch
        [ 0x2578,  0x45],    #Patch
        [ 0x2579,  0x46],    #Patch
        [ 0x257A,  0x46],    #Patch
        [ 0x257B,  0x47],    #Patch
        [ 0x257C,  0x48],    #Patch
        [ 0x257D,  0x49],    #Patch
        [ 0x257E,  0x4A],    #Patch
        [ 0x257F,  0x4B],    #Patch
        [ 0x2580,  0x4B],    #Patch
        [ 0x2581,  0x4C],    #Patch
        [ 0x2582,  0x4D],    #Patch
        [ 0x2583,  0x4E],    #Patch
        [ 0x2584,  0x4F],    #Patch
        [ 0x2585,  0x50],    #Patch
        [ 0x2586,  0x50],    #Patch
        [ 0x2587,  0x51],    #Patch
        [ 0x2588,  0x52],    #Patch
        [ 0x2589,  0x53],    #Patch
        [ 0x258A,  0x54],    #Patch
        [ 0x258B,  0x54],    #Patch
        [ 0x258C,  0x01],    #Patch
        [ 0x258D,  0x03],    #Patch
        [ 0x258E,  0x04],    #Patch
        [ 0x258F,  0x05],    #Patch
        [ 0x2590,  0x06],    #Patch
        [ 0x2591,  0x08],    #Patch
        [ 0x2592,  0x09],    #Patch
        [ 0x2593,  0x0A],    #Patch
        [ 0x2594,  0x0B],    #Patch
        [ 0x2595,  0x0D],    #Patch
        [ 0x2596,  0x0E],    #Patch
        [ 0x2597,  0x0F],    #Patch
        [ 0x2598,  0x10],    #Patch
        [ 0x2599,  0x12],    #Patch
        [ 0x259A,  0x13],    #Patch
        [ 0x259B,  0x14],    #Patch
        [ 0x259C,  0x15],    #Patch
        [ 0x259D,  0x17],    #Patch
        [ 0x259E,  0x18],    #Patch
        [ 0x259F,  0x19],    #Patch
        [ 0x25A0,  0x1A],    #Patch
        [ 0x25A1,  0x1B],    #Patch
        [ 0x25A2,  0x1D],    #Patch
        [ 0x25A3,  0x1E],    #Patch
        [ 0x25A4,  0x1F],    #Patch
        [ 0x25A5,  0x21],    #Patch
        [ 0x25A6,  0x22],    #Patch
        [ 0x25A7,  0x23],    #Patch
        [ 0x25A8,  0x24],    #Patch
        [ 0x25A9,  0x26],    #Patch
        [ 0x25AA,  0x27],    #Patch
        [ 0x25AB,  0x28],    #Patch
        [ 0x25AC,  0x29],    #Patch
        [ 0x25AD,  0x2B],    #Patch
        [ 0x25AE,  0x2C],    #Patch
        [ 0x25AF,  0x2D],    #Patch
        [ 0x25B0,  0x2E],    #Patch
        [ 0x25B1,  0x30],    #Patch
        [ 0x25B2,  0x31],    #Patch
        [ 0x25B3,  0x32],    #Patch
        [ 0x25B4,  0x33],    #Patch
        [ 0x25B5,  0x34],    #Patch
        [ 0x25B6,  0x36],    #Patch
        [ 0x25B7,  0x37],    #Patch
        [ 0x25B8,  0x38],    #Patch
        [ 0x25B9,  0x39],    #Patch
        [ 0x25BA,  0x3A],    #Patch
        [ 0x25BB,  0x3C],    #Patch
        [ 0x25BC,  0x3D],    #Patch
        [ 0x25BD,  0x3E],    #Patch
        [ 0x25BE,  0x3F],    #Patch
        [ 0x25BF,  0x41],    #Patch
        [ 0x25C0,  0x42],    #Patch
        [ 0x25C1,  0x44],    #Patch
        [ 0x25C2,  0x45],    #Patch
        [ 0x25C3,  0x46],    #Patch
        [ 0x25C4,  0x47],    #Patch
        [ 0x25C5,  0x49],    #Patch
        [ 0x25C6,  0x4A],    #Patch
        [ 0x25C7,  0x4B],    #Patch
        [ 0x25C8,  0x4C],    #Patch
        [ 0x25C9,  0x4D],    #Patch
        [ 0x25CA,  0x4F],    #Patch
        [ 0x25CB,  0x50],    #Patch
        [ 0x25CC,  0x51],    #Patch
        [ 0x25CD,  0x52],    #Patch
        [ 0x25CE,  0x54],    #Patch
        [ 0x25CF,  0x55],    #Patch
        [ 0x25D0,  0x56],    #Patch
        [ 0x25D1,  0x57],    #Patch
        [ 0x25D2,  0x58],    #Patch
        [ 0x25D3,  0x5A],    #Patch
        [ 0x25D4,  0x5B],    #Patch
        [ 0x25D5,  0x04],    #Patch
        [ 0x25D6,  0x06],    #Patch
        [ 0x25D7,  0x08],    #Patch
        [ 0x25D8,  0x09],    #Patch
        [ 0x25D9,  0x0B],    #Patch
        [ 0x25DA,  0x0D],    #Patch
        [ 0x25DB,  0x0F],    #Patch
        [ 0x25DC,  0x11],    #Patch
        [ 0x25DD,  0x13],    #Patch
        [ 0x25DE,  0x15],    #Patch
        [ 0x25DF,  0x17],    #Patch
        [ 0x25E0,  0x19],    #Patch
        [ 0x25E1,  0x1A],    #Patch
        [ 0x25E2,  0x1C],    #Patch
        [ 0x25E3,  0x1E],    #Patch
        [ 0x25E4,  0x20],    #Patch
        [ 0x25E5,  0x22],    #Patch
        [ 0x25E6,  0x24],    #Patch
        [ 0x25E7,  0x26],    #Patch
        [ 0x25E8,  0x28],    #Patch
        [ 0x25E9,  0x2A],    #Patch
        [ 0x25EA,  0x2C],    #Patch
        [ 0x25EB,  0x2D],    #Patch
        [ 0x25EC,  0x2F],    #Patch
        [ 0x25ED,  0x31],    #Patch
        [ 0x25EE,  0x33],    #Patch
        [ 0x25EF,  0x35],    #Patch
        [ 0x25F0,  0x37],    #Patch
        [ 0x25F1,  0x39],    #Patch
        [ 0x25F2,  0x3B],    #Patch
        [ 0x25F3,  0x3D],    #Patch
        [ 0x25F4,  0x3F],    #Patch
        [ 0x25F5,  0x41],    #Patch
        [ 0x25F6,  0x43],    #Patch
        [ 0x25F7,  0x45],    #Patch
        [ 0x25F8,  0x47],    #Patch
        [ 0x25F9,  0x49],    #Patch
        [ 0x25FA,  0x4B],    #Patch
        [ 0x25FB,  0x4C],    #Patch
        [ 0x25FC,  0x4E],    #Patch
        [ 0x25FD,  0x50],    #Patch
        [ 0x25FE,  0x52],    #Patch
        [ 0x25FF,  0x54],    #Patch
        [ 0x2600,  0x55],    #Patch
        [ 0x2601,  0x57],    #Patch
        [ 0x2602,  0x5A],    #Patch
        [ 0x2603,  0x5B],    #Patch
        [ 0x2604,  0x5D],    #Patch
        [ 0x2605,  0x5F],    #Patch
        [ 0x2606,  0x62],    #Patch
        [ 0x2607,  0x63],    #Patch
        [ 0x2608,  0x65],    #Patch
        [ 0x2609,  0x67],    #Patch
        [ 0x260A,  0x69],    #Patch
        [ 0x260B,  0x6B],    #Patch
        [ 0x260C,  0x06],    #Patch
        [ 0x260D,  0x09],    #Patch
        [ 0x260E,  0x0C],    #Patch
        [ 0x260F,  0x10],    #Patch
        [ 0x2610,  0x13],    #Patch
        [ 0x2611,  0x16],    #Patch
        [ 0x2612,  0x19],    #Patch
        [ 0x2613,  0x1D],    #Patch
        [ 0x2614,  0x20],    #Patch
        [ 0x2615,  0x23],    #Patch
        [ 0x2616,  0x26],    #Patch
        [ 0x2617,  0x2A],    #Patch
        [ 0x2618,  0x2D],    #Patch
        [ 0x2619,  0x30],    #Patch
        [ 0x261A,  0x34],    #Patch
        [ 0x261B,  0x37],    #Patch
        [ 0x261C,  0x3A],    #Patch
        [ 0x261D,  0x3D],    #Patch
        [ 0x261E,  0x41],    #Patch
        [ 0x261F,  0x44],    #Patch
        [ 0x2620,  0x47],    #Patch
        [ 0x2621,  0x4B],    #Patch
        [ 0x2622,  0x4E],    #Patch
        [ 0x2623,  0x51],    #Patch
        [ 0x2624,  0x54],    #Patch
        [ 0x2625,  0x58],    #Patch
        [ 0x2626,  0x5B],    #Patch
        [ 0x2627,  0x5E],    #Patch
        [ 0x2628,  0x62],    #Patch
        [ 0x2629,  0x65],    #Patch
        [ 0x262A,  0x68],    #Patch
        [ 0x262B,  0x6B],    #Patch
        [ 0x262C,  0x6F],    #Patch
        [ 0x262D,  0x72],    #Patch
        [ 0x262E,  0x75],    #Patch
        [ 0x262F,  0x78],    #Patch
        [ 0x2630,  0x7C],    #Patch
        [ 0x2631,  0x7F],    #Patch
        [ 0x2632,  0x83],    #Patch
        [ 0x2633,  0x86],    #Patch
        [ 0x2634,  0x89],    #Patch
        [ 0x2635,  0x8C],    #Patch
        [ 0x2636,  0x06],    #Patch
        [ 0x2637,  0x0D],    #Patch
        [ 0x2638,  0x14],    #Patch
        [ 0x2639,  0x1B],    #Patch
        [ 0x263A,  0x23],    #Patch
        [ 0x263B,  0x2A],    #Patch
        [ 0x263C,  0x31],    #Patch
        [ 0x263D,  0x39],    #Patch
        [ 0x263E,  0x40],    #Patch
        [ 0x263F,  0x48],    #Patch
        [ 0x2640,  0x4F],    #Patch
        [ 0x2641,  0x56],    #Patch
        [ 0x2642,  0x5D],    #Patch
        [ 0x2643,  0x65],    #Patch
        [ 0x2644,  0x6C],    #Patch
        [ 0x2645,  0x73],    #Patch
        [ 0x2646,  0x7A],    #Patch
        [ 0x2647,  0x82],    #Patch
        [ 0x2648,  0x89],    #Patch
        [ 0x2649,  0x8F],    #Patch
        [ 0x264A,  0x97],    #Patch
        [ 0x264B,  0x9E],    #Patch
        [ 0x264C,  0xA6],    #Patch
        [ 0x264D,  0xAD],    #Patch
        [ 0x264E,  0xB5],    #Patch
        [ 0x264F,  0xBC],    #Patch
        [ 0x2650,  0xC4],    #Patch
        [ 0x2651,  0xCB],    #Patch
        [ 0x2652,  0xD3],    #Patch
        [ 0x2653,  0xDA],    #Patch
        [ 0x2654,  0xE2],    #Patch
        [ 0x2655,  0xE9],    #Patch
        [ 0x2656,  0xF1],    #Patch
        [ 0x2657,  0xF8],    #Patch
        [ 0x2658,  0x2B],    #Patch
        [ 0x2659,  0x2D],    #Patch
        [ 0x265A,  0x2E],    #Patch
        [ 0x265B,  0x2E],    #Patch
        [ 0x265C,  0x2F],    #Patch
        [ 0x265D,  0x30],    #Patch
        [ 0x265E,  0x31],    #Patch
        [ 0x265F,  0x32],    #Patch
        [ 0x2660,  0x33],    #Patch
        [ 0x2661,  0x33],    #Patch
        [ 0x2662,  0x34],    #Patch
        [ 0x2663,  0x35],    #Patch
        [ 0x2664,  0x36],    #Patch
        [ 0x2665,  0x37],    #Patch
        [ 0x2666,  0x37],    #Patch
        [ 0x2667,  0x38],    #Patch
        [ 0x2668,  0x39],    #Patch
        [ 0x2669,  0x3A],    #Patch
        [ 0x266A,  0x3B],    #Patch
        [ 0x266B,  0x3B],    #Patch
        [ 0x266C,  0x3C],    #Patch
        [ 0x266D,  0x3D],    #Patch
        [ 0x266E,  0x3E],    #Patch
        [ 0x266F,  0x3F],    #Patch
        [ 0x2670,  0x3F],    #Patch
        [ 0x2671,  0x41],    #Patch
        [ 0x2672,  0x41],    #Patch
        [ 0x2673,  0x42],    #Patch
        [ 0x2674,  0x43],    #Patch
        [ 0x2675,  0x44],    #Patch
        [ 0x2676,  0x44],    #Patch
        [ 0x2677,  0x45],    #Patch
        [ 0x2678,  0x46],    #Patch
        [ 0x2679,  0x47],    #Patch
        [ 0x267A,  0x48],    #Patch
        [ 0x267B,  0x48],    #Patch
        [ 0x267C,  0x49],    #Patch
        [ 0x267D,  0x4A],    #Patch
        [ 0x267E,  0x4B],    #Patch
        [ 0x267F,  0x4C],    #Patch
        [ 0x2680,  0x4D],    #Patch
        [ 0x2681,  0x4D],    #Patch
        [ 0x2682,  0x4E],    #Patch
        [ 0x2683,  0x4F],    #Patch
        [ 0x2684,  0x50],    #Patch
        [ 0x2685,  0x51],    #Patch
        [ 0x2686,  0x51],    #Patch
        [ 0x2687,  0x52],    #Patch
        [ 0x2688,  0x53],    #Patch
        [ 0x2689,  0x54],    #Patch
        [ 0x268A,  0x55],    #Patch
        [ 0x268B,  0x03],    #Patch
        [ 0x268C,  0x04],    #Patch
        [ 0x268D,  0x05],    #Patch
        [ 0x268E,  0x06],    #Patch
        [ 0x268F,  0x08],    #Patch
        [ 0x2690,  0x09],    #Patch
        [ 0x2691,  0x0A],    #Patch
        [ 0x2692,  0x0B],    #Patch
        [ 0x2693,  0x0C],    #Patch
        [ 0x2694,  0x0E],    #Patch
        [ 0x2695,  0x0F],    #Patch
        [ 0x2696,  0x10],    #Patch
        [ 0x2697,  0x11],    #Patch
        [ 0x2698,  0x12],    #Patch
        [ 0x2699,  0x14],    #Patch
        [ 0x269A,  0x15],    #Patch
        [ 0x269B,  0x16],    #Patch
        [ 0x269C,  0x17],    #Patch
        [ 0x269D,  0x18],    #Patch
        [ 0x269E,  0x1A],    #Patch
        [ 0x269F,  0x1B],    #Patch
        [ 0x26A0,  0x1C],    #Patch
        [ 0x26A1,  0x1D],    #Patch
        [ 0x26A2,  0x1E],    #Patch
        [ 0x26A3,  0x20],    #Patch
        [ 0x26A4,  0x21],    #Patch
        [ 0x26A5,  0x23],    #Patch
        [ 0x26A6,  0x24],    #Patch
        [ 0x26A7,  0x25],    #Patch
        [ 0x26A8,  0x26],    #Patch
        [ 0x26A9,  0x27],    #Patch
        [ 0x26AA,  0x29],    #Patch
        [ 0x26AB,  0x2A],    #Patch
        [ 0x26AC,  0x2B],    #Patch
        [ 0x26AD,  0x2C],    #Patch
        [ 0x26AE,  0x2D],    #Patch
        [ 0x26AF,  0x2F],    #Patch
        [ 0x26B0,  0x30],    #Patch
        [ 0x26B1,  0x31],    #Patch
        [ 0x26B2,  0x32],    #Patch
        [ 0x26B3,  0x34],    #Patch
        [ 0x26B4,  0x35],    #Patch
        [ 0x26B5,  0x36],    #Patch
        [ 0x26B6,  0x37],    #Patch
        [ 0x26B7,  0x39],    #Patch
        [ 0x26B8,  0x3A],    #Patch
        [ 0x26B9,  0x3B],    #Patch
        [ 0x26BA,  0x3C],    #Patch
        [ 0x26BB,  0x3D],    #Patch
        [ 0x26BC,  0x3E],    #Patch
        [ 0x26BD,  0x40],    #Patch
        [ 0x26BE,  0x41],    #Patch
        [ 0x26BF,  0x42],    #Patch
        [ 0x26C0,  0x44],    #Patch
        [ 0x26C1,  0x45],    #Patch
        [ 0x26C2,  0x46],    #Patch
        [ 0x26C3,  0x47],    #Patch
        [ 0x26C4,  0x48],    #Patch
        [ 0x26C5,  0x4A],    #Patch
        [ 0x26C6,  0x4B],    #Patch
        [ 0x26C7,  0x4C],    #Patch
        [ 0x26C8,  0x4D],    #Patch
        [ 0x26C9,  0x4F],    #Patch
        [ 0x26CA,  0x50],    #Patch
        [ 0x26CB,  0x51],    #Patch
        [ 0x26CC,  0x52],    #Patch
        [ 0x26CD,  0x54],    #Patch
        [ 0x26CE,  0x55],    #Patch
        [ 0x26CF,  0x03],    #Patch
        [ 0x26D0,  0x05],    #Patch
        [ 0x26D1,  0x07],    #Patch
        [ 0x26D2,  0x09],    #Patch
        [ 0x26D3,  0x0A],    #Patch
        [ 0x26D4,  0x0B],    #Patch
        [ 0x26D5,  0x0E],    #Patch
        [ 0x26D6,  0x10],    #Patch
        [ 0x26D7,  0x12],    #Patch
        [ 0x26D8,  0x13],    #Patch
        [ 0x26D9,  0x15],    #Patch
        [ 0x26DA,  0x17],    #Patch
        [ 0x26DB,  0x18],    #Patch
        [ 0x26DC,  0x1B],    #Patch
        [ 0x26DD,  0x1C],    #Patch
        [ 0x26DE,  0x1E],    #Patch
        [ 0x26DF,  0x20],    #Patch
        [ 0x26E0,  0x22],    #Patch
        [ 0x26E1,  0x24],    #Patch
        [ 0x26E2,  0x26],    #Patch
        [ 0x26E3,  0x27],    #Patch
        [ 0x26E4,  0x2A],    #Patch
        [ 0x26E5,  0x2C],    #Patch
        [ 0x26E6,  0x2D],    #Patch
        [ 0x26E7,  0x2F],    #Patch
        [ 0x26E8,  0x31],    #Patch
        [ 0x26E9,  0x33],    #Patch
        [ 0x26EA,  0x35],    #Patch
        [ 0x26EB,  0x36],    #Patch
        [ 0x26EC,  0x38],    #Patch
        [ 0x26ED,  0x3A],    #Patch
        [ 0x26EE,  0x3C],    #Patch
        [ 0x26EF,  0x3E],    #Patch
        [ 0x26F0,  0x3F],    #Patch
        [ 0x26F1,  0x42],    #Patch
        [ 0x26F2,  0x43],    #Patch
        [ 0x26F3,  0x45],    #Patch
        [ 0x26F4,  0x47],    #Patch
        [ 0x26F5,  0x49],    #Patch
        [ 0x26F6,  0x4B],    #Patch
        [ 0x26F7,  0x4C],    #Patch
        [ 0x26F8,  0x4E],    #Patch
        [ 0x26F9,  0x50],    #Patch
        [ 0x26FA,  0x52],    #Patch
        [ 0x26FB,  0x54],    #Patch
        [ 0x26FC,  0x55],    #Patch
        [ 0x26FD,  0x57],    #Patch
        [ 0x26FE,  0x59],    #Patch
        [ 0x26FF,  0x5B],    #Patch
        [ 0x2700,  0x04],    #Patch
        [ 0x2701,  0x07],    #Patch
        [ 0x2702,  0x0A],    #Patch
        [ 0x2703,  0x0D],    #Patch
        [ 0x2704,  0x10],    #Patch
        [ 0x2705,  0x13],    #Patch
        [ 0x2706,  0x15],    #Patch
        [ 0x2707,  0x18],    #Patch
        [ 0x2708,  0x1B],    #Patch
        [ 0x2709,  0x1E],    #Patch
        [ 0x270A,  0x21],    #Patch
        [ 0x270B,  0x24],    #Patch
        [ 0x270C,  0x27],    #Patch
        [ 0x270D,  0x2A],    #Patch
        [ 0x270E,  0x2C],    #Patch
        [ 0x270F,  0x2F],    #Patch
        [ 0x2710,  0x32],    #Patch
        [ 0x2711,  0x35],    #Patch
        [ 0x2712,  0x38],    #Patch
        [ 0x2713,  0x3B],    #Patch
        [ 0x2714,  0x3D],    #Patch
        [ 0x2715,  0x40],    #Patch
        [ 0x2716,  0x43],    #Patch
        [ 0x2717,  0x46],    #Patch
        [ 0x2718,  0x49],    #Patch
        [ 0x2719,  0x4B],    #Patch
        [ 0x271A,  0x4E],    #Patch
        [ 0x271B,  0x51],    #Patch
        [ 0x271C,  0x54],    #Patch
        [ 0x271D,  0x57],    #Patch
        [ 0x271E,  0x5A],    #Patch
        [ 0x271F,  0x5C],    #Patch
        [ 0x2720,  0x5F],    #Patch
        [ 0x2721,  0x62],    #Patch
        [ 0x2722,  0x65],    #Patch
        [ 0x2723,  0x68],    #Patch
        [ 0x2724,  0x6B],    #Patch
        [ 0x2725,  0x07],    #Patch
        [ 0x2726,  0x0C],    #Patch
        [ 0x2727,  0x11],    #Patch
        [ 0x2728,  0x15],    #Patch
        [ 0x2729,  0x1A],    #Patch
        [ 0x272A,  0x1F],    #Patch
        [ 0x272B,  0x24],    #Patch
        [ 0x272C,  0x29],    #Patch
        [ 0x272D,  0x2E],    #Patch
        [ 0x272E,  0x33],    #Patch
        [ 0x272F,  0x37],    #Patch
        [ 0x2730,  0x3C],    #Patch
        [ 0x2731,  0x41],    #Patch
        [ 0x2732,  0x46],    #Patch
        [ 0x2733,  0x4B],    #Patch
        [ 0x2734,  0x50],    #Patch
        [ 0x2735,  0x54],    #Patch
        [ 0x2736,  0x59],    #Patch
        [ 0x2737,  0x5E],    #Patch
        [ 0x2738,  0x63],    #Patch
        [ 0x2739,  0x68],    #Patch
        [ 0x273A,  0x6D],    #Patch
        [ 0x273B,  0x72],    #Patch
        [ 0x273C,  0x76],    #Patch
        [ 0x273D,  0x7B],    #Patch
        [ 0x273E,  0x80],    #Patch
        [ 0x273F,  0x85],    #Patch
        [ 0x2740,  0x8A],    #Patch
        [ 0x2741,  0x8F],    #Patch
        [ 0x2742,  0x10],    #Patch
        [ 0x2743,  0x1A],    #Patch
        [ 0x2744,  0x26],    #Patch
        [ 0x2745,  0x30],    #Patch
        [ 0x2746,  0x3B],    #Patch
        [ 0x2747,  0x46],    #Patch
        [ 0x2748,  0x51],    #Patch
        [ 0x2749,  0x58],    #Patch
        [ 0x274A,  0x63],    #Patch
        [ 0x274B,  0x6E],    #Patch
        [ 0x274C,  0x79],    #Patch
        [ 0x274D,  0x85],    #Patch
        [ 0x274E,  0x90],    #Patch
        [ 0x274F,  0x9B],    #Patch
        [ 0x2750,  0xA6],    #Patch
        [ 0x2751,  0xB2],    #Patch
        [ 0x2752,  0xBD],    #Patch
        [ 0x2753,  0xC8],    #Patch
        [ 0x2754,  0xD3],    #Patch
        [ 0x2755,  0xDE],    #Patch
        [ 0x2756,  0xEA],    #Patch
        [ 0x2757,  0xF5],    #Patch
        [ 0x2758,  0x01],    #Patch
        [ 0x2759,  0x26],    #Patch
        [ 0x275A,  0x44],    #Patch
        [ 0x275B,  0x01],    #Patch
        [ 0x275C,  0x1D],    #Patch
        [ 0x275D,  0x45],    #Patch
        [ 0x275E,  0x60],    #Patch
        [ 0x275F,  0x02],    #Patch
        [ 0x2760,  0x46],    #Patch
        [ 0x2761,  0xD8],    #Patch
        [ 0x2762,  0x0F],    #Patch
        [ 0x2763,  0x47],    #Patch
        [ 0x2764,  0xAC],    #Patch
        [ 0x2765,  0x01],    #Patch
        [ 0x2766,  0x47],    #Patch
        [ 0x2767,  0xB0],    #Patch
        [ 0x2768,  0x7D],    #Patch
        [ 0x2769,  0x47],    #Patch
        [ 0x276A,  0xB1],    #Patch
        [ 0x276B,  0xB4],    #Patch
        [ 0x276C,  0x47],    #Patch
        [ 0x276D,  0xB4],    #Patch
        [ 0x276E,  0x7D],    #Patch
        [ 0x276F,  0x47],    #Patch
        [ 0x2770,  0xB5],    #Patch
        [ 0x2771,  0xB4],    #Patch
        [ 0x2772,  0x47],    #Patch
        [ 0x2773,  0xB8],    #Patch
        [ 0x2774,  0x77],    #Patch
        [ 0x2775,  0x47],    #Patch
        [ 0x2776,  0xB9],    #Patch
        [ 0x2777,  0xA8],    #Patch
        [ 0x2778,  0x47],    #Patch
        [ 0x2779,  0xC0],    #Patch
        [ 0x277A,  0x77],    #Patch
        [ 0x277B,  0x47],    #Patch
        [ 0x277C,  0xC1],    #Patch
        [ 0x277D,  0xA8],    #Patch
        [ 0x277E,  0x47],    #Patch
        [ 0x277F,  0xD1],    #Patch
        [ 0x2780,  0x04],    #Patch
        [ 0x2781,  0x47],    #Patch
        [ 0x2782,  0xD2],    #Patch
        [ 0x2783,  0x0B],    #Patch
        [ 0x2784,  0x47],    #Patch
        [ 0x2785,  0xD3],    #Patch
        [ 0x2786,  0x15],    #Patch
        [ 0x2787,  0x47],    #Patch
        [ 0x2788,  0xD4],    #Patch
        [ 0x2789,  0x06],    #Patch
        [ 0x278A,  0x47],    #Patch
        [ 0x278B,  0xD5],    #Patch
        [ 0x278C,  0x0D],    #Patch
        [ 0x278D,  0x47],    #Patch
        [ 0x278E,  0xD6],    #Patch
        [ 0x278F,  0x18],    #Patch
        [ 0x2790,  0x47],    #Patch
        [ 0x2791,  0xD7],    #Patch
        [ 0x2792,  0x00],    #Patch
        [ 0x2793,  0x47],    #Patch
        [ 0x2794,  0xD8],    #Patch
        [ 0x2795,  0x03],    #Patch
        [ 0x2796,  0x47],    #Patch
        [ 0x2797,  0xD9],    #Patch
        [ 0x2798,  0x12],    #Patch
        [ 0x2799,  0x47],    #Patch
        [ 0x279A,  0xDD],    #Patch
        [ 0x279B,  0x00],    #Patch
        [ 0x279C,  0x47],    #Patch
        [ 0x279D,  0xDE],    #Patch
        [ 0x279E,  0x00],    #Patch
        [ 0x279F,  0x47],    #Patch
        [ 0x27A0,  0xDF],    #Patch
        [ 0x27A1,  0x08],    #Patch
        [ 0x27A2,  0x47],    #Patch
        [ 0x27A3,  0xE3],    #Patch
        [ 0x27A4,  0x00],    #Patch
        [ 0x27A5,  0x47],    #Patch
        [ 0x27A6,  0xE4],    #Patch
        [ 0x27A7,  0x04],    #Patch
        [ 0x27A8,  0x47],    #Patch
        [ 0x27A9,  0xE5],    #Patch
        [ 0x27AA,  0x00],    #Patch
        [ 0x27AB,  0x47],    #Patch
        [ 0x27AC,  0xE6],    #Patch
        [ 0x27AD,  0x00],    #Patch
        [ 0x27AE,  0x47],    #Patch
        [ 0x27AF,  0xE7],    #Patch
        [ 0x27B0,  0x00],    #Patch
        [ 0x27B1,  0x47],    #Patch
        [ 0x27B2,  0xE8],    #Patch
        [ 0x27B3,  0x00],    #Patch
        [ 0x27B4,  0x47],    #Patch
        [ 0x27B5,  0xE9],    #Patch
        [ 0x27B6,  0x15],    #Patch
        [ 0x27B7,  0x47],    #Patch
        [ 0x27B8,  0xEA],    #Patch
        [ 0x27B9,  0x00],    #Patch
        [ 0x27BA,  0x47],    #Patch
        [ 0x27BB,  0xEB],    #Patch
        [ 0x27BC,  0x02],    #Patch
        [ 0x27BD,  0x47],    #Patch
        [ 0x27BE,  0xEF],    #Patch
        [ 0x27BF,  0x58],    #Patch
        [ 0x27C0,  0x47],    #Patch
        [ 0x27C1,  0xF0],    #Patch
        [ 0x27C2,  0x1D],    #Patch
        [ 0x27C3,  0x47],    #Patch
        [ 0x27C4,  0xF1],    #Patch
        [ 0x27C5,  0x04],    #Patch
        [ 0x27C6,  0x48],    #Patch
        [ 0x27C7,  0x11],    #Patch
        [ 0x27C8,  0x08],    #Patch
        [ 0x27C9,  0x48],    #Patch
        [ 0x27CA,  0x13],    #Patch
        [ 0x27CB,  0x0D],    #Patch
        [ 0x27CC,  0x48],    #Patch
        [ 0x27CD,  0x16],    #Patch
        [ 0x27CE,  0x07],    #Patch
        [ 0x27CF,  0x48],    #Patch
        [ 0x27D0,  0x17],    #Patch
        [ 0x27D1,  0x07],    #Patch
        [ 0x27D2,  0x48],    #Patch
        [ 0x27D3,  0x18],    #Patch
        [ 0x27D4,  0x06],    #Patch
        [ 0x27D5,  0x48],    #Patch
        [ 0x27D6,  0x19],    #Patch
        [ 0x27D7,  0x06],    #Patch
        [ 0x27D8,  0x48],    #Patch
        [ 0x27D9,  0x1F],    #Patch
        [ 0x27DA,  0x0F],    #Patch
        [ 0x27DB,  0x48],    #Patch
        [ 0x27DC,  0x20],    #Patch
        [ 0x27DD,  0x0E],    #Patch
        [ 0x27DE,  0x48],    #Patch
        [ 0x27DF,  0x2A],    #Patch
        [ 0x27E0,  0x09],    #Patch
        [ 0x27E1,  0x48],    #Patch
        [ 0x27E2,  0x56],    #Patch
        [ 0x27E3,  0x00],    #Patch
        [ 0x27E4,  0x48],    #Patch
        [ 0x27E5,  0x57],    #Patch
        [ 0x27E6,  0x6E],    #Patch
        [ 0x27E7,  0x48],    #Patch
        [ 0x27E8,  0x92],    #Patch
        [ 0x27E9,  0x00],    #Patch
        [ 0x27EA,  0x48],    #Patch
        [ 0x27EB,  0x93],    #Patch
        [ 0x27EC,  0xF0],    #Patch
        [ 0x27ED,  0x48],    #Patch
        [ 0x27EE,  0xD6],    #Patch
        [ 0x27EF,  0x19],    #Patch
        [ 0x27F0,  0x48],    #Patch
        [ 0x27F1,  0xD7],    #Patch
        [ 0x27F2,  0x19],    #Patch
        [ 0x27F3,  0x48],    #Patch
        [ 0x27F4,  0xD8],    #Patch
        [ 0x27F5,  0x19],    #Patch
        [ 0x27F6,  0x48],    #Patch
        [ 0x27F7,  0xE2],    #Patch
        [ 0x27F8,  0x19],    #Patch
        [ 0x27F9,  0x48],    #Patch
        [ 0x27FA,  0xE3],    #Patch
        [ 0x27FB,  0x19],    #Patch
        [ 0x27FC,  0x48],    #Patch
        [ 0x27FD,  0xE4],    #Patch
        [ 0x27FE,  0x19],    #Patch
        [ 0x27FF,  0x49],    #Patch
        [ 0x2800,  0x94],    #Patch
        [ 0x2801,  0x01],    #Patch
        [ 0x2802,  0x49],    #Patch
        [ 0x2803,  0x98],    #Patch
        [ 0x2804,  0x34],    #Patch
        [ 0x2805,  0x49],    #Patch
        [ 0x2806,  0x99],    #Patch
        [ 0x2807,  0x7D],    #Patch
        [ 0x2808,  0x49],    #Patch
        [ 0x2809,  0x9A],    #Patch
        [ 0x280A,  0xB4],    #Patch
        [ 0x280B,  0x49],    #Patch
        [ 0x280C,  0x9B],    #Patch
        [ 0x280D,  0xDE],    #Patch
        [ 0x280E,  0x49],    #Patch
        [ 0x280F,  0x9C],    #Patch
        [ 0x2810,  0xFF],    #Patch
        [ 0x2811,  0x49],    #Patch
        [ 0x2812,  0x9D],    #Patch
        [ 0x2813,  0xFF],    #Patch
        [ 0x2814,  0x49],    #Patch
        [ 0x2815,  0x9E],    #Patch
        [ 0x2816,  0xFF],    #Patch
        [ 0x2817,  0x49],    #Patch
        [ 0x2818,  0x9F],    #Patch
        [ 0x2819,  0xFF],    #Patch
        [ 0x281A,  0x49],    #Patch
        [ 0x281B,  0xA0],    #Patch
        [ 0x281C,  0xFF],    #Patch
        [ 0x281D,  0x49],    #Patch
        [ 0x281E,  0xA4],    #Patch
        [ 0x281F,  0x33],    #Patch
        [ 0x2820,  0x49],    #Patch
        [ 0x2821,  0xA5],    #Patch
        [ 0x2822,  0x77],    #Patch
        [ 0x2823,  0x49],    #Patch
        [ 0x2824,  0xA6],    #Patch
        [ 0x2825,  0xA8],    #Patch
        [ 0x2826,  0x49],    #Patch
        [ 0x2827,  0xA7],    #Patch
        [ 0x2828,  0xCD],    #Patch
        [ 0x2829,  0x49],    #Patch
        [ 0x282A,  0xA8],    #Patch
        [ 0x282B,  0xEA],    #Patch
        [ 0x282C,  0x49],    #Patch
        [ 0x282D,  0xA9],    #Patch
        [ 0x282E,  0xFF],    #Patch
        [ 0x282F,  0x49],    #Patch
        [ 0x2830,  0xAA],    #Patch
        [ 0x2831,  0xFF],    #Patch
        [ 0x2832,  0x49],    #Patch
        [ 0x2833,  0xAB],    #Patch
        [ 0x2834,  0xFF],    #Patch
        [ 0x2835,  0x49],    #Patch
        [ 0x2836,  0xAC],    #Patch
        [ 0x2837,  0xFF],    #Patch
        [ 0x2838,  0x49],    #Patch
        [ 0x2839,  0xAD],    #Patch
        [ 0x283A,  0xFF],    #Patch
        [ 0x283B,  0x49],    #Patch
        [ 0x283C,  0xB0],    #Patch
        [ 0x283D,  0x89],    #Patch
        [ 0x283E,  0x49],    #Patch
        [ 0x283F,  0xB1],    #Patch
        [ 0x2840,  0x8C],    #Patch
        [ 0x2841,  0x49],    #Patch
        [ 0x2842,  0xB2],    #Patch
        [ 0x2843,  0x8F],    #Patch
        [ 0x2844,  0x49],    #Patch
        [ 0x2845,  0xB3],    #Patch
        [ 0x2846,  0x87],    #Patch
        [ 0x2847,  0x49],    #Patch
        [ 0x2848,  0xB4],    #Patch
        [ 0x2849,  0xFF],    #Patch
        [ 0x284A,  0x49],    #Patch
        [ 0x284B,  0xBB],    #Patch
        [ 0x284C,  0x73],    #Patch
        [ 0x284D,  0x49],    #Patch
        [ 0x284E,  0xBC],    #Patch
        [ 0x284F,  0x7B],    #Patch
        [ 0x2850,  0x49],    #Patch
        [ 0x2851,  0xBD],    #Patch
        [ 0x2852,  0x86],    #Patch
        [ 0x2853,  0x49],    #Patch
        [ 0x2854,  0xBE],    #Patch
        [ 0x2855,  0x85],    #Patch
        [ 0x2856,  0x49],    #Patch
        [ 0x2857,  0xBF],    #Patch
        [ 0x2858,  0xFF],    #Patch
        [ 0x2859,  0x49],    #Patch
        [ 0x285A,  0xC6],    #Patch
        [ 0x285B,  0x84],    #Patch
        [ 0x285C,  0x49],    #Patch
        [ 0x285D,  0xC7],    #Patch
        [ 0x285E,  0x8A],    #Patch
        [ 0x285F,  0x49],    #Patch
        [ 0x2860,  0xC8],    #Patch
        [ 0x2861,  0x8F],    #Patch
        [ 0x2862,  0x49],    #Patch
        [ 0x2863,  0xC9],    #Patch
        [ 0x2864,  0x8F],    #Patch
        [ 0x2865,  0x49],    #Patch
        [ 0x2866,  0xCA],    #Patch
        [ 0x2867,  0xA7],    #Patch
        [ 0x2868,  0x49],    #Patch
        [ 0x2869,  0xDC],    #Patch
        [ 0x286A,  0x85],    #Patch
        [ 0x286B,  0x49],    #Patch
        [ 0x286C,  0xDD],    #Patch
        [ 0x286D,  0x89],    #Patch
        [ 0x286E,  0x49],    #Patch
        [ 0x286F,  0xDE],    #Patch
        [ 0x2870,  0x8C],    #Patch
        [ 0x2871,  0x49],    #Patch
        [ 0x2872,  0xDF],    #Patch
        [ 0x2873,  0x8F],    #Patch
        [ 0x2874,  0x49],    #Patch
        [ 0x2875,  0xE0],    #Patch
        [ 0x2876,  0xA7],    #Patch
        [ 0x2877,  0x49],    #Patch
        [ 0x2878,  0xF2],    #Patch
        [ 0x2879,  0x7F],    #Patch
        [ 0x287A,  0x49],    #Patch
        [ 0x287B,  0xF3],    #Patch
        [ 0x287C,  0x85],    #Patch
        [ 0x287D,  0x49],    #Patch
        [ 0x287E,  0xF4],    #Patch
        [ 0x287F,  0x93],    #Patch
        [ 0x2880,  0x49],    #Patch
        [ 0x2881,  0xF5],    #Patch
        [ 0x2882,  0xAB],    #Patch
        [ 0x2883,  0x49],    #Patch
        [ 0x2884,  0xF6],    #Patch
        [ 0x2885,  0xFF],    #Patch
        [ 0x2886,  0x49],    #Patch
        [ 0x2887,  0xFD],    #Patch
        [ 0x2888,  0x6C],    #Patch
        [ 0x2889,  0x49],    #Patch
        [ 0x288A,  0xFE],    #Patch
        [ 0x288B,  0x76],    #Patch
        [ 0x288C,  0x49],    #Patch
        [ 0x288D,  0xFF],    #Patch
        [ 0x288E,  0x8B],    #Patch
        [ 0x288F,  0x4A],    #Patch
        [ 0x2890,  0x00],    #Patch
        [ 0x2891,  0xAF],    #Patch
        [ 0x2892,  0x4A],    #Patch
        [ 0x2893,  0x01],    #Patch
        [ 0x2894,  0xFF],    #Patch
        [ 0x2895,  0x4A],    #Patch
        [ 0x2896,  0x08],    #Patch
        [ 0x2897,  0x78],    #Patch
        [ 0x2898,  0x4A],    #Patch
        [ 0x2899,  0x09],    #Patch
        [ 0x289A,  0x80],    #Patch
        [ 0x289B,  0x4A],    #Patch
        [ 0x289C,  0x0A],    #Patch
        [ 0x289D,  0x8A],    #Patch
        [ 0x289E,  0x4A],    #Patch
        [ 0x289F,  0x0B],    #Patch
        [ 0x28A0,  0x91],    #Patch
        [ 0x28A1,  0x4A],    #Patch
        [ 0x28A2,  0x0C],    #Patch
        [ 0x28A3,  0xBC],    #Patch
        [ 0x28A4,  0x4A],    #Patch
        [ 0x28A5,  0x1E],    #Patch
        [ 0x28A6,  0x78],    #Patch
        [ 0x28A7,  0x4A],    #Patch
        [ 0x28A8,  0x1F],    #Patch
        [ 0x28A9,  0x7D],    #Patch
        [ 0x28AA,  0x4A],    #Patch
        [ 0x28AB,  0x20],    #Patch
        [ 0x28AC,  0x85],    #Patch
        [ 0x28AD,  0x4A],    #Patch
        [ 0x28AE,  0x21],    #Patch
        [ 0x28AF,  0x8C],    #Patch
        [ 0x28B0,  0x4A],    #Patch
        [ 0x28B1,  0x22],    #Patch
        [ 0x28B2,  0xB6],    #Patch
        [ 0x28B3,  0x4A],    #Patch
        [ 0x28B4,  0x34],    #Patch
        [ 0x28B5,  0x01],    #Patch
        [ 0x28B6,  0x4A],    #Patch
        [ 0x28B7,  0x38],    #Patch
        [ 0x28B8,  0x34],    #Patch
        [ 0x28B9,  0x4A],    #Patch
        [ 0x28BA,  0x39],    #Patch
        [ 0x28BB,  0x7D],    #Patch
        [ 0x28BC,  0x4A],    #Patch
        [ 0x28BD,  0x3A],    #Patch
        [ 0x28BE,  0xB4],    #Patch
        [ 0x28BF,  0x4A],    #Patch
        [ 0x28C0,  0x3B],    #Patch
        [ 0x28C1,  0xDE],    #Patch
        [ 0x28C2,  0x4A],    #Patch
        [ 0x28C3,  0x3C],    #Patch
        [ 0x28C4,  0xFF],    #Patch
        [ 0x28C5,  0x4A],    #Patch
        [ 0x28C6,  0x40],    #Patch
        [ 0x28C7,  0x00],    #Patch
        [ 0x28C8,  0x4A],    #Patch
        [ 0x28C9,  0x41],    #Patch
        [ 0x28CA,  0xD1],    #Patch
        [ 0x28CB,  0x4A],    #Patch
        [ 0x28CC,  0x42],    #Patch
        [ 0x28CD,  0x00],    #Patch
        [ 0x28CE,  0x4A],    #Patch
        [ 0x28CF,  0x43],    #Patch
        [ 0x28D0,  0xAA],    #Patch
        [ 0x28D1,  0x4A],    #Patch
        [ 0x28D2,  0x44],    #Patch
        [ 0x28D3,  0x00],    #Patch
        [ 0x28D4,  0x4A],    #Patch
        [ 0x28D5,  0x45],    #Patch
        [ 0x28D6,  0x99],    #Patch
        [ 0x28D7,  0x4A],    #Patch
        [ 0x28D8,  0x46],    #Patch
        [ 0x28D9,  0x00],    #Patch
        [ 0x28DA,  0x4A],    #Patch
        [ 0x28DB,  0x47],    #Patch
        [ 0x28DC,  0x89],    #Patch
        [ 0x28DD,  0x4A],    #Patch
        [ 0x28DE,  0x48],    #Patch
        [ 0x28DF,  0x00],    #Patch
        [ 0x28E0,  0x4A],    #Patch
        [ 0x28E1,  0x49],    #Patch
        [ 0x28E2,  0x85],    #Patch
        [ 0x28E3,  0x4A],    #Patch
        [ 0x28E4,  0x50],    #Patch
        [ 0x28E5,  0x00],    #Patch
        [ 0x28E6,  0x4A],    #Patch
        [ 0x28E7,  0x51],    #Patch
        [ 0x28E8,  0x9C],    #Patch
        [ 0x28E9,  0x4A],    #Patch
        [ 0x28EA,  0x52],    #Patch
        [ 0x28EB,  0x00],    #Patch
        [ 0x28EC,  0x4A],    #Patch
        [ 0x28ED,  0x53],    #Patch
        [ 0x28EE,  0x8E],    #Patch
        [ 0x28EF,  0x4A],    #Patch
        [ 0x28F0,  0x54],    #Patch
        [ 0x28F1,  0x00],    #Patch
        [ 0x28F2,  0x4A],    #Patch
        [ 0x28F3,  0x55],    #Patch
        [ 0x28F4,  0x82],    #Patch
        [ 0x28F5,  0x4A],    #Patch
        [ 0x28F6,  0x56],    #Patch
        [ 0x28F7,  0x00],    #Patch
        [ 0x28F8,  0x4A],    #Patch
        [ 0x28F9,  0x57],    #Patch
        [ 0x28FA,  0x79],    #Patch
        [ 0x28FB,  0x4A],    #Patch
        [ 0x28FC,  0x58],    #Patch
        [ 0x28FD,  0x00],    #Patch
        [ 0x28FE,  0x4A],    #Patch
        [ 0x28FF,  0x59],    #Patch
        [ 0x2900,  0x77],    #Patch
        [ 0x2901,  0x4A],    #Patch
        [ 0x2902,  0x60],    #Patch
        [ 0x2903,  0x00],    #Patch
        [ 0x2904,  0x4A],    #Patch
        [ 0x2905,  0x61],    #Patch
        [ 0x2906,  0xEF],    #Patch
        [ 0x2907,  0x4A],    #Patch
        [ 0x2908,  0x62],    #Patch
        [ 0x2909,  0x00],    #Patch
        [ 0x290A,  0x4A],    #Patch
        [ 0x290B,  0x63],    #Patch
        [ 0x290C,  0xCD],    #Patch
        [ 0x290D,  0x4A],    #Patch
        [ 0x290E,  0x64],    #Patch
        [ 0x290F,  0x00],    #Patch
        [ 0x2910,  0x4A],    #Patch
        [ 0x2911,  0x65],    #Patch
        [ 0x2912,  0xA9],    #Patch
        [ 0x2913,  0x4A],    #Patch
        [ 0x2914,  0x66],    #Patch
        [ 0x2915,  0x00],    #Patch
        [ 0x2916,  0x4A],    #Patch
        [ 0x2917,  0x67],    #Patch
        [ 0x2918,  0x8D],    #Patch
        [ 0x2919,  0x4A],    #Patch
        [ 0x291A,  0x68],    #Patch
        [ 0x291B,  0x00],    #Patch
        [ 0x291C,  0x4A],    #Patch
        [ 0x291D,  0x69],    #Patch
        [ 0x291E,  0x8A],    #Patch
        [ 0x291F,  0x4A],    #Patch
        [ 0x2920,  0x80],    #Patch
        [ 0x2921,  0x00],    #Patch
        [ 0x2922,  0x4A],    #Patch
        [ 0x2923,  0x81],    #Patch
        [ 0x2924,  0xEB],    #Patch
        [ 0x2925,  0x4A],    #Patch
        [ 0x2926,  0x82],    #Patch
        [ 0x2927,  0x00],    #Patch
        [ 0x2928,  0x4A],    #Patch
        [ 0x2929,  0x83],    #Patch
        [ 0x292A,  0xC3],    #Patch
        [ 0x292B,  0x4A],    #Patch
        [ 0x292C,  0x84],    #Patch
        [ 0x292D,  0x00],    #Patch
        [ 0x292E,  0x4A],    #Patch
        [ 0x292F,  0x85],    #Patch
        [ 0x2930,  0xA8],    #Patch
        [ 0x2931,  0x4A],    #Patch
        [ 0x2932,  0x86],    #Patch
        [ 0x2933,  0x00],    #Patch
        [ 0x2934,  0x4A],    #Patch
        [ 0x2935,  0x87],    #Patch
        [ 0x2936,  0x8A],    #Patch
        [ 0x2937,  0x4A],    #Patch
        [ 0x2938,  0x88],    #Patch
        [ 0x2939,  0x00],    #Patch
        [ 0x293A,  0x4A],    #Patch
        [ 0x293B,  0x89],    #Patch
        [ 0x293C,  0x88],    #Patch
        [ 0x293D,  0x4A],    #Patch
        [ 0x293E,  0xC8],    #Patch
        [ 0x293F,  0x0D],    #Patch
        [ 0x2940,  0x4A],    #Patch
        [ 0x2941,  0xC9],    #Patch
        [ 0x2942,  0x0D],    #Patch
        [ 0x2943,  0x4A],    #Patch
        [ 0x2944,  0xCA],    #Patch
        [ 0x2945,  0x0D],    #Patch
        [ 0x2946,  0x4A],    #Patch
        [ 0x2947,  0xCB],    #Patch
        [ 0x2948,  0x0D],    #Patch
        [ 0x2949,  0x4A],    #Patch
        [ 0x294A,  0xCC],    #Patch
        [ 0x294B,  0x0D],    #Patch
        [ 0x294C,  0x4A],    #Patch
        [ 0x294D,  0xCD],    #Patch
        [ 0x294E,  0x0D],    #Patch
        [ 0x294F,  0x4A],    #Patch
        [ 0x2950,  0xCE],    #Patch
        [ 0x2951,  0x0D],    #Patch
        [ 0x2952,  0x4A],    #Patch
        [ 0x2953,  0xCF],    #Patch
        [ 0x2954,  0x0D],    #Patch
        [ 0x2955,  0x4A],    #Patch
        [ 0x2956,  0xD0],    #Patch
        [ 0x2957,  0x0D],    #Patch
        [ 0x2958,  0x4A],    #Patch
        [ 0x2959,  0xD1],    #Patch
        [ 0x295A,  0x0D],    #Patch
        [ 0x295B,  0x4A],    #Patch
        [ 0x295C,  0xD2],    #Patch
        [ 0x295D,  0x0D],    #Patch
        [ 0x295E,  0x4A],    #Patch
        [ 0x295F,  0xD3],    #Patch
        [ 0x2960,  0x0D],    #Patch
        [ 0x2961,  0x4A],    #Patch
        [ 0x2962,  0xD4],    #Patch
        [ 0x2963,  0x0D],    #Patch
        [ 0x2964,  0x4A],    #Patch
        [ 0x2965,  0xD5],    #Patch
        [ 0x2966,  0x0D],    #Patch
        [ 0x2967,  0x4A],    #Patch
        [ 0x2968,  0xD6],    #Patch
        [ 0x2969,  0x0D],    #Patch
        [ 0x296A,  0x4A],    #Patch
        [ 0x296B,  0xD7],    #Patch
        [ 0x296C,  0x0D],    #Patch
        [ 0x296D,  0x4A],    #Patch
        [ 0x296E,  0xD8],    #Patch
        [ 0x296F,  0x0D],    #Patch
        [ 0x2970,  0x4A],    #Patch
        [ 0x2971,  0xD9],    #Patch
        [ 0x2972,  0x0D],    #Patch
        [ 0x2973,  0x4A],    #Patch
        [ 0x2974,  0xDA],    #Patch
        [ 0x2975,  0x0D],    #Patch
        [ 0x2976,  0x4A],    #Patch
        [ 0x2977,  0xDB],    #Patch
        [ 0x2978,  0x0D],    #Patch
        [ 0x2979,  0x4B],    #Patch
        [ 0x297A,  0x2C],    #Patch
        [ 0x297B,  0x15],    #Patch
        [ 0x297C,  0x4B],    #Patch
        [ 0x297D,  0x2D],    #Patch
        [ 0x297E,  0x18],    #Patch
        [ 0x297F,  0x4B],    #Patch
        [ 0x2980,  0x2E],    #Patch
        [ 0x2981,  0x21],    #Patch
        [ 0x2982,  0x4B],    #Patch
        [ 0x2983,  0x2F],    #Patch
        [ 0x2984,  0x23],    #Patch
        [ 0x2985,  0x4B],    #Patch
        [ 0x2986,  0x30],    #Patch
        [ 0x2987,  0x2C],    #Patch
        [ 0x2988,  0x4B],    #Patch
        [ 0x2989,  0x31],    #Patch
        [ 0x298A,  0x1B],    #Patch
        [ 0x298B,  0x4B],    #Patch
        [ 0x298C,  0x32],    #Patch
        [ 0x298D,  0x20],    #Patch
        [ 0x298E,  0x4B],    #Patch
        [ 0x298F,  0x33],    #Patch
        [ 0x2990,  0x2B],    #Patch
        [ 0x2991,  0x4B],    #Patch
        [ 0x2992,  0x34],    #Patch
        [ 0x2993,  0x2A],    #Patch
        [ 0x2994,  0x4B],    #Patch
        [ 0x2995,  0x35],    #Patch
        [ 0x2996,  0x33],    #Patch
        [ 0x2997,  0x4B],    #Patch
        [ 0x2998,  0x36],    #Patch
        [ 0x2999,  0x13],    #Patch
        [ 0x299A,  0x4B],    #Patch
        [ 0x299B,  0x37],    #Patch
        [ 0x299C,  0x15],    #Patch
        [ 0x299D,  0x4B],    #Patch
        [ 0x299E,  0x38],    #Patch
        [ 0x299F,  0x1A],    #Patch
        [ 0x29A0,  0x4B],    #Patch
        [ 0x29A1,  0x39],    #Patch
        [ 0x29A2,  0x1D],    #Patch
        [ 0x29A3,  0x4B],    #Patch
        [ 0x29A4,  0x3A],    #Patch
        [ 0x29A5,  0x20],    #Patch
        [ 0x29A6,  0x4B],    #Patch
        [ 0x29A7,  0x3B],    #Patch
        [ 0x29A8,  0x11],    #Patch
        [ 0x29A9,  0x4B],    #Patch
        [ 0x29AA,  0x3C],    #Patch
        [ 0x29AB,  0x12],    #Patch
        [ 0x29AC,  0x4B],    #Patch
        [ 0x29AD,  0x3D],    #Patch
        [ 0x29AE,  0x15],    #Patch
        [ 0x29AF,  0x4B],    #Patch
        [ 0x29B0,  0x3E],    #Patch
        [ 0x29B1,  0x19],    #Patch
        [ 0x29B2,  0x4B],    #Patch
        [ 0x29B3,  0x3F],    #Patch
        [ 0x29B4,  0x1C],    #Patch
        [ 0x29B5,  0x4B],    #Patch
        [ 0x29B6,  0x54],    #Patch
        [ 0x29B7,  0x01],    #Patch
        [ 0x29B8,  0x4B],    #Patch
        [ 0x29B9,  0x55],    #Patch
        [ 0x29BA,  0x01],    #Patch
        [ 0x29BB,  0x4B],    #Patch
        [ 0x29BC,  0x56],    #Patch
        [ 0x29BD,  0x01],    #Patch
        [ 0x29BE,  0x4B],    #Patch
        [ 0x29BF,  0x57],    #Patch
        [ 0x29C0,  0x01],    #Patch
        [ 0x29C1,  0x4B],    #Patch
        [ 0x29C2,  0x58],    #Patch
        [ 0x29C3,  0x01],    #Patch
        [ 0x29C4,  0x4B],    #Patch
        [ 0x29C5,  0x59],    #Patch
        [ 0x29C6,  0x01],    #Patch
        [ 0x29C7,  0x4B],    #Patch
        [ 0x29C8,  0x5A],    #Patch
        [ 0x29C9,  0x01],    #Patch
        [ 0x29CA,  0x4B],    #Patch
        [ 0x29CB,  0x5B],    #Patch
        [ 0x29CC,  0x01],    #Patch
        [ 0x29CD,  0x4B],    #Patch
        [ 0x29CE,  0x5C],    #Patch
        [ 0x29CF,  0x01],    #Patch
        [ 0x29D0,  0x4B],    #Patch
        [ 0x29D1,  0x5D],    #Patch
        [ 0x29D2,  0x01],    #Patch
        [ 0x29D3,  0x4B],    #Patch
        [ 0x29D4,  0x5E],    #Patch
        [ 0x29D5,  0x01],    #Patch
        [ 0x29D6,  0x4B],    #Patch
        [ 0x29D7,  0x5F],    #Patch
        [ 0x29D8,  0x01],    #Patch
        [ 0x29D9,  0x4B],    #Patch
        [ 0x29DA,  0x60],    #Patch
        [ 0x29DB,  0x01],    #Patch
        [ 0x29DC,  0x4B],    #Patch
        [ 0x29DD,  0x61],    #Patch
        [ 0x29DE,  0x01],    #Patch
        [ 0x29DF,  0x4B],    #Patch
        [ 0x29E0,  0x62],    #Patch
        [ 0x29E1,  0x01],    #Patch
        [ 0x29E2,  0x4B],    #Patch
        [ 0x29E3,  0x63],    #Patch
        [ 0x29E4,  0x01],    #Patch
        [ 0x29E5,  0x4B],    #Patch
        [ 0x29E6,  0x64],    #Patch
        [ 0x29E7,  0x01],    #Patch
        [ 0x29E8,  0x4B],    #Patch
        [ 0x29E9,  0x65],    #Patch
        [ 0x29EA,  0x01],    #Patch
        [ 0x29EB,  0x4B],    #Patch
        [ 0x29EC,  0x66],    #Patch
        [ 0x29ED,  0x01],    #Patch
        [ 0x29EE,  0x4B],    #Patch
        [ 0x29EF,  0x67],    #Patch
        [ 0x29F0,  0x01],    #Patch
        [ 0x29F1,  0x4B],    #Patch
        [ 0x29F2,  0x80],    #Patch
        [ 0x29F3,  0x34],    #Patch
        [ 0x29F4,  0x4B],    #Patch
        [ 0x29F5,  0x81],    #Patch
        [ 0x29F6,  0x7D],    #Patch
        [ 0x29F7,  0x4B],    #Patch
        [ 0x29F8,  0x82],    #Patch
        [ 0x29F9,  0xB4],    #Patch
        [ 0x29FA,  0x4B],    #Patch
        [ 0x29FB,  0x83],    #Patch
        [ 0x29FC,  0xDE],    #Patch
        [ 0x29FD,  0x4B],    #Patch
        [ 0x29FE,  0x88],    #Patch
        [ 0x29FF,  0x33],    #Patch
        [ 0x2A00,  0x4B],    #Patch
        [ 0x2A01,  0x89],    #Patch
        [ 0x2A02,  0x77],    #Patch
        [ 0x2A03,  0x4B],    #Patch
        [ 0x2A04,  0x8A],    #Patch
        [ 0x2A05,  0xA8],    #Patch
        [ 0x2A06,  0x4B],    #Patch
        [ 0x2A07,  0x8B],    #Patch
        [ 0x2A08,  0xCD],    #Patch
        [ 0x2A09,  0x4B],    #Patch
        [ 0x2A0A,  0x8C],    #Patch
        [ 0x2A0B,  0x07],    #Patch
        [ 0x2A0C,  0x4B],    #Patch
        [ 0x2A0D,  0x8D],    #Patch
        [ 0x2A0E,  0x07],    #Patch
        [ 0x2A0F,  0x4B],    #Patch
        [ 0x2A10,  0x8E],    #Patch
        [ 0x2A11,  0x07],    #Patch
        [ 0x2A12,  0x4B],    #Patch
        [ 0x2A13,  0x8F],    #Patch
        [ 0x2A14,  0x07],    #Patch
        [ 0x2A15,  0x4B],    #Patch
        [ 0x2A16,  0x90],    #Patch
        [ 0x2A17,  0x07],    #Patch
        [ 0x2A18,  0x4B],    #Patch
        [ 0x2A19,  0x91],    #Patch
        [ 0x2A1A,  0x0F],    #Patch
        [ 0x2A1B,  0x4B],    #Patch
        [ 0x2A1C,  0x92],    #Patch
        [ 0x2A1D,  0x0F],    #Patch
        [ 0x2A1E,  0x4B],    #Patch
        [ 0x2A1F,  0x93],    #Patch
        [ 0x2A20,  0x0F],    #Patch
        [ 0x2A21,  0x4B],    #Patch
        [ 0x2A22,  0x94],    #Patch
        [ 0x2A23,  0x0F],    #Patch
        [ 0x2A24,  0x4B],    #Patch
        [ 0x2A25,  0x95],    #Patch
        [ 0x2A26,  0x0F],    #Patch
        [ 0x2A27,  0x4B],    #Patch
        [ 0x2A28,  0x96],    #Patch
        [ 0x2A29,  0x07],    #Patch
        [ 0x2A2A,  0x4B],    #Patch
        [ 0x2A2B,  0x97],    #Patch
        [ 0x2A2C,  0x07],    #Patch
        [ 0x2A2D,  0x4B],    #Patch
        [ 0x2A2E,  0x98],    #Patch
        [ 0x2A2F,  0x07],    #Patch
        [ 0x2A30,  0x4B],    #Patch
        [ 0x2A31,  0x99],    #Patch
        [ 0x2A32,  0x07],    #Patch
        [ 0x2A33,  0x4B],    #Patch
        [ 0x2A34,  0x9A],    #Patch
        [ 0x2A35,  0x07],    #Patch
        [ 0x2A36,  0x5B],    #Patch
        [ 0x2A37,  0x38],    #Patch
        [ 0x2A38,  0x07],    #Patch
        [ 0x2A39,  0x5B],    #Patch
        [ 0x2A3A,  0xAB],    #Patch
        [ 0x2A3B,  0x26],    #Patch
        [ 0x2A3C,  0x5E],    #Patch
        [ 0x2A3D,  0x5D],    #Patch
        [ 0x2A3E,  0x22],    #Patch
        [ 0x2A3F,  0x5E],    #Patch
        [ 0x2A40,  0x61],    #Patch
        [ 0x2A41,  0x22],    #Patch
        [ 0x2A42,  0x5E],    #Patch
        [ 0x2A43,  0x63],    #Patch
        [ 0x2A44,  0x22],    #Patch
        [ 0x2A45,  0x5E],    #Patch
        [ 0x2A46,  0x67],    #Patch
        [ 0x2A47,  0x22],    #Patch
        [ 0x2A48,  0x60],    #Patch
        [ 0x2A49,  0x6F],    #Patch
        [ 0x2A4A,  0x06],    #Patch
        [ 0x2A4B,  0x60],    #Patch
        [ 0x2A4C,  0x73],    #Patch
        [ 0x2A4D,  0x06],    #Patch
        [ 0x2A4E,  0x60],    #Patch
        [ 0x2A4F,  0x75],    #Patch
        [ 0x2A50,  0x06],    #Patch
        [ 0x2A51,  0x60],    #Patch
        [ 0x2A52,  0x79],    #Patch
        [ 0x2A53,  0x06],    #Patch
        [ 0x2A54,  0x61],    #Patch
        [ 0x2A55,  0xF2],    #Patch
        [ 0x2A56,  0x00],    #Patch
        [ 0x2A57,  0x63],    #Patch
        [ 0x2A58,  0x2C],    #Patch
        [ 0x2A59,  0x08],    #Patch
        [ 0x2A5A,  0xA7],    #Patch
        [ 0x2A5B,  0xD0],    #Patch
        [ 0x2A5C,  0x07],    #Patch
        [ 0x2A5D,  0xA9],    #Patch
        [ 0x2A5E,  0x10],    #Patch
        [ 0x2A5F,  0x00],    #Patch
        [ 0x2A60,  0xA9],    #Patch
        [ 0x2A61,  0x11],    #Patch
        [ 0x2A62,  0x00],    #Patch
        [ 0x2A63,  0xA9],    #Patch
        [ 0x2A64,  0x12],    #Patch
        [ 0x2A65,  0x00],    #Patch
        [ 0x2A66,  0xA9],    #Patch
        [ 0x2A67,  0x13],    #Patch
        [ 0x2A68,  0x07],    #Patch
        [ 0x2A69,  0xC8],    #Patch
        [ 0x2A6A,  0x6F],    #Patch
        [ 0x2A6B,  0x07],    #Patch
        [ 0x2A6C,  0xC8],    #Patch
        [ 0x2A6D,  0x73],    #Patch
        [ 0x2A6E,  0x0D],    #Patch
        [ 0x2A6F,  0xD7],    #Patch
        [ 0x2A70,  0x10],    #Patch
        [ 0x2A71,  0x20],    #Patch
        [ 0x2A72,  0xD7],    #Patch
        [ 0x2A73,  0x11],    #Patch
        [ 0x2A74,  0x20],    #Patch
        [ 0x2A75,  0xD7],    #Patch
        [ 0x2A76,  0x12],    #Patch
        [ 0x2A77,  0x20],    #Patch
        [ 0x2A78,  0xD7],    #Patch
        [ 0x2A79,  0x13],    #Patch
        [ 0x2A7A,  0x20],    #Patch
        [ 0x2A7B,  0xD7],    #Patch
        [ 0x2A7C,  0x14],    #Patch
        [ 0x2A7D,  0x20],    #Patch
        [ 0x2A7E,  0xD7],    #Patch
        [ 0x2A7F,  0x15],    #Patch
        [ 0x2A80,  0x20],    #Patch
        [ 0x2A81,  0xD7],    #Patch
        [ 0x2A82,  0x16],    #Patch
        [ 0x2A83,  0x20],    #Patch
        [ 0x2A84,  0xDB],    #Patch
        [ 0x2A85,  0x04],    #Patch
        [ 0x2A86,  0x00],    #Patch
        [ 0x2A87,  0xDB],    #Patch
        [ 0x2A88,  0x05],    #Patch
        [ 0x2A89,  0x00],    #Patch
        [ 0x2A8A,  0xDB],    #Patch
        [ 0x2A8B,  0x06],    #Patch
        [ 0x2A8C,  0x00],    #Patch
        [ 0x2A8D,  0xDB],    #Patch
        [ 0x2A8E,  0x07],    #Patch
        [ 0x2A8F,  0x00],    #Patch
        [ 0x2A90,  0xDB],    #Patch
        [ 0x2A91,  0x0C],    #Patch
        [ 0x2A92,  0x00],    #Patch
        [ 0x2A93,  0xDB],    #Patch
        [ 0x2A94,  0x0D],    #Patch
        [ 0x2A95,  0xA0],    #Patch
        [ 0x2A96,  0xDB],    #Patch
        [ 0x2A97,  0x0E],    #Patch
        [ 0x2A98,  0x00],    #Patch
        [ 0x2A99,  0xDB],    #Patch
        [ 0x2A9A,  0x0F],    #Patch
        [ 0x2A9B,  0xA0],    #Patch
        [ 0x2A9C,  0xDB],    #Patch
        [ 0x2A9D,  0x2E],    #Patch
        [ 0x2A9E,  0x00],    #Patch
        [ 0x2A9F,  0xDB],    #Patch
        [ 0x2AA0,  0x2F],    #Patch
        [ 0x2AA1,  0x00],    #Patch
        [ 0x2AA2,  0xDB],    #Patch
        [ 0x2AA3,  0x36],    #Patch
        [ 0x2AA4,  0x00],    #Patch
        [ 0x2AA5,  0xDB],    #Patch
        [ 0x2AA6,  0x37],    #Patch
        [ 0x2AA7,  0xF0],    #Patch
        [ 0x2AA8,  0xDB],    #Patch
        [ 0x2AA9,  0x54],    #Patch
        [ 0x2AAA,  0x00],    #Patch
        [ 0x2AAB,  0xDB],    #Patch
        [ 0x2AAC,  0x55],    #Patch
        [ 0x2AAD,  0x32],    #Patch
        [ 0x2AAE,  0xDB],    #Patch
        [ 0x2AAF,  0x56],    #Patch
        [ 0x2AB0,  0x00],    #Patch
        [ 0x2AB1,  0xDB],    #Patch
        [ 0x2AB2,  0x57],    #Patch
        [ 0x2AB3,  0x32],    #Patch
        [ 0x2AB4,  0xDB],    #Patch
        [ 0x2AB5,  0x5C],    #Patch
        [ 0x2AB6,  0x00],    #Patch
        [ 0x2AB7,  0xDB],    #Patch
        [ 0x2AB8,  0x5D],    #Patch
        [ 0x2AB9,  0x20],    #Patch
        [ 0x2ABA,  0xDB],    #Patch
        [ 0x2ABB,  0x5E],    #Patch
        [ 0x2ABC,  0x00],    #Patch
        [ 0x2ABD,  0xDB],    #Patch
        [ 0x2ABE,  0x5F],    #Patch
        [ 0x2ABF,  0x20],    #Patch
        [ 0x2AC0,  0xDC],    #Patch
        [ 0x2AC1,  0x7E],    #Patch
        [ 0x2AC2,  0x00],    #Patch
        [ 0x2AC3,  0xDC],    #Patch
        [ 0x2AC4,  0x7F],    #Patch
        [ 0x2AC5,  0x3C],    #Patch
        [ 0x2AC6,  0xDC],    #Patch
        [ 0x2AC7,  0x86],    #Patch
        [ 0x2AC8,  0x00],    #Patch
        [ 0x2AC9,  0xDC],    #Patch
        [ 0x2ACA,  0x87],    #Patch
        [ 0x2ACB,  0x34],    #Patch
        [ 0x2ACC,  0x01],    #Patch
        [ 0x2ACD,  0x00],    #Patch
        [ 0x2ACE,  0x00],    #Patch
        [ 0x2ACF,  0x00],    #Patch
        [ 0x2AD0,  0x00],    #Patch
        [ 0x2AD1,  0x00],    #Patch
        [ 0x2AD2,  0x00],    #Patch
        [ 0x2AD3,  0x00],    #Patch
        [ 0x2AD4,  0x30],    #Patch
        [ 0x2AD5,  0x00],    #Patch
        [ 0x2AD6,  0x00],    #Patch
        [ 0x2AD7,  0x00],    #Patch
        [ 0x2AD8,  0xF8],    #Patch
        [ 0x2AD9,  0x3F],    #Patch
        [ 0x2ADA,  0x01],    #Patch
        [ 0x2ADB,  0x00],    #Patch
        [ 0x2ADC,  0x1C],    #Patch
        [ 0x2ADD,  0x00],    #Patch
        [ 0x2ADE,  0x00],    #Patch
        [ 0x2ADF,  0x00],    #Patch
        [ 0x2AE0,  0x00],    #Patch
        [ 0x2AE1,  0x02],    #Patch
        [ 0x2AE2,  0x00],    #Patch
        [ 0x2AE3,  0x00],    #Patch
        [ 0x2AE4,  0x01],    #Patch
        [ 0x2AE5,  0x00],    #Patch
        [ 0x2AE6,  0x00],    #Patch
        [ 0x2AE7,  0x00],    #Patch
        [ 0x2AE8,  0x01],    #Patch
        [ 0x2AE9,  0x00],    #Patch
        [ 0x2AEA,  0x00],    #Patch
        [ 0x2AEB,  0x00],    #Patch
        [ 0x2AEC,  0x30],    #Patch
        [ 0x2AED,  0x02],    #Patch
        [ 0x2AEE,  0x00],    #Patch
        [ 0x2AEF,  0x00],    #Patch
        [ 0x2AF0,  0x88],    #Patch
        [ 0x2AF1,  0x29],    #Patch
        [ 0x2AF2,  0x01],    #Patch
        [ 0x2AF3,  0x00],    #Patch
        [ 0x2AF4,  0xE1],    #Patch
        [ 0x2AF5,  0x07],    #Patch
        [ 0x2AF6,  0x18],    #Patch
        [ 0x2AF7,  0x05],    #Patch
        [ 0x2AF8,  0x00],    #Patch
        [ 0x2AF9,  0x00],    #Patch
        [ 0x2AFA,  0x00],    #Patch
        [ 0x2AFB,  0x00],    #Patch
        [ 0x2AFC,  0x01],    #Patch
        [ 0x2AFD,  0x00],    #Patch
        [ 0x2AFE,  0x00],    #Patch
        [ 0x2AFF,  0x00],    #Patch
        [ 0x2B00,  0x02],    #Patch
        [ 0x2B01,  0x00],    #Patch
        [ 0x2B02,  0x00],    #Patch
        [ 0x2B03,  0x00],    #Patch
        [ 0x2B04,  0x30],    #Patch
        [ 0x2B05,  0x02],    #Patch
        [ 0x2B06,  0x00],    #Patch
        [ 0x2B07,  0x00],    #Patch
        [ 0x2B08,  0x8C],    #Patch
        [ 0x2B09,  0x29],    #Patch
        [ 0x2B0A,  0x01],    #Patch
        [ 0x2B0B,  0x00],    #Patch
        [ 0x2B0C,  0xE1],    #Patch
        [ 0x2B0D,  0x07],    #Patch
        [ 0x2B0E,  0x19],    #Patch
        [ 0x2B0F,  0x05],    #Patch
        [ 0x2B10,  0x00],    #Patch
        [ 0x2B11,  0x00],    #Patch
        [ 0x2B12,  0x00],    #Patch
        [ 0x2B13,  0x00],    #Patch
        [ 0x2B14,  0x01],    #Patch
        [ 0x2B15,  0x00],    #Patch
        [ 0x2B16,  0x00],    #Patch
        [ 0x2B17,  0x00],    #Patch
        [ 0x2B18,  0x03],    #Patch
        [ 0x2B19,  0x00],    #Patch
        [ 0x2B1A,  0x00],    #Patch
        [ 0x2B1B,  0x00],    #Patch
        [ 0x2B1C,  0x30],    #Patch
        [ 0x2B1D,  0x02],    #Patch
        [ 0x2B1E,  0x00],    #Patch
        [ 0x2B1F,  0x00],    #Patch
        [ 0x2B20,  0x44],    #Patch
        [ 0x2B21,  0x7F],    #Patch
        [ 0x2B22,  0x00],    #Patch
        [ 0x2B23,  0x00],    #Patch
        [ 0x2B24,  0x21],    #Patch
        [ 0x2B25,  0xD1],    #Patch
        [ 0x2B26,  0x5A],    #Patch
        [ 0x2B27,  0x05],    #Patch
        [ 0x2B28,  0x00],    #Patch
        [ 0x2B29,  0x00],    #Patch
        [ 0x2B2A,  0x00],    #Patch
        [ 0x2B2B,  0x00],    #Patch
        [ 0x2B2C,  0x01],    #Patch
        [ 0x2B2D,  0x00],    #Patch
        [ 0x2B2E,  0x00],    #Patch
        [ 0x2B2F,  0x00],    #Patch
        [ 0x2B30,  0x04],    #Patch
        [ 0x2B31,  0x00],    #Patch
        [ 0x2B32,  0x00],    #Patch
        [ 0x2B33,  0x00],    #Patch
        [ 0x2B34,  0x30],    #Patch
        [ 0x2B35,  0x02],    #Patch
        [ 0x2B36,  0x00],    #Patch
        [ 0x2B37,  0x00],    #Patch
        [ 0x2B38,  0x7C],    #Patch
        [ 0x2B39,  0x29],    #Patch
        [ 0x2B3A,  0x01],    #Patch
        [ 0x2B3B,  0x00],    #Patch
        [ 0x2B3C,  0x61],    #Patch
        [ 0x2B3D,  0x00],    #Patch
        [ 0x2B3E,  0x0B],    #Patch
        [ 0x2B3F,  0x19],    #Patch
        [ 0x2B40,  0x00],    #Patch
        [ 0x2B41,  0x00],    #Patch
        [ 0x2B42,  0x00],    #Patch
        [ 0x2B43,  0x00],    #Patch
        [ 0x2B44,  0x01],    #Patch
        [ 0x2B45,  0x00],    #Patch
        [ 0x2B46,  0x00],    #Patch
        [ 0x2B47,  0x00],    #Patch
        [ 0x2B48,  0x05],    #Patch
        [ 0x2B49,  0x00],    #Patch
        [ 0x2B4A,  0x00],    #Patch
        [ 0x2B4B,  0x00],    #Patch
        [ 0x2B4C,  0x30],    #Patch
        [ 0x2B4D,  0x02],    #Patch
        [ 0x2B4E,  0x00],    #Patch
        [ 0x2B4F,  0x00],    #Patch
        [ 0x2B50,  0x80],    #Patch
        [ 0x2B51,  0x29],    #Patch
        [ 0x2B52,  0x01],    #Patch
        [ 0x2B53,  0x00],    #Patch
        [ 0x2B54,  0x61],    #Patch
        [ 0x2B55,  0x00],    #Patch
        [ 0x2B56,  0x0C],    #Patch
        [ 0x2B57,  0x19],    #Patch
        [ 0x2B58,  0x00],    #Patch
        [ 0x2B59,  0x00],    #Patch
        [ 0x2B5A,  0x00],    #Patch
        [ 0x2B5B,  0x00],    #Patch
        [ 0x2B5C,  0x01],    #Patch
        [ 0x2B5D,  0x00],    #Patch
        [ 0x2B5E,  0x00],    #Patch
        [ 0x2B5F,  0x00],    #Patch
        [ 0x2B60,  0x06],    #Patch
        [ 0x2B61,  0x00],    #Patch
        [ 0x2B62,  0x00],    #Patch
        [ 0x2B63,  0x00],    #Patch
        [ 0x2B64,  0x30],    #Patch
        [ 0x2B65,  0x02],    #Patch
        [ 0x2B66,  0x00],    #Patch
        [ 0x2B67,  0x00],    #Patch
        [ 0x2B68,  0xFC],    #Patch
        [ 0x2B69,  0x3F],    #Patch
        [ 0x2B6A,  0x01],    #Patch
        [ 0x2B6B,  0x00],    #Patch
        [ 0x2B6C,  0x1C],    #Patch
        [ 0x2B6D,  0x00],    #Patch
        [ 0x2B6E,  0x00],    #Patch
        [ 0x2B6F,  0x02],    #Patch
        [ 0x2B70,  0x74],    #Patch
        [ 0x2B71,  0x03],    #Patch
        [ 0x2B72,  0x00],    #Patch
        [ 0x2B73,  0x00],    #Patch
        [ 0x1103,  0x01],    #PatchWriteFinish
        [ 0x1113,  0x01]]    #SecureBootStart
        for pair in patch:
            try:
                self.i2cwrite(pair[0],pair[1])
            except:
                print("SPMI error, retrying...")
                self.i2cwrite(pair[0],pair[1])

        time.sleep(1)


    def writeDefaults(self):
        print("Writing default register values")
        self.i2cwrite( 0x30EB, 0x05)       #rmpsr3_0[3:0]
        self.i2cwrite( 0x30EB, 0x0C)       #rmpsr3_0[3:0]
        self.i2cwrite( 0x300A, 0xFF)       #acsen[15:8]
        self.i2cwrite( 0x300B, 0xFF)       #acsen[7:0]
        self.i2cwrite( 0x0110, 0x01)       #FRAME_SKIP_INTERVAL_b[5:0]
        self.i2cwrite( 0x0111, 0x01)       #SIFR_SKIP_RATE_b[5:0]
        self.i2cwrite( 0x0124, 0x18)       #EXCK_FREQ_b[15:8]
        self.i2cwrite( 0x0125, 0x00)       #EXCK_FREQ_b[7:0]
        self.i2cwrite( 0x014D, 0x00)       #COARSE_INTEGRATION_TIME_A_b[19:16]
        self.i2cwrite( 0x014E, 0x00)       #COARSE_INTEGRATION_TIME_A_b[15:8]
        self.i2cwrite( 0x014F, 0xF4)       #COARSE_INTEGRATION_TIME_A_b[7:0]
        self.i2cwrite( 0x0155, 0x00)       #FRM_LENGTH_A_b[19:16]
        self.i2cwrite( 0x0156, 0x0A)       #FRM_LENGTH_A_b[15:8]
        self.i2cwrite( 0x0157, 0xA1)       #FRM_LENGTH_A_b[7:0]
        self.i2cwrite( 0x015A, 0x00)       #LINE_LENGTH_A_b[15:8]
        self.i2cwrite( 0x015B, 0x62)       #LINE_LENGTH_A_b[7:0]
        self.i2cwrite( 0x015C, 0x00)       #X_ADD_STA_READ_A_b[10:8]
        self.i2cwrite( 0x015D, 0x00)       #X_ADD_STA_READ_A_b[7:0]
        self.i2cwrite( 0x015E, 0x04)       #X_ADD__READ_A_b[10:8]
        self.i2cwrite( 0x015F, 0xFF)       #X_ADD__READ_A_b[7:0]
        self.i2cwrite( 0x0160, 0x00)       #Y_ADD_STA_SCAN_A_b[11:8]
        self.i2cwrite( 0x0161, 0x00)       #Y_ADD_STA_SCAN_A_b[7:0]
        self.i2cwrite( 0x0162, 0x04)       #Y_ADD__SCAN_A_b[11:8]
        self.i2cwrite( 0x0163, 0xFF)       #Y_ADD__SCAN_A_b[7:0]
        self.i2cwrite( 0x0164, 0x00)       #Y_ADD_STA_READ_A_b[11:8]
        self.i2cwrite( 0x0165, 0x00)       #Y_ADD_STA_READ_A_b[7:0]
        self.i2cwrite( 0x0166, 0x04)       #Y_ADD__READ_A_b[11:8]
        self.i2cwrite( 0x0167, 0xFF)       #Y_ADD__READ_A_b[7:0]
        self.i2cwrite( 0x0168, 0x00)       #ADC_MODE_A_b[1:0]
        self.i2cwrite( 0x016E, 0x00)       #IMG_ORIENTATION_A_b[1:0]
        self.i2cwrite( 0x0170, 0x00)       #BINNING_MODE_A_b[2:0]
        self.i2cwrite( 0x0172, 0x00)       #BINNING_CAL_MODE_A_b
        self.i2cwrite( 0x0174, 0x00)       #DIG_SCOPE_X_STA_A_b[10:8]
        self.i2cwrite( 0x0175, 0x00)       #DIG_SCOPE_X_STA_A_b[7:0]
        self.i2cwrite( 0x0176, 0x00)       #DIG_SCOPE_Y_STA_A_b[11:8]
        self.i2cwrite( 0x0177, 0x00)       #DIG_SCOPE_Y_STA_A_b[7:0]
        self.i2cwrite( 0x0178, 0x05)       #DIG_SCOPE_X_SIZE_A_b[10:8]
        self.i2cwrite( 0x0179, 0x00)       #DIG_SCOPE_X_SIZE_A_b[7:0]
        self.i2cwrite( 0x017A, 0x05)       #DIG_SCOPE_Y_SIZE_A_b[11:8]
        self.i2cwrite( 0x017B, 0x00)       #DIG_SCOPE_Y_SIZE_A_b[7:0]
        self.i2cwrite( 0x0180, 0x01)       #ACLPMODE_A_b[1:0]
        self.i2cwrite( 0x0181, 0x00)       #DCLPMODE_A_b[1:0]
        self.i2cwrite( 0x018A, 0x00)       #SIFR_MODE_A_b
        self.i2cwrite( 0x018D, 0x00)       #SIFR_RD_OFF_A_b[19:16]
        self.i2cwrite( 0x018E, 0x00)       #SIFR_RD_OFF_A_b[15:8]
        self.i2cwrite( 0x018F, 0x00)       #SIFR_RD_OFF_A_b[7:0]
        self.i2cwrite( 0x0195, 0x00)       #COARSE_INTEG_TIME_SHORT_A_b[19:16]
        self.i2cwrite( 0x0196, 0x00)       #COARSE_INTEG_TIME_SHORT_A_b[15:8]
        self.i2cwrite( 0x0197, 0x08)       #COARSE_INTEG_TIME_SHORT_A_b[7:0]
        self.i2cwrite( 0x01C8, 0x00)       #OUTPUT_DARK_ROWS_A_b
        self.i2cwrite( 0x01D0, 0x00)       #SECURE_IMAGE_EN_A_b
        self.i2cwrite( 0x01E8, 0x00)       #COMPRESS_MODE_VC1_A_b[2:0]
        self.i2cwrite( 0x01F0, 0x82)       #MSA_MISC0_VC1_A_b[7:0]
        self.i2cwrite( 0x01F1, 0x80)       #MSA_MISC1_VC1_A_b[7:0]
        self.i2cwrite( 0x0301, 0x08)       #VTPXCK_DIV_d[5:0]
        self.i2cwrite( 0x0304, 0x02)       #PREPLLCK_VT_DIV_d[6:0]
        self.i2cwrite( 0x0306, 0x00)       #PLL_VT_MPY_d[10:8]
        self.i2cwrite( 0x0307, 0xAA)       #PLL_VT_MPY_d[7:0]
        self.i2cwrite( 0x0311, 0x03)       #PLL_VT_POWER_DOWN_EN_d[1:0]
        self.i2cwrite( 0x03E0, 0x00)       #BASECK_SEL_d
        self.i2cwrite( 0x03E2, 0x01)       #CPVBCK_MODE_d
        self.i2cwrite( 0x03E3, 0x00)       #SHUTTER_MODE_d
        self.i2cwrite( 0x0511, 0x81)       #ENHANCED_FRAME_EN_f
        self.i2cwrite( 0x0528, 0x69)       #LINK_RATE_UPPER_f[7:0]
        self.i2cwrite( 0x0529, 0x78)       #LINK_RATE_LOWER_f[7:0]
        self.i2cwrite( 0x052A, 0x00)       #LINK_RATE_LSB_f[1:0]
        self.i2cwrite( 0x0598, 0x02)       #OPB_DISABLE_VC2_f
        self.i2cwrite( 0x0550, 0x01)       #USE_ALPM
        self.i2cwrite( 0x0518, 0x0C)       #FINE_VOLTAGE_SWING
        self.i2cwrite( 0x0519, 0x0C)       #FINE_EIEOS_VOLTAGE_SWING
        self.i2cwrite( 0x051A, 0x02)       #ZOUT_SET
        self.i2cwrite( 0x051B, 0x02)       #EIEOS_ZOUT_SET
        self.i2cwrite( 0x0514, 0x03)       #PRE_POST_CURSOR_SET
        self.i2cwrite( 0x0624, 0x05)       #TP_WINDOW_WIDTH_g[10:8]
        self.i2cwrite( 0x0625, 0x00)       #TP_WINDOW_WIDTH_g[7:0]
        self.i2cwrite( 0x0626, 0x05)       #TP_WINDOW_HEIGHT_g[11:8]
        self.i2cwrite( 0x0627, 0x00)       #TP_WINDOW_HEIGHT_g[7:0]
        self.i2cwrite( 0x0524, 0x01)       #LATCH_PARAMETER
        self.i2cwrite( 0x0525, 0x01)       #LATCH_ALPM_PARAMETER
        self.i2cwrite( 0x0108, 0x02)       #MULTI_SYNC_MODE
        self.i2cwrite( 0x0149, 0x00)       #ANA_GAIN_GLOBAL_A_b[7:0]
        self.i2cwrite( 0x0600, 0x00)       #TP_MODE[8]
        self.i2cwrite( 0x0601, 0x00)       #TP_MODE[7:0]

        self.i2cread(0x1303)
        self.i2cread(0x1307)
        self.i2cread(0x130b)


    def sause(self):
        self.i2cwrite( 0x30EB ,0x05) #left # rmpsr3_0[3:0]
        self.i2cwrite( 0x30EB ,0x0C) #left # rmpsr3_0[3:0]
        self.i2cwrite( 0x300A ,0xFF) #left # acsen[15:8]
        self.i2cwrite( 0x300B ,0xFF) #left # acsen[7:0]
        self.i2cwrite( 0x0110 ,0x01) #left # FRAME_SKIP_INTERVAL_b[5:0]
        self.i2cwrite( 0x0111 ,0x01) #left # SIFR_SKIP_RATE_b[5:0]
        self.i2cwrite( 0x0124 ,0x18) #left # EXCK_FREQ_b[15:8]
        self.i2cwrite( 0x0125 ,0x00) #left # EXCK_FREQ_b[7:0]
        self.i2cwrite( 0x014D ,0x00) #left # COARSE_INTEGRATION_TIME_A_b[19:16]
        self.i2cwrite( 0x014E ,0x00) #left # COARSE_INTEGRATION_TIME_A_b[15:8]
        self.i2cwrite( 0x014F ,0xF4) #left # COARSE_INTEGRATION_TIME_A_b[7:0]
        self.i2cwrite( 0x0155 ,0x00) #left # FRM_LENGTH_A_b[19:16]
        self.i2cwrite( 0x0156 ,0x06) #left # FRM_LENGTH_A_b[15:8]
        self.i2cwrite( 0x0157 ,0x5E) #left # FRM_LENGTH_A_b[7:0]
        self.i2cwrite( 0x015A ,0x01) #left # LINE_LENGTH_A_b[15:8]
        self.i2cwrite( 0x015B ,0x47) #left # LINE_LENGTH_A_b[7:0]
        self.i2cwrite( 0x015C ,0x00) #left # X_ADD_STA_READ_A_b[10:8]
        self.i2cwrite( 0x015D ,0x00) #left # X_ADD_STA_READ_A_b[7:0]
        self.i2cwrite( 0x015E ,0x04) #left # X_ADD__READ_A_b[10:8]
        self.i2cwrite( 0x015F ,0xFF) #left # X_ADD__READ_A_b[7:0]
        self.i2cwrite( 0x0160 ,0x00) #left # Y_ADD_STA_SCAN_A_b[11:8]
        self.i2cwrite( 0x0161 ,0x00) #left # Y_ADD_STA_SCAN_A_b[7:0]
        self.i2cwrite( 0x0162 ,0x04) #left # Y_ADD__SCAN_A_b[11:8]
        self.i2cwrite( 0x0163 ,0xFF) #left # Y_ADD__SCAN_A_b[7:0]
        self.i2cwrite( 0x0164 ,0x00) #left # Y_ADD_STA_READ_A_b[11:8]
        self.i2cwrite( 0x0165 ,0x00) #left # Y_ADD_STA_READ_A_b[7:0]
        self.i2cwrite( 0x0166 ,0x04) #left # Y_ADD__READ_A_b[11:8]
        self.i2cwrite( 0x0167 ,0xFF) #left # Y_ADD__READ_A_b[7:0]
        self.i2cwrite( 0x0168 ,0x00) #left # ADC_MODE_A_b[1:0]
        self.i2cwrite( 0x016E ,0x00) #left # IMG_ORIENTATION_A_b[1:0]
        self.i2cwrite( 0x0170 ,0x00) #left # BINNING_MODE_A_b[2:0]
        self.i2cwrite( 0x0172 ,0x00) #left # BINNING_CAL_MODE_A_b
        self.i2cwrite( 0x0174 ,0x00) #left # DIG_SCOPE_X_STA_A_b[10:8]
        self.i2cwrite( 0x0175 ,0x00) #left # DIG_SCOPE_X_STA_A_b[7:0]
        self.i2cwrite( 0x0176 ,0x00) #left # DIG_SCOPE_Y_STA_A_b[11:8]
        self.i2cwrite( 0x0177 ,0x00) #left # DIG_SCOPE_Y_STA_A_b[7:0]
        self.i2cwrite( 0x0178 ,0x05) #left # DIG_SCOPE_X_SIZE_A_b[10:8]
        self.i2cwrite( 0x0179 ,0x00) #left # DIG_SCOPE_X_SIZE_A_b[7:0]
        self.i2cwrite( 0x017A ,0x05) #left # DIG_SCOPE_Y_SIZE_A_b[11:8]
        self.i2cwrite( 0x017B ,0x00) #left # DIG_SCOPE_Y_SIZE_A_b[7:0]
        self.i2cwrite( 0x0180 ,0x01) #left # ACLPMODE_A_b[1:0]
        self.i2cwrite( 0x0181 ,0x00) #left # DCLPMODE_A_b[1:0]
        self.i2cwrite( 0x018A ,0x00) #left # SIFR_MODE_A_b
        self.i2cwrite( 0x018D ,0x00) #left # SIFR_RD_OFF_A_b[19:16]
        self.i2cwrite( 0x018E ,0x00) #left # SIFR_RD_OFF_A_b[15:8]
        self.i2cwrite( 0x018F ,0x00) #left # SIFR_RD_OFF_A_b[7:0]
        self.i2cwrite( 0x0195 ,0x00) #left # COARSE_INTEG_TIME_SHORT_A_b[19:16]
        self.i2cwrite( 0x0196 ,0x00) #left # COARSE_INTEG_TIME_SHORT_A_b[15:8]
        self.i2cwrite( 0x0197 ,0x08) #left # COARSE_INTEG_TIME_SHORT_A_b[7:0]
        self.i2cwrite( 0x01C8 ,0x00) #left # OUTPUT_DARK_ROWS_A_b
        self.i2cwrite( 0x01D0 ,0x00) #left # SECURE_IMAGE_EN_A_b
        self.i2cwrite( 0x01E8 ,0x00) #left # COMPRESS_MODE_VC1_A_b[2:0]
        self.i2cwrite( 0x01F0 ,0x62) #left # MSA_MISC0_VC1_A_b[7:0]
        self.i2cwrite( 0x01F1 ,0x80) #left # MSA_MISC1_VC1_A_b[7:0]
        self.i2cwrite( 0x0301 ,0x08) #left # VTPXCK_DIV_d[5:0]
        self.i2cwrite( 0x0304 ,0x02) #left # PREPLLCK_VT_DIV_d[6:0]
        self.i2cwrite( 0x0306 ,0x00) #left # PLL_VT_MPY_d[10:8]
        self.i2cwrite( 0x0307 ,0xAA) #left # PLL_VT_MPY_d[7:0]
        self.i2cwrite( 0x0311 ,0x03) #left # PLL_VT_POWER_DOWN_EN_d[1:0]
        self.i2cwrite( 0x03E0 ,0x00) #left # BASECK_SEL_d
        self.i2cwrite( 0x03E2 ,0x01) #left # CPVBCK_MODE_d
        self.i2cwrite( 0x03E3 ,0x00) #left # SHUTTER_MODE_d
        self.i2cwrite( 0x0511 ,0x81) #left # ENHANCED_FRAME_EN_f
        self.i2cwrite( 0x0512 ,0x20) #left
        self.i2cwrite( 0x0528 ,0x1F) #left # LINK_RATE_UPPER_f[7:0]
        self.i2cwrite( 0x0529 ,0xA4) #left # LINK_RATE_LOWER_f[7:0]
        self.i2cwrite( 0x052A ,0x00) #left # LINK_RATE_LSB_f[1:0]
        self.i2cwrite( 0x0598 ,0x02) #left # OPB_DISABLE_VC2_f
        self.i2cwrite( 0x0550 ,0x00) #left # USE_ALPM
        self.i2cwrite( 0x0518 ,0x0C) #left # FINE_VOLTAGE_SWING
        self.i2cwrite( 0x0519 ,0x0C) #left # FINE_EIEOS_VOLTAGE_SWING
        self.i2cwrite( 0x051A ,0x02) #left # ZOUT_SET
        self.i2cwrite( 0x051B ,0x02) #left # EIEOS_ZOUT_SET
        self.i2cwrite( 0x0514 ,0x03) #left # PRE_POST_CURSOR_SET
        self.i2cwrite( 0x0624 ,0x05) #left # TP_WINDOW_WIDTH_g[10:8]
        self.i2cwrite( 0x0625 ,0x00) #left # TP_WINDOW_WIDTH_g[7:0]
        self.i2cwrite( 0x0626 ,0x05) #left # TP_WINDOW_HEIGHT_g[11:8]
        self.i2cwrite( 0x0627 ,0x00) #left # TP_WINDOW_HEIGHT_g[7:0]
        self.i2cwrite( 0x052C ,0x10) #left
        self.i2cwrite( 0x052D ,0x07) #left
        self.i2cwrite( 0x0524 ,0x01) #left # LATCH_PARAMETER
        self.i2cwrite( 0x0525 ,0x01) #left # LATCH_ALPM_PARAMETER
        self.i2cwrite( 0x0108 ,0x02) #left # MULTI_SYNC_MODE
        self.i2cwrite( 0x0149 ,0x00) #left # ANA_GAIN_GLOBAL_A_b[7:0]
        self.i2cwrite( 0x0600 ,0x00) #left # TP_MODE[8]
        self.i2cwrite( 0x0601 ,0x07) #left # TP_MODE[7:0]
        self.i2cwrite( 0x0500 ,0x01) #left
        self.i2cwrite( 0x0510 ,0x01) #left
