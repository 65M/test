----------- QTx Lua script--------------------------------------------------------------------------
-- Copyright (c) 2020-2022
-- All rights reserved.
--
-- Author: Hungwen Wang, Eric Wang*
-- Date: 2020.02.24
-- Description:
--     This script will compare the result from differnt CMD, and Show the test Result from TestItem
--     which might contain more than one CMD.
----------------------------------------------------------------------------------------------------
require "TimeRelated"

-- library imports
local Universal = require 'Universal.14A'

-- PDCA file write
function ReportDataToStationAndPDCA(Name, Value, Units, LowerLimit, UpperLimit)
    local IsPassed = false
    Value = tonumber(Value)
    --PrintString("ReportDataToStationAndPDCA:"..Value)
    Universal:ReportDataToStation(Name, Value, Units, LowerLimit, UpperLimit)
    IsPassed = ReportData(Name, Value, Units, LowerLimit, UpperLimit)
    return IsPassed
end

-- And logic - 0/true 1/false
-- @param LastValue
-- @param TempValue
function TestNameResultCompare(LastValue,TempValue)
    if (LastValue==1 or TempValue==1) then
        return 1
    else
        return 0
    end
end

-- Execute result of each command
-- @param ResultStr MatchResult with expectated value of current command output 
-- @param flag Flag of Matching result of the previous command output
function TestItemResultCompare(ResultStr,flag)
    local tempflag=0
    if (ResultStr~=nil) then
        tempflag=0
    else
        tempflag=1
    end

    if (flag==1 or tempflag==1) then
        return 1
    else
        return 0
    end
end

-- Execute result of each Function
-- @param FuncResultFlag 0 - pass, 1 - fail
-- @param flag The pass or fail value for the commands of the TestItem 
function FuncResultCompare(FuncResultFlag,flag)
    local tempflag=0
    if (FuncResultFlag~=nil and FuncResultFlag~=1) then
        tempflag=0
    else
        tempflag=1
    end

    if (flag==1 or tempflag==1) then
        return 1
    else
        return 0
    end
end

-- TestCoverageList import
require "CheckList.TestCoverageList_PVT"

--common
--[[
CompareMode : StrCompare:string compare
              NumCompare:number compare, judge whether the TestResult is between Min and Max value
              NumCompare_other: judge whether the TestResult is equal to the Min or Max value
              Show:Execute successfully and did't compare only print TestResult
              ProcessFail:Execute Cmd fail, only print "Fail"
Status :      1/fail 0/pass
--]]
function CompareWithTC(TestName,TestResult,CompareMode,ExecTimeStr)
    local ItemIndex
    local Name,Status,Value,LowerLimitValue,UpperLimitValue,UnitStr,ExecTime
    -- find Item in TestCoverageList according to TestName
    for i=1,#Txxx_All
    do
        if Txxx_All[i]["Name"]==TestName then
            ItemIndex=i
            break
        else
            --NO DATA
            ItemIndex=-1
        end
    end
    if ItemIndex==-1 then
        PrintString(TestName)
        PrintString("Not Found DATA in TestCoverageList")
    else
        Name=Txxx_All[ItemIndex]["Name"]
        LowerLimitValue=Txxx_All[ItemIndex]["Min"]
        UpperLimitValue=Txxx_All[ItemIndex]["Max"]
        UnitStr=Txxx_All[ItemIndex]["Unit"]
        Value=TestResult
        ExecTime=ExecTimeStr
        --"open limit" situation
        if CompareMode~="ProcessFail" and ((LowerLimitValue == nil and UpperLimitValue == nil) or (LowerLimitValue == "nil" and UpperLimitValue == "nil")) then
            if CompareMode=="NumCompare" then
                if LowerLimitValue == "nil" then LowerLimitValue = tonumber(nil) else LowerLimitValue = tonumber(LowerLimitValue) end
                if UpperLimitValue == "nil" then UpperLimitValue = tonumber(nil) else UpperLimitValue = tonumber(UpperLimitValue) end
                -- Report result to PDCA
                ReportDataToStationAndPDCA(Name,Value,UnitStr,LowerLimitValue,UpperLimitValue)
            end
            CompareMode="Show"
        end
        if CompareMode=="StrCompare" then
            if string.match(LowerLimitValue,Value) or string.match(UpperLimitValue,Value) then
                Status=0
            else
                Status=1
            end
        -- Judge whether TestResult is between Min and Max value
        elseif CompareMode=="NumCompare" then
            MinCheck=0
            MaxCheck=0
            MinValueStr=Txxx_All[ItemIndex]["Min"]
            MaxValueStr=Txxx_All[ItemIndex]["Max"]
            TestResultNumber=tonumber(TestResult)

       

            if MinValueStr~="nil" then
                MinValue=tonumber(MinValueStr)
                if (TestResultNumber >= MinValue) then
                    MinCheck=0
                else
                    MinCheck=1
                end
            end
            if MaxValueStr~="nil" then
                MaxValue=tonumber(MaxValueStr)
                if (TestResultNumber <= MaxValue) then
                    MaxCheck=0
                else
                    MaxCheck=1
                end
            end
          

            Status=TestNameResultCompare(MinCheck,MaxCheck)
            -- Report result to PDCA
            if LowerLimitValue == "nil" then LowerLimitValue = tonumber(nil) else LowerLimitValue = tonumber(LowerLimitValue) end
            if UpperLimitValue == "nil" then UpperLimitValue = tonumber(nil) else UpperLimitValue = tonumber(UpperLimitValue) end
            ReportDataToStationAndPDCA(Name,Value,UnitStr,LowerLimitValue,UpperLimitValue)
        -- Judge whether TestResult is Min or Max value 
        elseif CompareMode=="NumCompare_other" then
            MinCheck=0
            MaxCheck=0
            MinValueStr=Txxx_All[ItemIndex]["Min"]
            MaxValueStr=Txxx_All[ItemIndex]["Max"]
            TestResultNumber=tonumber(TestResult)

            MinValue=tonumber(MinValueStr)
            MaxValue=tonumber(MaxValueStr)

            if TestResultNumber == MinValue or  TestResultNumber == MaxValue then
                MinCheck=0
                MaxCheck=0
            else
                MinCheck=1
                MaxCheck=1
            end
            
            Status=TestNameResultCompare(MinCheck,MaxCheck)
            if LowerLimitValue == "nil" then LowerLimitValue = tonumber(nil) else LowerLimitValue = tonumber(LowerLimitValue) end
            if UpperLimitValue == "nil" then UpperLimitValue = tonumber(nil) else UpperLimitValue = tonumber(UpperLimitValue) end
            if Value==LowerLimitValue or Value==UpperLimitValue then
                ReportDataToStationAndPDCA(Name,Value,UnitStr,LowerLimitValue,UpperLimitValue)
            else
                ReportDataToStationAndPDCA(Name,Value,UnitStr,LowerLimitValue,LowerLimitValue)
            end

        elseif CompareMode=="Show" then
            Status=0
        elseif CompareMode=="ProcessFail" then
            Status=1
        end
        -- after Comparing and set Status value ,write to CSV file
        TestResultOutput(Name,Status,Value,LowerLimitValue,UpperLimitValue,UnitStr,ExecTime)
    end
    return Status
end

-- CSV file write
function TestResultOutput(NameStr,StatusStr,ValueStr,LowerLimitStr,UpperLimitStr,UnitStr,ExecTimeStr)
    ValueStr="\""..ValueStr.."\""
    if LowerLimitStr==nil or LowerLimitStr=="nil" then
        LowerLimitStr="NA"
    end
    if UpperLimitStr==nil or UpperLimitStr=="nil" then
        UpperLimitStr="NA"
    end
    if UnitStr==nil or UnitStr=="nil" then
        UnitStr="NA"
    end

    ---"OutputText" Remove ExecTimeStr for Mulan P1 build
    OutputText=NameStr..","..StatusStr..","..ValueStr..","..LowerLimitStr..","..UpperLimitStr..","..UnitStr..","..ExecTimeStr.."\n"
    -- OutputText=NameStr..","..StatusStr..","..ValueStr..","..LowerLimitStr..","..UpperLimitStr..","..UnitStr.."\n"

    --Shell("writefile --append --text \'"..OutputText.."\' nandfs:\\AppleInternal\\Diags\\Logs\\Smokey\\Wildfire\\"..WildFireResultFileName)
    -- Unit Test
    -- PrintString("===============CsvFileName===============")
    -- PrintString(CsvFileName)
    if CsvFileName == "WildFire_Test_Result.csv" and CsvFileCreate == 0 then
        Shell("writefile --create --text "..ToolVer.."\n nandfs:\\AppleInternal\\Diags\\Logs\\Smokey\\Wildfire\\"..CsvFileName)
        Shell("writefile --append --text "..TCVer.."\n\n nandfs:\\AppleInternal\\Diags\\Logs\\Smokey\\Wildfire\\"..CsvFileName)
        CsvFileCreate=1
    end
    Shell("writefile --append --text \'"..OutputText.."\' nandfs:\\AppleInternal\\Diags\\Logs\\Smokey\\Wildfire\\"..CsvFileName)

    -- for Output TestName which got Error during testing
    CsvWriteFlag=0

    WildFireOverallResult=TestNameResultCompare(WildFireOverallResult,StatusStr)

end
