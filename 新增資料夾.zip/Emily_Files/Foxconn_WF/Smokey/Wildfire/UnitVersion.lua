require "SearchforTarget"
require "CompareAndOutput"


-- Judge Accessory Type (AkitaE or Ecosystem) and Read corresponding SN Value
function Export_accessory_SN()
    local Flag = 0
    local FuncResultFlag = 0
    local AkitaE_SN = ""
    local retryTimes = 2
    local retryCount = 0
    CsvWriteFlagCheck()
    TestName = "Export_accessory_SN"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
  
    -- Trying to change the sequence by doing i2c -s 0 then do audio init. <rdar：//94130251>
    PrintString("\n======================================Judge_Accessory_Type======================================")
    Shell("i2c -s 0")
    MatchResult=Last.Output:match("(0x20)")

    -- PrintString("\n======================================Judge_Accessory_Type======================================")
    -- Shell("i2c -z 4 -v 0x84 0x31 0x00008C00 0x00 0x40 0x63 0x00 multiple")
    -- Shell("i2c -z 4 -v 0x84 0x31 0x0000A064 0xED 0x00 0x00 0x00 multiple")
    -- Shell("i2c -z 4 -v 0x84 0x31 0x0000A064 0xC6 0x00 0x00 0x00 multiple")
    -- Shell("i2c -z 4 -d 0x84 0x31 0x00009FD4 4 multiple")
    -- Left_strap_output=Last.Output
    -- Shell("i2c -z 4 -v 0x84 0x31 0x00008C00 0x00 0x40 0x62 0x00 multiple")
    -- Shell("i2c -z 4 -v 0x84 0x31 0x0000A064 0x00 0x00 0x00 0x00 multiple")

    -- Shell("i2c -z 4 -v 0x85 0x31 0x00008C00 0x00 0x40 0x63 0x00 multiple")
    -- Shell("i2c -z 4 -v 0x85 0x31 0x0000A064 0xED 0x00 0x00 0x00 multiple")
    -- Shell("i2c -z 4 -v 0x85 0x31 0x0000A064 0xC6 0x00 0x00 0x00 multiple")
    -- Shell("i2c -z 4 -d 0x85 0x31 0x00009FD4 4 multiple")
    -- Right_strap_output=Last.Output
    -- Shell("i2c -z 4 -v 0x85 0x31 0x00008C00 0x00 0x40 0x62 0x00 multiple")
    -- Shell("i2c -z 4 -v 0x85 0x31 0x0000A064 0x00 0x00 0x00 0x00 multiple")

    -- OTP_configuration_l =""
    -- for word in Left_strap_output:gmatch("(0x%w%w)%s+") do
    --     OTP_configuration_l =string.char(tonumber(word))..OTP_configuration_l
    -- end
    -- PrintString("OTP_configuration_l =>")
    -- PrintString(OTP_configuration_l)

    -- OTP_configuration_r =""
    -- for word in Right_strap_output:gmatch("(0x%w%w)%s+") do
    --     OTP_configuration_r =string.char(tonumber(word))..OTP_configuration_r
    -- end
    -- PrintString("OTP_configuration_l =>")
    -- PrintString(OTP_configuration_r)

    
    if MatchResult == "0x20" then
        Encoderkeycheck=0
        PrintString("\n======================================Read_AkitaE_SN======================================")
        Shell("tristar -w \"0x05 0x00\"")
        Shell("tristar --pick Bellatrix2")
        while( retryCount < retryTimes and AkitaE_SN == "" )
        do
            Shell("tristar -b \"22 100 0x7A\"")
            for word in Last.Output:gmatch("(0x%w+)") do

                AkitaE_SN = AkitaE_SN ..string.format("%c", word)
            end
            AkitaE_SN = AkitaE_SN:sub(2, 2+17)
            retryCount = retryCount +1
        end
        PrintString("AkitaE_SN => ")
        PrintString(AkitaE_SN)
        TotalExeTime=os.time() - StartTimeStr
        if #AkitaE_SN ~= 0 then
            CompareWithTC(TestName,"AkitaE_SN:"..AkitaE_SN,"Show",TotalExeTime)
            Flag = 0
        else
            CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
            AkitaE_SN="NA"
            Flag = 1
        end
        FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
        PrintString("==================================================================================================================")

        ReportAttribute("Export_accesssary_SN", "AkitaE_SN:"..AkitaE_SN)
    end

    if MatchResult==nil then
        Encoderkeycheck=1
        -- I suspect if there are some register not cleaned, so tried to do audio init before audio test again, 
        -- however this time even audio initialize fail. <rdar：//94130251>
        PrintString("\n======================================ecosystem audio_init======================================")
        Shell("wait 30000")
        Shell("csoc --on")
        Shell("csoc --load")
        Shell("csi pick CSOC-CCPU")
        Shell("csi on")
        Shell("wait 5000")
        Shell("audio -r")
        Shell("wait 5000")
        Shell("audioparam -b bora --param route-type --set --value por")
        Shell("wait 2000")

        PrintString("\n======================================Read_Puck_SN======================================")
        Shell("tristar -w \"0x05 0x00\"")
        Shell("tristar --pick Bellatrix2")
        Shell("tristar -b \"22 100 0x7A\"")
        Puck_SN=""
        for word in Last.Output:gmatch("(0x%w+)") do
            Puck_SN = Puck_SN ..string.format("%c", word)
        end
        Puck_SN = Puck_SN:sub(2, 2+16)
        PrintString("Puck_SN => ")
        PrintString(Puck_SN)
        PrintString("\n======================================Read_Right_Strap_SN======================================")
        Shell("tristar -w \"0x05 0x00\"")
        Shell("tristar --pick Leviathan")
        Shell("tristar -b \"22 100 0x7A\"")
        Right_strap_SN=""
        for word in Last.Output:gmatch("(0x%w+)") do
            Right_strap_SN = Right_strap_SN ..string.format("%c", word)
        end
        Right_strap_SN = Right_strap_SN:sub(2, 2+16)
        PrintString("Right_strap_SN => ")
        PrintString(Right_strap_SN)
          
        PrintString("\n======================================Read_Left_Strap_SN======================================")
        Shell("i2c -z 1 -v 0x81 0x10 0x60 0xE2 0x02 0x01 0x01 0x00 0x00 0x92 0x00 0x14 0xFF multiple")
        Shell("wait 1000")
        Shell("i2c -z 1 -d 0x81 0x10 0x05 1")
        Shell("i2c -z 0 -w 0x81 0x10 0x60")
        Shell("i2c -z 0 -r 0x81 0x10 21")
        Left_strap_SN=""
        for word in Last.Output:gmatch("(0x%w%w)%s+") do
            Left_strap_SN = Left_strap_SN ..string.format("%c", word)
        end
        Left_strap_SN = Left_strap_SN:sub(2, 2+16)
        PrintString("Left_strap_SN => ")
        PrintString(Left_strap_SN)

        TotalExeTime=os.time() - StartTimeStr
        if #Puck_SN ~=0 and #Left_strap_SN ~=0 and #Right_strap_SN ~= 0 then
            CompareWithTC(TestName,"Puck_SN/Left_strap_SN/Right_strap_SN:"..Puck_SN.."/"..Left_strap_SN.."/"..Right_strap_SN,"Show",TotalExeTime)
            Flag = 0
        else
            CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
            if #Puck_SN==0 then
                Puck_SN="NA"
            end
            if #Left_strap_SN==0 then
                Left_strap_SN="NA"
            end
            if #Right_strap_SN==0 then
                Right_strap_SN="NA"
            end
            Flag = 1
        end
        FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
        ReportAttribute("Export_accessory_SN", "Puck_SN/Left_strap_SN/Right_strap_SN:"..Puck_SN.."/"..Left_strap_SN.."/"..Right_strap_SN)

        PrintString("==================================================================================================================")
    end
    PrintString("Encoderkeycheck before: "..Encoderkeycheck)
    PrintString("MLBkeycheck :"..MLBkeycheck)
    --Encoderkeycheck = Encoderkeycheck or MLBkeycheck
    if Encoderkeycheck == 0 and MLBkeycheck == 0 then
        Encoderkeycheck = 0
    else
        Encoderkeycheck = 1
    end
    PrintString("Encoderkeycheck after: "..Encoderkeycheck)
    return flagToBool(FuncResultFlag)
end

-- 2020/1/25 New Add <rdar://88006237 >
-- Read AkitaE SN and report result to PDCA 
function Read_AkitaE_SN()
    local Flag = 0
    local FuncResultFlag = 0
    local AkitaE_SN = ""
    local retryTimes = 2
    local retryCount = 0
    CsvWriteFlagCheck()
    TestName = "Read_AkitaE_SN"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    Shell("tristar -w \"0x05 0x00\"")
    Shell("tristar --pick Bellatrix2")
    while( retryCount < retryTimes and AkitaE_SN == "" )
    do
        Shell("tristar -b \"22 100 0x7A\"")
        for word in Last.Output:gmatch("(0x%w+)") do
            PrintString(word)
            AkitaE_SN = AkitaE_SN ..string.format("%c", word)
        end
        AkitaE_SN = AkitaE_SN:sub(2, 2+17)
        retryCount = retryCount +1
    end
    PrintString("AkitaE_SN => ")
    PrintString(AkitaE_SN)
    TotalExeTime=os.time() - StartTimeStr
    if #AkitaE_SN ~= 0 then
        CompareWithTC(TestName,AkitaE_SN,"Show",TotalExeTime)
        Flag = 0
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
        AkitaE_SN="NA"
        Flag = 1
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")

    ReportAttribute("AkitaE_SN", AkitaE_SN)
    return flagToBool(FuncResultFlag)
end




-- read Soc properties including Vendor,Model,Revision,
function SOC_PROPERTIES()
    local Flag=0
    local FuncResultFlag=0
    CsvWriteFlagCheck()
    TestName="SOC_PROPERTIES_Vendor"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    Shell("soc -p")
    SocInfo=Last.Output
    MatchResult=SocInfo:match("vendor:%s*(%w+)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    PrintString(MatchResult)
    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestName,MatchResult,"Show",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")

    CsvWriteFlagCheck()
    TestName="SOC_PROPERTIES_Model"
    Flag=0
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    MatchResult=SocInfo:match("model:%s*(%w+)")
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)
    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestName,MatchResult,"Show",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")

    CsvWriteFlagCheck()
    TestName="SOC_PROPERTIES_Revision"
    Flag=0
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    MatchResult=SocInfo:match("revision:%s*(%w+)")
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)


    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestName,MatchResult,"Show",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")
    return flagToBool(FuncResultFlag)
end


-- read Diags-related info including Platform,Version,ImgVer,Commit,EFI_ROOT
function DiagsInfo()
    local Flag=0
    local FuncResultFlag=0
    CsvWriteFlagCheck()
    TestName="Diag_Versions_Platform"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    Shell("version")
    DiagsInfoStr=Last.Output
    MatchResult=DiagsInfoStr:match("Platform%s*%((%w+)%)")
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)

    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestName,MatchResult,"Show",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")

    CsvWriteFlagCheck()
    TestName="Diag_Versions_Version"
    Flag=0
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    MatchResult=DiagsInfoStr:match("Version%s*-%s*(%w+.%w+.%w+)")
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)
    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestName,MatchResult,"Show",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")



    TestName="EFI_Root_Check" --PreEVT
    Flag=0
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    pcall(Shell,"dir nandfs:\\AppleInternal\\Roots\\")
    --Shell("dir nandfs:\\AppleInternal\\Roots\\")
    DiagsRoot=Last.Output
    MatchResult_DiagsRoot=string.find(DiagsRoot, "LLDIAGS.plist")
    if MatchResult_DiagsRoot~=nil then
        CsvWriteFlagCheck()
        Shell("cat nandfs:\\AppleInternal\\Roots\\LLDIAGS.plist")
        DiagsInfoStr=Last.Output
        MatchResult=DiagsInfoStr:match(">(N301.%w+)<")
        PrintString(MatchResult)
        Flag=TestItemResultCompare(MatchResult,Flag)

        TotalExeTime=os.time() - StartTimeStr
        if Flag == 0 then
            CompareWithTC(TestName,MatchResult,"Show",TotalExeTime)
        else
            CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
        end
        FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
        PrintString("==================================================================================================================")
        return flagToBool(FuncResultFlag)
    end
end        


-- Read Board info including boardID,boardREV,bootCFG,
function BoardInfo()
    local Flag=0
    local FuncResultFlag=0
    CsvWriteFlagCheck()
    TestName="BOARD_ID"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    Shell("boardid")
    MatchResult=Last.Output:match("Board Id:%s*(%w+)")
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)
    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        PrintString(MatchResult)
        CompareWithTC(TestName,MatchResult,"Show",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")

    CsvWriteFlagCheck()
    TestName="BOARD_REV"
    Flag = 0
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    Shell("boardrev")
    MatchResult=Last.Output:match("Board Revision:%s*(%w+)")
    PrintString(MatchResult)
    rev = tonumber(string.sub(MatchResult, -2),16)
    PrintString(rev)
    if rev <= 9 then
        MLBkeycheck = 1
    else
        MLBkeycheck = 0
    end
    PrintString("MLBkeycheck :"..MLBkeycheck)
    Flag=TestItemResultCompare(MatchResult,Flag)
    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestName,MatchResult,"Show",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")

    CsvWriteFlagCheck()
    TestName="Boot_Cfg"
    Flag=0
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    Shell("bootcfg")
    MatchResult=Last.Output:match("Boot Configuration:%s*(%w+)")
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)
    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestName,MatchResult,"Show",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)

    PrintString("==================================================================================================================")
    return flagToBool(FuncResultFlag)
end

-- Read syscfg info including SN, MLBSN, CFG, MPN, Regn
function syscfgInfo()
    local FuncResultFlag=0
    local Flag=0
    CsvWriteFlagCheck()
    TestName="Read_SN"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    Shell("syscfg print SrNm")
    MatchResult=Last.Output:match("Serial:%s*(%w+)")
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)
    TotalExeTime=os.time() - StartTimeStr
    if Flag==0 then
        CompareWithTC(TestName,MatchResult,"Show",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")

    CsvWriteFlagCheck()
    TestName="Read_MLB_SN"
    Flag=0
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    Shell("syscfg print MLB#")
    MatchResult=Last.Output:match("^(%w+)")
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)
    TotalExeTime=os.time() - StartTimeStr
    if Flag==0 then
        CompareWithTC(TestName,MatchResult,"Show",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")

    --wait for writeing CFG info Unit to do validation
    CsvWriteFlagCheck()

    TestName="Read_MPN"
    Flag=0
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    Shell("syscfg print Mod#")
    MatchResult=Last.Output:match("^[%w-]+")
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)
    TotalExeTime=os.time() - StartTimeStr
    if Flag==0 then
        CompareWithTC(TestName,MatchResult,"Show",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")

    CsvWriteFlagCheck()
    TestName="Read_Regn"
    Flag=0
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    Shell("syscfg print Regn")
    MatchResult=Last.Output:match("(%w+[/]%w+)")
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)
    TotalExeTime=os.time() - StartTimeStr
    if Flag==0 then
        CompareWithTC(TestName,MatchResult,"Show",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")
    return flagToBool(FuncResultFlag)
end

-- DDR test
function DDRMemoryTest()
    local FuncResultFlag=0
    local Flag=0
    CsvWriteFlagCheck()
    TestName="DDR_SOC_Mem_Test"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    Shell("testmemory")
    MatchResult=Last.Output:match("(Passed)")
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)
    TotalExeTime=os.time() - StartTimeStr
    if Flag==0 then
        CompareWithTC(TestName,MatchResult,"StrCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")
    return flagToBool(FuncResultFlag)
end

-- Read sensor info
function SENSORInfo()
    local FuncResultFlag=0
    local Flag=0
    CsvWriteFlagCheck()
    TestName="SENSORInfo"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    Shell("sensor --listsensors")
    MatchResult=Last.Output:match("(OK)")
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)
    TotalExeTime=os.time() - StartTimeStr
    if Flag==0 then
        CompareWithTC(TestName,MatchResult,"StrCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")
    return flagToBool(FuncResultFlag)
end
