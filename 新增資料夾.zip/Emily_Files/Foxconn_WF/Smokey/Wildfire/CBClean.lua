----------- CBinit Lua script--------------------------------------------------------------------------
-- Copyright (c) 2020-2022
-- All rights reserved.
--
-- Author: Mulan SW Diags Hao6 Chen*
-- Date: 2021.01.11
-- Description:
--     This script was for P1 Build CB related clean
----------------------------------------------------------------------------------------------------


require "SearchforTarget"
require "CompareAndOutput"

function CBinit()
    local ResultFlags=true
    TestName="CB_init"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    local Flag=0
    StartTimeStr=CurrentTimeStr()
    Shell("cbinit")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    Shell("syscfg init")
    MatchResult=Last.Output:match("(Finish)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    FinishTimeStr=CurrentTimeStr()
    TotalExeTime=TimeCalculator(StartTimeStr,FinishTimeStr)
    if Flag==0 then
        CompareWithQTResult(TestName,"PASS","StrCompare",TotalExeTime)
    else
        CompareWithQTResult(TestName,"ProcessFail","ProcessFail",TotalExeTime)
        ResultFlags=false
    end
    PrintString("==================================================================================================================")
    return ResultFlags
end
