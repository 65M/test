---------------------------------------------------------------------------
-- Main.
-- Main lua file for Wildfire scripts.

--require "BasicInfo"
--require "ChipsetTests"
--require "SensorTests"


-- functions to run of each testsuite are defined in Main.plist
-- testsuites import
require "CommonLib"
require "CompareAndOutput"
require "TimeRelated"
require "SearchforTarget"
require "UnitVersion"
require "MokuTest"
require "IPD"
require "Encoder"
require "PearlTest"
require "X1072Test"
require "X1080Test"
require "Bora"
require "AudioTest"
require "JasperTest"
require "CameraTest"
require "IrFloodTest"
require "PwrDCRTest"
require "SilegoTest"
require "PmuTest"


-- library import
Universal = require 'Universal.14A'

local RamlogEnabled = false
local ClearRamlogEnable = true
--According to radar 102885504, add Encoderkeycheck flag
Encoderkeycheck=0
-- ToolVer
ToolVer="ToolVer,MP_v0.1.15"
TCVer="TCVer,BurnIn_WildFire_vE1.7_0818" 
WildFireExecuteStart=""
WildFireExecuteTimeStart=""
WildFireExecuteTimeFinish=""
WildFireExecuteTimeCost=0
-- if one item failed ,overall result will fail
WildFireOverallResult=0
CsvFileName="WildFire_Test_Result.csv"
CsvFileCreate=0
-- CsvWriteFlag for CSV write function when testiem fail
-- CsvWriteFlag=1:Previous one not Output to CSV
CsvWriteFlag=0
-- make sure Bora-related commands executed once
-- if execute Bora-related commands in Bora.lua, it won't do it again in X1072Test or X1080Test
Borakeycheck=0
-- ToolVer end
Motordetectionflag=0
---------------------------------------------------------------------------
----------------------------------------------------------------------------
-- Disable Ram Log clearing.
function DisableRamlogClear()
    ClearRamlogEnable = false
end

----------------------------------------------------------------------------
-- Enable Ram Log clearing.
function EnableRamlogClear()
    ClearRamlogEnable = true
end

----------------------------------------------------------------------------

local BBLibTestNodes = {}

----------------------------------------------------------------------------
-- Initialise Ram log sources.
function RamlogInit()
    pcall(Shell, "ramlog --on 5")

    Shell "consolerouter --add --src builtinEP_SMC.debug.crashlog --dest ramlog --quiet"
    Shell("consolerouter --add --src smc.debug.notifications --dest ramlog --quiet")
    Shell "consolerouter --add --src *.{error,warn,print},system.debug.{debug,error} --dest ramlog --quiet"
    Shell "consolerouter --add --src sep.debug.* --dest ramlog --quiet"
    Shell "consolerouter --add --src i2clib.debug.* --dest ramlog --quiet"

    RamlogEnabled = true
end

-- Ram log extra Init
function RamlogExtrasInit()
    -- Only if ramlog has been previously enabled
    if RamlogEnabled ~= true then
        return
    end

    -- can only be done once csoc --load occurs
    Shell "consolerouter --add --src builtinEP_CSOC-AOP.debug.{crashlog,syslog,oslog} --dest ramlog --quiet"
    Shell "consolerouter --add --src builtinEP_CSOC-CCPU.debug.{crashlog,syslog,oslog} --dest ramlog --quiet"
    Shell "consolerouter --add --src builtinEP_CSOC-ISP.debug.{crashlog,syslog,oslog} --dest ramlog --quiet"
end

-- clear Ramlog
function ClearRamlog()
    if ClearRamlogEnable and RamlogEnabled then
        pcall(Shell, "ramlog -c")
    end
end

----------------------------------------------------------------------------
-- Disable Ram Log clearing.
function DisableRamlogClear()
    ClearRamlogEnable = false
end

----------------------------------------------------------------------------
-- Enable Ram Log clearing.
function EnableRamlogClear()
    ClearRamlogEnable = true
end

-- Initializing Supress Console Module
function SuppressConsole()
    PrintString("*** Initializing Supress Console Module ***")
    pcall(Shell, "ramlog --on 1")

    pcall(Shell, "consolerouter --add --src *.{print,error,warn,debug0} --dest ramlog --quiet")
    pcall(Shell, "consolerouter --rm --src *.print --dest serial --quiet")
    pcall(Shell, "consolerouter --add --src TestConsole.print --dest serial --quiet")
    pcall(Shell, "consolerouter --add --src TestSmokey.print --dest serial --quiet")

    RamlogEnabled = true
end

-- Reset Console Module and cleaning up
function ResetConsole()
    PrintString("*** Reset Console Module and cleaning up... ***")
    pcall(Shell, "consolerouter --reset")
    pcall(Shell, "ramlog --off")
    PrintString("*** All cleaned up. ***")
end

-- Error Handler for Wildfire Tests.
-- @param TestName Add description.
function ErrorHandler(TestName)
    if RamlogEnabled then
        PrintString("Dumping ramlog")
        pcall(Shell, "consoleformat --en --sink serial -o ts,func")
        pcall(Shell, "consoleformat --en --sink smokey -o ts,func")
        pcall(Shell, "camisp --dbgfw pull")
        pcall(Shell, "csi flush_logs")
        pcall(Shell, "ramlog --dump")
        pcall(Shell, "consoleformat --dis --sink serial -o ts,func")
        pcall(Shell, "consoleformat --dis --sink smokey -o ts,func")
    end
end

----------------------------------------------------------------------------
-- Result Handler for Wildfire Tests.
-- @param When Add description.
-- @param What Add description.
-- @param NodeId Add description.
-- @param TestIteration Add description.
-- @param Name Add description.
function CustomResultHandler(When, What, NodeId, TestIteration, Name)
    local Passed = true
    local EndOfAction = false
    local TestName

    if (When == "Initial") then
        local ParentTbl = GetSequenceNodeIds("ByNodeName", "BBLibTests")
        if (ParentTbl) and (#ParentTbl == 1) then
            BBLibTestNodes = GetSequenceNodeIds("ByParentNodeId", ParentTbl[1])
        else
            PrintString("Did not find BBLibTests")
        end
        -- If GlobalArguments.SuppressConsole is enabled, suppress the console output.
        if (GlobalArguments.SuppressConsole == "true") then
            SuppressConsole()
        end
        return
    elseif (When == "Intermediate") then
        if (Universal:IsValuePresent(BBLibTestNodes, NodeId)) then
            return
        end
        TestName = GetSequenceNodeProperties(NodeId)[NodeId].NodeName
        if (What == "TestResult") then
            local ThisTestResults = GetSequenceTestResults(NodeId)[NodeId]
            Passed = ThisTestResults[TestIteration].Passed
            EndOfAction = true
        elseif (What == "TestData") then
            local ThisTestData = GetSequenceTestData(NodeId, "ByDataName", Name)[NodeId]
            Passed = ThisTestData[Name][TestIteration].Passed
        elseif (What == "Attribute") then
            PrintString("Skipping custom attribute results")
        else
            return false
        end
    elseif (When == "Final") then
        -- If GlobalArguments.SuppressConsole is enabled, reset console output and clean up.
        if (GlobalArguments.SuppressConsole == "true") then
            ResetConsole()
        end
        return
    else
        return false
    end

    if Passed == false then
        PrintString(string.format("Calling error handler because %s %s %s Failure",
            TestName or "<No TestName>", Name or "<No ReportName>", When, What))
        ErrorHandler(TestName)
    end

    if EndOfAction or Passed == false then
        ClearRamlog()
    end
end
