require "SearchforTarget"
require "CompareAndOutput"

function PearlTests()
  CsvWriteFlagCheck()
  TestName="PearlTests_Command"
  local Flag=0
  local FuncResultFlag=0
  PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
  StartTimeStr=os.time()
  Shell("upy nandfs:\\AppleInternal\\Diags\\Scripts\\N301\\pearlTest.py")
  ExecResult=Last.Output
  cmdResult=pyFileProcessor(ExecResult)
  PearlPyCoommandExecFlag=PearlResultProcessor(cmdResult)
  if PearlPyCoommandExecFlag=="FAIL" then
    FuncResultFlag=1
  end
  TotalExeTime=os.time() - StartTimeStr
  CompareWithTC(TestName,PearlPyCoommandExecFlag,"StrCompare",TotalExeTime)
  PrintString("==================================================================================================================")
  return flagToBool(FuncResultFlag)
end
