require "SearchforTarget"
require "CompareAndOutput"
require "TimeRelated"
require "Burnin"

function byte2bin(n)
    local t = {}
    for i=7,0,-1 do
        t[#t+1] = math.floor(n / 2^i)
        n = n % 2^i
    end
    return table.concat(t)
end

function X1072_Flash_Check_L()
    CsvWriteFlagCheck()
    TestName="X1072_Flash_L"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    local Flag = 0
    local FuncResultFlag=0
    -- Shell("syscfg print CFG#")
    -- MatchResult=Last.Output:match("%w+/%w+[-]%w+/%w+/%w+/(%w+)")
    -- PrintString(MatchResult)
    -- character=string.sub(MatchResult, 2 ,2)
    -- PrintString(character)
    


    Shell("spi -t 9 2 0x5 0x00")
    TestdataName="X1072_SPI_Flash_Check_L_read"
    MatchResult=Last.Output:match("Received:%s%w+.0x(%w+)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    MatchResult=tonumber(MatchResult,16)
    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0  then
        CompareWithTC(TestdataName,MatchResult,"NumCompare",TotalExeTime)
    else
        CompareWithTC(TestdataName,"ProcessFail","ProcessFail",TotalExeTime)
    end

    StartTimeStr=os.time()
    Shell("spi -t 9 1 0x6")
    TestdataName="X1072_SPI_Flash_Check_L_write"
    MatchResult=Last.Output:match("Received:%s0x(%w+)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    TotalExeTime=os.time() - StartTimeStr
    MatchResult=tonumber(MatchResult,16)
    if Flag == 0 then
        CompareWithTC(TestdataName,MatchResult,"NumCompare",TotalExeTime)
    else
        CompareWithTC(TestdataName,"ProcessFail","ProcessFail",TotalExeTime)
    end

    Shell("spi -t 9 2 0x5 0x00")
    TestdataName="X1072_SPI_Flash_Check_L_readback"
    MatchResult=Last.Output:match("Received:%s%w+.0x(%w+)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    MatchResult=tonumber(MatchResult,16)
    MatchResult=byte2bin(MatchResult)
    MatchResult=tonumber(string.sub(MatchResult, -2,-2))
    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestdataName,MatchResult,"NumCompare",TotalExeTime)
    else
        CompareWithTC(TestdataName,"ProcessFail","ProcessFail",TotalExeTime)
    end

    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestName,"PASS","Show",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")
    return flagToBool(FuncResultFlag)
end

function X1072_Flash_Check_R()
    CsvWriteFlagCheck()
    TestName="X1072_Flash_R"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    local Flag = 0
    local FuncResultFlag=0
    
    Shell("spi -t 2 2 0x5 0x00")
    TestdataName="X1072_SPI_Flash_Check_R_read"
    MatchResult=Last.Output:match("Received:%s%w+.0x(%w+)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    MatchResult=tonumber(MatchResult,16)
    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestdataName,MatchResult,"NumCompare",TotalExeTime)
    else
        CompareWithTC(TestdataName,"ProcessFail","ProcessFail",TotalExeTime)
    end


    Shell("spi -t 2 1 0x6")
    TestdataName="X1072_SPI_Flash_Check_R_write"
    MatchResult=Last.Output:match("Received:%s0x(%w+)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    MatchResult=tonumber(MatchResult,16)
    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestdataName,MatchResult,"NumCompare",TotalExeTime)
    else
        CompareWithTC(TestdataName,"ProcessFail","ProcessFail",TotalExeTime)
    end

    Shell("spi -t 2 2 0x5 0x00")
    TestdataName="X1072_SPI_Flash_Check_R_readback"
    MatchResult=Last.Output:match("Received:%s%w+.0x(%w+)")
    Flag=TestItemResultCompare(MatchResult,Flag)
  
    MatchResult=tonumber(MatchResult,16)
    MatchResult=byte2bin(MatchResult)
    MatchResult=tonumber(string.sub(MatchResult, -2,-2))
    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
       CompareWithTC(TestdataName,MatchResult,"NumCompare",TotalExeTime)
    else
        CompareWithTC(TestdataName,"ProcessFail","ProcessFail",TotalExeTime)
    end

    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestName,"PASS","Show",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")
    return flagToBool(FuncResultFlag)
end

function X1072_Init()
    CsvWriteFlagCheck()
    local OsLogFolder = GenerateOsLogFolderName()

    TestName="X1072_Init"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    local Flag = 0
    local FuncResultFlag=0
    -- From Coco thomas_pham
    --this bootargs cmd needs to be set at the very first time Bora fw is loaded in the test sequence

    if Borakeycheck==0 then
        Shell("csoc --on -a 1 -g \"speedy_debug=2\"")
        MatchResult=Last.Output:match("(OK)")
        Flag=TestItemResultCompare(MatchResult,Flag)

    	Shell("csoc --load_firmware")
    	MatchResult=Last.Output:match("(OK)")
    	Flag=TestItemResultCompare(MatchResult,Flag)

        RamlogExtrasInit() 

        -- Shell("csi pick CSOC-CCPU")
        -- Shell("csi set_log_dir " .. OsLogFolder)
        -- pcall(Shell,"csi on")
        -- Shell("wait 20000")
    end
    Shell("csi pick CSOC-CCPU")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    Shell("csi set_log_dir " .. OsLogFolder)
    Shell("csi on")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    Shell("wait 20000")
    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestName,MatchResult,"StrCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")
    return flagToBool(FuncResultFlag)
end

-- main.plist remove X1072_TCON_Health_Check_WRT_EN_High Test during Mulan PreEVT Build
function X1072_TCON_Health_Check_WRT_EN_High()
    CsvWriteFlagCheck()
    local OsLogFolder = GenerateOsLogFolderName()

    TestName="X1072_TCON_WRT_EN_High"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    local Flag = 0
    local FuncResultFlag=0

    Shell("reg select csoc")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    Shell("reg write  0x23c100024 0x842003")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)


    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestName,MatchResult,"Show",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)

    PrintString("==================================================================================================================")
    return flagToBool(FuncResultFlag)
end

function X1072_TCON_Health_Check_Display_On()
    CsvWriteFlagCheck()
    TestName="X1072_TCON_Display_On"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    local Flag = 0
    local FuncResultFlag=0
    local OsLogFolder = GenerateOsLogFolderName()

    --pcall(Shell,"dcp on")-- radar:\86717304 At EVT, Staten DCP does not do anything in EFI
    --MatchResult=Last.Output:match("(OK)")
    --Flag=TestItemResultCompare(MatchResult,Flag)

    --Shell("display --pick internal")
    --MatchResult=Last.Output:match("(OK)")
    --Flag=TestItemResultCompare(MatchResult,Flag)

    -- comment Parese function
    --pcall(Shell,"display --on")
    -- MatchResult=Last.Output:match("(OK)")
    -- Flag=TestItemResultCompare(MatchResult,Flag)


    Shell("msg --id 0 --init-master")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    
    Shell("msg --id 0 --intr-en")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    Shell("msg --id 9 --init-slave 0")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    Shell("msg --id 10 --init-slave 0")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    Shell("msg --id 9 --set-config slave --assert-dur 24 --offset 369456")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    Shell("msg --id 10 --set-config slave --assert-dur 24 --offset 369456")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    Shell("msg --id 0 --set-config master --assert-dur 24 --frame-dur 266657")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    Shell("msg --id 0 --sync-start")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)


    Shell("csi pick CSOC-DCP")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    Shell("csi set_log_dir " .. OsLogFolder)
    Shell("csi on")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    Shell("csi pick CSOC-DCP2")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    Shell("csi set_log_dir " .. OsLogFolder)
    Shell("csi on")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)


    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestName,MatchResult,"Show",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")
    return flagToBool(FuncResultFlag)
end


function X1072_Flash_Check_Display_Health()
    CsvWriteFlagCheck()
    TestName="X1072_read_chip_state"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    local Flag = 0
    local FuncResultFlag=0
    Shell("reg select speedy")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    Shell("reg read 0x40063e20 4")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)


    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestName,MatchResult,"Show",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")

    CsvWriteFlagCheck()
    TestName="X1072_module_serial_number"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    local Flag = 0
    local FuncResultFlag=0
    Shell("reg read 0x40025898 180")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    Shell("reg read 0x4002594c 180")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)


    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestName,MatchResult,"Show",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")

    CsvWriteFlagCheck()
    TestName="X1072_ECID_revision"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    local Flag = 0
    local FuncResultFlag=0
    Shell("reg read 0x40023d48 64")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)


    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestName,MatchResult,"Show",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")

    CsvWriteFlagCheck()
    TestName="X1072_Sylvester_ECID"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    local Flag = 0
    local FuncResultFlag=0
    Shell("reg read 0x40063e90 64")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)


    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestName,MatchResult,"Show",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")

    CsvWriteFlagCheck()
    TestName="X1072_ADDR_training_stats"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    local Flag = 0
    local FuncResultFlag=0
    Shell("reg read 0x40063C78 48")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)


    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestName,MatchResult,"Show",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")

    CsvWriteFlagCheck()
    TestName="X1072_ADDR_error_stats"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    local Flag = 0
    local index=1
    local FuncResultFlag=0
    Shell("reg read 0x40063c64 20")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    TotalExeTime=os.time() - StartTimeStr
    for MatchResult in string.gmatch(Last.Output, "=>%s0x(%w+)") do
        if index==1 then
            TestdataName="X1072_ADDR_error_stats_1"
            MatchResult=tonumber(MatchResult,16)
            CompareWithTC(TestdataName,MatchResult,"NumCompare",TotalExeTime)
            index=index+1
            PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
        else
            TestdataName="X1072_ADDR_error_stats_"..index
            MatchResult=tonumber(MatchResult,16)
            CompareWithTC(TestdataName,MatchResult,"NumCompare",TotalExeTime)
            index=index+1
            PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
        end
    end

    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestName,"OK","Show",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")

    CsvWriteFlagCheck()
    TestName="X1072_TCON_speedy_FW_ver"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    local Flag = 0
    local FuncResultFlag=0
    Shell("reg read 0x40063E04")
    MatchResult=Last.Output:match("=>%s0x(%w+)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    MatchResult=tonumber(MatchResult,16)

    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestName,MatchResult,"NumCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")

    CsvWriteFlagCheck()
    TestName="X1072_speedy_patch_code_ver"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    local Flag = 0
    local FuncResultFlag=0
    Shell("reg read 0x40063E0C")
    MatchResult=Last.Output:match("=>%s0x(%w+)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    MatchResult=tonumber(MatchResult,16)

    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestName,MatchResult,"NumCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")

    CsvWriteFlagCheck()
    TestName="X1072_speedy_OTP_FW_ver"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    local Flag = 0
    local FuncResultFlag=0
    Shell("reg read 0x40023D70")
    MatchResult=Last.Output:match("=>%s0x(%w+)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    MatchResult=tonumber(MatchResult,16)

    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestName,MatchResult,"NumCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")
    return flagToBool(FuncResultFlag)
end
function x1072PmicRead(regAddr)
    local Flag=0
    Shell("reg list; reg select speedy")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    Shell("reg write 0x40060040 0x0") --clean up
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    Shell("reg write 0x40060000 0x60 0x00 0x00 0x00")--set I2C address
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    Shell("reg write 0x40060004 "..regAddr.." 0x00 0x00 0x00")--set register offset
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    Shell("reg write 0x40060008 0x1 0x00 0x00 0x00")--read 1 byte
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    Shell("reg write 0x4006000c 0x80 0x00 0x06 0x40")--read out result point pointer
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    Shell("reg write 0x50000060 0x00 0x00 0x06 0x40")--setup input arg pointer
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    Shell("reg write 0x50000064 0x40 0x00 0x06 0x40")--setup mbox result pointer
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    Shell("reg write 0x50000068 0x1A 0x01 0x02 0x00")--select rom function smb read 282 = 0x11a
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    Shell("reg write 0x5000006c 0x01")-- run ROM function
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    Shell("wait 10")
    Shell("reg read 0x40060040 1")--read result
    MatchResult=Last.Output:match("(OK)")
    reg40 = Last.Output:match("=>%s+(0x%w+)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    Shell("reg read 0x40060044 1")
    MatchResult=Last.Output:match("(OK)")
    reg44 = Last.Output:match("=>%s+(0x%w+)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    Shell("reg read 0x40060080 1")--read result from this I2c transaction 
    reg80 = Last.Output:match("=>%s+(0x%w+)")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    return Flag,reg40,reg44,reg80
end

function x1072_PMIC_Fault_Check()

    local FuncResultFlag=0
    for i = 24,32 do
        item = string.format("0x%X", tostring(i))
        CsvWriteFlagCheck()
        TestName = "x1072_PMIC_Fault_Check_"..item
        PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
        StartTimeStr=os.time()
        SubOverAll,reg40,reg44,reg80 = x1072PmicRead(item)
        TotalExeTime=os.time() - StartTimeStr
        if SubOverAll == 0 then
            CompareWithTC(TestName,"PASS","StrCompare",TotalExeTime)
        else
            CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
            FuncResultFlag = 1
        end
        PrintString("==================================================================================================================")

        CsvWriteFlagCheck()
        SubTestName = TestName.."_40"
        PrintString("\n\n====================================== Test Item :"..SubTestName.." ======================================")
        StartTimeStr=os.time()
        TotalExeTime=os.time() - StartTimeStr
        if reg40 ~= nil then
            CompareWithTC(SubTestName,tonumber(reg40),"NumCompare",TotalExeTime)
        else
            CompareWithTC(SubTestName,"ProcessFail","ProcessFail",TotalExeTime)
            FuncResultFlag = 1
        end
        PrintString("==================================================================================================================")

        CsvWriteFlagCheck()
        SubTestName = TestName.."_44"
        PrintString("\n\n====================================== Test Item :"..SubTestName.." ======================================")
        StartTimeStr=os.time()
        TotalExeTime=os.time() - StartTimeStr
        if reg44 ~= nil then
            CompareWithTC(SubTestName,tonumber(reg44),"NumCompare",TotalExeTime)
        else
            CompareWithTC(SubTestName,"ProcessFail","ProcessFail",TotalExeTime)
            FuncResultFlag = 1
        end
        PrintString("==================================================================================================================")

        CsvWriteFlagCheck()
        SubTestName = TestName.."_80"
        PrintString("\n\n====================================== Test Item :"..SubTestName.." ======================================")
        StartTimeStr=os.time()
        TotalExeTime=os.time() - StartTimeStr
        if reg80 ~= nil then
            CompareWithTC(SubTestName,tonumber(reg80),"NumCompare",TotalExeTime)
        else
            CompareWithTC(SubTestName,"ProcessFail","ProcessFail",TotalExeTime)
            FuncResultFlag = 1
        end
        PrintString("==================================================================================================================")
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,SubOverAll)
    return flagToBool(FuncResultFlag)
end

function X1072ModuleSN()
    local Side = "both"
    if GlobalArguments ~= nil then
        Side = GlobalArguments.Side or Side
    end

    if Side == "both" then
      X1072ReadSN("left", true)
      X1072ReadSN("right", false)
    else
      X1072ReadSN(Side, true)
    end
end

function DCR_Setup()
    TestName="Set_BL"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    Shell("display --pick CSOC-DCP")
    Shell("display --on")
    Shell("bl --nits 70 --select 0x3")
    Shell("wait 1000")
    PrintString("==================================================================================================================")
end

function White_Pattern_Light_Up()
    TestName="White_Right_Light_UP"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    Shell('afk -r CSOC-DCP -n disp0-service --buffer 8 -s "0xC1 0x01 0x0a 0x00 0x00 0x6b 0x00 0x00 0x00 0xFF 0xFF 0xFF 0x00 0x00 0x00 0x00 0x00"')
    PrintString("==================================================================================================================")

    TestName="White_Left_Light_UP"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    Shell('afk -r CSOC-DCP2 -n disp0-service --buffer 8 -s "0xC1 0x01 0x0a 0x00 0x00 0x6b 0x00 0x00 0x00 0xFF 0xFF 0xFF 0x00 0x00 0x00 0x00 0x00"')
    PrintString("==================================================================================================================")
end

function White_Pattern_Test()
    local Flag=0
    local FuncResultFlag=0
    CsvWriteFlagCheck()
    TestName="White_Pattern_PDR"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    Shell("smc fread PDR4")
    White_PDR_Result=Last.Output:match("PDR4 = (%w+.%w+)")
    Flag=TestItemResultCompare(White_PDR_Result,Flag)
    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestName,White_PDR_Result,"NumCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")

    CsvWriteFlagCheck()
    TestName="White_Pattern_VDR"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    Shell("smc fread VDR4")
    White_VDR_Result=Last.Output:match("VDR4 = (%w+.%w+)")
    Flag=TestItemResultCompare(White_VDR_Result,Flag)
    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestName,White_VDR_Result,"NumCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")

    CsvWriteFlagCheck()
    TestName="White_Pattern_IDR"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    Shell("smc fread IDR4")
    White_IDR_Result=Last.Output:match("IDR4 = (%w+.%w+)")
    Flag=TestItemResultCompare(White_IDR_Result,Flag)
    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestName,White_IDR_Result,"NumCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")

    CsvWriteFlagCheck()
    TestName="White_Pattern_PDL"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    Shell("smc fread PDL4")
    White_PDL_Result=Last.Output:match("PDL4 = (%w+.%w+)")
    Flag=TestItemResultCompare(White_PDL_Result,Flag)
    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestName,White_PDL_Result,"NumCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")
    
    CsvWriteFlagCheck()
    TestName="White_Pattern_VDL"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    Shell("smc fread VDL4")
    White_VDL_Result=Last.Output:match("VDL4 = (%w+.%w+)")
    Flag=TestItemResultCompare(White_VDL_Result,Flag)
    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestName,White_VDL_Result,"NumCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")

    CsvWriteFlagCheck()
    TestName="White_Pattern_IDL"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    Shell("smc fread IDL4")
    White_IDL_Result=Last.Output:match("IDL4 = (%w+.%w+)")
    Flag=TestItemResultCompare(White_IDL_Result,Flag)
    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestName,White_IDL_Result,"NumCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")


end

function Black_Pattern_Light_Up()
    TestName="Black_Right_Light_Up"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    Shell('afk -r CSOC-DCP -n disp0-service --buffer 8 -s "0xC1 0x01 0x0a 0x00 0x00 0x6b 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00"')
    PrintString("==================================================================================================================")

    TestName="Black_Left_Light_Up"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    Shell('afk -r CSOC-DCP2 -n disp0-service --buffer 8 -s "0xC1 0x01 0x0a 0x00 0x00 0x6b 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00"')
    PrintString("==================================================================================================================")
end

function Black_Pattern_Test()
    local Flag=0
    local FuncResultFlag=0
    CsvWriteFlagCheck()
    TestName="Black_Pattern_PDR"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    Shell("smc fread PDR4")
    Black_PDR_Result=Last.Output:match("PDR4 = (%w+.%w+)")
    Flag=TestItemResultCompare(Black_PDR_Result,Flag)
    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestName,Black_PDR_Result,"NumCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")

    CsvWriteFlagCheck()
    TestName="Black_Pattern_VDR"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    Shell("smc fread VDR4")
    Black_VDR_Result=Last.Output:match("VDR4 = (%w+.%w+)")
    Flag=TestItemResultCompare(Black_VDR_Result,Flag)
    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestName,Black_VDR_Result,"NumCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")

    CsvWriteFlagCheck()
    TestName="Black_Pattern_IDR"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    Shell("smc fread IDR4")
    Black_IDR_Result=Last.Output:match("IDR4 = (%w+.%w+)")
    Flag=TestItemResultCompare(Black_IDR_Result,Flag)
    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestName,Black_IDR_Result,"NumCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")

    CsvWriteFlagCheck()
    TestName="Black_Pattern_PDL"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    Shell("smc fread PDL4")
    Black_PDL_Result=Last.Output:match("PDL4 = (%w+.%w+)")
    Flag=TestItemResultCompare(Black_PDL_Result,Flag)
    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestName,Black_PDL_Result,"NumCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")

    CsvWriteFlagCheck()
    TestName="Black_Pattern_VDL"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    Shell("smc fread VDL4")
    Black_VDL_Result=Last.Output:match("VDL4 = (%w+.%w+)")
    Flag=TestItemResultCompare(Black_VDL_Result,Flag)
    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestName,Black_VDL_Result,"NumCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")

    CsvWriteFlagCheck()
    TestName="Black_Pattern_IDL"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    Shell("smc fread IDL4")
    Black_IDL_Result=Last.Output:match("IDL4 = (%w+.%w+)")
    Flag=TestItemResultCompare(Black_IDL_Result,Flag)
    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestName,Black_IDL_Result,"NumCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")
    return Black_VDR_Result,Black_IDR_Result,Black_VDL_Result,Black_IDL_Result

end

function X1072_Power_Off()
    local Flag=0
    local FuncResultFlag=0
    CsvWriteFlagCheck()
    TestName="X1072_Power_Off"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    Shell("display --pick CSOC-DCP")
    Shell("display --off")
    PrintString("==================================================================================================================")
    
    Shell("display --pick CSOC-DCP2")
    Shell("display --off")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestName,MatchResult,"StrCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")
    return flagToBool(FuncResultFlag)
end

function X1072_DCR_Test()
    DCR_Setup()
    White_Pattern_Light_Up()
    --hw.time.ustall(4000000) -- Wait for 4s
    Shell("wait --wfi 4000")
    White_Pattern_Test()
    Black_Pattern_Light_Up()
    --hw.time.ustall(4000000) -- Wait for 4s
    Shell("wait --wfi 4000")
    Black_Pattern_Test()
    local Flag=0
    local FuncResultFlag=0
    CsvWriteFlagCheck()
    TestName="DCR_3V8_Left"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    LeftV = math.abs(tonumber(White_VDL_Result) - tonumber(Black_VDL_Result))
    print("LeftV:  "..LeftV)
    LeftI = math.abs(tonumber(White_IDL_Result) - tonumber(Black_IDL_Result))
    print("LeftI :" ..LeftI)
    DCR_3V8_LeftResult = LeftV / LeftI
    --if tostring(DCR_3V8_LeftResult) == "nan" then error("DCR_3V8_LeftResult is NaN value") end
    if (DCR_3V8_LeftResult ~= DCR_3V8_LeftResult) then error("DCR_3V8_LeftResult is NaN value") end
    --To fix the infinity DCR value KY 09/19
    if DCR_3V8_LeftResult == math.huge then DCR_3V8_LeftResult = 99999 end
    print(DCR_3V8_LeftResult)
    --DCR_3V8_LeftResult = tonumber(DCR_3V8_LeftResult)

    Flag=TestItemResultCompare(DCR_3V8_LeftResult,Flag)
    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestName,DCR_3V8_LeftResult,"NumCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")
    local Flag=0
    TestName="DCR_3V8_Right"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    RightV = math.abs(tonumber(White_VDR_Result) - tonumber(Black_VDR_Result))
    RightI = math.abs(tonumber(White_IDR_Result) - tonumber(Black_IDR_Result))
    DCR_3V8_RightResult = RightV / RightI
    --DCR_3V8_RightResult = tonumber(DCR_3V8_RightResult)
    --if tostring(DCR_3V8_RightResult) == "NaN" then error("DCR_3V8_RightResult is NaN value") end
    if (DCR_3V8_RightResult ~= DCR_3V8_RightResult) then error("DCR_3V8_RightResult is NaN value") end
    --To fix the infinity DCR value KY 09/19
    if DCR_3V8_RightResult == math.huge then DCR_3V8_RightResult = 99999 end
    Flag=TestItemResultCompare(DCR_3V8_RightResult,Flag)
    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestName,DCR_3V8_RightResult,"NumCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")

    X1072_Power_Off()
    return flagToBool(FuncResultFlag)
end






