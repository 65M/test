--------------------------------------------------------------------------------
-- ChipsetTests.
-- This file contains tests for the following components :
-- 1. Lynx

---

-- Run self test for Lynx through SEP.
function LynxSelfTest()
    -- Lynx/lynt selftest is expected to take 76 seconds
    local LyntTimeout = 120000000 -- 120 seconds
    local EepromPassed, EepromErr
    local LynxPassed, LynxErr

    -- Init sep, this still passes if it was already initialized
    Shell("sep --init --wait_for_ready")

    -- Make sure lynx is active and not in standby
    Shell("sep -e lynx lynw")

    -- Clear the console, so we just see self test results after the next command
    Shell("sep -c")

    -- <rdar://problem/41370949> Test station changes for Lynx factory tests
    -- Run the EEPROM self test, default 20s timeout is enough for the expected ~6 second test time
    EepromPassed, EepromErr = pcall(Shell, "time sep -e lynx epst")

    -- Dump the EEPROM self test results
    Shell("sep -c")

    -- Run the Lynx self test, overriding the default 20s timeout
    LynxPassed, LynxErr = pcall(Shell, "time sep -e lynx lynt --timeout "..LyntTimeout)

    -- Dump the self test results
    Shell("sep -c")

    assert(EepromPassed, tostring(EepromErr))
    assert(LynxPassed, tostring(LynxErr))
end

