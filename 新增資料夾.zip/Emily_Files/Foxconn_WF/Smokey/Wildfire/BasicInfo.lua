---------------------------------------------------------------------------
-- BasicInfo.
-- This file contains platform specific tests, structures and functions.

---------------------------------------------------------------------------
-- Get the basic information about the DUT and the SW running on it.
function GetDeviceInfo()
    require "Burnin"

    -- Diags Version
    Shell "version"

    Shell "boardrev"
    Shell "sn"
    Shell "syscfg print MLB#"

    -- NAND related
    Shell "blockdevice"
    Shell "nandsize"
    Shell "nandcsid"

    -- Soc specific
    Shell "chipid"
    GetSocRevision()

end

