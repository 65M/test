----------- QTx Lua script--------------------------------------------------------------------------
-- Copyright (c) 2020-2022
-- All rights reserved.
--
-- Author: Hungwen Wang, Eric Wang*
-- Date: 2020.09.21
-- Description:
--     This script include all function which relate to "Search"
----------------------------------------------------------------------------------------------------


require "CheckList.CompassCheckList"
require "CheckList.GyroCheckList"
require "CheckList.AccelCheckList"

function DecimaltoBits(num)
    local t={}
    while num>0 do
        rest=num%2
        RestStr=string.format("%u",rest)
        table.insert(t,1,RestStr)
        num=(num-rest)/2
    end
    --if Address not 8 bit, will add o at pos 0 until  Address is 8 bit
    while #t<8 do
        table.insert(t,1,0)
    end
    --return table.concat(t) ====string
    return t --return table
end

function CompassSelfTestLogCheckFunction(LogStr,Choice,ItemList)
    local LocalList
    local ResultFlag=0
    local SearchResultList={}
    if Choice =="Compass1" then
        LocalList=Compass1CheckSelfTestList
    elseif Choice =="Compass2" then
        LocalList=Compass2CheckSelfTestList
    end
    for i=1,#LocalList
    do
        PrintString("====================================== Test Item :"..ItemList[i].."======================================")
        TempList={}
        TempStartTimeStr=CurrentTimeStr()
        TempAns=SearchSelfTestValue(LogStr,LocalList[i][1],LocalList[i][2])

        TempFinishTimeStr=CurrentTimeStr()
        TempTotalExeTime=TimeCalculator(TempStartTimeStr,TempFinishTimeStr)
        if TempAns~=nil then
            ResultFlag=CompareWithQTResult(ItemList[i],TempAns,"NumCompare",TempTotalExeTime)
        else
            ResultFlag=CompareWithQTResult(ItemList[i],"ProcessFail","ProcessFail",TempTotalExeTime)
        end
        PrintString("==================================================================================================================")
    end
    return ResultFlag
end

function SearchSelfTestValue(LogStr,ItemName,TargetStr)
    local Start,Stop,Ans
    Start,Stop,Ans=string.find(LogStr,"("..TargetStr..")")
    --PrintString(Ans)
    if Ans~=nil then
        Start,Stop,Ans=string.find(LogStr,"([-]?%w+[.]%w+)",Stop+1)
        --PrintString(Ans)
    else
        PrintString("In SearchSelfTestValue Function, Something Wrong")
    end
    --ShowTestItemResult(ItemName.." = "..Ans)
    return Ans
end

function SearchLPMorLNMLogFunction(LogStr,ComponentName,ModeChoice,TestItemStrList)
    --PrintString(ComponentName)
    if LogStr~=nil then
        local TempTimeStart,TempTimeFinish,TempExeTime
        local LocalList
        local SearchResultList={}
        if ModeChoice=="LPM" then
            if ComponentName =="Compass1" then
                LocalList=Compass1CheckLPMTest
            elseif ComponentName =="Compass2" then
                LocalList=Compass2CheckLPMTest
            elseif ComponentName =="Gyro1" then
                LocalList=Gyro1CheckLPMTest
            elseif ComponentName =="Gyro2" then
                LocalList=Gyro2CheckLPMTest
            elseif ComponentName =="Accel1" then
                LocalList=Accel1CheckLPMTest
            elseif ComponentName =="Accel2" then
                LocalList=Accel2CheckLPMTest
            elseif ComponentName =="Gyro3" then
                LocalList=Gyro3CheckLPMTest
            elseif ComponentName =="Gyro4" then
                LocalList=Gyro4CheckLPMTest
            elseif ComponentName =="Accel3" then
                LocalList=Accel3CheckLPMTest
            elseif ComponentName =="Accel4" then
                LocalList=Accel4CheckLPMTest
            end
        elseif ModeChoice=="LNM" then
            if ComponentName =="Compass1" then
                LocalList=Compass1CheckLNMTest
            elseif ComponentName =="Compass2" then
                LocalList=Compass2CheckLNMTest
            end
        end
        for i=1,#LocalList
        do
            PrintString("\n\n====================================== Test Item :"..TestItemStrList[i].." ======================================")
            TempTimeStart=CurrentTimeStr()
            TempAns=SearchTestValue(LogStr,LocalList[i][1],LocalList[i][2],LocalList[i][3])
            TempTimeFinish=CurrentTimeStr()
            --update 20201104
            TempExeTime=TimeCalculator(TempTimeStart,TempTimeFinish)
            CompareWithQTResult(TestItemStrList[i],TempAns,"NumCompare",TempExeTime)
            PrintString("==================================================================================================================")
        end
        return 0
    else
        for i=1,#LocalList
        do
            PrintString("\n\n====================================== Test Item :"..TestItemStrList[i].." ======================================")
            CompareWithQTResult(TestItemStrList[i],"ProcessFail","ProcessFail",0)
            PrintString("==================================================================================================================")
        end
        return 1
    end
end

function SearchTestValue(LogStr,ItemName,TargetStr,TargetStrXYZ)
    local Start,Stop,Ans
    --Search target "-" need add "%" ="%-"
    if TargetStr=="std-dev" then
        NewStr=string.match(TargetStr,"(%w+)")
        Start,Stop,Ans=string.find(LogStr,"("..NewStr..")")
    else
        Start,Stop,Ans=string.find(LogStr,"("..TargetStr..")")
    end
    if Ans~=nil then
        Start,Stop,Ans=string.find(LogStr,"("..TargetStrXYZ..")",Stop+1)
        Start,Stop,Ans=string.find(LogStr,"([-]?%d+[.]?%d+)",Stop+1)
        --PrintString(Ans)
    else
        PrintString("In SearchTestValue Function, Something Wrong")
    end
    --ShowTestItemResult(ItemName.." = "..Ans)
    return Ans
end


function SearchNVMOutputFunction(NVMLogStr,ComponentName)
    local InputList
    local ResultList={}
    if ComponentName=="juliet" then
        InputList=JulietTestItemList
    elseif ComponentName=="titus" then
        InputList=TitusTestItemList
    end
    for i=1,#InputList
    do
        PrintString("\n\n====================================== Test Item :"..InputList[i][1].." ======================================")
        StartTimeStr=CurrentTimeStr()
        ReStr=SearchNVMOutputValue(NVMLogStr,InputList[i][2],InputList[i][3],InputList[i][4])
        FinishTimeStr=CurrentTimeStr()
        TotalExeTime=TimeCalculator(StartTimeStr,FinishTimeStr)
        CompareWithQTResult(InputList[i][1],ReStr,"StrCompare",TotalExeTime)
        PrintString("==================================================================================================================")
    end
end

function TargeCatchFromTargerLine(LineStr,Pos)
    count=-1
    for word in string.gmatch(LineStr, "%w+")
    do
        if count==Pos then
          PrintString(word)
          return word
        end
        count=count+1
    end
end

function SearchNVMOutputValue(NvmLogStr,Address,BitRangeStart,BitRangeStop)
    AddressDecimal=string.format("%d",Address)
    TargetPos=tonumber(AddressDecimal)%8
    AddressHead=string.format("0x%X",tonumber(AddressDecimal)-TargetPos)
    --retrive target line
    TargetLineStartPos=string.find(NvmLogStr,AddressHead.." : ")
    if TargetLineStartPos~=nil then
      --PrintString(" TargetLineStartPos ",TargetLineStartPos)
      TargetLineEndPos=string.find(NvmLogStr,"\n",TargetLineStartPos)
      TargetLineStr=string.sub(NvmLogStr,TargetLineStartPos,TargetLineEndPos-1)
      --PrintString(" TargetLineStr ",TargetLineStr)
    --retrive target line end

      --retrive target from target line
      Target=TargeCatchFromTargerLine(TargetLineStr,TargetPos)
      Target=string.format("%d",Target)
      --PrintString("Target ",Target)
      Target = bit32.extract(Target, BitRangeStart, (BitRangeStop-BitRangeStart+1))
      --PrintString("After extract ", Target)
      return Target
    else
      return "Fail catch TargetLineStartPos"
    end

end

function SearchRegValue(LogStr,SearchTarget)
    Start,Stop,Ans=string.find(LogStr,"("..SearchTarget..")")
    Start,Stop,Ans=string.find(LogStr,"(0x%w+)",Stop+1)
    return Ans
end


function SearchBluetoothFW(LogStr)
  --firmware-filename: "BCM4387B0_17.1.88.105_PCIE_Thelonious_rFEM_MFG_USI_20191010.bin"
  local FWStr=""
  local vendorStr=""
  local modelStr=""
  vendorStr=string.match(LogStr,"vendor:%s*.(%w+).")
  modelStr=string.match(LogStr,"model:%s*.(%w+).")
  FWStr=vendorStr.."("..modelStr..")"
  --FWStr=string.match(LogStr,"firmware[-]filename: (.+).bin")
  --PrintString(FWStr)
  return FWStr
end

function SearchWifiFW(LogStr)
  --firmware-filename: "Thelonious_20_10_349_12_B0.bin"
  local vendorStr=""
  local modelStr=""
  local FWStr=""
  --FWStr=string.match(LogStr,"firmware[-]filename: (.+).bin")--for pp1
  --PrintString(FWStr)
  vendorStr=string.match(LogStr,"vendor:%s*.(%w+).")
  modelStr=string.match(LogStr,"model:%s*.(%w+).")
  FWStr=vendorStr.."("..modelStr..")"
  return FWStr
end
