require 'hw'

local kGPIOPortReset = "Soc"
local kGPIOPinReset = 45

local kGPIOPortDFU = "Soc"
local kGPIOPinDFU = 107

local kGPIOPortCS = "Soc"
local kGPIOPinCS = 49

local kSPISpeed = 1000000
local kSPIChannel = 3

local kSPIModeTable = {ActiveLevel=1, EdgeMissing=1, SlaveMode=0, RxCaptureRising=0, LittleEndian=0, DataWidth8=1, DataWidth16=0, DataWidth32=0}

local SOF = 0x5a
local ACK = 0x79
local NACK = 0x1f

local kCommandGet = 0x00
local kCommandGetVersion = 0x01
local kCommandGetID = 0x02
local kCommandReadMemory = 0x11
local kCommandGo = 0x21
local kCommandWriteMemory = 0x31
local kCommandErase = 0x44
local kCommandWriteProtect = 0x63
local kCommandWriteUnprotect = 0x73
local kCommandReadoutProtect = 0x82
local kCommandReadoutUnprotect = 0x92

local kBlockSize = 64
local kAppAddress = 0x8000000
local kSectorSize = 128 -- a "sector" in the bootloader doc actually refers to a "page" in the reference manual. wtf.
local kFlashWriteTime = 800  -- datasheet shows Tprog=3.2 ms, but bootloader appears to support direct polling after shorter stalls
local kWriteMemoryDataDelay = 1000  -- datasheet shows a 1 ms delay between address and data ACK, but doesn't explain which scenarios require this
local kFlashEraseDelay = 100000

-- Bootloader docs:
-- AN2606: General vendor bootloader
-- AN4286: SPI bootloader

local function MCUReset(assertReset)
    hw.gpio.set_output(kGPIOPortReset, kGPIOPinReset, assertReset and 0 or 1)
end

local function ForceDFU()
    hw.gpio.set_output(kGPIOPortDFU, kGPIOPinDFU, 1)
    MCUReset(true)
    hw.time.ustall(50000)
    MCUReset(false)
end

local function CS(assertCS)
    hw.gpio.set_output(kGPIOPortCS, kGPIOPinCS, assertCS and 0 or 1)
end

local function ConfigSPI()
    hw.spi.on(kSPIChannel)
    hw.spi.set_configuration(kSPIChannel, kSPISpeed, kSPIModeTable)
end

local function PrintSPI(mosi, miso)
    mosiStr = "        Sent [" .. #mosi .. "]: "
    for kk, vv in ipairs(mosi) do
        mosiStr = mosiStr .. string.format("0x%02x", vv) .. " "
    end

    misoStr = "    Received [" .. #mosi .. "]: "
    for kk, vv in ipairs(miso) do
        misoStr = misoStr .. string.format("0x%02x", vv) .. " "
    end

    PrintString(mosiStr)
    PrintString(misoStr)
end

local function WaitForACK(timeout)
    timeout = timeout or 64
    attempts = 0
    while attempts < timeout do
        attempts = attempts + 1
        miso = hw.spi.receive(kSPIChannel, 1)
        miso = miso[1]
        if miso == ACK then
            hw.spi.send(kSPIChannel, {ACK}, 1)
            break
        elseif miso == NACK then
            break
        end
    end
    if attempts >= timeout then
        PrintString("WaitForACK timed out after " .. attempts .. " of " .. timeout .. " attempts ")
        miso = NACK
    end
    return miso
end

-- Add this directly to payloads if bootloader ACK response time is fixed (to simplify polling logic)
local function AddSyncFrame(mosi, padding)
    padding = padding or 2
    while padding >= 1 do
        mosi[#mosi + 1] = 0x00
        padding = padding - 1
    end
    mosi[#mosi + 1] = ACK
end

local function SendSynchro()
    CS(true)
    hw.spi.send(kSPIChannel, {SOF}, 1)
    result = WaitForACK()
    CS(false)

    if result ~= ACK then
        error("    Result: " .. string.format("0x%02x", result))
    end
end

-- todo: use input dictionary
local function Command(code, payloads, numPayloads, readLength, ackPayloads, ackResponse)
    local mosi = {SOF, code, bit32.bxor(code, 0xff)}
    local result = ACK
    local output = nil

    CS(true)
    hw.spi.send(kSPIChannel, mosi, #mosi)
    result = WaitForACK()

    if result == NACK then 
        CS(false)
        error("Timed out sending command frame")
        --return nil, true
    end

    if payloads ~= nil then
        for ii, payload in ipairs(payloads) do
            mosi = {}
            for _,vv in ipairs(payload) do
                table.insert(mosi, vv)
            end
            hw.spi.send(kSPIChannel, mosi, #mosi)
            if ackPayloads ~= nil then
                ackPayload = ackPayloads[ii]
                if ackPayload then
                    result = WaitForACK(ackPayload["timeout"])
                    if result == NACK then 
                        CS(false)
                        error("Timed out sending command payload " .. ii .. " of " .. #payloads)
                        --return nil, true
                    end
                    if ackPayload["postPollDelay"] then
                        hw.time.ustall(ackPayload["postPollDelay"])
                    end
                end
            end
        end
    end

    if readLength ~= 0 then
        miso = hw.spi.receive(kSPIChannel, readLength)
        output = {table.unpack(miso)}
    end

    if ackResponse then
        if ackResponse["prePollDelay"] then
            hw.time.ustall(ackResponse["prePollDelay"])
        end
        result = WaitForACK(ackResponse["timeout"])
        if result == NACK then 
            CS(false)
            error("Timed out waiting for response")
            --return nil, true
        end
        if ackResponse["postPollDelay"] then
            hw.time.ustall(ackResponse["postPollDelay"])
        end
    else
        result = ACK
    end
    CS(false)

    return output, result ~= ACK
end

local function GetVersion()
    local output = Command(kCommandGetVersion, nil, 0, 3, nil, {})

    major = bit32.rshift(bit32.band(output[2], 0xf0), 4)
    minor = bit32.band(output[2], 0xf)

    return major, minor
end

local function GetID()
    local output = Command(kCommandGetID, nil, 0, 5, nil, {})
    local pid = bit32.lshift(output[3], 8) + output[4]

    return pid
end

local function ReadMemory(startAddress, count)
    local payload = {}
    local swapped = hw.helper.cpu_to_be32(startAddress)
    local csum = 0
    local nbytes = count

    for ii = 1,4 do
        byte = bit32.band(swapped, 0xff)
        csum = bit32.bxor(csum, byte)

        payload[#payload + 1] = byte
        swapped = bit32.rshift(swapped, 8)
    end
    payload[#payload + 1] = csum

    AddSyncFrame(payload)

    payload[#payload + 1] = nbytes - 1
    payload[#payload + 1] = bit32.bxor(nbytes - 1, 0xff)

    local output = Command(kCommandReadMemory, {payload}, 1, nbytes + 1, {{}}, false)
    return {table.unpack(output, 2, #output)}
end

local function ReadMemory32(startAddress, count)
    local output = ReadMemory(startAddress, count * 4)

    if #output % 4 ~= 0 then
        error("ReadMemory32 must be word aligned")
    end

    local values = {}

    for ii = 1, #output / 4 do
        local value = output[(ii - 1) * 4 + 1]
        value = value + bit32.lshift(output[(ii - 1) * 4 + 2], 8)
        value = value + bit32.lshift(output[(ii - 1) * 4 + 3], 16)
        value = value + bit32.lshift(output[(ii - 1) * 4 + 4], 24)
        values[ii] = value
    end

    return values
end

local function SectorErase(sectorStart, sectorCount)
    local payloadPages = {}
    local payloadData = {}

    payloadPages[#payloadPages + 1] = bit32.band(bit32.rshift(sectorCount - 1, 8), 0xff)
    payloadPages[#payloadPages + 1] = bit32.band(sectorCount - 1, 0xff)
    payloadPages[#payloadPages + 1] = bit32.bxor(payloadPages[1], payloadPages[2])

    -- For sector count < 256, this will always return zero
    local csum = bit32.bxor(payloadPages[1], payloadPages[2], payloadPages[3])

    for ii = 1 + sectorStart, sectorCount + sectorStart do
        msb = bit32.band(bit32.rshift(ii - 1, 8), 0xff)
        lsb = bit32.band(ii - 1, 0xff)
        csum = bit32.bxor(csum, msb, lsb)

        payloadData[#payloadData + 1] = msb
        payloadData[#payloadData + 1] = lsb
    end
    payloadData[#payloadData + 1] = csum

    -- todo: set timeout as a function of sector count
    local startTime = hw.time.usec()
    Command(kCommandErase, {payloadPages, payloadData}, 2, 0, {{}, nil}, {timeout = 524288})
    local endTime = hw.time.usec()
    PrintString("    Erase operation completed in " .. endTime - startTime .. " microseconds for " .. sectorCount .. " sector(s), starting with sector " .. sectorStart)
end

local function WriteMemory(address, data)
    local payloadAddress = {}
    local payloadData = {}
    local swapped = hw.helper.cpu_to_be32(address)
    local csum = 0

    for ii = 1,4 do
        byte = bit32.band(swapped, 0xff)
        csum = bit32.bxor(csum, byte)

        payloadAddress[#payloadAddress + 1] = byte
        swapped = bit32.rshift(swapped, 8)
    end
    payloadAddress[#payloadAddress + 1] = csum

    -- todo: check for valid block size
    payloadData[#payloadData + 1] = #data - 1

    csum = #data - 1

    for _,vv in ipairs(data) do
        table.insert(payloadData, vv)
        csum = bit32.bxor(csum, vv)
    end
    payloadData[#payloadData + 1] = csum

    Command(kCommandWriteMemory, {payloadAddress, payloadData}, 2, 0, {{postPollDelay = kWriteMemoryDataDelay}, nil}, {timeout = 4096, prePollDelay = kFlashWriteTime})
end

local function Program(fh, address, verify)
    local blocks = {}

    while true do
        local block = fh:read(kBlockSize)
        if not block then break end
        blocks[#blocks + 1] = table.pack(block:byte(1, kBlockSize))
    end

    PrintString("    Number of " .. kBlockSize .. " blocks: " .. #blocks)

    for blockNum, block in ipairs(blocks) do
        -- Confirm that block is cleared before writing
        local zeros = ReadMemory(address, #block)
        for ii, vv in ipairs(zeros) do
            if vv ~= 0 then
                error("Overwriting non-zero memory value (" ..string.format("0x%x", vv) ..  ") at " .. string.format("0x%x", address))
            end
        end

        WriteMemory(address, block)
        if verify then
            readback = ReadMemory(address, #block)
            if #block ~= #readback then
                error("Write and read length do not match (" .. #block .. " != " .. #readback .. ")")
            end
            local foundError = false
            for ii, vv in ipairs(block) do
                if vv ~= readback[ii] then
                    foundError = true
                end
            end
            if foundError then
                print("Detected mismatch at " .. string.format("0x%x", address))
            end
        end

        if blockNum % 128 == 0 then
            PrintString("    Completed: " .. blockNum .. " of " .. #blocks)
        end

        address = address + kBlockSize
    end
    PrintString("    Completed: " .. #blocks .. " of " .. #blocks)
end

local function WriteUnprotect()
    Command(kCommandWriteUnprotect, nil, 1, 0, nil, {})
end

 function main()
    local binFilename = "nandfs:\\usr\\standalone\\firmware\\t804-ofw\\t804-ofw.bin"

    PrintString("Reading firmware binary at " .. binFilename)
    local fh = assert(io.open(binFilename, "rb"))
    local binSize = fh:seek("end")

    fh:seek("set", 0)

    PrintString("Force MCU to enter vendor bootloader")
    ForceDFU()

    hw.time.ustall(10000)

    PrintString("Configuring SPI host interface")
    ConfigSPI()

    PrintString("Send synchro byte")
    SendSynchro()

    PrintString("\nGetting bootloader version")
    local major, minor = GetVersion()
    PrintString("Version: " .. major .. "." .. minor)

    PrintString("\nGetting MCU product ID")
    local pid = GetID()
    PrintString("Product ID: " .. string.format("0x%x", pid))

    local sectorStart = 0
    local sectorEraseCount = math.ceil(binSize / kSectorSize)
    PrintString("\nErasing " .. sectorEraseCount .. " flash sector(s)")
    SectorErase(sectorStart, sectorEraseCount)
    -- todo: leave this as a debug option
    -- while sectorStart < sectorEraseCount do
    --     SectorErase(sectorStart, 1)
    --  sectorStart = sectorStart + 1
    -- end

    -- This should be redundant since the bootloader has already reported the completion status by this point.
    -- PrintString("    Waiting an additional " .. kFlashEraseDelay .. " microseconds for mass erase to complete")
    -- hw.time.ustall(kFlashEraseDelay)

    -- PrintString("Disabling write protection")
    -- WriteUnprotect()

    PrintString("\nProgramming flash")
    Program(fh, kAppAddress, true)

    fh:close()
    hw.time.ustall(500000)

    hw.gpio.set_output(kGPIOPortDFU, kGPIOPinDFU, 0)
    MCUReset(true)
    MCUReset(false)
end


