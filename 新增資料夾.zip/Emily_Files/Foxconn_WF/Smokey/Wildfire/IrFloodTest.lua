require "SearchforTarget"
require "CompareAndOutput"
require "CommonLib"

function IrFloodTests()
  CsvWriteFlagCheck()
  TestName="IrFloodTests_Command"
  local SplitTable = {}
  local SEnd=-1
  local Flag=0
  local FuncResultFlag=0
  local temp =0
  local count =0
  local CommandResult="PASS"
  local LimitResult="PASS"
  PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
  StartTimeStr=os.time()
  Shell("upy nandfs:\\AppleInternal\\Diags\\Scripts\\N301\\irfloodTest.py")
  ExecResult=Last.Output
  -- PrintString("====mokuTests.py Output====")
  -- PrintString(ExecResult)
  -- PrintString("====mokuTests.py Output====")
  cmdResult=pyFileProcessor(ExecResult)
  IrFloodPyCoommandExecFlag=IrFloodResultProcessor(cmdResult)
  if IrFloodPyCoommandExecFlag=="FAIL" then
    FuncResultFlag=1
  end
  TotalExeTime=os.time() - StartTimeStr
  CompareWithTC(TestName,IrFloodPyCoommandExecFlag,"StrCompare",TotalExeTime)
  PrintString("==================================================================================================================")
  return flagToBool(FuncResultFlag)
end
