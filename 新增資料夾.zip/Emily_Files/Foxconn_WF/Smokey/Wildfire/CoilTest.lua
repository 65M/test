
require "SearchforTarget"
require "CompareAndOutput"


function CheckCFG()
    local Flag1=0
    Shell("syscfg print CFG#")
    CFG=string.match(Last.Output,"%d/(%w+)/%d+")
    local str=string.match(CFG,"(%w)$")
    if str=="J" then
        Flag1=1
    elseif	CFG=="FB04DTCC" or CFG=="FB05DTFC" or CFG=="FG03DTCC" then
        Flag1=1
    else
        Flag1=0
    end
    return Flag1
end


function Mag_Tracking()
    local Flag=0
    local MatchResult=""
    local TestNameTable={}
    local CoilPassTable={
    "INFO: MCU BOOT TEST",
    "INFO: MCU HW RESET TEST",
    "INFO: MCU CRYSTAL TEST",
    "INFO: MCU TIMESYNC TEST",
    "INFO: MCU IRQ TEST",
    "INFO: BB TEST",
    "COIL DRIVE:",
    }

    local CoilNumberTable={
    {"Coil_Info_FW_Version","INFO: FW VERSION:"},
    {"Coil_Vset_5_Vs_Vout","Vset: 5.0  vs. Vout:"},
    {"Coil_Vset_6_Vs_Vout","Vset: 6.0  vs. Vout:"},
    {"Coil_Vset_7_Vs_Vout","Vset: 7.0  vs. Vout:"},
    {"Coil_Vset_8_Vs_Vout","Vset: 8.0  vs. Vout:"},
    {"Coil_Vset_9_Vs_Vout","Vset: 9.0  vs. Vout:"},
    {"Coil_Vset_10_Vs_Vout","Vset: 10.0  vs. Vout:"},
    {"Coil_dc","dc ="},
    {"Coil_amplitude","amplitude: ="},
	}

    TestName="Coil"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=CurrentTimeStr()
    local CFGFlag=CheckCFG()
    local TempLog=""
    local ResultFlag=0
    local Flag=0
    TestNameTable1=CoilPassTable
    if CFGFlag==1 then
        Shell("upy nandfs:\\AppleInternal\\Diags\\Scripts\\Q100\\t804_efi_diags.py")
        TempLog=Last.Output
        for i=1,#TestNameTable1
        do
            MatchResult=TempLog:match(TestNameTable1[i].."%s+.%s(PASS)")
            Flag=TestItemResultCompare(MatchResult,Flag)
            FinishTimeStr=CurrentTimeStr()
            TotalExeTime=TimeCalculator(StartTimeStr,FinishTimeStr)
            if Flag==0 then
                ResultFlag=CompareWithQTResult(TestNameTable1[i],MatchResult,"StrCompare",TotalExeTime)
            else
                ResultFlag=CompareWithQTResult(TestNameTable1[i],"ProcessFail","ProcessFail",TotalExeTime)
            end
            Flag=TestItemResultCompareCheck(ResultFlag,Flag)
            PrintString("==================================================================================================================")
        end

        TestNameTable2=CoilNumberTable
        for j=1,#TestNameTable2
        do
			      PrintString("\n\n====================================== Test Item :"..TestNameTable2[j][1].." ======================================")
            MatchResult=TempLog:match(TestNameTable2[j][2].."%s+(%S+)")

        	  MatchResult=tonumber(MatchResult)--eliminate \n
        	  FinishTimeStr=CurrentTimeStr()
            TotalExeTime=TimeCalculator(StartTimeStr,FinishTimeStr)
        	  if MatchResult~= nil then
        		    ResultFlag=CompareWithQTResult(TestNameTable2[j][1],MatchResult,"Show",TotalExeTime)
            else
                ResultFlag=CompareWithQTResult(TestNameTable2[j][1],"ProcessFail","ProcessFail",TotalExeTime)
            end
            Flag=TestItemResultCompareCheck(ResultFlag,Flag)
        end
    else
        Flag=TestItemResultCompare(CFGFlag,Flag)
    	  FinishTimeStr=CurrentTimeStr()
    	  TotalExeTime=TimeCalculator(StartTimeStr,FinishTimeStr)
        CompareWithQTResult(TestName,"Pass","StrCompare",TotalExeTime)
    end
    return flagToBool(Flag)

end
