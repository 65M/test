HydraTestList={
    {"%(7%-bit%) 0x1A","%(8%-bit%) 0x34"},
    {"Data:  0x89"},
    {"Data:  0x82"},
    {"Data:  0x00"}
}

I2CSweepTest={
    {"I2C Sweep_s0","i2c -s 0",{"%(7%-bit%) 0x38"}},
    {"I2C Sweep_s","i2c -s 4",{"%(7%-bit%) 0x49","%(7%-bit%) 0x4B"}},
    {"I2C Sweep_s5","i2c -s 5",{"%(7%-bit%) 0xE","%(7%-bit%) 0xF"}},
    {"I2C Sweep_s6","i2c -s 6",{"%(7%-bit%) 0x29"}},
    {"I2C Sweep_s7","i2c -s 7",{"%(7%-bit%) 0x1D"}},
    {"I2C Sweep_s8","i2c -s 8",{"%(7%-bit%) 0x38"}},
    {"I2C Sweep_s11","i2c -s 11",{"%(7%-bit%) 0x01","%(7%-bit%) 0x6F"}},
}
