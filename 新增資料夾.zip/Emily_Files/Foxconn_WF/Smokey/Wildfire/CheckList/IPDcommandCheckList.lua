IPDcommandlist={
"sensor --sel encoder1 --set rate 50",
"sensorreg --sel encoder1 --write 0x0F 0x04",
"sensorreg --sel encoder1 --write 0x75 0x03",
"sensor --sel motor1 --exectest set --testopts 0x48 2 0x20,0x03",
"sensor --sel motor1 --exectest get --testopts 0x48",
"sensor --sel encoder1 --exectest set --testopts 0x4F 1 1",
"sensor --sel motor1 --exectest set --testopts 0x4A 1 0",
"sensor --sel encoder2 --set rate 50",
"sensorreg --sel encoder2 --write 0x0F 0x04",
"sensorreg --sel encoder2 --write 0x75 0x03",
"sensor --sel motor2 --exectest set --testopts 0x48 2 0x20,0x03",
"sensor --sel motor2 --exectest get --testopts 0x48",
"sensor --sel encoder2 --exectest set --testopts 0x4F 1 1",
"sensor --sel motor2 --exectest set --testopts 0x4A 1 0",
"smc write F1Md 1",
"smc fwrite F1Tg 7199",
"smc write F0Md 1",
"smc fwrite F0Tg 7199",
}


