----------- QTx Lua script--------------------------------------------------------------------------
-- Copyright (c) 2020-2022
-- All rights reserved.
--
-- Author: Hungwen Wang, Eric Wang*
-- Date: 2020.03.03
-- Description:
--     This script was for Time related function,
--     CurrentTimeStr(): it could retrive Current Time in the unit
--     CovertToTimeStamp(TimeStr): convert "Time" to right format
--     TimeCalculator(StartTime,FinishTime): it could Calc time gap between (StartTime,FinishTime)
----------------------------------------------------------------------------------------------------
function StartTimer()
		DisableUart()
		WildFireExecuteStart=os.time()
		local WildFireStartTime=nil
		WildFireExecuteTimeStart=CurrentTimeStr()
    --RTC_Time: 1970.1.1.2.24.33
    for word in string.gmatch(WildFireExecuteTimeStart, "%d+") do
        if WildFireStartTime==nil then
            WildFireStartTime=word
        else
            WildFireStartTime=WildFireStartTime.."_"..word
        end
    end
		CsvFileName=WildFireStartTime.."_"..CsvFileName

    PrintString("Create Test Result CSV -> "..CsvFileName)
    Shell("writefile --create --text "..ToolVer.."\n nandfs:\\AppleInternal\\Diags\\Logs\\Smokey\\Wildfire\\"..CsvFileName)
    Shell("writefile --append --text "..TCVer.."\n\n nandfs:\\AppleInternal\\Diags\\Logs\\Smokey\\Wildfire\\"..CsvFileName)
		--- Check Unit could support rtc properly, and readd "ExecuteTime" for Mulan P2 build?
		Shell("writefile --append --text 'TestName,Status,Value,LowLimit,UpperLimit,Unit,Time\n' nandfs:\\AppleInternal\\Diags\\Logs\\Smokey\\Wildfire\\"..CsvFileName)
    -- Shell("writefile --append --text 'TestName,Status,Value,LowLimit,UpperLimit,Unit\n' nandfs:\\AppleInternal\\Diags\\Logs\\Smokey\\Wildfire\\"..CsvFileName)
end
-- --Comment below and wait to solve issue radar 79072497
-- function CovertToTimeStamp(TimeStr)
-- 	local TimeFormat=''
--   	local yyyy,mm,dd,HHour,MMin,SSec = TimeStr:match('%s(%d+).(%d+).(%d+).(%d+).(%d+).(%d+)')
--   	local TimeFormat = os.time({year=yyyy, month=mm, day=dd, hour=HHour, min=MMin, sec=SSec})
-- 	--PrintString (TimeFormat)
-- 	return TimeFormat
-- end
--
-- function TimeCalculator(StartTime,FinishTime)
--   Start=CovertToTimeStamp(StartTime)
--   --PrintString(Start)
--   Finish=CovertToTimeStamp(FinishTime)
--   --PrintString(Finish)
--   local TimeDiff = Finish - Start
--   --PrintString(TimeDiff)
--   return TimeDiff
-- end

-- --Comment above and wait to solve issue radar 79072497


function CovertToTimeStamp(TimeStr)
	local TimeFormat=''
	local yyyy,mm,dd,HHour,MMin,SSec = TimeStr:match('%s(%d+).(%d+).(%d+).(%d+).(%d+).(%d+)')
  PrintString("===========RTC-Time Parse Output==========")
	PrintString(yyyy)
	PrintString(mm)
	PrintString(dd)
	PrintString(HHour)
	PrintString(MMin)
	PrintString(SSec)
  PrintString("===========RTC-Time Parse Output==========")
	local TimeFormat = os.time({year=yyyy, month=mm, day=dd, hour=HHour, min=MMin, sec=SSec})
  PrintString("===========Variable TimeFormat==========")
  PrintString(TimeFormat)
  PrintString("===========Variable TimeFormat==========")

	return TimeFormat
end

function TimeCalculator(StartTime,FinishTime)
  PrintString("===========Original StartTime and FinishTime==========")
	PrintString(StartTime)
	PrintString(FinishTime)
  PrintString("===========Original StartTime and FinishTime==========")
  Start=CovertToTimeStamp(StartTime)
  PrintString("===========Converted Variable Start==========")
  PrintString(Start)
  PrintString("===========Converted Variable Start==========")

  Finish=CovertToTimeStamp(FinishTime)
  PrintString("===========Converted Variable Finish==========")
  PrintString(Finish)
  PrintString("===========Converted Variable Finish==========")

  local TimeDiff = Finish - Start
  PrintString("===========Variable TimeDiff==========")
  PrintString(TimeDiff)
  PrintString("===========Variable TimeDiff==========")

  return TimeDiff
	-- return 0
end

function DisableUart()
	Shell("consolesinkctrl --dis --sink uart")
	PrintString("*** disable UART before test Start ***")
end

function CurrentTimeStr()
    Shell("rtc --get")
    return Last.Output
	--return "RTC_Time: 2020.12.23.0.17.52"
end

function WaitForSecond(WaitingTime)
    local WaitingCmd="wait "..WaitingTime
    PrintString("*** get into Waiting ***")
    PrintString(WaitingCmd)
    Shell(WaitingCmd)
end

function StopTimer()
		CsvWriteFlagCheck()
    OverallResultStr=""
    PASSorFail=""
    TotalExeTimeStr=""
		WildFireExecuteTimeCost=os.time()-WildFireExecuteStart
    TotalExeTimeStr=WildFireExecuteTimeCost.." (s)"
    PrintString("Total Time= "..TotalExeTimeStr)
    if WildFireOverallResult==0 then
        PASSorFail="PASS"
    elseif WildFireOverallResult==1 then
        PASSorFail="FAIL"
    else
        PASSorFail="Wrong Wildfire_OverallResult Value"
    end
    OverallResultStr="END_TEST_Smokey_Wildfire,"..WildFireOverallResult..","..PASSorFail..",Total Time,"..TotalExeTimeStr
    --Shell("writefile --append --text \'"..OverallResultStr.."\' nandfs:\\AppleInternal\\Diags\\Logs\\Smokey\\Wildfire\\"..WildFireResultFileName)
    Shell("writefile --append --text \'"..OverallResultStr.."\' nandfs:\\AppleInternal\\Diags\\Logs\\Smokey\\Wildfire\\"..CsvFileName)
end
