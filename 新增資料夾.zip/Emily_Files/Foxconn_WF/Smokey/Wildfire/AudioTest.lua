---@diagnostic disable: redefined-local
-- test imports
require "SearchforTarget"
require "CompareAndOutput"
require "TimeRelated"
require "CommonLib"

-- Audio Initialization
-- CsvWriteFlagCheck：CsvWriteFlag for CSV write function when testiem fail
function Audio_Initialization()
    CsvWriteFlagCheck()         
    local Flag=0
    local FuncResultFlag=0
    local OsLogFolder = GenerateOsLogFolderName()  -- generate OsLogFolder
    TestName="Audio_Initialization"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()  -- get current time

    Shell("tristar --pick Leviathan; tristar -p")
    MatchResult=Last.Output:match("(ID Connected    = 0x1)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    Shell("csoc --on")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)  --compare Shell execute result with previous Flag, update flag value 

    --load Broa firmware and show firmware-load result
    Shell("csoc --load")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    -- When RamlogEnabled not true, then return it's parameter, and do csoc --load once
    RamlogExtrasInit()

    Shell("wait 2000")

    -- pick CSOC-CCPU
    Shell("csi pick CSOC-CCPU")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    
    -- set os_log dir and power on CSOC-CCPU
    Shell("csi set_log_dir " .. OsLogFolder)
    Shell("csi on")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    Shell("wait 2000")

    --[[
    Turning off bora...
    Turning off socmca...
    Turning on socmca...
    Turning on bora...    
    --]]
    Shell("audio -r")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    Shell("wait 5000")
    --Shell("audioparam -b bora --param route-type --set --value loopback")
    --MatchResult=Last.Output:match("(OK)")
    --Flag=TestItemResultCompare(MatchResult,Flag)
    pcall(Shell,"audioparam -b bora --param route-type --set --value loopback")

    Shell("wait 15000")
    Flag=0
    StartTimeStr_now = os.time()
    TestItemName="Audio_R_DPLL_status_reg_dump"    
    Shell("i2c -z 4 -d 0x82 0x31 0xB01C 4 multiple")   
    MatchResult=Last.Output:match("Data:%s-0x%x%x%s-0x%x%x%s-0x%x%x%s-(0x%x%x)")
    print("debug R:"..MatchResult)
    MatchResult_R=MatchResult:match("0x05")
    Flag=TestItemResultCompare(MatchResult_R,Flag)
    TotalExeTime=os.time() - StartTimeStr_now
        
    if Flag==0 then
        -- Find the corresponding test item according to the testname and compare it's parameter(CompareMode:StrCompare)
        -- StrCompare: String compare, it contains the expected string then get OK
        CompareWithTC(TestItemName,"OK","StrCompare",TotalExeTime)
    else
        CompareWithTC(TestItemName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    PrintString("\n\n====================================== Test Item :"..TestItemName.." Done ======================================")
    Flag=0
    StartTimeStr_now = os.time()
    TestItemName="Audio_L_DPLL_status_reg_dump"    
    Shell("i2c -z 4 -d 0x80 0x31 0xB01C 4 multiple")
    MatchResult=Last.Output:match("Data:%s-0x%x%x%s-0x%x%x%s-0x%x%x%s-(0x%x%x)")
    print("debug L:"..MatchResult)
    MatchResult_L=MatchResult:match("0x04")
    Flag=TestItemResultCompare(MatchResult_L,Flag)
    TotalExeTime=os.time() - StartTimeStr_now
       
    if Flag==0 then
        -- Find the corresponding test item according to the testname and compare it's parameter(CompareMode:StrCompare)
        -- StrCompare: String compare, it contains the expected string then get OK
        CompareWithTC(TestItemName,"OK","StrCompare",TotalExeTime)
    else
        CompareWithTC(TestItemName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    PrintString("\n\n====================================== Test Item :"..TestItemName.." Done ======================================")
    if MatchResult_R==nil and MatchResult_L==nil then
        PrintString("DPLL status incorrect on both side")
        error("DPLL status incorrect on both side")
    elseif MatchResult_R==nil then
        PrintString("DPLL status incorrect on R side")
        error("DPLL status incorrect on R side")
    elseif MatchResult_L==nil then
        PrintString("DPLL status incorrect on L side")
        error("DPLL status incorrect on L side")
    end
    
    Shell("i2c -z 4 -d 0x82 0x31 0x9808 4 multiple")
    Shell("i2c -z 4 -d 0x82 0x31 0x908C 4 multiple")
    Shell("i2c -z 4 -d 0x82 0x31 0x9090 4 multiple")
    Shell("i2c -z 4 -d 0x82 0x31 0x9094 4 multiple")
    Shell("i2c -z 4 -d 0x82 0x31 0x9098 4 multiple")
    Shell("i2c -z 4 -d 0x82 0x31 0x909C 4 multiple")
    Shell("i2c -z 4 -d 0x82 0x31 0x90A0 4 multiple")
    Shell("i2c -z 4 -d 0x82 0x31 0x90A4 4 multiple")
    Shell("i2c -z 4 -d 0x82 0x31 0x90A8 4 multiple")
    Shell("i2c -z 4 -d 0x82 0x31 0x918C 4 multiple")
    Shell("i2c -z 4 -d 0x82 0x31 0x9190 4 multiple")
    Shell("i2c -z 4 -d 0x82 0x31 0x9194 4 multiple")
    Shell("i2c -z 4 -d 0x82 0x31 0x9198 4 multiple")
    Shell("i2c -z 4 -d 0x82 0x31 0x919C 4 multiple")
    Shell("i2c -z 4 -d 0x82 0x31 0x91A0 4 multiple")
    Shell("i2c -z 4 -d 0x82 0x31 0x91A4 4 multiple")
    Shell("i2c -z 4 -d 0x82 0x31 0x91A8 4 multiple")
    Shell("i2c -z 4 -d 0x82 0x31 0x900C 4 multiple")
    Shell("i2c -z 4 -d 0x82 0x31 0x9010 4 multiple")
    Shell("i2c -z 4 -d 0x82 0x31 0x9014 4 multiple")
    Shell("i2c -z 4 -d 0x82 0x31 0x9018 4 multiple")
    Shell("i2c -z 4 -d 0x82 0x31 0x901C 4 multiple")
    Shell("i2c -z 4 -d 0x82 0x31 0x9020 4 multiple")
    Shell("i2c -z 4 -d 0x82 0x31 0x9024 4 multiple")
    Shell("i2c -z 4 -d 0x82 0x31 0x9028 4 multiple")
    Shell("i2c -z 4 -d 0x82 0x31 0x910C 4 multiple")
    Shell("i2c -z 4 -d 0x82 0x31 0x9110 4 multiple")
    Shell("i2c -z 4 -d 0x82 0x31 0x9114 4 multiple")
    Shell("i2c -z 4 -d 0x82 0x31 0x9118 4 multiple")
    Shell("i2c -z 4 -d 0x82 0x31 0x911C 4 multiple")
    Shell("i2c -z 4 -d 0x82 0x31 0x9120 4 multiple")
    Shell("i2c -z 4 -d 0x82 0x31 0x9124 4 multiple")
    Shell("i2c -z 4 -d 0x82 0x31 0x9128 4 multiple")
    Shell("i2c -z 4 -d 0x82 0x31 0xB020 4 multiple")
    Shell("i2c -z 4 -d 0x82 0x31 0xB024 4 multiple")
    Shell("i2c -z 4 -d 0x82 0x31 0xB028 4 multiple")
    Shell("i2c -z 4 -d 0x82 0x31 0x620C 4 multiple")
    Shell("i2c -z 4 -d 0x82 0x31 0x632C 4 multiple")
    Shell("i2c -z 4 -d 0x82 0x31 0x6330 4 multiple")
    Shell("i2c -z 4 -d 0x82 0x31 0xB010 4 multiple")
    Shell("i2c -z 4 -d 0x82 0x31 0xB014 4 multiple")
    Shell("i2c -z 4 -d 0x82 0x31 0xB060 4 multiple")

    TotalExeTime=os.time() - StartTimeStr
    if Flag==0 then
        -- Find the corresponding test item according to the testname and compare it's parameter(CompareMode:StrCompare)
        -- StrCompare: String compare, it contains the expected string then get OK
        CompareWithTC(TestName,"OK","StrCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)  --the two parameters all equal to 1 then return 1, otherwise return 0
    PrintString("==================================================================================================================")
    return flagToBool(Flag)  -- Flag equal to 0, then return true, otherwise return false
end

-- Audio_Bunratty test
function Audio_Bunratty()
    CsvWriteFlagCheck()
    local Flag=0
    local FuncResultFlag=0
    TestName="Audio_Bunratty"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()

    -- Delete all buffers in the system
    Shell("processaudio --freebufs all")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)--compare Shell execute result with previous Flag, update flag value

    -- format audio date  and request new buffer to use then play the audio
    Shell("playaudio --block socmca --port ap-mca2 --bitdepth 32 --rate 48000 --channels 4 --freq 1000 --len 5000")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    -- debug to the specified value and record date, play the audio, and then send back the record
    Shell("loopaudio -b socmca --txport ap-mca2 --txbitdepth 32 --rxport ap-mca2 --rxbitdepth 16 --rate 48000 --txchannels 4 --rxchannels 8 --freq 1000 --len 5000")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    -- list all satisfactory Channel information
    Shell("processaudio -p fft -o \"--minHz 10 --peakBinWidth 2 --numTones 5  --sortOrder 1\" -i looprx0")
    MatchResult=Last.Output:match("(OK)")
    channelStringList=AudioChannelProcessor(Last.Output)  --AudioChannelProcessor: return each Channel String
    Flag=TestItemResultCompare(MatchResult,Flag)


    TotalExeTime=os.time() - StartTimeStr
    if Flag==0 then
        CompareWithTC(TestName,"OK","StrCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)  --the two parameters all equal to 1 then return 1, otherwise return 0
    PrintString("==================================================================================================================")

    -- TBD:Parse Only tone1 or all tone
    -- TestNane need to comfirm
    -- local Flag=0
    -- local MagnitudeValue,FrequencyValue
    -- TestName="Audio_Bunratty_Channel1_Peak_Magnitude"
    -- PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    -- StartTimeStr=os.time()
    -- MagnitudeValue,FrequencyValue=AudioBunrattyChannelStrProcessor(channelStringList[2])

    -- Flag=TestItemResultCompare(MagnitudeValue,Flag)

    --
    -- TotalExeTime=os.time() - StartTimeStr
    -- if Flag==0 then
    --     CompareWithTC(TestName,MagnitudeValue,"Show",TotalExeTime)
    -- else
    --     CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    -- end
    -- FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    -- PrintString("==================================================================================================================")

    local Flag=0
    local MagnitudeValue,FrequencyValue
    CsvWriteFlagCheck()
    TestName="Audio_Bunratty_Channel1_Peak_Magnitude"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()

    -- return MagnitudeValue and FrequencyValue of channelString
    MagnitudeValue,FrequencyValue=AudioBunrattyChannelStrProcessor(channelStringList[2])
    Flag=TestItemResultCompare(MagnitudeValue,Flag)


    TotalExeTime=os.time() - StartTimeStr
    if Flag==0 then
        CompareWithTC(TestName,MagnitudeValue,"NumCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")

    CsvWriteFlagCheck()
    TestName="Audio_Bunratty_Channel01_Frequency"
    Flag=0
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    Flag=TestItemResultCompare(FrequencyValue,Flag)--compare Shell execute result with previous Flag, update flag value
    TotalExeTime=os.time() - StartTimeStr
    if Flag==0 then
        CompareWithTC(TestName,FrequencyValue,"NumCompare",TotalExeTime)
        --The value in the range of min and Max is pass
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")
    

    local Flag=0
    local MagnitudeValue,FrequencyValue
    CsvWriteFlagCheck()
    TestName="Audio_Bunratty_Channel5_Peak_Magnitude"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()

    -- return MagnitudeValue and FrequencyValue of channelString
    MagnitudeValue,FrequencyValue=AudioBunrattyChannelStrProcessor(channelStringList[6])
    Flag=TestItemResultCompare(MagnitudeValue,Flag)


    TotalExeTime=os.time() - StartTimeStr
    if Flag==0 then
        CompareWithTC(TestName,MagnitudeValue,"NumCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")


    
    CsvWriteFlagCheck()
    TestName="Audio_Bunratty_Channel05_Frequency"
    Flag=0
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    Flag=TestItemResultCompare(FrequencyValue,Flag)
    TotalExeTime=os.time() - StartTimeStr
    if Flag==0 then
        CompareWithTC(TestName,FrequencyValue,"NumCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")
    return flagToBool(Flag)  -- Flag equal to 0, then return true, otherwise return false
end

-- Audio_Mic test
function Audio_Mic()
    CsvWriteFlagCheck()
    local Flag=0
    local FuncResultFlag=0
    TestName="Audio_Mic"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    -- Delete all buffers in the system
    Shell("processaudio --freebufs all")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    -- format audio date  and request new buffer to use then record new audio date
    Shell("recordaudio --block socmca --port ap-mca0 --bitdepth 32 --rate 48000 --channels 8 --len 5000")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    -- list all Audio Channel information
    Shell("processaudio -p fft -o \"--normalize false --float true --minHz 10 --peakBinWidth 2 --numTones 5  --sortOrder 1\" -i record0")
    MatchResult=Last.Output:match("(OK)")
    --AudioChannelProcessor: return each Channel String
    channelStringList=AudioChannelProcessor(Last.Output)
    Flag=TestItemResultCompare(MatchResult,Flag)
    

    TotalExeTime=os.time() - StartTimeStr
    if Flag==0 then
        CompareWithTC(TestName,"OK","StrCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")
    

    for i=1,(5+1)
    do
      
      CsvWriteFlagCheck()
      -- tostrint: Receives a value of any type and converts it to a string in a human-readable format.
      -- append Audio_Mic_Channel_DC_Magnitude date to csv file.
      TestName="Audio_Mic_Channel"..tostring(i-1).."_DC_Magnitude"
      local Flag=0
      PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
      StartTimeStr=os.time()
      DCMagnitudeValue=channelStringList[i]:match("DC Magnitude=(%d+[.]%d+)")
      PrintString(DCMagnitudeValue)
      Flag=TestItemResultCompare(DCMagnitudeValue,Flag)

      TotalExeTime=os.time() - StartTimeStr  -- caculate total time(current time-start time)
      if Flag==0 then
        CompareWithTC(TestName,DCMagnitudeValue,"NumCompare",TotalExeTime)
      else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
      end
      FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
      PrintString("==================================================================================================================")

      local Flag=0
      CsvWriteFlagCheck()
      -- append Audio_Mic_Channel_SINAD date to csv file.
      TestName="Audio_Mic_Channel"..tostring(i-1).."_SINAD"
      PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
      StartTimeStr=os.time()
      SINADValue=channelStringList[i]:match("SINAD=([-]?%d+[.]%d+)")
      PrintString(SINADValue)
      Flag=TestItemResultCompare(SINADValue,Flag)
      

      TotalExeTime=os.time() - StartTimeStr
      if Flag==0 then
        CompareWithTC(TestName,SINADValue,"NumCompare",TotalExeTime)
      else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
      end
      FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
      PrintString("==================================================================================================================")
    end

    PrintString("===========debug++++++++")
--    pcall('audioparam -b bora --param route-type --set --value stop')
    pcall(Shell,"audioparam -b bora --param route-type --set --value stop")

    return flagToBool(Flag)  -- Flag equal to 0, then return true, otherwise return false
end

function Audio_Bunratty_LR()
    CsvWriteFlagCheck()         
    local Flag=0
    local FuncResultFlag=0
    local OsLogFolder = GenerateOsLogFolderName()  -- generate OsLogFolder
    TestName="Audio_Bunratty_L"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()

    Shell("tristar --pick Leviathan; tristar -p")
    MatchResult=Last.Output:match("(ID Connected    = 0x1)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    Shell("csoc --on")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)  --compare Shell execute result with previous Flag, update flag value 

    --load Broa firmware and show firmware-load result
    Shell("csoc --load")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    -- When RamlogEnabled not true, then return it's parameter, and do csoc --load once
    RamlogExtrasInit()

    Shell("wait 2000")

    -- pick CSOC-CCPU
    Shell("csi pick CSOC-CCPU")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    -- set os_log dir and power on CSOC-CCPU
    Shell("csi set_log_dir " .. OsLogFolder)
    Shell("csi on")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    Shell("wait 2000")
    --Left
    Shell("audio -r")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    Shell("wait 2000")

    --Shell("audioparam -b bora --param route-type --set --value loopback")
    --Shell("audioparam -b bora --param route-type --set --value loopback_1")
    --MatchResult=Last.Output:match("(OK)")
    --Flag=TestItemResultCompare(MatchResult,Flag)
    pcall(Shell,"audioparam -b bora --param route-type --set --value loopback_1")
    
    Shell("wait 5000")
    Shell("processaudio --freebufs all")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    Shell("loopaudio -b socmca --txport ap-mca2 --rxport ap-mca2 -d 16 -c 8 --rate 48000 --len 2000 --freq 1000")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    Shell('processaudio -p fft -o "--minHz 10 --peakBinWidth 2 --numTones 5  --sortOrder 1" -i looprx0')
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)
   
    --Left:Check the frequency of channel 5, tone 1 should be 1KHz, limit 995~1005Hz
    channelStringList=AudioChannelProcessor(Last.Output)  --AudioChannelProcessor: return each Channel String
    Flag=TestItemResultCompare(MatchResult,Flag)
    TotalExeTime=os.time() - StartTimeStr
    if Flag==0 then
        CompareWithTC(TestName,"OK","StrCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")

    --Check the frequency of channel 5, tone 1 should be 1KHz, limit 995~1005Hz
    local Flag=0
    local MagnitudeValue,FrequencyValue
    CsvWriteFlagCheck()

    TestName="Audio_Bunratty_Channel05_Frequency"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    MagnitudeValue,FrequencyValue=AudioBunrattyChannelStrProcessor(channelStringList[6])
    StartTimeStr=os.time()
    Flag=TestItemResultCompare(FrequencyValue,Flag)
    TotalExeTime=os.time() - StartTimeStr
    if Flag==0 then
        CompareWithTC(TestName,FrequencyValue,"NumCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")
--    local Flag=0
--    local MagnitudeValue,FrequencyValue
--    CsvWriteFlagCheck()
--    TestName="Audio_Bunratty_Channel06_Frequency"
--    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
--    MagnitudeValue,FrequencyValue=AudioBunrattyChannelStrProcessor(channelStringList[7])
--    StartTimeStr=os.time()
--    Flag=TestItemResultCompare(FrequencyValue,Flag)
--    TotalExeTime=os.time() - StartTimeStr
--   if Flag==0 then
--        CompareWithTC(TestName,FrequencyValue,"NumCompare",TotalExeTime)
--    else
--        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
--    end
--    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
--    PrintString("==================================================================================================================")


    pcall(Shell,"audioparam -b bora --param route-type --set --value stop")

    CsvWriteFlagCheck()         
    local Flag=0
    local FuncResultFlag=0
    TestName="Audio_Bunratty_R"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()


    --Flag=0
    --Right
    Shell("audio -r")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    
    Shell("wait 2000")

    --Shell("audioparam -b bora --param route-type --set --value loopback_2")
    --MatchResult=Last.Output:match("(OK)")
    --Flag=TestItemResultCompare(MatchResult,Flag)
    pcall(Shell,"audioparam -b bora --param route-type --set --value loopback_2")
    
    Shell("wait 5000")
    Shell("processaudio --freebufs all")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    Shell("loopaudio -b socmca --txport ap-mca2 --rxport ap-mca2 -d 16 -c 8 --rate 48000 --len 2000 --freq 1000")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    Shell('processaudio -p fft -o "--minHz 10 --peakBinWidth 2 --numTones 5  --sortOrder 1" -i looprx0')
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    --Check the frequency of channel 1, tone 1 should be 1KHz, limit 995~1005Hz
    channelStringList=AudioChannelProcessor(Last.Output)  --AudioChannelProcessor: return each Channel String
    Flag=TestItemResultCompare(MatchResult,Flag)
    TotalExeTime=os.time() - StartTimeStr
    if Flag==0 then
        CompareWithTC(TestName,"OK","StrCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")

    --Check the frequency of channel 1, tone 1 should be 1KHz, limit 995~1005Hz
    local Flag=0
    local MagnitudeValue,FrequencyValue
    CsvWriteFlagCheck()
    TestName="Audio_Bunratty_Channel01_Frequency"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    MagnitudeValue,FrequencyValue=AudioBunrattyChannelStrProcessor(channelStringList[2])
    StartTimeStr=os.time()
    Flag=TestItemResultCompare(FrequencyValue,Flag)
    TotalExeTime=os.time() - StartTimeStr
    if Flag==0 then
        CompareWithTC(TestName,FrequencyValue,"NumCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")
--    local Flag=0
--   local MagnitudeValue,FrequencyValue
--    CsvWriteFlagCheck()
--    TestName="Audio_Bunratty_Channel04_Frequency"
--    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
--    MagnitudeValue,FrequencyValue=AudioBunrattyChannelStrProcessor(channelStringList[5])
--    StartTimeStr=os.time()
--    Flag=TestItemResultCompare(FrequencyValue,Flag)
--    TotalExeTime=os.time() - StartTimeStr
--    if Flag==0 then
--        CompareWithTC(TestName,FrequencyValue,"NumCompare",TotalExeTime)
--    else
--        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
--    end
--    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
--    PrintString("==================================================================================================================")
    

    pcall(Shell,"audioparam -b bora --param route-type --set --value stop")
    PrintString("==================================================================================================================")


end    




