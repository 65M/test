require "CompareAndOutput"

local OS_LOG_FOLDER_NAME = nil

function GenerateOsLogFolderName()
    if OS_LOG_FOLDER_NAME ~= nil then
      return OS_LOG_FOLDER_NAME
    end
    Shell("rtc --get")
    rtc = string.match(Last.Output, "RTC_Time: ([%d&%a%-%.]+)")
    timestamp = rtc:gsub("%.", "_")
    OS_LOG_FOLDER_NAME = GetSequencePath("OutputDir") .. "\\os_log-" .. timestamp
    pcall(Shell, "mkdir " .. OS_LOG_FOLDER_NAME)

    return OS_LOG_FOLDER_NAME;
end

function Average(values)
	local avg=0
    local pre_sum = 0
    for i = 1, #values do
        local val = values[i]
        pre_sum = pre_sum + val
  	end
    avg=pre_sum / #values
    return avg
end


function flagToBool(FuncResultFlag)
    if FuncResultFlag == 0 then
        return true
		else
        return false
    end
end

function pyResultToPDCA(LastOutput)
  local SEnd=-1
  local temp=0
  local SplitTable = {}
  local PPF="PASS"
  local PitemName,PValue,PUnit,PLowerLimit,PUpperLimit,result,start

  --each Line to table
  for word in string.gmatch(LastOutput, "\n")
  do
     a,SEnd=string.find (LastOutput, "\n",SEnd+1)
     lineStr = string.sub(LastOutput, temp, SEnd-1)
     temp=SEnd+1
     -- PrintString(lineStr)
     table.insert (SplitTable,lineStr)
     -- PrintString("====")
  end
  for i=1,(#SplitTable) do
    if SplitTable[i]:match("(Hark, Station! Behold the data I present you!)") then
      StatusStr=0
      result=SplitTable[i+1]
      resultPF=SplitTable[i+2]
      TempPPF=SplitTable[i+2]:match("(PASS)")
      if TempPPF == nil then
        PPF="FAIL"
        StatusStr=1
      end
      PValue,PUnit,PLowerLimit,PUpperLimit=result:match(",(%w+),(%w+),(%w+),(%w+)")
      if PValue==nil then
        --   PrintString("====rrr====")
        --   PrintString(result)
        --   PrintString("====rrr====")
        PValue,PUnit,PLowerLimit,PUpperLimit=result:match(",(%w+[.]%w+),(%w+[_]%w+),(%w+),(%w+)")
        if PValue==nil then
            PValue,PUnit,PLowerLimit,PUpperLimit=result:match(",(%w+[.]%w+),(%w+),(%w+[.]?%w?),(%w+[.]%w+)")
        end
      end
      start=result:find("(,)")
      PitemName=result:sub(1,start-1)

      PrintString("==========Example String==========")
      PrintString(result)
      PrintString(resultPF)
      PrintString("==========Example String==========")
      if PLowerLimit == "None" then PLowerLimit = tonumber(nil) else PLowerLimit = tonumber(PLowerLimit) end
      if PUpperLimit == "None" then PUpperLimit = tonumber(nil) else PUpperLimit = tonumber(PUpperLimit) end
      PrintString("==========Parse Result==========")
      PrintString(PitemName)
      PrintString(PValue)
      PrintString(PUnit)
      PrintString(PLowerLimit)
      PrintString(PUpperLimit)
      PrintString("==========Parse Result==========")
			if tonumber(PValue) then
				ReportDataToStationAndPDCA(PitemName,tonumber(PValue),PUnit,PLowerLimit,PUpperLimit)
        -- PrintString(PitemName.." "..tonumber(PValue))
			else
				-- wildfire v0.1.10, Change the logic to True/False:1/0
				if PValue == "False" then
					PValue=0
          -- PrintString(PitemName.." "..tonumber(PValue))
					ReportDataToStationAndPDCA(PitemName,tonumber(PValue),PUnit,PLowerLimit,PUpperLimit)
				elseif PValue == "True" then
					PValue=1
          -- PrintString(PitemName.." "..tonumber(PValue))
					ReportDataToStationAndPDCA(PitemName,tonumber(PValue),PUnit,PLowerLimit,PUpperLimit)
				else
					PrintString("==========Check Item Value==========")
		      PrintString(result)
		      PrintString("==========Check Item Value End==========")
				end
			end
      TestResultOutput(PitemName,StatusStr,PValue,PLowerLimit,PUpperLimit,PUnit,0)
    end

  end
	return PPF
end

function pyFileProcessor(ExecResult)
  SEnd=-1
  temp=0
  SplitTable = {}
  CmdTable={}
  CmdResult={}

  --each Line to table
  for word in string.gmatch(ExecResult, "\n")
  do
     a,SEnd=string.find (ExecResult, "\n",SEnd+1)
     lineStr = string.sub(ExecResult, temp, SEnd-1)
     temp=SEnd+1
     -- PrintString(lineStr)
     table.insert (SplitTable,lineStr)
     -- PrintString("====")
  end
  -- PrintString(count)
  -- PrintString("=======")
  -- PrintString(#SplitTable)
  -- PrintString(SplitTable[12956])
  -- PrintString(SplitTable[12957])

  --each cmd execute result to table
  for i=1,#SplitTable do
    if string.sub(SplitTable[i], 1,3)==">>>"
    then
      -- PrintString(i)
      -- PrintString(SplitTable[i])
      table.insert (CmdTable,i)
    end
  end
  -- PrintString(#CmdTable)
  for i=1,(#CmdTable) do
    CombineStr=""
    if i==#CmdTable then
      for z=CmdTable[i],#SplitTable do
        do
          CombineStr=CombineStr..SplitTable[z].."\n"
        end
      end
      -- PrintString("--------------------------")
      -- PrintString(CombineStr)
      -- PrintString("--------------------------")
    else
      for z=CmdTable[i],(CmdTable[i+1]-1)
      do
        CombineStr=CombineStr..SplitTable[z].."\n"
      end
      -- PrintString("++++++++++++++++++++++++++")
      -- PrintString(CombineStr)
      -- PrintString("++++++++++++++++++++++++++")
    end
    table.insert (CmdResult,CombineStr)
  end
  SplitTable = nil
  CmdTable=nil
  -- PrintString(#CmdResult)
  return CmdResult
end

function IrFloodResultProcessor(cmdResult)
  IrFloodCommandExecFlag="PASS"
  IrFloodCsocLoadFWFlag=0
  for i=1,#cmdResult do
  -- PrintString("++++++++++++++++++++++++++")
  -- PrintString(cmdResult[i])
  -- PrintString("++++++++++++++++++++++++++")
    if string.sub(cmdResult[i], 1,7)==">>>csoc" then
      if cmdResult[i]:match("%p+on") then
        -- PrintString("csoc on")
        if cmdResult[i]:match("(OK)") then
          -- PrintString("success")
        else
          IrFloodCommandExecFlag="FAIL"
          PrintString("=======Fail Command in IrFloodTest.py======")
          PrintString(cmdResult[i])
          PrintString("========================================\n")

        end
      else
        if IrFloodCsocLoadFWFlag==0 then
          -- PrintString("Inspected")
          IrFloodCsocLoadFWFlag=1
          if not cmdResult[i]:match("(firmware%p+load=\"Passed\")") then
            IrFloodCommandExecFlag="FAIL"
            PrintString("=======Fail Command in IrFloodTest.py======")
            PrintString(cmdResult[i])
            PrintString("========================================\n")
          end
        end
      end
    elseif string.sub(cmdResult[i], 1,6)==">>>csi" then
      if not cmdResult[i]:match("(OK)") then
        IrFloodCommandExecFlag="FAIL"
        PrintString("=======Fail Command in IrFloodTest.py======")
        PrintString(cmdResult[i])
        PrintString("========================================\n")
      end
    elseif string.sub(cmdResult[i], 1,6)==">>>reg" then
      if not cmdResult[i]:match("(OK)") then
        IrFloodCommandExecFlag="FAIL"
        PrintString("=======Fail Command in IrFloodTest.py======")
        PrintString(cmdResult[i])
        PrintString("========================================\n")
      end
    elseif string.sub(cmdResult[i], 1,6)==">>>sep" then
      if not cmdResult[i]:match("(OK)") then
        IrFloodCommandExecFlag="FAIL"
        PrintString("=======Fail Command in IrFloodTest.py======")
        PrintString(cmdResult[i])
        PrintString("========================================\n")
      end

    elseif string.sub(cmdResult[i], 1,9)==">>>camisp" then
      -- PrintString("++++++++++++++++++++++++++")
      -- PrintString(cmdResult[i])
      -- PrintString("++++++++++++++++++++++++++")

      if not cmdResult[i]:match("(Pass)") then
        IrFloodCommandExecFlag="FAIL"
        PrintString("=======Fail Command in IrFloodTest.py======")
        PrintString(cmdResult[i])
        PrintString("========================================\n")
      end

    elseif string.sub(cmdResult[i], 1,5)==">>>sn" then
      if not cmdResult[i]:match("(.+)") then
        IrFloodCommandExecFlag="FAIL"
        PrintString("=======Fail Command in IrFloodTest.py======")
        PrintString(cmdResult[i])
        PrintString("========================================\n")
      end
    else
      -- TDO
      PrintString("=======Need Coco Check Command Execute Result and Define Parse Target in IrFloodTest.py======")
      PrintString(i)
      PrintString(cmdResult[i])
      PrintString("========================================\n")
    end

    if cmdResult[i]:match("(Hark, Station! Behold the data I present you!)") then
      if pyResultToPDCA(cmdResult[i]) == "FAIL" then
        IrFloodCommandExecFlag="FAIL"
      end
    end
  end
  return IrFloodCommandExecFlag
end

function JasperResultProcessor(cmdResult)
  JasperCommandExecFlag="PASS"
  for i=1,#cmdResult do
  -- PrintString("++++++++++++++++++++++++++")
  -- PrintString(cmdResult[i])
  -- PrintString("++++++++++++++++++++++++++")
      if string.sub(cmdResult[i], 1,7)==">>>csoc" then
          if cmdResult[i]:match("%p+on") then
              -- PrintString("csoc on")
              if cmdResult[i]:match("(OK)") then
              -- PrintString("success")
              else
                  JasperCommandExecFlag="FAIL"
                  PrintString("=======Fail Command in JasperTest.py======")
                  PrintString(cmdResult[i])
                  PrintString("========================================\n")
              end
          else
              if not cmdResult[i]:match("(firmware%p+load=\"Passed\")") then
                  PrintString("=======Fail Command in JasperTest.py======")
                  PrintString(cmdResult[i])
                  PrintString("========================================\n")
                  JasperCommandExecFlag="FAIL"
              end
          end

      elseif string.sub(cmdResult[i], 1,6)==">>>csi" then
          if not cmdResult[i]:match("(OK)") then
              JasperCommandExecFlag="FAIL"
              PrintString("=======Fail Command in JasperTest.py======")
              PrintString(cmdResult[i])
              PrintString("========================================\n")
          end

      elseif string.sub(cmdResult[i], 1,6)==">>>sep" then
          if not cmdResult[i]:match("(OK)") then
              JasperCommandExecFlag="FAIL"
              PrintString("=======Fail Command in JasperTest.py======")
              PrintString(cmdResult[i])
              PrintString("========================================\n")
          end

      elseif string.sub(cmdResult[i], 1,9)==">>>camisp" then
          -- PrintString("++++++++++++++++++++++++++")
          -- PrintString(cmdResult[i])
          -- PrintString("++++++++++++++++++++++++++")
          if not cmdResult[i]:match("(Pass)") then
              JasperCommandExecFlag="FAIL"
              PrintString("=======Fail Command in JasperTest.py======")
              PrintString(cmdResult[i])
              PrintString("========================================\n")
          end

      elseif string.sub(cmdResult[i], 1,5)==">>>sn" then
          if not cmdResult[i]:match("(.+)") then
              JasperCommandExecFlag="FAIL"
              PrintString("=======Fail Command in MokuTest.py======")
              PrintString(cmdResult[i])
              PrintString("========================================\n")
          end
      else
          -- -- TDO
          PrintString("=======Need Coco Check Command Execute Result and Define Parse Target in JasperTest.py======")
          PrintString(i)
          PrintString(cmdResult[i])
          PrintString("========================================\n")
      end

      if cmdResult[i]:match("(Hark, Station! Behold the data I present you!)") then
        if pyResultToPDCA(cmdResult[i]) == "FAIL" then
          JasperCommandExecFlag="FAIL"
        end
      end
  end
  -- PrintString("===========")
  -- PrintString(JasperCommandExecFlag)
  return JasperCommandExecFlag
end

function CameraResultProcessor(cmdResult)
  CameraCommandExecFlag="PASS"
  for i=1,#cmdResult do
  -- PrintString("++++++++++++++++++++++++++")
  -- PrintString(cmdResult[i])
  -- PrintString("++++++++++++++++++++++++++")
      if string.sub(cmdResult[i], 1,7)==">>>csoc" then
          if cmdResult[i]:match("%p+on") then
              -- PrintString("csoc on")
              if cmdResult[i]:match("(OK)") then
              -- PrintString("success")
              else
                  CameraCommandExecFlag="FAIL"
                  PrintString("=======Fail Command in CameraTests.py======")
                  PrintString(cmdResult[i])
                  PrintString("========================================\n")
              end
          else
              if not cmdResult[i]:match("(firmware%p+load=\"Passed\")") then
                  PrintString("=======Fail Command in CameraTests.py======")
                  PrintString(cmdResult[i])
                  PrintString("========================================\n")
                  CameraCommandExecFlag="FAIL"
              end
          end

      elseif string.sub(cmdResult[i], 1,6)==">>>csi" then
          if not cmdResult[i]:match("(OK)") then
              CameraCommandExecFlag="FAIL"
              PrintString("=======Fail Command in CameraTests.py======")
              PrintString(cmdResult[i])
              PrintString("========================================\n")
          end

      elseif string.sub(cmdResult[i], 1,6)==">>>sep" then
          if not cmdResult[i]:match("(OK)") then
              CameraCommandExecFlag="FAIL"
              PrintString("=======Fail Command in CameraTests.py======")
              PrintString(cmdResult[i])
              PrintString("========================================\n")
          end

      elseif string.sub(cmdResult[i], 1,9)==">>>camisp" then
          -- PrintString("++++++++++++++++++++++++++")
          -- PrintString(cmdResult[i])
          -- PrintString("++++++++++++++++++++++++++")
          if not cmdResult[i]:match("(Pass)") then
              CameraCommandExecFlag="FAIL"
              PrintString("=======Fail Command in CameraTests.py======")
              PrintString(cmdResult[i])
              PrintString("========================================\n")
          end

      elseif string.sub(cmdResult[i], 1,5)==">>>sn" then
          if not cmdResult[i]:match("(.+)") then
              CameraCommandExecFlag="FAIL"
              PrintString("=======Fail Command in CameraTests.py======")
              PrintString(cmdResult[i])
              PrintString("========================================\n")
          end
      else
          -- -- TDO
          PrintString("=======Need Coco Check Command Execute Result and Define Parse Target in CameraTests.py======")
          PrintString(i)
          PrintString(cmdResult[i])
          PrintString("========================================\n")
      end

      if cmdResult[i]:match("(Hark, Station! Behold the data I present you!)") then
        if pyResultToPDCA(cmdResult[i]) == "FAIL" then
          CameraCommandExecFlag="FAIL"
        end
      end
  end
  -- PrintString("===========")
  -- PrintString(CameraCommandExecFlag)
  return CameraCommandExecFlag
end

function MokuResultProcessor(cmdResult)
  MokuCommandExecFlag="PASS"
  MokuCsocLoadFWFlag=0
  for i=1,#cmdResult do
  -- PrintString("++++++++++++++++++++++++++")
  -- PrintString(cmdResult[i])
  -- PrintString("++++++++++++++++++++++++++")
    if string.sub(cmdResult[i], 1,7)==">>>csoc" then
      if cmdResult[i]:match("%p+on") then
        -- PrintString("csoc on")
        if cmdResult[i]:match("(OK)") then
          -- PrintString("success")
        else
          MokuCommandExecFlag="FAIL"
          PrintString("=======Fail Command in MokuTest.py======")
          PrintString(cmdResult[i])
          PrintString("========================================\n")

        end
      else
        if MokuCsocLoadFWFlag==0 then
          -- PrintString("Inspected")
          MokuCsocLoadFWFlag=1
          if not cmdResult[i]:match("(firmware%p+load=\"Passed\")") then
            MokuCommandExecFlag="FAIL"
            PrintString("=======Fail Command in MokuTest.py======")
            PrintString(cmdResult[i])
            PrintString("========================================\n")
          end
        end
      end
    elseif string.sub(cmdResult[i], 1,6)==">>>csi" then
      if not cmdResult[i]:match("(OK)") then
        MokuCommandExecFlag="FAIL"
        PrintString("=======Fail Command in MokuTest.py======")
        PrintString(cmdResult[i])
        PrintString("========================================\n")
      end
    elseif string.sub(cmdResult[i], 1,6)==">>>reg" then
      if not cmdResult[i]:match("(OK)") then
        MokuCommandExecFlag="FAIL"
        PrintString("=======Fail Command in MokuTest.py======")
        PrintString(cmdResult[i])
        PrintString("========================================\n")
      end
    elseif string.sub(cmdResult[i], 1,6)==">>>sep" then
      if not cmdResult[i]:match("(OK)") then
        MokuCommandExecFlag="FAIL"
        PrintString("=======Fail Command in MokuTest.py======")
        PrintString(cmdResult[i])
        PrintString("========================================\n")
      end

    elseif string.sub(cmdResult[i], 1,9)==">>>camisp" then
      -- PrintString("++++++++++++++++++++++++++")
      -- PrintString(cmdResult[i])
      -- PrintString("++++++++++++++++++++++++++")

      if not cmdResult[i]:match("(Pass)") then
        MokuCommandExecFlag="FAIL"
        PrintString("=======Fail Command in MokuTest.py======")
        PrintString(cmdResult[i])
        PrintString("========================================\n")
      end

    elseif string.sub(cmdResult[i], 1,5)==">>>sn" then
      if not cmdResult[i]:match("(.+)") then
        MokuCommandExecFlag="FAIL"
        PrintString("=======Fail Command in MokuTest.py======")
        PrintString(cmdResult[i])
        PrintString("========================================\n")
      end
    else
      -- TDO
      PrintString("=======Need Coco Check Command Execute Result and Define Parse Target in MokuTest.py======")
      PrintString(i)
      PrintString(cmdResult[i])
      PrintString("========================================\n")
    end

    if cmdResult[i]:match("(Hark, Station! Behold the data I present you!)") then
      if pyResultToPDCA(cmdResult[i]) == "FAIL" then
        MokuCommandExecFlag="FAIL"
      end
    end
  end
  return MokuCommandExecFlag
end

function PearlResultProcessor(cmdResult)
  PearlCommandExecFlag="PASS"
  PearlCsocLoadFWFlag=0
  for i=1,#cmdResult do
  -- PrintString("++++++++++++++++++++++++++")
  -- PrintString(cmdResult[i])
  -- PrintString("++++++++++++++++++++++++++")
    if string.sub(cmdResult[i], 1,7)==">>>csoc" then
      if cmdResult[i]:match("%p+on") then
        -- PrintString("csoc on")
        if cmdResult[i]:match("(OK)") then
          -- PrintString("success")
        else
          PearlCommandExecFlag="FAIL"
          PrintString("=======Fail Command in PearlTest.py======")
          PrintString(cmdResult[i])
          PrintString("========================================\n")

        end
      else
        if PearlCsocLoadFWFlag==0 then
          PearlCsocLoadFWFlag=1
          if not cmdResult[i]:match("(firmware%p+load=\"Passed\")") then
            -- comment PearlCommandExecFlag="FAIL" to skip this fail
            -- since "csoc --load_firmware" might be sequence issue
            -- We still print out Fail Message for track
            -- PearlCommandExecFlag="FAIL"
            PrintString("=======Fail Command in PearlTest.py======")
            PrintString(cmdResult[i])
            PrintString("========================================\n")
          end
        end
      end
    elseif string.sub(cmdResult[i], 1,6)==">>>csi" then
      if not cmdResult[i]:match("(OK)") then
        PearlCommandExecFlag="FAIL"
        PrintString("=======Fail Command in PearlTest.py======")
        PrintString(cmdResult[i])
        PrintString("========================================\n")
      end
    elseif string.sub(cmdResult[i], 1,6)==">>>reg" then
      if not cmdResult[i]:match("(OK)") then
        PearlCommandExecFlag="FAIL"
        PrintString("=======Fail Command in PearlTest.py======")
        PrintString(cmdResult[i])
        PrintString("========================================\n")
      end
    elseif string.sub(cmdResult[i], 1,6)==">>>sep" then
      if not cmdResult[i]:match("(OK)") then
        PearlCommandExecFlag="FAIL"
        PrintString("=======Fail Command in PearlTest.py======")
        PrintString(cmdResult[i])
        PrintString("========================================\n")
      end

    elseif string.sub(cmdResult[i], 1,9)==">>>camisp" then
      -- PrintString("++++++++++++++++++++++++++")
      -- PrintString(cmdResult[i])
      -- PrintString("++++++++++++++++++++++++++")

      if not cmdResult[i]:match("(Pass)") then
        PearlCommandExecFlag="FAIL"
        PrintString("=======Fail Command in PearlTest.py======")
        PrintString(cmdResult[i])
        PrintString("========================================\n")
      end
    elseif string.sub(cmdResult[i], 1,5)==">>>sn" then
      if not cmdResult[i]:match("(.+)") then
        PearlCommandExecFlag="FAIL"
        PrintString("=======Fail Command in MokuTest.py======")
        PrintString(cmdResult[i])
        PrintString("========================================\n")
      end
    else
      -- -- TDO
      PrintString("=======Need Coco Check Command Execute Result and Define Parse Target in PearlTest.py======")
      PrintString(i)
      PrintString(cmdResult[i])
      PrintString("========================================\n")
    end

    if cmdResult[i]:match("(Hark, Station! Behold the data I present you!)") then
      if pyResultToPDCA(cmdResult[i]) == "FAIL" then
        PearlCommandExecFlag="FAIL"
      end
    end
  end
  return PearlCommandExecFlag
end

function AudioChannelProcessor(LastOutput)
  local ChannelStringList={}
  CH0Start=LastOutput:find("(Channel 0)")
  CH1Start=LastOutput:find("(Channel 1)")
  CH2Start=LastOutput:find("(Channel 2)")
  CH3Start=LastOutput:find("(Channel 3)")
  CH4Start=LastOutput:find("(Channel 4)")
  CH5Start=LastOutput:find("(Channel 5)")
  CH6Start=LastOutput:find("(Channel 6)")
  CH7Start=LastOutput:find("(Channel 7)")
	StringEnd=#LastOutput
  --PrintString("==============================")
  --PrintString(CH0Start)
  --PrintString(CH1Start)
  --PrintString(CH2Start)
  --PrintString(CH3Start)
  --PrintString(CH4Start)
  --PrintString(CH5Start)
  --PrintString(CH6Start)
  --PrintString(CH7Start)
  --PrintString(OKStart)
  --PrintString("==============================")

  CH0Str = LastOutput:sub(CH0Start, CH1Start-1)
  --PrintString("==============================")
  --PrintString(CH0Str)
  --PrintString("==============================")

  CH1Str = LastOutput:sub(CH1Start, CH2Start-1)
  --PrintString("==============================")
  --PrintString(CH1Str)
  --PrintString("==============================")

  CH2Str = LastOutput:sub(CH2Start, CH3Start-1)
  --PrintString("==============================")
  --PrintString(CH2Str)
  --PrintString("==============================")

  CH3Str = LastOutput:sub(CH3Start, CH4Start-1)
  --PrintString("==============================")
  --PrintString(CH3Str)
  --PrintString("==============================")

  CH4Str = LastOutput:sub(CH4Start, CH5Start-1)
  --PrintString("==============================")
  --PrintString(CH4Str)
  --PrintString("==============================")

  CH5Str = LastOutput:sub(CH5Start, CH6Start-1)
  --PrintString("==============================")
  --PrintString(CH5Str)
  --PrintString("==============================")
  CH6Str = LastOutput:sub(CH6Start, CH7Start-1)
	CH7Str = LastOutput:sub(CH7Start, StringEnd)


  table.insert(ChannelStringList,CH0Str)
  table.insert(ChannelStringList,CH1Str)
  table.insert(ChannelStringList,CH2Str)
  table.insert(ChannelStringList,CH3Str)
  table.insert(ChannelStringList,CH4Str)
  table.insert(ChannelStringList,CH5Str)
  table.insert(ChannelStringList,CH6Str)
  table.insert(ChannelStringList,CH7Str)
  return ChannelStringList
end

--CsvWriteFlag for CSV write function when testiem fail
function CsvWriteFlagCheck()
	if CsvWriteFlag==1 then
		CompareWithTC(TestName,"ProcessFail","ProcessFail","0")
	end
	CsvWriteFlag=1


end

function AudioBunrattyChannelStrProcessor(ChannelStr)
	local Start,End,TargetStr,MagnitudeValue,FrequencyValue
	-- PrintString(ChannelStr)
  Start,End=ChannelStr:find("(%(Tone%s+1%))")
  -- PrintString(Value)
  -- retrieve the line which contain (Tone 1)
  TargetStr=ChannelStr:sub(1,End)
  -- PrintString(TargetStr)
  MagnitudeValue=TargetStr:match("Peak Magnitude=(%d+%.%d+)")
  FrequencyValue=TargetStr:match("Frequency:%s+(%d+%.%d+)")
  -- PrintString(MagnitudeValue)
  -- PrintString(FrequencyValue)
	return MagnitudeValue,FrequencyValue

end
