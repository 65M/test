require "SearchforTarget"
require "CompareAndOutput"
require "CommonLib"

function MokuTests()
  CsvWriteFlagCheck()
  TestName="MokuTests_Command"
  local SplitTable = {}
  local SEnd=-1
  local Flag=0
  local FuncResultFlag=0
  local temp =0
  local count =0
  local CommandResult="PASS"
  local LimitResult="PASS"
  PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
  StartTimeStr=os.time()
  Shell("upy nandfs:\\AppleInternal\\Diags\\Scripts\\N301\\mokuTests.py")
  ExecResult=Last.Output
  -- PrintString("====mokuTests.py Output====")
  -- PrintString(ExecResult)
  -- PrintString("====mokuTests.py Output====")
  cmdResult=pyFileProcessor(ExecResult)
  MokuPyCoommandExecFlag=MokuResultProcessor(cmdResult)
  if MokuPyCoommandExecFlag=="FAIL" then
    FuncResultFlag=1
  end
  
  TotalExeTime=os.time() - StartTimeStr
  CompareWithTC(TestName,MokuPyCoommandExecFlag,"StrCompare",TotalExeTime)
  PrintString("==================================================================================================================")

  -- TestName="MokuTests_Limit"
  -- PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
  -- StartTimeStr=os.time()
  --
  -- TotalExeTime=TimeCalculator(StartTimeStr,FinishTimeStr)
  -- CompareWithTC(TestName,LimitResult,"StrCompare",TotalExeTime)
  -- FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
  -- PrintString("==================================================================================================================")
  return flagToBool(FuncResultFlag)
end
