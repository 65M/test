require "SearchforTarget"
require "CompareAndOutput"
require "TimeRelated"

function X1080_Init()
  CsvWriteFlagCheck()
  TestName="X1080_Init"
  PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
  StartTimeStr=os.time()
  local Flag = 0
  local FuncResultFlag=0

  if Borakeycheck==0 then
    -- 2/19 By Runren's request remove "-a 1 -g \"speedy_debug=2\" when load firmware
    Shell("csoc --on --load")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    Shell("wait 1000")
    Shell("csi pick CSOC-CCPU")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    Shell("csi on")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    --add 5s wait to allow CCPU FW ready in EVT KY
    Shell("wait 5000")

  end
  Shell("display --pick X1080")
  MatchResult=Last.Output:match("(OK)")
  Flag=TestItemResultCompare(MatchResult,Flag)

  Shell("display --on")
  MatchResult=Last.Output:match("(OK)")
  Flag=TestItemResultCompare(MatchResult,Flag)

  Shell("wait 1000")

  TotalExeTime=os.time() - StartTimeStr
  if Flag == 0 then
      CompareWithTC(TestName,MatchResult,"Show",TotalExeTime)
  else
      CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
  end
  FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
  PrintString("==================================================================================================================")
  return flagToBool(FuncResultFlag)
end

function X1080_mipi_wait(msec)
-- WA for mipi r/w error with UART disable
  Shell("wait "..msec)
end

function X1080_Panel_Crack_Check_StatenToShiraz()
  CsvWriteFlagCheck()
  TestName="X1080_Panel_Crack_Chk"
  PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
  StartTimeStr=os.time()
  local Flag = 0
  local FuncResultFlag=0
  
  Shell('mipi --list')
  MatchResult=Last.Output:match("(OK)")
  Flag=TestItemResultCompare(MatchResult,Flag)
  X1080_mipi_wait(10)
  
  
  Shell('mipi --pick internal')
  MatchResult=Last.Output:match("(OK)")
  Flag=TestItemResultCompare(MatchResult,Flag)
  X1080_mipi_wait(10)

  Shell('mipi -w 0x15 0xB2 "0x96"')
  MatchResult=Last.Output:match("(OK)")
  Flag=TestItemResultCompare(MatchResult,Flag)
  X1080_mipi_wait(10)

  Shell('mipi -w 0x15 0xB9 "0x40"')
  MatchResult=Last.Output:match("(OK)")
  Flag=TestItemResultCompare(MatchResult,Flag)
  X1080_mipi_wait(10)

  Shell('mipi -w 0x15 0x6F "0x01"')
  MatchResult=Last.Output:match("(OK)")
  Flag=TestItemResultCompare(MatchResult,Flag)
  X1080_mipi_wait(10)

  Shell('mipi -w 0x39 0xDE "0x01 0x10 0x01"')
  MatchResult=Last.Output:match("(OK)")
  Flag=TestItemResultCompare(MatchResult,Flag)
  X1080_mipi_wait(10)

  Shell('mipi -w 0x15 0xDE "0x01"')
  MatchResult=Last.Output:match("(OK)")
  Flag=TestItemResultCompare(MatchResult,Flag)
  X1080_mipi_wait(10)

  Shell('mipi -w 0x15 0x6F "0x08"')
  MatchResult=Last.Output:match("(OK)")
  Flag=TestItemResultCompare(MatchResult,Flag)
  X1080_mipi_wait(10)

  local str1,str2
  Shell("mipi -r 0x06 0xDE")
  str1,str2=Last.Output:match("%s0x(%w+)%s0x(%w+)")
  Flag=TestItemResultCompare(MatchResult,Flag)
  TestdataName="X1080_Panel_Crack_Chk_R"
  local ItemIndex
  for i=1,#StatenToShiraztable
    do
		  if StatenToShiraztable[i]["key"]==str1 then
            ItemIndex=i
            break
      else
            --NO DATA
            ItemIndex=-1
      end
  end
	MatchResult=StatenToShiraztable[ItemIndex]["data"]
  MatchResult=tonumber(MatchResult)
  PrintString(MatchResult)
  if Flag == 0 then
    CompareWithTC(TestdataName,MatchResult,"NumCompare",TotalExeTime)
  else
    CompareWithTC(TestdataName,"ProcessFail","ProcessFail",TotalExeTime)
  end

  TestdataName="X1080_Panel_Crack_Chk_L"
  local ItemIndex
  for i=1,#StatenToShiraztable
    do
		  if StatenToShiraztable[i]["key"]==str2 then
          ItemIndex=i
          break
      else
          --NO DATA
          ItemIndex=-1
      end
  end
  MatchResult=StatenToShiraztable[ItemIndex]["data"]
  MatchResult=tonumber(MatchResult)
  PrintString(MatchResult)
  if Flag == 0 then
    CompareWithTC(TestdataName,MatchResult,"NumCompare",TotalExeTime)
  else
    CompareWithTC(TestdataName,"ProcessFail","ProcessFail",TotalExeTime)
  end


  if Flag == 0 then
    CompareWithTC(TestName,"PASS","Show",TotalExeTime)
  else
    CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
  end

  FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
  PrintString("==================================================================================================================")
  return flagToBool(FuncResultFlag)
end

function X1080_SPI_Flash_Check()
  CsvWriteFlagCheck()
  TestName="X1080_SPI_Flash_Check"
  PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
  StartTimeStr=os.time()
  local Flag = 0
  local FuncResultFlag=0
  
  Shell('mipi --list')
  MatchResult=Last.Output:match("(OK)")
  Flag=TestItemResultCompare(MatchResult,Flag)
  X1080_mipi_wait(10)
  
  Shell('mipi --pick internal')
  MatchResult=Last.Output:match("(OK)")
  Flag=TestItemResultCompare(MatchResult,Flag)
  X1080_mipi_wait(10)

  Shell('mipi -w 0x15 0xB2 "0x96"')
  MatchResult=Last.Output:match("(OK)")
  Flag=TestItemResultCompare(MatchResult,Flag)
  X1080_mipi_wait(10)

  Shell('mipi -w 0x15 0xB9 "0x40"')
  MatchResult=Last.Output:match("(OK)")
  Flag=TestItemResultCompare(MatchResult,Flag)
  X1080_mipi_wait(10)

  Shell('mipi -w 0x39 0xF1 "0xE7 0xA5"')
  MatchResult=Last.Output:match("(OK)")
  Flag=TestItemResultCompare(MatchResult,Flag)
  X1080_mipi_wait(10)

  Shell('mipi -w 0x15 0xC2 "0x00"')
  MatchResult=Last.Output:match("(OK)")
  Flag=TestItemResultCompare(MatchResult,Flag)
  X1080_mipi_wait(10)

  Shell('mipi -w 0x39 0xC1 "0x00 0x90"')
  MatchResult=Last.Output:match("(OK)")
  Flag=TestItemResultCompare(MatchResult,Flag)
  X1080_mipi_wait(10)

  Shell('mipi -w 0x15 0xC0 "0x03"')
  MatchResult=Last.Output:match("(OK)")
  Flag=TestItemResultCompare(MatchResult,Flag)
  X1080_mipi_wait(10)

  Shell('mipi -w 0x37 "0x02"')
  MatchResult=Last.Output:match("(OK)")
  Flag=TestItemResultCompare(MatchResult,Flag)
  X1080_mipi_wait(10)

  Shell('mipi -r 0x06 0xC4')
  TestdataName="X1080_SPI_Flash_check_deviceID"
  MatchResult,MatchResult1=Last.Output:match("%s0x(%w+)%s0x(%w+)")
  MatchResult=MatchResult..MatchResult1
  MatchResult=tonumber(MatchResult,16)
  Flag=TestItemResultCompare(MatchResult,Flag)
  if Flag == 0 then
    CompareWithTC(TestdataName,MatchResult,"NumCompare",TotalExeTime)
  else
    CompareWithTC(TestdataName,"ProcessFail","ProcessFail",TotalExeTime)
  end

  X1080_mipi_wait(10)
  Shell('mipi -w 0x15 0x6F "0x08"')
  MatchResult=Last.Output:match("(OK)")
  Flag=TestItemResultCompare(MatchResult,Flag)

  X1080_mipi_wait(10)
  Shell('mipi -r 0x06 0xC4')
  TestdataName="X1080_SPI_Flash_check_CRCFlag"
  MatchResult=Last.Output:match("%s0x(%w+)")
  Flag=TestItemResultCompare(MatchResult,Flag)
  MatchResult=tonumber(MatchResult,16)
  if Flag == 0 then
    CompareWithTC(TestdataName,MatchResult,"NumCompare",TotalExeTime)
  else
    CompareWithTC(TestdataName,"ProcessFail","ProcessFail",TotalExeTime)
  end


  TotalExeTime=os.time() - StartTimeStr
  if Flag == 0 then
      CompareWithTC(TestName,"OK","Show",TotalExeTime)
  else
      CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
  end
  FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
  PrintString("==================================================================================================================")
  return flagToBool(FuncResultFlag)
end


function X1080_EEPROM_Test()
  CsvWriteFlagCheck()
  TestName="X1080_EEPROM_Test"
  PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
  StartTimeStr=os.time()
  local Flag = 0
  local FuncResultFlag=0

  X1080_mipi_wait(10)
  Shell('i2c -v 4 0x51 0x3F 0xF0 0x0A 0x1A 0x00 0x23 0x34 0xB3 0xE2 0x73 multiple')
  MatchResult=Last.Output:match("0xF0 0x0A")
  Flag=TestItemResultCompare(MatchResult,Flag)
  X1080_mipi_wait(10)
  Shell('i2c -z 2 -d 4 0x51 0x3FF0 8')
  MatchResult=Last.Output:match("Data:%s+(0x0A  0x1A  0x00  0x23  0x34  0xB3  0xE2  0x73)")
  Flag=TestItemResultCompare(MatchResult,Flag)


  TotalExeTime=os.time() - StartTimeStr
  if Flag == 0 then
      CompareWithTC(TestName,MatchResult,"StrCompare",TotalExeTime)
      ReportDataToStationAndPDCA(TestName,    0,    "NA",    nil,    nil)
  else
      CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
      ReportDataToStationAndPDCA(TestName,    1,    "NA",    nil,    nil)
  end
  FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
  PrintString("==================================================================================================================")
  return flagToBool(FuncResultFlag)
end

function X1080_DDIC_Health_Check()
  CsvWriteFlagCheck()
  TestName="X1080_DDIC_Health_Check"
  PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
  StartTimeStr=os.time()
  local Flag = 0
  local FuncResultFlag=0

  Shell('mipi -r 0x06 0x0A')
  MatchResult=Last.Output:match("0x(%w+)")
  Flag=TestItemResultCompare(MatchResult,Flag)
  MatchResult=tonumber(MatchResult,16)


  TotalExeTime=os.time() - StartTimeStr
  if Flag == 0 then
      CompareWithTC(TestName,MatchResult,"NumCompare",TotalExeTime)
  else
      CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
  end
  FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
  PrintString("==================================================================================================================")
  return flagToBool(FuncResultFlag)
end

function X1080_PMIC_Fault_Check()
  CsvWriteFlagCheck()
  TestName="X1080_PMIC_Fault_Check"
  PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
  StartTimeStr=os.time()
  local Flag = 0
  local FuncResultFlag=0
  
  Shell('mipi --list')
  MatchResult=Last.Output:match("(OK)")
  Flag=TestItemResultCompare(MatchResult,Flag)
  X1080_mipi_wait(10)
  
  Shell('mipi --pick internal')
  MatchResult=Last.Output:match("(OK)")
  Flag=TestItemResultCompare(MatchResult,Flag)
  X1080_mipi_wait(10)

  Shell('mipi -w 0x15 0xB9 "0x40"')
  MatchResult=Last.Output:match("(OK)")
  Flag=TestItemResultCompare(MatchResult,Flag)
  X1080_mipi_wait(10)

  Shell('mipi -w 0x39 0xF1 "0xE7 0xA5"')
  MatchResult=Last.Output:match("(OK)")
  Flag=TestItemResultCompare(MatchResult,Flag)
  X1080_mipi_wait(10)

  Shell('mipi -w 0x39 0xE1 "0xA0 0x41"')
  MatchResult=Last.Output:match("(OK)")
  Flag=TestItemResultCompare(MatchResult,Flag)
  X1080_mipi_wait(10)

  Shell('mipi -w 0x39 0xE2 "0x0A 0x00 0x10"')
  MatchResult=Last.Output:match("(OK)")
  Flag=TestItemResultCompare(MatchResult,Flag)
  X1080_mipi_wait(10)

  Shell('mipi -w 0x15 0x6F "0x01"')
  MatchResult=Last.Output:match("(OK)")
  Flag=TestItemResultCompare(MatchResult,Flag)
  X1080_mipi_wait(10)

  Shell('mipi -w 0x37 0x01')
  MatchResult=Last.Output:match("(OK)")
  Flag=TestItemResultCompare(MatchResult,Flag)
  X1080_mipi_wait(10)

  Shell("mipi -r 0x06 0xE3")
  MatchResult=Last.Output:match("%s0x(%w+)")
  Flag=TestItemResultCompare(MatchResult,Flag)
  MatchResult=tonumber(MatchResult,16)
  if Flag == 0 then
    CompareWithTC(TestName,MatchResult,"NumCompare",TotalExeTime)
  else
    CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
  end

  FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
  PrintString("==================================================================================================================")
  return flagToBool(FuncResultFlag)
end

function X1080_Temperature_Check()
  CsvWriteFlagCheck()
  TestName="X1080_Temperature_Check"
  PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
  StartTimeStr=os.time()
  local Flag = 0
  local FuncResultFlag=0

  X1080_mipi_wait(10)
  Shell("pmuadc --sel stowe --read tdev7")
  MatchResult=Last.Output:match("tdev7:%s(%w+.%w+)%s%w")
  Flag=TestItemResultCompare(MatchResult,Flag)


  TotalExeTime=os.time() - StartTimeStr
  if Flag == 0 then
      CompareWithTC(TestName,MatchResult,"NumCompare",TotalExeTime)
  else
      CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
  end
  FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
  PrintString("==================================================================================================================")
  return flagToBool(FuncResultFlag)
end

function X1080_Display_Connectivity_Check()
  CsvWriteFlagCheck()
  TestName="X1080_Display_Connectivity_Check"
  PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
  StartTimeStr=os.time()
  local Flag = 0
  local FuncResultFlag=0

  X1080_mipi_wait(10)
  Shell("pattern l")
  MatchResult=Last.Output:match("Finish!")
  Flag=TestItemResultCompare(MatchResult,Flag)

  Shell("wait 1000")
  
  Shell('mipi --list')
  MatchResult=Last.Output:match("(OK)")
  Flag=TestItemResultCompare(MatchResult,Flag)
  X1080_mipi_wait(10)
  
  Shell('mipi --pick internal')
  MatchResult=Last.Output:match("(OK)")
  Flag=TestItemResultCompare(MatchResult,Flag)
  X1080_mipi_wait(10)

  Shell("mipi -w 0x15 0xB2 \"0x96\"")
  MatchResult=Last.Output:match("(OK)")
  Flag=TestItemResultCompare(MatchResult,Flag)
  X1080_mipi_wait(10)

  Shell("mipi -w 0x05 0x28")
  MatchResult=Last.Output:match("(OK)")
  Flag=TestItemResultCompare(MatchResult,Flag)
  X1080_mipi_wait(10)

  Shell("mipi -w 0x05 0x10")
  MatchResult=Last.Output:match("(OK)")
  Flag=TestItemResultCompare(MatchResult,Flag)
  X1080_mipi_wait(10)

  Shell("reg select rpmu")
  MatchResult=Last.Output:match("(OK)")
  Flag=TestItemResultCompare(MatchResult,Flag)
  X1080_mipi_wait(10)

  Shell("reg write 0x183c 0x40")
  MatchResult=Last.Output:match("(OK)")
  Flag=TestItemResultCompare(MatchResult,Flag)
  X1080_mipi_wait(10)

  TestdataName="X1080_Connectivity_Check_184b"
  StartTimeStr_184b=os.time()
  Shell("reg read 0x184b")
  MatchResult=Last.Output:match("0x184B => 0x(%w+)")
  TotalExeTime_184b=os.time() - StartTimeStr_184b
  MatchResult=tonumber(MatchResult,16)
  if MatchResult ~=nil then
    Status=CompareWithTC(TestdataName,MatchResult,"NumCompare",TotalExeTime_184b)
  else
    Status=CompareWithTC(TestdataName,"ProcessFail","ProcessFail",TotalExeTime_184b)
  end
  Flag=TestItemResultCompare(Status,Flag)

  X1080_mipi_wait(10)
  Shell("reg write 0x184b 0x40")
  MatchResult=Last.Output:match("(OK)")
  Flag=TestItemResultCompare(MatchResult,Flag)
  X1080_mipi_wait(10)



  TestdataName="X1080_Connectivity_Check_183f"
  StartTimeStr_183f=os.time()
  Shell("reg read 0x183f")
  MatchResult=Last.Output:match("0x183F => 0x(%w+)")
  TotalExeTime_183f=os.time() - StartTimeStr_183f
  MatchResult=tonumber(MatchResult,16)
  if MatchResult ~=nil then
    Status=CompareWithTC(TestdataName,MatchResult,"NumCompare",TotalExeTime_183f)
  else
    Status=CompareWithTC(TestdataName,"ProcessFail","ProcessFail",TotalExeTime_183f)
  end
  Flag=TestItemResultCompare(Status,Flag)



  X1080_mipi_wait(10)
  Shell("reg write 0x183f 0x80")
  MatchResult=Last.Output:match("(OK)")
  Flag=TestItemResultCompare(MatchResult,Flag)
  X1080_mipi_wait(10)
  Shell("reg write 0x183f 0x81")
  MatchResult=Last.Output:match("(OK)")
  Flag=TestItemResultCompare(MatchResult,Flag)
  X1080_mipi_wait(10)

  TestdataName="X1080_Connectivity_Check_25f7"
  StartTimeStr_25f7=os.time()
  Shell("reg read 0x25f7")
  MatchResult=Last.Output:match("0x25F7 => 0x(%w+)")
  TotalExeTime_25f7=os.time() - StartTimeStr_25f7
  MatchResult=tonumber(MatchResult,16)
  if MatchResult ~=nil then
    Status=CompareWithTC(TestdataName,MatchResult,"NumCompare",TotalExeTime_25f7)
  else
    Status=CompareWithTC(TestdataName,"ProcessFail","ProcessFail",TotalExeTime_25f7)
  end
  Flag=TestItemResultCompare(Status,Flag)
  X1080_mipi_wait(10)
  Shell("reg write 0x25f7 0")
  MatchResult=Last.Output:match("(OK)")
  Flag=TestItemResultCompare(MatchResult,Flag)
  X1080_mipi_wait(10)
  Shell("reg write 0x25f7 1")
  MatchResult=Last.Output:match("(OK)")
  Flag=TestItemResultCompare(MatchResult,Flag)

  TotalExeTime=os.time() - StartTimeStr
  if Flag == 0 then
      CompareWithTC(TestName,MatchResult,"StrCompare",TotalExeTime)
  else
      CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
  end
  FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
  PrintString("==================================================================================================================")
  return flagToBool(FuncResultFlag)

end


StatenToShiraztable={
  {key = "01", data = "1200"},
  {key = "02", data = "2000"},
  {key = "03", data = "2800"},
  {key = "04", data = "3600"},
  {key = "05", data = "4400"},
  {key = "06", data = "5200"},
  {key = "07", data = "6000"},
  {key = "08", data = "6800"},
  {key = "09", data = "7600"},
  {key = "0A", data = "8400"},
  {key = "0B", data = "9200"},
  {key = "0C", data = "10000"},
  {key = "0D", data = "10800"},
  {key = "0E", data = "11600"},
  {key = "0F", data = "12400"},
  {key = "10", data = "13200"},
  {key = "11", data = "14000"},
  {key = "12", data = "14800"},
  {key = "13", data = "15600"},
  {key = "14", data = "16400"},
  {key = "15", data = "17200"},
  {key = "16", data = "18000"},
  {key = "17", data = "18800"},
  {key = "18", data = "19600"},
  {key = "19", data = "20400"},
  {key = "1A", data = "21200"},
  {key = "1B", data = "22000"},
  {key = "1C", data = "22800"},
  {key = "1D", data = "23600"},
  {key = "1E", data = "24400"},
  {key = "1F", data = "25200"},
  {key = "20", data = "26000"},
  {key = "21", data = "26800"},
  {key = "22", data = "27600"},
  {key = "23", data = "28400"},
  {key = "24", data = "29200"},
  {key = "25", data = "30000"},
  {key = "26", data = "30800"},
  {key = "27", data = "31600"},
  {key = "28", data = "32400"},
  {key = "29", data = "33200"},
  {key = "2A", data = "34000"},
  {key = "2B", data = "34800"},
  {key = "2C", data = "35600"},
  {key = "2D", data = "36400"},
  {key = "2E", data = "37200"},
  {key = "2F", data = "38000"},
  {key = "30", data = "38800"},
  {key = "31", data = "39600"},
  {key = "32", data = "40400"},
  {key = "33", data = "41200"},
  {key = "34", data = "42000"},
  {key = "35", data = "42800"},
  {key = "36", data = "43600"},
  {key = "37", data = "44400"},
  {key = "38", data = "45200"},
  {key = "39", data = "46000"},
  {key = "3A", data = "46800"},
  {key = "3B", data = "47600"},
  {key = "3C", data = "48400"},
  {key = "3D", data = "49200"},
  {key = "3E", data = "50000"},
  {key = "3F", data = "50800"},
}
