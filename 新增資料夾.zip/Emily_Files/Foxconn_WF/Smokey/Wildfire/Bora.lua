require "SearchforTarget"
require "CompareAndOutput"
require "TimeRelated"


function BoraOn()
    local Flag=0
    local FuncResultFlag=0
    CsvWriteFlagCheck()
    TestName="BoraOn"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    -- csoc --on parameter '-a 1 -g \"speedy_debug=2\'
    -- Mulan P2 Burin Wildfire - X1072
    Shell("csoc --on -a 1 -g \"speedy_debug=2\"")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    TotalExeTime=os.time() - StartTimeStr
    if Flag==0 then
        CompareWithTC(TestName,"PASS","StrCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")
    return flagToBool(Flag)
end

function BoraLoadFW()
    local Flag=0
    local FuncResultFlag=0
    local OsLogFolder = GenerateOsLogFolderName()

    CsvWriteFlagCheck()
    TestName="BoraLoadFW"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    Shell("csoc --load_firmware")
    MatchResult=Last.Output:match("(DATA: firmware[-]load[=]\"Passed\".*%cOK)")

    RamlogExtrasInit()

    Shell("csi pick CSOC-CCPU")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    Shell("csi set_log_dir " .. OsLogFolder)
    Shell("csi on")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    Shell("wait 5000")
    
    Shell("csi pick CSOC-AOP")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    Shell("csi set_log_dir " .. OsLogFolder)
    Shell("csi on")
    Shell("msg --id 0 --init-master")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    Shell("msg --id 0 --intr-en")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    Shell("msg --id 0 --set-config master --assert-dur 24 --frame-dur 266657")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    Shell("msg --id 0 --sync-start")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    
    
    Shell("csi pick CSOC-ISP")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    Shell("csi set_log_dir " .. OsLogFolder)
    Shell("csi on")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    Shell("camisp --setfirmwarebootarg 16 0x00010000")
    MatchResult=Last.Output:match("(Pass)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    Shell("camisp --find")
    MatchResult=Last.Output:match("(Pass)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    TotalExeTime=os.time() - StartTimeStr
    if Flag==0 then
        CompareWithTC(TestName,"PASS","StrCompare",TotalExeTime)
        Borakeycheck=1
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")
    return flagToBool(Flag)
end
