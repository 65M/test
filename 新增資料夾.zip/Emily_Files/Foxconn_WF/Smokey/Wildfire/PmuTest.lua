require "SearchforTarget"
require "CompareAndOutput"
require "TimeRelated"
require "CheckList.PmuCheckList"

function PMU_Setup()
    local Flag=0
    local FuncResultFlag=0
    CsvWriteFlagCheck()
    TestName="PMU_Setup_Load_Debug_Firmware"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    Shell("csoc --on --load")
    Shell("csi pick CSOC-CCPU")
    Shell("csi on")
    Shell("csi pick CSOC-AOP")
    Shell("csi on")
    Shell("msg --id 0 --init-master")
    Shell("msg --id 0 --intr-en")
    Shell("msg --id 0 --set-config master --assert-dur 24 --frame-dur 266657")
    Shell("msg --id 0 --sync-start")
    Shell("msg --id 9 --init-slave 0")
    Shell("msg --id 9 --set-config slave --assert-dur 24 --offset 369456")
    Shell("msg --id 10 --init-slave 0")
    Shell("msg --id 10 --set-config slave --assert-dur 24 --offset 369456")
    Shell("msg --id 2 --init-master")
    Shell("msg --id 11 --init-slave 2")
    Shell("msg --id 11 --set-config slave")
    Shell("msg --id 2 --set-config master --assert-dur 24 --frame-dur 400000")
    Shell("msg --id 2 --sync-start")
    Shell("csi pick CSOC-ISP")
    Shell("csi on")

    Shell("camisp --dbgfw on")
    Shell("camisp --setfirmwarebootarg 16 0x00010000")
    Shell("camisp --find")
    MatchResult=Last.Output:match("(Pass)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestName,MatchResult,"StrCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")


    TestName="PMU_Setup_Buck1_Vol600_Set"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    Shell("pmuset --buck 1 --vol 600")
    Shell("wait 1000")
    PrintString("==================================================================================================================")

    CsvWriteFlagCheck()
    TestName="PMU_Setup_LDO7_On"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    Shell("reg select rpmu")

    Shell("reg write 0x25D8 0x1")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestName,MatchResult,"StrCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")

    CsvWriteFlagCheck()
    TestName="PMU_Setup_SW5_On"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    Shell("reg write 0x25E6 0x1")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestName,MatchResult,"StrCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")


    TestName="PMU_Setup_DCAM_On"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    Shell("camisp --method powerdevice on 0x03ffffff")
    Shell("camisp --method powerdevice on 0x08ffffff")
    PrintString("==================================================================================================================")

    TestName="PMU_Setup_SCAM_On"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    Shell("camisp --method powerdevice on 0x09ffffff")
    Shell("camisp --method powerdevice on 0x0Affffff")
    PrintString("==================================================================================================================")

    return flagToBool(FuncResultFlag)
end

function PMUADC_Read()
    --local Flag=0
    local FuncResultFlag=0
    --CsvWriteFlagCheck()
    Shell("pmuadc --read all")
    Shell_Log = Last.Output
    for i=1, #PmuList do
        local Flag=0
        CsvWriteFlagCheck()
        StartTimeStr=os.time()
        PrintString("\n\n====================================== Test Item :"..PmuList[i][1].." ======================================")
        --print(Shell_Log)
        MatchResult = Shell_Log:match(PmuList[i][2])
        --print(MatchResult)
        Flag=TestItemResultCompare(MatchResult,Flag)
        TotalExeTime=os.time() - StartTimeStr
        if Flag == 0 then
            CompareWithTC(PmuList[i][1],MatchResult,"NumCompare",TotalExeTime)
        else
            CompareWithTC(PmuList[i][1],"ProcessFail","ProcessFail",TotalExeTime)
        end
        FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
        PrintString("==================================================================================================================")
    end
    return flagToBool(FuncResultFlag)
end

function PMU_Exit()
    Shell("camisp --exit")
end

function PMU()
    PMU_Setup()
    PMUADC_Read()
    PMU_Exit()
end    






