require "SearchforTarget"
require "CompareAndOutput"
--IPD_temperature test:compare temperature on sensor ('motor1' and 'motor2') with expected output,and write result in CSV file
function IPD_temperature()
    -- Wait for coco solve csi on CCPU Faill
    local Flag=0--'0' means 'PASS','1' means 'FAIL'
    local FuncResultFlag=0
    local OsLogFolder = GenerateOsLogFolderName()--generate OS log folder name
    CsvWriteFlagCheck()--check test result whether output to CSV file,'CsvWriteFlag=1' means previous one not Output to CSV
    TestName="IPD_Temperature_Check"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    -- Shell("csoc --on")
    -- MatchResult=Last.Output:match("(OK)")
    -- Flag=TestItemResultCompare(MatchResult,Flag)
    -- Shell("csoc --load_firmware")
    -- MatchResult=Last.Output:match("(OK)")
    -- Flag=TestItemResultCompare(MatchResult,Flag)
    Shell("csi list")
    --[[
    list csi items:
    ANS
    SMC
    MTP
    DCP
    CSOC-CCPU
    CSOC-ISP
    CSOC-DCP
    CSOC-DCP2
    CSOC-DCP3
    CSOC-AOP 
    CSOC-AUD
    CSOC-SCDC
    CSOC-KMP
    --]]
    MatchResult=Last.Output:match("(OK)")--Shell execute result
    Flag=TestItemResultCompare(MatchResult,Flag)--compare Shell execute result with previous Flag, update Flag 
    if Borakeycheck==0 then
        Shell("csi pick CSOC-CCPU")--pick CSOC-CCPU
        MatchResult=Last.Output:match("(OK)")--Shell execute result
        Flag=TestItemResultCompare(MatchResult,Flag)--update Flag 
        Shell("csi set_log_dir " .. OsLogFolder)--set log folder
        Shell("csi on")--power on CSOC-CCPU
        MatchResult=Last.Output:match("(OK)")
        Flag=TestItemResultCompare(MatchResult,Flag)--update Flag 
        Shell("wait 5000")
    end
  
    Shell("csi pick CSOC-AOP")--pick CSOC-AOP
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    Shell("csi set_log_dir " .. OsLogFolder)
    Shell("csi on")--power on CSOC-AOP
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    -- skip parse target since CCPU issue
    Shell("sensor --sel motor1 --exectest get-temperature")--Execute test 'get-temperature' on sensor 'motor1'
    motor1Temperature=Last.Output
    MatchResult=motor1Temperature:match("(test[-]result:%s*passed.*\nPASS)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    Shell("sensor --sel motor2 --exectest get-temperature")--Execute test 'get-temperature' on sensor 'motor2'
    motor2Temperature=Last.Output
    MatchResult=motor2Temperature:match("(test[-]result:%s*passed.*\nPASS)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    TotalExeTime=os.time() - StartTimeStr
    --compare "IPD_Temperature_Check" result with expected output,and write result in CSV file
    if Flag == 0 then
        CompareWithTC(TestName,"PASS","StrCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")

    CsvWriteFlagCheck()
    TestName="IPD_motor1_MotorTemp1"
    local Flag=0
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    MatchResult=motor1Temperature:match("MotorTemp1: (%d+.%d+) C")
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)

    TotalExeTime=os.time() - StartTimeStr
    --compare "IPD_motor1_MotorTemp1" result with expected output,and write result in CSV file
    if Flag == 0 then
        CompareWithTC(TestName,MatchResult,"NumCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")

    CsvWriteFlagCheck()
    TestName="IPD_motor1_MotorTemp2"
    local Flag=0
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    MatchResult=motor1Temperature:match("MotorTemp2: (%d+.%d+) C")
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)

    TotalExeTime=os.time() - StartTimeStr
    --compare "IPD_motor1_MotorTemp2" result with expected output,and write result in CSV file
    if Flag == 0 then
        CompareWithTC(TestName,MatchResult,"NumCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")

    CsvWriteFlagCheck()
    TestName="IPD_motor2_MotorTemp1"
    local Flag=0
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    MatchResult=motor2Temperature:match("MotorTemp1: (%d+.%d+) C")
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)

    TotalExeTime=os.time() - StartTimeStr
    --compare "IPD_motor2_MotorTemp1" result with expected output,and write result in CSV file
    if Flag == 0 then
        CompareWithTC(TestName,MatchResult,"NumCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")

    CsvWriteFlagCheck()
    TestName="IPD_motor2_MotorTemp2"
    local Flag=0
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    MatchResult=motor2Temperature:match("MotorTemp2: (%d+.%d+) C")
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)

    TotalExeTime=os.time() - StartTimeStr
    --compare "IPD_motor2_MotorTemp2" result with expected output,and write result in CSV file
    if Flag == 0 then
        CompareWithTC(TestName,MatchResult,"NumCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")

    return flagToBool(FuncResultFlag)
end
