
require "SearchforTarget"
require "CompareAndOutput"

function DurantTest()
    TestName="Durant"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=CurrentTimeStr()
    local Flag=0
    local Result=0
	  local MatchResult=""

    Shell("device -k durant -e power_on")
    MatchResult=Last.Output:match("power_on")
    Flag=TestItemResultCompare(MatchResult,Flag)
	  PrintString(MatchResult)

  	Shell("device -k durant -e load_firmware")
  	Ans=Last.Output:match("Loaded FW Version%s*(.+)")
  	posS=Ans:find(",")
    MatchResult=Ans:sub(1,posS-1)
    Flag=TestItemResultCompare(MatchResult,Flag)
    PrintString("Durant_FW:")
  	PrintString(MatchResult)

  	Shell("device -k durant -e power_off")
    MatchResult=Last.Output:match("power_off")
    Flag=TestItemResultCompare(MatchResult,Flag)
  	PrintString(MatchResult)

    FinishTimeStr=CurrentTimeStr()
    TotalExeTime=TimeCalculator(StartTimeStr,FinishTimeStr)
    if Flag==0 then
  	   ResultFlag=CompareWithQTResult(TestName,"PASS","StrCompare",TotalExeTime)
  	else
  	   ResultFlag=CompareWithQTResult(TestName,"ProcessFail","ProcessFail",TotalExeTime)
  	end
    Flag=TestItemResultCompareCheck(ResultFlag,Flag)
		PrintString("==================================================================================================================")
    return flagToBool(Flag)
end

function BTTest()
    local Flag=0
    local ResultFlag=0
  	local MatchResult=""

    TestName="BT"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=CurrentTimeStr()

    Shell("bluetooth --on")
    MatchResult=Last.Output:match("OK")
    Flag=TestItemResultCompare(MatchResult,Flag)
  	PrintString(MatchResult)

  	Shell("bluetooth --load")
    MatchResult=Last.Output:match("OK")
    Flag=TestItemResultCompare(MatchResult,Flag)
  	PrintString(MatchResult)

  	Shell("bluetooth --send_raw \"0x14 0x0c 0x00\"")
    MatchResult=Last.Output:match("OK")
    Flag=TestItemResultCompare(MatchResult,Flag)
  	PrintString(MatchResult)

    -----TDO print bt FW
  	Shell("bluetooth -p")
    MatchResult=Last.Output:match("OK")
    Flag=TestItemResultCompare(MatchResult,Flag)
  	PrintString(MatchResult)

  	Shell("bluetooth --off")
    MatchResult=Last.Output:match("OK")
    Flag=TestItemResultCompare(MatchResult,Flag)
  	PrintString(MatchResult)

    FinishTimeStr=CurrentTimeStr()
    TotalExeTime=TimeCalculator(StartTimeStr,FinishTimeStr)
    if Flag==0 then
			ResultFlag=CompareWithQTResult(TestName,"OK","StrCompare",TotalExeTime)
		else
			ResultFlag=CompareWithQTResult(TestName,"ProcessFail","ProcessFail",TotalExeTime)
		end
    Flag=TestItemResultCompareCheck(ResultFlag,Flag)
		PrintString("==================================================================================================================")

    return flagToBool(Flag)
end


function SETest()
	  TestName="SE"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=CurrentTimeStr()
    local Flag=0
    local ResultFlag=0

    Shell("stockholm --on")
    MatchResult=Last.Output:match("OK")
    Flag=TestItemResultCompare(MatchResult,Flag)
  	PrintString(MatchResult)

  	Shell("stockholm --init")
    MatchResult=Last.Output:match("OK")
    Flag=TestItemResultCompare(MatchResult,Flag)
  	PrintString(MatchResult)

  	Shell("stockholm --off")
    MatchResult=Last.Output:match("OK")
    Flag=TestItemResultCompare(MatchResult,Flag)
  	PrintString(MatchResult)

    FinishTimeStr=CurrentTimeStr()
    TotalExeTime=TimeCalculator(StartTimeStr,FinishTimeStr)
    if Flag==0 then
			 ResultFlag=CompareWithQTResult(TestName,"OK","StrCompare",TotalExeTime)
		else
			 ResultFlag=CompareWithQTResult(TestName,"ProcessFail","ProcessFail",TotalExeTime)
		end
    Flag=TestItemResultCompareCheck(ResultFlag,Flag)
		PrintString("==================================================================================================================")
    return flagToBool(Flag)
end

function WiFiTest()
  	TestName="WiFi"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=CurrentTimeStr()
    local Flag=0
    local ResultFlag=0

    Shell("wifi --on")
    MatchResult=Last.Output:match("OK")
    Flag=TestItemResultCompare(MatchResult,Flag)
  	PrintString(MatchResult)

  	Shell("wifi --load")
    MatchResult=Last.Output:match("OK")
    Flag=TestItemResultCompare(MatchResult,Flag)
  	PrintString(MatchResult)

  	Shell("wifi -p")
    MatchResult=Last.Output:match("OK")
    Flag=TestItemResultCompare(MatchResult,Flag)
  	PrintString(MatchResult)

  	Shell("wifi --off")
    MatchResult=Last.Output:match("OK")
    Flag=TestItemResultCompare(MatchResult,Flag)
  	PrintString(MatchResult)

    FinishTimeStr=CurrentTimeStr()
    TotalExeTime=TimeCalculator(StartTimeStr,FinishTimeStr)
  	if Flag==0 then
  			ResultFlag=CompareWithQTResult(TestName,"OK","StrCompare",TotalExeTime)
		else
  			ResultFlag=CompareWithQTResult(TestName,"ProcessFail","ProcessFail",TotalExeTime)
		end
    Flag=TestItemResultCompareCheck(ResultFlag,Flag)
		PrintString("==================================================================================================================")
    return flagToBool(Flag)
end
