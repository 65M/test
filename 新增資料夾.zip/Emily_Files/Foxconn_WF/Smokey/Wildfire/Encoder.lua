----------- QTx Lua script--------------------------------------------------------------------------
-- Copyright (c) 2020-2022
-- All rights reserved.
--
-- Author: Payne Cai, Eric Wang*
-- Date: 2021.07.07
-- Description:
--     This script for P2 encoder test
----------------------------------------------------------------------------------------------------

require "SearchforTarget"
require "CompareAndOutput"
require "TimeRelated"
require "IPD"
-- require "CheckList.IPDcommandCheckList"

vActual_limit=2900

--[[
process string   
eg: MatchResult='abcdefg0x1A1B1C'    
    return '1C 1B 1A'
--]]
function stringprocessing(MatchResult)
    local num=""
    for word in string.gmatch(MatchResult,"0x(%w+)") do--match string
        reversestr=string.reverse(word)--reverse string 
        for str1 in string.gmatch (reversestr,"%w%w") do
            str2=string.reverse(str1)
            num=num.." "..str2
        end
    end
    return num
end

-- read key for Motc,MOTP and OMDC,and write result to CSV file
function IPD_Read()
    local Flag=0
    local FuncResultFlag=0
    CsvWriteFlagCheck() -- check test result whether output to CSV file,'CsvWriteFlag=1' means previous one not Output to CSV
    TestName="IPD_Motc_read"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()

    if Borakeycheck==0 then
        Shell("csoc --on -a 1 -g \"speedy_debug=2\"")
        MatchResult=Last.Output:match("(OK)")
        Flag=TestItemResultCompare(MatchResult,Flag)

        Shell("csoc --load_firmware")
        MatchResult=Last.Output:match("(OK)")
        Flag=TestItemResultCompare(MatchResult,Flag)

        RamlogExtrasInit()
    end

    Shell("syscfg print MotC") -- print MotC
    MotCKey=Last.Output:match("(.+)") -- get MotC key
    Existed=MotCKey:match("Not Found")
    if Existed ~= nil then
        MatchResult=nil
        MotCKey=nil
    else
        MatchResult="PASS" -- find MotC successfully
    end
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag) -- compare Shell execute result with previous Flag, update Flag 
    TotalExeTime=os.time() - StartTimeStr
    -- compare "IPD_Motc_read" result with expected output,and write result in CSV file
    if Flag == 0 then
        CompareWithTC(TestName,MatchResult,"StrCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")

    CsvWriteFlagCheck()
    TestName="IPD_MOTP_read"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    Shell("dir Hardware:\\FactoryData\\System\\Library\\Caches\\com.apple.factorydata\\") -- List the files in this directory
    MatchResult=Last.Output:match("WbCl[-]%w+[-]%w+")
    local Flag = 0
    if MatchResult == nil then
        Flag = 1
        TotalExeTime=os.time() - StartTimeStr
        error("WbCl data is missing")
    end
    Shell("fdrdecode -s Hardware:\\FactoryData\\System\\Library\\Caches\\com.apple.factorydata\\"..MatchResult) -- Decode FDR file
    MatchResult=Last.Output:match("0x.+")
    MOTP_index=string.find(MatchResult, "0x50 0x54 0x4F 0x4D", 1) -- get MOTP index in MatchResul
    -- MOTPKey=string.sub(MatchResult,MOTP_index+45, MOTP_index+45+209)--get MOTP key in MatchResul
    -- update: MOTPKey 42byte ==> 38byte
    MOTPKey=string.sub(MatchResult,MOTP_index+45, MOTP_index+45+189)-- get MOTP key in MatchResul
    OMDC_index=string.find(MatchResult, "0x43 0x44 0x4D 0x4F", 1)-- get OMDC index in MatchResul
    OMDCKey=string.sub(MatchResult,OMDC_index+45, OMDC_index+45+109)-- get OMDC key in MatchResul



    PrintString("MotcKey:"..MotCKey)
    PrintString("WbCl MOTPKey:"..MOTPKey)
    PrintString("WbCl OMDCKey:"..OMDCKey)
    local Flag = 0
    -- Shell("syscfg print MOTP")
    -- MOTPKey=Last.Output:match("(.+)")
    Existed=MOTPKey:match("Not Found")
    if Existed ~= nil then
        MatchResult=nil
        MOTPKey=nil
    else 
        MatchResult="PASS"
    end

    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)

    TotalExeTime=os.time() - StartTimeStr
    -- compare "IPD_MOTP_read" result with expected output,and write result in CSV file
    if Flag == 0 then
        CompareWithTC(TestName,MatchResult,"StrCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")

    CsvWriteFlagCheck()
    TestName="IPD_OMDC_read"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    local Flag = 0
    StartTimeStr=os.time()
    -- Shell("syscfg print OMDC")
    -- OMDCKey=Last.Output:match("(.+)")
    Existed=OMDCKey:match("Not Found")
    if Existed ~= nil then 
        MatchResult=nil
        OMDCKey=nil
    else
        MatchResult="PASS"
    end
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)

    TotalExeTime=os.time() - StartTimeStr
    -- compare "IPD_OMDC_read" result with expected output,and write result in CSV file
    if Flag == 0 then
        CompareWithTC(TestName,MatchResult,"StrCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")
    return flagToBool(FuncResultFlag)
end

-- get motc by motckey, MOTC 12
function GetMotcByMotckey(MotCKey)
    local MotC_result = ""
    local count = 0
    local temp =""
    local temp0=""
    local temp1=""
    local temp2=""
    local temp3=""

    for word in string.gmatch(MotCKey,"%d%d") do
        if count >= 12 then
            break
        end
--        if count == 5 or count == 9 then
--            word = "01"
--        end
        if count % 4 == 0 then
            temp0 = "0x"..word..","
        elseif count % 4 == 1 then
            temp1 = "0x"..word..","
        elseif count % 4 == 2 then
            temp2 = "0x"..word..","
        elseif count % 4 == 3 then
            temp3 = "0x"..word..","
            temp = temp3..temp2..temp1..temp0
            MotC_result=MotC_result..temp
        end
        count = count+1
    end
    MotC_result=string.sub(MotC_result,0,-2)
    return MotC_result
end

-- write IPD
function IPD_Write(motorNum)
    local Flag=0
    local OsLogFolder = GenerateOsLogFolderName()--generate os log folder name
    CsvWriteFlagCheck()
    TestName="IPD_"..motorNum.."_MotC_Write"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    MotC_result=""

    -- for word in string.gmatch(MotCKey,"%d%d") do
    --     MotC_result=MotC_result.."0x"..word..","
    -- end
    -- MotC_result=string.sub(MotC_result,0,-2)--remove the last comma

    -- updata:MotC_result 16byte ==> 12byte  
    MotC_result = GetMotcByMotckey(MotCKey)

    -- Add for solve <radar://80893505>
    Shell("csi pick CSOC-CCPU") -- pick CSOC-CCPU
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)-- compare Shell execute result with previous Flag, update Flag
    Shell("csi set_log_dir " .. OsLogFolder)-- set log directory
    Shell("csi on") -- power on CSOC-CCPU
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    Shell("wait 25000")
    Shell("csi pick CSOC-AOP") -- pick CSOC-AOP
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    Shell("csi set_log_dir " .. OsLogFolder)
    Shell("csi on") -- power on CSOC-AOP
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    Shell("sensor --sel "..motorNum.." --get ready") -- get sensor motor ready
    MatchResult=Last.Output:match("(true)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    Shell("sensor --sel "..motorNum.." --exectest set_named --testopts ".."\"MOTC 12 "..MotC_result.."\"")--execute test 'set_named' on sensor motor
    MatchResult=Last.Output:match("(PASS)")
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)

    TotalExeTime=os.time() - StartTimeStr
    if Flag == 0 then
        CompareWithTC(TestName,MatchResult,"StrCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")
    -- Remove MotC, MotP, OMDC set in diag to resolve rdar://100200664 (Mulan EVT | Wildfire IPD DOE)
    CsvWriteFlagCheck()
    TestName="IPD_"..motorNum.."_MOTP_Write"
    local Flag=0
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    MOTP_result=string.gsub(string.sub(MOTPKey,0,-2)," ",",")
	Shell("sensor --sel "..string.gsub(motorNum,"motor","encoder").." --exectest set_named --testopts ".."\"MOTP 38 "..MOTP_result.."\"")
    MatchResult=Last.Output:match("(PASS)")
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)

    TotalExeTime=os.time() - StartTimeStr
    --compare "IPD_"..motorNum.."_MOTP_Write" result with expected output,and write result in CSV file
    if Flag == 0 then
        CompareWithTC(TestName,MatchResult,"StrCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")

    CsvWriteFlagCheck()
    TestName="IPD_"..motorNum.."_OMDC_Write"
    local Flag=0
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    OMDC_result=string.gsub(string.sub(OMDCKey,0,-2)," ",",")
    Shell("sensor --sel "..string.gsub(motorNum,"motor","encoder").." --exectest set_named --testopts ".."\"OMDC 22 "..OMDC_result.."\"")
    MatchResult=Last.Output:match("(PASS)")
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)

    TotalExeTime=os.time() - StartTimeStr
    -- compare "IPD_"..motorNum.."_OMDC_Write" result with expected output,and write result in CSV file
    if Flag == 0 then
        CompareWithTC(TestName,MatchResult,"StrCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")
    return flagToBool(FuncResultFlag)
end

-- set up IPD
function IPD_SetUp(motorNum)
    local Flag=0
    local FuncResultFlag=0
    local IPDConfigFlag = 0 
    CsvWriteFlagCheck()
    TestName="IPD_"..motorNum.."_SetUp"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    VNum=motorNum:sub(-1)
    Shell('boardrev')
    MatchResult=Last.Output:match("Board Revision: 0x07")
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)
    if Flag == 0 then
		Shell("sensor --sel encoder"..VNum.." --exectest set --testopts 0x73 1 0") --KY: add to turn on encoder
	else
		PrintString("This's NOT EVT board")
	end
    
    Shell("sensor --sel "..motorNum.." --exectest set-power --testopts \"1 --dual\"") -- Turn on sensor power before RSENSE change
    MatchResult=Last.Output:match("(PASS)")
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)
    
    Shell("wait 100")
    --pcall(Shell, "syscfg print CFG#")
    --MatchResult=Last.Output:match("(%w+/%w+[-]?%w+/.+%w)")
    --if MatchResult==nil then
        --PrintString("There's no CFG info")
    Shell("sensor --sel "..motorNum.." --exectest set --testopts 0x6E 4 0x6C,0x02,0x00,0x00")
    --else
        --MotorInit = require [[MotorInit]]; if MotorInit:CheckLoaded() then MotorInit:SetupMotor() end
    --end
    --KY: Removed the search thru the 620mOhm Rsense config list for N301 MP/DSP intent
    
    Shell("wait 5000")
    Shell("sensor --sel "..motorNum.." --exectest set-power --testopts \"0 --dual\"") -- Turn off sensor power after RSENSE change
    MatchResult=Last.Output:match("(PASS)") 
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)
    Shell("wait 100")

    -- add sensor set-power command in the front of IPD_Setup
    Shell("sensor --sel "..motorNum.." --exectest set-power --testopts \"1 --dual\"")
    MatchResult=Last.Output:match("(PASS)")
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)
    Shell("wait 200")

    Shell("sensor -s "..motorNum.." --exectest get --testopts 0x6E")

    Shell("sensor --sel encoder"..VNum.." --set rate 50")--Set parameter 'rate' to 50 for encoder
    MatchResult=Last.Output:match("(OK)")
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)

    Shell("sensorreg --sel encoder"..VNum.." --write 0x0F 0x04")--Write 1 registers to address 0x0F:0x0F = 0x04
    MatchResult=Last.Output:match("(OK)")
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)

    Shell("sensorreg --sel encoder"..VNum.." --write 0x75 0x03")--Writing 1 registers to address 0x75:0x75 = 0x03
    MatchResult=Last.Output:match("(OK)")
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)
    --remove Irun set in diag to resolve rdar://100200664 (Mulan EVT | Wildfire IPD DOE)
    --add speed controller mode get in diag to resolve rdar://100200664 (Mulan EVT | Wildfire IPD DOE)

    Shell("sensor --sel "..motorNum.." --exectest get --testopts 0x4B")--execute test 'get' on sensor motor
    MatchResult=Last.Output:match("(PASS)")
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)

    Shell("sensor --sel "..motorNum.." --exectest get --testopts 0x48")--execute test 'get' on sensor motor
    MatchResult=Last.Output:match("(PASS)")
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)

    -- “sensor --sel encoder1 --exectest set --testopts 0x4F 1 1” was an error check cmd， move away
    -- Shell("sensor --sel encoder"..VNum.." --exectest set --testopts 0x4F 1 1")--execute test 'set' on sensor encoder
    -- MatchResult=Last.Output:match("(PASS)")
    -- PrintString(MatchResult)
    -- Flag=TestItemResultCompare(MatchResult,Flag)

    Shell("sensor --sel "..motorNum.." --exectest set --testopts 0x4A 1 0") -- execute test 'set' on sensor motor
    MatchResult=Last.Output:match("(PASS)")
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)

    if Motordetectionflag==0 then
    	Shell("sensor --sel motor1 --exectest get --testopts 0x6F 4")
        Shell("sensor --sel motor1 --exectest set --testopts 0x6F 4 0x01,0x00,0x00,0x00")
        Shell("sensor --sel motor1 --exectest get --testopts 0x6F 4")
        Motordetectionflag=1

    end

    --Shell("sensorreg --sel "..motorNum.." --write 0x27 0x000346DB")
    --Shell("sensorreg --sel "..motorNum.." --write 0x47 0x000346DB") --added to limit the max speed 12/15
    Shell("sensorreg --sel "..motorNum.." --write 0x27 0x229A6") --added to limit the max speed  03/01
    Shell("sensorreg --sel "..motorNum.." --write 0x47 0x229A6")
    
    Shell("sensor -s encoder"..VNum.." --set print_mode bookend") -- added for 2h bundle AOP change
    MatchResult=Last.Output:match("(OK)")
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)
    

    Shell("smc write F1Md 1") -- Key Write "F1Md": 00000000:01
    MatchResult=Last.Output:match("(OK)")
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)

    Shell("smc fwrite F1Tg 3300") -- Key write "F1Tg" of type flt :  00000000: 00 F8 E0 45 
    MatchResult=Last.Output:match("(OK)")
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)

    Shell("smc write F0Md 1") -- Key Write "F0Md": 00000000: 01
    MatchResult=Last.Output:match("(OK)")
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)

    Shell("smc fwrite F0Tg 3300") -- Key write "F0Tg" of type flt . 00000000: 00 F8 E0 4
    MatchResult=Last.Output:match("(OK)")
    PrintString(MatchResult)
    TotalExeTime=os.time() - StartTimeStr
    Flag=TestItemResultCompare(MatchResult,Flag)
    if Flag == 0 then
        CompareWithTC(TestName,"PASS","StrCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")
    return flagToBool(FuncResultFlag)
end

function Temperature_monitoring(start_time)
    local CostTime=0
    local WaitTemp= 40
    while true  do
        Shell("sensor --sel motor1 --exectest get-temperature")
        motor1Temperature=Last.Output
        motor1Temperature_MotorTemp1=motor1Temperature:match("MotorTemp1: (%d+.%d+) C")
        motor1Temperature_MotorTemp2=motor1Temperature:match("MotorTemp2: (%d+.%d+) C")
        Shell("sensor --sel motor2 --exectest get-temperature")
        motor2Temperature=Last.Output
        motor2Temperature_MotorTemp1=motor2Temperature:match("MotorTemp1: (%d+.%d+) C")
        motor2Temperature_MotorTemp2=motor2Temperature:match("MotorTemp2: (%d+.%d+) C")
        if motor1Temperature_MotorTemp1==nil or motor1Temperature_MotorTemp2==nil or motor2Temperature_MotorTemp1==nil or motor2Temperature_MotorTemp2==nil then
            PrintString("Not able to read all xmotor temp at this moment, force 120s cool down")
            Shell("wait 120000")
            endtime = os.time()
            CostTime = endtime - start_time
            break
        end
        motor1Temperature_MotorTemp1=tonumber(motor1Temperature_MotorTemp1)
        motor1Temperature_MotorTemp2=tonumber(motor1Temperature_MotorTemp2)
        motor2Temperature_MotorTemp1=tonumber(motor2Temperature_MotorTemp1)
        motor2Temperature_MotorTemp2=tonumber(motor2Temperature_MotorTemp2)
        endtime = os.time()
        CostTime = endtime - start_time
        print("Debug: "..CostTime.. "s")
        if motor1Temperature_MotorTemp1< WaitTemp and motor1Temperature_MotorTemp2< WaitTemp and motor2Temperature_MotorTemp1< WaitTemp and motor2Temperature_MotorTemp2< WaitTemp then
            break
        end
        if CostTime>120 then
            break
        end
        Shell("wait 5000")
    end 
    return CostTime
end

function IPD_MOTP_Location_redirection(MOTORnum,EncoderName,key1,key2)
    local FuncResultFlag=0
    CsvWriteFlagCheck()
    MOTPByteList={}
    TestName=EncoderName.."_Read"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    local Flag = 0
    -- Shell("syscfg printbyte MOTP")
    for word in string.gmatch(MOTPKey, "0x(%w%w)")
    do
        PrintString(word)
        table.insert(MOTPByteList,word) -- insert MOTPKey into MOTPByteList
    end
    MOTORvalue=""
    PrintString("=============key============")
    PrintString(key1)
    PrintString(key2)
    PrintString("=============key============")
    for i=key1,key2 do
        MOTORvalue=MOTPByteList[i]..MOTORvalue -- get MOTORvalue from MOTPByteList
    end

    MOTORvalue=tonumber(MOTORvalue,16) -- convert MOTORvalue from hexadecimal to decimal
    PrintString("=============Num============")
    PrintString(MOTORvalue)
    PrintString("=============Num============")

    TestName=EncoderName.."_Location_redirection"
    local Flag = 0
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr= os.time()
    Shell("sensor --sel "..MOTORnum.." --exectest go --testopts \"--pos "..MOTORvalue.." --timeout 40000ms\"") -- execute test 'go' on sensor motor
    MatchResult=Last.Output:match("(PASS)")
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)
    --Temperature_monitoring function  to decrease wildfire test time
    TotalExeTime = Temperature_monitoring(StartTimeStr)
    if Flag == 0 then
        CompareWithTC(TestName,MatchResult,"Show",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")  
    return flagToBool(FuncResultFlag)
end

function IPD_MOTP_SS_MIN_MAX_Read(MOTORnum,EncoderName,key1,key2)
    local Flag=0
    local FuncResultFlag=0
    CsvWriteFlagCheck()
    MOTPByteList={}
    TestName=EncoderName.."_Read"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    local Flag = 0
    -- Shell("syscfg printbyte MOTP")
    for word in string.gmatch(MOTPKey, "0x(%w%w)")
    do
        PrintString(word)
        table.insert(MOTPByteList,word) -- insert MOTPKey into MOTPByteList
    end
    MOTORvalue=""
    PrintString("=============key============")
    PrintString(key1)
    PrintString(key2)
    PrintString("=============key============")
    for i=key1,key2 do
        MOTORvalue=MOTPByteList[i]..MOTORvalue -- get MOTORvalue from MOTPByteList
    end

    MOTORvalue=tonumber(MOTORvalue,16) -- convert MOTORvalue from hexadecimal to decimal
    PrintString("=============Num============")
    PrintString(MOTORvalue)
    PrintString("=============Num============")

    TotalExeTime=os.time() - StartTimeStr
    -- compare "EncoderName.."_Read" result with expected output,and write result in CSV file
    if Flag == 0 then
        CompareWithTC(TestName,MOTORvalue,"Show",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")
    
    CsvWriteFlagCheck()
    TestName=EncoderName.."_Go"
    local Flag = 0
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    Shell("sensor --sel "..MOTORnum.." --exectest go --testopts \"--pos "..MOTORvalue.." --timeout 40000ms\"") -- execute test 'go' on sensor motor
    MatchResult=Last.Output:match("(PASS)")
      TestName1=EncoderName.."_Go_vActual"
    local Flag = 0
    PrintString("\n\n====================================== Test Item :"..TestName1.." ======================================")
    StartTimeStr1=os.time()
    MatchResult1= Last.Output:match("vActual%s+(.-)%s+")
    --for word in string.gmatch(Last.Output, "vActual%s+(.-)%s+") do 
    --    if math.abs(MatchResult1)<= math.abs(word) then
    --        MatchResult1=word
    --    else
    --        MatchResult1=MatchResult1
    --    end
    --end
	--Change for v2 velocity change
    list1= {}
    list2= {}
    vActuallist={}
    local vActualMAX = 0
    --local index=1
    --local index2=1
    for word in string.gmatch(Last.Output, "companion timestamp%s+(.-),") do 
        table.insert(list1,word) -- insert companion timestamp into list1
    end
    for word in string.gmatch(Last.Output, "encoder data%s+(.-)%s+") do 
        table.insert(list2,word) -- insert encoder data into list2
    end
    for i=2,#list1 do
        Eventtimestamp=list1[i-1]
        encoderdata=list2[i-1]
        Eventtimestamp=list1[i]-Eventtimestamp
        --print("Companionstamp="..Eventtimestamp)
        encoderdata=list2[i]-encoderdata
        print("Companionstamp="..Eventtimestamp)
        print("encoderdata="..encoderdata)
        vActual=math.abs(encoderdata)/math.abs(Eventtimestamp)
        PrintString("vActual="..vActual*1000000)
        vActual=tonumber(string.format("%.3f", vActual*1000000))
        table.insert(vActuallist,math.abs(vActual))
    end
    function avg(a)
        local values = {}
        k = 0
        for i=1, #a-4 do
            k = (a[i]+a[i+1]+a[i+2]+a[i+3]+a[i+4])/5
            table.insert(values, k)
            print("avg5 = "..values[i])
        end
        return values
    end
    function max(a)
        local values = {}
        for k, v in pairs(a) do
            if type(k) == "number" and type(v) == "number" then
                values[#values+1] = v
            end
        end
        table.sort(values)
        return values[#values]
    end
    if EncoderName=="IPD_MOTP_MOTOR1_SS_MIN" or EncoderName=="IPD_MOTP_MOTOR2_SS_MIN"  then
        TestName1=EncoderName.."_Go_vActual_max2min_peak"
        vActualMAX_peak=max(vActuallist)
        PrintString("vActual_Max_Peak="..vActualMAX_peak)
        Flag=TestItemResultCompare(MatchResult1,Flag)
        TotalExeTime1=os.time() - StartTimeStr1
        if Flag == 0 then
            CompareWithTC(TestName1,vActualMAX_peak,"NumCompare",TotalExeTime1)
        else
            CompareWithTC(TestName1,"ProcessFail","ProcessFail",TotalExeTime1)
        end

        TestName1=EncoderName.."_Go_vActual_max2min"
        vActuallist = avg(vActuallist)
        vActualMAX=max(vActuallist)
        PrintString("vActual_Max="..vActualMAX)
        Flag=TestItemResultCompare(MatchResult1,Flag)
        -- compare EncoderName.."_Go" result with expected output,and write result in CSV file
        if Flag == 0 then
            CompareWithTC(TestName1,vActualMAX,"NumCompare",TotalExeTime1)
        else
            CompareWithTC(TestName1,"ProcessFail","ProcessFail",TotalExeTime1)
        end
    else
        TestName1=EncoderName.."_Go_vActual_min2max_peak"
        vActualMAX_peak=max(vActuallist)
        PrintString("vActual_Max_Peak="..vActualMAX_peak)
        Flag=TestItemResultCompare(MatchResult1,Flag)
        TotalExeTime1=os.time() - StartTimeStr1
        if Flag == 0 then
            CompareWithTC(TestName1,vActualMAX_peak,"NumCompare",TotalExeTime1)
        else
            CompareWithTC(TestName1,"ProcessFail","ProcessFail",TotalExeTime1)
        end

        TestName1=EncoderName.."_Go_vActual_min2max"
        for i=3,#vActuallist-2 do
            if vActuallist[i]>vActual_limit then
                if vActuallist[i-1]>vActual_limit and vActuallist[i+1]>vActual_limit then
                    if vActuallist[i-2]>vActual_limit or vActuallist[i+2]>vActual_limit then
                        PrintString("vActual_Result= HHHH Fail")
                        vActual_Result="FAIL"
                    end
                end
            else
                vActual_value=vActuallist[i]
                if vActual_value>vActualMAX then
                    vActualMAX=vActual_value
                end
                
            end
        end
        if vActual_Result=="FAIL" then
            vActualMAX=max(vActuallist)
        end
        PrintString("vActual_Max="..vActualMAX)
        Flag=TestItemResultCompare(MatchResult1,Flag)
        -- compare EncoderName.."_Go" result with expected output,and write result in CSV file
        if Flag == 0 then
            CompareWithTC(TestName1,vActualMAX,"NumCompare",TotalExeTime1)
        else
            CompareWithTC(TestName1,"ProcessFail","ProcessFail",TotalExeTime1)
        end
    end
    
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")
    
    --Temperature_monitoring function  instead to decrease wildfire test time
    TotalExeTime = Temperature_monitoring(StartTimeStr)
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)
    if Flag == 0 then
        CompareWithTC(TestName,MatchResult,"Show",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")
  
    return flagToBool(FuncResultFlag)
end

function Fan_reset()
	Shell("smc write F0Md 0")
	Shell("smc write F1Md 0")

end

function SYSCFG_Encoder() -- encode motor1_MOTP and motor2_MOTP 
    IPD_MOTP_SS_MIN_MAX_Read("motor1","IPD_MOTP_MOTOR1_SS_MIN",10,13)
    IPD_MOTP_SS_MIN_MAX_Read("motor1","IPD_MOTP_MOTOR1_SS_MAX",18,21)
    IPD_MOTP_SS_MIN_MAX_Read("motor2","IPD_MOTP_MOTOR2_SS_MIN",27,30)
    IPD_MOTP_SS_MIN_MAX_Read("motor2","IPD_MOTP_MOTOR2_SS_MAX",35,38)
end

---------------------------------------Plist------------------------------------------------------

function IPD_Motor1_Test() -- motor1 IPD test
    if Encoderkeycheck == 1 then
        IPD_Write("motor1")
    else
        IPD_Write("motor1")
        IPD_SetUp("motor1")
        IPD_MOTP_Location_redirection("motor1","IPD_MOTP_MOTOR1_SS_MAX",18,21)
        IPD_MOTP_SS_MIN_MAX_Read("motor1","IPD_MOTP_MOTOR1_SS_MIN",10,13)
        IPD_MOTP_SS_MIN_MAX_Read("motor1","IPD_MOTP_MOTOR1_SS_MAX",18,21)
    end
end

function IPD_Motor2_Test() -- motor2 IPD test
    if Encoderkeycheck == 1 then
        IPD_Write("motor2")
        Fan_reset()
    else
        IPD_Write("motor2")
        IPD_SetUp("motor2")
        IPD_MOTP_Location_redirection("motor2","IPD_MOTP_MOTOR2_SS_MAX",35,38)
        IPD_MOTP_SS_MIN_MAX_Read("motor2","IPD_MOTP_MOTOR2_SS_MIN",27,30)
        IPD_MOTP_SS_MIN_MAX_Read("motor2","IPD_MOTP_MOTOR2_SS_MAX",35,38)
        Fan_reset()
    end        
end
