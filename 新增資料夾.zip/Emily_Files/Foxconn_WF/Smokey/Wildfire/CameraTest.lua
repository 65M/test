require "SearchforTarget"
require "CompareAndOutput"
require "CommonLib"

function CameraTests()
    CsvWriteFlagCheck()
    TestName="CameraTests_Command"
    local FuncResultFlag=0
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    -- call Camera py file
    Shell("upy nandfs:\\AppleInternal\\Diags\\Scripts\\N301\\cameraTests.py")
    ExecResult=Last.Output
    -- PrintString("====CameraTests.py Output====")
    -- -- PrintString(ExecResult)
    -- PrintString("====CameraTests.py Output====")
    cmdResult=pyFileProcessor(ExecResult)
    CameraPyCoommandExecFlag=CameraResultProcessor(cmdResult)
    if CameraPyCoommandExecFlag=="FAIL" then
      FuncResultFlag=1
    end
    
    TotalExeTime=os.time() - StartTimeStr
    CompareWithTC(TestName,CameraPyCoommandExecFlag,"StrCompare",TotalExeTime)
    PrintString("==================================================================================================================")
  
    return flagToBool(FuncResultFlag)
  end
  
