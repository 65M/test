require "SearchforTarget"
require "CompareAndOutput"

function Crown()
    TestName="CROWN"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=CurrentTimeStr()
    local MatchResult=""
    local Flag=0
    local ResultFlag=0

    Shell("memrw --32 0x24a820038 0x00870382")
    MatchResult=Last.Output:match("OK")
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)

    Shell("wait 1000")

    Shell("memrw --32 0x24a820038 0x00870383")
    MatchResult=Last.Output:match("OK")
    Flag=TestItemResultCompare(MatchResult,Flag)
    PrintString(MatchResult)

    Shell("wait 1000")

    Shell("sensor --listsensors")
    MatchResult=Last.Output:match("OK")
    Flag=TestItemResultCompare(MatchResult,Flag)
    PrintString(MatchResult)

    Shell("sensor -s lisa --turnoff")
    MatchResult=Last.Output:match("OK")
    Flag=TestItemResultCompare(MatchResult,Flag)
    PrintString(MatchResult)

    FinishTimeStr=CurrentTimeStr()
    TotalExeTime=TimeCalculator(StartTimeStr,FinishTimeStr)
    if Flag==0 then
        ResultFlag=CompareWithQTResult(TestName,"OK","StrCompare",TotalExeTime)
    else
        ResultFlag=CompareWithQTResult(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    Flag=TestItemResultCompareCheck(ResultFlag,Flag)
    PrintString("==================================================================================================================")
    return Flag
end

function LisaInit1()
    TestName="Lisa_Init1"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=CurrentTimeStr()
    local MatchResult=""
    local Flag=0
    local ResultFlag=0

    pcall(Shell,"sensor -s lisa --init")
    MatchResult=Last.Output:match("OK")
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)

    --TBD
    Shell("sensor -s lisa --get fw_version")
    MatchResult=Last.Output:match("OK")
    Flag=TestItemResultCompare(MatchResult,Flag)
    PrintString(MatchResult)
    --TBDdiscuss

    --Will got command fail so use pcall
    pcall(Shell,"sensor -s lisa --sample 10 --stats --quiet")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    PrintString(MatchResult)

    FinishTimeStr=CurrentTimeStr()
    TotalExeTime=TimeCalculator(StartTimeStr,FinishTimeStr)
    if Flag==0 then
        ResultFlag=CompareWithQTResult(TestName,"OK","StrCompare",TotalExeTime)
    else
        ResultFlag=CompareWithQTResult(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    Flag=TestItemResultCompareCheck(ResultFlag,Flag)
    PrintString("==================================================================================================================")

    return Flag
end

function LisaInit2()
    TestName="Lisa_Init2"
    local Flag=0
    local ResultFlag=0
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=CurrentTimeStr()

    pcall(Shell,"sensor -s lisa --init")
    MatchResult=Last.Output:match("OK")
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)
    --TBDdiscuss

    Shell("sensor -s lisa --set dac-mode manual led-curr 3")
    MatchResult=Last.Output:match("OK")
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)

    Shell("sensor -s lisa --set rate 1024")
    MatchResult=Last.Output:match("OK")
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)

    Shell("sensor -s lisa --sample 2000 --stats")
    MatchResult=Last.Output:match("OK")
    PrintString(MatchResult)
    Flag=TestItemResultCompare(MatchResult,Flag)
    --TBDdiscuss

    FinishTimeStr=CurrentTimeStr()
    TotalExeTime=TimeCalculator(StartTimeStr,FinishTimeStr)
    if Flag==0 then
        ResultFlag=CompareWithQTResult(TestName,"OK","StrCompare",TotalExeTime)
    else
        ResultFlag=CompareWithQTResult(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    Flag=TestItemResultCompareCheck(ResultFlag,Flag)
    PrintString("==================================================================================================================")
    return Flag
end

function CrownButton()
    TestName="Crown button"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=CurrentTimeStr()
    local Flag=0

    Shell("pmustat btn")
    BtnStr=Last.Output

    TestName="Crown button 1"
    MatchResult1=BtnStr:match("BTN1%p%s*(%w+)")
    PrintString(MatchResult1)

    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    PrintString(MatchResult1)
    if MatchResult1 ~= nil then
        ResultFlag=CompareWithQTResult(TestName,MatchResult1,"StrCompare",0)
    else
        ResultFlag=CompareWithQTResult(TestName,"ProcessFail","ProcessFail",0)
    end
    Flag=TestItemResultCompareCheck(ResultFlag,Flag)

    PrintString("==================================================================================================================")

    TestName="Crown button 2"
    MatchResult2=BtnStr:match("BTN2%p%s*(%w+)")
    PrintString(MatchResult2)
    Flag=TestItemResultCompare(MatchResult2,Flag)

    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")

    PrintString(MatchResult2)
    if MatchResult2 ~= nil then
        ResultFlag=CompareWithQTResult(TestName,MatchResult2,"StrCompare",0)
    else
        ResultFlag=CompareWithQTResult(TestName,"ProcessFail","ProcessFail",0)
    end
    Flag=TestItemResultCompareCheck(ResultFlag,Flag)

    PrintString("==================================================================================================================")

    MatchResult = MatchResult1..","..MatchResult2
    FinishTimeStr=CurrentTimeStr()
    TotalExeTime=TimeCalculator(StartTimeStr,FinishTimeStr)
    if Flag==0 then
        ResultFlag=CompareWithQTResult(TestName,MatchResult,"Show",TotalExeTime)
    else
        ResultFlag=CompareWithQTResult(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    Flag=TestItemResultCompareCheck(ResultFlag,Flag)

    PrintString("==================================================================================================================")
    return Flag
end

function CrownTestItem()
    local ResultFlags=0
    local Flag=0
    ResultFlags=Crown()
    Flag=TestItemResultCompareCheck(ResultFlags,Flag)
    ResultFlags=LisaInit1()
    Flag=TestItemResultCompareCheck(ResultFlags,Flag)
    ResultFlags=LisaInit2()
    Flag=TestItemResultCompareCheck(ResultFlags,Flag)
    ResultFlags=CrownButton()
    Flag=TestItemResultCompareCheck(ResultFlags,Flag)

    return flagToBool(Flag)
end
