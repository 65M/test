require "SearchforTarget"
require "CompareAndOutput"

function SilegoLock()
    CsvWriteFlagCheck()
    local FuncResultFlag=0
    --TestName="silegolock"
    TestdataName="Silego_Reg_Read"
    local Flag=0
    PrintString("\n\n====================================== Test Item :"..TestdataName.." ======================================")
    StartTimeStr=os.time()
    Shell('i2c -d 12 0x08 0xE0 16')
    MatchResult=Last.Output:match("0x08  0x02  0x00  0x00  0x01  0x00  0x00  0x00  0x00  0x00  0x00  0x00  0x00  0x00  0x00  0x00")
    Flag=TestItemResultCompare(MatchResult,Flag)
    TotalExeTime=os.time() - StartTimeStr
    if MatchResult==nil then     
        MatchResult=1
        PrintString("MatchResult="..MatchResult)
        error("Silego is not locked, test failed!")
    else
        MatchResult=0
        PrintString("MatchResult="..MatchResult)
    end
    if Flag == 0 then
        CompareWithTC(TestdataName,MatchResult,"NumCompare",TotalExeTime)
    else
        CompareWithTC(TestdataName,MatchResult,"NumCompare",TotalExeTime)
    end
    -- Only if SilegoLock is locked to do the Silego_Lock_Check
    if MatchResult==0 then
    	TestdataName="Silego_Lock_Check"
    	PrintString("\n\n====================================== Test Item :"..TestdataName.." ======================================")
    	Shell('i2c -d 12 0x08 0x7A 1')
    	Shell('i2c -v 12 0x08 0x7A 0xE0')
    	Shell('i2c -d 12 0x08 0x7A 1')
    	MatchResult=Last.Output:match("0xA0")
    	Flag=TestItemResultCompare(MatchResult,Flag)
    	if MatchResult==nil then
        	MatchResult=1
    	else
        	MatchResult=0
    	end
    	TotalExeTime=os.time() - StartTimeStr
    	if Flag == 0 then
        	CompareWithTC(TestdataName,MatchResult,"NumCompare",TotalExeTime)
    	else
        	CompareWithTC(TestdataName,MatchResult,"NumCompare",TotalExeTime)
    	end
    	FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    	PrintString("=================================================================================================================")
    end
    return flagToBool(FuncResultFlag)
end
   
 
function SilegoTest()
    SilegoLock()
    -- Removed cfg check for N301 MP/DSP intent
end