---------------------------------------------------------------------------
-- SensorTests.
---------------------------------------------------------------------------

-- Takes in name of sensor in a Main.plist fashion
function SensorConnectivity(Args)
    require "Burnin"

    ExecuteSensorConnectivity(Args.Name)
end

function SensorSampleTest(Args)
    require "Burnin"

    ExecuteTestSensor(Args.Name)
end

