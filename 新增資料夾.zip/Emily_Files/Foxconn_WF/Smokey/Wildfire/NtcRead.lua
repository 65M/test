----------- QTx Lua script--------------------------------------------------------------------------
-- Copyright (c) 2020-2022
-- All rights reserved.
--
-- Author: Hungwen Wang, Eric Wang*
-- Date: 2021.01.08
-- Description:
--     This script was for NTC value read
----------------------------------------------------------------------------------------------------

require "SearchforTarget"
require "CompareAndOutput"
require "TimeRelated"

ListDevice={"soc","pmu","pmu2"}
ListSocItem={"THERMAL0","THERMAL1","THERMAL2"}
ListSocItemSchema={"Instant","Max","Min","Average"}
ListPmuItem={"TCAL","TDEV1","TDEV2","TDEV3","TDEV4","TDEV5","TDEV6","TDEV7","TDEV8"}
ListPmuItemSchema={"Instant"}
ListPmu2Item={"TCAL","TDEV1","TDEV2","TDEV3","TDEV4","TDEV5"}
ListPmu2ItemSchema={"Instant"}

function CatchSoc(LogStr)
    local ResultFlag=0
    local Flag=0
    local SocStopPos=0
    local StopLevel2=0
    local StopLevel3=0
    for i=1,#ListSocItem do
        for j=1,#ListSocItemSchema do
            TestName=(string.upper(ListDevice[1])).."_"..ListSocItem[i].."_"..ListSocItemSchema[j]
            PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
            StartTimeStr=CurrentTimeStr()
            if SocStopPos==0 then
                Start,SocStopPos=string.find(LogStr,"(soc)")
            end
            Start,StopLevel2,Ans=string.find(LogStr,"([_]?"..ListSocItem[i]..")",SocStopPos+1)
            while(Ans~=ListSocItem[i])
            do
                Start,StopLevel2,Ans=string.find(LogStr,"([_]?"..ListSocItem[i]..")",StopLevel2+1)
            end
            Start,StopLevel3,Ans=string.find(LogStr,"("..ListSocItemSchema[j]..")",StopLevel2)
            Start,Stop,SocValue=string.find(LogStr,"([-]?%d+[.]?%d+)",StopLevel3+2)
            FinishTimeStr=CurrentTimeStr()
            TotalExeTime=TimeCalculator(StartTimeStr,FinishTimeStr)
            if Ans~=nil then
                ResultFlag=CompareWithQTResult(TestName,SocValue,"NumCompare",TotalExeTime)
                --ReportData(TestName,tonumber(SocValue),"NA",0,100)
            else
                ResultFlag=CompareWithQTResult(TestName,"Process Fail","Process Fail",TotalExeTime)
            end
            Flag=TestItemResultCompareCheck(ResultFlag,Flag)
            PrintString("=======================================================================================================")
        end
    end
    return Flag
end

function CatchPmu(LogStr)
    local Flag=0
    local ResultFlag=0
    local pmuStopPos=0
    local StopLevel2=0
    local StopLevel3=0
    for i=1,#ListPmuItem do
        for j=1,#ListPmuItemSchema do
            TestName=(ListDevice[2]).."_"..ListPmuItem[i].."_"..ListPmuItemSchema[j]
            PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
            StartTimeStr=CurrentTimeStr()
            if pmuStopPos==0 then
                Start,pmuStopPos=string.find(LogStr,"(pmu)")
            end
            Start,StopLevel2,Ans=string.find(LogStr,"([_]?"..ListPmuItem[i]..")",pmuStopPos+1)
            while(Ans~=ListPmuItem[i])
            do
                Start,StopLevel2,Ans=string.find(LogStr,"([_]?"..ListPmuItem[i]..")",StopLevel2+1)
            end
            Start,StopLevel3,Ans=string.find(LogStr,"("..ListPmuItemSchema[j]..")",StopLevel2)
            Start,Stop,pmuValue=string.find(LogStr,"([-]?%d+[.]?%d+)",StopLevel3+2)
            FinishTimeStr=CurrentTimeStr()
            TotalExeTime=TimeCalculator(StartTimeStr,FinishTimeStr)
            if (pmuValue)~=nil then
                ResultFlag=CompareWithQTResult(TestName,pmuValue,"NumCompare",TotalExeTime)
            else
                ResultFlag=CompareWithQTResult(TestName,"Process Fail","Process Fail",TotalExeTime)
            end
            Flag=TestItemResultCompareCheck(ResultFlag,Flag)
            PrintString("=======================================================================================================")
        end
    end
    return Flag
end

function CatchPmu2(LogStr)
    local ResultFlag=0
    local Flag=0
    local pmu2StopPos=0
    local StopLevel2=0
    local StopLevel3=0
    for i=1,#ListPmu2Item do
        for j=1,#ListPmu2ItemSchema do
            TestName=(ListDevice[3]).."_"..ListPmu2Item[i].."_"..ListPmu2ItemSchema[j]
            PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
            StartTimeStr=CurrentTimeStr()
            if pmu2StopPos==0 then
                Start,pmu2StopPos=string.find(LogStr,"(pmu2)")
            end
            Start,StopLevel2,Ans=string.find(LogStr,"([_]?"..ListPmu2Item[i]..")",pmu2StopPos+1)
            while(Ans~=ListPmu2Item[i])
            do
                Start,StopLevel2,Ans=string.find(LogStr,"([_]?"..ListPmu2Item[i]..")",StopLevel2+1)
            end
            Start,StopLevel3,Ans=string.find(LogStr,"("..ListPmu2ItemSchema[j]..")",StopLevel2)
            Start,Stop,pmu2Value=string.find(LogStr,"([-]?%d+[.]?%d+)",StopLevel3+2)
            FinishTimeStr=CurrentTimeStr()
            TotalExeTime=TimeCalculator(StartTimeStr,FinishTimeStr)
            if (pmu2Value)~=nil then
                ResultFlag=CompareWithQTResult(TestName,pmu2Value,"NumCompare",TotalExeTime)
            else
                ResultFlag=CompareWithQTResult(TestName,"Process Fail","Process Fail",TotalExeTime)
            end
            Flag=TestItemResultCompareCheck(ResultFlag,Flag)
            PrintString("=======================================================================================================")
        end
    end
    return Flag
end

function ReadAllNTCValue()
    local Flag=0
    local ResultFlag=0
    local PmuAdcReadValue
    TestName="Read_all_NTC_values"
    PrintString("====================================== Test Item :"..TestName.."======================================")
    StartTimeStr=CurrentTimeStr()
    pcall(Shell,"temperature --all")
    LastOutputLog=Last.Output
    FinishTimeStr=CurrentTimeStr()
    TotalExeTime=TimeCalculator(StartTimeStr,FinishTimeStr)
    if (LastOutputLog)~=nil then
        ResultFlag=CompareWithQTResult(TestName,"PASS","StrCompare",TotalExeTime)
    else
        ResultFlag=CompareWithQTResult(TestName,"Process Fail","Process Fail",TotalExeTime)
    end
    Flag=TestItemResultCompareCheck(ResultFlag,Flag)

    PrintString("=======================================================================================================")
    ResultFlag=CatchSoc(LastOutputLog)
    Flag=TestItemResultCompare(ResultFlag,Flag)
    ResultFlag=CatchPmu(LastOutputLog)
    Flag=TestItemResultCompare(ResultFlag,Flag)
    ResultFlag=CatchPmu2(LastOutputLog)
    Flag=TestItemResultCompare(ResultFlag,Flag)

    return flagToBool(Flag)
end
