require "SearchforTarget"
require "CompareAndOutput"
require "TimeRelated"


function PwrDCRTests()
    local Flag = 0
    local FuncResultFlag = 0
    CsvWriteFlagCheck()
    -- Please refer to rdar://100486301
    TestNameAll = "PwrDCRTest"
    PrintString("\n\n====================================== Test Item :"..TestNameAll.." ======================================")
    StartTimeStrAll=os.time()

    StartTimeStr=os.time()
    TestName="PwrDCRTests_IPBR1"
    Shell("smc fread IPBR")
    PwrDCRTests_IPBR1=Last.Output:match("IPBR = ([%w%.]+)")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    TotalExeTime=os.time() - StartTimeStr
    if Flag==0 then
        CompareWithTC(TestName,PwrDCRTests_IPBR1,"NumCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end


    StartTimeStr=os.time()
    TestName="PwrDCRTests_VPOR1"
    Shell("smc fread VP0R")
    PwrDCRTests_VPOR1=Last.Output:match("VP0R = ([%w%.]+)")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    TotalExeTime=os.time() - StartTimeStr
    if Flag==0 then
        CompareWithTC(TestName,PwrDCRTests_VPOR1,"NumCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    
    Shell('soc -p "get-perf-state"')

    Shell('soc -s "perfstate cpu 7"')
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    Shell('soc -p "get-perf-state"')


    Shell('thermalvirus --on --dev soc --name THERMAL0 --lower_limit 60 --upper_limit 65 --set_point 62 --window_time_limit 300000 --ap_mask 0xee')
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    -- Shell('repeat 5 "thermalvirus --status;smc fread IPBR;smc fread VP0R;wait 1000";')
    -- MatchResult=Last.Output:match("(OK)")
    -- Flag=TestItemResultCompare(MatchResult,Flag)

    Shell("wait 5000")
    

    StartTimeStr=os.time()
    TestName="PwrDCRTests_IPBR2"
    Shell("smc fread IPBR")
    PwrDCRTests_IPBR2=Last.Output:match("IPBR = ([%w%.]+)")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    TotalExeTime=os.time() - StartTimeStr
    if Flag==0 then
        CompareWithTC(TestName,PwrDCRTests_IPBR2,"NumCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end

    StartTimeStr=os.time()
    TestName="PwrDCRTests_VPOR2"
    Shell("smc fread VP0R")
    PwrDCRTests_VPOR2=Last.Output:match("VP0R = ([%w%.]+)")
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)
    TotalExeTime=os.time() - StartTimeStr
    if Flag==0 then
        CompareWithTC(TestName,PwrDCRTests_VPOR2,"NumCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end

    Shell('thermalvirus --off')
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    Shell('soc -s "perfstate cpu 6"')
    MatchResult=Last.Output:match("(OK)")
    Flag=TestItemResultCompare(MatchResult,Flag)

    StartTimeStr=os.time()
    TestName="PwrDCRTests_IPBR2_1"
    PwrDCRTests_IPBR2_1=PwrDCRTests_IPBR2-PwrDCRTests_IPBR1
    Flag=TestItemResultCompare(PwrDCRTests_IPBR2_1,Flag)
    TotalExeTime=os.time() - StartTimeStr
    if Flag==0 then
        CompareWithTC(TestName,PwrDCRTests_IPBR2_1,"NumCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    StartTimeStr=os.time()
    TestName="PwrDCRTests_VPOR1_2"
    PwrDCRTests_VPOR1_2=PwrDCRTests_VPOR1-PwrDCRTests_VPOR2
    Flag=TestItemResultCompare(PwrDCRTests_VPOR1_2,Flag)
    TotalExeTime=os.time() - StartTimeStr
    if Flag==0 then
        CompareWithTC(TestName,PwrDCRTests_VPOR1_2,"NumCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end

    
    TestName="PwrDCRTest_Value"
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    PwrDCRTests_DCR13V=PwrDCRTests_VPOR1_2/PwrDCRTests_IPBR2_1
    Flag=TestItemResultCompare(PwrDCRTests_DCR13V,Flag)
    TotalExeTime=os.time() - StartTimeStr
    if Flag==0 then
        CompareWithTC(TestName,PwrDCRTests_DCR13V,"NumCompare",TotalExeTime)
    else
        CompareWithTC(TestName,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")


    TotalExeTime=os.time() - StartTimeStrAll
    if Flag==0 then
        CompareWithTC(TestNameAll,"OK","StrCompare",TotalExeTime)
    else
        CompareWithTC(TestNameAll,"ProcessFail","ProcessFail",TotalExeTime)
    end
    FuncResultFlag=FuncResultCompare(FuncResultFlag,Flag)
    PrintString("==================================================================================================================")

    return flagToBool(FuncResultFlag)
end

