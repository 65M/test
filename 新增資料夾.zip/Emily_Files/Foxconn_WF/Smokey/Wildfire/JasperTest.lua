require "SearchforTarget"
require "CompareAndOutput"
require "CommonLib"

function JasperTests()
    CsvWriteFlagCheck()
    TestName="JasperTests_Command"
    local FuncResultFlag=0
    PrintString("\n\n====================================== Test Item :"..TestName.." ======================================")
    StartTimeStr=os.time()
    -- call Jasper py file
    Shell("upy nandfs:\\AppleInternal\\Diags\\Scripts\\N301\\jasperTest.py")
    ExecResult=Last.Output
    -- PrintString("====JasperTests.py Output====")
    -- -- PrintString(ExecResult)
    -- PrintString("====JasperTests.py Output====")
    cmdResult=pyFileProcessor(ExecResult)
    JasperPyCoommandExecFlag=JasperResultProcessor(cmdResult)
    if JasperPyCoommandExecFlag=="FAIL" then
      FuncResultFlag=1
    end
    
    TotalExeTime=os.time() - StartTimeStr
    CompareWithTC(TestName,JasperPyCoommandExecFlag,"StrCompare",TotalExeTime)
    PrintString("==================================================================================================================")
  
    return flagToBool(FuncResultFlag)
  end
  
