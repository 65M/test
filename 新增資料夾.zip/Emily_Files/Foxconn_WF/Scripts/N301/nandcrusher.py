import time
from pexpect import pxssh
import re
import math
import time ,os, datetime, csv
import random,sys

PORT=int(sys.argv[1])
Probe=sys.argv[2]

print("Running with port ",PORT)
print("using probe ",Probe)

hostname = "localhost"
username = "root"
password = "alpine"

for i in range(50):
    s = pxssh.pxssh()
    print("---- TEST CYCYLE"+str(i)+" ----")
    while True:
        try:
            s.login(hostname, username, password,port=PORT+22)
            print("bam!, got into non ui")
            break
        except Exception as e:
            print(e)
            print("noluck with non ui, retrying in 3s")
            pass
        time.sleep(3)
    s.sendline("pkill nand_cycler")
    s.sendline("nand_cycler 1 -s &")
    print("kicked off nand stress")
    time.sleep(5)
    s.logout()
    os.system("astrisctl relay vbus 0 --probe "+Probe) # eg. ChimpSWD-000038
    print('yanking system power')
    time.sleep(3)
    os.system("astrisctl relay vbus 1 --probe "+Probe) # eg. ChimpSWD-000038
    print('restoring system power')
