import sys

file = sys.argv[1]

readflag=False

with open(file,"r+") as f:
    dat=f.read()
    for line in dat.split("\n"):
        if readflag:
            readflag=False
            segs=line.split(",")
            try:
                if float(segs[3])<=float(segs[1]) and float(segs[1])<=float(segs[4]):
                    print("PASS "+line)
                else:
                    print("FAIL "+line)
            except ValueError:
                print("PASS "+line)
        if "Hark" in line:
            readflag=True
