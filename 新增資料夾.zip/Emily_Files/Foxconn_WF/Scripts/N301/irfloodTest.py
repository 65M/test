import sys
print(sys.path)
sys.path.append("nandfs:\\AppleInternal\Diags\Logs\Smokey\Shared\SEuP")
sys.path.append("nandfs:\\AppleInternal\Diags\Python\lib")
from seup import *
from cameraTests import startExternalStream, stopExternalStream

import argparse

IRFLOOD_VER = "2023-11-15-01"
print("irFloodTest Version: "+IRFLOOD_VER)

ODRVExpectedOTP = 0xB

ODRVSafetyParamTable = [
    {"Reg" : 0xB3, "NumofBytes" : 4, "OTPDetails" : [
                                    {"Name" : "RIGEL_OTP_regotp67_ctm3",   "StartBit" : 0,    "Len" : 8,   "Result" : 0x80},
                                    {"Name" : "RIGEL_OTP_regotp68_ctm3",   "StartBit" : 8,    "Len" : 8,   "Result" : 0x14},
                                    {"Name" : "RIGEL_OTP_regotp69_ctm3",   "StartBit" : 16,   "Len" : 8,   "Result" : 0x00},
                                    {"Name" : "RIGEL_OTP_regotp70_ctm3",   "StartBit" : 24,   "Len" : 8,   "Result" : 0x41},
                                ]},
    {"Reg" : 0xB7, "NumofBytes" : 4, "OTPDetails" : [
                                    {"Name" : "RIGEL_OTP_regotp71_ctm3",   "StartBit" : 0,   "Len" : 8,   "Result" : 0x00},
                                    {"Name" : "RIGEL_OTP_regotp72_ctm3",   "StartBit" : 8,   "Len" : 8,   "Result" : 0x50},
                                    {"Name" : "RIGEL_OTP_regotp73_ctm3",   "StartBit" : 16,  "Len" : 8,   "Result" : 0xE0},
                                    {"Name" : "RIGEL_OTP_regotp74_ctm3",   "StartBit" : 27,  "Len" : 5,   "Result" : 0x1B},
                                ]},
    {"Reg" : 0xC0, "NumofBytes" : 4, "OTPDetails" : [
                                    {"Name" : "RIGEL_OTP_regotp0_st1",   "StartBit" : 0,   "Len" : 8,   "Result" : None},
                                    {"Name" : "RIGEL_OTP_regotp1_st1",   "StartBit" : 8,   "Len" : 8,   "Result" : None},
                                    {"Name" : "RIGEL_OTP_regotp2_st1",   "StartBit" : 16,  "Len" : 8,   "Result" : None},
                                    {"Name" : "RIGEL_OTP_regotp3_st1",   "StartBit" : 24,  "Len" : 8,   "Result" : None},
                                ]},
    {"Reg" : 0xC4, "NumofBytes" : 4, "OTPDetails" : [
                                    {"Name" : "RIGEL_OTP_regotp4_st1",   "StartBit" : 0,   "Len" : 8,   "Result" : None},
                                    {"Name" : "RIGEL_OTP_regotp5_st1",   "StartBit" : 8,   "Len" : 8,   "Result" : None},
                                    {"Name" : "RIGEL_OTP_regotp6_st1",   "StartBit" : 16,  "Len" : 8,   "Result" : None},
                                    {"Name" : "RIGEL_OTP_regotp7_st1",   "StartBit" : 24,  "Len" : 8,   "Result" : None},
                                ]},
    {"Reg" : 0xC8, "NumofBytes" : 1, "OTPDetails" : [
                                    {"Name" : "RIGEL_OTP_regotp8_st1",   "StartBit" : 0,   "Len" : 8,   "Result" : None},
                                ]},
    {"Reg" : 0xCE, "NumofBytes" : 2, "OTPDetails" : [
                                    {"Name" : "RIGEL_OTP_regotp14_st1",  "StartBit" : 0,   "Len" : 8,   "Result" : 0x0A},
                                    {"Name" : "RIGEL_OTP_regotp15_st1",  "StartBit" : 8,   "Len" : 8,   "Result" : 0x00},
                                ]},
    {"Reg" : 0xD6, "NumofBytes" : 4, "OTPDetails" : [
                                    {"Name" : "RIGEL_OTP_regotp22_st2",  "StartBit" : 0,   "Len" : 1,   "Result" : 0x00},
                                    {"Name" : "RIGEL_OTP_regotp23_st2",  "StartBit" : 8,   "Len" : 8,   "Result" : 0xAD},
                                    {"Name" : "RIGEL_OTP_regotp24_st2",  "StartBit" : 16,  "Len" : 8,   "Result" : 0x80},
                                    {"Name" : "RIGEL_OTP_regotp25_st2",  "StartBit" : 24,  "Len" : 8,   "Result" : 0x48},
                                ]},
    {"Reg" : 0xDA, "NumofBytes" : 2, "OTPDetails" : [
                                    {"Name" : "RIGEL_OTP_regotp26_st2",  "StartBit" : 0,   "Len" : 8,   "Result" : 0x81},
                                    {"Name" : "RIGEL_OTP_regotp27_st2",  "StartBit" : 8,   "Len" : 8,   "Result" : 0x12},
                                ]},
    {"Reg" : 0xDF, "NumofBytes" : 1, "OTPDetails" : [
                                    {"Name" : "RIGEL_OTP_regotp31_st2",  "StartBit" : 0,   "Len" : 8,   "Result" : 0xF4},
                                ]},
    {"Reg" : 0xE0, "NumofBytes" : 4, "OTPDetails" : [
                                    {"Name" : "RIGEL_OTP_regotp32_ctm1",   "StartBit" : 0,   "Len" : 8,   "Result" : 0x55},
                                    {"Name" : "RIGEL_OTP_regotp33_ctm1",   "StartBit" : 8,   "Len" : 8,   "Result" : 0x01},
                                    {"Name" : "RIGEL_OTP_regotp34_ctm1",   "StartBit" : 16,  "Len" : 8,   "Result" : 0x04},
                                    {"Name" : "RIGEL_OTP_regotp35_ctm1",   "StartBit" : 24,  "Len" : 8,   "Result" : 0x04},
                                ]},
    {"Reg" : 0xE4, "NumofBytes" : 4, "OTPDetails" : [
                                    {"Name" : "RIGEL_OTP_regotp36_ctm1",   "StartBit" : 0,   "Len" : 8,   "Result" : 0x40},
                                    {"Name" : "RIGEL_OTP_regotp37_ctm1",   "StartBit" : 8,   "Len" : 8,   "Result" : 0x05},
                                    {"Name" : "RIGEL_OTP_regotp38_ctm1",   "StartBit" : 16,  "Len" : 8,   "Result" : 0x00},
                                    {"Name" : "RIGEL_OTP_regotp39_ctm1",   "StartBit" : 24,  "Len" : 8,   "Result" : 0xA0},
                                ]},
    {"Reg" : 0xE8, "NumofBytes" : 4, "OTPDetails" : [
                                    {"Name" : "RIGEL_OTP_regotp40_ctm1",   "StartBit" : 0,   "Len" : 8,   "Result" : 0xD3},
                                    {"Name" : "RIGEL_OTP_regotp41_ctm1",   "StartBit" : 8,   "Len" : 8,   "Result" : 0xA2},
                                    {"Name" : "RIGEL_OTP_regotp42_ctm1",   "StartBit" : 16,  "Len" : 8,   "Result" : 0x1F},
                                    {"Name" : "RIGEL_OTP_regotp43_ctm1",   "StartBit" : 24,  "Len" : 8,   "Result" : 0x38},
                                ]},
    {"Reg" : 0xEF, "NumofBytes" : 4, "OTPDetails" : [
                                    {"Name" : "RIGEL_OTP_regotp47_ctm2",   "StartBit" : 0,   "Len" : 8,   "Result" : 0x8B},
                                    {"Name" : "RIGEL_OTP_regotp48_ctm2",   "StartBit" : 8,   "Len" : 8,   "Result" : 0x81},
                                    {"Name" : "RIGEL_OTP_regotp49_ctm2",   "StartBit" : 16,  "Len" : 8,   "Result" : 0x40},
                                    {"Name" : "RIGEL_OTP_regotp50_ctm2",   "StartBit" : 24,  "Len" : 8,   "Result" : 0x24},
                                ]},
    {"Reg" : 0xF3, "NumofBytes" : 4, "OTPDetails" : [
                                    {"Name" : "RIGEL_OTP_regotp51_ctm2",   "StartBit" : 0,   "Len" : 8,   "Result" : 0xFF},
                                    {"Name" : "RIGEL_OTP_regotp52_ctm2",   "StartBit" : 8,   "Len" : 8,   "Result" : 0x7F},
                                    {"Name" : "RIGEL_OTP_regotp53_ctm2",   "StartBit" : 16,  "Len" : 8,   "Result" : 0x1B},
                                    {"Name" : "RIGEL_OTP_regotp54_ctm2",   "StartBit" : 24,  "Len" : 8,   "Result" : 0xB8},
                                ]},
    {"Reg" : 0xF7, "NumofBytes" : 4, "OTPDetails" : [
                                    {"Name" : "RIGEL_OTP_regotp55_ctm2",   "StartBit" : 0,   "Len" : 8,   "Result" : 0x22},
                                    {"Name" : "RIGEL_OTP_regotp56_ctm2",   "StartBit" : 8,   "Len" : 8,   "Result" : 0x20},
                                    {"Name" : "RIGEL_OTP_regotp57_ctm2",   "StartBit" : 16,  "Len" : 8,   "Result" : 0x10},
                                    {"Name" : "RIGEL_OTP_regotp58_ctm2",   "StartBit" : 24,  "Len" : 8,   "Result" : 0x6A},
                                ]},
    {"Reg" : 0xFF, "NumofBytes" : 1, "OTPDetails" : [
                                    {"Name" : "RIGEL_OTP_regotp63_ctm2",   "StartBit" : 0,   "Len" : 8,   "Result" : 0xF0},
                                ]},
]


def firePrewittR(duration=5):
    diags('camisp --method projector en 8')
    bora.isp.DCAMR.startStreaming()
    bora.isp.ODRV.configureStrobe(2)
    diags('repeat -q {}s "camisp --i2cwrite 0 0x55 0x46 1 1 0x05"'.format(duration))


def ceasefirePrewittR():
    diags('camisp --method projector dis 8')
    bora.isp.DCAMR.stopStreaming()


if __name__=="__main__":
    parser = argparse.ArgumentParser(description='N301 IR Flood Test')
    parser.add_argument('-s','--station', help='Specify test coverage: [QT, Burnin]', required=False)
    args = parser.parse_args()

    fullTest = True
    if args.station and args.station.lower() == 'qt':
        print("[irfloodTest] QT Coverage")
        fullTest = False

    else:
        print("[irfloodTest] Full Coverage")

    #turn bora on
    bora.boot()
    bora.msg.initMaster(0)
    bora.isp.powerOn()
    stopwatch = Stopwatch()

    diags('camisp --method projector en 8')

    initRxCnt = startExternalStream("DCAMR")
    stopwatch.tik()

    bora.isp.ODRV.IdleStatusCheck()
    bora.isp.ODRV.IsOTPWritable()
    bora.isp.ODRV.OTPValidation(ODRVSafetyParamTable, ODRVExpectedOTP)
    bora.isp.ODRV.RigelTestModeTest()
    bora.isp.ODRV.ThrottleTest()
    # if fullTest:
    #     bora.isp.ODRV.ThrottleStrobeTest()

    stopwatch.tok()
    stopExternalStream("DCAMR", initRxCnt, stopwatch.runtime()/1000)

    diags('camisp --method projector dis 8')
    diags("camisp --exit")

    irflood_failures, irflood_overall = getOverallResults()
    if not irflood_overall:
        print("IRFloodTest Failures:", irflood_failures)
    ReportDataToStationAndPDCA("IRFLOODTEST_OVERALL", irflood_overall, "bool", 1, 1)
