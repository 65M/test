from CDB40L10.cdb40l10 import *
import time ,os, datetime, csv
# initialize the cdb40L10 system
cdb = CDB40L10(system_name='CDB40L10', scs_version='1.7')  # , verbose_mode='scs_script')
l10 = cdb.l10
def write_otp_i2c_a_ind(prefetch=1, write_abort=1):
    # ensure standby mode
    l10.writeRegisterByAddress(0x0408, 0)
    stand = l10.readRegisterByAddress(0x0400)
    # ensure VDDP is in 1.78V to 1.98V
    if stand == 0x02:
        VDDP = 1.85 # 1.78 <= VDDP <= 1.98 (1.85V)
​
        addr_list = [24, 30, 154] #OTP shadow register byte
​
        data_list = [0x0040, 0x0200, 0x6C00] # the new OTP value to be overwrite
​
        time.sleep(1)
​
        if 1.78 <= VDDP <= 1.98:
​
            l10.writeRegisterByAddress(0x4808, 0x01) # OTP_CTRL_IF3 (VDD_OTP_EN = 1) to enable VDD for OTP programming
            l10.writeRegisterByAddress(0x4200, 0xA41A) # OTP_CTRL_0 to enable OTP write, WRITE ABORT, PREFETCH
​
            print('-------------------------- Writing OTP --------------------------')
            i=0
            for byte in addr_list:
                addr = 0x4000 + byte
                data = data_list[i]
                print('{}: {} overwrite = {}'.format(byte, (hex(addr)), hex(data)))
                value = l10.readRegisterByAddress(addr)
                otp_bit = value | data
                l10.writeRegisterByAddress(addr, otp_bit)
                busy = l10.readRegisterByAddress(0x420C)    # Wait until write is complete...
​
                while busy == 1:
                    time.sleep(.1)
                    busy = l10.readRegisterByAddress(0x420C)
                # check for errors writing OTP address
​
                if prefetch and write_abort:
                    if (l10.readRegisterByAddress(0x4208) & 0x8000) == 0x8000:
                        raise ValueError('OTP_WR_ERR: Error occurred at {} = {}'.format(
                            hex(l10.readField('OTP_ERROR_ADDR')), hex(data)))
                i=i+1
​
            l10.writeRegisterByAddress(0x4200, 0xA418)
            l10.writeRegisterByAddress(0x4808, 0x00)
​
        else:
            print('VDDP = {:.3f}'.format(VDDP))
            print('VDDP is outside the OTP programming range of 1.78 to 1.98 V')
    else:
        print('The DUT is not in standby')
    # customer_otp.close()
​
def read_opt_regs():
    print('-------------------------- Reading OTP --------------------------')
    for byte in range(0, 160, 2):
        addr = 0x4000 + byte
        print('{}: {} = {}'.format(byte, (hex(addr)), hex(l10.readRegisterByAddress(addr))))
    print()
​
​
path = os.getcwd()
chip_version = "Moku_A0"
current_time = datetime.datetime.now().strftime("%m_%d_%H_%M")
result_file = path + "/data/"+ chip_version + "OTP_dump" +current_time + ".csv"
​
​
cdb.clear_int()
write_otp_i2c_a_ind()
Collaps
