import sys
print(sys.path)
sys.path.append("nandfs:\\AppleInternal\Diags\Logs\Smokey\Shared\SEuP")
sys.path.append("nandfs:\\AppleInternal\Diags\Python\lib")
from seup import *
from cameraTests import startExternalStream, stopExternalStream

import argparse

PEARL_VER = "2023-11-15-01"
print("pearlTest Version: "+PEARL_VER)

PDRVExpectedOTP = 0xA

PDRVSafetyParamTable = [
    {"Reg" : 0xB3, "NumofBytes" : 4, "OTPDetails" : [
                                    {"Name" : "RIGEL_OTP_regotp67_ctm3",   "StartBit" : 0,    "Len" : 8,   "Result" : 0x80},
                                    {"Name" : "RIGEL_OTP_regotp68_ctm3",   "StartBit" : 8,    "Len" : 8,   "Result" : 0x14},
                                    {"Name" : "RIGEL_OTP_regotp69_ctm3",   "StartBit" : 16,   "Len" : 8,   "Result" : 0x00},
                                    {"Name" : "RIGEL_OTP_regotp70_ctm3",   "StartBit" : 24,   "Len" : 8,   "Result" : 0x41},
                                ]},
    {"Reg" : 0xB7, "NumofBytes" : 4, "OTPDetails" : [
                                    {"Name" : "RIGEL_OTP_regotp71_ctm3",   "StartBit" : 0,   "Len" : 8,   "Result" : 0x00},
                                    {"Name" : "RIGEL_OTP_regotp72_ctm3",   "StartBit" : 8,   "Len" : 8,   "Result" : 0x55},
                                    {"Name" : "RIGEL_OTP_regotp73_ctm3",   "StartBit" : 16,  "Len" : 8,   "Result" : 0xE0},
                                    {"Name" : "RIGEL_OTP_regotp74_ctm3",   "StartBit" : 27,  "Len" : 5,   "Result" : 0x1B},
                                ]},
    {"Reg" : 0xC0, "NumofBytes" : 4, "OTPDetails" : [
                                    {"Name" : "RIGEL_OTP_regotp0_st1",   "StartBit" : 0,   "Len" : 8,   "Result" : None},
                                    {"Name" : "RIGEL_OTP_regotp1_st1",   "StartBit" : 8,   "Len" : 8,   "Result" : None},
                                    {"Name" : "RIGEL_OTP_regotp2_st1",   "StartBit" : 16,  "Len" : 8,   "Result" : None},
                                    {"Name" : "RIGEL_OTP_regotp3_st1",   "StartBit" : 24,  "Len" : 8,   "Result" : None},
                                ]},
    {"Reg" : 0xC4, "NumofBytes" : 4, "OTPDetails" : [
                                    {"Name" : "RIGEL_OTP_regotp4_st1",   "StartBit" : 0,   "Len" : 8,   "Result" : None},
                                    {"Name" : "RIGEL_OTP_regotp5_st1",   "StartBit" : 8,   "Len" : 8,   "Result" : None},
                                    {"Name" : "RIGEL_OTP_regotp6_st1",   "StartBit" : 16,  "Len" : 8,   "Result" : None},
                                    {"Name" : "RIGEL_OTP_regotp7_st1",   "StartBit" : 24,  "Len" : 8,   "Result" : None},
                                ]},
    {"Reg" : 0xC8, "NumofBytes" : 1, "OTPDetails" : [
                                    {"Name" : "RIGEL_OTP_regotp8_st1",   "StartBit" : 0,   "Len" : 8,   "Result" : None},
                                ]},
    {"Reg" : 0xCE, "NumofBytes" : 2, "OTPDetails" : [
                                    {"Name" : "RIGEL_OTP_regotp14_st1",  "StartBit" : 0,   "Len" : 8,   "Result" : 0x0A},
                                    {"Name" : "RIGEL_OTP_regotp15_st1",  "StartBit" : 8,   "Len" : 8,   "Result" : 0x00},
                                ]},
    {"Reg" : 0xD6, "NumofBytes" : 4, "OTPDetails" : [
                                    {"Name" : "RIGEL_OTP_regotp22_st2",  "StartBit" : 0,   "Len" : 1,   "Result" : 0x00},
                                    {"Name" : "RIGEL_OTP_regotp23_st2",  "StartBit" : 8,   "Len" : 8,   "Result" : 0xAD},
                                    {"Name" : "RIGEL_OTP_regotp24_st2",  "StartBit" : 16,  "Len" : 8,   "Result" : 0x80},
                                    {"Name" : "RIGEL_OTP_regotp25_st2",  "StartBit" : 24,  "Len" : 8,   "Result" : 0x48},
                                ]},
    {"Reg" : 0xDA, "NumofBytes" : 2, "OTPDetails" : [
                                    {"Name" : "RIGEL_OTP_regotp26_st2",  "StartBit" : 0,   "Len" : 8,   "Result" : 0x81},
                                    {"Name" : "RIGEL_OTP_regotp27_st2",  "StartBit" : 8,   "Len" : 8,   "Result" : 0x12},
                                ]},
    {"Reg" : 0xDF, "NumofBytes" : 1, "OTPDetails" : [
                                    {"Name" : "RIGEL_OTP_regotp31_st2",  "StartBit" : 0,   "Len" : 8,   "Result" : 0xF4},
                                ]},
    {"Reg" : 0xE0, "NumofBytes" : 4, "OTPDetails" : [
                                    {"Name" : "RIGEL_OTP_regotp32_ctm1",   "StartBit" : 0,   "Len" : 8,   "Result" : 0x55},
                                    {"Name" : "RIGEL_OTP_regotp33_ctm1",   "StartBit" : 8,   "Len" : 8,   "Result" : 0x01},
                                    {"Name" : "RIGEL_OTP_regotp34_ctm1",   "StartBit" : 16,  "Len" : 8,   "Result" : 0x04},
                                    {"Name" : "RIGEL_OTP_regotp35_ctm1",   "StartBit" : 24,  "Len" : 8,   "Result" : 0x04},
                                ]},
    {"Reg" : 0xE4, "NumofBytes" : 4, "OTPDetails" : [
                                    {"Name" : "RIGEL_OTP_regotp36_ctm1",   "StartBit" : 0,   "Len" : 8,   "Result" : 0x45},
                                    {"Name" : "RIGEL_OTP_regotp37_ctm1",   "StartBit" : 8,   "Len" : 8,   "Result" : 0x05},
                                    {"Name" : "RIGEL_OTP_regotp38_ctm1",   "StartBit" : 16,  "Len" : 8,   "Result" : 0xB0},
                                    {"Name" : "RIGEL_OTP_regotp39_ctm1",   "StartBit" : 24,  "Len" : 8,   "Result" : 0xA9},
                                ]},
    {"Reg" : 0xE8, "NumofBytes" : 4, "OTPDetails" : [
                                    {"Name" : "RIGEL_OTP_regotp40_ctm1",   "StartBit" : 0,   "Len" : 8,   "Result" : 0xD3},
                                    {"Name" : "RIGEL_OTP_regotp41_ctm1",   "StartBit" : 8,   "Len" : 8,   "Result" : 0xA2},
                                    {"Name" : "RIGEL_OTP_regotp42_ctm1",   "StartBit" : 16,  "Len" : 8,   "Result" : 0x1F},
                                    {"Name" : "RIGEL_OTP_regotp43_ctm1",   "StartBit" : 24,  "Len" : 8,   "Result" : 0x38},
                                ]},
    {"Reg" : 0xEF, "NumofBytes" : 4, "OTPDetails" : [
                                    {"Name" : "RIGEL_OTP_regotp47_ctm2",   "StartBit" : 0,   "Len" : 8,   "Result" : 0x8A},
                                    {"Name" : "RIGEL_OTP_regotp48_ctm2",   "StartBit" : 8,   "Len" : 8,   "Result" : 0x81},
                                    {"Name" : "RIGEL_OTP_regotp49_ctm2",   "StartBit" : 16,  "Len" : 8,   "Result" : 0x65},
                                    {"Name" : "RIGEL_OTP_regotp50_ctm2",   "StartBit" : 24,  "Len" : 8,   "Result" : 0x24},
                                ]},
    {"Reg" : 0xF3, "NumofBytes" : 4, "OTPDetails" : [
                                    {"Name" : "RIGEL_OTP_regotp51_ctm2",   "StartBit" : 0,   "Len" : 8,   "Result" : 0xFF},
                                    {"Name" : "RIGEL_OTP_regotp52_ctm2",   "StartBit" : 8,   "Len" : 8,   "Result" : 0x37},
                                    {"Name" : "RIGEL_OTP_regotp53_ctm2",   "StartBit" : 16,  "Len" : 8,   "Result" : 0x9B},
                                    {"Name" : "RIGEL_OTP_regotp54_ctm2",   "StartBit" : 24,  "Len" : 8,   "Result" : 0xB8},
                                ]},
    {"Reg" : 0xF7, "NumofBytes" : 4, "OTPDetails" : [
                                    {"Name" : "RIGEL_OTP_regotp55_ctm2",   "StartBit" : 0,   "Len" : 8,   "Result" : 0x22},
                                    {"Name" : "RIGEL_OTP_regotp56_ctm2",   "StartBit" : 8,   "Len" : 8,   "Result" : 0x20},
                                    {"Name" : "RIGEL_OTP_regotp57_ctm2",   "StartBit" : 16,  "Len" : 8,   "Result" : 0x10},
                                    {"Name" : "RIGEL_OTP_regotp58_ctm2",   "StartBit" : 24,  "Len" : 8,   "Result" : 0x6A},
                                ]},
    {"Reg" : 0xFF, "NumofBytes" : 1, "OTPDetails" : [
                                    {"Name" : "RIGEL_OTP_regotp63_ctm2",   "StartBit" : 0,   "Len" : 8,   "Result" : 0xF0},
                                ]},
]



titusSafetyParamTable = [
    {"Reg" : 0x800<<3, "NumofBytes" : 4, "OTPDetails" : [
                                    {"Name" : "TITUS_CTS_OTP_VERSION",          "StartBit" : 0,    "Len" : 8,   "Result" : 0x07},
                                    {"Name" : "TITUS_CTS_OTP_PROJECT",          "StartBit" : 8,    "Len" : 4,   "Result" : 0x06},
                                    {"Name" : "TITUS_CTS_OTP_PROGRAM_VARIANT",  "StartBit" : 12,   "Len" : 4,   "Result" : 0x03},
                                    {"Name" : "TITUS_CTS_OTP_INTEGRATOR_PLANT", "StartBit" : 16,   "Len" : 8,   "Result" : 0x08},
                                    {"Name" : "TITUS_CTS_OTP_ANDALUSIA_VENDOR", "StartBit" : 24,   "Len" : 3,   "Result" : 0x02},
                                    {"Name" : "TITUS_CTS_OTP_ANDALUSIA_VERSION","StartBit" : 27,   "Len" : 3,   "Result" : 0x02},
                                    {"Name" : "TITUS_CTS_OTP_ANDALUSIA_VARIANT","StartBit" : 30,   "Len" : 2,   "Result" : 0x00},
                                ]},


    {"Reg" : 0x804<<3, "NumofBytes" : 4, "OTPDetails" : [
                                    {"Name" : "TITUS_CTS_OTP_BENVOLIO_VENDOR",      "StartBit" : 0,    "Len" : 3,   "Result" : 0x01},
                                    {"Name" : "TITUS_CTS_OTP_BENVOLIO_VERSION",     "StartBit" : 3,    "Len" : 3,   "Result" : 0x03},
                                    {"Name" : "TITUS_CTS_OTP_BENVOLIO_VARIANT",     "StartBit" : 6,    "Len" : 2,   "Result" : [0x01,0x03]},
                                    {"Name" : "TITUS_CTS_OTP_MIDAS_VENDOR",         "StartBit" : 8,    "Len" : 3,   "Result" : 0x02},
                                    {"Name" : "TITUS_CTS_OTP_MIDAS_VERSION",        "StartBit" : 11,   "Len" : 3,   "Result" : 0x02},
                                    {"Name" : "TITUS_CTS_OTP_MIDAS_VARIANT",        "StartBit" : 14,   "Len" : 2,   "Result" : 0x00},
                                    {"Name" : "TITUS_CTS_OTP_SUBSTRATE_VENDOR",     "StartBit" : 16,   "Len" : 3,   "Result" : 0x01},
                                    {"Name" : "TITUS_CTS_OTP_SUBSTRATE_VERSION",    "StartBit" : 19,   "Len" : 3,   "Result" : 0x01},
                                    {"Name" : "TITUS_CTS_OTP_SUBSTRATE_VARIANT",    "StartBit" : 22,   "Len" : 2,   "Result" : 0x01},
                                    {"Name" : "TITUS_CTS_OTP_ROCK_VENDOR",          "StartBit" : 24,   "Len" : 3,   "Result" : 0x01},
                                    {"Name" : "TITUS_CTS_OTP_ROCK_VERSION",         "StartBit" : 27,   "Len" : 3,   "Result" : 0x02},
                                    {"Name" : "TITUS_CTS_OTP_ROCK_VARIANT",         "StartBit" : 30,   "Len" : 2,   "Result" : 0x00},
                                ]},

    {"Reg" : 0x808<<3, "NumofBytes" : 4, "OTPDetails" : [
                                    {"Name" : "TITUS_CTS_OTP_FLEX_VENDOR",          "StartBit" : 0,    "Len" : 3,   "Result" : 0x06},
                                    {"Name" : "TITUS_CTS_OTP_FLEX_VERSION",         "StartBit" : 3,    "Len" : 3,   "Result" : 0x03},
                                    {"Name" : "TITUS_CTS_OTP_FLEX_VARIANT",         "StartBit" : 6,    "Len" : 2,   "Result" : 0x00},
                                    {"Name" : "TITUS_CTS_OTP_BEETLE_VENDOR",        "StartBit" : 8,    "Len" : 3,   "Result" : 0x02},
                                    {"Name" : "TITUS_CTS_OTP_BEETLE_VERSION",       "StartBit" : 11,   "Len" : 3,   "Result" : 0x02},
                                    {"Name" : "TITUS_CTS_OTP_BEETLE_VARIANT",       "StartBit" : 14,   "Len" : 2,   "Result" : 0x00},
                                    {"Name" : "TITUS_CTS_OTP_TICK_VENDOR",          "StartBit" : 16,   "Len" : 3,   "Result" : 0x02},
                                    {"Name" : "TITUS_CTS_OTP_TICK_VERSION",         "StartBit" : 19,   "Len" : 3,   "Result" : 0x02},
                                    {"Name" : "TITUS_CTS_OTP_TICK_VARIANT",         "StartBit" : 22,   "Len" : 2,   "Result" : 0x01},
                                    {"Name" : "TITUS_CTS_OTP_PROJECTOR_BUILD",      "StartBit" : 24,   "Len" : 8,   "Result" : [0x20,0x50]},
                                ]},
]


def titusOTPValidation():
    # id = bora.isp.PPRJ.getChipID()
    for item  in titusSafetyParamTable:

        payload = bora.isp.PPRJ.i2cread(item["Reg"],datalen=item["NumofBytes"])

        bits=item["NumofBytes"]*8
        print(hex(payload))

        for otpItem in item["OTPDetails"]:

            Start = otpItem["StartBit"]
            Length = otpItem["Len"]
            Limits = otpItem["Result"]

            shift=(bits-Start-Length)
            print("Shift ",shift)
            Output = (payload & ((2**Length-1)<<shift) ) >> shift

            print(otpItem["Name"] +  hex(Output))
            if type(Limits) == type([]):
                ReportDataToStationAndPDCA(otpItem["Name"].upper(), Output, "hex", Limits[0], Limits[1])
            else:
                ReportDataToStationAndPDCA(otpItem["Name"].upper(), Output, "hex", Limits, Limits)



def titusStatus():
    val=bora.isp.PPRJ.getStatus()
    ReportDataToStationAndPDCA("Titus_Status", val, None, 0x10, 0x15)


def fireTitus():
    bora.isp.PPRJ.enableProjector()
    bora.isp.PCAM.startStreaming()


def ceasefireTitus():
    bora.isp.PPRJ.disableProjector()
    bora.isp.PCAM.stopStreaming()


def firePrewittL():
    diags('camisp --method projector en 3')
    bora.isp.DCAML.startStreaming()
    bora.isp.PDRV.configureStrobe(2)


def ceasefirePrewittL():
    diags('camisp --method projector dis 3')
    bora.isp.DCAML.stopStreaming()


# def GetRomeoCap():
#     Passed = True
#     Pearl_Capacitance = 0
#
#     Output=diags("camisp --method pearl romeo cap")
#     Pearl_Capacitance = string.match(Output, "Capacitance%:(%d+)")
#     print("Pearl_Capacitance:"+Pearl_Capacitance)
#     Passed = ReportDataToStationAndPDCA("Pearl_Capacitance", tonumber(Pearl_Capacitance), None, None, None) and Passed
#
#     return Passed


def MamaBearStateTest():
    count = 0
    Output = ""
    StateVal = 0
    ArmState = 0
    ArmState_Expected = 0
    ArmState_Limits = [0x10, 0x11, 0x14, 0x15, 0x1C]    #Expected Arm State values

    StateVal=bora.isp.PPRJ.getStatus()

    if StateVal == 0x15 or StateVal == 0x14 :
        print("MamaBear is Armed!!")
        ArmState = 1
    elif StateVal == 0x11 or StateVal == 0x10 :
        print("MamaBear is Unarmed")
    elif StateVal == 0x1c :
        print("MamaBear is Bricked")

    for Limit in ArmState_Limits:
        if StateVal == Limit :
            ArmState_Expected = 1

    ReportDataToStationAndPDCA("MamaBear_Armed_State", ArmState, None, 1, 1)
    ReportDataToStationAndPDCA("MamaBear_Armed_State_Expected", ArmState_Expected, None, 1, 1)
    ReportDataToStationAndPDCA("MamaBear_Armed_State_Value", StateVal, None, None, None)



#<rdar://problem/38557419> EFI: Rigel2-Mamabear fault coverage
def MamaBearFaultTest():
    FaultResult = 0

    CC1, CC2 = bora.isp.PDRV.getCCStatus()
    if CC1 != 0x00 or CC2 != 0x00 :
        print("Rigel is in fault state already")

    #Turn off GPIO2, which goes to the ext LDO
    bora.isp.ADAMSCR.regRead(0x1D04)
    bora.isp.ADAMSCR.setIO(2,0)
    time.sleep(0.5)
    bora.isp.ADAMSCR.regRead(0x1D04)

    bora.isp.PDRV.i2cwrite(0x2E, 0x69)
    time.sleep(0.5)
    Rigel_Fault_Status = bora.isp.PDRV.getFaultStatus()
    # Rigel_Fault_Status = bora.isp.PDRV.i2cread(0x7E)
    CC1, CC2 = bora.isp.PDRV.getCCStatus()
    # CC1 = int(bora.isp.PDRV.i2cread(0x1C))
    # CC2 = int(bora.isp.PDRV.i2cread(0xF0))

    if (Rigel_Fault_Status >> 24 & 0x08) != 0:  # reg 0x7E -> 0x08
    # if (Rigel_Fault_Status == 0x8) or (Rigel_Fault_Status & 0x08 != 0):
        if (CC1 == 0x02 and CC2 == 0x00) or (CC1 == 0x0B and CC2 == 0x04):
        # if (CC1 == 0x0B and CC2 == 0x04):
            #MamaBear did hit expected fault!
            FaultResult = 1

    bora.isp.ADAMSCR.setIO(2,1)
    bora.isp.ADAMSCR.regRead(0x1D04)

    ReportDataToStationAndPDCA("RIGEL_MamaBearFault_TestResult", FaultResult, None, 1, 1)


def RigelXEF0FaultTest():
    FaultResult = 0

    CC1,CC2=bora.isp.PDRV.getCCStatus()

    if CC1 != 0x00 or CC2 != 0x00 :
        print("Rigel is in fault state already")

    #Turn off GPIO7
    bora.isp.PPRJ.getStatus()
    bora.isp.ADAMSCR.regRead(0x1D10)
    bora.isp.ADAMSCR.setIO(6,0)
    time.sleep(0.1)
    bora.isp.ADAMSCR.regRead(0x1D10)
    bora.isp.PPRJ.getStatus()

    Rigel_Fault_Status = bora.isp.PDRV.getFaultStatus()
    if (Rigel_Fault_Status >> 24 & 0x40) != 0:
        #Did hit expected XEF0 fault!
        FaultResult = 1
    bora.isp.ADAMSCR.setIO(6,1)
    bora.isp.ADAMSCR.regRead(0x1D10)

    ReportDataToStationAndPDCA("RIGEL_XEF0Fault_Test", FaultResult, None, 1, 1)


# Check strobe connectivity from PCAM by pulse counter
def PearlStrobeTest():
    PulseCounterResult = 0

    # PCAM strobe -> PDRV (Rigel IOUT1 = BB_B = PPRJ)
    start_pcnt = bora.isp.PDRV.i2cread(0x13)

    if not bora.isp.PCAM.streaming:
        bora.isp.PCAM.startStreaming()
    bora.isp.PDRV.configureStrobe(1)
    time.sleep(0.5)

    stop_pcnt = bora.isp.PDRV.i2cread(0x13)
    state = bora.isp.PDRV.getState()
    if stop_pcnt > 0 or (state & 0b00000011) > 0x0:
        PulseCounterResult = 1

    ReportDataToStationAndPDCA("RIGEL_PearlStrobe_Test", PulseCounterResult, None, 1, 1)



if __name__=="__main__":
    parser = argparse.ArgumentParser(description='N301 Pearl Test')
    parser.add_argument('-s','--station', help='Specify test coverage: [QT, Burnin]', required=False)
    args = parser.parse_args()

    fullTest = True
    if args.station and args.station.lower() == 'qt':
        print("[pearlTest] QT Coverage")
        fullTest = False

    else:
        print("[pearlTest] Full Coverage")

    #turn bora on
    bora.boot()
    bora.msg.initMaster(0)
    bora.isp.powerOn()
    stopwatch = Stopwatch()

    diags('camisp --method projector en 3')
    diags('camisp --method projector en 4')

    titusStatus()
    titusOTPValidation()
    MamaBearStateTest()

    initRxCnt = startExternalStream("DCAML")
    stopwatch.tik()

    bora.isp.PDRV.IdleStatusCheck()
    bora.isp.PDRV.IsOTPWritable()
    bora.isp.PDRV.OTPValidation(PDRVSafetyParamTable, PDRVExpectedOTP)
    bora.isp.PDRV.RigelTestModeTest()
    MamaBearStateTest()
    if fullTest:
        RigelXEF0FaultTest()
        bora.isp.PDRV.ThrottleTest()
        MamaBearFaultTest()
    else:
        bora.isp.PDRV.ThrottleTest()

    stopwatch.tok()
    stopExternalStream("DCAML", initRxCnt, stopwatch.runtime()/1000)

    initRxCnt = startExternalStream("PCAM")
    stopwatch.tik()
    if fullTest:
        PearlStrobeTest()
    else:
        time.sleep(0.5)
    stopwatch.tok()
    stopExternalStream("PCAM", initRxCnt, stopwatch.runtime()/1000)

    diags('camisp --method projector dis 4')
    diags('camisp --method projector dis 3')
    diags("camisp --exit")

    pearl_failures, pearl_overall = getOverallResults()
    if not pearl_overall:
        print("PearlTest Failures:", pearl_failures)
    ReportDataToStationAndPDCA("PEARLTEST_OVERALL", pearl_overall, "bool", 1, 1)
