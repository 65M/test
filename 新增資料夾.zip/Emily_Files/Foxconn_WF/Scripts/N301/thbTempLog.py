
import time

import sys
sys.path.append("nandfs:\\AppleInternal\Diags\Logs\Smokey\Shared\SEuP")
sys.path.append("nandfs:\\AppleInternal\Diags\Python\lib")

from seup import *


def getTongaTemp():
    rct=run('temperature --all',True)

    match=re.search("THERMAL0\n\s*Instant: ([0-9|\.]*) deg C",rct).group(1)
    return float(match)
def getAdamsTemp(loc):
    rct=run('pmuadc --sel '+loc+' --read tjint',True)
    match=re.search("tjint: ([0-9|.]*)",rct).group(1)
    return float(match)


if __name__=="__main__":

    #turn bora on

    bora=Bora()
    bora.boot()
    bora.isp.powerOn()
    time.sleep(5)
    now=time.time()
    print("Spam ctrl+c to prevent logger execusion, delaying for 10 seconds!")

    # for i in range(0,15):
    #     print(15-i,"seconds left")
    #     time.sleep(i)

    print("Starting logger!")
    # for i in range(0,1):
    while(1):
        tongaTemp=getTongaTemp()
        ADAMSOLTemp=getAdamsTemp("cpmu")
        ADAMSCLTemp=getAdamsTemp("cpmu2")
        ADAMSORTemp=getAdamsTemp("cpmu3")
        ADAMSCRTemp=getAdamsTemp("cpmu4")
        # print('dbg4')
        with open("nandfs:/var/thb"+str(now)+".log","a") as f:
            # print('dbg3')
            tempStr=str(time.time())+","+str(tongaTemp)+","+str(ADAMSOLTemp)+","+str(ADAMSCLTemp)+","+str(ADAMSORTemp)+","+str(ADAMSCRTemp)+"\n"
            print(tempStr)
            # print('dbg2')
            f.write(tempStr)
            # print('dbg1')
            run("event -s media-sync",False)
            # print('dbg0')
