import sys
print(sys.path)
sys.path.append("nandfs:\\AppleInternal\Diags\Logs\Smokey\Shared\SEuP")
sys.path.append("nandfs:\\AppleInternal\Diags\Python\lib")
from seup import *
from cameraTests import compensateOverflow

import argparse

JASPER_VER = "2023-11-15-01"
print("jasperTest Version: "+JASPER_VER)

# Limits listed are for historical reference, not enforced in pass/fail
# rdar://106732733 ([Jasper-N LGIT] PVT Design documents])
JasperNVMIntegrityTable = [
    {"Reg" : 0x0000, "NumofBytes" : 4, "NVMDetails" : [
        {"Name" : "JASPER_EEPROM_NVM_FORMAT_REV",   "StartBit" : 0,    "Len" : 8,   "Result" : 0xE7},
        {"Name" : "JASPER_EEPROM_CAMERA_PROJECT",   "StartBit" : 8,    "Len" : 8,   "Result" : 0x2B},
        {"Name" : "JASPER_EEPROM_PROJECT_VERSION",  "StartBit" : 16,   "Len" : 8,   "Result" : 0x17},
        {"Name" : "JASPER_EEPROM_INTEGRATOR_PLANT", "StartBit" : 24,   "Len" : 8,   "Result" : 0x09},
    ]},
    {"Reg" : 0x0004, "NumofBytes" : 4, "NVMDetails" : [
        {"Name" : "JASPER_EEPROM_CAMERA_BUILD",     "StartBit" : 0,    "Len" : 8,   "Result" : [0x10,0x72]},
        {"Name" : "JASPER_EEPROM_CONFIG_NUMBER",    "StartBit" : 8,    "Len" : 8,   "Result" : [0x00,0x99]},
        {"Name" : "JASPER_EEPROM_SUBSTRATE",        "StartBit" : 16,   "Len" : 8,   "Result" : [0x17,0x3E]},
        {"Name" : "JASPER_EEPROM_DRIVER",           "StartBit" : 24,   "Len" : 8,   "Result" : [0xCA,0xD8]},
    ]},
    {"Reg" : 0x0008, "NumofBytes" : 4, "NVMDetails" : [
        {"Name" : "JASPER_EEPROM_KIRK",             "StartBit" : 0,    "Len" : 8,   "Result" : [0x34,0x60]},
        {"Name" : "JASPER_EEPROM_PERISCOPE",        "StartBit" : 8,    "Len" : 8,   "Result" : [0x20,0x30]},
        {"Name" : "JASPER_EEPROM_IR_FILTER",        "StartBit" : 16,   "Len" : 8,   "Result" : [0x78,0xB8]},
        {"Name" : "JASPER_EEPROM_LENS1_MCCOY",      "StartBit" : 24,   "Len" : 8,   "Result" : [0x33,0x54]},
    ]},
    {"Reg" : 0x000C, "NumofBytes" : 4, "NVMDetails" : [
        {"Name" : "JASPER_EEPROM_LENS2_SPOCK",      "StartBit" : 0,    "Len" : 8,   "Result" : [0x34,0x55]},
        {"Name" : "JASPER_EEPROM_SULU_DOE",         "StartBit" : 8,    "Len" : 8,   "Result" : [0x35,0x5B]},
        {"Name" : "JASPER_EEPROM_LENS_HOLDER",      "StartBit" : 16,   "Len" : 8,   "Result" : [0x74,0x98]},
        {"Name" : "JASPER_EEPROM_SHIELD_CAN",       "StartBit" : 24,   "Len" : 8,   "Result" : [0x0D,0x7D]},
    ]},
    {"Reg" : 0x00010, "NumofBytes" : 3, "NVMDetails" : [
        {"Name" : "JASPER_EEPROM_FLEX",             "StartBit" : 0,    "Len" : 8,   "Result" : [0x08,0x58]},
        {"Name" : "JASPER_EEPROM_STIFFENER",        "StartBit" : 8,    "Len" : 8,   "Result" : [0x0D,0x76]},
        {"Name" : "JASPER_EEPROM_DRIVER_SHIELD",    "StartBit" : 16,   "Len" : 8,   "Result" : None},
    ]},
    {"Reg" : 0x0001E, "NumofBytes" : 1, "NVMDetails" : [
        {"Name" : "JASPER_EEPROM_LINER",            "StartBit" : 0,    "Len" : 8,   "Result" : None},
    ]},
]

def jasperNVMValidation(nvmIntegrityTable):
    for item in nvmIntegrityTable:

        payload = bora.isp.XMEM.i2cread(item["Reg"],datalen=item["NumofBytes"])

        bits=item["NumofBytes"]*8
        print(hex(payload))

        for otpItem in item["NVMDetails"]:

            Start = otpItem["StartBit"]
            Length = otpItem["Len"]
            Limits = otpItem["Result"]

            shift=(bits-Start-Length)
            print("Shift ",shift)
            Output = (payload & ((2**Length-1)<<shift) ) >> shift

            print(otpItem["Name"] +  hex(Output))
            ReportDataToStationAndPDCA(otpItem["Name"] , Output, "hex", None, None)


def fireJasper():
    bora.isp.XCAM.enableProjector()
    bora.isp.XCAM.startStreaming()
def ceasefireJasper():
    bora.isp.XCAM.disableProjector()
    bora.isp.XCAM.stopStreaming()


def rikerOTPVer():
    ReportDataToStationAndPDCA("JASPER_RIKER_CONFIG_OTP_VER",bora.isp.XDRV.getOTPVer(),None,0x87,0x88)
    ReportDataToStationAndPDCA("JASPER_RIKER_TRIM_OTP_VER",bora.isp.XDRV.getTrimOTPVer(),None,None,None)

def rikerArmingCheck():
    ReportDataToStationAndPDCA("JASPER_RIKER_ARMING_CHECK",bora.isp.XDRV.getArmingStatus(),None,0x3e,0x3f)


def rikerIDCheck():
    ReportDataToStationAndPDCA("JASPER_RIKER_DEVICE_ID",bora.isp.XDRV.getDeviceID(),None,0x0E75,0x0E75)
    ReportDataToStationAndPDCA("JASPER_RIKER_DEVICE_REV",bora.isp.XDRV.getDeviceRev(),None,0x0200,0x0200)
    ReportDataToStationAndPDCA("JASPER_RIKER_TRACE_ID",bora.isp.XDRV.getTraceID(),None,1,None)


def rikerIntResponse():
    preint=bora.regRead(0x23C100348)
    ReportDataToStationAndPDCA("JASPER_PRE_INT_YANK_STATE",preint&0x01,None,1,1)
    preint=bora.regWrite(0x23C100348,0x4002)
    # regs=[0x00,0x01,0x04,0x05,0x06,0x07,0x43,0x44,0x45,0x46]
    dats=bora.isp.XDRV.interruptDump()
    print(dats)
    ReportDataToStationAndPDCA("JASPER_INT_RESPONSE_Riker_Fault_Registers@0x44",dats[7],"hex",0,0)
    ReportDataToStationAndPDCA("JASPER_INT_RESPONSE_Riker_Fault_Registers@0x45",dats[8],"hex",4,4)
    ReportDataToStationAndPDCA("JASPER_INT_RESPONSE_Riker_Fault_Registers@0x46",dats[9],"hex",1,1)

    preint=bora.regWrite(0x23C100348,0x430B)


def willIDCheck():
    ReportDataToStationAndPDCA("JASPER_WILL_CHIP_ID",bora.isp.XPMU.getChipID(),None,0x0400,0x0400)
    ReportDataToStationAndPDCA("JASPER_WILL_CHIP_REV",bora.isp.XPMU.getChipRev(),None,0xA1,0xA1)


def willFaultRegisters():
    ReportDataToStationAndPDCA("JASPER_Will_Fault_Registers@0x43",bora.isp.XPMU.i2cread(0x43),None,0,0)
    ReportDataToStationAndPDCA("JASPER_Will_Fault_Registers@0x44",bora.isp.XPMU.i2cread(0x44),None,0,0)
    ReportDataToStationAndPDCA("JASPER_Will_Fault_Registers@0x45",bora.isp.XPMU.i2cread(0x45),None,0,0)


def periscopeIDRead():
    chipID=bora.isp.XCAM.getChipID()
    ReportDataToStationAndPDCA("JASPER_PERISCOPE_ID",chipID,"hex",1,None)

def periscopeStatusCheck():
    fwStateInfo, auxErrorInfo, linkTrainingResult, errorCode = bora.isp.XCAM.checkJasperStatus()
    ReportDataToStationAndPDCA("JASPER_PERISCOPE_FW_STATE",fwStateInfo,"hex",None,None)
    ReportDataToStationAndPDCA("JASPER_PERISCOPE_AUX_ERROR",auxErrorInfo,"hex",0,0)
    ReportDataToStationAndPDCA("JASPER_PERISCOPE_LINK_TRAINING_RESULT",linkTrainingResult,"hex",0,0)
    ReportDataToStationAndPDCA("JASPER_PERISCOPE_ERROR_CODE",linkTrainingResult,"hex",0,0)

#
# def readWillVDDCurrent():
#
#
# def readPeriscopeVDDCurrent():
#
#
# def readRikerVDDCurrent():
#

#
def rikerInterruptDump(prefix=""):
    regs=[0x43,0x44,0x45,0x46]
    dats=bora.isp.XDRV.interruptDump()
    print(dats)
    for index,reg in enumerate(regs):
        ReportDataToStationAndPDCA(prefix+"JASPER_Riker_Fault_Registers@"+hex(reg),dats[index],"hex",None,None)


def willTests():
    willIDCheck()
    willFaultRegisters()

def EEPROMTests():
    ReportDataToStationAndPDCA("JASPER_BUILD_CONFIG_0",bora.isp.XMEM.i2cread(0x0004),None,None,None)
    ReportDataToStationAndPDCA("JASPER_BUILD_CONFIG_1",bora.isp.XMEM.i2cread(0x0005),None,None,None)
    ReportDataToStationAndPDCA("JASPER_EEPROM",bora.isp.XMEM.i2cread(0x0002),None,None,None)
    ReportDataToStationAndPDCA("JASPER_VENDOR",bora.isp.XMEM.i2cread(0x0008),None,None,None)

def periscopeTests(doVf=False):
    periscopeIDRead()
    if doVf:
        jasperVfTest()

def powerTests():
    readWillVDDCurrent()
    readPeriscopeVDDCurrent()
    readRikerVDDCurrent()


def jasperVfTest():
    # compliance_modes=[36,37,38,39]
    compliance_modes = [26,29,32,35]
    iterCnt=10
    delay_ms=1000
    min_Vf = {}
    max_Vf = {}
    min_Im = {}
    max_Im = {}
    for mode in compliance_modes:
        bora.isp.XCAM.setComplianceMode(mode)
        fireJasper()
        Vf_mode = {}
        Im_mode = {}
        min_Vf[mode] = 9999999
        max_Vf[mode] = 0
        min_Im[mode] = 9999999
        max_Im[mode] = 0
        time.sleep(0.5)
        for i in range(iterCnt):
            rct = diags("camisp --method gettofprojector 13")
            Vf = float(re.search("Forward Voltage:.*?([0-9|.]+)",rct,re.M).group(1))
            Im = float(re.search("Monitor Current:.*?([0-9|.]+)",rct,re.M).group(1))
            Vdd_OTP = float(re.search("Riker OTP VDD Laser:.*?([0-9|.]+)",rct,re.M).group(1))
            if Im <= 19.25E-3:
                print("Imon is less than 19.25mA ",Im)
                time.sleep(0.25)
                continue
            elif Vf <= 4.6:
                print("Vf is less than 4.6V", Vf)
                time.sleep(0.25)
                continue

            Vf_mode[i] = Vf
            Im_mode[i] = Im

        ceasefireJasper()

        if Vf_mode and Im_mode:
            min_Vf[mode] = min(Vf_mode.values())
            max_Vf[mode] = max(Vf_mode.values())
            min_Im[mode] = min(Im_mode.values())
            max_Im[mode] = max(Im_mode.values())

    for mode in compliance_modes:
        print("\ncompliance mode: ",mode)
        print("min Vf: ",min_Vf[mode])
        print("max Vf: ",max_Vf[mode])
        print("min Im: ",min_Im[mode])
        print("max Im: ",max_Im[mode])
        print("Vdd_OTP: ",Vdd_OTP)

    Imon_max = max(max_Im.values())
    Imon_min = min(min_Im.values())
    I_mon_max_delta_bank2bank = round((Imon_max - Imon_min) * 1000, 4)
    ReportDataToStationAndPDCA("JASPER_I_mon_max_delta_bank2bank", I_mon_max_delta_bank2bank, "mA", 0, 4.0)

    # print(max_Vf,min_Vf)
    Vf_max = max(max_Vf.values())
    Vf_min = min(min_Vf.values())
    Vf_max_delta_bank2bank = round(Vf_max - Vf_min, 4)
    ReportDataToStationAndPDCA("JASPER_Vf_max_delta_bank2bank", Vf_max_delta_bank2bank, "V", 0, 0.52)

    Vdd_delta = round(Vdd_OTP - Vf_min, 4)
    ReportDataToStationAndPDCA("JASPER_Vdd_laser - Vf_min", Vdd_delta, "V", 1.1, 2.0)


def rikerTests():
    if not bora.isp.XCAM.streaming:
        fireJasper()

    rikerOTPVer()
    rikerArmingCheck()
    rikerIDCheck()
    rikerInterruptDump()

    jasper_int_status = bora.regRead(0x23C100348)
    riker_faultstatus1 = bora.isp.XDRV.i2cread(0x45)
    ReportDataToStationAndPDCA("JASPER_INT_CHECK_IDLE",jasper_int_status&0x01,"hex",1,1)
    ReportDataToStationAndPDCA("JASPER_RIKER_FAULT@0x45_IDLE",riker_faultstatus1,"hex",0,0)
    bora.isp.XPMU.i2cread(0x28)

    # Disable VPOS (VDDLAS) output, Riker will externally pull INT_L down
    bora.isp.XPMU.i2cwrite(0x28, 0x7F)
    time.sleep(0.25)
    bora.isp.XPMU.i2cread(0x28)
    jasper_int_status = bora.regRead(0x23C100348)
    riker_faultstatus1 = bora.isp.XDRV.i2cread(0x45)
    bora.isp.XPMU.i2cwrite(0x28, 0xFF)
    ReportDataToStationAndPDCA("JASPER_INT_CHECK_FAULT",jasper_int_status&0x01,"hex",0,0)
    ReportDataToStationAndPDCA("JASPER_RIKER_FAULT@0x45_UVLO_VDDLAS",riker_faultstatus1>>2&0x01,"hex",1,1)

    # bora.isp.XPMU.i2cwrite(0x28, 0xFF)
    if bora.isp.XCAM.streaming:
        ceasefireJasper()
    bora.regRead(0x23C100348)


if __name__=="__main__":
    parser = argparse.ArgumentParser(description='N301 Jasper Test')
    parser.add_argument('-s','--station', help='Specify test coverage: [QT, Burnin]', required=False)
    args = parser.parse_args()

    fullTest = True
    if args.station and args.station.lower() == 'qt':
        print("[jasperTest] QT Coverage")
        fullTest = False
    else:
        print("[jasperTest] Full Coverage")

    #turn bora on
    bora.boot()
    bora.msg.initMaster(0)
    # bora.msg.configChannel(bora.msg.MAP["XCAM"],0)
    bora.isp.powerOn()

    jasperSN = bora.isp.XCAM.getSN()
    jasperNVMValidation(JasperNVMIntegrityTable)

    # initTBCCNT = bora.isp.XCAM.getTBCCNT()
    initTMSTAMP = bora.isp.XCAM.getTMSTAMP()
    bora.msg.configChannel(bora.msg.MAP["XCAM"],0)
    bora.isp.XCAM.externalSyncMode(True)
    fireJasper()
    time.sleep(2)

    # rikerTests()
    willTests()
    # EEPROMTests()
    # periscopeTests(doVf=doVf)
    periscopeIDRead()
    periscopeStatusCheck()

    # t1TBCCNT = bora.isp.XCAM.getTBCCNT()
    t1TMSTAMP = bora.isp.XCAM.getTMSTAMP()
    ceasefireJasper()
    bora.isp.XCAM.externalSyncMode(False)
    rikerTests()

    # delta = compensateOverflow(initTBCCNT, t1TBCCNT)
    # print(delta,"Frames received during sync external mode")
    ReportDataToStationAndPDCA("JASPER_STREAM_EXT_SYNC",t1TMSTAMP,None,1,None)

    if fullTest:
        jasperVfTest()

    jasper_failures, jasper_overall = getOverallResults()
    if not jasper_overall:
        print("JasperTest Failures:", jasper_failures)
    ReportDataToStationAndPDCA("JASPERTEST_OVERALL", jasper_overall, "bool", 1, 1)
