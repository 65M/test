import sys

from shell import run

run("usbfs -m")
run("cp usbfs:\\SEuP.py nandfs:\\AppleInternal\\Diags\\Python\\lib")


# sys.path.append("usbfs:\\")
