## Runren Zhang <runren_zhang@apple.com>
import re
import math
from factorylogcollector import pdcaplist
from pdca.record import ParametricPDCARecord
from pdca.run import PDCARun
from datetime import datetime
from datetime import timezone
from shell import run

resultStr = []

def Dec2Hex(Num):
    isNegative = Num < 0
    Num = Num * (2**16)
    Num = math.fabs(Num)
    Num = math.floor(Num + 0.5)
    if isNegative:
        Num = (2**32) - Num
    hexStr = hex(Num)
    print(hexStr)
    hexStrRev = hexStr[:2] + '0' * (10 - len(hexStr)) + hexStr[2:].upper()
    print(hexStrRev)
    return hexStrRev

def ReportDataToStationAndPDCA(Name, Value, Units, LowerLimit="N/A", UpperLimit="N/A"):
    print("Hark, Station! Behold the data I present you!")
    print(Name + "," + str(Value) + "," + str(Units) + "," +str(LowerLimit) + "," + str(UpperLimit))
    PFstr = "N/A"
    if LowerLimit != "N/A" and UpperLimit != "N/A":
        if LowerLimit <= Value <= UpperLimit:
            PFstr="PASS"
        else:
            PFstr="FAIL"

    resultStr.append(Name+","+PFstr+","+str(Value)+","+str(LowerLimit)+","+str(UpperLimit)+"\n")
    return PFstr
    #reimplement this however you want


lr = {1:"L", 2:"R"}
spec = dict( 
 Vbus_AllLoadOn_CompassL_PostCal = (0, 2),
 Vbus_AllLoadOn_CompassR_PostCal = (0, 2),
 AllLoadOn_iSense_Delta_Current = (0.1, 2),
 AllLoadOn_iSense_Delta_Current_Post = (0.1, 2))

def SampleCurrent(test, state):
    ## Key Read "aDCR":
    ## 00000000: D1 0B 00 00 00 00 00 00 
    currentSum = 0
    for _ in range(20):
        output = run("smc read aDCR 0x66 0x33 0x50 0x61")
        currentRaw = re.search(r"00000000: ([\dA-F]*) ([\dA-F]*) ([\dA-F]*) ([\dA-F]*) ([\dA-F]*) ([\dA-F]*) ([\dA-F]*) ([\dA-F]*) ", output)
        current = int(currentRaw.group(8)+currentRaw.group(7)+currentRaw.group(6)+currentRaw.group(5)+currentRaw.group(4)+currentRaw.group(3)+currentRaw.group(2)+currentRaw.group(1), 16) / 65535 / 100 / 0.005
        currentSum += current
        print(current)
    currentAvg = currentSum/20
    ReportDataToStationAndPDCA("All"+state+"_Accum_ISense"+test, currentAvg, "A")
    return currentAvg

def SampleCompass(compassNumber, test, state):
    ## average: X = 5.982959, Y = -24.965907, Z = 12.592054, T = 25.585713
    ## std-dev: X = 0.067316, Y = 0.112416, Z = 0.101301, T = 0.067974

    output = run("sensor -s compass" + str(compassNumber) +  " --set mode lnm rate 100 --sample 100 --stream --stats")
    average = re.search(r"average: X = (-?\d*\.\d+|\d+), Y = (-?\d*\.\d+|\d+), Z = (-?\d*\.\d+|\d+), T = (-?\d*\.\d+|\d+)", output)
    averageX, averageY, averageZ = average.group(1), average.group(2), average.group(3)
    std = re.search(r"std-dev: X = (-?\d*\.\d+|\d+), Y = (-?\d*\.\d+|\d+), Z = (-?\d*\.\d+|\d+), T = (-?\d*\.\d+|\d+)", output)
    stdX, stdY, stdZ = std.group(1), std.group(2), std.group(3)
#    print(averageX, averageY, averageZ, stdX, stdY, stdZ)

    for num, xyz in zip(range(1,4), ('_X','_Y','_Z')):
        ReportDataToStationAndPDCA("All"+state+"_AVG_Compass"+lr[compassNumber]+xyz+test, float(average.group(num)), "uT")
        ReportDataToStationAndPDCA("All"+state+"_STD_Compass"+lr[compassNumber]+xyz+test, float(std.group(num)), "uT")
    return [float(averageX), float(averageY), float(averageZ)]

def Main(Input=[]):
    ## PDCA file prep
    pdcaRun = PDCARun()
    pdcaRun.start_time = datetime.now(timezone.utc)
    
    print(spec)

#    run("sensor -s compass1 --turnoff")
    run("sensor -s compass1 --init; sensor -s compass2 --init")
    sampleCompass = [dict(), dict()]
    sampleCurrent = dict()
    deltaCompass = [dict(), dict()]
    deltaCurrent = dict()
    slope = [None, None]
    slopeCorrected = [None, None]
    postCal = [dict(), dict()]
    blackStr = "reg write 0x40060000 0x00 0x00 0x00 0x00; reg write 0x40060004 0x00 0x00 0x00 0x00; "
    whiteStr = "reg write 0x40060000 0xFF 0xFF 0xFF 0xFF; reg write 0x40060004 0xFF 0xFF 0xFF 0xFF; "
    enableStr = "reg write 0x50000060 0x00 0x00 0x06 0x40; reg write 0x50000064 0x40 0x00 0x06 0x40; reg write 0x50000068 0x8C 0x01 0x02 0x00; reg write 0x5000006c 0x01; reg read 0x40060040 1"
    for test in ("", "_Post"):  # empty "" means the first round (cal)
        for state in ("LoadOff", "LoadOn"):
            if state == "LoadOff":
                if test == "_Post":
                    run("reg list; reg select speedy; " + blackStr + enableStr)
                    run("reg list; reg select speedy2; " + blackStr + enableStr)
                run("pwm -p 2 -f 30000 -d 0 --state on; wait 4000; pwm --port 1 --state on --sample; wait 4000; fan getRpm --selAp --fanID 1; fan getRpm --selAp --fanID 1; smc write F0Md 02; smc fwrite F0Dc 0.0; wait 15000; smc fread F0Ac; fan getRpm --selAp --fanID 1")
            else:
                if test == "":
                    run("display --pick internal; display --on; wait 1000; csoc --on --load; wait 4000; csi pick CSOC-DCP2; csi on; wait 1000; csi pick CSOC-DCP; csi on; wait 1000")
                run("reg list; reg select speedy; " + whiteStr + enableStr)
                run("reg list; reg select speedy2; " + whiteStr + enableStr)
                run("pwm -p 2 -f 30000 -d 99 --state on; wait 4000; pwm --port 1 --state on --sample; wait 4000; fan getRpm --selAp --fanID 1; fan getRpm --selAp --fanID 1; smc write F0Md 02; smc fwrite F0Dc 0.99; wait 15000; smc fread F0Ac; fan getRpm --selAp --fanID 1")

    ## Turn OFF main display, read iSense 
    #    run("display --off")
            
            # Sample current
            sampleCurrent[state+test] = SampleCurrent(test, state)

    ## Collect 100 samples of both magnetometers output data with statistics reported. Extract average values for X, Y, and Z-axis and write keys “DisplayOFF_AVG_Compass_X/Y/Z”. Extract standard deviation values for X, Y, and Z-axis and write keys “DisplayOFF_STD_Compass_X/Y/Z”. 
            for compassNumber in (1,2):
               sampleCompass[compassNumber-1][state+test] = SampleCompass(compassNumber, test, state)

        ## Calculate the Delta
        for compassNumber in (1,2):
            deltaCompass[compassNumber-1]["XYZ"+test] = [x1 - x2 for (x1, x2) in zip(sampleCompass[compassNumber-1]["LoadOn"+test] , sampleCompass[compassNumber-1]["LoadOff"+test])]
            for num, xyz in zip(range(3), ('_X','_Y','_Z')):
                name = "Vbus_AllLoadOn_Delta_Compass"+lr[compassNumber]+xyz+test
                ReportDataToStationAndPDCA(name, deltaCompass[compassNumber-1]["XYZ"+test][num], "uT")
                
            deltaCompass[compassNumber-1]["ABS"+test] = math.sqrt(sum( x*x for x in deltaCompass[compassNumber-1]["XYZ"+test]))
            name = "Vbus_AllLoadOn_Delta_Compass"+lr[compassNumber]+test
            ReportDataToStationAndPDCA(name, deltaCompass[compassNumber-1]["ABS"+test], "uT")

        deltaCurrent[test] = sampleCurrent["LoadOn"+test] - sampleCurrent["LoadOff"+test]
        name = "AllLoadOn_iSense_Delta_Current"+test
        ReportDataToStationAndPDCA(name, deltaCurrent[test], "A", spec[name][0], spec[name][1])

        # Calculate Slope
        if test == "":
            print("Calculate Slope")
            for compassNumber in (1,2):
                slope[compassNumber-1] = [x / deltaCurrent[""] for x in deltaCompass[compassNumber-1]["XYZ"]]
                
                for num, xyz in zip(range(3), ('_X','_Y','_Z')):
                    ReportDataToStationAndPDCA("Vbus_Slope_Compass"+lr[compassNumber]+xyz, slope[compassNumber-1][num], "uT/A")

        # Calculate the post cal error
        if test == "_Post":
            passSpec = [None, None]
            for compassNumber in (1,2):
                postCal[compassNumber-1]["XYZ"] = [deltaCompassPost - deltaCurrent["_Post"] * slp for (deltaCompassPost, slp) in zip(deltaCompass[compassNumber-1]["XYZ_Post"], slope[compassNumber-1])]
                for num, xyz in zip(range(3), ('_X','_Y','_Z')):
                    ReportDataToStationAndPDCA("Vbus_AllLoadOn_Compass"+lr[compassNumber]+xyz+"_PostCal", postCal[compassNumber-1]["XYZ"][num], "uT")

                postCal[compassNumber-1]["ABS"] = math.sqrt(sum( x*x for x in postCal[compassNumber-1]["XYZ"]))
                name = "Vbus_AllLoadOn_Compass"+lr[compassNumber]+"_PostCal"
                passSpec[compassNumber-1] = ReportDataToStationAndPDCA(name, postCal[compassNumber-1]["ABS"], "uT", spec[name][0], spec[name][1])
    
    with open("usbfs:\PDCA_compass.csv","w+") as f:
        for row in resultStr:
            f.write(row)
    f.close() 
#    pdcaRun.end_time = datetime.now(timezone.utc)
#    pdcaRun.store.add_record(new_record)

    if passSpec[0] == "PASS" and passSpec[1] == "PASS":
        for compassNumber in (1,2):
            if deltaCompass[compassNumber-1]["ABS"] < 1.5:
                print("Coex too small (" + str(deltaCompass[compassNumber-1]["ABS"]) + "), calibration quality might not be good for Compass " + lr[compassNumber])
                slopeCorrected[compassNumber-1] = [0, 0, 0]
            else:
                slopeCorrected[compassNumber-1] = slope[compassNumber-1]
        syscfgStr = " ".join([Dec2Hex(elem) for compass in slopeCorrected for elem in compass]) 
        print("syscfgStr: " + syscfgStr)
        run("syscfg add CVCC " + syscfgStr)
        run("syscfg print CVCC")
    else:
        print("ERROR: Post Cal Error Exceed Spec\n")

    run("pwm -p 2 -f 30000 -d 30 --state on; wait 4000; pwm --port 1 --state on --sample; wait 4000; fan getRpm --\
selAp --fanID 1; fan getRpm --selAp --fanID 1; smc write F0Md 02; smc fwrite F0Dc 0.3; wait 8000; smc fread F0Ac; fan getRpm --selAp --fanID 1")
    print("sampleCurrent: ")
    print(sampleCurrent)
    print("sampleCompass: ")
    print(sampleCompass)
    print("deltaCurrent: ")
    print(deltaCurrent)
    print("deltaCompass: ")
    print(deltaCompass)
    print("slope: ")
    print(slope)
    print("slopeCorrected: ")
    print(slopeCorrected)
    print("postCal: ")
    print(postCal)

if __name__ == "__main__":
    Main()
#    Dec2Hex(0.5)


#new_record = ParametricPDCARecord(**{
#        'testname': self.endpoint + str(self.root_port),
#        'subtestname': "cycle{}_{}{}".format(self.current_cycle, key, units),
#        'value': value,
#        'units': units,
#        'upperlimit': upperlimit,
#        'lowerlimit': lowerlimit
#        })


