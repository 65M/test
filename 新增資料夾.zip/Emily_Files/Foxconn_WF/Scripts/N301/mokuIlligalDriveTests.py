import time
from pexpect import pxssh
import re
import math
import time ,os, datetime, csv

resultStr=[]
PORT=37000
try:
    s = pxssh.pxssh()
    hostname = "localhost"
    username = "root"
    password = "alpine"
    s.login(hostname, username, password,port=PORT+22)

    s.sendline("h13isp -n")
    s.PROMPT="\n->"
    s.prompt(timeout=5)
    # print(s.before)
    print("In h13isp")

    s.sendline("forget")
    s.prompt(timeout=2)
    print("forget done")
    # print(s.before)
    s.sendline("fwlog")
    s.prompt(timeout=2)
    print("fwlog done")
    # print(s.before)
    s.sendline("on")
    s.prompt(timeout=60)
    # print(s.before)
    if b"poweron:\r\n  result: 0x00000000" in s.before:
        print("ISP Powered ON!")
    else:
        print("Timed out! BAD!")
        sys.exit(1)


except pxssh.ExceptionPxssh as e:
    print("pxssh failed on login.")
    print(e)


def ReportDataToStationAndPDCA(Name, Value, Units, LowerLimit, UpperLimit):
    print("Hark, Station! Behold the data I present you!")
    print(Name + "," + str(Value) + "," + str(Units) + "," +str(LowerLimit) + "," + str(UpperLimit))
    if LowerLimit <= Value <= UpperLimit:
        PFstr="PASS"
    else:
        PFstr="FAIL"

    if Units=="hex":
        resultStr.append(Name+","+PFstr+","+hex(Value)+","+hex(LowerLimit)+","+hex(UpperLimit)+"\n")
    else:
        resultStr.append(Name+","+PFstr+","+str(Value)+","+str(LowerLimit)+","+str(UpperLimit)+"\n")
    #reimplement this however you want


def ISPShell(cmd,prompt="-> ",timeout=60):
    #implement shell controller here
    print("-> "+cmd)
    s.PROMPT=prompt
    s.sendline(cmd)
    s.prompt(timeout=timeout)
    s.PROMPT="-> "
    return s.before.decode("utf-8")

    #reimplement this however you want

def dummyWrite(reg,dat):
    print("DEBUG!!! I2CDEVICEWRITE "+str(2)+" "+str(2)+" "+hex(0x38)+" "+hex(reg)+" "+str(2)+" "+str(2)+" "+hex(dat))

class ISPI2CDevice:
    def __init__(self,cam=2,ch=2,address=0x38,reglen=2,datlen=2):
        self.cam=cam
        self.ch=ch
        self.addr=address
        self.reglen=reglen
        self.datlen=datlen

    def i2cread(self,reg,len=0):
        if len == 0:
            len=self.datlen
        rct=ISPShell("I2CDEVICEREAD "+str(self.cam)+" "+str(self.ch)+" "+hex(self.addr)+" "+hex(reg)+" "+str(self.reglen)+" "+str(len))
        val=self.parsei2cRead(rct,len)
        # print("=== DEBUG2 ",hex(val))
        return val

    def i2cwrite(self,reg,dat,len=0):
        if len == 0:
            len=self.datlen
        ISPShell("I2CDEVICEWRITE "+str(self.cam)+" "+str(self.ch)+" "+hex(self.addr)+" "+hex(reg)+" "+str(self.reglen)+" "+str(len)+" "+hex(dat))
    def parsei2cRead(self,matchstr,datlen):
        ma=re.search("data: (0x[0-9|A-F]{"+str(datlen*2)+"})",matchstr,re.M)
        try:
            val=ma.group(1)
            # print("=== DEBUG "+ ma.group(1),hex(int(val,16)))
            # print("=== +++ DEBUG"+ matchstr)
        except Exception:
            print("PARSER NO MATCH, RETURINING 0")
            print(matchstr)
            return 0
        #implement fancy parser here
        return int(val,16)


class Moku(ISPI2CDevice):
    DEVICE_ID=0x0000

    def __init__(self,cam):
        ISPI2CDevice.__init__(self,cam=cam,ch=2,address=0x38,reglen=2,datlen=2)
        if cam==2:
            self.LR="L"
        elif cam==5:
            self.LR="R"
        else:
            print("FATAL, MOKU ID NOT RECOGNIZED")
            sys.exit(1)
        #h13ISP syntax

        #I2CDEVICEWRITE 2 2 0x38 0x0680 2 2 0x0000
    def I2CCheck(self):
        did1=self.i2cread(0x0000)
        did2=self.i2cread(0x0001)
        did=(did1<<8)+did2
        if did == self.DEVICE_ID:
            print("Moku Device ID "+hex(did))
            ReportDataToStationAndPDCA("Moku_I2C_DID",did,"hex",self.DEVICE_ID,self.DEVICE_ID)
            return True
        else:
            return False
            ReportDataToStationAndPDCA("Moku_I2C_DID",did,"hex",self.DEVICE_ID,self.DEVICE_ID)


    def vendorIDDump(self):
        RegMap={
        "MOKU_TRACKINGID_0_0":0x24,
        "MOKU_TRACKINGID_0_1":0x26,
        "MOKU_TRACKINGID_1_0":0x28,
        "MOKU_TRACKINGID_1_1":0x2a,
        "MOKU_TRACKINGID_2_0":0x2c,
        "MOKU_TRACKINGID_2_1":0x2e,
        "MOKU_TRACKINGID_3_0":0x30,
        "MOKU_TRACKINGID_3_1":0x32,
        "MOKU_TRACKINGID_4":0x34}

        IDAGG=0
        for key in RegMap:
            val=RegMap[key]
            dat=self.i2cread(val)
            IDAGG+=(IDAGG<<16)+dat

        ReportDataToStationAndPDCA("MOKU_TRACKING_ID",IDAGG,"hex",0,0xffffffffffffffffffffffffffffffffffff)


    def OTPDump(self,prefix=""):
        OTPMap={
        # Moku OTP should not contain registers 0x08 to 0x34 - Beign OTP logging at register 0x100
        "MOKU_OTP_CCM.OSC_BIST_THRES_0":0x100,
        "MOKU_OTP_CCM.OSC_TRIM_CTRL_0":0x108,
        "MOKU_OTP_MSM.MSM_CTRL_1":0x40A,
        "MOKU_OTP_MSM.MSM_VIOLATION_MASK_0":0x40C,
        "MOKU_OTP_MSM.MSM_VIOLATION_MASK_1":0x40E,
        "MOKU_OTP_MSM.MSM_OVV_VIOLATION_MASK_0":0x410,
        "MOKU_OTP_MSM.MSM_OVV_VIOLATION_MASK_1":0x412,
        "MOKU_OTP_MSM.MSM_FLT_MASK_1_0": 0x0414,
        "MOKU_OTP_MSM.MSM_FLT_MASK_1_1": 0x0416,
        "MOKU_OTP_MSM.MSM_FLT_MASK_2_0": 0x0418,
        "MOKU_OTP_MSM.MSM_FLT_MASK_2_1": 0x041A,
        # Added MSM_FLT_Masks
        "MOKU_OTP_MSM.COMPL_CFG4":0x41C,
        "MOKU_OTP_MSM.MSM_ANA_CTRL_0":0x420,
        "MOKU_OTP_MSM.MSM_ANA_CTRL_1":0x422,
        "MOKU_OTP_MSM.ISRC_MM_CTRL":0x43C,
        # Added ISRC_MM_CTRL
        "MOKU_OTP_SWCTRL.COMPL1_CFG1":0x600,
        "MOKU_OTP_SWCTRL.COMPL1_CFG2_0":0x604,
        "MOKU_OTP_SWCTRL.COMPL1_CFG2_1":0x606,
        "MOKU_OTP_SWCTRL.COMPL2_CFG1":0x608,
        "MOKU_OTP_SWCTRL.COMPL2_CFG2_0":0x60C,
        "MOKU_OTP_SWCTRL.COMPL2_CFG2_1":0x60E,
        "MOKU_OTP_SWCTRL.COMPL3_CFG1":0x610,
        "MOKU_OTP_SWCTRL.COMPL3_CFG2_0":0x614,
        "MOKU_OTP_SWCTRL.COMPL3_CFG2_1":0x616,
        "MOKU_OTP_SWCTRL.COMPL4_CFG1":0x618,
        "MOKU_OTP_SWCTRL.COMPL4_CFG2_0":0x61C,
        "MOKU_OTP_SWCTRL.COMPL4_CFG2_1":0x61E,
        "MOKU_OTP_SWCTRL.COMPL5_CFG1":0x620,
        "MOKU_OTP_SWCTRL.COMPL5_CFG2_0":0x624,
        "MOKU_OTP_SWCTRL.COMPL5_CFG2_1":0x626,
        "MOKU_OTP_SWCTRL.COMPL6_CFG1":0x628,
        "MOKU_OTP_SWCTRL.COMPL6_CFG2_0":0x62C,
        "MOKU_OTP_SWCTRL.COMPL6_CFG2_1":0x62E,
        "MOKU_OTP_SWCTRL.COMPL7_CFG1":0x630,
        "MOKU_OTP_SWCTRL.COMPL7_CFG2_0":0x634,
        "MOKU_OTP_SWCTRL.COMPL7_CFG2_1":0x636,
        "MOKU_OTP_SWCTRL.COMPL8_CFG1":0x638,
        "MOKU_OTP_SWCTRL.COMPL8_CFG2_0":0x63C,
        "MOKU_OTP_SWCTRL.COMPL8_CFG2_1":0x63E,
        "MOKU_OTP_SWCTRL.COMPL1_PULSE_CFG_0":0x640,
        "MOKU_OTP_SWCTRL.COMPL1_PULSE_CFG_1":0x642,
        "MOKU_OTP_SWCTRL.COMPL2_PULSE_CFG_0":0x644,
        "MOKU_OTP_SWCTRL.COMPL2_PULSE_CFG_1":0x646,
        "MOKU_OTP_SWCTRL.COMPL3_PULSE_CFG_0":0x648,
        "MOKU_OTP_SWCTRL.COMPL3_PULSE_CFG_1":0x64A,
        "MOKU_OTP_SWCTRL.COMPL4_PULSE_CFG_0":0x64C,
        "MOKU_OTP_SWCTRL.COMPL4_PULSE_CFG_1":0x64E,
        "MOKU_OTP_SWCTRL.COMPL5_PULSE_CFG_0":0x650,
        "MOKU_OTP_SWCTRL.COMPL5_PULSE_CFG_1":0x652,
        "MOKU_OTP_SWCTRL.COMPL6_PULSE_CFG_0":0x654,
        "MOKU_OTP_SWCTRL.COMPL6_PULSE_CFG_1":0x656,
        "MOKU_OTP_SWCTRL.COMPL7_PULSE_CFG_0":0x658,
        "MOKU_OTP_SWCTRL.COMPL7_PULSE_CFG_1":0x65A,
        "MOKU_OTP_SWCTRL.COMPL8_PULSE_CFG_0":0x65C,
        "MOKU_OTP_SWCTRL.COMPL8_PULSE_CFG_1":0x65E,
        "MOKU_OTP_SWCTRL.COMPL_CFG5":0x660,
        "MOKU_OTP_SWCTRL.SELECT_CFG_0":0x664,
        "MOKU_OTP_SWCTRL.SELECT_CFG_1":0x666,
        "MOKU_OTP_SWCTRL.SLEW_CFG":0x668,
        "MOKU_OTP_SWCTRL.ERROR_CFG":0x66C,
        "MOKU_OTP_SWCTRL.ERROR_CFG_1":0x66E,
        "MOKU_OTP_SWCTRL.BIST_CFG_0":0x670,
        "MOKU_OTP_SWCTRL.BIST_CFG_1":0x672,
        "MOKU_OTP_SWCTRL.TOLERANCE_CFG1_0":0x700,
        # added TOLERANCE_CFG1_0
        "MOKU_OTP_SWCTRL.TOLERANCE_CFG1_1":0x702,
        # added TOLERANCE_CFG1_1
        "MOKU_OTP_SARADC_MON.DIAG_ADC_MON_CFG_3_0":0x808,
        "MOKU_OTP_SARADC_MON.DIAG_ADC_MON_CFG_5_0":0x88C,
        "MOKU_OTP_SARADC_MON.DIAG_ADC_MON_CFG_5_1":0x88E,
        "MOKU_OTP_SARADC_SENSE.ADC_SENS_CFG_4_1":0xC0E,
        "MOKU_OTP_EXT_TEMP.LOW_TEMP_THRES":0x1208,
        "MOKU_OTP_EXT_TEMP.HIGH_TEMP_THRES":0x120C,
        "MOKU_OTP_EXT_TEMP.EXTTMP_CTRL":0x1210,
        "MOKU_OTP_EXT_TEMP.TEMP_FILT_SAMPLES":0x1214,
        "MOKU_OTP_PAD_INTERFACE.PAD_CTRL_0":0x6004,
        # added PAD_CTRL_0
        "MOKU_OTP_ANALOG_CTRL.OVV_THRESHOLD_CTRL":0x6254,
        "MOKU_OTP_CTRL_IF.CTRL_IF0":0x4800,
        "MOKU_OTP_CTRL_IF.CTRL_IF1":0x4804
        }
        OTP3Val={
        "MOKU_OTP_CCM.OSC_BIST_THRES_0": 0x01FD,
        "MOKU_OTP_CCM.OSC_TRIM_CTRL_0": 0x00,
        "MOKU_OTP_MSM.MSM_CTRL_1": 0x01FF,
        "MOKU_OTP_MSM.MSM_VIOLATION_MASK_0": 0x4000,
        "MOKU_OTP_MSM.MSM_VIOLATION_MASK_1": 0x0002,
        "MOKU_OTP_MSM.MSM_OVV_VIOLATION_MASK_0": 0x0000,
        "MOKU_OTP_MSM.MSM_OVV_VIOLATION_MASK_1": 0x0000,
        "MOKU_OTP_MSM.MSM_FLT_MASK_1_0": 0x0002,
        "MOKU_OTP_MSM.MSM_FLT_MASK_1_1": 0x0000,
        "MOKU_OTP_MSM.MSM_FLT_MASK_2_0": 0x0000,
        "MOKU_OTP_MSM.MSM_FLT_MASK_2_1": 0x0000,
        "MOKU_OTP_MSM.COMPL_CFG4": 0x0384,
        "MOKU_OTP_MSM.MSM_ANA_CTRL_0": 0xFFFF,
        "MOKU_OTP_MSM.MSM_ANA_CTRL_1": 0x07FF,
        "MOKU_OTP_MSM.ISRC_MM_CTRL": 0x001F,
        "MOKU_OTP_SWCTRL.COMPL1_CFG1": 0x8CCF,
        "MOKU_OTP_SWCTRL.COMPL1_CFG2_0": 0xFFFF,
        "MOKU_OTP_SWCTRL.COMPL1_CFG2_1": 0x001B,
        "MOKU_OTP_SWCTRL.COMPL2_CFG1": 0x892B,
        "MOKU_OTP_SWCTRL.COMPL2_CFG2_0": 0x030C,
        "MOKU_OTP_SWCTRL.COMPL2_CFG2_1": 0x0159,
        "MOKU_OTP_SWCTRL.COMPL3_CFG1": 0x898F,
        "MOKU_OTP_SWCTRL.COMPL3_CFG2_0": 0x023E,
        "MOKU_OTP_SWCTRL.COMPL3_CFG2_1": 0x0212,
        "MOKU_OTP_SWCTRL.COMPL4_CFG1": 0x89F3,
        "MOKU_OTP_SWCTRL.COMPL4_CFG2_0": 0x01C7,
        "MOKU_OTP_SWCTRL.COMPL4_CFG2_1": 0x027F,
        "MOKU_OTP_SWCTRL.COMPL5_CFG1": 0x8A57,
        "MOKU_OTP_SWCTRL.COMPL5_CFG2_0": 0x0178,
        "MOKU_OTP_SWCTRL.COMPL5_CFG2_1": 0x02C5,
        "MOKU_OTP_SWCTRL.COMPL6_CFG1": 0x8ABB,
        "MOKU_OTP_SWCTRL.COMPL6_CFG2_0": 0x0140,
        "MOKU_OTP_SWCTRL.COMPL6_CFG2_1": 0x02F5,
        "MOKU_OTP_SWCTRL.COMPL7_CFG1": 0x8B1F,
        "MOKU_OTP_SWCTRL.COMPL7_CFG2_0": 0x0118,
        "MOKU_OTP_SWCTRL.COMPL7_CFG2_1": 0x031D,
        "MOKU_OTP_SWCTRL.COMPL8_CFG1": 0x8B83,
        "MOKU_OTP_SWCTRL.COMPL8_CFG2_0": 0x00F8,
        "MOKU_OTP_SWCTRL.COMPL8_CFG2_1": 0x0339,
        "MOKU_OTP_SWCTRL.COMPL1_PULSE_CFG_0": 0x1919,
        "MOKU_OTP_SWCTRL.COMPL1_PULSE_CFG_1": 0x0104,
        "MOKU_OTP_SWCTRL.COMPL2_PULSE_CFG_0": 0x2424,
        "MOKU_OTP_SWCTRL.COMPL2_PULSE_CFG_1": 0x0104,
        "MOKU_OTP_SWCTRL.COMPL3_PULSE_CFG_0": 0x3131,
        "MOKU_OTP_SWCTRL.COMPL3_PULSE_CFG_1": 0x0104,
        "MOKU_OTP_SWCTRL.COMPL4_PULSE_CFG_0": 0x3D3D,
        "MOKU_OTP_SWCTRL.COMPL4_PULSE_CFG_1": 0x0104,
        "MOKU_OTP_SWCTRL.COMPL5_PULSE_CFG_0": 0x4A4A,
        "MOKU_OTP_SWCTRL.COMPL5_PULSE_CFG_1": 0x0104,
        "MOKU_OTP_SWCTRL.COMPL6_PULSE_CFG_0": 0x5656,
        "MOKU_OTP_SWCTRL.COMPL6_PULSE_CFG_1": 0x0104,
        "MOKU_OTP_SWCTRL.COMPL7_PULSE_CFG_0": 0x6363,
        "MOKU_OTP_SWCTRL.COMPL7_PULSE_CFG_1": 0x0104,
        "MOKU_OTP_SWCTRL.COMPL8_PULSE_CFG_0": 0x6F6F,
        "MOKU_OTP_SWCTRL.COMPL8_PULSE_CFG_1": 0x0104,
        "MOKU_OTP_SWCTRL.COMPL_CFG5": 0x0080,
        "MOKU_OTP_SWCTRL.SELECT_CFG_0": 0x0000,
        "MOKU_OTP_SWCTRL.SELECT_CFG_1": 0x0001,
        "MOKU_OTP_SWCTRL.SLEW_CFG": 0x1C,
        "MOKU_OTP_SWCTRL.ERROR_CFG": 0xFFFF,
        "MOKU_OTP_SWCTRL.ERROR_CFG_1": 0x03,
        "MOKU_OTP_SWCTRL.BIST_CFG_0": 0x0F,
        "MOKU_OTP_SWCTRL.BIST_CFG_1": 0x0000,
        "MOKU_OTP_SWCTRL.TOLERANCE_CFG1_0": 0x4210,
        "MOKU_OTP_SWCTRL.TOLERANCE_CFG1_1": 0x798A,
        "MOKU_OTP_SARADC_MON.DIAG_ADC_MON_CFG_3_0": 0x00,
        "MOKU_OTP_SARADC_MON.DIAG_ADC_MON_CFG_5_0": 0x0000,
        "MOKU_OTP_SARADC_MON.DIAG_ADC_MON_CFG_5_1": 0x00,
        "MOKU_OTP_SARADC_SENSE.ADC_SENS_CFG_4_1": 0x01,
        "MOKU_OTP_EXT_TEMP.LOW_TEMP_THRES": 0x4232,
        "MOKU_OTP_EXT_TEMP.HIGH_TEMP_THRES": 0x0315,
        "MOKU_OTP_EXT_TEMP.EXTTMP_CTRL": 0x60,
        "MOKU_OTP_EXT_TEMP.TEMP_FILT_SAMPLES": 0x24,
        "MOKU_OTP_PAD_INTERFACE.PAD_CTRL_0": 0x89,
        "MOKU_OTP_ANALOG_CTRL.OVV_THRESHOLD_CTRL": 0xF5,
        "MOKU_OTP_CTRL_IF.CTRL_IF0":0x6C,
        "MOKU_OTP_CTRL_IF.CTRL_IF1":0x6C
        }

        OTP4Val={
        "MOKU_OTP_CCM.OSC_BIST_THRES_0": 0x01FD,
        "MOKU_OTP_CCM.OSC_TRIM_CTRL_0": 0x00,
        "MOKU_OTP_MSM.MSM_CTRL_1": 0x01FF,
        "MOKU_OTP_MSM.MSM_VIOLATION_MASK_0": 0x4800,
        "MOKU_OTP_MSM.MSM_VIOLATION_MASK_1": 0x0200,
        "MOKU_OTP_MSM.MSM_OVV_VIOLATION_MASK_0": 0x0000,
        "MOKU_OTP_MSM.MSM_OVV_VIOLATION_MASK_1": 0x0000,
        "MOKU_OTP_MSM.MSM_FLT_MASK_1_0": 0x0002,
        "MOKU_OTP_MSM.MSM_FLT_MASK_1_1": 0x0000,
        "MOKU_OTP_MSM.MSM_FLT_MASK_2_0": 0x0000,
        "MOKU_OTP_MSM.MSM_FLT_MASK_2_1": 0x0000,
        "MOKU_OTP_MSM.COMPL_CFG4": 0x0384,
        "MOKU_OTP_MSM.MSM_ANA_CTRL_0": 0xFFFF,
        "MOKU_OTP_MSM.MSM_ANA_CTRL_1": 0x07FF,
        "MOKU_OTP_MSM.ISRC_MM_CTRL": 0x001F,
        "MOKU_OTP_SWCTRL.COMPL1_CFG1": 0x8CCF,
        "MOKU_OTP_SWCTRL.COMPL1_CFG2_0": 0xFFFF,
        "MOKU_OTP_SWCTRL.COMPL1_CFG2_1": 0x001B,
        "MOKU_OTP_SWCTRL.COMPL2_CFG1": 0x8D2B,
        "MOKU_OTP_SWCTRL.COMPL2_CFG2_0": 0x030C,
        "MOKU_OTP_SWCTRL.COMPL2_CFG2_1": 0x0159,
        "MOKU_OTP_SWCTRL.COMPL3_CFG1": 0x8D8F,
        "MOKU_OTP_SWCTRL.COMPL3_CFG2_0": 0x023E,
        "MOKU_OTP_SWCTRL.COMPL3_CFG2_1": 0x0212,
        "MOKU_OTP_SWCTRL.COMPL4_CFG1": 0x8DF3,
        "MOKU_OTP_SWCTRL.COMPL4_CFG2_0": 0x01C7,
        "MOKU_OTP_SWCTRL.COMPL4_CFG2_1": 0x027F,
        "MOKU_OTP_SWCTRL.COMPL5_CFG1": 0x8E57,
        "MOKU_OTP_SWCTRL.COMPL5_CFG2_0": 0x0178,
        "MOKU_OTP_SWCTRL.COMPL5_CFG2_1": 0x02C5,
        "MOKU_OTP_SWCTRL.COMPL6_CFG1": 0x8EBB,
        "MOKU_OTP_SWCTRL.COMPL6_CFG2_0": 0x0140,
        "MOKU_OTP_SWCTRL.COMPL6_CFG2_1": 0x02F5,
        "MOKU_OTP_SWCTRL.COMPL7_CFG1": 0x8F1F,
        "MOKU_OTP_SWCTRL.COMPL7_CFG2_0": 0x0118,
        "MOKU_OTP_SWCTRL.COMPL7_CFG2_1": 0x031D,
        "MOKU_OTP_SWCTRL.COMPL8_CFG1": 0x8F83,
        "MOKU_OTP_SWCTRL.COMPL8_CFG2_0": 0x00F8,
        "MOKU_OTP_SWCTRL.COMPL8_CFG2_1": 0x0339,
        "MOKU_OTP_SWCTRL.COMPL1_PULSE_CFG_0": 0x0404,
        "MOKU_OTP_SWCTRL.COMPL1_PULSE_CFG_1": 0xFF06,
        "MOKU_OTP_SWCTRL.COMPL2_PULSE_CFG_0": 0x0606,
        "MOKU_OTP_SWCTRL.COMPL2_PULSE_CFG_1": 0xFF06,
        "MOKU_OTP_SWCTRL.COMPL3_PULSE_CFG_0": 0x0909,
        "MOKU_OTP_SWCTRL.COMPL3_PULSE_CFG_1": 0xFF06,
        "MOKU_OTP_SWCTRL.COMPL4_PULSE_CFG_0": 0x0B0B,
        "MOKU_OTP_SWCTRL.COMPL4_PULSE_CFG_1": 0xFE06,
        "MOKU_OTP_SWCTRL.COMPL5_PULSE_CFG_0": 0x0E0E,
        "MOKU_OTP_SWCTRL.COMPL5_PULSE_CFG_1": 0xFE06,
        "MOKU_OTP_SWCTRL.COMPL6_PULSE_CFG_0": 0x0101,
        "MOKU_OTP_SWCTRL.COMPL6_PULSE_CFG_1": 0xFD06,
        "MOKU_OTP_SWCTRL.COMPL7_PULSE_CFG_0": 0x1313,
        "MOKU_OTP_SWCTRL.COMPL7_PULSE_CFG_1": 0xFD06,
        "MOKU_OTP_SWCTRL.COMPL8_PULSE_CFG_0": 0x1515,
        "MOKU_OTP_SWCTRL.COMPL8_PULSE_CFG_1": 0xFC07,
        "MOKU_OTP_SWCTRL.COMPL_CFG5": 0x0080,
        "MOKU_OTP_SWCTRL.SELECT_CFG_0": 0x0000,
        "MOKU_OTP_SWCTRL.SELECT_CFG_1": 0x7801,
        "MOKU_OTP_SWCTRL.SLEW_CFG": 0x1C,
        "MOKU_OTP_SWCTRL.ERROR_CFG": 0xFFFF,
        "MOKU_OTP_SWCTRL.ERROR_CFG_1": 0x03,
        "MOKU_OTP_SWCTRL.BIST_CFG_0": 0x0F,
        "MOKU_OTP_SWCTRL.BIST_CFG_1": 0x0000,
        "MOKU_OTP_SWCTRL.TOLERANCE_CFG1_0": 0x4210,
        "MOKU_OTP_SWCTRL.TOLERANCE_CFG1_1": 0x798A,
        "MOKU_OTP_SARADC_MON.DIAG_ADC_MON_CFG_3_0": 0x00,
        "MOKU_OTP_SARADC_MON.DIAG_ADC_MON_CFG_5_0": 0x0000,
        "MOKU_OTP_SARADC_MON.DIAG_ADC_MON_CFG_5_1": 0x00,
        "MOKU_OTP_SARADC_SENSE.ADC_SENS_CFG_4_1": 0x01,
        "MOKU_OTP_EXT_TEMP.LOW_TEMP_THRES": 0x4232,
        "MOKU_OTP_EXT_TEMP.HIGH_TEMP_THRES": 0x0315,
        "MOKU_OTP_EXT_TEMP.EXTTMP_CTRL": 0x60,
        "MOKU_OTP_EXT_TEMP.TEMP_FILT_SAMPLES": 0x24,
        "MOKU_OTP_PAD_INTERFACE.PAD_CTRL_0": 0x89,
        "MOKU_OTP_ANALOG_CTRL.OVV_THRESHOLD_CTRL": 0xF5,
        "MOKU_OTP_CTRL_IF.CTRL_IF0":0x6C,
        "MOKU_OTP_CTRL_IF.CTRL_IF1":0x6C
        }

        OTP2Val={
        "MOKU_OTP_CCM.OSC_BIST_THRES_0": 0x01FF,
        "MOKU_OTP_CCM.OSC_TRIM_CTRL_0": 0x00,
        "MOKU_OTP_MSM.MSM_CTRL_1": 0x01FF,
        "MOKU_OTP_MSM.MSM_VIOLATION_MASK_0": 0x4119,
        "MOKU_OTP_MSM.MSM_VIOLATION_MASK_1": 0x00B3,
        "MOKU_OTP_MSM.MSM_OVV_VIOLATION_MASK_0": 0x0030,
        "MOKU_OTP_MSM.MSM_OVV_VIOLATION_MASK_1": 0x0000,
        "MOKU_OTP_MSM.MSM_FLT_MASK_1_0": 0x0002,
        "MOKU_OTP_MSM.MSM_FLT_MASK_1_1": 0x0000,
        "MOKU_OTP_MSM.MSM_FLT_MASK_2_0": 0x0000,
        "MOKU_OTP_MSM.MSM_FLT_MASK_2_1": 0x0000,
        "MOKU_OTP_MSM.COMPL_CFG4": 0x03E8,
        "MOKU_OTP_MSM.MSM_ANA_CTRL_0": 0xFFFF,
        "MOKU_OTP_MSM.MSM_ANA_CTRL_1": 0x07FF,
        "MOKU_OTP_MSM.ISRC_MM_CTRL": 0x003F,
        "MOKU_OTP_SWCTRL.COMPL1_CFG1": 0x8CB3,
        "MOKU_OTP_SWCTRL.COMPL1_CFG2_0": 0xFFFF,
        "MOKU_OTP_SWCTRL.COMPL1_CFG2_1": 0x0032,
        "MOKU_OTP_SWCTRL.COMPL2_CFG1": 0x00B3,
        "MOKU_OTP_SWCTRL.COMPL2_CFG2_0": 0x0000,
        "MOKU_OTP_SWCTRL.COMPL2_CFG2_1": 0x0000,
        "MOKU_OTP_SWCTRL.COMPL3_CFG1": 0x0000,
        "MOKU_OTP_SWCTRL.COMPL3_CFG2_0": 0x0000,
        "MOKU_OTP_SWCTRL.COMPL3_CFG2_1": 0x0000,
        "MOKU_OTP_SWCTRL.COMPL4_CFG1": 0x0000,
        "MOKU_OTP_SWCTRL.COMPL4_CFG2_0": 0x0000,
        "MOKU_OTP_SWCTRL.COMPL4_CFG2_1": 0x0000,
        "MOKU_OTP_SWCTRL.COMPL5_CFG1": 0x0000,
        "MOKU_OTP_SWCTRL.COMPL5_CFG2_0": 0x0000,
        "MOKU_OTP_SWCTRL.COMPL5_CFG2_1": 0x0000,
        "MOKU_OTP_SWCTRL.COMPL6_CFG1": 0x0000,
        "MOKU_OTP_SWCTRL.COMPL6_CFG2_0": 0x0000,
        "MOKU_OTP_SWCTRL.COMPL6_CFG2_1": 0x0000,
        "MOKU_OTP_SWCTRL.COMPL7_CFG1": 0x0000,
        "MOKU_OTP_SWCTRL.COMPL7_CFG2_0": 0x0000,
        "MOKU_OTP_SWCTRL.COMPL7_CFG2_1": 0x0000,
        "MOKU_OTP_SWCTRL.COMPL8_CFG1": 0x0000,
        "MOKU_OTP_SWCTRL.COMPL8_CFG2_0": 0x0000,
        "MOKU_OTP_SWCTRL.COMPL8_CFG2_1": 0x0000,
        "MOKU_OTP_SWCTRL.COMPL1_PULSE_CFG_0": 0x1616,
        "MOKU_OTP_SWCTRL.COMPL1_PULSE_CFG_1": 0x0104,
        "MOKU_OTP_SWCTRL.COMPL2_PULSE_CFG_0": 0x1616,
        "MOKU_OTP_SWCTRL.COMPL2_PULSE_CFG_1": 0x0104,
        "MOKU_OTP_SWCTRL.COMPL3_PULSE_CFG_0": 0x0000,
        "MOKU_OTP_SWCTRL.COMPL3_PULSE_CFG_1": 0x0000,
        "MOKU_OTP_SWCTRL.COMPL4_PULSE_CFG_0": 0x0000,
        "MOKU_OTP_SWCTRL.COMPL4_PULSE_CFG_1": 0x0000,
        "MOKU_OTP_SWCTRL.COMPL5_PULSE_CFG_0": 0x0000,
        "MOKU_OTP_SWCTRL.COMPL5_PULSE_CFG_1": 0x0000,
        "MOKU_OTP_SWCTRL.COMPL6_PULSE_CFG_0": 0x0000,
        "MOKU_OTP_SWCTRL.COMPL6_PULSE_CFG_1": 0x0000,
        "MOKU_OTP_SWCTRL.COMPL7_PULSE_CFG_0": 0x0000,
        "MOKU_OTP_SWCTRL.COMPL7_PULSE_CFG_1": 0x0000,
        "MOKU_OTP_SWCTRL.COMPL8_PULSE_CFG_0": 0x0000,
        "MOKU_OTP_SWCTRL.COMPL8_PULSE_CFG_1": 0x0000,
        "MOKU_OTP_SWCTRL.COMPL_CFG5": 0x0080,
        "MOKU_OTP_SWCTRL.SELECT_CFG_0": 0x0200,
        "MOKU_OTP_SWCTRL.SELECT_CFG_1": 0x0001,
        "MOKU_OTP_SWCTRL.SLEW_CFG": 0x1C,
        "MOKU_OTP_SWCTRL.ERROR_CFG": 0xFFE7,
        "MOKU_OTP_SWCTRL.ERROR_CFG_1": 0x02,
        "MOKU_OTP_SWCTRL.BIST_CFG_0": 0x0F,
        "MOKU_OTP_SWCTRL.BIST_CFG_1": 0x0000,
        "MOKU_OTP_SWCTRL.TOLERANCE_CFG1_0": 0x4210,
        "MOKU_OTP_SWCTRL.TOLERANCE_CFG1_1": 0x798A,
        "MOKU_OTP_SARADC_MON.DIAG_ADC_MON_CFG_3_0": 0x00,
        "MOKU_OTP_SARADC_MON.DIAG_ADC_MON_CFG_5_0": 0x0000,
        "MOKU_OTP_SARADC_MON.DIAG_ADC_MON_CFG_5_1": 0x00,
        "MOKU_OTP_SARADC_SENSE.ADC_SENS_CFG_4_1": 0x01,
        "MOKU_OTP_EXT_TEMP.LOW_TEMP_THRES": 0x4232,
        "MOKU_OTP_EXT_TEMP.HIGH_TEMP_THRES": 0x038C,
        "MOKU_OTP_EXT_TEMP.EXTTMP_CTRL": 0x60,
        "MOKU_OTP_EXT_TEMP.TEMP_FILT_SAMPLES": 0x24,
        "MOKU_OTP_PAD_INTERFACE.PAD_CTRL_0": 0x89,
        "MOKU_OTP_ANALOG_CTRL.OVV_THRESHOLD_CTRL": 0xF5,
        "MOKU_OTP_CTRL_IF.CTRL_IF0":0x6C,
        "MOKU_OTP_CTRL_IF.CTRL_IF1":0x6C
        }


        # determine which moku config
        OTP_CTRL_6 = self.i2cread(0x4218)
        # print("DEBUG!!",hex(OTP_CTRL_6))
        OTPID_STS = (OTP_CTRL_6 & 0x0F00) >> 8; #bits 11:8 of OTP_CTRL_6
        # print("DEBUG2!!",hex(OTPID_STS))
        tracking_ID_2 = self.i2cread(0x0028)

        if OTPID_STS == 4:
            print("Moku Config2 Detected  - reject this moku!")
            ReportDataToStationAndPDCA(prefix+"MOKU_Config",2,"Config",3,4)
            selectedOTP=OTP2Val
        elif OTPID_STS == 7:
            print("Moku Config3 Detected - pass this moku!")
            ReportDataToStationAndPDCA(prefix+"MOKU_Config",3,"Config",3,4)
            selectedOTP=OTP3Val
        elif OTPID_STS == 8:
            # either config 4 or 4b
            if tracking_ID_2 == 0x0904:
                # Config 4b - good for the build.
                print("Moku Config4B Detected - pass this moku!")
                ReportDataToStationAndPDCA(prefix+"MOKU_Config",4,"Config",3,4)
                selectedOTP=OTP4Val
            elif tracking_ID_2 == 0x0804:
                # config 4 - reject
                print("Moku Config4 Detected - reject this moku!")
                # Report Config 4 as 4.5 to PDCA  ensures proper rejection of Moku
                ReportDataToStationAndPDCA(prefix+"MOKU_Config",4.5,"Config",3,4)
                selectedOTP=OTP4Val
            else:
                print("unknown config  - reject this moku!")
                ReportDataToStationAndPDCA(prefix+"MOKU_Config",0,"Config",3,4)
                selectedOTP=OTP2Val
        else:
            print("unknown config  - reject this moku!")
            ReportDataToStationAndPDCA(prefix+"MOKU_Config",0,"Config",3,4)
            selectedOTP=OTP2Val
        # Check OTP
        for key in OTPMap:
            val=OTPMap[key]
            dat=self.i2cread(val)
            ReportDataToStationAndPDCA(prefix+key,dat,"hex",selectedOTP[key],selectedOTP[key])



    def standby2idle(self):

        state = self.i2cread(0x0400)
        if state != 0x02: # 0x02 is standby
            print("Standby state check - not in standby")
        ReportDataToStationAndPDCA("Standby to Idle state - standby check", state, "hex", 0x02, 0x02)

        self.i2cwrite(0x0408, 0x0001) # Enable the chip
        time.sleep(0.01)

        state = self.i2cread(0x0400)
        if state != 0x08: # 0x08 is idle state
            print("Standby to Idle transition failed - BAD!")
        ReportDataToStationAndPDCA("Standby to Idle state - idle check", state, "hex", 0x08, 0x08)


    def internalTempRead(self):
        self.i2cwrite(0x0406,0x0000)
        self.i2cwrite(0x0800,0x0000)
        self.i2cwrite(0x2014,0x0140)
        # self.i2cwrite(0x2094,0x0000)
        # nterrupt signal get asserted due to the ADC_data_info get unmasked here.
        # (remove this line if you do not want to assert INT for diagnostic data available)
        self.i2cwrite(0x0804,0x0000)
        self.i2cwrite(0x0806,0x0000)
        self.i2cwrite(0x080A,0x0001)
        self.i2cwrite(0x0804,0xFFFF)
        self.i2cwrite(0x0806,0x000F)
        time.sleep(0.0002)
        self.i2cwrite(0x0800,0x0802)
        # it should be => self.i2cwrite(0x0800, 0x0802)
        # write 0x0800 with value 0x0802 (you want 2^8 (256 samples) from the ADC, so for this you may have to wait 200us per sample
        # before you read out to get accurate number (so total ~51ms)
        time.sleep(0.1)
        dat=self.i2cread(0x1400)

		## Pei : added the conversion here
        if dat < 2 ** 16 / 2:
            int_temp_v = dat * 2 ** (-7)
        else:
            int_temp_v = (dat - 2 ** 16) * 2 ** (-7)

        ReportDataToStationAndPDCA("MOKU_INT_TEMP",dat,"hex",0x00,0xffff)

        state = self.i2cread(0x0400)
        if state != 0x08: # 0x08 is idle state -
            print("Not in Idle state test after internal temperature check - BAD!")
        ReportDataToStationAndPDCA("MOKU_INT_TEMP_BIST_STATUS", state, "hex", 0x08, 0x08)





    def externalTempRead(self):
        self.i2cwrite(0x0406,0x0000)
        self.i2cwrite(0x0800,0x0000)
        self.i2cwrite(0x2014,0x0140)
        # self.i2cwrite(0x2094,0x0000)
        # nterrupt signal get asserted due to the ADC_data_info get unmasked here.
        # (remove this line if you do not want to assert INT for diagnostic data available)
        self.i2cwrite(0x0804,0x0000)
        self.i2cwrite(0x0806,0x0000)
        self.i2cwrite(0x080A,0x0001)
        self.i2cwrite(0x0804,0xFFFF)
        self.i2cwrite(0x0806,0x000F)
        time.sleep(0.0002)
        self.i2cwrite(0x0800,0x0802)
        # it should be => self.i2cwrite(0x0800, 0x0802)
        # write 0x0800 with value 0x0802 (you want 2^8 (256 samples) from the ADC, so for this you may have to wait 200us per sample
        # before you read out to get accurate number (so total ~51ms)
        time.sleep(0.1)
        dat=self.i2cread(0x1204)  #Pei : multiply this by 2. I fixed this in line 563
        beta_constant = 3380
        kelvin_offset = 273.15
        standard_state = 298.15
        external_temp_c = (beta_constant / math.log(2*dat / (10000 * math.exp(-1*beta_constant / standard_state)))) - kelvin_offset
        # external_temp_c = (beta_constant / math.log(dat / (10000 * math.exp(-1*beta_constant / standard_state)))) - kelvin_offset
        ReportDataToStationAndPDCA("MOKU_EXT_TEMP",external_temp_c,"deg_c",15,45)
		# Limits updated needed to map from 15ºC to 40ºC

        state = self.i2cread(0x0400)
        if state != 0x08: # 0x08 is idle state
            print("Not in Idle state test after exteranl temperature check - BAD!")
        ReportDataToStationAndPDCA("MOKU_EXT_TEMP_BIST_STATUS", state, "hex", 0x08, 0x08)


    def BISTCheck(self,prefix=""):
        lexReset(self.LR,0)
        time.sleep(0.1)
        lexReset(self.LR,1)
        time.sleep(0.8)

        #dummy read to clear the FIFO
        self.i2cread(0x0000)

        state=self.i2cread(0x0400)
        if state!=0x02:
            print("BIST entry state is not standby, BAD!")
        ReportDataToStationAndPDCA(prefix+"MOKU_BIST_ENTRY_STATE",state,"hex",0x02,0x02)

        self.i2cwrite(0x0408,0x01) #state transition
        time.sleep(0.01)

        state=self.i2cread(0x0400)
        if state!=0x08:
            print("BIST exit state is not standby, BAD!")
        ReportDataToStationAndPDCA(prefix+"MOKU_BIST_EXIT_STATE",state,"hex",0x08,0x08)
        self.interruptDump(prefix=prefix)

    def interruptDump(self,prefix=""):
        IRQ_INT_0=self.i2cread(0x2010)
        ReportDataToStationAndPDCA(prefix+"MOKU_BIST_IRQ_INT_0",IRQ_INT_0,"hex",0x0000,0xffff)
        IRQ_INT_1=self.i2cread(0x2012)
        ReportDataToStationAndPDCA(prefix+"MOKU_BIST_IRQ_INT_1",IRQ_INT_1,"hex",0x0000,0xffff)
        IRQ_INT_2=self.i2cread(0x2014)
        ReportDataToStationAndPDCA(prefix+"MOKU_BIST_IRQ_INT_2",IRQ_INT_2,"hex",0x0000,0xffff)
        IRQ_INT_3=self.i2cread(0x2016)
        ReportDataToStationAndPDCA(prefix+"MOKU_BIST_IRQ_INT_3",IRQ_INT_3,"hex",0x0000,0xffff)
        IRQ_INT_4=self.i2cread(0x2018)
        ReportDataToStationAndPDCA(prefix+"MOKU_BIST_IRQ_INT_4",IRQ_INT_4,"hex",0x0000,0xffff)
        IRQ_INT_5=self.i2cread(0x201A)
        ReportDataToStationAndPDCA(prefix+"MOKU_BIST_IRQ_INT_5",IRQ_INT_5,"hex",0x0000,0x0004)
        IRQ_INT_6=self.i2cread(0x201C)
        ReportDataToStationAndPDCA(prefix+"MOKU_BIST_IRQ_INT_6",IRQ_INT_6,"hex",0x0000,0x0000)
        IRQ_INT_7=self.i2cread(0x201E)
        ReportDataToStationAndPDCA(prefix+"MOKU_BIST_IRQ_INT_7",IRQ_INT_7,"hex",0x3000,0x3000)
        IRQ_INT_8=self.i2cread(0x2020)
        ReportDataToStationAndPDCA(prefix+"MOKU_BIST_IRQ_INT_8",IRQ_INT_8,"hex",0x0000,0x0000)
        IRQ_INT_9=self.i2cread(0x2022)
        ReportDataToStationAndPDCA(prefix+"MOKU_BIST_IRQ_INT_9",IRQ_INT_9,"hex",0x0000,0x0000)
        IRQ_INT_10=self.i2cread(0x2024)
        ReportDataToStationAndPDCA(prefix+"MOKU_BIST_IRQ_INT_10",IRQ_INT_10,"hex",0x0000,0x0000)
        IRQ_INT_11=self.i2cread(0x2026)
        ReportDataToStationAndPDCA(prefix+"MOKU_BIST_IRQ_INT_11",IRQ_INT_11,"hex",0x0000,0x0000)
        IRQ_INT_12=self.i2cread(0x2028)
        ReportDataToStationAndPDCA(prefix+"MOKU_BIST_IRQ_INT_12",IRQ_INT_12,"hex",0x0000,0x0000)
        IRQ_INT_13=self.i2cread(0x202A)
        ReportDataToStationAndPDCA(prefix+"MOKU_BIST_IRQ_INT_13",IRQ_INT_13,"hex",0x0000,0x0000)
        IRQ_INT_14=self.i2cread(0x202C)
        ReportDataToStationAndPDCA(prefix+"MOKU_BIST_IRQ_INT_14",IRQ_INT_14,"hex",0x0000,0x0000)
        IRQ_INT_15=self.i2cread(0x202E)
        ReportDataToStationAndPDCA(prefix+"MOKU_BIST_IRQ_INT_15",IRQ_INT_15,"hex",0x0000,0x0000)
        IRQ_INT_16=self.i2cread(0x2030)
        ReportDataToStationAndPDCA(prefix+"MOKU_BIST_IRQ_INT_16",IRQ_INT_16,"hex",0x0000,0x0000)
        IRQ_INT_17=self.i2cread(0x2032)
        ReportDataToStationAndPDCA(prefix+"MOKU_BIST_IRQ_INT_17",IRQ_INT_17,"hex",0x0000,0x0000)
        IRQ_INT_18=self.i2cread(0x2034)
        ReportDataToStationAndPDCA(prefix+"MOKU_BIST_IRQ_INT_18",IRQ_INT_18,"hex",0x2a0,0x2a0)
        IRQ_INT_19=self.i2cread(0x2036)
        ReportDataToStationAndPDCA(prefix+"MOKU_BIST_IRQ_INT_19",IRQ_INT_19,"hex",0x0000,0x0000)


    def setupStrobe(self,source):
        # self.i2cwrite(0x0680,0x0000) # Copmliance Rule 0
        self.i2cwrite(0x0682,0x000F) # Signals on TRIG 1,2,3,4 all enable Moku Strobe 1
        # Above line shold write to 0x000F, per Pei's comment
        if source == 1:
            self.i2cwrite(0x0684,0x04ff) # SRC 1: write 0x04ff
        elif source == 2:
            self.i2cwrite(0x0684,0x08ff) # SRC 2: write 0x08ff
        else:
            self.i2cwrite(0x0684,0x0000) # no srcs
        self.i2cwrite(0x0686,0x0000)
        self.i2cwrite(0x0688,0x0000)
        self.i2cwrite(0x068a,0x0000)
        self.i2cwrite(0x0694,0x009F) # SNK1: 8mA drive current
        self.i2cwrite(0x0696,0x009F) # SNK2: 8mA drive current
        self.i2cwrite(0x0698,0x009F) # SNK3: 8mA drive current
        self.i2cwrite(0x069a,0x009F) # SNK4: 8mA drive current
        self.i2cwrite(0x069c,0x009F) # SNK5: 8mA drive current
        self.i2cwrite(0x069e,0x009F) # SNK6: 8mA drive current
        self.i2cwrite(0x06a0,0x009F) # SNK7: 8mA drive current
        self.i2cwrite(0x06a2,0x009F) # SNK8: 8mA drive current

    def write_otp_i2c_a_ind(self,prefetch=1, write_abort=1):

        if self.i2cread(0x4804) ==  0x6c:
            print("Part is locked, skipping this!")
            return

        print("State 1 "+hex(self.i2cread(0x0400)))
        # ensure standby mode
        self.i2cwrite(0x0408, 0)
        # dummyWrite(0x0408, 0)
        print("State 2 "+hex(self.i2cread(0x0400)))
        stand = self.i2cread(0x0400)
        # ensure VDDP is in 1.78V to 1.98V
        if stand == 0x02:
            VDDP = 1.88 # 1.78 <= VDDP <= 1.98 (1.85V)
            addr_list = [24     ,30     , 154  ] #OTP shadow register byte
            data_list = [0x0040, 0x0200, 0x6C00] # the new OTP value to be overwrite
            time.sleep(1)
            self.i2cwrite(0x4808, 0x01) # OTP_CTRL_IF3 (VDD_OTP_EN = 1) to enable VDD for OTP programming
            # dummyWrite(0x4808, 0x01)
            self.i2cwrite(0x4200, 0xA41A) # OTP_CTRL_0 to enable OTP write, WRITE ABORT, PREFETCH
            # dummyWrite(0x4200, 0xA41A)
            print('-------------------------- Writing OTP --------------------------')
            i=0
            for byte in addr_list:
                addr = 0x4000 + byte
                data = data_list[i]
                print('{}: {} overwrite = {}'.format(byte, (hex(addr)), hex(data)))
                value = self.i2cread(addr)
                otp_bit = value | data
                self.i2cwrite(addr, otp_bit)
                # dummyWrite(addr, otp_bit)
                busy = self.i2cread(0x420C)    # Wait until write is complete...
                while busy == 1:
                    time.sleep(.1)
                    busy = self.i2cread(0x420C)
                # check for errors writing OTP address
                if prefetch and write_abort:
                    if (self.i2cread(0x4208) & 0x8000) == 0x8000:
                        raise ValueError('OTP_WR_ERR: Error occurred at {} = {}'.format(
                            hex(self.i2cread(0x4208)), hex(data)))
                i=i+1
            self.i2cwrite(0x4200, 0xA418)
            # dummyWrite(0x4200, 0xA418)#Disable OTP write mode
            self.i2cwrite(0x4808, 0x00)
            # dummyWrite(0x4808, 0x00)#Disable OTP write mode

        else:
            print('The DUT is not in standby')
        # customer_otp.close()
    def read_opt_regs(self):
        print('-------------------------- Reading OTP --------------------------')
        for byte in range(0, 160, 2):
            addr = 0x4000 + byte
            print('{}: {} = {}'.format(byte, (hex(addr)), hex(self.i2cread(addr))))
        print()
    def sause(self):
        print("Pouring on some sause")
        val=self.i2cread(0x040C)
        self.i2cwrite(0x040C,val|0x4000)
        self.i2cwrite(0x209E,0x1000)
    def configureStrobe(self,source,ton=2):
        # Program Moku src/snk
        # self.i2cwrite(0x0680,0x0000)
        self.i2cwrite(0x0682,0x000f)
        if source == 1:
            self.i2cwrite(0x0684,0x04ff) # SRC 1: write 0x04ff
            print("Configuring Source 1")
        elif source == 2:
            self.i2cwrite(0x0684,0x08ff) # SRC 2: write 0x08ff
            print("Configuring Source 2")
        else:
            self.i2cwrite(0x0684,0x0000) # no srcs
        self.i2cwrite(0x0686,0x0000)
        self.i2cwrite(0x0688,0x0000)
        self.i2cwrite(0x068a,0x0000)
        # self.i2cwrite(0x068c,0x0000)
        # self.i2cwrite(0x068e,0x0000)
        # self.i2cwrite(0x0690,0x0000)
        # self.i2cwrite(0x0692,0x0000)
        self.i2cwrite(0x0694,0x009c)
        self.i2cwrite(0x0696,0x009c)
        self.i2cwrite(0x0698,0x009c)
        self.i2cwrite(0x069a,0x009c)
        self.i2cwrite(0x069c,0x009c)
        self.i2cwrite(0x069e,0x009c)
        self.i2cwrite(0x06a0,0x009c)
        self.i2cwrite(0x06a2,0x009c)
        self.i2cwrite(0x06a4,0x0000)
        self.i2cwrite(0x06a6,0x0000)


    def compliancePatch(self):
        # write config 3 settings into empty config 2
        self.i2cwrite(0x600,	0x8CB3)
        self.i2cwrite(0x604,	0xFFFF)
        self.i2cwrite(0x606,	0x32)
        self.i2cwrite(0x608,	0xB3)
        self.i2cwrite(0x640,	0x1616)
        self.i2cwrite(0x642,	0x104)
        self.i2cwrite(0x644,	0x1616)
        self.i2cwrite(0x646,	0x104)
        self.i2cwrite(0x660,	0x80)
        self.i2cwrite(0x664,	0x200)
        self.i2cwrite(0x666,	0x1)

class Lanai(ISPI2CDevice):


    def __init__(self, cam):
        ISPI2CDevice.__init__(self,cam=cam,ch=0,address=0x10,reglen=2,datlen=1)
        self.cam=cam

    def setupManualExp(self):
        ISPShell("MANUALAE "+str(self.cam)+" 4000 0x100 0x100 0x100")
    def setupSync(self):
        self.i2cwrite(0x0681,0x00) # Continous output
        self.i2cwrite(0x0650,0x01) # mid-exposure drive
        self.i2cwrite(0x0651,0x04) # Strobe on GPO0: 0x04, Strobe on GPO1 for BECAM: 0x???
        # Need GPO 1 configuration from Ashish
        self.i2cwrite(0x0680,0x00) # use shutter as reference point
        self.i2cwrite(0x0685,0x000000,3) # Zero delay from reference point
        self.i2cwrite(0x068c,0x000003D4,4) #4000us strobe signal to match exposure time of 4000us
        self.i2cwrite(0x0670,0x01,1) #enable
    def startStreaming(self):

        frameTxt=ISPShell("SFSTART "+str(self.cam),prompt="framereceived:",timeout=10)
        print(frameTxt)
    def stopStreaming(self):
        ISPShell("SFSTOP "+str(self.cam))
    def primeStrobe(self,ton=5500):#ton in us
        tonval=int(ton/4.083)
        print("Ton reg",hex(tonval))
        self.i2cwrite(0x0681,0x00,1)
        self.i2cwrite(0x0650,0x01,1)
        self.i2cwrite(0x0651,0x04,1)
        self.i2cwrite(0x0680,0x00,1)
        self.i2cwrite(0x0685,0x00,3)
        self.i2cwrite(0x068c,tonval,4)
        self.i2cwrite(0x0670,0x01,1)


class Adams():
    def __init__(self,ch):
        self.ch=ch
    def regRead(self,addr):

        rct=ISPShell("SPMIREAD "+str(self.ch)+" 0x9 "+hex(addr)+" 2 1 ")
        val=self.parsei2cRead(rct,1)
        # print("=== DEBUG2 ",hex(val))
        return val

    def regWrite(self,addr,dat):
        ISPShell("SPMIWRITE "+str(self.ch)+" 0x9 "+hex(addr)+" 2 1 "+hex(dat))
    def parsei2cRead(self,matchstr,datlen):
        ma=re.search("data: (0x[0-9|A-F]{"+str(datlen*2)+"})",matchstr,re.M)
        try:
            val=ma.group(1)
            # print("=== DEBUG "+ ma.group(1),hex(int(val,16)))
            # print("=== +++ DEBUG"+ matchstr)
        except Exception:
            print("PARSER NO MATCH, RETURINING 0")
            print(matchstr)
            return 0
        #implement fancy parser here
        return int(val,16)

mokul=Moku(cam=2)
mokur=Moku(cam=5)

NECAML=Lanai(cam=2)
NECAMR=Lanai(cam=5)
BECAML=Lanai(cam=6)
BECAMR=Lanai(cam=7)


def openTest(LR):# for LEFT
    if LR == "L":
        mokuDUT=mokul
        lanaiDUT=NECAML
    elif LR == "R":
        mokuDUT=mokur
        lanaiDUT=NECAMR

    strobeLEDs(LR,1,timeout=5)
    state=mokuDUT.i2cread(0x0400)
    if state!=0x08: # Should be 0x08 for idle
        print("BIST exit state is not idle, BAD!")
    ReportDataToStationAndPDCA("MOKU_CC_CHECK_STATE_SOURCE1",state,"hex",0x08,0x08)
	# Modified to verify Source 1 and Source 2 independeintly
    time.sleep(1)
    strobeLEDs(LR,2,timeout=5)
    state=mokuDUT.i2cread(0x0400)
    if state!=0x08:
        # Should be 0x08 for idle
        print("BIST exit state is not idle, BAD!")
    ReportDataToStationAndPDCA("MOKU_CC_CHECK_STATE_SOURCE2",state,"hex",0x08,0x08)

def burnOTP(LR):
    if LR == "L":
        mokuDUT=mokul
    elif LR == "R":
        mokuDUT=mokur


    mokuDUT.OTPDump(prefix="PREBURN-")
    lexReset(LR,0)
    time.sleep(0.1)
    lexReset(LR,1)
    time.sleep(0.8)

    #dummy read to clear the FIFO
    mokuDUT.i2cread(0x0000)

    if mokuDUT.i2cread(0x0400) != 0x02:
        print("Moku NOT in STANDBY, abort!",hex(mokuDUT.i2cread(0x0400)))
        sys.exit(1)

    setLexV(LR,1.88)
    setLexV(LR,1.88)
    setLexV(LR,1.88)
    mokuDUT.write_otp_i2c_a_ind()

    lexReset(LR,0)
    time.sleep(0.1)
    lexReset(LR,1)
    time.sleep(0.8)

    #dummy read to clear the FIFO
    mokuDUT.i2cread(0x0000)

    mokuDUT.BISTCheck(prefix="POSTBURN-")
    mokuDUT.OTPDump(prefix="POSTBURN-")




def rch(ch):
    return r"camChannel: "+str(ch)+"([\s|\n]*.*){3,8}[\s|\n]+sensorSerialNum: ([0-9|A-Z]*)"
avaliableCam=[]
def camConnTest():
    s.sendline("i")
    s.prompt(timeout=5)
    print("i done")
    for i in range(14):
        try:
            ser=re.search(rch(i),s.before.decode("utf-8"),re.M).group(2)
            if ser != "0000000000000000":
                print("cam "+str(i)+" detected! Ser:"+ser)
                avaliableCam.append(i)
            else:
                print("cam "+str(i)+" NOT detected!")
        except Exception:
            print("re failed ",i)

    titusSerRE=r"camChannel: 4([\s|\n]*.*){25,30}[\s|\n]+strobeSerialNum:[\s]*([A-Z|0-9]*)"
    try:
        titusSer=re.search(titusSerRE,s.before.decode("utf-8"),re.M).group(2)
        if ser != "0000000000000000":
            print("Titus detected! Ser:"+ser)
        else:
            print("Titus NOT detected!")
    except Exception:
        print("re failed Titus")
            # print(s.before.decode("utf-8"))
    # print(s.before)

def camStreamTest():
    frameRE=r"framereceived:"

    s.sendline("SFSETLAYOUTTYPE 1 ")
    s.prompt(timeout=5)

    for cam in avaliableCam:
        ISPShell("sfstart "+str(cam),prompt="framereceived:",timeout=10)

        if frameRE in s.before.decode("utf-8"):
            print("Cam "+str(cam)+"streaming test passed")
        else:
            print("Can't Stream cam",str(cam))
            print(s.before.decode("utf-8"))
        ISPShell("sfstop "+str(cam))


def lexReset(LR,state):
    if LR == "L":
        ISPShell("spmiwrite 3 0x9 0x1D1f 2 1 0x8"+str(int(state)))
    elif LR  == "R":
        ISPShell("spmiwrite 0 0x9 0x1D1f 2 1 0x8"+str(int(state)))
    else:
        print("Pass L/R to LR!")
        sys.exit(1)



def writeResults(file):
    with open(file,"w+") as f:
        for row in resultStr:
            f.write(row)

def setLexV(LR,voltage):

  if (voltage>=1.24 and voltage <=3.79):
    VSEL=hex(int((voltage-1.24)/0.01))
    print("Setting VSEL to ",VSEL)
    if LR == "L":
        cmd="I2CDEVICEWRITE 2 2 0x75 0x2000 2 1 "+VSEL
    elif LR=="R":
        cmd="I2CDEVICEWRITE 5 2 0x75 0x2000 2 1 "+VSEL
    print("DEBUG!!!  "+cmd)
    ISPShell(cmd)

def strobeLEDs(LR,ISRC,timeout=60):
    if LR == "L":
        mokuDUT=mokul
        lanaiDUT=NECAML
    elif LR == "R":
        mokuDUT=mokur
        lanaiDUT=NECAMR


    ISPShell("RMCOPEN")
    ISPShell("RMCSENDCOMMAND SensorFrameRateSet 2 768")

    # mokuDUT.sause() # only on unlocked units
    # mokuDUT.compliancePatch() # only on config2 unlocked

    lexReset(LR,0)
    time.sleep(0.1)
    lexReset(LR,1)
    time.sleep(0.8)
    #dummy read to clear the FIFO
    mokuDUT.i2cread(0x0000)

    mokuDUT.i2cwrite(0x0408,0x01) #state transition
    time.sleep(0.1)

    if mokuDUT.i2cread(0x0400) != 0x08:
        print("Moku NOT in idle, abort!",hex(mokuDUT.i2cread(0x0400)))
        return
    lanaiDUT.primeStrobe()
    mokuDUT.configureStrobe(ISRC)
    time.sleep(0.25)
    if mokuDUT.i2cread(0x0400) != 0x08:
        print("Moku NOT in idle after priming, abort!",hex(mokuDUT.i2cread(0x0400)))

    lanaiDUT.startStreaming()
    time.sleep(timeout)
    lanaiDUT.stopStreaming()

    mokuDUT.interruptDump(prefix="ISRC"+str(ISRC)+"-")
    # camConnTest()
    # camStreamTest()

def mokuIlligalTests(LR):
    if LR == "L":
        mokuDUT=mokul
    elif LR == "R":
        mokuDUT=mokur

    lexReset(LR,0)
    time.sleep(0.1)
    lexReset(LR,1)
    #dummy read to clear the FIFO
    mokuDUT.i2cread(0x0000)

    mokuDUT.I2CCheck()
    # mokuDUT.sause() # overwrites the shadow regs for unlocked only
    VIO_MAX_TON_DIG_LVL_INT(LR)
    VIO_MIN_TOFF_DIG_LVL_INT(LR)


TON_VIO={1:8.39,2:6.33,3:4.98,4:4.15,5:3.56,6:3.14,7:2.8}
TOFF_VIO={0:10.91,1:7.7}


ISNK={0:250,1:360,2:480,3:600,4:720,5:840,6:960,7:1023}

def VIO_MAX_TON_DIG_LVL_INT(LR):
    if LR == "L":
        mokuDUT=mokul
        adamsDUT=Adams(0)
        lanaiDUT=NECAML
    elif LR == "R":
        mokuDUT=mokur
        adamsDUT=Adams(3)
        lanaiDUT=NECAMR

    for rule in TON_VIO.keys():
    # 1. POWER UP Moku. WAIT for 1ms after VDD Moku reaches POR level.  * This does not includesLEX power up time
        lexReset(LR,0)
        time.sleep(0.1)
        lexReset(LR,1)
        setLexV(LR,2.7)
        mokuDUT.i2cread(0x0000)
    # 2. WRITE 0x01 to address 0x201A to de-assert the INT pin.
        mokuDUT.i2cwrite(0x201A,0x01)
    # 3. WRITE rule# = 0x00 to address 0x0680.
        mokuDUT.i2cwrite(0x0680,rule)
    # 4. WRITE 0x01 to address 0x0408 to transition from STANBY2IDLE. Wait for MIN_TOFF after i2c command reaches Moku. 
        mokuDUT.i2cwrite(0x0408,0x01)
        time.sleep(0.2)
    # * I2C delay isn’t included in the wait time. Will need to confirm with FW/ System. 

    # * MIN TOFF based on OTP settings => TBD
    # 5. OBSERVE INT pin to ensure it is HIGH, i.e no interrupt is flagged.
        mokuDUT.i2cwrite(0x201A,0x01)
        stat=adamsDUT.regRead(0x1DC2)
        INTState=stat&0x01
        # ReportDataToStationAndPDCA("VIO_MAX_TON_DIG_LVL_INT_STEP5_RULE"+str(rule),INTState,"",1,1)
    # 6. READ the value in address 0x0400, value return should be 0x08. 
        val=mokuDUT.i2cread(0x0400)
        ReportDataToStationAndPDCA("VIO_MAX_TON_DIG_LVL_INT_STEP6_RULE"+str(rule),val,"",0x08,0x08)
    # *If value = 0x20 or 0x40, Moku is in violation
    # 7. APPLY the TRIG signal based on that is within the limit, except for TON timing. 
    # *value TON is still TBD
        #configure Lanai
        width=TON_VIO[rule]
        lanaiDUT.primeStrobe(ton=width*1000)
        # lanaiDUT.setFR(120)#33ms cycle, def enough TOFF
        mokuDUT.configureStrobe(1)
        time.sleep(0.25)

        lanaiDUT.startStreaming()
        time.sleep(0.2)
        lanaiDUT.stopStreaming()

    # 7b. READ the value in address 0x0400, value return should be 0x20. 
        val=mokuDUT.i2cread(0x0400)
        ReportDataToStationAndPDCA("VIO_MAX_TON_DIG_LVL_INT_STEP7b_RULE"+str(rule),val,"",0x20,0x20)
    # 8. READ the value in address 0x201C, if violation occurs, it should return 0xC000.
        val=mokuDUT.i2cread(0x201C)
        maskedval=val & 0xc000
        ReportDataToStationAndPDCA("VIO_MAX_TON_DIG_LVL_INT_STEP8_RULE"+str(rule),maskedval,"",0xC000,0xC000)
        mokuDUT.interruptDump(prefix="")
    # # 9. To CLEAR the interrupt,
    # # 9-1. WRITE 0x4000 to address 0x201C to clear the INT.
    #     mokuDUT.i2cwrite(0x201C,0x4000)
    # # 9-2. READ the value in address 0x2010, get the value.
    # # • clear_val = value | 0x1000
    #     val=mokuDUT.i2cread(0x2010)
    #     clear_val = val | 0x1000
    # # 3. WRITE the clear_val into address 0x2010.
    #     mokuDUT.i2cwrite(0x2010,clear_val)
    # # 4. INT will go HIGH.
    # # 10.READ the value in address 0x0400, value return should be 0x02.
    #     val=mokuDUT.i2cread(0x0400)
    #     ReportDataToStationAndPDCA("VIO_MAX_TON_DIG_LVL_INT_STEP10_RULE"+str(rule),val,"",0x02,0x02)
    # # 11.POWER DOWN Moku.

# 12.REPEAT the test from step 2 with rule# = [0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07]

def VIO_MIN_TOFF_DIG_LVL_INT(LR):
    if LR == "L":
        mokuDUT=mokul
        adamsDUT=Adams(0)
        lanaiDUT=NECAML
    elif LR == "R":
        mokuDUT=mokur
        adamsDUT=Adams(3)
        lanaiDUT=NECAMR
    for rule in TOFF_VIO.keys():
    # 1. POWER UP Moku. WAIT for 1ms after VDD Moku reaches POR level.  * This does not includesLEX power up time
        lexReset(LR,0)
        time.sleep(0.1)
        lexReset(LR,1)
        setLexV(LR,2.7)
        mokuDUT.i2cread(0x0000)
    # 2. WRITE 0x01 to address 0x201A to de-assert the INT pin.
        mokuDUT.i2cwrite(0x201A,0x01)
    # 3. WRITE rule# = 0x00 to address 0x0680.
        mokuDUT.i2cwrite(0x0680,rule)
    # 4. WRITE 0x01 to address 0x0408 to transition from STANBY2IDLE. Wait for MIN_TOFF after i2c command reaches Moku. 
        mokuDUT.i2cwrite(0x0408,0x01)
        time.sleep(0.2)
    # * I2C delay isn’t included in the wait time. Will need to confirm with FW/ System. 

    # * MIN TOFF based on OTP settings => TBD
    # 5. OBSERVE INT pin to ensure it is HIGH, i.e no interrupt is flagged.
        mokuDUT.i2cwrite(0x201A,0x01)#known bug, SeL width
        stat=adamsDUT.regRead(0x1DC2)
        INTState=stat&0x01
        # ReportDataToStationAndPDCA("VIO_MIN_TOFF_DIG_LVL_INT_STEP5_RULE"+str(rule),INTState,"",1,1)
    # 6. READ the value in address 0x0400, value return should be 0x08. 
        val=mokuDUT.i2cread(0x0400)
        ReportDataToStationAndPDCA("VIO_MIN_TOFF_DIG_LVL_INT_STEP6_RULE"+str(rule),val,"",0x08,0x08)
# *If value = 0x20 or 0x40, Moku is in violation
#7. APPLY the TRIG signal based with right timing except for TON. 

        width=TOFF_VIO[rule]
        lanaiDUT.primeStrobe(ton=width*1000)
        # lanaiDUT.setFR(120)#90Hz 1.1ms
        mokuDUT.configureStrobe(1)
        time.sleep(0.1)

        lanaiDUT.startStreaming()
        time.sleep(1)
        lanaiDUT.stopStreaming()
    # 7b. READ the value in address 0x0400, value return should be 0x20. 
        val=mokuDUT.i2cread(0x0400)
        ReportDataToStationAndPDCA("VIO_MAX_TOFF_DIG_LVL_INT_STEP7b_RULE"+str(rule),val,"",0x20,0x20)
# *value TOFF is still TBD
# 8. READ the value in address 0x201E, if violation occurs, it should return 0x000C.
        val=mokuDUT.i2cread(0x201E)
        ReportDataToStationAndPDCA("VIO_MIN_TOFF_DIG_LVL_INT_STEP8_RULE"+str(rule),val&0x0C,"",0x000C,0x000C)
        mokuDUT.interruptDump(prefix="")
# # 9. To CLEAR the interrupt,
# # 1. WRITE 0x0004 to address 0x201E to clear the INT.
#         mokuDUT.i2cwrite(0x201E,0x0004)
# # 2. WRITE the 0x1000 into address 0x2010.
#         mokuDUT.i2cwrite(0x2010,0x1000)
# # 3. INT will back HIGH.
# # 10.READ the value in address 0x0400, value return should be 0x02.
#         val=mokuDUT.i2cread(0x0400)
#         ReportDataToStationAndPDCA("VIO_MIN_TOFF_DIG_LVL_INT_STEP10_RULE"+str(rule),val,"",0x02,0x02)
# # 11.POWER DOWN Moku.
# # 12.REPEAT the test from step 2 with rule# = [0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07]

def VIO_MAX_ISNK_ANA_LVL_INT():
    if LR == "L":
        mokuDUT=mokul
        adamsDUT=adamsDUT=Adams(0)
        lanaiDUT=NECAML
    elif LR == "R":
        mokuDUT=mokur
        adamsDUT=adamsDUT=Adams(3)
        lanaiDUT=NECAMR
    for rule in [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07]:
# 1. POWER UP Moku. WAIT for 1ms after VDD Moku reaches POR level.  * This does not includes LEX power up time
        lexReset(LR,0)
        time.sleep(0.1)
        lexReset(LR,1)
        setLexV(LR,2.7)
        mokuDUT.i2cread(0x0000)
# 2. WRITE 0x01 to address 0x201A to de-assert the INT pin.
        mokuDUT.i2cwrite(0x201A,0x01)
# 3. WRITE rule# = 0x00 to address 0x0680.
        mokuDUT.i2cwrite(0x0680,rule)
# 4. WRITE 0x01 to address 0x0408 to transition from STANBY2IDLE. Wait for 10 ms## .
        mokuDUT.i2cwrite(0x0408,0x01)
        time.sleep(0.2)
# 5. OBSERVE INT pin to ensure it is HIGH, i.e no interrupt is flagged.
        stat=adamsDUT.regRead(0x1DC2)
        INTState=stat&0x01
        ReportDataToStationAndPDCA("VIO_MAX_ISNK_ANA_LVL_INT_INT_STEP5_RULE"+str(rule),INTState,"",1,1)
# 6. READ the value in address 0x0400, value return should be 0x08.  Note : If value = 0x20 or 0x40, Moku is in violation
        val=mokuDUT.i2cread(0x0400)
        ReportDataToStationAndPDCA("VIO_MAX_ISNK_ANA_LVL_INT_INT_STEP6"+str(rule),val,"",0x08,0x08)
# 7. WRITE ISNK_lvl to adresses = [0x0694, 0x0696, 0x0698, 0x069A, 0x069C, 0x069E, 0x06A0, 0x06A2, 0x06A4, 0x06A6]
        for tgt in [0x0694, 0x0696, 0x0698, 0x069A, 0x069C, 0x069E, 0x06A0, 0x06A2, 0x06A4, 0x06A6]:
            val=mokuDUT.write(tgt,ISNK[rulle])
# * Refer table1 below for violated ISNK values.
# 8. APPLY the TRIG signal based on the selected rules.
        mokuDUT.configureStrobe(1)
        time.sleep(0.25)

        lanaiDUT.startStreaming()
        time.sleep(0.2)
        lanaiDUT.stopStreaming()
# 9. READ the value in address 0x201C, if violation occurs, it should return 0x3C00.
        val=mokuDUT.i2cread(0x201C)
        ReportDataToStationAndPDCA("VIO_MAX_ISNK_ANA_LVL_INT_INT_STEP9"+str(rule),val,"",0x3C00,0x3C00)
# 10.To CLEAR the interrupt,
# 1. WRITE 0x1400 to address 0x201C to clear the INT.
        mokuDUT.i2cwrite(0x201C,0x1400)
# 2. WRITE the 0x1000 into address 0x2010.
        mokuDUT.i2cwrite(0x2010,0x1000)
# 3. INT will back HIGH.
# 11.READ the value in address 0x0400, value return should be 0x02.
        val=mokuDUT.i2cread(0x0400)
        ReportDataToStationAndPDCA("VIO_MAX_ISNK_ANA_LVL_INT_INT_STEP11"+str(rule),val,"",0x02,0x02)
# 12.POWER DOWN Moku.
# 13.REPEAT the test from step 2 with rule# = [0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07]

# def VIO_BIST_CC_TIMING_RISE_INT():
#     if LR == "L":
#         mokuDUT=mokul
#         adamsDUT=bora.isp.ADAMSOL
#         lanaiDUT=NECAML
#     elif LR == "R":
#         mokuDUT=mokur
#         adamsDUT=bora.isp.ADAMSOR
#         lanaiDUT=NECAMR
# # 1. POWER UP Moku. WAIT for 1ms after VDD Moku reaches POR level.  * This does not includes LEX power up time
#     lexReset(LR,0)
#     time.sleep(0.1)
#     lexReset(LR,1)
#     mokuDUT.i2cread(0x0000)
# # 2. WRITE 0x01 to address 0x201A to de-assert the INT pin.
# mokuDUT.i2cwrite(0x201A,0x01)
# # 3. OBSERVE INT pin to ensure it is HIGH, i.e no interrupt is flagged.
#         stat=adamsDUT.regRead(0x1DC2)
#         INTState=stat&0x01
#         ReportDataToStationAndPDCA("VIO_MAX_ISNK_ANA_LVL_INT_INT_STEP5_RULE"+str(rule),INTState,"",1,1)
# # 4. READ the value in address 0x0400, value return should be 0x0002.  *If value = 0x20 or 0x40, Moku is in violation.
#         val=mokuDUT.i2cread(0x0000)
#         ReportDataToStationAndPDCA("VIO_MAX_ISNK_ANA_LVL_INT_INT_STEP6"+str(rule),val,"",0x08,0x08)
# # 5. APPLY the TRIG signal based on the selected rules.
# # 6. At the same time, WRITE 0x01 to address 0x0408 to transition from STANBY2IDLE.
# # 7. READ the value in address 0x201A , if violation occurs, it should return 0x0016.
# # 8. To CLEAR the interrupt,
# # 1. WRITE 0x0014 to address 0x201A to clear the INT.
# # 2. WRITE the 0x1000 into address 0x2010.
# # 3. INT will back HIGH.
# # 9. READ the value in address 0x0400, value return should be 0x02.
# # 10.POWER DOWN Moku.



def main():

    mokuIlligalTests("L")

    writeResults("results.csv")


    # strobeLEDs()

if __name__=="__main__":
    main()
