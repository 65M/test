import sys

# print(sys.path)
sys.path.append("nandfs:\\AppleInternal\Diags\Logs\Smokey\Shared\SEuP")
sys.path.append("nandfs:\\AppleInternal\Diags\Python\lib")
from seup import *
from cameraTests import *

import re
import math
import time ,os, datetime
import random
import argparse

MOKUTESTS_VER = "2022-12-15-01"
print("mokuTests Version: "+MOKUTESTS_VER)

MOKUL=bora.isp.MOKUL
MOKUR=bora.isp.MOKUR

NECAML=bora.isp.NECAML
NECAMR=bora.isp.NECAMR
BECAML=bora.isp.BECAML
BECAMR=bora.isp.BECAMR

def lexReset(LR,state):

    if LR == "L":
        bora.isp.ADAMSOL.setIO(11,state)
    elif LR  == "R":
        bora.isp.ADAMSOR.setIO(11,state)
    else:
        print("Pass L/R to LR!")
        sys.exit(1)
    #implement with seup
def setLexV(LR,voltage):
    if LR == "L":
        bora.isp.LEXL.setV(voltage)
    elif LR  == "R":
        bora.isp.LEXR.setV(voltage)
    else:
        print("Pass L/R to LR!")
        sys.exit(1)



def kilaueaTest(LR):
    CAM_OPT = "NECAM"
    if LR == "L":
        mokuDUT=MOKUL
        lanaiDUT=NECAML
    elif LR == "R":
        mokuDUT=MOKUR
        lanaiDUT=NECAMR

    strobeLEDs(CAM_OPT,"1",LR,1,timeout=1.5, sec_check=0)

    state=mokuDUT.i2cread(0x0400)
    ReportDataToStationAndPDCA("KILAUEA"+LR+"_CC_CHECK_STATE_SOURCE1",state,"hex",0x08,0x08)
    if state!=0x08: # Should be 0x08 for idle
        print("BIST exit state is not idle, BAD!")
        mokuDUT.interruptDump(prefix="ISRC1-")

	# Modified to verify Source 1 and Source 2 independently
    time.sleep(1)
    # toggle Secure IO
    sep.secureIO("L",0)
    sep.secureIO("R",0)

    strobeLEDs(CAM_OPT,"1",LR,2,timeout=1.5, sec_check=0)
    state=mokuDUT.i2cread(0x0400)
    ReportDataToStationAndPDCA("KILAUEA"+LR+"_CC_CHECK_STATE_SOURCE2",state,"hex",0x08,0x08)
    if state!=0x08:
        # Should be 0x08 for idle
        print("BIST exit state is not idle, BAD!")
        mokuDUT.interruptDump(prefix="ISRC2-")

    sep.secureIO("L",1)
    sep.secureIO("R",1)

def camStrobeCheck(LR):
    cam_opts = ["NECAM", "BECAM"]
    strobes = ["1", "2"]

    if LR == "L":
        mokuDUT=MOKUL
        sep.secureIO("L", 1)
    elif LR == "R":
        mokuDUT=MOKUR
        sep.secureIO("R", 1)
    for c in cam_opts:
        for s in strobes:
            strobeLEDs(c, s, LR, 1, timeout=1.5, ton=8000, expected_violation=True)
            ton_violation = mokuDUT.i2cread(0x201C) & 0xC000
            ReportDataToStationAndPDCA("MOKU" + LR + "_" + c + LR + "_STROBE" + s + "_CONNECTIVITY", ton_violation, "hex", 0xC000, 0xC000)
            if (ton_violation != 0xC000):
                print("Check strobe connectivity!")

    sep.secureIO("L",1)
    sep.secureIO("R",1)

    lexReset(LR, 0)
    time.sleep(0.1)
    lexReset(LR, 1)
    setLexV(LR, 2.55)

    mokuDUT.BISTCheck()

def danceTest(LR):
    if LR == "L":
        mokuDUT=MOKUL
        lanaiDUT=NECAML
    elif LR == "R":
        mokuDUT=MOKUR
        lanaiDUT=NECAMR

    lexReset(LR,0)
    time.sleep(0.1)
    lexReset(LR,1)
    time.sleep(0.8)
    setLexV(LR,2.7)
    #dummy read to clear the FIFO
    mokuDUT.i2cread(0x0000)
    mokuDUT.i2cwrite(0x0408,0x01) #state transition
    time.sleep(0.1)
    if mokuDUT.i2cread(0x0400) != 0x08:
        print("Moku NOT in idle, abort!",hex(mokuDUT.i2cread(0x0400)))
        return
    lanaiDUT.primeStrobe1()
    mokuDUT.configureStrobes(1,nine=True)
    time.sleep(0.25)
    if mokuDUT.i2cread(0x0400) != 0x08:
        print("Moku NOT in idle after priming, abort!",hex(mokuDUT.i2cread(0x0400)))
    lanaiDUT.startStreaming()

    for i in range(20):
        for j in range(1,9):
            mokuDUT.setISNK(j,random.randint(0,100))
        time.sleep(0.5)

    mokuDUT.configureStrobes(2,nine=True)
    for i in range(20):
        for j in range(1,9):
            mokuDUT.setISNK(j,random.randint(0,100))
        time.sleep(0.5)
    lanaiDUT.stopStreaming()

def secureTest(LR):
    CAM_OPT = "NECAM"
    if LR == "L":
        mokuDUT = MOKUL
        lanaiDUT = NECAML
        sep.secureIO("L", 1)
    elif LR == "R":
        mokuDUT = MOKUR
        lanaiDUT = NECAMR
        sep.secureIO("R", 1)

    strobeLEDs(CAM_OPT, "1", LR, 2, timeout=1.5, sec_check=1)

    state = mokuDUT.i2cread(0x0400)
    ReportDataToStationAndPDCA("MOKU" + LR + "_" + CAM_OPT + LR + "_SECURE_IO_CONNECTIVITY", state, "hex", 0x20, 0x20)

    if state != 0x20:  # Should be 0x08 for idle
        print("SECURE_IO is not connected!")
        mokuDUT.interruptDump(prefix="ISRC1-SECURE-")
    else:
        lexReset(LR, 0)
        time.sleep(0.1)
        lexReset(LR, 1)
        setLexV(LR, 2.55)
        mokuDUT.BISTCheck()


def strobeLEDs(CAM_OPT, STROBE, LR,ISRC,timeout=60,nine=False,ton=5500, sec_check=0, expected_violation=False):
    if LR == "L":
        mokuDUT=MOKUL
        if CAM_OPT == "BECAM":
            lanaiDUT= BECAML
        else:
            lanaiDUT = NECAML
    elif LR == "R":
        mokuDUT=MOKUR
        if CAM_OPT == "BECAM":
            lanaiDUT= BECAMR
        else:
            lanaiDUT=NECAMR

    lexReset(LR,0)
    time.sleep(0.1)
    lexReset(LR,1)
    time.sleep(0.8)
    setLexV(LR,2.55)

    #dummy read to clear the FIFO
    mokuDUT.i2cread(0x0000)

    # mokuDUT.specialSause()

    mokuDUT.i2cwrite(0x0408,0x01) #state transition
    time.sleep(0.2)
    if mokuDUT.i2cread(0x0400) != 0x08:
        print("Moku NOT in idle, abort!",hex(mokuDUT.i2cread(0x0400)))
        mokuDUT.interruptDump(prefix="ISRC"+str(ISRC)+"-")
        return

    if STROBE == "1":
        lanaiDUT.primeStrobe1(ton=ton)
    else:
        lanaiDUT.primeStrobe2(ton=ton)

    mokuDUT.configureStrobes(ISRC,nine=nine)

    time.sleep(0.25)
    if mokuDUT.i2cread(0x0400) != 0x08:
        print("Moku NOT in idle after priming, abort!",hex(mokuDUT.i2cread(0x0400)))
        mokuDUT.interruptDump(prefix="ISRC"+str(ISRC)+"-")

    lanai_frame = startExternalStream(CAM_OPT + LR)
    stopwatch.tik()

    frame_state = lanaiDUT.i2cread(0x035F) & 0x03

    if ISRC == 1 and sec_check == 0:
        ReportDataToStationAndPDCA(CAM_OPT + LR + "_FRAME_BLANK_STATE", frame_state, "hex", 0x03, 0x03)
        if frame_state!=0x03:
            print(CAM_OPT + " frame is blank with SecureIO High! Not expected, abort! ", hex(lanaiDUT.i2cread(0x035F)))
            mokuDUT.interruptDump(prefix="ISRC"+str(ISRC)+"-")

    if ISRC == 2 and sec_check == 0:
        ReportDataToStationAndPDCA(CAM_OPT + LR + "_FRAME_BLANK_STATE", frame_state, "hex", 0x00, 0x00)
        if frame_state != 0x00:
            print(CAM_OPT + " frame is not blank with SecureIO LOW! Not expected, abort! ", hex(lanaiDUT.i2cread(0x035F)))
            mokuDUT.interruptDump(prefix="ISRC" + str(ISRC) + "-")

    # lanaiDUT.setFR(120)
    time.sleep(timeout)
    stopwatch.tok()
    stopExternalStream(CAM_OPT + LR, lanai_frame, stopwatch.runtime()/1000)

    moku_active = mokuDUT.i2cread(0x2010) & 0x100
    if sec_check == 0:
        ReportDataToStationAndPDCA("MOKU" + LR + "_" + CAM_OPT + LR + "_STROBE" + STROBE + "_ACTIVE_TRANSITION", moku_active, "hex", 0x100, 0x100)

    if  moku_active!= 0x100:
        print("Moku never goes into ACTIVE, Lanai and Moku aren't connected! ", hex(mokuDUT.i2cread(0x2010)))
        mokuDUT.interruptDump(prefix="ISRC" + str(ISRC) + "-")

def parkLEDs(LR,ISRC=1,timeout=60,nine=False,ton=5500,current=10,rule=0):
    if LR == "L":

        mokuDUT=MOKUL
        lanaiDUT=NECAML

    elif LR == "R":

        mokuDUT=MOKUR
        lanaiDUT=NECAMR

    lexReset(LR,0)
    time.sleep(0.1)
    lexReset(LR,1)
    time.sleep(0.8)

    if ISRC==1:
        sep.secureIO(LR,1)
        setLexV(LR, 2.55)

    else:
        sep.secureIO(LR,0)
        setLexV(LR, 3.1)

    #dummy read to clear the FIFO
    mokuDUT.i2cread(0x0000)

    mokuDUT.i2cwrite(0x0408,0x01) #state transition
    time.sleep(0.2)

    if mokuDUT.i2cread(0x0400) != 0x08:
        print("Moku NOT in idle, abort!",hex(mokuDUT.i2cread(0x0400)))
        mokuDUT.interruptDump(prefix="ISRC"+str(ISRC)+"-")
        return


    lanaiDUT.primeStrobe1(ton=ton)

    if ISRC == 1: #3280
        mokuDUT.configureStrobes(ISRC, nine=nine, current = current)
        mokuDUT.i2cwrite(0x0680, rule-1)


    elif ISRC ==2: #1450
        mokuDUT.configureStrobes(ISRC, nine= nine, current = current)
        mokuDUT.i2cwrite(0x0680, rule-1)
        mokuDUT.i2cwrite(0x0684, 0x080f)


    time.sleep(0.25)

    if mokuDUT.i2cread(0x0400) != 0x08:
        print("Moku NOT in idle after priming, abort!", hex(mokuDUT.i2cread(0x0400)))
        mokuDUT.interruptDump(prefix="ISRC" + str(ISRC) + "-")

    startExternalStream("NECAM"+LR)

def mokuTests(LR, station):
    if LR == "L":
        mokuDUT=MOKUL
    elif LR == "R":
        mokuDUT=MOKUR

    lexReset(LR,0)
    time.sleep(0.1)
    lexReset(LR,1)
    #dummy read to clear the FIFO
    mokuDUT.i2cread(0x0000)

    mokuDUT.I2CCheck()
    # mokuDUT.sause() # overwrites the shadow regs for unlocked only

    # lexReset(LR,0)
    # time.sleep(0.1)
    # lexReset(LR,1)

    mokuDUT.vendorATEpass_postburn()
    mokuDUT.MokuOperationMode()
    mokuDUT.MokuSiliconRev()
    mokuDUT.mokuOTPID()
    mokuDUT.BISTCheck(dump=False)
    mokuDUT.vendorIDDump()
    mokuDUT.vendorLockStateRead()
    mokuDUT.appleLockStateRead()
    mokuDUT.vendorDebugModeCheck()
    if station.lower() != "qt":
        mokuDUT.OTPDump()
    mokuDUT.internalTempRead()
    mokuDUT.externalTempRead()

if __name__=="__main__":
    parser = argparse.ArgumentParser(description='N301 Consolidated Moku and Kilauea Test')
    parser.add_argument('--side', help='Specify side to test - L for left, R for Right, LR for both', required=False, nargs='?', default='LR')
    parser.add_argument('--station', help='Specify test station - OMQT, QT, Burnin, or Debug', required=False, nargs='?', default='Burnin')
    LR, station = parser.parse_args()

    # bora=Bora()
    bora.boot()
    bora.msg.initMaster(0)
    bora.isp.powerOn()
    stopwatch = Stopwatch()

	# Dummy register read to ensure we check moku lock bit correctly
    MOKUL.i2cread(0x0000)
    MOKUR.i2cread(0x0000)


    if "L" in LR:
        mokuTests("L", station)
        kilaueaTest("L") # for kilauea connectivity
        if station.lower() != "qt":
            secureTest("L") # for secure IO connectivity

    if "R" in LR:
        mokuTests("R", station)
        kilaueaTest("R") # for kilauea connectivity
        if station.lower() != "qt":
            secureTest("R") # for secure IO connectivity

    if station.lower() == "burnin" or station.lower() =="debug":
        if "L" in LR:
            camStrobeCheck("L") # for strobe connectivity
            ADCPowerTest("NECAML")
            ADCPowerTest("BECAML")
        if "R" in LR:
            camStrobeCheck("R") # for strobe connectivity
            ADCPowerTest("NECAMR")
            ADCPowerTest("BECAMR")

    # overall CTS check
    CTSPassL=True
    CTSPassR=True
    connectivityPassL = True
    connectivityPassR = True
    for item in resultStr:
        # (Name+","+`PFstr`+","+hex(Value)+","+hex(LowerLimit)+","+hex(UpperLimit)+"\n")
        segs=item.split(",")
        if ("MOKUL" in segs[0])  and (segs[1] == "FAIL") and ("CTS" in segs[0]):
            CTSPassL=False
        if ("MOKUL" in segs[0])  and (segs[1] == "FAIL") and ("CONNECTIVITY" in segs[0]):
            connectivityPassL=False
        if ("MOKUR" in segs[0])  and (segs[1] == "FAIL") and ("CTS" in segs[0]):
            CTSPassR=False
        if ("MOKUR" in segs[0])  and (segs[1] == "FAIL") and ("CONNECTIVITY" in segs[0]):
            connectivityPassR=False

    if "L" in LR:
        ReportDataToStationAndPDCA("MOKUL_CTS_OVERALL", CTSPassL, "bool", 1, 1)
        if CTSPassL == False:
            print("Crap! Left CTS Failed")
        ReportDataToStationAndPDCA("MOKUL_CONNECTIVITY_OVERALL", connectivityPassL, "bool", 1, 1)
    if "R" in LR:
        ReportDataToStationAndPDCA("MOKUR_CTS_OVERALL", CTSPassR, "bool", 1, 1)
        if CTSPassR == False:
            print("Crap! Right CTS Failed")
        ReportDataToStationAndPDCA("MOKUR_CONNECTIVITY_OVERALL", connectivityPassR, "bool", 1, 1)

    writeResults("nandfs:/mokuResults.csv")
    diags("camisp --exit")
    # writeResults("usbfs:/mokuResults-" + station + ".csv")
