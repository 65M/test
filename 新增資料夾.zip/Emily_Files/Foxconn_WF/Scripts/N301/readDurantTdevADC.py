import sys
import math
from shell import run

'''
Laguna NTC I2C Read Sequence:
register    value   comment
write   0x7e00  value: 0x46 select TDEV channel 70, see TAS Table 12.3
read    0x7e7A      ADC_EOC_EVENT (0x01 indicates measurement complete)
read    0x7e01      MANUAL_1_RES_LSB (bit range 3:0)
read    0x7e02      MANUAL_1_RES_MSB (bit range 7:0)
'''

def ParseRegRead(CmdOutput):
    outputgrp = CmdOutput.split()
    readval = outputgrp[6]
    readval = readval[2:]
    return readval

if __name__=="__main__":

    run("device -k durant -e write_reg 1 0x7e00 0x46")
    resp = run("device -k durant -e read_reg 1 0x7e7a")
    #Get the value read and strip 0x
    val = ParseRegRead(resp)

    #If the value read is not 0x1, error out
    if (int(val) & (~0x1)):
        print ('Error: measurement not complete')
        sys.exit()

    #Get the lsb value and strip 0x
    lsbresp = run("device -k durant -e read_reg 1 0x7e01")
    lsbval = ParseRegRead(lsbresp)

    #Get the msb value and strip 0x
    msbresp = run("device -k durant -e read_reg 1 0x7e02")
    msbval = ParseRegRead(msbresp)

    #Concatenate msb (bit range 0-7) and lsb (bit range 0-3)
    adcvaldec = (int(msbval,16)<<4) | int(lsbval,16)
    adcvalhex = (hex(adcvaldec))
    print ("ADC Value: ", adcvalhex)
    tempinc = -273+1/((math.log(((adcvaldec*1.221/1000)/0.000075)/10000)/3380)+1/(273+25))
    print ("Temp in C: ", tempinc)
