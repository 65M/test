import sys

# print(sys.path)
sys.path.append("nandfs:\\AppleInternal\Diags\Logs\Smokey\Shared\SEuP")
sys.path.append("nandfs:\\AppleInternal\Diags\Python\lib")
from seup import *

import re
import math
import time ,os, datetime
import random
# from colored import back, style


class BurnableMoku(Moku):
    def __init__(self,sib):
        Moku.__init__(self,sib)

    def write_otp_i2c(self,filename=None, prefetch=1, write_abort=1):
        customer_otp = open(filename)
        otp_bytes = []
        for line in customer_otp:
            otp_bytes.append(line.strip('\n'))

        if self.i2cread(0x4804) ==  0x6c:
            print("Part is locked, skipping this!")
            return

        print("State 1 "+hex(self.i2cread(0x0400)))
        # ensure standby mode
        self.i2cwrite(0x0408, 0)
        # dummyWrite(0x0408, 0)
        print("State 2 "+hex(self.i2cread(0x0400)))
        stand = self.i2cread(0x0400)
        # ensure VDDP is in 1.78V to 1.98V
        if stand == 0x02:

            time.sleep(1)
            self.i2cwrite(0x4808, 0x01) # OTP_CTRL_IF3 (VDD_OTP_EN = 1) to enable VDD for OTP programming
            # dummyWrite(0x4808, 0x01)
            self.i2cwrite(0x4200, 0xA41A) # OTP_CTRL_0 to enable OTP write, WRITE ABORT, PREFETCH
            # dummyWrite(0x4200, 0xA41A)
            print('-------------------------- Writing OTP --------------------------')
            for byte in range(0, 163, 2):
                addr = 0x4000 + byte
                data = int(otp_bytes[byte + 1] + otp_bytes[byte], 16)
                print('{}: {} = {}'.format(byte, (hex(addr)), hex(data)))
                self.i2cwrite(addr, data)
                # dummyWrite(addr, data)
                busy = self.i2cread(0x420C)    # Wait until write is complete...
                while busy == 1:
                    time.sleep(.1)
                    busy = self.i2cread(0x420C)
                # check for errors writing OTP address
                if prefetch and write_abort:
                    if (self.i2cread(0x4208) & 0x8000) == 0x8000:
                        raise ValueError('OTP_WR_ERR: Error occurred at {} = {}'.format(
                            hex(self.i2cread(0x4208)), hex(data)))
            self.i2cwrite(0x4200, 0xA418)
            # dummyWrite(0x4200, 0xA418)#Disable OTP write mode
            self.i2cwrite(0x4808, 0x00)
            # dummyWrite(0x4808, 0x00)#Disable OTP write mode
            self.read_opt_regs()

        else:
            print('The DUT is not in standby')
            # customer_otp.close()
    def read_opt_regs(self):
        print('-------------------------- Reading OTP --------------------------')
        for byte in range(0, 163, 2):
            addr = 0x4000 + byte
            print('{}: {} = {}'.format(byte, (hex(addr)), hex(self.i2cread(addr))))
        # print()
# LR=sys.argv[1]
LR="LR" #temp hack before args are fixed

MOKUL=BurnableMoku(BoraI2Cconfig(2,2))
MOKUR=BurnableMoku(BoraI2Cconfig(5,2))

NECAML=bora.isp.NECAML
NECAMR=bora.isp.NECAMR
BECAML=bora.isp.BECAML
BECAMR=bora.isp.BECAMR

# sep=sep()

def lexReset(LR,state):

    if LR == "L":
        bora.isp.ADAMSOL.setIO(11,state)
    elif LR  == "R":
        bora.isp.ADAMSOR.setIO(11,state)
    else:
        print("Pass L/R to LR!")
        sys.exit(1)
    #implement with seup
def setLexV(LR,voltage):
    if LR == "L":
        bora.isp.LEXL.setV(voltage)
    elif LR  == "R":
        bora.isp.LEXR.setV(voltage)
    else:
        print("Pass L/R to LR!")
        sys.exit(1)



def kilaueaTest(LR):# for LEFT
    if LR == "L":
        mokuDUT=MOKUL
        lanaiDUT=NECAML
    elif LR == "R":
        mokuDUT=MOKUR
        lanaiDUT=NECAMR

    strobeLEDs(LR,1,timeout=5)
    state=mokuDUT.i2cread(0x0400)
    ReportDataToStationAndPDCA("KILAUEA"+LR+"_CC_CHECK_STATE_SOURCE1",state,"hex",0x08,0x08)
    if state!=0x08: # Should be 0x08 for idle
        print("BIST exit state is not idle, BAD!")
        mokuDUT.interruptDump(prefix="ISRC1-")

	# Modified to verify Source 1 and Source 2 independeintly
    time.sleep(1)
    # toggle Secure IO

    sep.secureIO("L",0)
    sep.secureIO("R",0)

    strobeLEDs(LR,2,timeout=5)
    state=mokuDUT.i2cread(0x0400)
    ReportDataToStationAndPDCA("KILAUEA"+LR+"_CC_CHECK_STATE_SOURCE2",state,"hex",0x08,0x08)
    if state!=0x08:
        # Should be 0x08 for idle
        print("BIST exit state is not idle, BAD!")
        mokuDUT.interruptDump(prefix="ISRC2-")

    sep.secureIO("L",1)
    sep.secureIO("R",1)



def danceTest(LR):
    if LR == "L":
        mokuDUT=MOKUL
        lanaiDUT=NECAML
    elif LR == "R":
        mokuDUT=MOKUR
        lanaiDUT=NECAMR
    # ISPShell("RMCOPEN")
    # ISPShell("RMCSENDCOMMAND SensorFrameRateSet 2 768")
    # mokuDUT.sause() # only on unlocked units
    # mokuDUT.compliancePatch() # only on config2 unlocked
    lexReset(LR,0)
    time.sleep(0.1)
    lexReset(LR,1)
    time.sleep(0.8)
    setLexV(LR,2.7)
    #dummy read to clear the FIFO
    mokuDUT.i2cread(0x0000)
    mokuDUT.i2cwrite(0x0408,0x01) #state transition
    time.sleep(0.1)
    if mokuDUT.i2cread(0x0400) != 0x08:
        print("Moku NOT in idle, abort!",hex(mokuDUT.i2cread(0x0400)))
        return
    lanaiDUT.primeStrobe()
    mokuDUT.configureStrobes(1,nine=True)
    time.sleep(0.25)
    if mokuDUT.i2cread(0x0400) != 0x08:
        print("Moku NOT in idle after priming, abort!",hex(mokuDUT.i2cread(0x0400)))
    lanaiDUT.startStreaming()

    for i in range(20):
        for j in range(1,9):
            mokuDUT.setISNK(j,random.randint(0,100))
        time.sleep(0.5)

    mokuDUT.configureStrobes(2,nine=True)
    for i in range(20):
        for j in range(1,9):
            mokuDUT.setISNK(j,random.randint(0,100))
        time.sleep(0.5)
    lanaiDUT.stopStreaming()

def mokuBurnOTP(LR):
    if LR == "L":
        mokuDUT=MOKUL
        lanaiDUT=NECAML
    elif LR == "R":
        mokuDUT=MOKUR
        lanaiDUT=NECAMR

    path=sys.argv[1]
    if ".hex" not in path:
        print("No Hex file provided, abort!")
        return

    mokuDUT.OTPDump(prefix="PREBURN-")
    lexReset(LR,0)
    time.sleep(0.1)
    lexReset(LR,1)
    time.sleep(0.8)

    #dummy read to clear the FIFO
    mokuDUT.i2cread(0x0000)

    if mokuDUT.i2cread(0x0400) != 0x02:
        print("Moku NOT in STANDBY, abort!",hex(mokuDUT.i2cread(0x0400)))
        mokuDUT.interruptDump(prefix="ISRC-")
        sys.exit(1)


    setLexV(LR,1.88)
    setLexV(LR,1.88)
    setLexV(LR,1.88)
    mokuDUT.write_otp_i2c(path)

    lexReset(LR,0)
    time.sleep(0.1)
    lexReset(LR,1)
    time.sleep(0.8)
    #dummy read to clear the FIFO
    mokuDUT.i2cread(0x0000)

    # mokuDUT.BISTCheck(prefix="POSTBURN-")
    mokuDUT.OTPDump(prefix="POSTBURN-")



def strobeLEDs(LR,ISRC,timeout=60,nine=False,ton=5500):
    if LR == "L":
        mokuDUT=MOKUL
        lanaiDUT=NECAML
    elif LR == "R":
        mokuDUT=MOKUR
        lanaiDUT=NECAMR

    # ISPShell("RMCOPEN")
    # ISPShell("RMCSENDCOMMAND SensorFrameRateSet 2 568")
    # mokuDUT.sause() # only on unlocked units
    # mokuDUT.compliancePatch() # only on config2 unlocked
    lexReset(LR,0)
    time.sleep(0.1)
    lexReset(LR,1)
    time.sleep(0.8)
    setLexV(LR,2.6)
    #dummy read to clear the FIFO

    mokuDUT.i2cread(0x0000)

    mokuDUT.specialSause()

    mokuDUT.i2cwrite(0x0408,0x01) #state transition
    time.sleep(0.2)
    if mokuDUT.i2cread(0x0400) != 0x08:
        print("Moku NOT in idle, abort!",hex(mokuDUT.i2cread(0x0400)))
        mokuDUT.interruptDump(prefix="ISRC"+str(ISRC)+"-")
        return
    lanaiDUT.primeStrobe(ton=ton)
    mokuDUT.configureStrobes(ISRC,nine=nine)

    time.sleep(0.25)
    if mokuDUT.i2cread(0x0400) != 0x08:
        print("Moku NOT in idle after priming, abort!",hex(mokuDUT.i2cread(0x0400)))
        mokuDUT.interruptDump(prefix="ISRC"+str(ISRC)+"-")

#    mokuDUT.interruptDump(prefix="TEST-ISRC"+str(ISRC)+"-")
    lanaiDUT.startStreaming()
    # lanaiDUT.setFR(120)
    time.sleep(timeout)
    lanaiDUT.stopStreaming()
#    mokuDUT.interruptDump(prefix="TEST2-ISRC"+str(ISRC)+"-")
#    mokuDUT.interruptDump(prefix="ISRC"+str(ISRC)+"-")
    # camConnTest()
    # camStreamTest()

def parkLEDs(LR,ISRC,timeout=60,nine=False,ton=5500):
    if LR == "L":
        mokuDUT=MOKUL
        lanaiDUT=NECAML
    elif LR == "R":
        mokuDUT=MOKUR
        lanaiDUT=NECAMR

    # ISPShell("RMCOPEN")
    # ISPShell("RMCSENDCOMMAND SensorFrameRateSet 2 568")
    # mokuDUT.sause() # only on unlocked units
    # mokuDUT.compliancePatch() # only on config2 unlocked
    lexReset(LR,0)
    time.sleep(0.1)
    lexReset(LR,1)
    time.sleep(0.8)
    setLexV(LR,2.6)

    if ISRC==1:
        sep.secureIO(LR,1)
    else:
        sep.secureIO(LR,0)

    #dummy read to clear the FIFO

    mokuDUT.i2cread(0x0000)
    mokuDUT.specialSause()

    mokuDUT.i2cwrite(0x0408,0x01) #state transition
    time.sleep(0.2)
    if mokuDUT.i2cread(0x0400) != 0x08:
        print("Moku NOT in idle, abort!",hex(mokuDUT.i2cread(0x0400)))
        mokuDUT.interruptDump(prefix="ISRC"+str(ISRC)+"-")
        return
    lanaiDUT.primeStrobe(ton=ton)
    mokuDUT.configureStrobes(ISRC,nine=nine)

    time.sleep(0.25)
    if mokuDUT.i2cread(0x0400) != 0x08:
        print("Moku NOT in idle after priming, abort!",hex(mokuDUT.i2cread(0x0400)))
        mokuDUT.interruptDump(prefix="ISRC"+str(ISRC)+"-")

#    mokuDUT.interruptDump(prefix="TEST-ISRC"+str(ISRC)+"-")
    lanaiDUT.startStreaming()
    # lanaiDUT.setFR(120)



if __name__=="__main__":
    bora.boot()
    bora.isp.powerOn()
    if MOKUL.i2cread(0x4804) !=  0x6c:
        print("MokuL is NOT locked, burning!")
        si_rev = MOKUL.i2cread(0x0004)
        dat = MOKUL.i2cread(0x409C)
        MOKUL.vendorATEpass_preburn()
        if (si_rev == 0xB0 or 0xB1) and (dat != 0x6D):  # 0x6D locked state
            print("Moku silicon Failed Vendor ATE test! Do not use this Moku!!!")
        else:
            mokuBurnOTP("L")
    else:
        print("MokuL is locked, not burning!")
    if MOKUR.i2cread(0x4804) !=  0x6c:
        print("MokuR is NOT locked, burning!")
        si_rev = MOKUR.i2cread(0x0004)
        dat = MOKUR.i2cread(0x409C)
        MOKUR.vendorATEpass_preburn()
        if (si_rev == 0xB0) and (dat != 0x6D):  # 0x6D locked state
            print("Failed Vendor ATE test! Do not use this Moku!!!")
        else:
            mokuBurnOTP("R")
    else:
        print("MokuR is locked, not burning!")
