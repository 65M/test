consolerouter --add --src *.{error,warn,print},system.debug.debug --dest file --quiet
filelog --on \AppleInternal\Diags\Logs\N301\Sochot0Log.txt
temperature --all
rtc --get
filelog --off
