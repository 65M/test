import sys

# print(sys.path)
sys.path.append("nandfs:\\AppleInternal\Diags\Logs\Smokey\Shared\SEuP")
sys.path.append("nandfs:\\AppleInternal\Diags\Python\lib")
from seup import *
from cameraTests import secureFuseTest

CAMERAFUSETEST_VER = "2022-11-29-01"
print("cameraFuseTest Version: "+CAMERAFUSETEST_VER)

OAHU_LANAI_CAMERAS=[
"NECAML",
"NECAMR",
"DCAML",
"DCAMR",
"BECAML",
"BECAMR",
"SCAML",
"SCAMR",
"JCAML",
"JCAMR",
]

if __name__ == '__main__':
    bora.boot()
    bora.msg.initMaster(0)
    bora.isp.powerOn()
    secureFuseTest(OAHU_LANAI_CAMERAS)
