import sys

# print(sys.path)
sys.path.append("nandfs:\\AppleInternal\Diags\Logs\Smokey\Shared\SEuP")
sys.path.append("nandfs:\\AppleInternal\Diags\Python\lib")
from seup import *

import re
import math
import time ,os, datetime
import random
import argparse

CAMERATESTS_VER = "2022-12-14-01"
print("cameraTests Version: "+CAMERATESTS_VER)

ALLOWED_CAMS=[
"MCAML",
"MCAMR",
"NECAML",
"NECAMR",
"DCAML",
"DCAMR",
"BECAML",
"BECAMR",
"SCAML",
"SCAMR",
"JCAML",
"JCAMR",
# "XCAM", # handled in jasperTest.py
"PCAM",
]
ALLOWED_OPTICAL_BLACK_TEST=[
"NECAML",
"NECAMR",
"DCAML",
"DCAMR",
"BECAML",
"BECAMR",
"SCAML",
"SCAMR",
"JCAML",
"JCAMR",
]
OBJECT_MAP={
"MCAML":bora.isp.MCAML,
"MCAMR":bora.isp.MCAMR,
"NECAML":bora.isp.NECAML,
"NECAMR":bora.isp.NECAMR,
"DCAML":bora.isp.DCAML,
"DCAMR":bora.isp.DCAMR,
"BECAML":bora.isp.BECAML,
"BECAMR":bora.isp.BECAMR,
"SCAML":bora.isp.SCAML,
"SCAMR":bora.isp.SCAMR,
"JCAML":bora.isp.JCAML,
"JCAMR":bora.isp.JCAMR,
"XCAM":bora.isp.XCAM,
"PCAM":bora.isp.PCAM}

MSG_FRAME_SKIP =   {"MCAML": 0,
                    "MCAMR": 0,
                    "NECAML": 0,
                    "NECAMR": 0,
                    "DCAML": 2,
                    "DCAMR": 2,
                    "BECAML": 0,
                    "BECAMR": 0,
                    "SCAML": 2,
                    "SCAMR": 2,
                    "JCAML": 2,
                    "JCAMR": 2,
                    "XCAM": 44,
                    "PCAM": 8}


def parseCameraArg(inStr):
    if inStr is None:
        return ALLOWED_CAMS
    if "ALL" in inStr.upper():
        return ALLOWED_CAMS
    chunks=[]
    if "," in inStr:
        chunks=inStr.split(",")
    else:
        chunks=[inStr]

    for chunk in chunks:
        if chunk.upper() not in ALLOWED_CAMS:
            raise KeyError("You entered a illegal camera name, use one of "+str(ALLOWED_CAMS))
    return chunks
def compensateOverflow(init,t1):
    if t1<init:
        t1+=0xff
    return t1 - init

def internalStream(target):
    cameraDUT=OBJECT_MAP[target]
    # internal sync mode streaming
    cameraDUT.externalSyncMode(False)
    initRxCnt=bora.rxFrameCounter(cameraDUT.channel)
    # initTxCnt=cameraDUT.getFrameCounter()
    cameraDUT.startStreaming()
    time.sleep(0.5)
    cameraDUT.stopStreaming()
    t1RxCnt=bora.rxFrameCounter(cameraDUT.channel)
    # t1TxCnt=cameraDUT.getFrameCounter()
    # doe(cameraDUT.channel)
    delta=compensateOverflow(initRxCnt,t1RxCnt)
    # print(initRxCnt,t1RxCnt)
    print(delta,"Frames received during sync internal mode")
    ReportDataToStationAndPDCA(target+"_STREAM_INT_SYNC",delta,"frames",1,None)


def externalStream(target):
    cameraDUT=OBJECT_MAP[target]
    # external sync mode streaming
    cameraDUT.externalSyncMode(True)
    initRxCnt=bora.rxFrameCounter(cameraDUT.channel)
    # initTxCnt=cameraDUT.getFrameCounter()
    cameraDUT.startStreaming()
    time.sleep(0.5)
    cameraDUT.stopStreaming()
    t1RxCnt=bora.rxFrameCounter(cameraDUT.channel)
    # t1TxCnt=cameraDUT.getFrameCounter()

    delta=compensateOverflow(initRxCnt,t1RxCnt)
    print(delta,"Frames received during sync external mode")
    ReportDataToStationAndPDCA(target+"_STREAM_EXT_SYNC",delta,"frames",1,None)
    cameraDUT.externalSyncMode(False)

def startExternalStream(target):
    cameraDUT=OBJECT_MAP[target]
    if target.startswith("MCAM"):
        bora.msg.configChannel(bora.msg.MAP["MCAML"],0,frame_skip=MSG_FRAME_SKIP[target])
        bora.msg.configChannel(bora.msg.MAP["MCAMR"],0,frame_skip=MSG_FRAME_SKIP[target])
    else:
        bora.msg.configChannel(bora.msg.MAP[target],0,frame_skip=MSG_FRAME_SKIP[target])
    # external sync mode streaming
    cameraDUT.externalSyncMode(True)
    initRxCnt=bora.rxFrameCounter(cameraDUT.channel)
    cameraDUT.startStreaming()
    return initRxCnt

def stopExternalStream(target, initRxCnt=None, streamTime=None):
    cameraDUT=OBJECT_MAP[target]
    cameraDUT.stopStreaming()
    t1RxCnt=bora.rxFrameCounter(cameraDUT.channel)
    minFrames = 1
    if streamTime:
        # streamTime in seconds
        print("Streamed {} for {} seconds".format(target, streamTime))
        minFrames = math.floor(streamTime * (90/(MSG_FRAME_SKIP[target]+1)) * 0.8)
    if initRxCnt is not None:
        delta=compensateOverflow(initRxCnt,t1RxCnt)
        print(delta,"Frames received during sync external mode")
        ReportDataToStationAndPDCA(target+"_STREAM_EXT_SYNC",delta,"frames",minFrames,None)
    cameraDUT.externalSyncMode(False)

def ADCPowerTest(target):
    pixels_1x = 0
    pixels_8x = 0
    cameraDUT=OBJECT_MAP[target]
    cameraDUT.setExposure()
    cameraDUT.setBlackLevelGain(1)
    cameraDUT.startStreaming()
    pixels_1x = cameraDUT.opticalBlackRegDump(target+"_GAIN_1")
    ReportDataToStationAndPDCA(target+"_OPTICAL_BLACK_TEST_PIXELS_1X",pixels_1x,"Value",1,None)

    cameraDUT.setBlackLevelGain(8)
    pixels_8x = cameraDUT.opticalBlackRegDump(target+"_GAIN_8")
    ReportDataToStationAndPDCA(target+"_OPTICAL_BLACK_TEST_PIXELS_8X",pixels_8x,"Value",1,None)

    cameraDUT.stopStreaming()

def secureFuseTest(cameras=None):
    if not cameras:
        cameras = ALLOWED_OPTICAL_BLACK_TEST
    fusings = {c:OBJECT_MAP[c].getFusing() for c in cameras}
    print("Oahu and Lanai Secure Fusings:")
    for c,f in fusings.items():
        print("{}:\t{}".format(c, f))

    fuse_type = "MIXED"
    all_same_fuse = False
    if all(f=="PROD" for f in fusings.values()):
        fuse_type = "PROD"
        all_same_fuse = True
    elif all(f=="DEV" for f in fusings.values()):
        fuse_type = "DEV"
        all_same_fuse = True

    # all_same_fuse = all(f==next(iter(fusings.values())) for f in fusings.values())
    ReportDataToStationAndPDCA("OAHU_LANAI_FUSING",all_same_fuse,"bool",True,True)
    ReportDataToStationAndPDCA("OAHU_LANAI_FUSING_TYPE",fuse_type,None,None,None)


if __name__=="__main__":
    parser = argparse.ArgumentParser(description='N301 Consolidated Camera Test')
    parser.add_argument('-c','--camera', help='Specify camera to test, use comma to separate, use ALL for all cams', required=False, nargs='?', default='ALL')
    parser.add_argument('-s','--station', help='Specify test station - QT, Burnin, or Debug', required=False, nargs='?', default='Burnin')
    parser.add_argument('--skipNVM', required=False, action='store_true')
    args = parser.parse_args()
    targets=parseCameraArg(args.camera)

    bora.boot()
    bora.msg.initMaster(0)
    bora.isp.powerOn()
    stopwatch = Stopwatch()
    # for cam in ALLOWED_CAMS:
    #     bora.msg.configChannel(bora.msg.MAP[cam],0)
    diags('camisp --method projector en 3')
    diags('camisp --method projector en 4')
    diags('camisp --method projector en 8')

    for target in targets:
        prev_results = resultStr.copy()
        if not args.skipNVM:
            if target not in ["XCAM"]:
                # OBJECT_MAP[target].nvmDump()
                OBJECT_MAP[target].nvmIntegrityTest(target)

        target_frames = startExternalStream(target)
        stopwatch.tik()
        time.sleep(0.5)
        stopwatch.tok()
        stopExternalStream(target, target_frames, stopwatch.runtime()/1000)

        if args.station.upper() != "QT" and target in ALLOWED_OPTICAL_BLACK_TEST:
            ADCPowerTest(target)

        target_results = [r for r in resultStr if r not in prev_results]
        failures, overall = getOverallResults(results=target_results)
        test_name = "CameraTests_{}".format(target)
        if not overall:
            print("{} Failures:".format(test_name), failures)
        ReportDataToStationAndPDCA("{}_OVERALL".format(test_name.upper()), overall, "bool", True, True)

    writeResults("nandfs:/camResults.csv")
    diags("camisp --exit")
    #writeResults("usbfs:/camResults-" + station + ".csv")
