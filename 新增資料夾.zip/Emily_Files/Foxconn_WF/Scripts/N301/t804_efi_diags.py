#================================================================================================================================================
# N301 P1 T804 - MAGNETIC TRACKING SUB-SYSTEM
# EFI DIAGS SYSTEM CHECK FOR N301 P1 MAG-TRACK SUB-SYSTEM
# AUTHOR: PETER TWISS (PTWISS@APPLE.COM)
# DATE: 01/06/2021
# REVISION: 0.8
# MCU FW IMAGE THIS EFI DIAGS SCRIPT COMMUNICATES WITH:    rdar://68284896
# SPEC FOR MCU FW THIS EFI DIAGS SCRIPT COMMUNICATES WITH: rdar://68853621
# MICRO-PYTHON vs. PYTHON: http://docs.micropython.org/en/latest/genrst/index.html
#================================================================================================================================================


#================================================================================================================================================
# EFI DIAGS NOTES:
#================================================================================================================================================
#----------------------------------
# GPIO ID#'s: See RADAR #64904614
#----------------------------------
#   - GPIO_AP_TO_MAG_MCU_RST_L:         45
#   - GPIO_AP_TO_MAG_MCU_BOOT:          107
#   - GPIO_AP_FROM_MAG_MCU_IRQ:         44
#   - GPIO_AP_FROM_MAG_MCU_TIMESYNC:    104
#   - SPI: SPI3, MODE 3, 1MHz


#================================================================================================================================================
# FUNCTION: USED LIBRARIES
#================================================================================================================================================
import sys
import logging
import os
import time
from shell import run
from time import sleep


#================================================================================================================================================
# REGISTER DEFINITIONS: DEFINITION IS FROM 7804 VALIDATION FW SPEC (rdar://68853621)
#================================================================================================================================================
REG_EM_ADDR__DEVICE_ID                      = '0x00'
REG_EM_ADDR__FW_VERSION                     = '0x04'
REG_EM_ADDR__FW_BUILD_NUM                   = '0x08'
REG_EM_ADDR__STATUS                         = '0x0C'
REG_EM_ADDR__HOST_IRQ_CONTROL               = '0x10'
REG_EM_ADDR__CARRIER_PWM_CONTROL_0          = '0x14'
REG_EM_ADDR__CARRIER_PWM_CONTROL_1          = '0x18'
REG_EM_ADDR__POWER_PWM_CONTROL_0            = '0x1C'
REG_EM_ADDR__POWER_PWM_CONTROL_1            = '0x20'
REG_EM_ADDR__BB_CONTROL_0                   = '0x24'
REG_EM_ADDR__BB_STATUS_0                    = '0x28'
REG_EM_ADDR__CARRIER_PWM_HI_TIME            = '0x2C'
REG_EM_ADDR__CARRIER_PWM_LO_TIME            = '0x30'
REG_EM_ADDR__POWER_PWM_HI_TIME              = '0x34'
REG_EM_ADDR__POWER_PWM_LO_TIME              = '0x38'
REG_EM_ADDR__CAPBANK_CONTROL_0              = '0x3C'
REG_EM_ADDR__TIMESYNC_HI_TIMESTAMP          = '0x40'
REG_EM_ADDR__TIMESYNC_LO_TIMESTAMP          = '0x44'
REG_EM_ADDR__CS_HI_TIMESTAMP                = '0x48'
REG_EM_ADDR__CS_LO_TIMESTAMP                = '0x4C'
REG_EM_ADDR__POWER_PWM_RISE_HI_TIMESTAMP    = '0x50'
REG_EM_ADDR__POWER_PWM_RISE_LO_TIMESTAMP    = '0x54'
REG_EM_ADDR__BB_ADC_CONTROL_0               = '0x58'
REG_EM_ADDR__BB_ADC_CONTROL_1               = '0x5C'
REG_EM_ADDR__BB_ADC_FIFO                    = '0x60'
REG_EM_ADDR__OUTPUT_ADC_CONTROL_0           = '0x64'
REG_EM_ADDR__OUTPUT_ADC_CONTROL_1           = '0x68'
REG_EM_ADDR__OUTPUT_ADC_FIFO                = '0x6C'
REG_EM_ADDR__DEBUG_MEM_ADDRESS              = '0x70'
REG_EM_ADDR__DEBUG_MEM_VALUE                = '0x74'
REG_EM_ADDR__OPAMP_CONTROL                  = '0x78'
REG_EM_ADDR__HBRIDGE_CONTROL                = '0x7C'


#================================================================================================================================================
# OTHER SYSTEM CONSTANTS
#================================================================================================================================================
CONST_FW_VERSION                            = 3
CONST_MCU_PERIPERAL_CLK                     = 32000000   # 32MHz
CONST_COIL_DRIVE_PWM_DC                     = 0.5        # ASSUME A 50% DUTY-CYCLE FOR NOW
CONST_BB_DEFAULT_VOUT                       = 0x00       # BUCK-BOOST DEFAULT VREF REG SETTING: ~4.5V
CONST_ADC_FIFO_SIZE                         = 256
CONST_ADC_FIFO_REG_WIDTH                    = 2
CONST_ADC_FIFO_RD_SIZE                      = int(CONST_ADC_FIFO_SIZE / CONST_ADC_FIFO_REG_WIDTH)
CONST_SPI_RD_DEBUG_EN                       = 1
CONST_SPI_RD_DEBUG_DIS                      = 0
CONST_TIMESYNC_CNTR_100msec                 = CONST_MCU_PERIPERAL_CLK * 0.1
CONST_BUCK_BOOST_DEFAULT_VOUT               = 7      # VOLTS
CONST_RES_FREQ_LO                           = 38500  # Hz
CONST_RES_CAPBANK_LO_CONFIG                 = 7
CONST_COIL_ADC_FB_TYPICAL_AMPLITUDE         = 850.0    # 850dn IS TYPICAL, LESS BY 10%, MIGHT HAVE ISSUE
CONST_COIL_ADC_FB_TYPICAL_MEAN              = 2000.0   # DC VALUE SHOULD BE SPOT ON DUE TO BIAS RESISTORS, 10% OK HERE TOO



""" UNUSED FOR NOW:
CONST_STATUS_BIT_CAR_PWM_EN                 = 0
CONST_STATUS_BIT_PWR_PWM_EN                 = 1
CONST_STATUS_BIT_BB_EN                      = 2
CONST_STATUS_BIT_HSE_ERROR                  = 3
CONST_STATUS_BIT_EE_ERROR                   = 4
CONST_STATUS_BIT_ADC_IDLE                   = 5
"""


#================================================================================================================================================
# FUNCTION: TIME DELAYS (usec)
#================================================================================================================================================
def t804_make_terminal_space():
    for i in range(10):
        print(' ')
    return


#================================================================================================================================================
# FUNCTION: TIME DELAYS (usec)
#================================================================================================================================================
def t804_delay_usec(delay):
    cmd = 'stall ' + str(delay)
    run(cmd,True)
    return


#================================================================================================================================================
# FUNCTION: GET BOARD ID
#================================================================================================================================================
def t804_get_board_id(print_en):
    cmd = 'boardid'
    resp = run(cmd,True)
    a = resp.split()
    for i in range(len(a)):
        if(a[i][0:2] == '0x'):
            if(a[i] == '0x47'):
                if(print_en == True):
                    print("INFO: BOARD TYPE = DEV")
                return 'DEV'
            else:
                if(print_en == True):
                    print("INFO: BOARD TYPE = HMD")
                return 'HMD'
    print("INFO: BOARD ID READ FAIL")
    return 'FAIL'


#================================================================================================================================================
# FUNCTION: SETTING T804 MCU BOOT PIN
#================================================================================================================================================
def t804_set_boot_pin(pin_state, print_en):
    if(pin_state > 0):
        resp = run('socgpio --port 0 --pin 107 --output 1',True)
        if(print_en == True):
            print('INFO: BOOT PIN SET TO 1: SPI SLAVE BOOT')
    else:
        resp = run('socgpio --port 0 --pin 107 --output 0',True)
        if(print_en == True):
            print('INFO: BOOT PIN SET TO 0: FLASH BOOT')
    t804_delay_usec(10000)
    return


#================================================================================================================================================
# FUNCTION: SETTING T804 MCU BOOT PIN
#================================================================================================================================================
def t804_set_nRst_pin(pin_state):
    if(pin_state > 0):
        resp = run('socgpio --port 0 --pin 45 --output 1',True)
    else:
        resp = run('socgpio --port 0 --pin 45 --output 0',True)
    return


#================================================================================================================================================
# FUNCTION: SETTING T804 MCU BOOT PIN
#================================================================================================================================================
def t804_mcu_rst(print_en):
    t804_set_nRst_pin(1)            # INITIAL CONDITION
    t804_delay_usec(1000)           # HOLD UC STATE FOR A BIT
    t804_set_nRst_pin(0)            # RESETTING MCU
    t804_delay_usec(10000)          # HOLD RESET FOR 10msec
    t804_set_nRst_pin(1)            # RELEASEING MCU RESET
    t804_delay_usec(200000)         # WAIT FOR MCU BOOT (~100msec IS PLENTY)
    if(print_en == True):
        print("INFO: T804 MCU RESET")   # NOTUFY CONSOLE OF RESET
    return


#================================================================================================================================================
# FUNCTION: INIT T804 MCU
#================================================================================================================================================
def t804_mcu_init():
    t804_set_boot_pin(0,False)            # MAKE SURE WE ARE NOT BOOTING FROM SPI
    t804_mcu_rst(False)                  # RESET MCU
    return


#================================================================================================================================================
# FUNCTION: SPI READ
# [INPUT] <string> Addr
# [OUTPUT] NONE
#================================================================================================================================================
def t804_test_spi_read_reg(debug_en, str_hex_addr):
    cmd = 'spi -b 1000000 -m 3 -t 3 64 0x01 ' + str_hex_addr + ' 0x00 0x00 0x00'
    if(debug_en == 0):
        out = run(cmd,True)
    else:
        out = run(cmd)
    t804_delay_usec(1000)
    return out


#================================================================================================================================================
# FUNCTION: SETTING T804 MCU BOOT PIN
#================================================================================================================================================
def t804_test_spi_write_reg(str_hex_addr, str_hex_value):
    dummy_bytes = ''
    dummy_byte = '0x00 '
    for i in range(55):
        dummy_bytes += dummy_byte
    cmd = 'spi -b 1000000 -m 3 -t 3 64 0x11 ' + str_hex_addr +  ' 0x00 0x00 0x00 ' + dummy_bytes + str_hex_value
    out = run(cmd,True)
    #out = run(cmd)
    t804_delay_usec(10000)
    return


#================================================================================================================================================
# CHECK FW VERSION
#================================================================================================================================================
def t804_check_fw_version(print_en):
    spi_read_good = False
    fw_version = 0
    resp = t804_test_spi_read_reg(CONST_SPI_RD_DEBUG_DIS, REG_EM_ADDR__FW_VERSION)
    #print(resp)
    a = resp.split()
    for i in range(len(a) - 4):
        if(a[i] == '0xA5'):
            spi_read_good = True       # USING PAD BYTE 0xA5 TO DETERMINE IF SPI TRANSACTION WAS SUCCESSFUL OR NOT
            fw_version = int(a[i+1],16)
            break
    if(print_en == True):
        if(fw_version == CONST_FW_VERSION):
            print('INFO: FW VERSION:',fw_version,'    - PASS')
        else:
            print('INFO: FW VERSION:',fw_version,'    - FAIL, SHOULD BE REV3')
    return spi_read_good, fw_version


#===============================================================================================================================================
# FUNCTION: T804 BUCK/BOOST STATUS
#===============================================================================================================================================
def t804_get_sys_status():
    reg_status = 0
    resp = t804_test_spi_read_reg(CONST_SPI_RD_DEBUG_DIS, REG_EM_ADDR__STATUS)
    a = resp.split()
    #print(a)
    L = len(a)
    fault = 1
    for i in range(L - 4):
        if(a[i] == '0xA5'):
            fault = 0
            reg_status = int(a[i+1],16)
            break;
    if(fault == 1):
        print('SPI FAILURE - LINE 244')
        sys.exit()
    status_car_pwm_en   = (reg_status >> 0) & 0x01
    status_pwr_pwm_en   = (reg_status >> 1) & 0x01
    status_bb_en        = (reg_status >> 2) & 0x01
    status_hse_error    = (reg_status >> 3) & 0x01
    status_bb_error     = (reg_status >> 4) & 0x01
    status_adc_hw_idle  = (reg_status >> 5) & 0x01
    return status_car_pwm_en, status_pwr_pwm_en, status_bb_en, status_hse_error, status_bb_error, status_adc_hw_idle


#===============================================================================================================================================
# FUNCTION: TEST TO VERIFY IF MCU RESET OPERATES
#===============================================================================================================================================
def t804_check_mcu_reset():
    CONST_IRQ_CTRL_TEST_VALUE = '0x34'
    test_reg_before_write = '0xDD'
    test_reg_after_write = '0xEE'
    test_reg_after_reset = '0xEE'

    # RESET MCU:
    t804_mcu_rst(False)

    # READ A RANDOM READ-WRITE REGISTER, IN THIS CASE, I CHOSE IRQ_CTRL:
    resp = t804_test_spi_read_reg(CONST_SPI_RD_DEBUG_DIS, REG_EM_ADDR__HOST_IRQ_CONTROL)
    a = resp.split()
    for i in range(len(a) - 4):
        if(a[i] == '0xA5'):
            test_reg_before_write = a[i+1]
            break

    # WRITE A VALUR INTO REGISTER:
    t804_test_spi_write_reg(REG_EM_ADDR__HOST_IRQ_CONTROL, CONST_IRQ_CTRL_TEST_VALUE)

    # RE-READ REGISTER TO VERIFY IT HAS CHANGED:
    resp = t804_test_spi_read_reg(CONST_SPI_RD_DEBUG_DIS, REG_EM_ADDR__HOST_IRQ_CONTROL)
    a = resp.split()
    for i in range(len(a) - 4):
        if(a[i] == '0xA5'):
            test_reg_after_write = a[i+1]
            break;

    # RESET MCU (AGAIN):
    t804_mcu_rst(False)

    # READ POST-RESET VALUE AGAIN:
    resp = t804_test_spi_read_reg(CONST_SPI_RD_DEBUG_DIS, REG_EM_ADDR__HOST_IRQ_CONTROL)
    a = resp.split()
    for i in range(len(a) - 4):
        if(a[i] == '0xA5'):
            test_reg_after_reset = a[i+1]
            break

    # COMPARE RESULTS:
    if((test_reg_before_write == test_reg_after_reset) and (test_reg_before_write != test_reg_after_write) and (test_reg_before_write != CONST_IRQ_CTRL_TEST_VALUE)):
        print('INFO: MCU HW RESET TEST - PASS')
    else:
        print('INFO: MCU HW RESET TEST - FAIL')
    return


#===============================================================================================================================================
# FUNCTION: TEST TO VERIFY MCU BOOT PIN OPERATES
#===============================================================================================================================================
def t804_check_mcu_boot():

    # CHECK AN SPI COMMAND WITH BOOT HIGH (SHOULD WORK):
    t804_set_boot_pin(0,False)
    t804_mcu_rst(False)
    spi_ok_boot_lo, fw_version_boot_lo  = t804_check_fw_version(False)

    # CHECK AN SPI COMMAND WITH BOOT HIGH (SHOULDN'T WORK)
    t804_set_boot_pin(1,False)
    t804_mcu_rst(False)
    spi_ok_boot_hi, fw_version_boot_hi  = t804_check_fw_version(False)

    # RESET SYSTEM BACK TO FLASH OPERATION AS DEFAULT:
    t804_set_boot_pin(0,False)
    t804_mcu_rst(False)

    # COMPARE RESULTS:
    if(spi_ok_boot_lo == True and spi_ok_boot_hi == False):
        print('INFO: MCU BOOT TEST     - PASS')
    else:
        print('INFO: MCU BOOT TEST     - FAIL')
    return


#===============================================================================================================================================
# FUNCTION: SET TIMSYNC PIN
#===============================================================================================================================================
def t804_set_timesync_pin(pin_state):
    if(pin_state > 0):
        resp = run('socgpio --port 0 --pin 104 --output 1',True)
    else:
        resp = run('socgpio --port 0 --pin 104 --output 0',True)
    return


#===============================================================================================================================================
# FUNCTION: READ TINESYNC TIMESTAMP
#===============================================================================================================================================
def t804_get_timesync_ts():
    # READ TIMESYNC TIME LO REGISTER:
    resp = t804_test_spi_read_reg(CONST_SPI_RD_DEBUG_DIS, REG_EM_ADDR__TIMESYNC_LO_TIMESTAMP)
    a = resp.split()
    #print(a)
    for i in range(len(a) - 4):
        if(a[i] == '0xA5'):
            ts_b0 = int(a[i+1],16)
            ts_b1 = int(a[i+2],16)
            ts_b2 = int(a[i+3],16)
            ts_b3 = int(a[i+4],16)
            break
    ts = (ts_b3 * 16777216) + (ts_b2 * 65536) + (ts_b1 * 256) + ts_b0
    return ts


#===============================================================================================================================================
# FUNCTION:
#===============================================================================================================================================
def t804_check_connection_timesync():

    # SET TIMESYNC HI:
    t804_set_timesync_pin(1)

    # RESET MCU -> RESETS TIMESYNC COUNTER:
    t804_mcu_rst(True)

    # READ TIMESYNC TIME REGISTER: EXPECTED TO BE 0
    ts0 = t804_get_timesync_ts()

    # SET TIMESYNC LO: NEG-EDGE STATS COUNTER
    t804_set_timesync_pin(0)

    # WAIT FOR 100msec:
    t804_delay_usec(101000)

    # READ TIMESYNC TIMESTAMP AGAIN:
    ts1 = t804_get_timesync_ts()

    # SET TIMESYNC HI FOR DEFAULT POSITION:
    t804_set_timesync_pin(1)

    # COMPARE TIMES: WILL BE GREAT THAN 3.0M COUNTS DUE TO TIME TO SEND SERIAL PORT INFO THROUGH DIAGS
    if(ts0 == 0 and ts1 > CONST_TIMESYNC_CNTR_100msec):
        print('INFO: MCU TIMESYNC TEST - PASS')
    else:
        print('INFO: MCU TIMESYNC TEST - FAIL')
        print('ts0:',ts0)
        print('ts1:',ts1)
    return


#===============================================================================================================================================
# FUNCTION: SET IRQ PIN
#===============================================================================================================================================
def t804_set_irq_pin(pin_state):

    if(pin_state > 0):
        t804_test_spi_write_reg(REG_EM_ADDR__HOST_IRQ_CONTROL,'0x11')
    else:
        t804_test_spi_write_reg(REG_EM_ADDR__HOST_IRQ_CONTROL,'0x10')
    return


#===============================================================================================================================================
# FUNCTION:
#===============================================================================================================================================
def t804_check_connection_irq():

    # SET IRQ PIN LO:
    pin_lo = 0
    t804_set_irq_pin(pin_lo)

    # READ IRQ PIN ON HOST SIDE:
    resp = run('socgpio --port 0 --pin 44 --input --get',True)
    a = resp.split()
    for i in range(len(a)):
        if(a[i] == '='):
            pin_state = int(a[i+1])
            break

    # COMPARE:
    if(pin_state != pin_lo):
        print('INFO: MCU IRQ TEST      - FAIL')
        return

    # SET IRQ PIN HI:
    pin_hi = 1
    t804_set_irq_pin(pin_hi)

    # READ IRQ PIN ON HOST SIDE:
    resp = run('socgpio --port 0 --pin 44 --input --get',True)
    a = resp.split()
    for i in range(len(a)):
        if(a[i] == '='):
            pin_state = int(a[i+1])
            break

    # COMPARE:
    if(pin_state != pin_hi):
        print('INFO: MCU IRQ TEST      - FAIL' )
        return

    # IF WE MADE IT THIS FAR THEN WE PASSED:
    print('INFO: MCU IRQ TEST      - PASS' )
    return


#===============================================================================================================================================
# FUNCTION: CHECK MCU EXTERNAL CRYSTAL
#===============================================================================================================================================
def t804_check_mcu_crystal():
    t804_mcu_rst(False)
    t804_delay_usec(100000)
    d1,d2,d3,status_hse_error,d4,d5 = t804_get_sys_status()


    if(status_hse_error > 0): # CHECKING HSE_ERROR FLAG
        print('INFO: MCU CRYSTAL TEST  - FAIL')
    else:
        print('INFO: MCU CRYSTAL TEST  - PASS')
    return


#===============================================================================================================================================
# FUNCTION: T804 BUCK/BOOST CONTROL
# En: 0 = OFF, 1 = ON (INTEGER)
#
# Vout (INTEGER) settings: must be exact number otherwise it will default to bb default of ~4.45V
# 0 - 4 = default = ~4.45V (WILL VARY BY 2%)
# 5  = 5V
# 6  = 6V
# 7  = 7V
# 8  = 8V
# 9  = 9V
# 10 = 10V
#
#================================================================================================================================================
def t804_bb_ctrl(En, vout_setting):
    if(En > 0):
        # BB VREF REG SETTINGS FOR A SPECIFIC VOUT:
        vout = {
            5: '0x01 0x00 0x00 0x44',
            6: '0x01 0x00 0x00 0x52',
            7: '0x01 0x00 0x00 0x60',
            8: '0x01 0x00 0x00 0x6E',
            9: '0x01 0x00 0x00 0x7C',
            10: '0x01 0x00 0x00 0x89'
        }
        # DEV MUST HAVE A LIMIT OF 6V AS THE COIL'S Q-FACTOR IS TOO HIGH:
        # POSSIBLE DAMAGE > 6V, HMD IS OK DUE TO EDDY CURRENTS
        #if(vout_setting > 6):
        #    vout_setting = 6
        vref_config = vout.get(vout_setting,'0x01 0x00 0x00 0x00')
        t804_test_spi_write_reg(REG_EM_ADDR__BB_CONTROL_0, vref_config)
    else:
        t804_test_spi_write_reg(REG_EM_ADDR__BB_CONTROL_0, '0x00 0x00 0x00 0x00')
    dummy1, dummy2, status_bb_en, dummy3, status_bb_error, dummy4 = t804_get_sys_status()
    if(status_bb_en == 0):
        print('INFO: BB ENABLE FAIL')
    if(status_bb_error == 1):
        print('INFO: BB I2C FAIL')
    t804_delay_usec(10000) # 10msec WAIT
    return


#===============================================================================================================================================
# FUNCTION: READ BUCK-BOST STATUS REG IN MCU:
#===============================================================================================================================================
def t804_get_bb_status():
    reg_bb_status = 0
    resp = t804_test_spi_read_reg(CONST_SPI_RD_DEBUG_EN, REG_EM_ADDR__BB_STATUS_0)
    a = resp.split()
    L = len(a)
    fault = 1
    for i in range(L - 4):
        if(a[i] == '0xA5'):
            fault = 0
            reg_bb_status = hex(int(a[i+4],16))
            break;
    if(fault == 1):
        print('SPI FAILURE - LINE 244')
        sys.exit()
    else:
        return reg_bb_status


#===============================================================================================================================================
# FUNCTION: BUCK-BOST VOUT SWEEP
#===============================================================================================================================================
def t804_bb_sweep():
    print('INFO: BUCK-BOOST VOUT SWEEP START')
    for i in range(7):
        t804_bb_ctrl(True, 4+i)
        t804_delay_usec(500000) # 0.5 SEC WAIT
    for i in range(7):
        t804_bb_ctrl(True, 10-i)
        t804_delay_usec(500000) # 0.5 SEC WAIT
    t804_bb_ctrl(False, 0)
    print('INFO: BUCK-BOOST VOUT SWEEP END')
    return


#===============================================================================================================================================
# FUNCTION: GET BB ADC DATA
#===============================================================================================================================================
def t804_config_bb_adc():
    bb_adc_config = '0x01 0x00 0x02 0x07' #divBy4 pre-scalar + 19, 5 clks/sample, start
    t804_test_spi_write_reg(REG_EM_ADDR__BB_ADC_CONTROL_0,bb_adc_config)

    status_adc_hw_idle = 0
    timeout_cntr = 0
    while(status_adc_hw_idle == 0):
        d1, d2, d3, d4, d5, status_adc_hw_idle = t804_get_sys_status()
        t804_delay_usec(1000) # 1msec WAIT
        timeout_cntr += 1
        if(timeout_cntr == 1000): # ~1 sec WAIT
            print("INFO: SPI READ FAIL OR ADC_HW_IDLE BIT STUCK")
            sys.exit()
    return


#===============================================================================================================================================
# FUNCTION: GET BB ADC DATA
#===============================================================================================================================================
def t804_get_bb_adc_fifo_pop():

    adc_value1 = 99
    adc_value2 = 99
    resp = t804_test_spi_read_reg(CONST_SPI_RD_DEBUG_DIS, REG_EM_ADDR__BB_ADC_FIFO)
    a = resp.split()
    array_length = len(a)
    for i in range(array_length - 4):
        if(a[i] == '0xA5'):
            adc_value1 = int(a[i+2]) * 256 + int(a[i+1])
            adc_value2 = int(a[i+4]) * 256 + int(a[i+3])
            break
        if(i > array_length - 4):
            print('SPI ERROR:')
            print(a)
            exit()
    return (float(adc_value1 + adc_value2) / 2.0)


#===============================================================================================================================================
# FUNCTION: ESTIMATE BB VOUT FROM ADC VALUES
#===============================================================================================================================================
def t804_get_bb_vout():
    accumulation_size = 10
    vout_dn_accum = 0
    vout_avg = 0.0
    for i in range(accumulation_size):
        vout_dn_accum += t804_get_bb_adc_fifo_pop()
        #print(t804_get_bb_adc_fifo_pop())
    vout_dn_avg = vout_dn_accum / accumulation_size
    vout_avg = 0.0035 * vout_dn_avg + 0.0892 # EQUATION BASED ON LINEAR ESTIMATION OF COLLECTED DATA, BUT THIS IS WAY OFF
    return round(vout_avg,3)


#===============================================================================================================================================
# FUNCTION: CHECKING BUCK-BOOST & IT'S FEEDBACK
#===============================================================================================================================================
def t804_check_bb():
    print('INFO: BB TEST START:')
    for i in range(6):
        vset = float(i + 5)
        t804_bb_ctrl(1, i + 5)
        t804_config_bb_adc()
        vout_fb = float(t804_get_bb_vout())
        print('Vset:',vset, ' vs. Vout:',vout_fb)
        if((vout_fb > vset + 0.25) or (vout_fb < vset - 0.25)):
            print('INFO: BB TEST           - FAIL')
            return
    print('INFO: BB TEST           - PASS')
    return


#===============================================================================================================================================
# FUNCTION: CAPACITOR BANK CONTROL
#===============================================================================================================================================
def t804_config_cap_bank(cap_bank_setting):
    if(cap_bank_setting > 7 or cap_bank_setting < 0):
        print('INFO: CAP-BANK CONFIG FAIL')
        return
    else:
        cap_bank_setting_str = str(hex(int(cap_bank_setting))) + ' 0x00 0x00 0x00'
    t804_test_spi_write_reg(REG_EM_ADDR__CAPBANK_CONTROL_0, cap_bank_setting_str)
    return


#===============================================================================================================================================
# FUNCTION: SET PWM FREQ
#===============================================================================================================================================
def t804_en_pwm(en):
    if(en > 0):
        t804_test_spi_write_reg(REG_EM_ADDR__HBRIDGE_CONTROL, '0x01 0x00 0x00 0x00')
        t804_test_spi_write_reg(REG_EM_ADDR__CARRIER_PWM_CONTROL_0, '0x01 0x00 0x01 0x00')
    else:
        t804_test_spi_write_reg(REG_EM_ADDR__HBRIDGE_CONTROL, '0x00 0x00 0x00 0x00')
        t804_test_spi_write_reg(REG_EM_ADDR__CARRIER_PWM_CONTROL_0, '0x00 0x00 0x01 0x00')
    t804_delay_usec(1000) # 1msec WAIT
    return


#===============================================================================================================================================
# FUNCTION: ENABLING OR DISABLING COIL FEEDBACK BUFFER AMP
#===============================================================================================================================================
def t804_vres_fb_buffer_en(state):
    if(state > 0):
        t804_test_spi_write_reg(REG_EM_ADDR__OPAMP_CONTROL, '0x01')
    else:
        t804_test_spi_write_reg(REG_EM_ADDR__OPAMP_CONTROL, '0x00')
    return


#===============================================================================================================================================
# FUNCTION:
#===============================================================================================================================================
def t804_set_res_freq(pwm_freq):
    CONST_MCU_PERIPERAL_CLK = 32000000
    CONST_COIL_DRIVE_PWM_DC = 0.5
    cntr_time = int(round(CONST_MCU_PERIPERAL_CLK / pwm_freq * CONST_COIL_DRIVE_PWM_DC,0))
    #print(cntr_time)
    cntr_time_msB = cntr_time >> 8
    cntr_time_msB_str = '0x{0:0{1}X}'.format(cntr_time_msB,2)
    #print(cntr_time_msB_str)
    cntr_time_lsB = cntr_time  % 256
    cntr_time_lsB_str = '0x{0:0{1}X}'.format(cntr_time_lsB,2)
    #print(cntr_time_lsB_str)
    cntr_time_str = cntr_time_lsB_str + ' ' + cntr_time_msB_str + ' 0x00 0x00'
    t804_test_spi_write_reg(REG_EM_ADDR__CARRIER_PWM_HI_TIME, cntr_time_str)
    t804_test_spi_write_reg(REG_EM_ADDR__CARRIER_PWM_LO_TIME, cntr_time_str)
    return


#===============================================================================================================================================
# FUNCTION: ENABLE TX COIL DRIVE
#===============================================================================================================================================
def t804_drive_coil(freqHz, capbank_config, bb_vout):

    # SET CAP BANK FOR SPECIFIC RESONATE FREQ:
    t804_config_cap_bank(capbank_config)

    # SET CARRIER FREQUENCY (PWM)
    t804_set_res_freq(freqHz) # CURRENT DEFAULT, DO NOT CHANGE

    # ENABLE BUCK-BOOST:
    t804_bb_ctrl(1, bb_vout)  # CURRENT DEFAULT, DO NOT CHANGE

    # ENABLE PWM: PWM LINE + 5V LEVELSHIFTER
    t804_en_pwm(1)

    # WAIT FOR COIL TO RAMP-UP:
    t804_delay_usec(100000) # 100msec WAIT

    return


#===============================================================================================================================================
# FUNCTION: GET BB ADC DATA
#===============================================================================================================================================
def t804_config_tx_coil_adc():
    tx_coil_adc_config = '0x01 0x00 0x00 0x00'
    t804_test_spi_write_reg(REG_EM_ADDR__OUTPUT_ADC_CONTROL_0,tx_coil_adc_config)
    status_adc_hw_idle = 0
    timeout_cntr = 0
    while(status_adc_hw_idle == 0):
        d1, d2, d3, d4, d5, status_adc_hw_idle = t804_get_sys_status()
        t804_delay_usec(1000) # 1msec WAIT
        timeout_cntr += 1
        if(timeout_cntr == 1000): # ~1 sec WAIT
            print("INFO: SPI READ FAIL OR ADC_HW_IDLE BIT STUCK")
            sys.exit()
    return


#===============================================================================================================================================
# FUNCTION: GET BB ADC DATA
#===============================================================================================================================================
def t804_get_tx_coil_adc_fifo_pop():
    adc_value1 = 99
    adc_value2 = 99
    resp = t804_test_spi_read_reg(CONST_SPI_RD_DEBUG_DIS, REG_EM_ADDR__OUTPUT_ADC_FIFO)
    a = resp.split()
    for i in range(len(a) - 4):
        if(a[i] == '0xA5'):
            adc_value1 = int(a[i+2]) * 256 + int(a[i+1])
            adc_value2 = int(a[i+4]) * 256 + int(a[i+3])
            break
    return adc_value1, adc_value2


#===============================================================================================================================================
# FUNCTION: GET MEAN
#===============================================================================================================================================
def t804_get_mean(data_array):
    accum = 0.0
    size = len(data_array)
    for i in range(size):
        accum += data_array[i];
    mean = round((accum / float(size)),3)
    return mean


#===============================================================================================================================================
# FUNCTION: GET MAX SWING (SIMPLE METHOD)
#===============================================================================================================================================
def t804_get_max(data_array):
    max = 0
    size = len(data_array)
    for i in range(size):
        if(data_array[i] < 0):
            data_array[i] *= (-1) # ABSOLUTE VALUE
        if(data_array[i] > max):
            max = data_array[i]
    return max

#===============================================================================================================================================
# FUNCTION: get AC-COUPLED DATA
#===============================================================================================================================================
def t804_get_ac_data(data_array):
    mean = t804_get_mean(data_array)
    size = len(data_array)
    for i in range(size):
        data_array[i] -= mean
        #print(data_array[i])
    return data_array

#===============================================================================================================================================
# FUNCTION: ESTIMATE BB VOUT FROM ADC VALUES
#===============================================================================================================================================
def t804_get_tx_coil_vout():

    # INIT VARIABLES:
    adc1 = 0.0
    adc2 = 0.0
    adc_array = []

    # GET DATA STORE IT IN AN ARRAY, CALC AVG:
    for i in range(CONST_ADC_FIFO_RD_SIZE):
        adc1, adc2 = t804_get_tx_coil_adc_fifo_pop()
        adc_array.append(adc1)
        adc_array.append(adc2)

    return adc_array


#===============================================================================================================================================
# FUNCTION: COLLECT ADC DATA
#===============================================================================================================================================
def t804_check_coil_drive():
    print('INFO: COIL DRIVE START:')

    # ENABLE ADCBUFFER:
    t804_vres_fb_buffer_en(1)

    # WAIT FOR BUF-AMP TO ENABLE:
    t804_delay_usec(20000) # 20msec WAIT (WAY TOO LONG BUT WHATEVER)

    # START COIL: 38.5KHz, CAPBANK CONFIG (ALL SWITCHED ON), 7V BUCK-BOOST
    t804_drive_coil(CONST_RES_FREQ_LO, CONST_RES_CAPBANK_LO_CONFIG, CONST_BUCK_BOOST_DEFAULT_VOUT)

    # WAIT FOR COIL TO RESONATE:
    t804_delay_usec(100000) # 100msec WAIT (WAY TOO LONG BUT WHATEVER)

    # CONFIG COIL ADC FB & COLLECT DATA:
    print('INFO: COLLECTING COIL DATA:')
    t804_config_tx_coil_adc()

    # GRAB DATA:
    coil_data   = t804_get_tx_coil_vout()
    mean        = t804_get_mean(coil_data)
    ac_data     = t804_get_ac_data(coil_data)
    ac_max      = t804_get_max(ac_data)
    print('dc =', mean, ' amplitude: =', ac_max)


    # CHECK IF MAX ARE WITHIN KNOWN OK VALUES:
    if((ac_max < (0.85 * CONST_COIL_ADC_FB_TYPICAL_AMPLITUDE)) or (ac_max > (1.15 * CONST_COIL_ADC_FB_TYPICAL_AMPLITUDE)) or (mean < (0.85 * CONST_COIL_ADC_FB_TYPICAL_MEAN)) or (mean > (1.15 * CONST_COIL_ADC_FB_TYPICAL_MEAN))):
        print('    COIL DRIVE:      - FAIL - UNEXPECTED DRIVE VALUES')
    else:
        print('    COIL DRIVE:      - PASS')
    return


#===============================================================================================================================================
# FUNCTION: RUN SUB-SYSTEM CHECK FOR FATP-ONLY TEST
#===============================================================================================================================================
def t804_sub_system_validation():
    t804_make_terminal_space()
    print('================================================')
    print('N301 P1 MAGNETIC TRACKING FATP VALIDATION SCRIPT')
    print('================================================')
    t804_get_board_id(True)
    t804_set_boot_pin(0,True)
    t804_mcu_rst(True)
    t804_check_fw_version(True)
    t804_check_mcu_boot()
    t804_check_mcu_reset()
    t804_check_mcu_crystal()
    t804_check_connection_timesync()
    t804_check_connection_irq()
    t804_check_bb()
    t804_check_coil_drive()
    t804_mcu_rst(True)
    print('================================================')
    print('END')
    print('================================================')
    t804_make_terminal_space()
    return


#================================================================================================================================================
# START OF SCRIPT EXECUTION
#================================================================================================================================================
t804_sub_system_validation()


#================================================================================================================================================
# END OF FILE
#================================================================================================================================================
