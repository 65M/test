import sys
import os
import argparse
sys.path.append("nandfs:\\AppleInternal\\Diags\\Logs\\Smokey\\AEMTools")
sys.path.append("nandfs:\\AppleInternal\\Diags\\Logs\\Smokey")
from AEMTools import main as AEMToolsMain
from shell import run


parser = argparse.ArgumentParser()
parser.add_argument("--AdditionalPdca", dest="AdditionalPdca", type=str, default=None, help="Location for the final result")
AdditionalPdca = parser.parse_args().AdditionalPdca
DirPath = AdditionalPdca.rsplit("\\",1)[0]
Basename = AdditionalPdca.rsplit("\\",1)[1]

run("nandfs:")
AEMToolsMain.run_margining(["--end_point", "cobra", "--device_index", "1", "--doe", "True", "--result_path", DirPath, "--additional_pdca", Basename])
