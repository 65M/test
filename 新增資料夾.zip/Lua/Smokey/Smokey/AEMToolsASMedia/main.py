import sys
import os
import argparse
sys.path.append("nandfs:\\AppleInternal\\Diags\\Logs\\Smokey\\AEMTools")
sys.path.append("nandfs:\\AppleInternal\\Diags\\Logs\\Smokey")
from AEMTools import main as AEMToolsMain


parser = argparse.ArgumentParser()
parser.add_argument("--AdditionalPdca", dest="AdditionalPdca", type=str, default=None, help="Location for the final result")
AdditionalPdca = parser.parse_args().AdditionalPdca
DirPath = AdditionalPdca.rsplit("\\",1)[0]
Basename = AdditionalPdca.rsplit("\\",1)[1]

AEMToolsMain.run_margining(["--end_point", "asmedia", "--result_path", DirPath, "--additional_pdca", Basename])
