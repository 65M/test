_all_ = [
    "AbstractEndpointsParams"
]


class AbstractEndpointsParams(object):
    min_x = None
    max_x = None
    min_y = None
    max_y = None
    step_x = None
    step_y = None
    duration_ms = None
    delay_us = None
    threshold = 0
    traffic = "Live"
    gen_speed = 0
    gen_width = 0
    timeout_s = None
    adaptations = []
    tool_cycle_count = 1
    axis_only = False
    cycles = 1
    module = None
    tick_voltage = None
    tick_frequency = None
    root_port = None
    doe = False
    doe_no = None
    vendor_specific = None
    ctle_sweep = False
    dfe = True
