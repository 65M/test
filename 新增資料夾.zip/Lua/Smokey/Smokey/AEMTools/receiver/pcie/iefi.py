"""Access for iEFI"""
from .base import AbstractReceiverMarginTool
from shell import run
import re
import time
from .defines import *
__all__ = [
    "MarginTool"
]


def n_lsb(x):
    return (1 << x) - 1


def n_to_m(n, m):
    return n_lsb(n) & ~ n_lsb(m)


class MarginTool(AbstractReceiverMarginTool):
    """Margin Tool Instance"""

    def verify_cfg2_bits(self):
        two_bit = self.get_bits(self.cfg2_offset, 2, 2)
        zero_bit = self.get_bits(self.cfg2_offset, 0, 2)
        print("cfg2 two bit: {} cfg2 zero bit: {}".format(two_bit, zero_bit))
        if int(zero_bit) != 3:
            print("WARNING!!! Zero bit doesn't match 3")

    def verify_link_speed(self, timeframe):
        print(f" Start Verify Link Speed: {self.cfg2_offset}")
        self.verify_cfg2_bits()
        train_speed = self.get_bits(self.pcie_cfg_rp_offset + LINK_CAPABAILTIES['PCIE_CONTROL_LINK_STATUS'], 16, 4)
        print(f"Train Speed: {train_speed} Expected: {self.gen_speed} Timeframe: {timeframe}")
        if (train_speed == self.gen_speed) or (timeframe == "Test End"):
            self.log_msg(f"Trained to the specified speed {train_speed}")
        else:
            raise Exception(f"PCIE link training failed {timeframe}")

        print("Verify Link Width")
        self.verify_link_width(timeframe)
        print("Done Verify Link Speed")

    def verify_link_width(self, timeframe):
        gen_width = self.get_bits(self.pcie_cfg_rp_offset + LINK_CAPABAILTIES['PCIE_CONTROL_LINK_STATUS'], 20, 4)
        print("Found Gen Width: {} Expected: {} Timeframe: {}".format(gen_width, self.gen_width, timeframe))
        # if gen_width == self.gen_width:
        #     self.log_msg("trained to speed {}".format(gen_width))
        #     self.log_msg("Trained to the specified speed")
        # else:
        #     raise Exception("PCIE link training failed {}".format(timeframe))

    def ensure_link(self):
        """Check Link meets Speed / Width requirements"""
        if self.module not in ["microsemi", "ipc"]:
            print("Disabling Link to begin with to confirm it's off")
            data = run("pcie --pick {} ".format(self.root_port))
            if "ERROR" in data:
                raise Exception("PCIE on failed, please check its valid")
            run("pcie --off") # Disable the link to begin with
            print("Done Disabling Link to begin with to confirm it's off")

        if self.module is "wifi":
            on = run("wifi --on")
            if "ERROR" not in on:
                self.log_msg("Turned on WiFi")
                data = run("pcie --pick {} ". format(self.root_port))
                if "ERROR" not in data:
                    self.log_msg("Picked root port number {}".format(self.root_port))
                    on_data = run("pcie --on")
                    # run("pcie --aspm off")
                    if "ERROR" not in on_data:
                        self.verify_link_speed("Test Start")
                    else:
                        raise Exception("PCIE on failed, please check its valid")
                else:
                    raise Exception("PCIE pick failed, please check port number")
            else:
                raise Exception("Failed turning on {}", self.module)

        elif self.module is "baseband":
            # Power on
            run("baseband --off;baseband --on --load")
            self.verify_link_speed("Test Start")

        elif self.module is "microsemi":
            # Power on
            data = run("pcie --pick 4")
            if "ERROR" in data:
                raise Exception("PCIE pick failed, please check its valid")

            data = run("pcie --func 1")
            if "ERROR" in data:
                raise Exception("PCIE pick failed, please check its valid")

            data = run("pcie --on")
            if "ERROR" in data:
                raise Exception("PCIE pick failed, please check its valid")

            data = run("pcie --pick 21")
            if "ERROR" in data:
                raise Exception("PCIE pick failed, please check its valid")

            data = run("pcie --func 1")
            if "ERROR" in data:
                raise Exception("PCIE pick failed, please check its valid")

            data = run("pcie --on")
            if "ERROR" in data:
                raise Exception("PCIE pick failed, please check its valid")

            self.verify_link_speed("Test Start")

        elif self.module is "flusb":
            # Power on
            run("device -k FL1100 -e on")
            self.verify_link_speed("Test Start")

        elif self.module is "sdgen2": # New 9763 controller on Rhodes
            run("pmugpio --pin 22 --output 1; wait 1") # PMU GPIO command from Colin Szechy
            print("SDGen3 Enable for new GL9676 Chip")
            run("pcie --pick {}".format(self.root_port))
            # Check PCIE Gen
            on_data = run("pcie --on")
            run("pcie --aspm off")
            if "ERROR" not in on_data:
                train_speed = self.get_bits(self.pcie_cfg_rp_offset + LINK_CAPABAILTIES['PCIE_CONTROL_LINK_STATUS'], 16, 4)

                print(train_speed)
                if train_speed == self.gen_speed:
                    self.log_msg(
                        "trained to speed {}".format(train_speed))
                    self.log_msg("Trained to the specified speed")
                else:
                    raise Exception("PCIE link training failed")

            else:
                raise Exception(
                    "PCIE on failed, please check its valid")

        elif self.module is "sdgen3": # New 9763 controller on Rhodes
            run("pmugpio --pin 22 --output 1; wait 1") # PMU GPIO command from Colin Szechy
            print("SDGen3 Enable for new GL9676 Chip")
            run("i2c --devwrite 4 0x6a 0x40 0x1")
            run("i2c --devwrite 4 0x6a 0x7f 0x12")
            run("i2c --devwrite 4 0x6a 0xc4 0x81")
            run("i2c --devwrite 4 0x6a 0x7f 0x11")
            run("i2c --devwrite 4 0x6a 0xc8 0xd1")
            run("i2c --devwrite 4 0x6a 0xc4 0x91")
            run("i2c --devwrite 4 0x6a 0xc5 0xb1")
            run("pcie --pick {}".format(self.root_port))
            # Check PCIE Gen
            on_data = run("pcie --on")
            run("pcie --aspm off")
            if "ERROR" not in on_data:
                train_speed = self.get_bits(self.pcie_cfg_rp_offset + LINK_CAPABAILTIES['PCIE_CONTROL_LINK_STATUS'], 16, 4)

                print(train_speed)
                if train_speed == self.gen_speed:
                    self.log_msg(
                        "trained to speed {}".format(train_speed))
                    self.log_msg("Trained to the specified speed")
                else:
                    raise Exception("PCIE link training failed")

            else:
                raise Exception(
                    "PCIE on failed, please check its valid")

        elif self.module is "gen3sd":
            run("pmugpio --pin 26 --output 1; wait 1; socgpio --pin 227 --output 1")
            run("pcie --pick {}".format(self.root_port))
            # Check PCIE Gen
            on_data = run("pcie --on")
            run("pcie --aspm off")
            if "ERROR" not in on_data:
                self.verify_link_speed("Test Start")

            else:
                raise Exception(
                    "PCIE on failed, please check its valid")

        elif self.module is "ethernet" or "usb" or "sdcard":
            # Power on
            # Set PCIE Gen
            if self.product_code == "J375" and self.module is "sdcard":
                run("egpio --pick pmu --pin 26 --write 1")
            run("pcie --pick {}".format(self.root_port))
            # Check PCIE Gen
            on_data = run("pcie --on")
            run("pcie --aspm off")
            if "ERROR" not in on_data:
                self.verify_link_speed("Test Start")
                if self.load_fw:
                    run("nandfs:\AppleInternal\Diags\Apps\\asmfud.efi -f nandfs:\AppleInternal\Diags\\USBC\J375\\asm3142_fw.bin")
                    run("nandfs:\AppleInternal\Diags\Apps\\asmfud.efi -v")
            else:
                raise Exception(
                    "PCIE on failed, please check its valid")

        elif self.module is "storage" or "ipc":
            self.verify_link_speed("Test Start")

        print("Done Ensure Link")

    def check_link(self):
        speed = run("pcie --get gen")
        if "gen" in speed:
            train_speed = re.search("= [\d]", speed).group(0).strip("=")[1]
            self.log_msg("trained to speed {}".format(train_speed))
            print("Train Speed: {} Expected: {}".format(train_speed, self.gen_speed))
            if int(train_speed) is self.gen_speed:
                self.log_msg("trained to speed {}".format(train_speed))
                self.log_msg("Trained to the specified speed")
            else:
                raise Exception("PCIE link training failed")

    def set_bits(self, address, start_bit, length, value):
        """Read registers"""
        mm_data = run("mm -w 4 -n {}".format(hex(address)))
        if "MEM" in mm_data:
            end_bit = start_bit + length
            a = mm_data.split(": ")
            reg_val = a[1].strip("\r\n")
            result = hex((int(reg_val, 16) & ~n_to_m(
                end_bit, start_bit)) | value << start_bit)
            run("mm -w 4 -n {} {}".format(hex(address), result))
        else:
            raise Exception("Set bits failed")

    def get_bits(self, address, start_bit, length):
        """Read registers"""
        mm_data = run("mm -w 4 -n {}".format(hex(address)))
        if "MEM" in mm_data:
            a = mm_data.split(": ")
            reg_val = a[1].strip("\r\n")
            bin_val = '{:>032}'.format(bin(int(reg_val, 16))[2:])
            end_pos = 31 - start_bit + 1
            start_pos = 31 - start_bit - length + 1
            bits = int(bin_val[start_pos:end_pos], 2)
            return bits
        else:
            raise Exception("Get bits failed")

    def write_register(self, address, data):
        """Write an offset"""
        mm_data = run("mm -w 4 -n {}".format(hex(address)))
        if "MEM" not in mm_data:
            raise Exception("Write Register failed")

    def read_register(self, address):
        """Read an offset"""
        mm_data = run("mm -w 4 -n {}".format(hex(address)))
        if "MEM" in mm_data:
            a = mm_data.split(": ")
            reg_val = a[1].strip("\r\n")
            return reg_val
        else:
            raise Exception("Read Register failed")
