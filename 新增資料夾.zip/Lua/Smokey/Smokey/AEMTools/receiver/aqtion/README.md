# Aqauntia Aqtion 10G Ethernet

### Device Capabilities:
  - PCIE Gen 3
  - X2 / X4


