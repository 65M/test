"""Access for OS"""
import os
import re
import subprocess
import csv
from .base import AbstractReceiverMarginTool

__all__ = [
    "MarginTool"
]


class MarginTool(AbstractReceiverMarginTool):
    """Margin Tool Instance"""

    def disable_aspm(self, bdf_endpoint):
        # Disable ASPM for the passed in bdf endpoint.
        disable_aspm = subprocess.run(
            "sudo /AppleInternal/Diagnostics/Scripts/{}/pcie-util/pcie-util.lua --disable-ASPM {}".format(self.folder_name, bdf_endpoint), shell=True,
            stdout=subprocess.PIPE).stdout.decode('utf-8')

        print("Disable ASPM {} Result".format(bdf_endpoint))
        self.log_msg("Disable ASPM {} Result".format(bdf_endpoint))
        for line in disable_aspm.split("\n"):
            self.log_msg(line)
            print(line)

    def enable_aspm(self, bdf_endpoint):
        # Enable ASPM for the passed in bdf endpoint.
        enable_aspm = subprocess.run(
            "sudo /AppleInternal/Diagnostics/Scripts/{}/pcie-util/pcie-util.lua --enable-ASPM-L1 {}".format(self.folder_name, bdf_endpoint), shell=True,
            stdout=subprocess.PIPE).stdout.decode('utf-8')

        print("Enable ASPM L1 {} Result".format(bdf_endpoint))
        self.log_msg("Enable ASPM L1 {} Result".format(bdf_endpoint))
        for line in enable_aspm.split("\n"):
            self.log_msg(line)
            print(line)

    def ensure_controller_speed_width(self, controller_number, index):
        # Ensure the passed in controller speed / width matches expected
        print("Running link status with {}".format(self.link_status_endpoints[index]))
        controller = subprocess.run(
            "sudo /AppleInternal/Diagnostics/Scripts/{}/pcie-util/pcie-util.lua --link-status {}".format(self.folder_name, self.link_status_endpoints[index]), shell=True,
            stdout=subprocess.PIPE).stdout.decode('utf-8')

        print("Controller {} Status".format(controller_number))
        print(controller)
        self.log_msg("Controller {} Status".format(controller_number))
        self.log_msg(controller)

        controller_width = 0
        controller_gen = 0
        for line in controller.split("\n"):
            link_speed_match = re.search(r".*Current Link Speed.*PCIe Gen(\d+).*0.*", line)
            link_width_match = re.search(r".*Negotiated Link Width.* (\d+) .*0.*", line)
            if link_width_match != None:
                controller_width = int(link_width_match.group(1))
                print("Found Controller {} Width: {}".format(controller_number+1, controller_width))
                self.log_msg("Found Controller {} Width: {}".format(controller_number+1, controller_width))
            if link_speed_match != None:
                controller_gen = int(link_speed_match.group(1))
                print("Found Controller {} Gen: {}".format(controller_number+1, controller_gen))
                self.log_msg("Found Controller {} Gen: {}".format(controller_number+1, controller_gen))

        return controller_width, controller_gen


    def ensure_link(self):
        # Ensure the link is setup as expected and matches the expected parameters
        # Setup .csv file
        self.csv_path = os.path.join(self.log_path, "results.csv")
        self.csv_file = open(self.csv_path, "w", newline="")
        self.csv_writer = csv.writer(self.csv_file, delimiter=',',quotechar='|', quoting=csv.QUOTE_MINIMAL)

        print("Disable ASPM Values: {} Enable ASPM Values: {} Folder Name: {} Controller Count: {} Controller Numbers: {} EN Endpoints: {} Link Status Endpoints: {} "
              .format(self.disable_aspm_val, self.enable_aspm_val, self.folder_name, self.controller_count, self.controller_numbers,
              self.en_endpoints, self.link_status_endpoints))

        """Check Link meets Speed / Width requirements"""
        # Magic Register for Serdes Eye / Register Reads (from Arnold - used for 274s)
        register_set = subprocess.run("sudo aeaa_util bar0 -i en0 0x1594 1", shell=True,
                                      stdout=subprocess.PIPE).stdout.decode('utf-8')
        print("Magic Register Set: {}".format(register_set))

        # Disable ASPM Endpoints
        for disable_aspm_bdf in self.disable_aspm_val:
            self.disable_aspm(disable_aspm_bdf)

        # Enable ASPM L1 (double check with --link-control on a unit to see the default value)
        for enable_aspm_bdf in self.enable_aspm_val:
            self.enable_aspm(enable_aspm_bdf)

        # Link Status Checks
        for i in range (0, self.controller_count):
            print("Running with Controller #: {}".format(self.controller_numbers[i]+1))
            controller_width, controller_gen = self.ensure_controller_speed_width(self.controller_numbers[i], i)

            self.log_key(key="aqc113_Cont#{}_link_".format(i+1), units='gen', value=controller_gen, lowerlimit=self.gen_speed, upperlimit=self.gen_speed)
            self.log_key(key="aqc113_Cont#{}_link_".format(i+1), units='width', value=controller_width, lowerlimit=self.gen_width, upperlimit=self.gen_width)

            self.csv_writer.writerow(['aqc113_Cont#{}'.format(i+1),'gen_speed',controller_gen])
            self.csv_writer.writerow(['aqc113_Cont#{}'.format(i+1),'link_width',controller_width])

            if controller_width != self.gen_width:
                raise Exception("Controller {} Width: {} does not match expected Width: {}".format(
                    i+1, controller_width, self.gen_width
                ))
            else:
                print("Controller {} width {} match expected width {}".format(
                    i+1, controller_width, self.gen_width))

            if controller_gen != self.gen_speed:
                raise Exception("Controller {} Gen: {} does not match expected Gen Speed: {}".format(
                    i+1, controller_gen, self.gen_speed
                ))
            else:
                print("Controller {} gen speed {} matches expected gen speed {}".format(
                    i+1, controller_gen, self.gen_speed))

        pass

    def dump_registers(self, initial=False):
        """Dump Static Registers"""
        # ToDo: Do we need to dump any registers while doing this?

    def start_margining(self):
        # Run margining data for the desired enx ports. (This is a slow function 5-6 min / J170 / command)
        # ToDo: Parse out the desired enx lanes based on (not sure if this'll work)
        #   Look for the type: key (edited)
        #   Ethernet: Ethernet (0x6) family: 2 subfamily: 0
        #   Wifi: Wi-Fi (0x6) family: 2 subfamily: 3
        #   ifconfig -vv

        self.margin_data = []
        for enx in self.en_endpoints:
            for i in range(0, self.lane_count):
                # Run for all the different en endpoints and each  lane
                self.file_name = os.path.join(self.log_path, "serdeseyelane{}logs{}.json".format(i, enx))
                command = "sudo aeaa_util serdeseye -i {} -o {} -l {}".format(enx, self.file_name, i)
                print("Running Serdes Eye command {} with JSON Output File Location: {}".format(command, self.file_name))
                self.margin_data.append(subprocess.run(command, shell=True, stdout=subprocess.PIPE).stdout.decode('utf-8'))

        print("Initial Margining Complete")
        pass

    def parse_enlane_data(self, margin_data, en_string, lane):
        # Parse the margining data for each enx and lane
        eye_width_cells = 0
        eye_width_ui = 0
        eye_height_cells = 0
        eye_height_mV = 0

        print("Margining Data Output For: {} and Lane: {}".format(en_string, lane))
        self.log_msg("Margining Data Output For: {} and Lane: {}".format(en_string, lane))

        for line in margin_data.split("\n"):
            print(line)
            self.log_msg(line)
            eye_width_match = re.search(r".*Eye width:.* (\d+) cells,.*(0\.\d+) UI.*",
                                        line)  # Eye width:   31 cells,   0.877358 UI
            eye_height_match = re.search(r".*Eye height.* (\d+) cells,.* (\d+\.\d+) mV.*",
                                         line)  # Eye height: 122 cells, 340.343353 mV

            if eye_width_match != None:
                eye_width_cells = float(eye_width_match.group(1))
                eye_width_ui = float(eye_width_match.group(2))
                print("Found {} Eye Width Match with cells: {} and ui: {}".format(en_string, eye_width_cells, eye_width_ui))
                self.log_msg("Found {} Eye Width Match with cells: {} and ui: {}".format(en_string, eye_width_cells, eye_width_ui))

            if eye_height_match != None:
                eye_height_cells = float(eye_height_match.group(1))
                eye_height_mV = float(eye_height_match.group(2))
                print("Found {} Eye Height Match with cells: {} and mV: {}".format(en_string, eye_height_cells, eye_height_mV))
                self.log_msg("Found {} Eye Height Match with cells: {} and mV: {}".format(en_string, eye_height_cells, eye_height_mV))

        self.log_key(key="lane{}_{}_ew_".format(lane, en_string), value=eye_width_ui,
                     units='ui', lowerlimit=self.ew_min, upperlimit=self.ew_max)

        self.log_key(key="lane{}_{}_eh_".format(lane, en_string), value=eye_height_mV,
                     units='mV', lowerlimit=self.eh_min, upperlimit=float('inf'))

        self.csv_writer.writerow(['lane{}_{}_ew'.format(lane, en_string), eye_width_ui, 'ui'])
        self.csv_writer.writerow(['lane{}_{}_eh'.format(lane, en_string), eye_height_mV, 'mV'])

        return eye_width_cells, eye_width_ui, eye_height_cells, eye_height_mV


    def parse_margin_data(self):
        """Parse data to the necessary format(s)"""
        print("Parsing Data")
        self.result = []
        # Margin Data Format: [en0 lane 0, en0 lane 1, en1 lane 0, en1 lane1]
        for i in range (0, len(self.en_endpoints)):
            for j in range(0, self.lane_count):
                eye_width_cells, eye_width_ui, eye_height_cells, eye_height_mV = self.parse_enlane_data(self.margin_data[(i*self.lane_count)+j], self.en_endpoints[i], j)
                self.result.append([eye_width_cells, eye_width_ui, eye_height_cells, eye_height_mV])


    def calculate_eye(self):
        """Calculate the Eye Diagram for axis only"""
        # Parse the output
        self.parse_margin_data()
        pass
