from ..base import AbstractBaseMarginTool
import re
__all__ = [
    "AbstractReceiverMarginTool"
]


class AbstractReceiverMarginTool(AbstractBaseMarginTool):
    """Generic Interface for ANS (Apple NAND System) Margining"""
    LANE_COUNT = 1  # This needs to be set at run time (it's base on the system)
    TIMEOUT = 180  # Set timeout to 2min (Average is 1-1.5)
    POLL_TIME = 2  # Poll every 2 seconds
    margin_data=()

    def __init__(self, *args, **kwargs):
        super(AbstractReceiverMarginTool, self).__init__(*args, **kwargs)

        # Dynamically set the number of lanes by using Identify Controller
        self.LANE_COUNT = 1

        self._previous_percent = -1
        self.valid_bdf = []

    def padded_hex(self, i, l):
        given_int = i
        given_len = l

        hex_result = hex(given_int)[2:]  # remove '0x' from beginning of str
        num_hex_chars = len(hex_result)
        extra_zeros = '0' * (given_len - num_hex_chars)  # may not get used..

        return ('0x' + hex_result if num_hex_chars == given_len else
                '?' * given_len if num_hex_chars > given_len else
                '0x' + extra_zeros + hex_result if num_hex_chars < given_len else
                None)

    def disable_power_management(self):
        """Disable Power Management Modes"""

    #
    # Active Lane (ANS or MCP) Register RW functions
    #




    #
    # Execution Flow
    #
    def set_adaptation(self, figure_of_merit):
        """Set the Adaptation Type (if applicable)"""
        self.log_msg("   Setting Adaptation to {}".format(figure_of_merit))

    def configure_phy(self):
        """Configure the PHY Settings, Overrides, ECO, etc"""
        pass

    def set_traffic_type(self, traffic_type):
        """Select the Traffic type (Live, PRBS, etc)"""
        self.log_msg("   Setting Traffic Type to {}".format(traffic_type))

    def apply_settings(self, retrain=True):
        """Apply EQ and other settings, retrain (if applicable)"""

    # No settings to apply
    def ensure_link(self):
        """Check Link meets Speed / Width requirements"""
        # Get the Link Status, and calculate the Link Width / Speed

    def select_lane(self, lane):
        """Select a Lane"""
        self.current_lane = lane

    # Not applicable, all lanes are margined together

    def setup_margining(self):
        """Configure the PHY and Setup Margining"""

    def start_margining(self):
        """Start the Margining"""

    def dump_registers(self, initial=False):
        """Dump Static Registers"""

    def dump_registers(self, initial=True):
        """Dump Static Registers"""

    def parse_margin_data(self):
        """Parse data to the necessary format(s)"""

    def calculate_eye(self):
        """Calculate the Eye Diagram for axis only"""
        self.margin_data = self.margin_data.split("\r\n")
        match='[-+]?[0-9]*\.?[0-9]+'
        print(f"Margin Data {self.margin_data}")
        for i in range(0, len(self.margin_data), 1):
            if "Eye width" in self.margin_data[i]:
                eye_data = re.split(":|,", self.margin_data[i])
                self.eye_width_ticks[self.current_lane] = int((re.search(match, eye_data[1] )).group(0))
                self.eye_width[self.current_lane] = float((re.search(match, eye_data[2])).group(0))
            elif "Eye height" in self.margin_data[i]:
                eye_data = re.split(":|,", self.margin_data[i])
                self.eye_height_ticks[self.current_lane] = int((re.search(match, eye_data[1] )).group(0))
                self.eye_height[self.current_lane] = float((re.search(match, eye_data[2])).group(0))

        # Log them to the result file

        self.log_key(key="lane_{}_eh_mV".format(self.current_lane), value=self.eye_height[self.current_lane],
                         units='mV', upperlimit=self.eh_max, lowerlimit=self.eh_min)
        self.log_key(key="lane_{}_ew_ps".format(self.current_lane), value=self.eye_width[self.current_lane],
                         units='ui',upperlimit=self.ew_max, lowerlimit=self.ew_min)
        self.log_key(key="lane_{}_eh_ticks".format(self.current_lane), value=self.eye_height_ticks[self.current_lane], units='ticks')
        self.log_key(key="lane_{}_ew_ticks".format(self.current_lane), value=self.eye_width_ticks[self.current_lane], units='ticks')

        self.log_msg("Lane {}:  ns = {}ticks, ew = {}ticks".format(
                self.current_lane,
                self.eye_height[self.current_lane],
                self.eye_width[self.current_lane]
            ))


    #
    # Helpers
    #
    def progress(self):
        """Progress in integer % increments"""
        self.log_msg("   {}%".format(self._fake_progress))
        return self._fake_progress

    def is_running(self):
        """Check if Margining is running"""
        return self.progress < 100

    def all_lanes_scanned(self, lane):
        """Check if all lanes scanned, Used for tools that need to have individual lanes scanned"""
        if lane == self.LANE_COUNT:
            return 1
        else:
            self.log_msg("Didnt complete all lanes")

    def wait_for_finish(self):
        return 1
