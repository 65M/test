"""Access for iEFI"""
import sys
import logging
from .base import AbstractReceiverMarginTool
from shell import run
import os
import re

__all__ = [
    "MarginTool"
]

seq_log = logging.getLogger("sequence")


class MarginTool(AbstractReceiverMarginTool):
    """Margin Tool Instance"""

    def ensure_link(self):
        """Check Link meets Speed / Width requirements"""
        if self.product_code.upper() in ["J180"]:
            try:
                data = run("pcie --pick 4")
            except Exception as e:
                print(f"Exception: {e}")

            try:
                data = run("pcie --on")
            except Exception as e:
                print(f"Exception: {e}")

            try:
                data = run("pcie --pick 21")
            except Exception as e:
                print(f"Exception: {e}")

            try:
                data = run("pcie --on")
            except Exception as e:
                print(f"Exception: {e}")

            try:
                output = run("dh -p PciRootBridgeIo")
                for line in output.split("\n"):
                    m = re.search(r"(\w+): PCIRoot.*", line)
                    if m:
                        connect = m.group(1)
                        print(f"Found Connect Port: {connect}")
                        run(f"connect {connect}")

            except Exception as e:
                print(f"Exception: {e}")

            list_devices = run("listDevices.efi")
            for line in list_devices.split("\r\n"):
                print(f"line: {line}")
                if ("0000-" in line) or ("0001-" in line):
                    self.valid_bdf.append(line.replace(" ", ""))

            print(f"Valid BDF {self.valid_bdf}")

        else:
            run("pcie --pick {}".format(self.root_port))
            # Check PCIE Gen
            run("pcie --on")
            list_devices = run("listDevices.efi")
            print("List Device Output: {}".format(list_devices))
            run("pcie --set gen {}".format(self.gen_speed))
            pcie_log = run("pcie --get gen")
            gen = int(re.search(r"gen = (\d)", pcie_log).group(1))
            if gen != self.gen_speed:
                raise Exception(
                    "Failed to check PCIE Gen, expect=[%d], actual=[%d]" % (self.gen_speed, gen))

            list_devices = run("listDevices.efi")
            print("List Device Output: {}".format(list_devices))

    def dump_registers(self, initial=False):
        """Dump Static Registers"""

        if initial:
            self.log_msg("      Initial register dump")
        else:
            self.log_msg("      Skipping Initial register dump")
            print("Try List Devices")
            try:
                list_devices = run("listDevices.efi")
                print("List Devices: {}".format(list_devices))
            except Exception as e:
                print("Exception: {}".format(e))

            try:
                data = run("nandfs:\\AppleInternal\\Diags\\Apps\\readstat2 --snps")
                f = open(os.path.join(self.log_path, "debug_registers.log"), "w+")
                f.write(data)
                f.close()
                file = open(os.path.join(self.log_path, "debug_registers.log"), "r")

                debug_reg = file.read().strip("\r\n")
                debug_reg = debug_reg.split("\r\n")
                print(debug_reg)
                index_start = debug_reg.index('Lane 0:')
                index_end = debug_reg.index('Lane 1:')
                print(index_start)
                for i in range(index_start+1, index_end-1, 1):
                    print(debug_reg[i])
                    key_name = debug_reg[i].split(":")[0].strip(" ")
                    val_ticks = debug_reg[i].split(":")[1]
                    self.log_key(key="lane:{}_{}_ticks".format(self.current_lane, key_name),
                                 value=int(val_ticks),
                                 units='ticks')
                file.close()
            except Exception as e:
                print(f"Unable to dump registers with exception: {e}")

    def start_margining(self):
        if self.product_code.upper() in ["J180"]:
            print(f"Current Lane {self.current_lane} Device Index {self.device_index} Valid BDF {self.valid_bdf} Running on BDF {self.valid_bdf[int(self.device_index)]}")
            # nandfs:\\AppleInternal\\Diags\\Apps\\serdesEye2 -d "0000-07:00.0" -o "usbfs:\Desktop\sample0.txt" -lane 1
            self.margin_data = run("nandfs:\\AppleInternal\\Diags\\Apps\\serdesEye2 -d {} -o {} --lane {}".format(self.valid_bdf[int(self.device_index)], os.path.join(self.log_path, "sample{}.txt".format(self.current_lane)), self.current_lane))
        else:
            self.margin_data = run("nandfs:\\AppleInternal\\Diags\\Apps\\serdesEye2 -o {} --lane {}".format(os.path.join(self.log_path, "sample{}.txt".format(self.current_lane)), self.current_lane))
