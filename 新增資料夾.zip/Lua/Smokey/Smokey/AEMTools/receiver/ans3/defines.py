__all__ = [
    "ANS2_S4E_REGISTERS",
    "ANS2_SERVICE_ID",
	"AUSPMA_LANE0_registers",
	"AUSPMA_LANE0_SMGR_registers"
]

AUSPMA_LANE0_registers = {
    "APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_REQ_CFG4": 0xa1a0,
    'APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG13_EQ': 0xa030,
}

AUSPMA_LANE0_SMGR_registers = {
    'APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_EQ_REQ_CFG4': 0xa1a0,
    'APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_eq_eng1_cfg': 0xa1c0,
    'APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_eq_eng2_cfg': 0xa1c4,
    'APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_eq_eng3_cfg': 0xa1c8,
    'APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_eq_eng4_cfg': 0xa1cc,
    'APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_eq_eng5_cfg': 0xa1d0,
    'APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_eq_eng6_cfg': 0xa1d4,
    'APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_eq_eng7_cfg': 0xa1d8,
    'APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_eq_eng8_cfg': 0xa1dc,
    'APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG13_EQ': 0xa030,
    'APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG42_EQ': 0xa080,
    'APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG43_EQ': 0xa084,
    'APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG61_EQ': 0xa0c8,
    'APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG62_EQ': 0xa0cc,
    'APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG63_EQ': 0xa0d0,
    'APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG64_EQ': 0xa0dc,
    'APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG65_EQ': 0xa0e0,
    'APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG67_EQ': 0xa0e8,
    'APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG76_EQ': 0xa10c,
    'APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG82_EQ': 0xa0d4,
    'APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_eq_req_seq1_cfg1': 0xa1b0,
    'APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_eq_req_seq1_cfg2': 0xa1b4,
    'APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_eq_req_seq2_cfg1': 0xa1b8,
    'APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_eq_req_seq2_cfg2': 0xa1bc,
    'APCIE_DOWN_AUS_LANE0_AUSPMA_RX_TOP_perfcntr_cfg2': 0x9028,
    'APCIE_DOWN_AUS_LANE0_AUSPMA_RX_TOP_aeq_ctrl_dfe_status5': 0x92e0,
    'APCIE_DOWN_AUS_LANE0_AUSPMA_RX_TOP_aeq_ctrl_iqa_status6': 0x932c,
    'APCIE_DOWN_AUS_LANE0_AUSPMA_RX_TOP_aeq_ctrl_ctle_status1': 0x9298,
    'APCIE_DOWN_AUS_LANE0_AUSPMA_DFE_CTRL13_RO': 0xb110,
    'APCIE_DOWN_AUS_LANE0_AUSPMA_rx_rxa_dcoring_ctrl712_ro': 0xb10c,
    'APCIE_DOWN_AUS_LANE0_AUSPMA_rx_rxa_afe_ctrl16_ro': 0xb0f4,
}

ANS2_S4E_REGISTERS = {
    # Raw ANS2 register valuesupy main.py
    "0x8e90": "S5E_RX_EQ_CTRL_RAW_CAP1",
    "0x8e94": "S5E_RX_EQ_CTRL_RAW_CAP2",
    "0xb098": "ANS3_RX_EQ_CTRL_RAW_CAP1",
    "0xb09c": "ANS3_RX_EQ_CTRL_RAW_CAP2",
}


#
# ANS2 Service IDs
# https://confluence.sd.apple.com/display/FLASHSW/Debug+Service

# PCIe CFG Spec Defines
# https://seg-docs.csg.apple.com/projects/gibraltar//release/UserManual/regs_a0/pcie_rc0.html?baseaddr=0x710000000

# PHY register offsets
# Defined at https://seg-docs.csg.apple.com/projects/gibraltar/release/UserManual/regs_a0/chip__PCIE_STG0__APCIE_PHY_IP.html?baseaddr=0x0
#


class ANS2_SERVICE_ID(object):
    # Life Boot Mode
    LIFE_BOOT_MODE = 0x100

    LINK_STATUS = 0XA06
    # PG minimum Idle Time
    # Value in microseconds, multiples of 1000
    # Value of zero (0) means never - effectively disabling PG
    # Value of -1 (0xFFFFFFFF) means return to default
    PG_MIN_TIME = 0x300

    # Read Disturb Enable
    # 0x0 - Disable Read Disturb
    # 0x1 - Enable Read Disturb
    READ_DISTURB_ENABLE = 0x900

    # Smart CW Override
    # Get / Set SMART Critical warning Field
    # Each bit is a SMART warning bit
    SMART_CW_OVERRRIDE = 0x920

    # Reset CLOG and INF flow max number of Bands
    RESET_CLOG_COUNTERS = 0x930

    # Reset and Start CPU Utilization
    START_CPU_UTILIZATION = 0x931

    # Stop and Get CPU Utilization
    GET_CPU_UTILIZATION = 0x932

    # 0xA00 - S4E device ID
    # Write: Select which S4E to work with.
    # Read: Returns the last value written.
    S4E_ID = 0xA00

    # 0xA01 - PHY register address
    # Write: Sets the PHY address to read or write from. Only the lower 16 bits [15:0] are valid.
    # Read: Returns the last value written.
    PHY_REG = 0xA01

    # 0xA02 - PHY register data
    # Write: Writes to S4E PHY register.
    # Read: Reads from S4E PHY register.
    PHY_DATA = 0xA02

    # S4E config space address (0xA03)
    # Sets the config space address to read or write from:
    # Bits [11:0] - Offset
    # Bits [18:16] - Size (in bytes), only 1/2/4 are valid
    # Bit [24] - RP/EP. Set '1' to access root port (APCIE RC core) or '0' to access endpoint (S4E)
    CFG_SPACE_ADDR = 0xA03

    # S4E config space value
    # Data to write to config space, or data read from config space
    CFG_SPACE_DATA = 0xA04

    # ANS2 Downlink Control
    DOWN_PHY_REG = 0xA08
    DOWN_PHY_DATA = 0xA09

    # Downlink ASPM control
    # Write 0x0 to enable ASPM or 0x1 to disable ASPM for all downlinks
    ASPM_DISABLE = 0xA10

    # Platform Debug Flags
    # Boot-arg: nand-debug=0xXXXX will set  the bit flags
    # Bit 0 - Enable panic on AER
    # Bit 1 - Disable automatic gating of NAND_SYS_CLK
    PLATFORM_DEBUG_FLAGS_LOWER = 0xB00
    PLATFORM_DEBUG_FLAGS_UPPER = 0xB01

    # Axis Type
    # Write 0x0 to Scan All data, 0x1 for Axis only (full scan default)
    AXIS_ONLY = 0xB02

    # Error Mask
    # Write 0x0 for composite, 0x1 for odd, 0x2 for even
    ERROR_MASK = 0xB15

    # Test Duration
    # Duration in milliseconds, default is 200ms
    TEST_DURATION = 0xB03

    # Test Timeout
    # Duration in sec, default is 5sec
    TEST_TIMEOUT = 0xB04

    # Test Delay
    # Duration in microseconds, default is 512us
    TEST_DELAY = 0xB05

    # Minimum X (voltage) axis point
    # Values are 0 to -31, default is -31
    MIN_POINT_X = 0xB06

    # Maximum X (voltage) axis point
    # Values are 0 to 31, default is 31
    MAX_POINT_X = 0xB07

    # Minimum Y (time) axis point
    # Values are 0 to -31, default is -31
    MIN_POINT_Y = 0xB08

    # Maximum X (voltage) axis point
    # Values are 0 to 31, default is 31
    MAX_POINT_Y = 0xB09

    # X Step value (voltage)
    # Values are in millivolts, default is 1
    STEP_VALUE_X = 0xB0A

    # Y Step value (voltage)
    # Values are in usec, default is 1
    STEP_VALUE_Y = 0xB0B

    # Start Scan
    # No value required to start
    SCAN_START = 0xB0C

    # Phy to scan
    # Scan 0x0 - S4E or 0x01 - ANS, default S4E
    SCAN_ANS2_PHY = 0xB0E

    # Query progress (read)
    # Read: Progress value in 1% increments
    QUERY_PROGRESS = 0xB0D

    FE_DEBUG_SERVICE_EYE_SCAN_TEST_FINISH = 0xB11
