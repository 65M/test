# Apple NAND Storage (ANS) and Storage Controller (ie. S4E / S5E)


Flow per Carmel Yamberger / Amir Apel, details in <rdar://problem/48235504>
1. s4e/ans2 scan
2. axis only scan
3. max, max y
4. step x, step y
5. test time, delay and timeout
6. start test
7. get test progress

## Input Parameters
|Service Param|Address|Debug Service|Details
|------|-----|-----|-----
FE_DEBUG_SERVICE_EYE_SCAN_AXIS_ONLY|0xB02|WRITE|no val requires, full scan is the default
FE_DEBUG_SERVICE_EYE_SCAN_SET_TEST_DURATIN|0xB03|WRITE|in ms, default is 200ms
FE_DEBUG_SERVICE_EYE_SCAN_SET_TEST_TIMEOUT|0xB04|WRITE|in sec, default is 5 sec
FE_DEBUG_SERVICE_EYE_SCAN_SET_TEST_DELAY|0xB05|WRITE|in us, default is 512
FE_DEBUG_SERVICE_EYE_SCAN_SET_MIN_POINT_X|0xB06|WRITE|default is -31
FE_DEBUG_SERVICE_EYE_SCAN_SET_MAX_POINT_X|0xB07|WRITE|default is 31
FE_DEBUG_SERVICE_EYE_SCAN_SET_MIN_POINT_Y|0xB08|WRITE|default is -31
FE_DEBUG_SERVICE_EYE_SCAN_SET_MAX_POINT_Y|0xB09|WRITE|default is 31
FE_DEBUG_SERVICE_EYE_SCAN_SET_STEP_VALUE_X|0xB0A|WRITE|default is 1
FE_DEBUG_SERVICE_EYE_SCAN_SET_STEP_VALUE_Y|0xB0B|WRITE|default is 1
FE_DEBUG_SERVICE_EYE_SCAN_TEST_START|0xB0C|WRITE|no val requires. scan will start
FE_DEBUG_SERVICE_EYE_SCAN_SCAN_ANS2_PHY|0xB0E|WRITE|no val requires, default is s4e scan
FE_DEBUG_SERVICE_EYE_SCAN_QUERY_PROGRESS|0xB0D|READ|returns progress in percentages

none of the input params are mandatory, everything has a default value.

after scan is finished (when FE_DEBUG_SERVICE_EYE_SCAN_QUERY_PROGRESS returns 100%)

the data can be read by the read debug log command : FE_DEBUG_LOG_GET_EYE_SCAN_DATA = 0x74
the debug register can be read by setting log id tp 0x75 
The scan data is in TLV format, the buffer header is:
```
typedef struct {
    uint8_t x_axis_num_points;
    uint8_t y_axis_num_points;
    uint8_t num_of_static_regs;
    uint8_t spare[5];
}eye_scan_data_header_t;
```

and each TLV header is:

```
// TLV header
typedef struct {
    uint16_t type;
    uint16_t length;
} eye_scan_tlv_t;

typedef enum {
    DATA_TYPE_ERROR_TABLE,
    DATA_TYPE_STATIC_REGS_BEFORE_SCAN,
    DATA_TYPE_STATIC_REGS_AFTER_SCAN,
}eye_scan_data_type_e;
the error table is actually a 2D array of:
uint16_t errors[y_point][x_point]
```

and the table size is always (y_axis_num_points * x_axis_num_points) even for axis_only (all the points that are not on axis will have a 0 value)

as for the static registers, per each reg the entry is -
```
typedef struct {
    uint32_t offset;
    uint32_t value;
}static_registers_t;
```
and the  list of registers is the same one from the python code.

you’ll need 3 buffers to get the entire data.

Raw data is a matrix of 63x63, if mix/max is +/-31 and each cell is 2 bytes.