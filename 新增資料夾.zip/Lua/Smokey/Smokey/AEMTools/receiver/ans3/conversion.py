_all_ = [
    "conversion_registers"
]


def conv_and_six_lsb(value):
    """{raw} AND with 0X7F"""
    val = value
    return val & 0x3f


def conv_sub_64_if_gt_31(value):
    """{val}-64 if {val}>31 else {val}"""
    val = value
    return val - 64 if val > 31 else val


def conv_sub_64_if_gt_32(value):
    """{val}-64 if {val}>32 else {val}"""
    val = value
    return val - 64 if val > 32 else val
    

def get_bits(value, start_bit, length):
    """Read registers"""
    bin_val = '{:>032}'.format(bin(value)[2:])
    end_pos = 31 - start_bit + 1
    start_pos = 31 - start_bit - length + 1
    bits = int(bin_val[start_pos:end_pos], 2)
    return bits


def gray2dec( i=0, total_bits=63):
    """ convert gray to dec """
    return [dec2gray(d) for d in range(total_bits)].index(i)


def dec2gray( i=0):
    """ convert dec to gray """
    return i ^ i >> 1

class conversion_registers():
    """Class for conversion of registers"""
    def __init__(self, *args, **kwargs):
        super(conversion_registers, self).__init__(*args, **kwargs)

    def S5E_RX_EQ_CTRL_RAW_CAP1(self, value, lane):
        out = []
        cs_ticks = gray2dec(get_bits(value, 4, 4))
        out.append([
            "S5E_lane:{}_cs_ticks".format(lane),  cs_ticks, "ticks_d"
        ])
        cs = self.CONVERSION_OFFSET_FACTORS["c"] + self.CONVERSION_MULTIPLICATION_FACTORS["c"]*\
             gray2dec(get_bits(value, 4, 4))
        out.append([
            "S5E_lane:{}_cs".format(lane),  cs, "db"
        ])
        #out.append({
            #"S5E_lane:{}_cs".format(lane), cs, "ticks"
        #})
        rs_ticks = gray2dec(get_bits(value, 0, 4))
        out.append([
            "S5E_lane:{}_rs_ticks".format(lane), rs_ticks, "ticks_d"
        ])
        rs = self.CONVERSION_OFFSET_FACTORS["r"] + self.CONVERSION_MULTIPLICATION_FACTORS["r"]*gray2dec(get_bits(value, 0, 4))
        out.append([
            "S5E_lane:{}_rs".format(lane), rs, "db"
        ])
        h1_ticks = gray2dec(get_bits(value, 8, 5))
        out.append([
            "S5E_lane:{}_h1_ticks".format(lane), h1_ticks, "ticks_d"
        ])
        h1 = self.CONVERSION_MULTIPLICATION_FACTORS["h1"]*gray2dec(get_bits(value, 8, 5))
        out.append([
            "S5E_lane:{}_h1".format(lane), h1, "mV"
        ])
        sign = get_bits(value, 16, 1)
        if sign is 1:
            h2_sign = -1
        else:
            h2_sign = 1
        h2_ticks = gray2dec(get_bits(value, 13, 4))
        out.append([
            "S5E_lane:{}_h2_ticks".format(lane), h2_ticks, "ticks_d"
        ])
        h2 =h2_sign * self.CONVERSION_MULTIPLICATION_FACTORS["h2"]*gray2dec(get_bits(value, 13, 3))
        out.append([
            "S5E_lane:{}_h2".format(lane), h2, "mV"
        ])
        sign1 = get_bits(value, 21, 1)
        if sign1 is 1:
            h3_sign = -1
        else:
            h3_sign = 1
        h3_ticks = gray2dec(get_bits(value, 17, 4))
        out.append([
            "S5E_lane:{}_h3_ticks".format(lane), h3_ticks, "ticks_d"
        ])
        h3 = h3_sign * self.CONVERSION_MULTIPLICATION_FACTORS["h3"]*gray2dec(get_bits(value, 17, 3))
        out.append([
            "S5E_lane:{}_h3".format(lane), h3, "mV"
        ])
        sign2 = get_bits(value, 24, 1)
        if sign2 is 1:
            h4_sign = -1
        else:
            h4_sign = 1
        h4_ticks = gray2dec(get_bits(value, 21, 4))
        out.append([
            "S5E_lane:{}_h4_ticks".format(lane), h4_ticks, "ticks_d"
        ])
        h4 = h4_sign * self.CONVERSION_MULTIPLICATION_FACTORS["h4"]*gray2dec(get_bits(value, 21, 3))
        out.append([
            "S5E_lane:{}_h4".format(lane), h4, "mV"
        ])
        sign3 =  get_bits(value, 28, 1)
        if sign3 is 1:
            h5_sign = -1
        else:
            h5_sign = 1
        h5_ticks = gray2dec(get_bits(value, 25, 4))
        out.append([
            "S5E_lane:{}_h5_ticks".format(lane), h5_ticks, "ticks_d"
        ])
        h5 = h5_sign * self.CONVERSION_MULTIPLICATION_FACTORS["h5"]*gray2dec(get_bits(value, 25, 3))
        out.append([
            "S5E_lane:{}_h5".format(lane), h5, "mV"
        ])
        return out

    def S5E_RX_EQ_CTRL_RAW_CAP2(self, value, lane):
        print(f"Value: {value}")
        out = []
        xclk_pos = gray2dec(get_bits(value, 0, 7))
        out.append([
            "S5E_lane:{}_xclk".format(lane), xclk_pos, "ticks"
        ])
        xclkb_pos = gray2dec(get_bits(value, 7, 7))
        out.append([
            "S5E_lane:{}_xclkb".format(lane), xclkb_pos, "ticks"
        ])

        dclkb_pos = gray2dec(get_bits(value, 21, 7))
        out.append([
            "S5E_lane:{}_dclkb".format(lane), dclkb_pos, "ticks"
        ])
         
        dclk_pos = gray2dec(get_bits(value, 14, 7))
        out.append([
            "S5E_lane:{}_dclk".format(lane), dclk_pos, "ticks"
        ])
        return out

    def ANS3_RX_EQ_CTRL_RAW_CAP1(self, value, lane):
        out = []
        cs_ticks = gray2dec(get_bits(value, 4, 4))
        out.append([
            "ANS3_lane:{}_cs_ticks".format(lane), cs_ticks, "ticks_d"
        ])
        cs = self.CONVERSION_OFFSET_FACTORS["c"] + self.CONVERSION_MULTIPLICATION_FACTORS["c"]*gray2dec(get_bits(value, 4, 4))
        out.append([
            "ANS3_lane:{}_cs".format(lane), cs, "db"
        ])
        rs_ticks = gray2dec(get_bits(value, 0, 4))
        out.append([
            "ANS3_lane:{}_rs_ticks".format(lane), rs_ticks, "ticks_d"
        ])
        rs =  self.CONVERSION_OFFSET_FACTORS["r"] + self.CONVERSION_MULTIPLICATION_FACTORS["r"]*gray2dec(get_bits(value, 0, 4))
        out.append([
            "ANS3_lane:{}_rs".format(lane), rs, "db"
        ])
        h1_ticks = gray2dec(get_bits(value, 8, 5))
        out.append([
            "ANS3_lane:{}_h1_ticks".format(lane), h1_ticks, "ticks_d"
        ])
        h1 = self.CONVERSION_MULTIPLICATION_FACTORS["h1"]*gray2dec(get_bits(value, 8, 5))
        out.append([
            "ANS3_lane:{}_h1".format(lane), h1, "mV"
        ])
        sign = get_bits(value, 16, 1)
        if sign is 1:
            h2_sign = -1
        else:
            h2_sign = 1
        h2_ticks = gray2dec(get_bits(value, 13, 4))
        out.append([
            "ANS3_lane:{}_h2_ticks".format(lane), h2_ticks, "ticks_d"
        ])
        h2 = h2_sign * self.CONVERSION_MULTIPLICATION_FACTORS["h2"]*gray2dec(get_bits(value, 13, 3))
        out.append([
            "ANS3_lane:{}_h2".format(lane), h2, "mV"
        ])
        sign1 = get_bits(value, 21, 1)
        if sign1 is 1:
            h3_sign = -1
        else:
            h3_sign = 1
        h3_ticks = gray2dec(get_bits(value, 17, 4))
        out.append([
            "ANS3_lane:{}_h3_ticks".format(lane), h3_ticks, "ticks_d"
        ])
        h3 = h3_sign * self.CONVERSION_MULTIPLICATION_FACTORS["h3"]*gray2dec(get_bits(value, 17, 3))
        out.append([
            "ANS3_lane:{}_h3".format(lane), h3, "mV"
        ])
        sign2 = get_bits(value, 24, 1)
        if sign2 is 1:
            h4_sign = -1
        else:
            h4_sign = 1
        h4_ticks = gray2dec(get_bits(value, 21, 4))
        out.append([
            "ANS3_lane:{}_h4_ticks".format(lane), h4_ticks, "ticks_d"
        ])
        h4 = h4_sign * self.CONVERSION_MULTIPLICATION_FACTORS["h4"]*gray2dec(get_bits(value, 21, 3))
        out.append([
            "ANS3_lane:{}_h4".format(lane), h4, "mV"
        ])
        sign3 =  get_bits(value, 28, 1)
        if sign3 is 1:
            h5_sign = -1
        else:
            h5_sign = 1
        h5_ticks = gray2dec(get_bits(value, 25, 4))
        out.append([
            "ANS3_lane:{}_h5_ticks".format(lane), h5_ticks, "ticks_d"
        ])
        h5 = h5_sign * self.CONVERSION_MULTIPLICATION_FACTORS["h5"]*gray2dec(get_bits(value, 25, 3))
        out.append([
            "ANS3_lane:{}_h5".format(lane), h5, "mV"
        ])
        return out

    def ANS3_RX_EQ_CTRL_RAW_CAP2(self, value, lane):
        out = []
        xclk_pos = gray2dec(get_bits(value, 0, 7))
        out.append([
         "ANS3_lane:{}_xclk".format(lane), xclk_pos, "ticks"
        ])
         
        xclkb_pos = gray2dec(get_bits(value, 7, 7))
        out.append([
            "ANS3_lane:{}_xclkb".format(lane), xclkb_pos, "ticks"
        ])
         
        dclkb_pos = gray2dec(get_bits(value, 21, 7))
        out.append([
            "ANS3_lane:{}_dclkb".format(lane), dclkb_pos, "ticks"
        ])
         
        dclk_pos = gray2dec(get_bits(value, 14, 7))
        out.append([
            "ANS3_lane:{}_dclk".format(lane), dclk_pos, "ticks"
        ])
        return out

    def S5E_RXA_SAVOS_CTRL16(self, value, lane):
        out = []
        rxterm_code = get_bits(value, 15, 5)
        out.append([
            "S5E_lane:{}_rxterm_code".format(lane), rxterm_code, "ticks"
        ])
        return out

    def AFE_CTRL16_RO(self, value, lane):
        out = []
        cs_ticks = gray2dec(get_bits(value, 7, 4))
        out.append([
            "ANS3_lane:{}_cs_ticks".format(lane), cs_ticks, "ticks_d"
        ])
        cs = self.CONVERSION_OFFSET_FACTORS["c"] + self.CONVERSION_MULTIPLICATION_FACTORS["c"] * cs_ticks
        out.append([
            "ANS3_lane:{}_cs".format(lane), cs, "db"
        ])

        rs_ticks = gray2dec(get_bits(value, 19, 4))
        out.append([
            "ANS3_lane:{}_rs_ticks".format(lane), rs_ticks, "ticks_d"
        ])
        rs = self.CONVERSION_OFFSET_FACTORS["r"] + self.CONVERSION_MULTIPLICATION_FACTORS["r"] * rs_ticks
        out.append([
            "ANS3_lane:{}_rs".format(lane), rs, "db"
        ])
        return out

    def DFE_CTRL13_RO(self, value, lane):
        out = []
        h1_ticks = gray2dec(get_bits(value, 10, 5))

        sign = get_bits(value, 15, 1)
        if sign is 1:
            h1_sign = -1
        else:
            h1_sign = 1

        out.append([
            "ANS3_lane:{}_h1_ticks".format(lane), h1_ticks, "ticks_d"
        ])
        h1 = self.CONVERSION_MULTIPLICATION_FACTORS["h1"] * h1_ticks * h1_sign
        out.append([
            "ANS3_lane:{}_h1".format(lane), h1, "mV"
        ])

        sign2 = get_bits(value, 3, 1)
        if sign2 is 1:
            h4_sign = -1
        else:
            h4_sign = 1
        h4_ticks = gray2dec(get_bits(value, 0, 3))
        out.append([
            "ANS3_lane:{}_h4_ticks".format(lane), h4_ticks, "ticks_d"
        ])
        h4 = h4_sign * self.CONVERSION_MULTIPLICATION_FACTORS["h4"] * h4_ticks
        out.append([
            "ANS3_lane:{}_h4".format(lane), h4, "mV"
        ])

        sign3 = get_bits(value, 8, 1)
        if sign3 is 1:
            h5_sign = -1
        else:
            h5_sign = 1
        h5_ticks = gray2dec(get_bits(value, 5, 3))
        out.append([
            "ANS3_lane:{}_h5_ticks".format(lane), h5_ticks, "ticks_d"
        ])
        h5 = h5_sign * self.CONVERSION_MULTIPLICATION_FACTORS["h5"] * h5_ticks
        out.append([
            "ANS3_lane:{}_h5".format(lane), h5, "mV"
        ])
        return out

    def DCORING_CTRL712_RO(self, value, lane):
        out = []
        sign = get_bits(value, 24, 1)
        if sign is 1:
            h2_sign = -1
        else:
            h2_sign = 1
        h2_ticks = gray2dec(get_bits(value, 21, 4))
        out.append([
            "ANS3_lane:{}_h2_ticks".format(lane), h2_ticks, "ticks_d"
        ])
        h2 = h2_sign * self.CONVERSION_MULTIPLICATION_FACTORS["h2"]*h2_ticks
        out.append([
            "ANS3_lane:{}_h2".format(lane), h2, "mV"
        ])
        sign1 = get_bits(value, 29, 1)
        if sign1 is 1:
            h3_sign = -1
        else:
            h3_sign = 1
        h3_ticks = gray2dec(get_bits(value, 26, 3))
        out.append([
            "ANS3_lane:{}_h3_ticks".format(lane), h3_ticks, "ticks_d"
        ])
        h3 = h3_sign * self.CONVERSION_MULTIPLICATION_FACTORS["h3"]*h3_ticks
        out.append([
            "ANS3_lane:{}_h3".format(lane), h3, "mV"
        ])
        return out

    def RXA_DCO_CTRL89_RO(self, value, lane):
        out = []
        dclkb_pos = gray2dec(get_bits(value, 21, 7))
        out.append([
            "ANS3_lane:{}_dclkb".format(lane), dclkb_pos, "ticks"
        ])

        dclk_pos = gray2dec(get_bits(value, 14, 7))
        out.append([
            "ANS3_lane:{}_dclk".format(lane), dclk_pos, "ticks"
        ])
        return out

    def DCOPI_CTRL10_RO(self, value, lane):
        out = []
        xclk_pos = gray2dec(get_bits(value, 0, 7))
        out.append([
            "ANS3_lane:{}_xclk".format(lane), xclk_pos, "ticks"
        ])
        xclkb_pos = gray2dec(get_bits(value, 7, 7))
        out.append([
            "ANS3_lane:{}_xclkb".format(lane), xclkb_pos, "ticks"
        ])
        return out

    CONVERSION_REGISTER_ADDRESSES = [{
        "0x8e90": {"func": S5E_RX_EQ_CTRL_RAW_CAP1},
        "0x8e94": {"func": S5E_RX_EQ_CTRL_RAW_CAP2},
        "0x8e40": {"func": S5E_RXA_SAVOS_CTRL16},
        "0x3098": {"func": ANS3_RX_EQ_CTRL_RAW_CAP1},
        "0xb098": {"func": ANS3_RX_EQ_CTRL_RAW_CAP1},
        "0x13098": {"func": ANS3_RX_EQ_CTRL_RAW_CAP1},
        "0x1b098": {"func": ANS3_RX_EQ_CTRL_RAW_CAP1},
        "0xb09c": {"func": ANS3_RX_EQ_CTRL_RAW_CAP2},
        "0xb0f4": {"func": AFE_CTRL16_RO},
        "0xb110": {"func": DFE_CTRL13_RO},
        "0xb10c": {"func": DCORING_CTRL712_RO},
        "0xb100": {"func": RXA_DCO_CTRL89_RO},
        "0xb104": {"func": DCOPI_CTRL10_RO},
        "0x1309c": {"func": ANS3_RX_EQ_CTRL_RAW_CAP2},
        "0x130f4": {"func": AFE_CTRL16_RO},
        "0x13110": {"func": DFE_CTRL13_RO},
        "0x1310c": {"func": DCORING_CTRL712_RO},
        "0x13100": {"func": RXA_DCO_CTRL89_RO},
        "0x13104": {"func": DCOPI_CTRL10_RO},
        "0x1b0f4": {"func": AFE_CTRL16_RO},
        "0x1b110": {"func": DFE_CTRL13_RO},
        "0x1b10c": {"func": DCORING_CTRL712_RO},
        "0x1b100": {"func": RXA_DCO_CTRL89_RO},
        "0x1b104": {"func": DCOPI_CTRL10_RO},
        "0x2309c": {"func": ANS3_RX_EQ_CTRL_RAW_CAP2},
        "0x230f4": {"func": AFE_CTRL16_RO},
        "0x23110": {"func": DFE_CTRL13_RO},
        "0x2310c": {"func": DCORING_CTRL712_RO},
        "0x23100": {"func": RXA_DCO_CTRL89_RO},
        "0x23104": {"func": DCOPI_CTRL10_RO},
        "0x23098": {"func": ANS3_RX_EQ_CTRL_RAW_CAP1},
    }]






