"""Access for OS"""

import sys
import logging
from .base import AbstractReceiverMarginTool

try:
    import nvmectl
except ImportError:
    if sys.platform == "darwin":
        raise Exception("Ensure you are running in Python3 environment")

__all__ = [
    "MarginTool"
]

seq_log = logging.getLogger("sequence")


def _nvmectl_status_return_data(nvmectl_status):
    """Check if status is valid, raise exception if not"""
    seq_log.debug("      status=0x{:X} NVMeStatus=0x{:X} dword0=0x{:X} time={}".format(nvmectl_status.fReturn,
                                                                                       nvmectl_status.fNVMeStatus,
                                                                                       nvmectl_status.fCommandSpecificData,
                                                                                       nvmectl_status.fExecutionTime))

    # nvmectl status: .fReturn, .fNVMeStatus, .fCommandSpecificData, .fExecutionTime
    if nvmectl_status.fReturn != 0 or nvmectl_status.fNVMeStatus != 0:
        raise Exception(
            "nvmectl returned bad status 0x{:X} 0x{:X}".format(nvmectl_status.fReturn, nvmectl_status.fNVMeStatus))

    # Return the command data
    return nvmectl_status.fCommandSpecificData


class MarginTool(AbstractReceiverMarginTool):
    """Margin Tool Instance"""

    def __init__(self, *args, **kwargs):
        self.nvmectl = nvmectl.NVMeCTL("disk0")
        super(MarginTool, self).__init__(*args, **kwargs)

    def get_identify_controller(self):
        """Get Identify Controller Data"""
        data = nvmectl.NVMeIdentifyControllerStruct()
        _nvmectl_status_return_data(self.nvmectl.IdentifyController(data))
        return data

    def get_lane_count(self):
        """Return the number of MCP Landings present using the 'NUM_OF_LANDINGS' from Identify Controller"""
        return self.get_identify_controller().NUM_OF_LANDINGS

    def get_nand_size(self):
        """Return the NAND capacity"""
        return self.get_identify_controller().SSD_Capacity

    def debug_service_write(self, register, value):
        """Debug Service Write"""
        seq_log.debug("      Debug Service Write 0x{:04X} = 0x{:04X}".format(register, value))
        _nvmectl_status_return_data(self.nvmectl.DebugServiceWrite(register, value))

    def debug_service_read(self, register):
        """Debug Service Read"""
        seq_log.debug("      Debug Service Read 0x{:04X}".format(register))
        return _nvmectl_status_return_data(self.nvmectl.DebugServiceRead(register))

    def debug_data_read(self, log_id, param0, param1, log_size):
        """Debug Data Read"""
        buf = nvmectl.charArray(log_size)
        seq_log.debug(
            "      Debug Data Read id=0x{:04X}, p0={}, p1={} for {} bytes".format(log_id, param0, param1, log_size))
        data_len = _nvmectl_status_return_data(self.nvmectl.ReadDebugData(buf, log_size, log_id, param0, param1))
        seq_log.debug("      Debug Data Read {} bytes".format(data_len))
        return buf, data_len
