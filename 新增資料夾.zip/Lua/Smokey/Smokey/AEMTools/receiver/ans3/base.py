import struct
from .defines import *
from ..base import AbstractBaseMarginTool
from .conversion import conversion_registers
from .soc_defines import *


__all__ = [
    "AbstractReceiverMarginTool"
]


class AbstractReceiverMarginTool(AbstractBaseMarginTool):
    """Generic Interface for ANS (Apple NAND System) Margining"""
    LANE_COUNT = None  # This needs to be set at run time (it's base on the system)
    TIMEOUT = 180  # Set timeout to 2min (Average is 1-1.5)
    POLL_TIME = 2  # Poll every 2 seconds
    DEBUG_LOG = 0x74
    DEBUG_REGISTERS = 0x75

    # The PHY Register and Data Debug Services
    ROOT_PORT = True  # Root Port
    PHY_REG = ANS2_SERVICE_ID.PHY_REG  # Phy Register Selector
    PHY_DATA = ANS2_SERVICE_ID.PHY_DATA  # Phy Data Selector
    STATIC_REGISTERS = ANS2_S4E_REGISTERS  # Static Registers
    all_data = []
    reg_data = []
    ERROR_COUNT = []
    ORIGIN_X = 0
    ORIGIN_Y = 0
    env = 'efi'
    res_data = []
    res_vol_data = []
    res_pi_data = []
    mid_y = 0
    mid_x = 0

    CONVERSION_MULTIPLICATION_FACTORS = {
        "h0": 10,
        "h1": 13,
        "h2": 4,
        "h3": 4,
        "h4": 4,
        "h5": 4,
        "c": 0.5,
        "r": 0.6
    }

    CONVERSION_OFFSET_FACTORS = {
        "c": 4,
        "r": -5.5
    }

    def __init__(self, *args, **kwargs):
        super(AbstractReceiverMarginTool, self).__init__(*args, **kwargs)

        # Dynamically set the number of lanes by using Identify Controller
        self.LANE_COUNT = self.get_lane_count()
        self.CAPACITY = str(self.get_nand_size())
        self.valid_lanes = []
        self.register_read_dclks = [None] * 16
        print("Lane Count: {} Capacity: {} Endpoint: {} Product Code: {} Letter Code: {}".format(self.LANE_COUNT, self.CAPACITY, self.endpoint, self.product_code, self.letter_code))

        # Temporarily DOE Block for Failure # Requested By Rae / Renuka / Junjie #
        # if self.CAPACITY == "8192GB" and self.endpoint.upper() == "S5E" and self.product_code == "J375" and self.letter_code.upper() == "D":
        #     print("Raising Exception Lane Count")
        #     raise Exception("Per Rae, Renuka, we want to skip 8TB configs to prevent hangs")
        # print("Valid Lane Count")
        # Temporarily DOE Block for Failure #

        self._previous_percent = -1

    def get_identify_controller(self):
        """Get Identify Controller Data"""

    def get_lane_count(self):
        """Return the number of MCP Landings present using the 'NUM_OF_LANDINGS' from Identify Controller"""

    def get_nand_size(self):
        """Return the NAND capacity"""

    def debug_service_write(self, register, value):
        """Debug Service Write"""

    def debug_service_read(self, register):
        """Debug Service Write"""

    def debug_data_read(self, log_id, param0, param1, log_size):
        """Debug Data Read"""

    def disable_power_management(self):
        """Disable Power Management Modes"""
        self.log_msg("IN HERE")
        self.debug_service_write(ANS2_SERVICE_ID.ASPM_DISABLE, 1)
    #
    # Active Lane (ANS or MCP) Register RW functions
    #

    def set_active_register(self, offset):
        """Set the active register to read and write from for the active S4E"""
        # Set the register to writef
        self.debug_service_write(register=self.PHY_REG, value=offset)

        # Verify the offset value is correct
        current_offset = self.debug_service_read(register=self.PHY_REG)
        if current_offset != offset:
            raise Exception("Failed to set active register to {}. Stuck at {}".format(offset, current_offset))

    def write_phy_register(self, offset, value):
        """Use the debug service write to write the active S4E"""
        # Select the register
        self.set_active_register(offset=offset)

        # Write the register
        self.debug_service_write(register=self.PHY_DATA, value=value)

    def read_phy_register(self, offset):
        """Use the debug service commands to get the register value of the active S4E"""
        # Set the register to read
        self.set_active_register(offset=offset)

        # Read and return the register
        return self.debug_service_read(register=self.PHY_DATA)

    def get_bits(self, value, start_bit, length):
        """Read registers"""
        bin_val = '{:>032}'.format(bin(value)[2:])
        end_pos = 31 - start_bit + 1
        start_pos = 31 - start_bit - length + 1
        bits = int(bin_val[start_pos:end_pos], 2)
        return bits
    #
    # PCIe Config Space Manipulation
    #
    def pcie_cfg_set_active_register(self, offset, size_in_bytes):
        """Set the active config space register for manipulation"""
        # Ensure the masked value is the less than 12 bits
        if offset > 0xFFF:
            raise Exception("Invalid PCIe config space offset 0x{:X}. Can not be greater than 12 bits".format(offset))

        # Ensure valid size in bytes
        if size_in_bytes not in [1, 2, 4]:
            raise Exception("Invalid PCIe config space size in bytes {}".format(size_in_bytes))

        # Bits [11:0] - Offset
        # Bits [18:16] - Size (in bytes), only 1/2/4 are valid
        # Bit [24] - RP/EP. Set '1' to access root port (APCIE RC core) or '0' to access endpoint (S4E)
        offset = (1 << 24 if self.ROOT_PORT else 0) + (size_in_bytes << 16) + (offset & 0xFFF)

        # Set the register to write
        self.debug_service_write(register=ANS2_SERVICE_ID.CFG_SPACE_ADDR, value=offset)

        # Verify the offset value is correct
        current_val = self.debug_service_read(register=ANS2_SERVICE_ID.CFG_SPACE_ADDR)
        if current_val != offset:
            raise Exception("Failed to set active register to {}. Stuck at {}".format(offset, current_val))

    def pcie_cfg_read_register(self, offset, size):
        """Read from config space for the specified PCIe lane index root port"""
        self.pcie_cfg_set_active_register(offset=offset, size_in_bytes=size)

        # Read the register
        return self.debug_service_read(register=ANS2_SERVICE_ID.CFG_SPACE_DATA)

    def pcie_cfg_write_register(self, offset, size, value):
        """Write to config space for the specified PCIe lane index end port"""
        self.pcie_cfg_set_active_register(offset=offset, size_in_bytes=size)

        # Write the register
        self.debug_service_write(register=ANS2_SERVICE_ID.CFG_SPACE_DATA, value=value)

    #
    # Execution Flow
    #
    def set_adaptation(self, figure_of_merit):
        """Set the Adaptation Type (if applicable)"""
        self.log_msg("   Setting Adaptation to {}".format(figure_of_merit))

    def padded_hex(self, i, l):
        given_int = i
        given_len = l

        hex_result = hex(given_int)[2:]  # remove '0x' from beginning of str
        num_hex_chars = len(hex_result)
        extra_zeros = '0' * (given_len - num_hex_chars)  # may not get used..

        return ('0x' + hex_result if num_hex_chars == given_len else
                '?' * given_len if num_hex_chars > given_len else
                '0x' + extra_zeros + hex_result if num_hex_chars < given_len else
                None)

    def configure_phy(self):
        """Configure the PHY Settings, Overrides, ECO, etc"""
        pass

    def convert_register(self, offset, value):
        """Convert raw registers to ticks and electrical values"""
        print(f"Checking Register Offset (Last 4): {offset} Value: {value}")
        if offset in conversion_registers.CONVERSION_REGISTER_ADDRESSES[0]:
            print(f"Calling Function: {conversion_registers.CONVERSION_REGISTER_ADDRESSES[0][offset]['func']}")
            out = conversion_registers.CONVERSION_REGISTER_ADDRESSES[0][offset]["func"](self, value, self.current_lane)
            for m in range(0, len(out)):
                # print(f"key_name {out[m][0]}")
                if self.endpoint is "ans3":
                    if f"ans3_lane:{self.current_lane}_dclk" in out[m][0].lower():
                        self.register_read_dclks[self.current_lane] = out[m][1]

                if self.endpoint is "s5e":
                    if f"s5e_lane:{self.current_lane}_dclk" in out[m][0].lower():
                        self.register_read_dclks[self.current_lane] = out[m][1]

                self.log_key(key=out[m][0], value=out[m][1], units=out[m][2])
        else:
            print("Register Offset Not Found")
            return 1

    def set_traffic_type(self, traffic_type):
        """Select the Traffic type (Live, PRBS, etc)"""
        self.log_msg("   Setting Traffic Type to {}".format(traffic_type))

    def apply_settings(self, retrain=True):
        """Apply EQ and other settings, retrain (if applicable)"""

    def check_link(self, timeframe):
        """Check Link meets Speed / Width requirements"""
        # Get the Link Status, and calculate the Link Width / Speed
        link_status = self.debug_service_read(ANS2_SERVICE_ID.LINK_STATUS)
        link_status_stk1 = link_status >> 16
        self.log_msg("Link status {} is: {}".format(timeframe, link_status))
        print("Link Status {} is: {}".format(timeframe, link_status))
        # link_status = int(self.pcie_cfg_read_register(0x82, 2))
        lane_start = 0
        while lane_start < self.LANE_COUNT:
            link_speed = link_status & 0xF
            link_status = link_status >> 4

            # >1 stack doesn't work for this split
            link_speed_stk1 = link_status_stk1 & 0xF
            link_status_stk1 = link_status_stk1 >> 4

            # Verify the Speed / Width Matches
            self.log_msg("   Link Status {} for landing number {} {}".format(timeframe, lane_start, link_speed))
            if timeframe == "test start":
                if self.gen_speed == link_speed:
                    print("Gen Speed Matches Link Speed for Lane: {} STK 0".format(lane_start))
                    self.valid_lanes.append(lane_start)

                # For 8 lanes there's two valid stacks so we need to avoid doubling up
                if self.gen_speed == link_speed_stk1 and self.LANE_COUNT == 4:
                    lane = lane_start + 4
                    print("Gen Speed Matches Link Speed for Lane: {} STK 1".format(lane))
                    self.valid_lanes.append(lane)

            if (self.gen_speed != link_speed) and (self.gen_speed != link_speed_stk1):
                raise Exception(
                    "   Link Speed Stk 1 Gen {} and Stk 2 Gen {} does not match requirement Gen {}".format(timeframe, link_speed, link_speed_stk1, self.gen_speed))
            lane_start = lane_start + 1

        print("Valid Lanes: {}".format(self.valid_lanes))

    # No settings to apply
    def ensure_link(self):
        """Check Link meets Speed / Width requirements"""
        self.check_link("test start")
        # If we are running just stop
        prog = self.progress()
        if 100 > prog > 0:
            raise Exception("Margining in progress ({}%), aborting access".format(prog))

    def select_lane(self, lane):
        """Select a Lane"""

    # Not applicable, all lanes are margined together

    def _set_setting(self, register, value):
        """Set a setting if the value is defined"""
        if value is not None:
            self.debug_service_write(register=register, value=value)

    def setup_margining(self):
        """Configure the PHY and Setup Margining"""
        # Select the Phy
        self.log_msg("   Selecting {} to margin".format("ANS2" if self.ROOT_PORT else "S4E"))
        self.debug_service_write(register=ANS2_SERVICE_ID.SCAN_ANS2_PHY, value=1 if self.ROOT_PORT else 0)

        # Set the Axis Types
        self.log_msg("   Running with {} Scan Type".format("Axis Only" if self.axis_only else "Full"))
        self.debug_service_write(register=ANS2_SERVICE_ID.AXIS_ONLY, value=1 if self.axis_only else 0)

        # Set the error type
        self.log_msg("   Running with {} Error mask".format(self.error_mask))
        print("Running with {} Error mask".format(self.error_mask))
        self.debug_service_write(register=ANS2_SERVICE_ID.ERROR_MASK, value=self.error_mask)

        # Set the X Axis Values
        # self.log_msg("   Setting X: {} to {} with {}mV step size".format(self.min_x, self.max_x,
        #                                                                  self.step_x))
        # self._set_setting(register=ANS2_SERVICE_ID.MIN_POINT_X, value=self.min_x)
        # self._set_setting(register=ANS2_SERVICE_ID.MAX_POINT_X, value=self.max_x)
        # self._set_setting(register=ANS2_SERVICE_ID.STEP_VALUE_X, value=self.step_x)

        if self.doe is True:
            self.debug_service_write(register=ANS2_SERVICE_ID.TEST_DURATION, value= self.duration_ms)

        # Set the Y Axis Values
        self.log_msg("   Setting Y: {} to {} with {}us step size".format(self.min_y, self.max_y,
                                                                         self.step_y))

        # Set the Dwell / Timeout
        self.log_msg("   Setting {}ms Dwell Time, {}us Delay between Points, {}s Timeout".format(
            self.duration_ms or "200",
            self.delay_us or "512",
            self.timeout_s or "5",
        )
        )

    def direct_register_printout(self, current_lane):
        ans3_pcie_num = int(current_lane / 4)
        ans3_auspma_lane = current_lane % 4

        soc_defines = SOC_CONVERSION_CODE[self.soc]
        pcie_address_offset = soc_defines['ANS3_PCIE0'] + soc_defines['SOC_AUS_LANE0'] + (ans3_auspma_lane * soc_defines['SOC_LANE_OFFSET'])

        if ans3_pcie_num > 3 and "ANS3_PCIE_offset" in soc_defines:
            pcie_address_offset += (ans3_pcie_num * soc_defines["ANS3_PCIE_offset"])
        elif ans3_pcie_num > 3:
            print(f"{self.soc} is not setup correctly for ans3 register printout. Report to AEMTools DRI")
            return

        print(f"Trying to read from ans3 {current_lane} at address {pcie_address_offset}")

        h0_smgr = self.CONVERSION_MULTIPLICATION_FACTORS["h0"] * self.get_bits(pcie_address_offset + AUSPMA_LANE0_registers['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_REQ_CFG4'], 0, 6)

        SMGR_seq_ptr = self.get_bits(pcie_address_offset +
                                     AUSPMA_LANE0_registers['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_REQ_CFG4'], 28,
                                     4)
        SMGR_best_eng = self.get_bits(pcie_address_offset +
                                      AUSPMA_LANE0_registers['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG13_EQ'], 4,
                                      4)

        self.log_key(key="ans3_lane:{}_h0".format(current_lane), value=h0_smgr, units='')
        self.log_key(key="ans3_lane:{}_SMGR_seq_ptr".format(current_lane), value=SMGR_seq_ptr, units='')
        self.log_key(key="ans3_lane:{}_SMGR_best_eng".format(current_lane), value=SMGR_best_eng, units='')

        for register_name, register_address in AUSPMA_LANE0_SMGR_registers.items():
            register_value = self.get_bits(pcie_address_offset + register_address, 0, 32)

            try:
                self.log_key(key="ans3_lane:{}_{}".format(
                    current_lane,
                    register_name.replace("APCIE_DOWN_AUS_LANE0_AUSPMA_", "").lower()),
                    value=register_value, units='')
            except Exception as e:
                print("Unable to read register: ", register_name, " due to ", e)

    def start_margining(self):
        """Start the Margining"""
        self.debug_service_write(ANS2_SERVICE_ID.SCAN_START, 0)

    def dump_registers(self, initial=False):
        """Dump Static Registers"""
        if initial:
            self.log_msg("      Skipping Initial register dump")
        else:
            self.log_msg("      Skipping Initial register dump")
            if self.env is "darwin":
                self.reg_data = []
                for i in self.valid_lanes:
                    self.current_lane = i
                    self.log_msg("      Dumping registers for lane {}".format(i))
                    self.reg_data = []
                    reg, reg_len = self.debug_data_read(log_id=self.DEBUG_REGISTERS, param0=self.current_lane, param1= 0,
                                                     log_size=0x30000)
                    number_of_static_registers = reg[0]+(reg[1] << 8)       # First 2 bytes represent number of registers
                    self.log_msg("Number of static registers{}".format(number_of_static_registers))
                    reg_len = reg[2]+(reg[3] << 8)       # Second two bytes represent register values length
                    spare = reg[4]+reg[5]+reg[6]+reg[7]        # There are 4 additional spare bytes for future purposes
                    self.log_msg("Spare bytes{}".format(spare))
                    reg_offset_start = 8             # Actual register offsets and values starts from index 8,
                    # and  4bytes represent offset value and 4bytes represent register value
                    print("Current Lane: {} Reg Offset Start: {} Reg Len: {} Static Register Count: {} Spare Bytes: {}".format(
                        self.current_lane, reg_offset_start, reg_len, number_of_static_registers, spare))
                    while reg_offset_start < reg_len * 2 + 1:
                        reg_offset = reg[reg_offset_start]+(reg[reg_offset_start+1] << 8)+(reg[
                                     reg_offset_start+2] << 16)+(reg[reg_offset_start+3] << 24)
                        reg_value = reg[reg_offset_start + 4] + (reg[reg_offset_start + 5] << 8) + (
                                 reg[reg_offset_start + 6] << 16) + (reg[reg_offset_start + 7] << 24)
                        self.convert_register(hex(reg_offset), reg_value)
                        if hex(reg_offset) in self.STATIC_REGISTERS:
                            self.log_reg("offset:{},reg_name:{},reg_value:{},lane_value:{}".format(
                             hex(reg_offset), self.STATIC_REGISTERS[hex(reg_offset)], hex(reg_value), self.current_lane))
                        else:
                            self.log_reg("offset:{},reg_name:{},reg_value:{},lane_value:{}".format(
                             hex(reg_offset), "DONT KNOW REGISTER NAME SORRY!", hex(reg_value), self.current_lane))
                        reg_offset_start = reg_offset_start + 8
            else:
                self.reg_data = []
                if self.endpoint is "ans3":
                    for msp in range(0, self.get_lane_count()): # for MSP 0->3 - Grab only MSP 0 because of product availability
                        self.debug_service_write(ANS2_SERVICE_ID.S4E_ID, int(msp))
                        self.debug_service_write(ANS2_SERVICE_ID.CFG_SPACE_ADDR, int(0x01040154))
                        data = self.debug_service_read(ANS2_SERVICE_ID.CFG_SPACE_DATA)
                        soc_usp_rx_preset_hint0 = self.get_bits(data, 12, 3)
                        self.log_key(key=f'msp{msp}_soc_usp_rx_preset_hint0', value=soc_usp_rx_preset_hint0, units='ticks')
                        soc_usp_tx_preset_hint0 = self.get_bits(data, 8, 4)
                        self.log_key(key=f'msp{msp}_soc_usp_tx_preset_hint0', value=soc_usp_tx_preset_hint0, units='ticks')

                        self.debug_service_write(ANS2_SERVICE_ID.S4E_ID, int(msp))
                        self.debug_service_write(ANS2_SERVICE_ID.CFG_SPACE_ADDR, int(0x01040890))
                        data = self.debug_service_read(ANS2_SERVICE_ID.CFG_SPACE_DATA)
                        soc_rate_shadow_sel = self.get_bits(data, 24, 2)
                        self.log_key(key=f'msp{msp}soc_rate_shadow_sel', value=soc_rate_shadow_sel, units='ticks')

                        self.debug_service_write(ANS2_SERVICE_ID.S4E_ID, int(msp))
                        self.debug_service_write(ANS2_SERVICE_ID.CFG_SPACE_ADDR, int(0x010400a0))
                        data = self.debug_service_read(ANS2_SERVICE_ID.CFG_SPACE_DATA)
                        soc_rate_status = self.get_bits(data, 28, 3)
                        self.log_key(key=f'msp{msp}soc_rate_status', value=soc_rate_status, units='ticks')

                    # if 0 in self.valid_lanes:
                    #     self.debug_service_write(ANS2_SERVICE_ID.DOWN_PHY_REG, int(0x00000154))
                    # else: # only stack 1 0x01000000
                    #     self.debug_service_write(ANS2_SERVICE_ID.DOWN_PHY_REG, int(0x01000154))
                    # data = self.debug_service_read(ANS2_SERVICE_ID.DOWN_PHY_DATA)
                    # soc_usp_rx_preset_hint0 = self.get_bits(data, 12, 3)
                    # self.log_key(key='soc_usp_rx_preset_hint0', value=soc_usp_rx_preset_hint0, units='ticks')
                    # soc_usp_tx_preset_hint0 = self.get_bits(data, 8, 4)
                    # self.log_key(key='soc_usp_tx_preset_hint0', value=soc_usp_tx_preset_hint0, units='ticks')
                    # if 0 in self.valid_lanes:
                    #     self.debug_service_write(ANS2_SERVICE_ID.DOWN_PHY_REG, int(0x00000890))
                    # else: # only stack 1 0x01000000
                    #     self.debug_service_write(ANS2_SERVICE_ID.DOWN_PHY_REG, int(0x01000890))
                    # data = self.debug_service_read(ANS2_SERVICE_ID.DOWN_PHY_DATA)
                    # soc_rate_shadow_sel = self.get_bits(data, 24, 2)
                    # self.log_key(key='soc_rate_shadow_sel', value=soc_rate_shadow_sel, units='ticks')
                    # if 0 in self.valid_lanes:
                    #     self.debug_service_write(ANS2_SERVICE_ID.DOWN_PHY_REG, int(0x010000a0))
                    # else: # only stack 1 0x01000000
                    #     self.debug_service_write(ANS2_SERVICE_ID.DOWN_PHY_REG, int(0x010000a0))
                    # data = self.debug_service_read(ANS2_SERVICE_ID.DOWN_PHY_DATA)
                    # soc_rate_status = self.get_bits(data, 28, 3)
                    # self.log_key(key='soc_rate_status', value=soc_rate_status, units='ticks')
                    self.debug_service_write(ANS2_SERVICE_ID.PHY_REG, int(0x0174))
                    data = self.debug_service_read(ANS2_SERVICE_ID.PHY_DATA)
                    s5e_usp_rx_preset_hint0 = self.get_bits(data, 12, 3)
                    self.log_key(key='s5e_usp_rx_preset_hint0', value=s5e_usp_rx_preset_hint0, units='ticks')
                    s5e_usp_tx_preset_hint0 = self.get_bits(data, 8, 4)
                    self.log_key(key='s5e_usp_tx_preset_hint0', value=s5e_usp_tx_preset_hint0, units='ticks')
                    self.debug_service_write(ANS2_SERVICE_ID.PHY_REG, int(0x0890))
                    data = self.debug_service_read(ANS2_SERVICE_ID.PHY_DATA)
                    s5e_rate_shadow_sel = self.get_bits(data, 24, 2)
                    self.log_key(key='s5e_rate_shadow_sel', value=s5e_rate_shadow_sel, units='ticks')
                for i in self.valid_lanes:
                    # ToDo: Should this be Valid Lanes Index of Current Lane (DEBUG_REGISTERS ISSUE)
                    self.current_lane = self.valid_lanes.index(i)

                    if self.soc in SOC_CONVERSION_CODE:
                        self.direct_register_printout(i)
                    else:
                        print("Not in SOC conversions", self.soc in SOC_CONVERSION_CODE, self.soc)

                    self.log_msg("      Dumping registers for lane {}".format(i))
                    self.reg_data = []
                    ## Use param 0 to indicate lane to dump register log befor the eye scan execution, and param1 for dump after margining
                    reg = self.debug_data_read(log_id=self.DEBUG_REGISTERS, param0=self.current_lane, param1=0,
                                                     log_size=0x30000)
                    print("Current Lane: {} Reg: {}".format(self.current_lane, reg))
                    number_of_static_registers = int(reg[2:4] + reg[0:2], 16)       # First 2 bytes represent number of registers
                    self.log_msg("Number of static registers{}".format(number_of_static_registers))
                    # reg_len = int(reg[6:8]+reg[4:6], 16)       # Second two bytes represent register values length
                    reg_len = int.from_bytes(struct.pack('H', int(reg[4:8], 16)), "big") # seems to default to little endian conversion
                    spare = reg[8:15]        # There are 4 additional spare bytes for future purposes
                    self.log_msg("Spare bytes{}".format(spare))
                    reg_offset_start = 16             # Actual register offsets and values starts from index 8,
                    # 4 bytes represent offset value and 4 bytes represent register value
                    while reg_offset_start < (reg_len * 2 + 1):
                        # reg_offset = int(reg[reg_offset_start + 6: reg_offset_start + 8] +
                        #               reg[reg_offset_start + 4: reg_offset_start+ 6] +
                        #               reg[reg_offset_start + 2: reg_offset_start+ 4] +
                        #               reg[reg_offset_start: reg_offset_start+2], 16)
                        reg_offset = int.from_bytes(struct.pack('I', int(reg[reg_offset_start:reg_offset_start + 8], 16)), "big")
                        reg_offset_val = reg_offset_start + 8
                        # reg_value = int(reg[reg_offset_val + 6: reg_offset_val + 8] +
                        #               reg[reg_offset_val + 4: reg_offset_val + 6] +
                        #               reg[reg_offset_val + 2: reg_offset_val + 4] +
                        #               reg[reg_offset_val: reg_offset_val + 2], 16)
                        reg_value = int.from_bytes(struct.pack('I', int(reg[reg_offset_val:reg_offset_val + 8], 16)), "big")

                        self.convert_register(hex(reg_offset), reg_value)
                        if hex(reg_offset) in self.STATIC_REGISTERS:
                            self.log_reg("offset:{},reg_name:{},reg_value:{},lane_value:{}".format(
                                hex(reg_offset), self.STATIC_REGISTERS[hex(reg_offset)], hex(reg_value), self.current_lane))
                        else:
                            self.log_reg("offset:{},reg_name:{},reg_value:{},lane_value:{}".format(
                            hex(reg_offset), "DONT KNOW REGISTER NAME SORRY!", hex(reg_value), self.current_lane))

                        reg_offset_start = reg_offset_start + 16

    def parse_margin_data(self):
        """Parse data to the necessary format(s)"""
        if self.env is "darwin":
            data, data_len = self.debug_data_read(log_id=self.DEBUG_LOG, param0=self.current_lane, param1=0,
                                              log_size=0x30000)
            x_num_points = data[0]
            y_num_points = data[1]
            raw_data_length = data[2]+(data[3] << 8)
            self.log_msg("Raw Data Length is {}".format(raw_data_length))
            spare_data = data[4]+data[5]+data[6]+data[7]
            self.log_msg("Spare Data Bytes is {}".format(spare_data))
            raw_data_index = 8
            m = []
            for y in range(0, y_num_points, 1):
                for x in range(0, x_num_points, 1):
                    errors_data = data[raw_data_index]+(data[raw_data_index+1] << 8)
                    m.append(errors_data)
                    raw_data_index = raw_data_index + 2
        else:
            data = self.debug_data_read(log_id=self.DEBUG_LOG, param0=self.current_lane, param1=0,
                                                  log_size=0x30000)
            x_num_points = int(data[0]+data[1], 16)
            y_num_points = int(data[2]+data[3], 16)
            raw_data_length = int(data[4]+data[5]+data[6]+data[7], 16)
            self.log_msg("Raw Data Length is {}".format(raw_data_length))
            spare_data = int(data[8]+data[9]+data[10]+data[11]+data[12]+data[13]+data[14]+data[15], 16)
            self.log_msg("Spare Data Bytes is {}".format(spare_data))
            raw_data_index = 16
            m = []
            for y in range(0, y_num_points, 1):
                for x in range(0, x_num_points, 1):
                    errors_data = int(data[raw_data_index+2] +
                                      data[raw_data_index+3] + data[raw_data_index]+data[raw_data_index+1], 16)
                    m.append(errors_data)
                    raw_data_index = raw_data_index + 4

        print("Parsed margin data: {}".format(m))
        return m

    def calculate_eye(self):
        # Grab link status now that margining is done
        self.check_link("test complete")

        """Calculate the Eye Diagram for axis only"""
        self.debug_service_write(register=ANS2_SERVICE_ID.SCAN_ANS2_PHY, value=1 if self.ROOT_PORT else 0)

        for lane in self.valid_lanes:
            # print("before self.current_lane: ", self.current_lane, lane)

            self.current_lane = self.valid_lanes.index(lane)
            self.mid_y = (self.max_y + self.min_y) / 2

            # print("after self.current_lane: ", self.current_lane, lane)

            if self.current_lane < len(self.register_read_dclks) and self.register_read_dclks[self.current_lane] is not None:
                self.mid_x = self.register_read_dclks[self.current_lane]
            else:
                print("dclk is missing from register reads, using normal value of 40")
                self.mid_x = int((self.max_x + self.min_x + 1) / 2)

            # print("debug_mid_x_calculation=", int((self.max_x + self.min_x + 1) / 2), "vs", "dclk",
            #      self.register_read_dclks[self.current_lane], self.register_read_dclks)
            print(
                "mid y: {} mid x: {} max y: {} min y: {} max x: {} min x: {}".format(self.mid_y, self.mid_x, self.max_y,
                                                                                     self.min_y, self.max_x,
                                                                                     self.min_x))
            print("Lane: {} Valid Lanes: {} Current Lane: {} ".format(lane, self.valid_lanes, self.current_lane))
            # Get the data for the lane (list of margin values)
            data = self.parse_margin_data()
            if len(data) > 0:
                self.seq_log.info("      Dumping eye for lane {}".format(self.current_lane))
                north, south, east, west = self.min_y, self.max_y, self.min_x, self.max_x

                # Visual diagram and Raw diagram
                diagram, coords = "", ""

                # Iterate thru the coordinate Top Left to Bottom Right
                if self.axis_only is True:
                    for y in range(self.min_y, self.max_y + 1, 1):
                        for x in range(self.min_x, self.max_x + 1, 1):
                            margin = data.pop(0)
                            if y != self.mid_y and x != self.mid_x:
                                diagram += " "
                                coords += "{}".format("     ") if x == self.max_x else ",{}". \
                                    format("     ")
                            else:
                                # Add to the Coordinate file
                                coords += "{}".format(self.padded_hex(margin, 5))

                                # Log only values below the threshold
                                if margin <= self.threshold:
                                    diagram += "0"
                                    # Set the North / South values
                                    south = y if y < south else south
                                    north = y if y > north else north
                                    # Set the East / West values
                                    west = x if x < west else west
                                    east = x if x > east else east
                                else:
                                    # Draw the axis
                                    diagram += "1 "
                        coords += "\n"
                        diagram += "\n"
                else:
                    # Iterate thru the coordinate Top Left to Bottom Right
                    for y in range(self.min_y, self.max_y + 1, 1):
                        for x in range(self.min_x, self.max_x + 1, 1):
                            margin = data.pop(0)
                            # Add to the Coordinate file
                            coords += "{}".format(self.padded_hex(margin, 5)) if x == self.max_x else ",{}". \
                                format(self.padded_hex(margin, 5))

                            # Log only values below the threshold
                            if margin <= self.threshold:
                                diagram += "0"
                                # Set the North / South values
                                if x == self.mid_x:
                                    south = y if y < south else south
                                    north = y if y > north else north
                                elif y == self.mid_y:
                                    # Set the East / West values
                                    west = x if x < west else west
                                    east = x if x > east else east
                            else:
                                diagram += "1"

                        coords += "\n"
                        diagram += "\n"

                # Write the coordinate and diagram files
                # Update Lanes from Index for Saving Files
                self.current_lane = self.valid_lanes[self.current_lane]

                self.write_coordinate_file(coords)
                self.write_eye_diagram_file(diagram)

                # Set the Height / Width
                self.eye_height[self.current_lane] = (self.TICK_TO_VOLTAGE * (north + abs(south))) if (self.TICK_TO_VOLTAGE * (north + abs(south))) >= 0 else 0
                self.eye_width[self.current_lane] = (self.TICK_TO_FREQUENCY * (east - west)) if (self.TICK_TO_FREQUENCY * (east - west)) >= 0 else 0
                self.eye_height_ticks[self.current_lane] = (north + abs(south)) if (north + abs(south)) >= 0 else 0
                self.eye_width_ticks[self.current_lane] = (east - west) if (east - west) >= 0 else 0

                left_ew_ps = self.TICK_TO_FREQUENCY * (self.mid_x - west)
                right_ew_ps = self.TICK_TO_FREQUENCY * (east - self.mid_x)
                min_ew_ps = min(left_ew_ps, right_ew_ps)

                # Print keys to serial
                print("lane_{}_north_ticks={}".format(self.current_lane, north))
                print("lane_{}_south_ticks={}".format(self.current_lane, south))
                print("lane_{}_east_ticks={}".format(self.current_lane, east))
                print("lane_{}_west_ticks={}".format(self.current_lane, west))
                print("lane_{}_eh_mv={}".format(self.current_lane, self.eye_height[self.current_lane]))
                print("lane_{}_ew_ps={}".format(self.current_lane, self.eye_width[self.current_lane]))
                print("lane_{}_eh_ticks={}".format(self.current_lane, self.eye_height_ticks[self.current_lane]))
                print("lane_{}_ew_ticks={}".format(self.current_lane, self.eye_width_ticks[self.current_lane]))
                print("lane_{}_leftright_2min_ew_ps={}".format(self.current_lane,2 * min_ew_ps ))


                # Log them to the result file
                self.log_key(key="lane_{}_north_ticks".format(self.current_lane), value=north, units='ticks')
                self.log_key(key="lane_{}_south_ticks".format(self.current_lane), value=south, units='ticks')
                self.log_key(key="lane_{}_east_ticks".format(self.current_lane), value=east, units='ticks')
                self.log_key(key="lane_{}_west_ticks".format(self.current_lane), value=west, units='ticks')
                self.log_key(key="lane_{}_eh_mv".format(self.current_lane), value=self.eye_height[self.current_lane],
                             units='mv', upperlimit=self.eh_max, lowerlimit=self.eh_min)
                self.log_key(key="lane_{}_ew_ps".format(self.current_lane), value=self.eye_width[self.current_lane],
                             units='ps', upperlimit=self.ew_max, lowerlimit=self.ew_min)
                self.log_key(key="lane_{}_eh_ticks".format(self.current_lane), value=self.eye_height_ticks[self.current_lane], units='ticks')
                self.log_key(key="lane_{}_ew_ticks".format(self.current_lane), value=self.eye_width_ticks[self.current_lane], units='ticks')
                self.log_key(key="lane_{}_leftright_2min_ew_ps".format(self.current_lane), value=2 * min_ew_ps, units='ps', upperlimit=self.ew_max, lowerlimit=self.ew_min)

                self.log_msg("Lane {}: north = {}, south = {}, east = {}, west = {}, ns = {}mv, ew = {}ps".format(
                    self.current_lane,
                    north,
                    south,
                    east,
                    west,
                    self.eye_height[self.current_lane],
                    self.eye_width[self.current_lane]
                ))

    def progress(self):
        """Progress in integer % increments"""
        return int(self.debug_service_read(register=ANS2_SERVICE_ID.QUERY_PROGRESS))

    def is_running(self):
        """Check if Margining is running"""
        prog = self.progress()
        if prog != self._previous_percent:
            self._previous_percent = prog
            self.log_msg("      Progress {}%".format(prog))
        return int(prog) < 100

    def clean_up(self):
        """Clean up margining and reset the PHY"""

    def all_lanes_scanned(self, lane):
        """Check if all lanes scanned"""
        # Lanes are all scanned at once
        return 1
