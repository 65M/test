import time
import math
from shell import run
from .defines import *
from ..base import AbstractBaseMarginTool
from .conversion import *
from .soc_defines import *

__all__ = [
    "AbstractReceiverMarginTool"
]


class AbstractReceiverMarginTool(AbstractBaseMarginTool):
    """Generic Interface for Widget Pass Margining"""
    LANE_COUNT = 1  # The Number of lanes (if applicable)
    POLL_TIME = 1  # Polling interval
    TIMEOUT = 20.000  # Maximum time in seconds before a 'run' is timedout
    res_data = []
    res_vol_north_data = []
    res_vol_south_data = []
    res_pi_east_data = []
    res_pi_west_data = []
    res_vol_north_data_1 = []
    res_vol_south_data_1 = []
    res_pi_east_data_1 = []
    res_pi_west_data_1 = []
    LANE_RP_OFFSET = 0
    mid_x = 0
    mid_y = 0
    soc_apcie_down_offset=0
    soc_auspma_lane0_offset=0
    soc_lane_offset=0


    def __init__(self, *args, **kwargs):
        super(AbstractReceiverMarginTool, self).__init__(*args, **kwargs)
        print("PCIE 3NM BASE MARGINING!")

        # Update the Lane Count as Appropriate
        print(f"Lane Count: {self.LANE_COUNT} PCIe Lane Count: {self.pcie_lane_count}")

        if self.pcie_lane_count:
            print("Update Lane Count")
            self.LANE_COUNT = self.pcie_lane_count

        self._fake_progress = 0
        try:
            self.die_offset = SOC_CONVERSION_CODE[self.soc]['DIE_OFFSET']
        except KeyError:
            self.die_offset = None
        self.die_offset_addr = 0

        # Grab the die location and length for lane offset calculations
        if self.die_location:
            self.die_length = int(len(self.die_location['0']))
            self.die_number = 0
            print("Number of PCIE Ports on DIE: {}".format(self.die_length))
        else:
            self.die_length = 0
            self.die_number = 0

        self.calculate_base_offset(self.root_port)

        # APCIE down offset includes both the base offset + any offset based on which die it's on.
        self.soc_apcie_down_offset = SOC_CONVERSION_CODE[self.soc]['SOC_APCIE_DOWN'] + self.die_offset_addr
        self.auspma_lane0_offset= SOC_CONVERSION_CODE[self.soc]['SOC_AUS_LANE0']
        self.pcie_cfg_offset= SOC_CONVERSION_CODE[self.soc]['SOC_GP_CONFIG']
        self.lane_offset = SOC_CONVERSION_CODE[self.soc]['SOC_LANE_OFFSET']
        self.cfg2_offset = self.soc_apcie_down_offset + (self.root_port - (self.die_number * self.die_length)) * self.lane_offset + SOC_CONVERSION_CODE[self.soc]['CFG_2'] # https://seg-docs.csg.apple.com/projects/jadecdie/release/UserManual/regs_1c/AUSPMA_RX_TOP.html?baseaddr=0x5800c9000
        self.LANE_RP_OFFSET = self.soc_apcie_down_offset + self.auspma_lane0_offset + \
                              (self.root_port + SOC_CONVERSION_CODE[self.soc]['LANE_ADJUST'] - (self.die_number * self.die_length)) * self.lane_offset

        if self.pcie_port is None:
            self.pcie_cfg_rp_offset = self.soc_apcie_down_offset + self.pcie_cfg_offset + (self.root_port - (self.die_number * self.die_length)) * self.lane_offset
        else:
            self.pcie_cfg_rp_offset = self.soc_apcie_down_offset + self.pcie_cfg_offset + (
                        self.pcie_port - (self.die_number * self.die_length)) * self.lane_offset

        print("Lane RP Offset: {} and PCIE CFG Offset: {}, {}".format(self.LANE_RP_OFFSET, self.pcie_cfg_rp_offset, self.pcie_port))


    def calculate_base_offset(self, port_num):
        """Calculate the base pcie offset based on the port_num"""
        self.die_offset_addr = 0
        # if die location isn't provided in project defines, we assume the project is single die.
        if self.die_location:
            for key, value in self.die_location.items():
                # grab which die the port_num is on
                if str(port_num) in value:
                    if self.die_offset is not None:
                        die_offset_addr = int(key) * self.die_offset
                        self.die_offset_addr = die_offset_addr
                        self.die_number = int(key)
                        print("   Found Valid Key: {} in Die Location: {} for Port Num: {} New Die Offset ADDR: {}   ".format(key, self.die_location, port_num, self.die_offset_addr))
                        self.log_msg("   Found Valid Key: {} in Die Location: {} for Port Num: {}   ".format(key, self.die_location, port_num))
                        return
                    else:
                        # error if we have multiple dies but no offset for between the dies
                        print("    Die Location Exists (i.e. the product has multiple dies) but no offsett address provided    ")
                        raise("    Die Location Exists (i.e. the product has multiple dies) but no offsett address provided    ")
            print("    Port Number: {} not found in Die Location: {}    ".format(port_num, self.die_location))
            raise("    Port Number: {} not found in Die Location: {}    ".format(port_num, self.die_location))
        else:
            # print("    No Die Location, Moving On     ")
            self.log_msg("    No Die Location, Moving On     ")


    #
    #  Accessors
    #

    def write_register(self, address, value):
        """Set Register to a value"""

    def read_register(self, address):
        """Get a Register value"""

    def set_bits(self, address, start_bit, length, value):
        """Change specific bits of a address"""

    def get_bits(self, address, start_bit, length):
        """Change specific bits of a address"""

    def int2sa_vos_code(self, intval):
        """Convert to gray code from sign int 5 bits"""
        if (intval < -31) or (intval > 31):
            return None
        elif intval >= 0:
            return intval ^ intval >> 1
        intval = abs(intval)
        return (intval ^ intval >> 1) + 32

    def dec2gray(self, i=0):
        """ convert dec to gray """
        return i ^ i >> 1

    def gray2dec(self, i=0, total_bits=128):
        """ convert gray to dec """
        return [self.dec2gray(d) for d in range(total_bits)].index(i)
    #
    # Execution Flow
    #
    def set_adaptation_dfe(self):
        if bool(self.dfe_off):
            print(f"Setting adaptations for DFE {self.dfe_off} lane_rp_offset {self.LANE_RP_OFFSET} vs {hex(self.LANE_RP_OFFSET+AUSPMA_LANE0['AEQ_CTRL_DFE_CFG0'])}")
            # 10g to 20g DFEH1 to 0
            self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['AEQ_CTRL_DFE_CFG0'], 18, 6, 0)

            # 10g to 20g DFEH2 to 0
            self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['AEQ_CTRL_DFE_CFG1'], 4, 4, 0)

            # 10g to 20g DFEH3 to 0
            self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['AEQ_CTRL_DFE_CFG1'], 20, 4, 0)

            # 10g to 20g DFEH4 to 0
            self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['AEQ_CTRL_DFE_CFG2'], 4, 4, 0)

            # 10g to 20g DFEH5 to 0
            self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['AEQ_CTRL_DFE_CFG2'], 20, 4, 0)

            # Set all 5 override bits to 1
            self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['AEQ_CTRL_DFE_CFG8'], 0, 5, 31)
        else:
            print("DFE Engine is On by default")

    def set_rc(self, figure_of_merit):
        if bool(self.ctle_sweep):
            self.r = figure_of_merit[0]
            self.c = figure_of_merit[1]

            print(f"ctle_sweep: lane_rp_offset {self.LANE_RP_OFFSET} vs {hex(self.LANE_RP_OFFSET+AUSPMA_LANE0['AEQ_CTRL_DFE_CFG0'])}")
            # R/C Speed Override Bits for all Protocols
            self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['AEQ_CTRL_CTLE_CFG3'], 0, 2, 3)

            #   C override (all protocols)
            self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['AEQ_CTRL_CTLE_CFG0'], 0, 4, self.dec2gray(self.c))
            self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['AEQ_CTRL_CTLE_CFG0'], 4, 4, self.dec2gray(self.c))
            self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['AEQ_CTRL_CTLE_CFG0'], 8, 4, self.dec2gray(self.c))
            self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['AEQ_CTRL_CTLE_CFG0'], 12, 4, self.dec2gray(self.c))

            #   R override (all protocols)
            self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['AEQ_CTRL_CTLE_CFG0'], 16, 4, self.dec2gray(self.r))
            self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['AEQ_CTRL_CTLE_CFG0'], 20, 4, self.dec2gray(self.r))
            self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['AEQ_CTRL_CTLE_CFG0'], 24, 4, self.dec2gray(self.r))
            self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['AEQ_CTRL_CTLE_CFG0'], 28, 4, self.dec2gray(self.r))
        else:
            print("Skipped r/c value set")
            pass
        #
        # Execution Flow

    def set_adaptation(self, figure_of_merit):
        """Set the Adaptation Type (if applicable)"""
        if bool(self.doe) is True:
            self.turn_on_pcieeyescan()
            if self.pcie_port is not None:
                run(f"pcie --pick {self.pcie_port}")
            else:
                run(f"pcie --pick {self.root_port}")

            if self.pcie_gpio is not None:
                run(f"pmugpio --pin {self.pcie_gpio} --output 1")

            run("pcie --powerup")

            self.set_adaptation_dfe()
            print(self.ctle_sweep)
            self.set_rc(figure_of_merit)

            if self.module is not "gpstorage":
                run("pcie --linktrain")
            else:
                pass
                # run("nand --poweron")
                # run("nand --set DownlinkASPMControl 1")

        else:
            return 1

    def apply_settings(self, retrain=True):
        """Apply EQ and other settings, retrain (if applicable)"""

    def ensure_link(self):
        """Check Link meets Speed / Width requirements"""

    def turn_on_pcieeyescan(self):
        """ Turns on the pcie eye scan for margining """
        pass

    def disable_power_management(self):
        """Disable Power Management Modes"""
        self.log_msg("   Disable Power Management")

    def set_traffic_type(self, traffic_type):
        """Select the Traffic type (Live, PRBS, etc)"""

    def select_lane(self, lane):
        """Select a Lane"""


    def configure_phy(self):
        """Configure the PHY Settings, Overrides, ECO, etc"""
        print("Skip Configure PHY")

        # https://seg-docs.csg.apple.com/projects/tonga/release/specs/Apple/AUSPMA/AUSPMA_Specification.pdf
        # print(f"Configure PHY")

        # Ethernet doesn't have extended capability 0x1E which is required to set L1 substrates but does support aspm
        # if self.module in ["ethernet"]:
        #     run("pcie --aspm l1.2")
        # else:
        #     run("pcie --pm l1.2")

        # # Dump the link state to verify
        # print("L1.2 Dump Link Status Verify")
        # link_status_register = self.soc_apcie_down_offset + (self.root_port * 0x001000000) + 0x014000000 + 0x8208
        # print(f"Link Status Register: {link_status_register} Root Port: {self.root_port} APCIE Down: {self.soc_apcie_down_offset}")
        # output = self.get_bits(link_status_register, 0, 32)
        # print(f"Link Status Register Output: {output}")
        #
        # # self.root_port
        # # SOC_APCIE_DOWN + #
        # # 0x594008208
        # # 0x595008208
        # # 0x580000000 + 0x014000000 + 0x001000000 (root_port) + 0x000008208
        #
        # print(f"LANE RP Offset: {self.LANE_RP_OFFSET}")
        #
        # # The following steps of the eyescan sequence should be executed before de-assertion of lane reset and after de-assertion of apb_reset.
        #
        # # Step 1 (a)
        # # Enable byte clock for EQ engine
        # #   Write lane’s RX EQ register, eq_smgr_override
        # #   clk_en = 1
        #
        # print("The following steps (1/2) of the eyescan sequence should be executed before de-assertion of lane reset and after de-assertion of apb_reset.")
        #
        # print("Step 1(a) - Enable byte clock for EQ engine")
        # self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RX_EQ_EQ_SMGR_OVERRIDE'], 0, 1, 1)
        #
        # # Step 2 (a)
        # #   Write lane’s RX SHIM register, rxa_dcopi_ctrl61 to enable Error PI
        # #       pma_rxa_dcopi_eclk_en_ov = 1
        # #       pma_rxa_dcopi_eclk_en = 1
        #
        # print("Step 2(a) - Write lane’s RX SHIM register, rxa_dcopi_ctrl61 to enable Error PI")
        # self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL61'], 17, 1, 1)
        # self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL61'], 16, 1, 1)
        #
        # # Step 2 (b)
        # #   Write lane’s RX SHIM register, rxa_dcopi_ctrl1 to enable eclk
        # #       pma_rxa_dcoclk_eck_en_ov = 1;
        # #       pma_rxa_dcoclk_eck_en = 1;
        #
        # print("Step 2(b) - Write lane’s RX SHIM register, rxa_dcopi_ctrl1 to enable eclk")
        # self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL1'], 1, 1, 1)
        # self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL1'], 0, 1, 1)
        #
        # # Step 2 (c)
        # #   Write lane’s RX SHIM register, rxa_dcopi_ctrl1 to disable the bypass eclk DCO PI
        # #       pma_rxa_dcopi_eclk_bypass_en_ov = 1
        # #       pma_rxa_dcopi_eclk_bypass_en = 0
        # #       pma_rxa_dcopi_xdclk_bypass_en_ov = 1
        # #       pma_rxa_dcopi_xdclk_bypass_en = 0
        #
        # print("Step 2(c) - Write lane’s RX SHIM register, rxa_dcopi_ctrl1 to disable the bypass eclk DCO PI")
        # self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL1'], 10, 1, 1)
        # self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL1'], 9, 1, 0)
        #
        # print("Temp Disable")
        # # self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL1'], 12, 1, 1)
        # # self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL1'], 11, 1, 0)
        #
        # print("Step 3 set DCO bits")
        # print("Set DCO CTRL31 Bits")
        # self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_DCO_CTRL31'], 13, 1, 0)
        # self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_DCO_CTRL31'], 15, 1, 0)
        # self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_DCO_CTRL31'], 17, 1, 0)
        # print("Done Set DCO CTRL31 Bits")
        #
        # run("pcie --pm l1")
        #
        # # Dump the link state to verify
        # print("L1, Post Setup, Dump Link Status Verify")
        # link_status_register = self.soc_apcie_down_offset + (self.root_port * 0x001000000) + 0x014000000 + 0x8208
        # print(f"Link Status Register: {link_status_register} Root Port: {self.root_port} APCIE Down: {self.soc_apcie_down_offset}")
        # output = self.get_bits(link_status_register, 0, 32)
        # print(f"Link Status Register Output: {output}")
        print("Done Skip Configure PHY")

    def setup_margining(self):
        """Configure the PHY and Setup Margining"""
        # Per Olivier, Skip Steps 5b / 5c -> instead read E-Clock / D-Clock
        # The Error PI Codes, PMA RXA DCOPI ECLK POS GRAY, and EXCLKB Should Only Change 1x At A Time and Not By >1

        # ToDo: (Questions)
        # AUS40PMA_RX_APB_OVERRIDE_REG_50
        # Conversion factor mV to Ticks?

        # Presume that steps 1 / 2(a)(b)(c) are handled by the FW.

        # Step 3(a) - Setup Error PI to Align EClk Pos Gray
        # RXA_DCOPI_CTRL61 - https://seg-docs.csg.apple.com/projects/ibiza/release/UserManual/regs/trunk/default/AUSPMA_RX_SHM.html?baseaddr=0x2a671a000#AUSPMA_RX_SHM_auspma_rx_rxa_dcopi_ctrl61
        #   eclk_pos_gray_ov = 1
        #   eclk_pos_gray = binary2gray(8) = 12
        #   eclkb_pos_gray_ov = 1
        #   eclkb_pos_gray = binary2gray(8) = 12
        print("Step 3(a) Setup Error PI To Align EClk Pos Gray")
        print("Skip setting values to 8 and instead align ECLK / ECLKB to DCLK / DCLKB")
        print("Check ECLK/ECLKB and DCLK/DCLKB are in the same location (center of the eye) - if not, walk them back")

        dclk_pos_decimal = self.gray2dec(self.get_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCO_CTRL89_RO'], 14, 7))
        dclkb_pos_decimal = self.gray2dec(self.get_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCO_CTRL89_RO'], 21, 7))

        eclk_pos_decimal = self.gray2dec(self.get_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL611_RO'], 0, 7))
        eclkb_pos_decimal = self.gray2dec(self.get_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL611_RO'], 7, 7))

        # Set 61 to value from CTRL611
        self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL61'], 0, 7, self.dec2gray(eclk_pos_decimal))
        self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL61'], 7, 1, 1)
        time.sleep(10 / 1000000.0)

        self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL61'], 8, 7, self.dec2gray(eclkb_pos_decimal))
        self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL61'], 15, 1, 1)
        time.sleep(10 / 1000000.0)

        print(f"DCLK: {dclk_pos_decimal} DCLKB: {dclkb_pos_decimal} ECLK :{eclk_pos_decimal} ECLKB: {eclkb_pos_decimal}")
        if eclk_pos_decimal != dclk_pos_decimal and eclkb_pos_decimal != dclkb_pos_decimal:
            if dclk_pos_decimal > eclk_pos_decimal:
                direction = 1
            elif dclk_pos_decimal < eclk_pos_decimal:
                direction = -1

            print(f" Direction: {direction}")
            for difference in range(eclk_pos_decimal, dclk_pos_decimal, direction):
                print(f" Walking Back Difference: {difference} Gray Value: {self.dec2gray(difference)}")
                self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL61'], 0, 7, self.dec2gray(difference))
                time.sleep(10 / 1000000.0)
                self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL61'], 8, 7, self.dec2gray(difference))
                print(f" Touching DCOPI 61 Bits 0->6 and 8->14 Decimal: {difference} Gray: {self.dec2gray(difference)}")
                time.sleep(10 / 1000000.0)

            self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL61'], 0, 7, self.dec2gray(dclk_pos_decimal))
            time.sleep(10 / 1000000.0)
            self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL61'], 8, 7, self.dec2gray(dclkb_pos_decimal))
            time.sleep(10 / 1000000.0)
            print(f" Touching DCOPI 61 Bits 0->6 and 8->14 Decimal: {dclk_pos_decimal} Gray: {self.dec2gray(dclk_pos_decimal)}")

            dclk_pos_decimal = self.gray2dec(self.get_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCO_CTRL89_RO'], 14, 7))
            dclkb_pos_decimal = self.gray2dec(self.get_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCO_CTRL89_RO'], 21, 7))

            eclk_pos_decimal = self.gray2dec(self.get_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL611_RO'], 0, 7))
            eclkb_pos_decimal = self.gray2dec(self.get_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL611_RO'], 7, 7))

            print(f"DCLK: {dclk_pos_decimal} DCLKB: {dclkb_pos_decimal} ECLK :{eclk_pos_decimal} ECLKB: {eclkb_pos_decimal}")

        # Step 4(a) - Enable H0 DAC (set it 0 to begin with, also enable error deserializer)
        # The register write should happen in following order with a gap of 1 μs between each write.
        # rxa_deser_ctrl91 not required if cfg0_eq.h0_dac_en is 1 (https://seg-docs.csg.apple.com/projects/ibiza/release/UserManual/regs/trunk/default/AUSPMA_RX_EQ.html?baseaddr=0x2a6719000#AUSPMA_RX_EQ_cfg0_eq)
        # rxa_deser_ctrl91 - https://seg-docs.csg.apple.com/projects/ibiza/release/UserManual/regs/trunk/default/AUSPMA_RX_SHM.html?baseaddr=0x2a671a000#AUSPMA_RX_SHM_auspma_rx_rxa_deser_ctrl91
        #   dfeh0dac_sml_en_ov = 1
        #   dfeh0dac_big_en_ov = 1
        #   dfeh0dac_sml_en = 1
        #   dfeh0dac_big_en = 1
        #   dfeh0dac_gray_ov = 1
        #   dfeh0dac_gray = 0

        print("Step 4(a) Enable H0 Dac (set it to 0 to begin with) also enable error deserializer.")
        self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DESER_CTRL91'], 17, 1, 1)
        self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DESER_CTRL91'], 18, 1, 1)

        self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DESER_CTRL91'], 15, 1, 1)
        self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DESER_CTRL91'], 16, 1, 1)

        self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DESER_CTRL91'], 19, 6, 0)
        self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DESER_CTRL91'], 25, 1, 1)

        # Step 4(b) - Write lane’s RX SHIM register, rxa_dfe_ctrl111 to control H0 DAC
        # rxa_dfe_ctrl111 - https://seg-docs.csg.apple.com/projects/ibiza/release/UserManual/regs/trunk/default/AUSPMA_RX_SHM.html?baseaddr=0x2a671a000#AUSPMA_RX_SHM_auspma_rx_rxa_dfe_ctrl111
        #   dfeh0dac_range_ov = 1
        #   dfeh0dac_range = 3

        print("Step 4(b)")
        self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DFE_CTRL111'], 0, 2, 3)
        self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DFE_CTRL111'], 2, 1, 1)

        # Step 5(a) - Enable Error deserializer (Data and Edge should already be enabled by PCTRL)
        # rxa_deser_ctrl91
        #   pma_rxa_deser_e_en_ov = 1
        #   pma_rxa_deser_e_en = 1

        print("Step 5(a) - Enable Error Deserializer (Data and Edge should already be enabled by PCTRL)")
        self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DESER_CTRL91'], 10, 1, 1)
        self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DESER_CTRL91'], 11, 1, 1)

        print("Skip 5(b) and 5(c)")
        # Skip 5(b) and 5(c)
        # Alternative 5(b) and 5(c) from Olivier
        # AUSPMA_RX_RXA_DCO_CTRL89_RO : for DCLK/DCLKB and AUSPMA_RX_RXA_DCOPI_CTRL611_RO for ECLK/ECLKB
        # Make sure they are at the same location. This should be the center of the eye
        # If ECLK/ECLKB are not at the same location as DCLK/DCLKB move them back to those locations (the rule that you can only move by one step at a time, still applies
        # AUSPMA_RX_SHM_auspma_rx_rxa_dco_ctrl89_ro - https://seg-docs.csg.apple.com/projects/ibiza/release/UserManual/regs/trunk/default/AUSPMA_RX_SHM.html?baseaddr=0x2a671a000#AUSPMA_RX_SHM_auspma_rx_rxa_dco_ctrl89_ro
        # AUSPMA_RX_SHM_auspma_rx_rxa_dco_ctrl611_ro - https://seg-docs.csg.apple.com/projects/ibiza/release/UserManual/regs/trunk/default/AUSPMA_RX_SHM.html?baseaddr=0x2a671a000#AUSPMA_RX_SHM_auspma_rx_rxa_dcopi_ctrl611_ro

        # To walk them back - AUSPMA_RX_RXA_DCOPI_CTRL61 - https://seg-docs.csg.apple.com/projects/ibiza/release/UserManual/regs/trunk/default/AUSPMA_RX_SHM.html?baseaddr=0x2a671a000#AUSPMA_RX_SHM_auspma_rx_rxa_dcopi_ctrl61
        print("Step 6 - Choose eye scan mask, to choose between composite, even/odd bits")
        print("Setting error_mask to", self.error_mask)
        self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RX_EQ_CFG42_EQ'], 1, 2, self.error_mask)
        self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RX_EQ_CFG42_EQ'], 3, 1, 1)
        # Step 6 - Choose eye scan mask, to choose between composite, even/odd bits
        # RX EQ register, cfg42_eq - https://seg-docs.csg.apple.com/projects/ibiza/release/UserManual/regs/trunk/default/AUSPMA_RX_EQ.html?baseaddr=0x2a6719000#AUSPMA_RX_EQ_cfg42_eq
        # error_mask = 0x0 – composite scan (both even and odd are active)
        #            = 0x1 – only odd samplers’ output is used
        #            = 0x2 – only even samplers’ output is used
        #            = 0x3 – gated both even and odd samplers’ output
        # error_mask_ov = 1, if user wants to do either even or odd eye scan else write error_mask_ov = 0

        # print("Set DCO CTRL31 Bits")
        # self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_DCO_CTRL31'], 13, 1, 0)
        # self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_DCO_CTRL31'], 15, 1, 0)
        # self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_DCO_CTRL31'], 17, 1, 0)
        # print("Done Set DCO CTRL31 Bits")

    def _update_status(self):
        """Fake Progress updater"""
        for i in range(0, 101):
            self._fake_progress = i
            time.sleep(0.05)

    def padded_hex(self, i, l):
        given_int = i
        given_len = l

        hex_result = hex(given_int)[2:]  # remove '0x' from beginning of str
        num_hex_chars = len(hex_result)
        extra_zeros = '0' * (given_len - num_hex_chars)  # may not get used..

        return ('0x' + hex_result if num_hex_chars == given_len else
                '?' * given_len if num_hex_chars > given_len else
                '0x' + extra_zeros + hex_result if num_hex_chars < given_len else
                None)


    def dump_registers(self, initial=False):
        """Dump Static Registers check adaptation converged values"""
        # Set below to make sure h0,h1 etc are read right
        # Convert CTLE and DFE to actual training parameters
        # Read out dclk, xclk, dclkb and xclkb positions
        if initial is True:
            cs_ticks = self.gray2dec(self.get_bits((self.LANE_RP_OFFSET +
                                              AUS_LANE0_DEBUG['AFE_CTRL16_RO']),
                                                   7,
                                                   4))
            self.log_key(key="lane:{}_cs_ticks".format(
                self.current_lane),
                value=cs_ticks,
                units='ticks')
            cs = CONVERSION_OFFSET_FACTORS["c"] + CONVERSION_MULTIPLICATION_FACTORS["c"] * cs_ticks
            self.log_key(key="lane:{}_cs".format(
                self.current_lane),
                value=cs,
                units='db')
            rs_ticks = self.gray2dec(self.get_bits(self.LANE_RP_OFFSET +
                                             AUS_LANE0_DEBUG['AFE_CTRL16_RO'], 19,
                                                   4))
            self.log_key(key="lane:{}_rs_ticks".format(
                self.current_lane),
                value=rs_ticks,
                units='ticks')
            rs = CONVERSION_OFFSET_FACTORS["r"] + CONVERSION_MULTIPLICATION_FACTORS["r"] * rs_ticks
            self.log_key(key="lane:{}_rs".format(
                self.current_lane),
                value=rs,
                units='db')

            dfeh5fb_en = self.get_bits(self.LANE_RP_OFFSET + AUS_LANE0_DEBUG['DFE_CTRL13_RO'], 28, 1)
            dfeh4fb_en = self.get_bits(self.LANE_RP_OFFSET + AUS_LANE0_DEBUG['DFE_CTRL13_RO'], 22, 1)
            dfeh3fb_en = self.get_bits(self.LANE_RP_OFFSET + AUS_LANE0_DEBUG['DFE_CTRL13_RO'], 21, 1)
            dfeh2fb_en = self.get_bits(self.LANE_RP_OFFSET + AUS_LANE0_DEBUG['DFE_CTRL13_RO'], 20, 1)
            dfeh1fb_en = self.get_bits(self.LANE_RP_OFFSET + AUS_LANE0_DEBUG['DFE_CTRL13_RO'], 19, 1)

            self.log_key(key="lane:{}_dfeh5fb_en".format(self.current_lane), value=dfeh5fb_en, units='')
            self.log_key(key="lane:{}_dfeh4fb_en".format(self.current_lane), value=dfeh4fb_en, units='')
            self.log_key(key="lane:{}_dfeh3fb_en".format(self.current_lane), value=dfeh3fb_en, units='')
            self.log_key(key="lane:{}_dfeh2fb_en".format(self.current_lane), value=dfeh2fb_en, units='')
            self.log_key(key="lane:{}_dfeh1fb_en".format(self.current_lane), value=dfeh1fb_en, units='')


            h1_ticks = self.gray2dec(self.get_bits(self.LANE_RP_OFFSET +
                                             AUS_LANE0_DEBUG['DFE_CTRL13_RO'], 10,
                                             5))
            sign = self.gray2dec(self.get_bits(self.LANE_RP_OFFSET +
                                                   AUS_LANE0_DEBUG['DFE_CTRL13_RO'], 15,
                                                   1))
            if sign is 1:
                h1_sign = -1
            else:
                h1_sign = 1
            h1 = h1_sign * CONVERSION_MULTIPLICATION_FACTORS["h1"] * h1_ticks
            self.log_key(key="lane:{}_h1".format(
                self.current_lane),
                value=h1,
                units='mV')
            self.log_key(key="lane:{}_h1_ticks".format(
                self.current_lane),
                value=h1_ticks,
                units='ticks')

            sign = self.get_bits(self.LANE_RP_OFFSET +
                                             AUS_LANE0_DEBUG['DCORING_CTRL712_RO'], 24,
                                             1)
            if sign is 1:
                h2_sign = -1
            else:
                h2_sign = 1
            h2_ticks = self.gray2dec(self.get_bits(self.LANE_RP_OFFSET +
                                             AUS_LANE0_DEBUG['DCORING_CTRL712_RO'], 21,
                                             3))
            h2 = h2_sign * CONVERSION_MULTIPLICATION_FACTORS["h2"] * h2_ticks
            self.log_key(key="lane:{}_h2".format(
                self.current_lane),
                value=h2,
                units='mV')
            self.log_key(key="lane:{}_h2_ticks".format(
                self.current_lane),
                value=h2_ticks,
                units='ticks')
            sign1 = self.get_bits(self.LANE_RP_OFFSET +
                                             AUS_LANE0_DEBUG['DCORING_CTRL712_RO'], 29, 1)
            if sign1 is 1:
                h3_sign = -1
            else:
                h3_sign = 1
            h3_ticks = self.gray2dec(self.get_bits(self.LANE_RP_OFFSET +
                                             AUS_LANE0_DEBUG['DCORING_CTRL712_RO'], 26, 3))
            h3 = h3_sign * CONVERSION_MULTIPLICATION_FACTORS["h3"] * h3_ticks
            self.log_key(key="lane:{}_h3".format(
                self.current_lane),
                value=h3,
                units='mV')
            self.log_key(key="lane:{}_h3_ticks".format(
                self.current_lane),
                value=h3_ticks,
                units='ticks')
            sign2 = self.get_bits(self.LANE_RP_OFFSET +
                                             AUS_LANE0_DEBUG['DFE_CTRL13_RO'], 3, 1)
            if sign2 is 1:
                h4_sign = -1
            else:
                h4_sign = 1
            h4_ticks = self.gray2dec(self.get_bits(self.LANE_RP_OFFSET +
                                             AUS_LANE0_DEBUG['DFE_CTRL13_RO'], 0, 3))
            h4 = h4_sign * CONVERSION_MULTIPLICATION_FACTORS["h4"] * h4_ticks

            self.log_key(key="lane:{}_h4".format(
                self.current_lane),
                value=h4,
                units='mV')
            self.log_key(key="lane:{}_h4_ticks".format(
                self.current_lane),
                value=h4_ticks,
                units='ticks')
            sign5 = self.get_bits(self.LANE_RP_OFFSET +
                                             AUS_LANE0_DEBUG['DFE_CTRL13_RO'], 8, 1)
            if sign5 is 1:
                h5_sign = -1
            else:
                h5_sign = 1
            h5 = h5_sign * CONVERSION_MULTIPLICATION_FACTORS["h5"] * \
                 self.gray2dec(self.get_bits(self.LANE_RP_OFFSET +
                                             AUS_LANE0_DEBUG['DFE_CTRL13_RO'], 5, 3))
            self.log_key(key="lane:{}_h5".format(
                self.current_lane),
                value=h5,
                units='mV')

            aus_eq_ctrl_raw_cap_dclk_pos = self.gray2dec(self.get_bits(
                self.LANE_RP_OFFSET +
                AUS_LANE0_DEBUG['RXA_DCO_CTRL89_RO'],
                14, 7))
            self.log_key(key="lane:{}_aus_eq_ctrl_raw_cap_dclk_pos_raw".format(
                self.current_lane),
                value=aus_eq_ctrl_raw_cap_dclk_pos, units='ticks')
    
            aus_eq_ctrl_raw_cap_dclkb_pos = self.gray2dec(self.get_bits(
                self.LANE_RP_OFFSET +
                AUS_LANE0_DEBUG['RXA_DCO_CTRL89_RO'],
                21, 7))
    
            self.log_key(key="lane:{}_aus_eq_ctrl_raw_cap_dclkb_pos_raw".format(
                self.current_lane),
                value=aus_eq_ctrl_raw_cap_dclkb_pos, units='ticks')
    
            aus_eq_ctrl_raw_cap_xclk_pos = self.gray2dec(self.get_bits(
                self.LANE_RP_OFFSET +
                AUS_LANE0_DEBUG['DCOPI_CTRL10_RO'],
                0, 7))
            self.log_key(key="lane:{}_aus_eq_ctrl_raw_cap_xclk_pos_raw".format(
                self.current_lane),
                value=aus_eq_ctrl_raw_cap_xclk_pos, units='ticks')

            aus_eq_ctrl_raw_cap_xclkb_pos = self.gray2dec(self.get_bits(
                self.LANE_RP_OFFSET +
                AUS_LANE0_DEBUG['DCOPI_CTRL10_RO'],
                7, 7))
            self.log_key(key="lane:{}aus_eq_ctrl_raw_cap_xclkb_pos_raw".format(
                self.current_lane),
                value=aus_eq_ctrl_raw_cap_xclkb_pos, units='ticks')
        elif initial is False:
            cs = CONVERSION_OFFSET_FACTORS["c"] + CONVERSION_MULTIPLICATION_FACTORS["c"] * \
                 self.gray2dec(self.get_bits((self.LANE_RP_OFFSET +
                                              AUS_LANE0_DEBUG['AFE_CTRL16_RO']),
                                             7,
                                             4))
            self.log_reg("lane:{}_cs{}_units{}".format(self.current_lane, cs, 'db'))
            rs = CONVERSION_OFFSET_FACTORS["r"] + CONVERSION_MULTIPLICATION_FACTORS["r"] * \
                 self.gray2dec(self.get_bits(self.LANE_RP_OFFSET +
                                             AUS_LANE0_DEBUG['AFE_CTRL16_RO'], 19,
                                             4))
            self.log_reg("lane:{}_rs{}_units{}".format(self.current_lane, rs, 'db'))
            h1 = CONVERSION_MULTIPLICATION_FACTORS["h1"] * \
                 self.gray2dec(self.get_bits(self.LANE_RP_OFFSET +
                                             AUS_LANE0_DEBUG['DFE_CTRL13_RO'], 10,
                                             5))
            self.log_reg("lane:{}_h1{}_units{}".format(self.current_lane, h1, 'mV'))
            h2 = CONVERSION_MULTIPLICATION_FACTORS["h2"] * \
                 self.gray2dec(self.get_bits(self.LANE_RP_OFFSET +
                                             AUS_LANE0_DEBUG['DCORING_CTRL712_RO'], 21,
                                             3))
            self.log_reg("lane:{}_h2{}_units{}".format(self.current_lane, h2, 'mV'))
            h3 = CONVERSION_MULTIPLICATION_FACTORS["h3"] * \
                 self.gray2dec(self.get_bits(self.LANE_RP_OFFSET +
                                             AUS_LANE0_DEBUG['DCORING_CTRL712_RO'], 26, 3))
            self.log_reg("lane:{}_h3{}_units{}".format(self.current_lane, h3, 'mV'))
            h4 = CONVERSION_MULTIPLICATION_FACTORS["h4"] * \
                 self.gray2dec(self.get_bits(self.LANE_RP_OFFSET +
                                             AUS_LANE0_DEBUG['DFE_CTRL13_RO'], 0, 3))
            self.log_reg("lane:{}_h4{}_units{}".format(self.current_lane, h4, 'mV'))
            h5 = CONVERSION_MULTIPLICATION_FACTORS["h5"] * \
                 self.gray2dec(self.get_bits(self.LANE_RP_OFFSET +
                                             AUS_LANE0_DEBUG['DFE_CTRL13_RO'], 5, 3))
            self.log_reg("lane:{}_h5{}_units{}".format(self.current_lane, h5, 'mV'))

            aus_eq_ctrl_raw_cap_dclk_pos = self.gray2dec(self.get_bits(
                self.LANE_RP_OFFSET +
                AUS_LANE0_DEBUG['RXA_DCO_CTRL89_RO'],
                14, 7))
            self.log_reg("lane:{}_aus_eq_ctrl_raw_cap_dclk_pos_raw{}_{}".format(
                self.current_lane, aus_eq_ctrl_raw_cap_dclk_pos, 'ticks'))

            aus_eq_ctrl_raw_cap_dclkb_pos = self.gray2dec(self.get_bits(
                self.LANE_RP_OFFSET +
                AUS_LANE0_DEBUG['RXA_DCO_CTRL89_RO'],
                21, 7))

            self.log_reg("lane:{}_aus_eq_ctrl_raw_cap_dclkb_pos_raw_{},{}".format(self.current_lane,
                         aus_eq_ctrl_raw_cap_dclkb_pos,
                         'ticks'))

            aus_eq_ctrl_raw_cap_xclk_pos = self.gray2dec(self.get_bits(
                self.LANE_RP_OFFSET +
                AUS_LANE0_DEBUG['DCOPI_CTRL10_RO'],
                0, 7))
            self.log_reg("lane:{}_aus_eq_ctrl_raw_cap_xclk_pos_raw{}_{}".format(self.current_lane,
                                                                                    aus_eq_ctrl_raw_cap_xclk_pos,
                                                                                    'ticks'))
            aus_eq_ctrl_raw_cap_xclkb_pos = self.gray2dec(self.get_bits(
                self.LANE_RP_OFFSET +
                AUS_LANE0_DEBUG['DCOPI_CTRL10_RO'],
                7, 7))
            self.log_reg("lane:{}_aus_eq_ctrl_raw_cap_xclkb_pos_raw{}_{}".format(self.current_lane,
                                                                                aus_eq_ctrl_raw_cap_xclkb_pos, 'ticks'))
            for key, value in AUSPMA_LANE0_SMGR_registers.items():
                print(f"Trying to read register: {key}:{self.LANE_RP_OFFSET + value}")
                register_value = self.get_bits(self.LANE_RP_OFFSET + value, 0, 32)

                try:
                    self.log_key(key="lane:{}_{}".format(
                        self.current_lane,
                        key.replace("APCIE_DOWN_AUS_LANE0_AUSPMA_", "").lower()),
                        value=register_value, units='')
                except Exception as e:
                    print("Unable to read register: ", key, " due to ", e)

    def capture_errors(self):
        # Enable capture of D XOR E accumulator output
        ##### Step B --> E helper method #####
        # Step B - Enable Error Accumulator
        # Write Rx Eq Register CFG46_EQ: EN_ERR_ACC=1

        # Step C - Wait for desired number of bits (dwell time)
        # PCIe Gen3, one UI = 125 ps (one bit) so for 10^12 bits the wait is 125 seconds

        # Step D - Read number of errors
        # Write Rx EQ register to capture the error count
        # CFG46_EQ Cap Err Acc = 1
        # Read Rx EQ Register CFG44_EQ ERR ACC
        # Write Rx EQ Register
        # CFG46_EQ CAP ERR ACC = 0

        # Step E - Disable Error Accumulator
        # Write Rx EQ Register CFG46 EQ EN_ERR_ACC = 0
        ##### Step B --> E helper method #####

        print("Capture Errors")

        print("Enable Error Accumulator - EN ERR ACC = 1")
        # en_err_acc = 1
        self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RX_EQ_CFG46_EQ'], 20, 1, 1)

        time.sleep_ms(self.duration_ms)

        print("Read Number of Errors - Write to Capture to Error, Read Register, Cancel Error Accumulate")
        self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RX_EQ_CFG46_EQ'], 19, 1, 1)
        errors = int(self.get_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RX_EQ_CFG44_EQ'], 12, 20))
        self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RX_EQ_CFG46_EQ'], 19, 1, 0)

        print(f"Found Errors: {errors}")

        print("Disable Error Accumulator - EN ERR ACC = 0")
        # en_err_acc = 0
        self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RX_EQ_CFG46_EQ'], 20, 1, 0)

        return errors


    def start_margining(self):
        """Start the Margining"""
        # Eyescan Steps A->G for vertical scan and H->I for horizontal scan
        # X-Value Pi-Codes, Y-Value-H0 Dac

        self.mid_x = int((self.min_x + self.max_x) / 2)
        self.mid_x = self.gray2dec(self.get_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCO_CTRL89_RO'], 14, 7))

        # Sweep 64 to each side if not running full eye
        vco_bsel_div_code_r = int(self.get_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RX_TOP_CDR_CFG2'], 0, 2))

        self.log_key(key="lane_{}_div_code".format(self.current_lane), value=vco_bsel_div_code_r, units='ticks', retry=True)

        # if vco_bsel_div_code_r < 3:
        #     self.min_x = self.mid_x - 64
        #     self.max_x = self.mid_x + 64
        # else:
        self.min_x = self.mid_x - 32
        self.max_x = self.mid_x + 32

        # standard eye width ps
        self.TICK_TO_FREQUENCY = (self.TICK_TO_FREQUENCY / (2 ** abs(3-vco_bsel_div_code_r)))
        print(f"New Div Code: {vco_bsel_div_code_r} Tick To Freq: {self.TICK_TO_FREQUENCY}")

        # self.mid_y = self.gray2dec(self.get_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCO_CTRL89_RO'], 14, 7))
        # self.min_y = self.mid_y - 32
        # self.max_y = self.mid_y + 32

        print(f" Mid X: {self.mid_x} Min X: {self.min_x} Max X: {self.max_x}")
        print(f" Mid Y: {self.mid_y} Min Y: {self.min_y} Max Y: {self.max_y}")

        self.sleep_time = self.duration_ms / 1000

        print("Step A - Setup H0 Dac - CTRL91")

        # Start Position = 40
        # Can't presume starting at mid_x
        dclk_pos_decimal = self.gray2dec(self.get_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCO_CTRL89_RO'], 14, 7))

        # Capture Errors and adjust start point
        initial_point_errors = self.capture_errors()
        print(f"Initial Errors: {initial_point_errors} Div Code: {vco_bsel_div_code_r}")

        if int(vco_bsel_div_code_r) < 3:
            ### In the case where div_code = 2, center the eye at 64 and run +/- 63 ###
            # print(f"Centering the eye at 64")
            #
            # new_mid_x = 64
            # for time_coord in range(self.mid_x, new_mid_x, 1):  # Hardcoded value per Olivier
            #     print(f"Walking Time_Coord to {new_mid_x}: {time_coord} Gray Value: {self.dec2gray(time_coord)}")
            #     self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL61'], 0, 7, self.dec2gray(time_coord))
            #     self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL61'], 8, 7, self.dec2gray(time_coord))
            #     print(f" Touching DCOPI 61 Bits 0->6 and 8->14 Decimal: {time_coord} Gray: {self.dec2gray(time_coord)}")
            # self.mid_x = new_mid_x
            self.min_x = 0
            self.max_x = 127

        else:
            print("No Update Needed")

        # if int(initial_point_errors) > 0 and int(vco_bsel_div_code_r) == 2:
        #     print(f" Centering Eye at 104 instead of DCLK")
        #
        #     # Walk X Coord to new 104 value
        #     for time_coord in range(self.mid_x, 104, 1):  # Hardcoded value per Olivier
        #         print(f"Walking Time_Coord to 104: {time_coord} Gray Value: {self.dec2gray(time_coord)}")
        #         self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL61'], 0, 7, self.dec2gray(time_coord))
        #         self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL61'], 8, 7, self.dec2gray(time_coord))
        #         print(f" Touching DCOPI 61 Bits 0->6 and 8->14 Decimal: {time_coord} Gray: {self.dec2gray(time_coord)}")
        #
        #     self.mid_x = 104  # Hardcoded value per Olivier
        #     self.min_x = self.mid_x - 32
        #     self.max_x = self.mid_x + 32
        # else:
        #     print("No Update Needed")

        print(f" Post Update Mid X: {self.mid_x} Min X: {self.min_x} Max X: {self.max_x}")
        print(f" Post Update Mid Y: {self.mid_y} Min Y: {self.min_y} Max Y: {self.max_y}")

        print("Start by bringing Timing to Min-X For Eye Scan")
        for time_coord in range(dclk_pos_decimal, self.min_x - 1, -1):
            print(f"Walking Back Time_Coord: {time_coord} Gray Value: {self.dec2gray(time_coord)}")
            # Walk back to Pi (Time) value = min_x
            self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL61'], 0, 7, self.dec2gray(time_coord))
            time.sleep(10 / 1000000.0)
            self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL61'], 8, 7, self.dec2gray(time_coord))
            time.sleep(10 / 1000000.0)
            print(f" Touching DCOPI 61 Bits 0->6 and 8->14 Decimal: {time_coord} Gray: {self.dec2gray(time_coord)}")

        self.x_axis = [] # 32 code each direction + 1 center
        print("Margin X-Axis")
        for time_coord in range(self.min_x, self.max_x + 1):
            if time_coord > 127:
                print(f"Time Coord Overflow, Set to -128")
                time_coord = time_coord - 128

                if time_coord == 0: # Only for the coordinate immediately after
                    print(f"Found 0 Time Coord")
                    for time_coord_back in range(127, 0, -1):
                        print(f"Walking Back Time_Coord One Time: {time_coord_back} Gray Value: {self.dec2gray(time_coord_back)}")
                        # Walk back to Pi (Time) value = min_x
                        self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL61'], 0, 7, self.dec2gray(time_coord_back))
                        time.sleep(10 / 1000000.0)
                        self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL61'], 8, 7, self.dec2gray(time_coord_back))
                        time.sleep(10 / 1000000.0)
                        print(f" Touching DCOPI 61 Bits 0->6 and 8->14 Decimal: {time_coord_back} Gray: {self.dec2gray(time_coord_back)}")

            print(f"Setting X-Axis Coord Value: {time_coord} Gray Value: {self.dec2gray(time_coord)}")
            self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL61'], 0, 7, self.dec2gray(time_coord))
            time.sleep(10 / 1000000.0)
            self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL61'], 8, 7, self.dec2gray(time_coord))
            time.sleep(10 / 1000000.0)

            print(f" Touching DCOPI 61 Bits 0->6 and 8->14 Decimal: {time_coord} Gray: {self.dec2gray(time_coord)}")
            print(f"Scanning X-Axis Time Coord {time_coord} for Error")
            self.x_axis.append(self.capture_errors())

            ### Additional Logging ###
            deserializer_output = self.get_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_LPBK_CTRL_OBS4_RO'], 0, 20)
            vco_bsel_range_code_r = self.get_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RX_TOP_CDR_CFG2'], 2, 2)
            vco_bsel_div_code_r = self.get_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RX_TOP_CDR_CFG2'], 0, 2)
            print(f"Setting X-Cord Decimal: {time_coord} Gray: {self.dec2gray(time_coord)} Deserializer Output: {deserializer_output} "
                  f"BSEL Range Code: {vco_bsel_range_code_r} BSEL Div Code: {vco_bsel_div_code_r}")

        print("Bring X Timing Coordinate Back to Middle for Voltage Scan")
        for time_coord in range(self.max_x, self.mid_x - 1, -1):
            print(f"Walking Back Time_Coord: {time_coord} Gray Value: {self.dec2gray(time_coord)}")
            # Walk back to Pi (Time) value = min_x
            self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL61'], 0, 7, self.dec2gray(time_coord))
            time.sleep(10 / 1000000.0)
            self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL61'], 8, 7, self.dec2gray(time_coord))
            time.sleep(10 / 1000000.0)
            print(f" Touching DCOPI 61 Bits 0->6 and 8->14 Decimal: {time_coord} Gray: {self.dec2gray(time_coord)}")

        # ToDo: Once done iterating X what does AUS40PMA_RX_APB_OVERRIDE_REG_50 mean?

        self.y_axis = []
        for voltage in range(self.min_y, self.max_y + 1):
            print(f"Scanning Y-Axis Voltage: {voltage} Dec to Grey: {self.dec2gray(abs(voltage))} INT2SA Vos Code: {self.int2sa_vos_code(voltage)}")
            self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DESER_CTRL91'], 19, 6, self.int2sa_vos_code(voltage))
            time.sleep(1 / 1000000.0)
            self.y_axis.append(self.capture_errors())

        print("Walking h0dac back to middle eye")
        for voltage in range(self.max_y, self.mid_y-1, -1):
            print(
                f"Scanning Y-Axis Voltage: {voltage} Dec to Grey: {self.dec2gray(abs(voltage))} INT2SA Vos Code: {self.int2sa_vos_code(voltage)}")
            self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DESER_CTRL91'], 19, 6, self.int2sa_vos_code(voltage))
            time.sleep(1 / 1000000.0)


        print(f"X-Axis: {self.x_axis}")
        print(f"Y-Axis: {self.y_axis}")

        # Pi - Time - X-Axis - Steps H/I
        # Vol - Voltage - Y-Axis - Steps A/G

        # Step A - Setup H0 Dac - CTRL91
        #   DFEH0DAC_GRAY[5] = sign bit - 0 for positive sign and 1 for negative sign
        #   DFEH0DAC_GRAY[4:0] = DEC2GRAY(Value)

        # Step F - Iterate h0dac
        # Decrerment H0 DAC
        # Write Rx SHIM Register RX_DESER_CTRL91
        # DFEH0DAC_GRAY[5] = Sign Bit
        # DFEh0DAC_GRAY[4:0] = DEC2Gray(Prev_value-1)

        # At the end of Y-axis
        # Write RRx SHIM Register RX DESER CTRL91.DFEH0DAC_GRAY[5:0] Walk Back to Mid Value for X-axis

        # Step H Iterate Pi Codes
        # Covered all values? AUS40PMA_RX_APB_OVERRIDE_REG_50
        # ECKL_POS_GRAY / ECLKB_POS_GRAY -> Once Done Walk Back to the middle

        # Otherwise Increment Err_Pos by 1
        # Write RX SHIM Register RXA DCOPI_CTRL61
        # ECLK_POS_GRAY = Dec2Gray(Prev + 1)
        # ECLKB_POS_GRAY = Dec2Gray(Prev + 1)

        # At the end of the testing clear all margining registers and retrain link

    def save_eye(self):
        """Save the Eye Diagram"""
        f = open(self.log_path + f"\eyemargin_pcie{self.current_lane}.csv", "w")
        for y in range(0, len(self.y_axis)):
            row_write = ""
            self.mid_y = int((self.min_y + self.max_y) / 2)
            if y != int(self.mid_y - self.min_y):
                for x in range(0, self.mid_x - self.min_x):
                    row_write += " ,"  # pad so that the column for axis is in the middle
                row_write += f"{self.y_axis[y]},"
                for x in range(self.mid_x - self.min_x, self.max_x - self.min_x):
                    row_write += " ,"  # pad so that the column for axis is in the middle
            else:
                for value in self.x_axis:
                    row_write += f"{value},"
            row_write = row_write + '\n'
            f.write(row_write)
            print(f" Row: {row_write}")

        f.close()

    def calculate_eye(self):
        """Calculate the Eye Diagram for axis only"""
        self.save_eye()

        north, south, east, west = self.mid_y, self.mid_y, self.mid_x, self.mid_x

        print(f"Y-axis: {self.y_axis} X-axis {self.x_axis}")

        for coord in range(self.mid_y, self.max_y + 1):
            if self.y_axis[coord - self.min_y] == 0:
                north = coord
            if self.y_axis[coord - self.min_y] != 0:
                break

        for coord in range(self.mid_y, self.min_y - 1, -1):
            if self.y_axis[coord - self.min_y] == 0:
                south = coord
            if self.y_axis[coord - self.min_y] != 0:
                break

        for coord in range(self.mid_x, self.max_x + 1):
            if self.x_axis[coord - self.min_x] == 0:
                east = coord
            if self.x_axis[coord - self.min_x] != 0:
                break

        for coord in range(self.mid_x, self.min_x - 1, -1):
            if self.x_axis[coord - self.min_x] == 0:
                west = coord
            if self.x_axis[coord - self.min_x] != 0:
                break

        print(f"North: {north} South: {south} East: {east} West: {west}")

        height = north + abs(south)
        width = (east - west)
        print(f"Height: {height} Width: {width}")

        dfe_range_factor = self.get_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['DFE_CTRL13_RO'], 29, 2)
        if dfe_range_factor is 0:
            dfeh0dac_range = 0.5
        elif dfe_range_factor is 1:
            dfeh0dac_range = 1
        elif dfe_range_factor is 2:
            dfeh0dac_range = 1.5
        else:
            dfeh0dac_range = 2

        # RXA_ACCAP_CTRL5_RO.pma_rxa_afe_spare_0
        afe_spare_0 = self.get_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_ACCAP_CTRL5_RO'], 26, 1)
        print(f"dfe_range_factor: {dfe_range_factor} and afe_spare_0: {afe_spare_0}")

        # Set the Height / Width
        print(f"Tick Voltage: {self.TICK_TO_VOLTAGE} Tick Frequency: {self.TICK_TO_FREQUENCY}")
        if height >> 0 and width >> 0:
            self.eye_height[self.current_lane] = self.TICK_TO_VOLTAGE * (1+0.25*afe_spare_0) * dfeh0dac_range * (north + abs(south))
            self.eye_width[self.current_lane] = self.TICK_TO_FREQUENCY * (east - west)
            self.eye_height_ticks[self.current_lane] = north + abs(south)
            self.eye_width_ticks[self.current_lane] = east - west
        else:
            if height >> 0:
                self.eye_height[self.current_lane] = self.TICK_TO_VOLTAGE * (1+0.25*afe_spare_0) * dfeh0dac_range * (north + abs(south))
                self.eye_width[self.current_lane] = 0
                self.eye_height_ticks[self.current_lane] = north + abs(south)
                self.eye_width_ticks[self.current_lane] = 0
            elif width >> 0:
                self.eye_height[self.current_lane] = 0
                self.eye_width[self.current_lane] = self.TICK_TO_FREQUENCY * (east - west)
                self.eye_height_ticks[self.current_lane] = 0
                self.eye_width_ticks[self.current_lane] = east - west
            else:
                self.eye_height[self.current_lane] = 0
                self.eye_width[self.current_lane] = 0
                self.eye_height_ticks[self.current_lane] = 0
                self.eye_width_ticks[self.current_lane] = 0

        # Log them to the result file
        left_ew_ps = self.TICK_TO_FREQUENCY * (self.mid_x - west)
        right_ew_ps = self.TICK_TO_FREQUENCY * (east - self.mid_x)
        min_ew_ps = min(left_ew_ps, right_ew_ps)

        print("Log the Keys with the retry index for all attempts for SDCard / Wifi")
        if self.module in ["sdcard", "wifi", "sdgen2"]:
            print("SD Card / Wifi Found")
            self.log_key(key="lane_{}_north_ticks".format(self.current_lane), value=north, units='ticks', retry=True)
            self.log_key(key="lane_{}_south_ticks".format(self.current_lane), value=south, units='ticks', retry=True)
            self.log_key(key="lane_{}_east_ticks".format(self.current_lane), value=east, units='ticks', retry=True)
            self.log_key(key="lane_{}_west_ticks".format(self.current_lane), value=west, units='ticks', retry=True)
            self.log_key(key="lane_{}_eh_mv".format(self.current_lane), value=self.eye_height[self.current_lane],
                         units='mV', retry=True)
            self.log_key(key="lane_{}_ew_ps".format(self.current_lane), value=self.eye_width[self.current_lane],
                         units='ps', retry=True)
            self.log_key(key="lane_{}_eh_ticks".format(self.current_lane),
                         value=self.eye_height_ticks[self.current_lane], units='ticks', retry=True)
            self.log_key(key="lane_{}_ew_ticks".format(self.current_lane),
                         value=self.eye_width_ticks[self.current_lane], units='ticks', retry=True)
            self.log_key(key="lane_{}_leftright_2min_ew_ps".format(self.current_lane), value=2 * min_ew_ps, units='ps',
                         retry=True)

        self.retry_margining()
        print("Retry Flag: {} Retry Position: {} Retry Count: {}".format(self.retry_flag, self.retry_position,
                                                                         self.retry_count))
        if (self.retry_flag == 0) or self.retry_position == (self.retry_count - 1):
            print(
                "Either Retry Flag is 0, or we've hit last allowed iteration with a Fail, logging with limits and no retry index")
            print("lane_{}_eh_mv: {} lane_{}_ew_ps: {} ".format(self.current_lane, self.eye_height[self.current_lane],
                                                                self.current_lane, self.eye_width[self.current_lane]))
            self.log_key(key="lane_{}_north_ticks".format(self.current_lane), value=north, units='ticks')
            self.log_key(key="lane_{}_south_ticks".format(self.current_lane), value=south, units='ticks')
            self.log_key(key="lane_{}_east_ticks".format(self.current_lane), value=east, units='ticks')
            self.log_key(key="lane_{}_west_ticks".format(self.current_lane), value=west, units='ticks')
            self.log_key(key="lane_{}_eh_ticks".format(self.current_lane),
                         value=self.eye_height_ticks[self.current_lane], units='ticks')
            self.log_key(key="lane_{}_ew_ticks".format(self.current_lane),
                         value=self.eye_width_ticks[self.current_lane], units='ticks')
            self.log_key(key="lane_{}_leftright_2min_ew_ps".format(self.current_lane), value=2 * min_ew_ps, units='ps', upperlimit=self.ew_max, lowerlimit=self.ew_min)
            self.log_key(key="lane_{}_eh_mv".format(self.current_lane), value=self.eye_height[self.current_lane],
                         units='mV', upperlimit=self.eh_max, lowerlimit=self.eh_min)
            self.log_key(key="lane_{}_ew_ps".format(self.current_lane), value=self.eye_width[self.current_lane],
                         units='ps')
        else:
            if self.module not in ["sdcard", "wifi", "sdgen2"]:
                raise Exception("Not Logging Keys for Non-Retry PCIe Endpoint")
            else:
                print("Retrying SDCard / Wifi endpoint")

        self.log_msg("Lane {}: north = {}, south = {}, east = {}, west = {}, ns = {}mV, ew = {}ps".format(
            self.current_lane,
            north,
            south,
            east,
            west,
            self.eye_height[self.current_lane],
            self.eye_width[self.current_lane]
        ))

    def retry_margining(self):
        # Need both an eye height and an eye width failure to retry
        print(f"EH Max: {self.eh_max} EH Min: {self.eh_min} EW Max: {self.ew_max} EW Min: {self.ew_min}")
        print(f"Found EH: {self.eye_height[self.current_lane]} Found EW: {self.eye_width[self.current_lane]}")
        if (self.eh_max is not None and self.eye_height[self.current_lane] > self.eh_max) or (self.eh_min is not None and self.eye_height[self.current_lane] < self.eh_min):
            print("Eye Height Failure Detected")
            if self.module in ["sdcard", "wifi", "sdgen2"]:
                self.retry_flag = 1
                print("Valid Module for Failure")
            else:
                self.retry_flag = 0
                print("Invalid Module for Failure")
        else:
            print("No Eye Height Failure Detected")
            self.retry_flag = 0

        if (self.ew_max is not None and self.eye_width[self.current_lane] > self.ew_max) or (self.ew_min is not None and self.eye_width[self.current_lane] < self.ew_min):
            print("Eye Width Failure Detected")
            if self.module in ["sdcard", "wifi", "sdgen2"]:
                self.retry_flag = 1
                print("Valid Module for Failure")
            else:
                self.retry_flag = 0
                print("Invalid Module for Failure")
        else:
            print("No Eye Width Failure Detected")
            self.retry_flag = 0

    def parse_margin_data(self):
        """Parse data to the necessary format(s)"""
        return 1

    def clean_up(self):
        """Clean up margining and reset the PHY"""
        # print("Skipping Test End Verify Link Speed Until Olivier Can Investigate Failure")
        # self.verify_link_speed("Test End")
        self.status = 1

    #
    # Helpers
    #
    def progress(self):
        """Progress in integer % increments"""
        self.log_msg("   {}%".format(self._fake_progress))
        return self._fake_progress

    def is_running(self):
        """Check if Margining is running"""
        return self.progress < 100

    def all_lanes_scanned(self, lane):
        """Check if all lanes scanned, Used for tools that need to have individual lanes scanned"""
        if lane == self.LANE_COUNT:
            return 1
        else:
            self.log_msg("Didnt complete all lanes")

    def wait_for_finish(self):
        return 1
