_all_ = [
    'SOC_0x8103', # Tonga
    'SOC_0x8112', # Staten,
    'SOC_0x8122', # Ibiza,
    'SOC_0x8110', # Ellis
    'SOC_0x8030', # Cebu
    'SOC_0x8101', # Sicily
    'SOC_0x6000', # Jade C Chop
    'SOC_0x6001', # Jade C Die
    'SOC_0x6002', # Jade 2C
    'SOC_0x6020', # Rhodes C Chop
    'SOC_0x6021', # Rhodes C Die
    'SOC_0x6022', # Rhodes 2C
    'SOC_0x6030', # Lobos
    'SOC_0x6031', # Palma
    'SOC_0x6034', # Palma M
    'SOC_0x8130', # Coll
    'SOC_0x8120', # Crete
    'SOC_0x8132', # Donan
    'SOC_CONVERSION_CODE'
]

"""
Explanation:

SOC APCIE DOWN = Base Register Address of GP PCIE / APCIE DOWN Subsystem
SOC AUS Lane 0 = AUS Top Address Offset from SoC APCIE Down Base Address
				(Normally located within AUS Subsystem on SEG Docs)
SOC Lane Offset = AUS Lane 0 (and subsequent lanes) Base Address Offset from SOC AUS Lane 0
SoC GP Config = PCIE Config / PCIE GP Config Offset from SoC APCIE DOWN Base Address

Note: USE LANE_ADJUST only in cases where storage is in general purpose pcie and you have to adjust the register offsets
"""


SOC_0x8112 = { # Staten
    'SOC_APCIE_DOWN': 0x680000000,
    'SOC_AUS_LANE0': 0xc0000,
    'SOC_LANE_OFFSET': 0x8000,
    'SOC_GP_CONFIG': 0x10000000,
    'CFG_2': 0xc90b0,
    'LANE_ADJUST': 0
}


SOC_0x8122 = { # Ibiza
    'SOC_APCIE_DOWN': 0x580000000,
    'SOC_AUS_LANE0': 0x1e040000,
    'SOC_LANE_OFFSET': 0x8000,
    'SOC_GP_CONFIG': 0x00000000, # not verified
    'CFG_2': 0x1e0490b0,
    'LANE_ADJUST': 0
}


SOC_0x8103 = { # Tonga
    'SOC_APCIE_DOWN': 0x680000000,
    'SOC_AUS_LANE0': 0xc0000,
    'SOC_LANE_OFFSET': 0x8000,
    'SOC_GP_CONFIG': 0x10000000,
    'CFG_2': 0xc90b0,
    'LANE_ADJUST': 0
}


SOC_0x8110 = { # Ellis
    'SOC_APCIE_DOWN': 0x600000000,
    'SOC_AUS_LANE0': 0xc0000,
    'SOC_LANE_OFFSET': 0x8000,
    'SOC_GP_CONFIG': 0x10000000,
    'CFG_2': 0xc90b0,
    'LANE_ADJUST': 1
}


SOC_0x8030 = { # Cebu
    'SOC_APCIE_DOWN': 0x600000000,
    'SOC_AUS_LANE0': 0xc0000,
    'SOC_LANE_OFFSET': 0x4000,
    'SOC_GP_CONFIG': 0x10000000,
    'CFG_2': 0xc90b0,
    'LANE_ADJUST': 0
}


SOC_0x6020 = { # Rhodes C Chop
    'SOC_APCIE_DOWN': 0x580000000,
    'SOC_AUS_LANE0': 0x1e040000,
    'SOC_LANE_OFFSET': 0x8000,
    'SOC_GP_CONFIG': 0x00000000, # not verified
    'CFG_2':          0x1e0490b0, # 59E0490B0
    'LANE_ADJUST': 0
}


SOC_0x6021 = { # Rhodes C Die
    'SOC_APCIE_DOWN': 0x580000000,
    'SOC_AUS_LANE0':   0x1e040000,
    'SOC_LANE_OFFSET': 0x8000,
    'SOC_GP_CONFIG': 0x00000000, # not verified
    'CFG_2': 0x1e0490b0,
    'LANE_ADJUST': 0
}


SOC_0x6022 = { # Rhodes 2C
    'CFG_2': 0x1e0490b0,
    'SOC_APCIE_DOWN': 0x1680000000,
    'SOC_AUS_LANE0':  0x1e040000,
    'AUS_4L_SPLIT': 0x40000,
    'BASE_LANE_OFFSET': 0x8000,
    'SOC_LANE_OFFSET': 0x8000,
    'SOC_GP_CONFIG': 0x00000000,  # not verified
    'LANE_ADJUST': 1,
    'DIE_OFFSET': 0x2000000000
}


SOC_0x6000 = { # Jade C Chop
    'SOC_APCIE_DOWN': 0x580000000,
    'SOC_AUS_LANE0': 0xc0000,
    'SOC_LANE_OFFSET': 0x8000,
    'SOC_GP_CONFIG': 0x10000000,
    'CFG_2': 0xc90b0,
    'LANE_ADJUST': 0
}


SOC_0x6001 = { # Jade C  Die
    'SOC_APCIE_DOWN': 0x580000000,
    'SOC_AUS_LANE0': 0xc0000,
    'SOC_LANE_OFFSET': 0x8000,
    'SOC_GP_CONFIG': 0x10000000,
    'LANE_ADJUST': 0,
    'CFG_2': 0xc90b0,
    'DIE_OFFSET': 0x0000000000
}


SOC_0x6002 = { # Jade 2C
    'SOC_APCIE_DOWN': 0x580000000,
    'SOC_AUS_LANE0': 0xc0000,
    'SOC_LANE_OFFSET': 0x8000,
    'SOC_GP_CONFIG':  0x10000000,
    'LANE_ADJUST' : 0,
    'CFG_2': 0xc90b0,
    'DIE_OFFSET': 0x2000000000
}

SOC_0x6031 = {  # Palma
    'SOC_APCIE_DOWN': 0x580000000,
    'SOC_AUS_LANE0': 0x1e040000, # 0x0005_9e04_8000 - 0x580000000
    'SOC_LANE_OFFSET': 0x8000,
    'SOC_GP_CONFIG': 0x00000000, # not verified
    'CFG_2':           0x1e0490b0,
    'LANE_ADJUST': 0
}

SOC_0x6034 = {  # Palma
    'SOC_APCIE_DOWN': 0x580000000,
    'SOC_AUS_LANE0': 0x1e040000, # 0x0005_9e04_8000 - 0x580000000
    'SOC_LANE_OFFSET': 0x8000,
    'SOC_GP_CONFIG': 0x00000000, # not verified
    'CFG_2':           0x1e0490b0,
    'LANE_ADJUST': 0
}


SOC_0x6030 = {  # Lobos
    'SOC_APCIE_DOWN': 0x580000000,
    'SOC_AUS_LANE0': 0x1e040000,  #0x00059e048000 - 0x580000000
    'SOC_LANE_OFFSET': 0x8000,
    'SOC_GP_CONFIG': 0x00000000, # not verified
    'CFG_2': 0x1e0490b0,  # 0x00059e049000 - 0x580000000
    'LANE_ADJUST': 0
}

SOC_0x8101 = { # Sicily
    'SOC_APCIE_DOWN': 0x600000000,
    'SOC_AUS_LANE0': 0xc0000,
    'SOC_LANE_OFFSET': 0x8000,
    'SOC_GP_CONFIG': 0x10000000,
    'CFG_2': 0xc90b0,
    'LANE_ADJUST': 1
}

SOC_0x8130 = { # Coll
    'SOC_APCIE_DOWN': 0x580000000,
    'SOC_AUS_LANE0': 0x1e040000,  #0x00059e048000 - 0x580000000
    'SOC_LANE_OFFSET': 0x8000,
    'SOC_GP_CONFIG': 0x00000000, # not verified
    'CFG_2': 0x1e0490b0,  # 0x00059e049000 - 0x580000000
    'LANE_ADJUST': 0
}

SOC_0x8120 = { # Crete
    'SOC_APCIE_DOWN': 0x580000000,
    'SOC_AUS_LANE0': 0x1e040000,  #0x00059e048000 - 0x580000000
    'SOC_LANE_OFFSET': 0x8000,
    'SOC_GP_CONFIG': 0x00000000, # not verified
    'CFG_2': 0x1e0490b0,  # 0x00059e049000 - 0x580000000
    'LANE_ADJUST': 0
}

SOC_0x8132 = { # Donan
    'SOC_APCIE_DOWN': 0x490000000,
    'SOC_AUS_LANE0':    0x7040000,  # 0x497040000 - 0x490000000
    'SOC_LANE_OFFSET':     0x8000,  #
    'SOC_GP_CONFIG':   0x1820000000,  # 0x1cb0000080 - 0x490000080
    'CFG_2':            0x7049108,  # 0x497049108, 4AE0490B0
    'LANE_ADJUST': 0
}
# 497049108
# 4AE0490B0
#

SOC_CONVERSION_CODE = {
    '8030': SOC_0x8030,  # Tonga
    '8112': SOC_0x8112,  # Staten
    '8122': SOC_0x8122,  # Ibiza
    '8103': SOC_0x8103,  # Cebu
    '8110': SOC_0x8110,  # Ellis
    '8101': SOC_0x8101,  # Sicily
    '6000': SOC_0x6000,  # Jade C Chop
    '6001': SOC_0x6001,  # Jade C Die
    '6002': SOC_0x6002,  # Jade 2C
    '6020': SOC_0x6020,  # Rhodes C Chop
    '6021': SOC_0x6021,  # Rhodes C Die
    '6022': SOC_0x6022,  # Rhodes 2C
    '6030': SOC_0x6030,  # Lobos
    '6031': SOC_0x6031,  # Palma
    '6034': SOC_0x6034,  # Palma M
    '8130': SOC_0x8130,  # Coll
    '8120': SOC_0x8120,  # Crete
    '8132': SOC_0x8132,  # Donan
}
