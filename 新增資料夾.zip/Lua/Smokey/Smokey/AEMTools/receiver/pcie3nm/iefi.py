"""Access for iEFI"""
from .base import AbstractReceiverMarginTool
from shell import run
import re
import time
from .defines import *
__all__ = [
    "MarginTool"
]


def n_lsb(x):
    return (1 << x) - 1


def n_to_m(n, m):
    return n_lsb(n) & ~ n_lsb(m)


class MarginTool(AbstractReceiverMarginTool):
    """Margin Tool Instance"""

    def verify_cfg2_bits(self):
        two_bit = self.get_bits(self.cfg2_offset, 2, 2)
        zero_bit = self.get_bits(self.cfg2_offset, 0, 2)
        print("cfg2 two bit: {} cfg2 zero bit: {}".format(two_bit, zero_bit))
        if int(zero_bit) != 3:
            print("WARNING!!! Zero bit doesn't match 3")

    def verify_link_speed(self, timeframe):
        print(f" Start Verify Link Speed: {self.cfg2_offset}")
        self.verify_cfg2_bits()
        train_speed = self.get_bits(self.pcie_cfg_rp_offset + LINK_CAPABAILTIES['PCIE_CONTROL_LINK_STATUS'], 16, 4)
        print("Train Speed: {} Expected: {} Timeframe: {}".format(train_speed, self.gen_speed, timeframe))
        if train_speed == self.gen_speed:
            self.log_msg("trained to speed {}".format(train_speed))
            self.log_msg("Trained to the specified speed")
        else:
            raise Exception("PCIE link training failed {}".format(timeframe))

        print("Verify Link Width")
        self.verify_link_width(timeframe)
        print("Done Verify Link Speed")

    def verify_link_width(self, timeframe):
        gen_width = self.get_bits(self.pcie_cfg_rp_offset + LINK_CAPABAILTIES['PCIE_CONTROL_LINK_STATUS'], 20, 4)
        print("Found Gen Width: {} Expected: {} Timeframe: {}".format(gen_width, self.gen_width, timeframe))
        # if gen_width == self.gen_width:
        #     self.log_msg("trained to speed {}".format(gen_width))
        #     self.log_msg("Trained to the specified speed")
        # else:
        #     raise Exception("PCIE link training failed {}".format(timeframe))

    def turn_on_pcieeyescan(self):
        if self.pcie_startup:
            run("nand --poweroff")
            run("pcie --set setup_eyescan true")
            run("nand --poweron")

    def disable_power_management(self):
        if self.doe:
            print("Not running due to doe set to true!")
            return
        self.turn_on_pcieeyescan()

    def ensure_link(self):
        """Check Link meets Speed / Width requirements"""
        if self.doe:
            print("Doe is set to true. Skipping ensure_link")
            return

        # pcie --pick <#>
        # pcie --powerup
        # # do register writes to enable margining
        # pcie --linktrain

        if self.module not in ["microsemi", "ipc"]:
            print("Disabling Link to begin with to confirm it's off")
            self.clean_up()
            print("Done Disabling Link to begin with to confirm it's off")

        if self.module is "wifi":
            on = run("wifi --on")
            if "ERROR" not in on:
                self.log_msg("Turned on WiFi")

                if not self.uses_oss:
                    if self.pcie_port is not None:
                        data = run(f"pcie --pick {self.pcie_port}")
                    else:
                        data = run("pcie --pick {}".format(self.root_port))
                else:
                    data = run("pcie --pick 0")

                if "ERROR" not in data:
                    self.log_msg("Picked root port number {}".format(self.root_port))
                    # on_data = run("pcie --on")
                    # run("pcie --aspm off")
                    self.verify_link_speed("Test Start")
                else:
                    raise Exception("PCIE pick failed, please check port number")
            else:
                raise Exception("Failed turning on {}", self.module)

        elif self.module is "baseband":
            # Power on
            run("baseband --off;baseband --on --load")
            self.verify_link_speed("Test Start")
        elif self.module is "gpstorage":
            if not self.uses_oss:
                if self.pcie_port is not None:
                    run(f"pcie --pick {self.pcie_port}")
                else:
                    run(f"pcie --pick {self.root_port}")
            else:
                run("pcie --pick 0")

            on_data = run("nand --poweron")
            if "ERROR" not in on_data:
                run("nand --set DownlinkASPMControl 1")
                link_status = run("nand --debugread 0xA06")
                data = link_status.strip("\r\nOK")
                train_speed = data.split("value =")[1].strip(" ")
                if int(train_speed) is self.gen_speed:
                    self.log_msg("trained to speed {}".format(train_speed))
                    self.log_msg("Trained to the specified speed")
                else:
                    raise Exception("PCIE link training failed")
            else:
                raise Exception("PCIE on failed, please check its valid")

        elif self.module is "sdgen2": # New 9763 controller on Rhodes
            run("pmugpio --pin 22 --output 1; wait 1") # PMU GPIO command from Colin Szechy
            print("SDGen3 Enable for new GL9676 Chip")

            if not self.uses_oss:
                if self.pcie_port is not None:
                    run(f"pcie --pick {self.pcie_port}")
                else:
                    run(f"pcie --pick {self.root_port}")
            else:
                run("pcie --pick 0")

            # Check PCIE Gen
            on_data = run("pcie --on")

            if self.soc != '6030' and self.soc != '6031':   # Lobos / Palma use OSS
                run("pcie --aspm off")

            if "ERROR" not in on_data:
                train_speed = self.get_bits(self.pcie_cfg_rp_offset + LINK_CAPABAILTIES['PCIE_CONTROL_LINK_STATUS'], 16, 4)

                print(train_speed)
                if train_speed == self.gen_speed:
                    self.log_msg(
                        "trained to speed {}".format(train_speed))
                    self.log_msg("Trained to the specified speed")
                else:
                    raise Exception("PCIE link training failed")
            else:
                raise Exception(
                    "PCIE on failed, please check its valid")

        elif self.module is "sdgen3": # New 9763 controller on Rhodes
            run("pmugpio --pin 22 --output 1; wait 1") # PMU GPIO command from Colin Szechy
            print("SDGen3 Enable for new GL9676 Chip")
            run("i2c --devwrite 4 0x6a 0x40 0x1")
            run("i2c --devwrite 4 0x6a 0x7f 0x12")
            run("i2c --devwrite 4 0x6a 0xc4 0x81")
            run("i2c --devwrite 4 0x6a 0x7f 0x11")
            run("i2c --devwrite 4 0x6a 0xc8 0xd1")
            run("i2c --devwrite 4 0x6a 0xc4 0x91")
            run("i2c --devwrite 4 0x6a 0xc5 0xb1")

            if not self.uses_oss:
                if self.pcie_port is not None:
                    run(f"pcie --pick {self.pcie_port}")
                else:
                    run(f"pcie --pick {self.root_port}")
            else:
                run("pcie --pick 0")
            # Check PCIE Gen
            on_data = run("pcie --on")

            if self.soc != '6030' and self.soc != '6031':   # Lobos / Palma use OSS
                run("pcie --aspm off")

            if "ERROR" not in on_data:
                train_speed = self.get_bits(self.pcie_cfg_rp_offset + LINK_CAPABAILTIES['PCIE_CONTROL_LINK_STATUS'], 16, 4)

                print(train_speed)
                if train_speed == self.gen_speed:
                    self.log_msg(
                        "trained to speed {}".format(train_speed))
                    self.log_msg("Trained to the specified speed")
                else:
                    raise Exception("PCIE link training failed")

            else:
                raise Exception(
                    "PCIE on failed, please check its valid")

        elif self.module is "gen3sd":
            run("pmugpio --pin 26 --output 1; wait 1; socgpio --pin 227 --output 1")

            if not self.uses_oss:
                if self.pcie_port is not None:
                    run(f"pcie --pick {self.pcie_port}")
                else:
                    run(f"pcie --pick {self.root_port}")
            else:
                run("pcie --pick 0")
            # Check PCIE Gen
            on_data = run("pcie --on")

            if self.soc != '6030' and self.soc != '6031':   # Lobos / Palma use OSS
                run("pcie --aspm off")
            if "ERROR" not in on_data:
                self.verify_link_speed("Test Start")

            else:
                raise Exception(
                    "PCIE on failed, please check its valid")

        elif self.module == "ethernet" or self.module == "usb" or self.module == "sdcard":
            # Power on
            # Set PCIE Gen
            on_data = ""
            if self.module is "sdcard":
                run("sdcard --on")

            if not self.uses_oss:
                if self.pcie_port is not None:
                    run(f"pcie --pick {self.pcie_port}")
                else:
                    run(f"pcie --pick {self.root_port}")
            else:
                run("pcie --pick 0")

            # Check PCIE Gen
            if self.module == "ethernet" or self.module == "usb":
                on_data = run("pcie --on")

            if not self.uses_oss:
                run("pcie --aspm off")

            if "ERROR" not in on_data:
                self.verify_link_speed("Test Start")
            else:
                raise Exception("PCIE on failed, please check its valid")

        print("Done Ensure Link")

    def check_link(self):
        speed = run("pcie --get gen")
        if "gen" in speed:
            train_speed = re.search("= [\d]", speed).group(0).strip("=")[1]
            self.log_msg("trained to speed {}".format(train_speed))
            print("Train Speed: {} Expected: {}".format(train_speed, self.gen_speed))
            if int(train_speed) is self.gen_speed:
                self.log_msg("trained to speed {}".format(train_speed))
                self.log_msg("Trained to the specified speed")
            else:
                raise Exception("PCIE link training failed")

    def set_bits(self, address, start_bit, length, value):
        """Read registers"""
        mm_data = run("mm -w 4 -n {}".format(hex(address)))
        if "MEM" in mm_data:
            end_bit = start_bit + length
            a = mm_data.split(": ")
            reg_val = a[1].strip("\r\n")
            result = hex((int(reg_val, 16) & ~n_to_m(end_bit, start_bit)) | value << start_bit)
            run("mm -w 4 -n {} {}".format(hex(address), result))
        else:
            raise Exception("Set bits failed")

    def get_bits(self, address, start_bit, length):
        """Read registers"""
        mm_data = run("mm -w 4 -n {}".format(hex(address)))
        if "MEM" in mm_data:
            a = mm_data.split(": ")
            reg_val = a[1].strip("\r\n")
            bin_val = '{:>032}'.format(bin(int(reg_val, 16))[2:])
            end_pos = 31 - start_bit + 1
            start_pos = 31 - start_bit - length + 1
            bits = int(bin_val[start_pos:end_pos], 2)
            return bits
        else:
            raise Exception("Get bits failed")

    def write_register(self, address, data):
        """Write an offset"""
        mm_data = run("mm -w 4 -n {}".format(hex(address)))
        if "MEM" not in mm_data:
            raise Exception("Write Register failed")

    def read_register(self, address):
        """Read an offset"""
        mm_data = run("mm -w 4 -n {}".format(hex(address)))
        if "MEM" in mm_data:
            a = mm_data.split(": ")
            reg_val = a[1].strip("\r\n")
            return reg_val
        else:
            raise Exception("Read Register failed")

    def clean_up(self):
        super().clean_up()

        if self.module is "sdcard":
            run("sdcard --off")

        if self.module is "wifi":
            run("wifi --off")

        if self.module is "baseband":
            run("baseband --off")

        if not self.uses_oss:
            if self.pcie_port is not None:
                run(f"pcie --pick {self.pcie_port}")
            else:
                run(f"pcie --pick {self.root_port}")
        else:
            run("pcie --pick 0")

        if self.module is not "sdcard" and self.module is not "wifi":
            run("pcie --off")
