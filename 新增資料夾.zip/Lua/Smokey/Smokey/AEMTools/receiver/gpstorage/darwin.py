"""Access for iEFI"""
from .base import AbstractReceiverMarginTool
import os
import re
__all__ = [
	"MarginTool"
]


class MarginTool(AbstractReceiverMarginTool):
	"""Margin Tool Instance"""

	def ensure_link(self):
		"""Check Link meets Speed / Width requirements"""
		data = run("pcie --pick {} ". format(self.root_port))
		if "ERROR" not in data:
			on_data = run("pcie --on")
			if "ERROR" not in on_data:
				speed = run("pcie --get gen")
				if "gen" in speed:
					train_speed = re.search("= [\d]",speed).group(0)
					if train_speed is self.gen_speed:
						self.log_msg("Trained to the specified speed")
					else:
						raise Exception("PCIE link training failed")
				else:
					raise Exception("Failed when trying to check for link training")
			else:
				raise Exception("PCIE on failed, please check its valid")
		else:
			raise Exception("PCIE pick failed, please check port number")

	def set_bits(self, address, start_bit, length, value):
		"""Read registers"""
		bit_mask = (~(0xFFFFFFFF << length) << start_bit)
		temp1 = value << start_bit
		mm_data = os.system("mm -w 4 -n ..{}".format(address))
		if "MEM" in mm_data:
			a = re.search(": ([\dx]*)", mm_data).group(0)
			reg_val = a.strip(":").split("x")[1]
			result = "0x{}".format((~bit_mask & reg_val) | temp1)
			os.system("mm -w 4 -n ..{}..{}".format(address, result))
		else:
			raise Exception("Set bits failed")

	def get_bits(self, address, start_bit, length, value):
		"""Read registers"""
		temp1 = ~(0xFFFFFFFF << length)
		mm_data = run("mm -w 4 -n ..{}".format(address))
		if "MEM" in mm_data:
			a = re.search(": ([\dx]*)", mm_data).group(0)
			reg_val = a.strip(":").split("x")[1]
			temp2 = reg_val >> start_bit
			bits = temp2 and temp1
			return bits
		else:
			raise Exception("Get bits failed")

	def write_register(self, address, data):
		"""Write an offset"""
		os.system("mm -w 4 -n ..{}".format(address))

	def read_register(self, address):
		"""Read an offset"""
		mm_data = os.system("mm -w 4 -n ..{}".format(address))
		if "MEM" in mm_data:
			a = re.search(": ([\dx]*)", mm_data).group(0)
			reg_val = a.strip(":").split("x")[1]
			return reg_val
		else:
			raise Exception("Read Register failed")
