_all_ = [
	'SOC_0x8112', # Staten
	'SOC_0x8120', # Crete
	'SOC_0x8122', # Ibiza
	'SOC_0x6000', # Jade C Chop
	'SOC_0x6002', # Jade C Die
	'SOC_0x6020', # Rhodes C Chop
	'SOC_0x6021', # Rhodes C Die
	'SOC_0x6022', # Rhodes 2C
	'SOC_CONVERSION_CODE'
]


"""
Explanation:

SOC USB Offset = AUSB Subsystem Base Address
				(Sometimes located within AFNC on SEG Docs)
USB Top Offset = Offset from AUSBTop Subsystem Base Address to AUSB Subsystem Base  Address
USB PHY Offset = Offset from USB3PHY Subsystem Base Address to AUSBTop Subsystem Base Address 
AUSBPHY LANE0 = Offset from ACIOPHY Lane 0 Subsystem to USB3PHY Subsystem Base Address
LANE OFFSET = Offset from ACIOPHY Lane 1 Subsystem to AUSBPHY LANE0 System Base Address
"""

# No Sicily or Ellis or Cebu Drive Ports

SOC_0x8120 = { # Crete
	'SOC_USB_OFFSET': 0x260000000,
	'USB_TOP_OFFSET':   0x1000000,
	'USB_PHY_OFFSET':    0x980000,
	'AUSBPHY_LANE0':       0x8000,
	'LANE_OFFSET':         0x7000
}

SOC_0x6020 = { # Rhodes C Chop
	# ToDo: Sep. 9, 2021 - USBA addresses not yet available (Cameron)
	# Source: https://seg-docs.csg.apple.com/projects/rhodes/release/UserManual/regs/trunk/chop/chip__DIE_0.html?baseaddr=0x0
	'SOC_USB_OFFSET': 0x300000000, # not verified
	'USB_TOP_OFFSET': 0xd000000, # not verified
	'USB_PHY_OFFSET': 0x980000, # not verified
	'AUSBPHY_LANE0': 0x8000, # not verified
	'LANE_OFFSET': 0x7000 # not verified
}


SOC_0x6021 = { # Rhodes C Die
	# ToDo: Sep. 9, 2021 - USBA addresses not yet available (Cameron)
	# Source: https://seg-docs.csg.apple.com/projects/rhodes/release/UserManual/regs/trunk/chop/chip__DIE_0.html?baseaddr=0x0
	'SOC_USB_OFFSET': 0x300000000, # not verified
	'USB_TOP_OFFSET': 0xd000000, # not verified
	'USB_PHY_OFFSET': 0x980000, # not verified
	'AUSBPHY_LANE0': 0x8000, # not verified
	'LANE_OFFSET': 0x7000 # not verified
}


SOC_0x6022 = { # Rhodes 2C
	# ToDo: Sep. 9, 2021 - USBA addresses not yet available (Cameron)
	# Source: https://seg-docs.csg.apple.com/projects/rhodes/release/UserManual/regs/trunk/chop/chip__DIE_0.html?baseaddr=0x0
	'SOC_USB_OFFSET': 0x300000000, # not verified
	'USB_TOP_OFFSET': 0xd000000, # not verified
	'USB_PHY_OFFSET': 0x980000, # not verified
	'AUSBPHY_LANE0': 0x8000, # not verified
	'LANE_OFFSET': 0x7000 # not verified
}


SOC_0x8112 = { # Staten
	# ToDo: Sep. 9, 2021 - USBA reserved address marked but other offsets not yet available to be verified (Cameron)
	# Source: https://seg-docs.csg.apple.com/projects/staten/release/UserManual/regs_a0/chip.html
	'SOC_USB_OFFSET': 0x260000000, # reserved, not available yet
	'USB_TOP_OFFSET': 0xd000000, # not verified
	'USB_PHY_OFFSET': 0x980000, # not verified
	'AUSBPHY_LANE0': 0x8000, # not verified
	'LANE_OFFSET': 0x7000 # not verified
}


SOC_0x8122 = { # Ibiza
	# ToDo: Sep. 9, 2021 - USBA reserved address marked but other offsets not yet available to be verified (Cameron)
	# Source: https://seg-docs.csg.apple.com/projects/ibiza/release/UserManual/regs_a0/chip.html
	'SOC_USB_OFFSET': 0x260000000, # reserved, not available yet
	'USB_TOP_OFFSET': 0xd000000, # not verified
	'USB_PHY_OFFSET': 0x980000, # not verified
	'AUSBPHY_LANE0': 0x8000, # not verified
	'LANE_OFFSET': 0x7000 # not verified
}


SOC_0x6000 = { # Jade C Chop
	'SOC_USB_OFFSET': 0x300000000,
	'USB_TOP_OFFSET': 0xd000000,
	'USB_PHY_OFFSET': 0x980000,
	'AUSBPHY_LANE0': 0x8000,
	'LANE_OFFSET': 0x7000
}


SOC_0x6002 = { # Jade 2C
	'SOC_USB_OFFSET': 0x300000000,
	'USB_TOP_OFFSET': 0xd000000,
	'USB_PHY_OFFSET': 0x980000,
	'AUSBPHY_LANE0': 0x8000,
	'LANE_OFFSET': 0x7000
}


SOC_CONVERSION_CODE = {
	'8112': SOC_0x8112, # Staten,
	'8120': SOC_0x8120, # Crete
	'8122': SOC_0x8122, # Ibiza,
	'6000': SOC_0x6000, # Jade C Chop
	'6002': SOC_0x6002, # Jade 2C
	'6020': SOC_0x6020, # Rhodes C Chop
	'6021': SOC_0x6021, # Rhodes C Die
	'6022': SOC_0x6022 # Rhodes 2C
}

