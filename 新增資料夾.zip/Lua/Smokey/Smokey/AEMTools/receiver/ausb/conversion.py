_all_ = [
	"CONVERSION_MULTIPLICATION_FACTORS",
	"CONVERSION_OFFSET_FACTORS"
]


CONVERSION_MULTIPLICATION_FACTORS = {
		"h1": 13,
		"h2": 4,
		"h3": 4,
		"h4": 4,
		"h5": 4,
		"c": 0.5,
		"r": 0.6

	}

CONVERSION_OFFSET_FACTORS = {
		"c": 4,
		"r": -5.5

	}

