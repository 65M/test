"""Access for iEFI"""
from .base import AbstractReceiverMarginTool
from shell import run
import re
import time
from .defines import *
__all__ = [
    "MarginTool"
]


def n_lsb(x):
    return (1 << x) - 1


def n_to_m(n, m):
    return n_lsb(n) & ~ n_lsb(m)


class MarginTool(AbstractReceiverMarginTool):
    """Margin Tool Instance"""
    def verify_link_speed(self, timeframe):
        train_speed = self.get_bits(self.pcie_cfg_rp_offset + LINK_CAPABAILTIES['PCIE_CONTROL_LINK_STATUS'], 16, 4)
        print("Train Speed: {} Expected: {} Timeframe: {}".format(train_speed, self.gen_speed, timeframe))
        if train_speed == self.gen_speed:
            self.log_msg("trained to speed {}".format(train_speed))
            self.log_msg("Trained to the specified speed")
        else:
            raise Exception("PCIE link training failed {}".format(timeframe))

    def ensure_link(self):
        """Check Link meets Speed / Width requirements"""
        print("Ensure Link")
        run("pcie --pick 4")
        run("pcie --powerup")

        run("pcie --pick 21")
        run("pcie --powerup")

        print("Ensure Link Done")

    def set_bits(self, address, start_bit, length, value):
        """Read registers"""
        mm_data = run("mm -w 4 -n {}".format(hex(address)))
        if "MEM" in mm_data:
            end_bit = start_bit + length
            a = mm_data.split(": ")
            reg_val = a[1].strip("\r\n")
            result = hex((int(reg_val, 16) & ~n_to_m(
                end_bit, start_bit)) | value << start_bit)
            run("mm -w 4 -n {} {}".format(hex(address), result))
        else:
            raise Exception("Set bits failed")

    def get_bits(self, address, start_bit, length):
        """Read registers"""
        mm_data = run("mm -w 4 -n {}".format(hex(address)))
        if "MEM" in mm_data:
            a = mm_data.split(": ")
            reg_val = a[1].strip("\r\n")
            bin_val = '{:>032}'.format(bin(int(reg_val, 16))[2:])
            end_pos = 31 - start_bit + 1
            start_pos = 31 - start_bit - length + 1
            bits = int(bin_val[start_pos:end_pos], 2)
            return bits
        else:
            raise Exception("Get bits failed")

    def write_register(self, address, data):
        """Write an offset"""
        mm_data = run("mm -w 4 -n {}".format(hex(address)))
        if "MEM" not in mm_data:
            raise Exception("Write Register failed")

    def read_register(self, address):
        """Read an offset"""
        mm_data = run("mm -w 4 -n {}".format(hex(address)))
        if "MEM" in mm_data:
            a = mm_data.split(": ")
            reg_val = a[1].strip("\r\n")
            return reg_val
        else:
            raise Exception("Read Register failed")
