_all_ = [
    'SOC_0x6022', # Rhodes 2C
    'SOC_CONVERSION_CODE'
]

"""
Explanation:

SOC APCIE DOWN = Base Register Address of GP PCIE / APCIE DOWN Subsystem
SOC AUS Lane 0 = AUS Top Address Offset from SoC APCIE Down Base Address
				(Normally located within AUS Subsystem on SEG Docs)
SOC Lane Offset = AUS Lane 0 (and subsequent lanes) Base Address Offset from SOC AUS Lane 0
SoC GP Config = PCIE Config / PCIE GP Config Offset from SoC APCIE DOWN Base Address

Note: USE LANE_ADJUST only in cases where storage is in general purpose pcie and you have to adjust the register offsets
"""

SOC_0x6022 = { # Rhodes 2C
    'DIE_LANE_MAP': {'0':['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15'], '1':['16', '17', '18', '19', '20', '21', '22', '23']},
    'SOC_APCIE_DOWN': 0x1680000000,
    'SOC_AUS_LANE0': 0x1e040000,
    'AUS_4L_SPLIT': 0x40000,
    'BASE_LANE_OFFSET': 0x8000,
    'SOC_LANE_OFFSET': 0x8000,
    'SOC_GP_CONFIG': 0x00000000, # not verified
    'LANE_ADJUST': 1,
    'DIE_OFFSET': 0x2000000000
}


SOC_CONVERSION_CODE = {
    '6022': SOC_0x6022 # Rhodes 2C
}
