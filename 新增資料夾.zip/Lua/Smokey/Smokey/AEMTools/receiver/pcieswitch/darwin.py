"""Access for iEFI"""
from .base import AbstractReceiverMarginTool
import os
import re
__all__ = [
	"MarginTool"
]


class MarginTool(AbstractReceiverMarginTool):
	"""Margin Tool Instance"""
