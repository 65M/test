import time
import re
import math
from shell import run
from .defines import *
from ..base import AbstractBaseMarginTool
from .conversion import *
from .soc_defines import *

__all__ = [
	"AbstractReceiverMarginTool"
]


class AbstractReceiverMarginTool(AbstractBaseMarginTool):
	"""Generic Interface for Widget Pass Margining"""
	POLL_TIME = 1  # Polling interval
	TIMEOUT = 20.000  # Maximum time in seconds before a 'run' is timed out

	# Res Data is an array for each lane
	res_data = []
	res_vol_north_data = []
	res_vol_south_data = []
	res_pi_east_data = []
	res_pi_west_data = []
	res_vol_north_data_1 = []
	res_vol_south_data_1 = []
	res_pi_east_data_1 = []
	res_pi_west_data_1 = []

	# These points are individual points for each lane
	LANE_RP_OFFSET = []
	pcie_cfg_rp_offset = 0
	mid_x = []
	mid_y = []
	soc_apcie_down_offset = []

	# These values are constant
	soc_auspma_lane0_offset = 0
	pcie_cfg_offset = 0
	soc_lane_offset = 0

	def __init__(self, *args, **kwargs):
		super(AbstractReceiverMarginTool, self).__init__(*args, **kwargs)

		# The Number of lanes (if applicable)

		if self.board_rev == 4 or self.pfx84:
			self.LANE_COUNT = [16, 17, 18, 19, 20, 21, 22, 23]
		else:
			self.LANE_COUNT = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23]
		print(f"Running margining on {self.LANE_COUNT} lanes with board rev: {self.board_rev} PFX84: {self.pfx84}")

		self._fake_progress = 0

		# All these endpoints should have a Die offset since the Microsemi switch is multi-die.
		self.die_offset = SOC_CONVERSION_CODE[self.soc]['DIE_OFFSET']
		self.die_location = SOC_CONVERSION_CODE[self.soc]['DIE_LANE_MAP']
		self.die_length = int(len(self.die_location['0']))

		self.die_offset_addr = []
		self.die_number = []

		print(f"DIE Offset: {self.die_offset} DIE Lane Map: {self.die_location} DIE Length: {self.die_length} PCIE_CFG_RP: {self.pcie_cfg_offset}")

		self.auspma_lane0_offset = SOC_CONVERSION_CODE[self.soc]['SOC_AUS_LANE0']
		self.pcie_cfg_offset = SOC_CONVERSION_CODE[self.soc]['SOC_GP_CONFIG']
		self.lane_offset = SOC_CONVERSION_CODE[self.soc]['SOC_LANE_OFFSET']
		self.aus_4lane_split = SOC_CONVERSION_CODE[self.soc]['AUS_4L_SPLIT']

		for lane in self.LANE_COUNT:
			print(f"Setting Registers for Lane: {lane}")
			self.calculate_base_offset(lane)
			self.soc_apcie_down_offset.append(SOC_CONVERSION_CODE[self.soc]['SOC_APCIE_DOWN'] + self.die_offset_addr[self.LANE_COUNT.index(lane)])

			die_lane = lane - (self.die_number[self.LANE_COUNT.index(lane)] * self.die_length)
			lane_adjust_value = SOC_CONVERSION_CODE[self.soc]['LANE_ADJUST'] * self.lane_offset
			base_lane_adjust = lane_adjust_value + ((die_lane % 4) * self.lane_offset)
			aus_4l_split_adjust = (int(die_lane / 4) * self.aus_4lane_split)
			self.adjusted_lane_address = aus_4l_split_adjust + base_lane_adjust

			print(f"Die Lane: {die_lane} Lane Adjust: {lane_adjust_value} Base Lane Adjust: {base_lane_adjust} AUS 4L Split Adjust: {aus_4l_split_adjust}")
			self.LANE_RP_OFFSET.append(self.soc_apcie_down_offset[self.LANE_COUNT.index(lane)] + self.auspma_lane0_offset + self.adjusted_lane_address)
			print(f"Lane: {lane} RP Offset: {hex(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)])}")

		# Use default register root port 0 values for speed etc.
		self.pcie_cfg_rp_offset = self.soc_apcie_down_offset[0] + self.pcie_cfg_offset

	def calculate_base_offset(self, lane_num):
		"""Calculate the base pcie offset based on the port_num"""
		for key, value in self.die_location.items():
			if str(lane_num) in value:
				self.die_offset_addr.append(int(key) * self.die_offset)
				self.die_number.append(int(key))
				print("   Found Valid Key: {} in Die Location: {} for Lane Num: {} New Die Offset ADDR: {}   ".format(key, self.die_location, lane_num, self.die_offset_addr))
				self.log_msg("   Found Valid Key: {} in Die Location: {} for Lane Num: {}   ".format(key, self.die_location, lane_num))
				return
		raise Exception("    Lane Number: {} not found in Die Location: {}    ".format(lane_num, self.die_location))

	#
	#  Accessors
	#
	def write_register(self, address, value):
		"""Set Register to a value"""

	def read_register(self, address):
		"""Get a Register value"""

	def set_bits(self, address, start_bit, length, value):
		"""Change specific bits of a address"""

	def get_bits(self, address, start_bit, length):
		"""Change specific bits of a address"""

	def int2sa_vos_code(self, intval):
		""" convert to gray code from sign int 5 bits """
		if (intval < -31) or (intval > 31):
			return None
		elif intval >= 0:
			return intval ^ intval >> 1
		return abs(intval ^ intval >> 1) + 32

	def dec2gray(self, i=0):
		""" convert dec to gray """
		return i ^ i >> 1

	def gray2dec(self, i=0, total_bits=63):
		""" convert gray to dec """
		return [self.dec2gray(d) for d in range(total_bits)].index(i)

	#
	# Execution Flow
	#
	def set_adaptation(self, figure_of_merit):
		"""Set the Adaptation Type (if applicable)"""

	def apply_settings(self, retrain=True):
		"""Apply EQ and other settings, retrain (if applicable)"""

	def ensure_link(self):
		"""Check Link meets Speed / Width requirements"""

	def disable_power_management(self):
		"""Disable Power Management Modes"""
		self.log_msg("   Disable Power Management")

	def set_traffic_type(self, traffic_type):
		"""Select the Traffic type (Live, PRBS, etc)"""

	def select_lane(self, lane):
		"""Select a Lane"""

	def configure_phy(self):
		"""Configure the PHY Settings, Overrides, ECO, etc"""
		# https://seg-docs.csg.apple.com/projects/tonga/release/specs/Apple/AUSPMA/AUSPMA_Specification.pdf
		self.initial_dclk = []
		self.initial_dclkb = []

		print("Assume Link In D2 State")
		# print("Finish Link train")
		# run("pcie --pick 4")
		# run("pcie --linktrain")
		# run("pcie --pick 21")
		# run("pcie --linktrain")

		for lane in self.LANE_COUNT:
			print(f"Configure PHY Lane: {lane} Lane RP Offset: {hex(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)])}")
			self.set_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DESER_CTRL9'], 31, 1, 1)
			self.set_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DESER_CTRL9'], 30, 1, 0)

			# Change #1 (IQA): Olivier move your Bit 24 before Bit 25 to avoid a glitch
			self.set_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DCOPI_CTRL6'], 24, 1, 1)
			self.set_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DCOPI_CTRL6'], 25, 1, 1)

			self.set_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG27_EQ'], 8, 1, 1)
			self.set_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG27_EQ'], 9, 1, 1)

			# Change #4 (IQA): Set OV to 1
			self.set_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DCOPI_CTRL6'], 23, 1, 1)
			self.set_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DCOPI_CTRL6'], 15, 1, 1)

			# Change #2 (IQA): Read Back DCLK / DCLKB position
			dclk = self.gray2dec(self.get_bits((self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP2']), 14, 7))
			dclkb = self.gray2dec(self.get_bits((self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP2']), 21, 7))

			self.initial_dclk.append(dclk)
			self.initial_dclkb.append(dclkb)

			# Change #3 (IQA): Set grey value of ECLK / ECLKB to this value raw_eq_cap2 value DCLK / DCLK
			eclk = self.gray2dec(self.get_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DCOPI_CTRL6'], 16, 7))
			eclkb = self.gray2dec(self.get_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DCOPI_CTRL6'], 8, 7))

			print(f"[BEFORE LANE {lane}] DCLK: {dclk} DCLKB: {dclkb} ECLK :{eclk} ECLKB: {eclkb}")

			# Fix ECLK
			if eclk != dclk:
				direction = math.floor(((dclk - eclk) / dclk) + 0.5)
				print(f" Direction: {direction}")
				for difference in range(eclk, dclk, direction):
					print(f" Walking Back Difference: {difference} Gray Value: {self.dec2gray(difference)}")
					self.set_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DCOPI_CTRL6'], 8, 7, self.dec2gray(dclk))

			self.set_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DCOPI_CTRL6'], 8, 7, self.dec2gray(dclk))

			# Fix ECLKB
			if eclkb != dclkb:
				direction = math.floor(((dclkb - eclkb) / dclkb) + 0.5)
				print(f" Direction: {direction}")
				for difference in range(eclkb, dclkb, direction):
					print(f" Walking Back Difference: {difference} Gray Value: {self.dec2gray(difference)}")
					self.set_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DCOPI_CTRL6'], 16, 7, self.dec2gray(dclk))

			self.set_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DCOPI_CTRL6'], 16, 7, self.dec2gray(dclk))

			eclk = self.gray2dec(self.get_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DCOPI_CTRL6'], 16, 7))
			eclkb = self.gray2dec(self.get_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DCOPI_CTRL6'], 8, 7))
			dclk = self.gray2dec(self.get_bits((self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP2']), 14, 7))
			dclkb = self.gray2dec(self.get_bits((self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP2']), 21, 7))
			print(f"[AFTER LANE {lane}] DCLK: {dclk} DCLKB: {dclkb} ECLK :{eclk} ECLKB: {eclkb}")

		# run("pcie --pm l1")
		print("Finish Link train")
		run("pcie --pick 4")
		run("pcie --linktrain")
		run("pcie --pick 21")
		run("pcie --linktrain")

		output = run("dh -p PciRootBridgeIo")
		for line in output.split("\n"):
			m = re.search(r"(\w+): PCIRoot.*", line)
			if m:
				connect = m.group(1)
				print(f"Found Connect Port: {connect}")
				run(f"connect {connect}")

		self.verify_link_speed("Test Start")


	def setup_margining(self):
		"""Configure Margin Settings"""

		for lane in self.LANE_COUNT:
			print(f"Setup Margining Lane: {lane} Lane RP Offset: {hex(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)])}")
			self.read_register(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG27_EQ'])
			self.read_register(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DESER_CTRL9'])
			self.read_register(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DCOPI_CTRL6'])

			#   Check Link status
			data = self.read_register(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0_ADAPTATION_CHECK["APCIE_DOWN_AUS_LANE0_AUSPMA_RX_TOP_PMAFSM_REG0"])
			self.log_reg("Lane {} PMAFSM_REG0 is {}".format(lane, data))
			data = self.read_register(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0_ADAPTATION_CHECK["APCIE_DOWN_AUS_LANE0_AUSPMA_RX_TOP_PMAFSM_REG1"])
			self.log_reg("Lane {} PMAFSM_REG1 is {}".format(lane, data))

			#   Override for eclk, eclkb and and gray position overrides
			self.set_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DCOPI_CTRL6'], 23, 1, 1)
			self.set_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DCOPI_CTRL6'], 15, 1, 1)

			#	Overrides for enabling voltage scan, and setting the voltage to the center of the eye
			self.set_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DESER_CTRL9'], 22, 1, 1)
			self.set_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DESER_CTRL9'], 21, 1, 1)
			self.set_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DESER_CTRL9'], 20, 1, 1)
			self.set_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DESER_CTRL9'], 19, 1, 1)
			self.set_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DESER_CTRL9'], 29, 1, 1)
			self.set_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DESER_CTRL9'], 23, 6, self.int2sa_vos_code(0))
			self.set_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DFE_CTRL10'], 0, 1, 1)

			self.set_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DFE_CTRL11'], 3, 1, 1)
			self.set_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DFE_CTRL11'], 1, 2, 3)

			self.set_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DESER_CTRL9'], 14, 1, 1)
			self.set_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DESER_CTRL9'], 16, 1, 1)
			self.set_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DESER_CTRL9'], 15, 1, 1)
			self.set_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DESER_CTRL9'], 17, 1, 1)

			#  Error mask override and clearing the error accumulator enabling register
			self.write_register(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG46_EQ'], 0)
			self.set_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG42_EQ'], 3, 1, 0)


	def _update_status(self):
		"""Fake Progress updater"""
		for i in range(0, 101):
			self._fake_progress = i
			time.sleep(0.05)

	def padded_hex(self, i, l):
		given_int = i
		given_len = l

		hex_result = hex(given_int)[2:]  # remove '0x' from beginning of str
		num_hex_chars = len(hex_result)
		extra_zeros = '0' * (given_len - num_hex_chars)  # may not get used..

		return ('0x' + hex_result if num_hex_chars == given_len else
				'?' * given_len if num_hex_chars > given_len else
				'0x' + extra_zeros + hex_result if num_hex_chars < given_len else
				None)

	def xor_err_counter_read(self, lane):
		# Enable capture of D XOR E accumulator output
		print(f"XOR Error Count Read Lane: {lane}")
		self.set_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG46_EQ'], 20, 1, 1)
		time.sleep_ms(self.duration_ms)

		self.set_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] +AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG46_EQ'], 19, 1, 1)
		#  Read the error register
		data = self.get_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)]+ AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG44_EQ'], 12, 20)
		#  Disable Error accumulator enable
		self.set_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG46_EQ'], 19, 1, 0)
		self.set_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG46_EQ'], 20, 1, 0)
		print(f"Lane: {lane} XOR ERR COUNTER READ: {data}")

		return data

	def start_margining(self):
		"""Start the Margining"""
		for lane in self.LANE_COUNT:
			print(f"Start Margining Lane {lane} LANE RP Offset: {hex(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)])}")
			res_vol_north_data = []
			res_vol_south_data = []
			res_pi_west_data = []
			res_pi_east_data = []
			res_vol_north_data_1 = []
			res_vol_south_data_1 = []
			res_pi_west_data_1 = []
			res_pi_east_data_1 = []
			self.mid_x = (self.min_x + self.max_x) // 2

			#  Set X-Axis to Be Based Around Clk
			print(f"Lane: {lane} Initial DCLK: {self.initial_dclk}")

			print(f"Min X: {self.min_x} Mid X: {self.mid_x} Max X: {self.max_x}")

			max_x_diff = self.max_x - self.mid_x
			self.max_x = self.initial_dclk[lane] + max_x_diff

			min_x_diff = self.mid_x - self.min_x
			self.min_x = self.initial_dclk[lane] - min_x_diff

			self.mid_x = self.initial_dclk[lane]

			print(f"Min X: {self.min_x} Mid X: {self.mid_x} Max X: {self.max_x}")

			pi_idx = list(range(self.min_x, self.max_x))

			#  Make sure you bring to the edge of the PI code before scan, and only move by one step at a time.
			for i in range(self.mid_x, pi_idx[0], -1):
				self.set_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DCOPI_CTRL6'], 16, 7, self.dec2gray(i))
				self.set_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DCOPI_CTRL6'], 8, 7, self.dec2gray(i))

			if self.axis_only is True:
				self.mid_y = (self.min_y + self.max_y) // 2
				# Pi scan, again make sure you only move 1 step at a time
				for pi_val in pi_idx:
					print(f"PI_VAL: {pi_val} PI_IDX: {pi_idx}")
					self.set_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DCOPI_CTRL6'], 16, 7, self.dec2gray(pi_val))
					self.set_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DCOPI_CTRL6'], 8, 7, self.dec2gray(pi_val))
					if pi_val <= self.mid_x:
						error_data = self.xor_err_counter_read(lane)
						res_pi_west_data.append(error_data)
						res_pi_west_data_1.append(error_data)
						if pi_val == self.mid_x:
							res_pi_east_data.append(error_data)
							res_pi_east_data_1.append(error_data)

					elif pi_val > self.mid_x:
						error_data = self.xor_err_counter_read(lane)
						res_pi_east_data.append(error_data)
						res_pi_east_data_1.append(error_data)

				print(f" East Data: {res_pi_east_data} West Data: {res_pi_west_data}")
				# Bring pi back to mid, for voltage scan.
				for j in range(self.max_x, self.mid_x - 1, -1):
					self.set_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DCOPI_CTRL6'], 16, 7, self.dec2gray(j))
					self.set_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DCOPI_CTRL6'], 8, 7, self.dec2gray(j))
					self.read_register(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DCOPI_CTRL6'])

				# Do the voltage scan
				for vol in range(self.min_y, self.max_y + 1, self.step_y):
					self.set_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DESER_CTRL9'], 23, 6, self.int2sa_vos_code(vol))
					self.read_register(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DESER_CTRL9'])

					if vol <= self.mid_y:
						error_data = self.xor_err_counter_read(lane)
						res_vol_south_data.append(error_data)
						res_vol_south_data_1.append(error_data)
						if vol == self.mid_y:
							res_vol_north_data.append(error_data)
							res_vol_north_data_1.append(error_data)

					elif vol > self.mid_y:
						error_data = self.xor_err_counter_read(lane)
						res_vol_north_data.append(error_data)
						res_vol_north_data_1.append(error_data)
			else:
				raise Exception("Full scan not vetted out")

			self.res_vol_north_data.append(res_vol_north_data)
			self.res_vol_south_data.append(res_vol_south_data)
			self.res_pi_west_data.append(res_pi_west_data)
			self.res_pi_east_data.append(res_pi_east_data)
			self.res_vol_north_data_1.append(res_vol_north_data_1)
			self.res_vol_south_data_1.append(res_vol_south_data_1)
			self.res_pi_west_data_1.append(res_pi_west_data_1)
			self.res_pi_east_data_1.append(res_pi_east_data_1)

	def dump_registers(self, initial=False):
		"""Dump Static Registers check adaptation converged values"""
		# Set below to make sure h0,h1 etc are read right
		# Convert CTLE and DFE to actual training parameters
		# Read out dclk, xclk, dclkb and xclkb positions
		for lane in self.LANE_COUNT:
			self.current_lane = lane
			print(f"Dumping Registers Lane: {self.current_lane}")

			if initial is True:
				cs_ticks = self.gray2dec(self.get_bits((self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP1']), 4, 4))
				self.log_key(key="lane:{}_cs_ticks".format(
					self.current_lane),
					value=cs_ticks,
					units='ticks')
				cs = CONVERSION_OFFSET_FACTORS["c"] + CONVERSION_MULTIPLICATION_FACTORS["c"] * cs_ticks
				self.log_key(key="lane:{}_cs".format(
					self.current_lane),
					value=cs,
					units='db')
				rs_ticks = self.gray2dec(self.get_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP1'], 0, 4))
				self.log_key(key="lane:{}_rs_ticks".format(
					self.current_lane),
					value=rs_ticks,
					units='ticks')
				rs = CONVERSION_OFFSET_FACTORS["r"] + CONVERSION_MULTIPLICATION_FACTORS["r"] * rs_ticks
				self.log_key(key="lane:{}_rs".format(
					self.current_lane),
					value=rs,
					units='db')
				h1_ticks = self.gray2dec(self.get_bits((self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP1']), 8, 5))
				h1 = CONVERSION_MULTIPLICATION_FACTORS["h1"] * h1_ticks
				self.log_key(key="lane:{}_h1".format(
					self.current_lane),
					value=h1,
					units='mV')
				self.log_key(key="lane:{}_h1_ticks".format(
					self.current_lane),
					value=h1_ticks,
					units='ticks')
				sign = self.get_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP1'], 16, 1)
				if sign is 1:
					h2_sign = -1
				else:
					h2_sign = 1
				h2_ticks = self.gray2dec(self.get_bits(self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP1'], 13, 3))
				h2 = h2_sign * CONVERSION_MULTIPLICATION_FACTORS["h2"] * h2_ticks
				self.log_key(key="lane:{}_h2".format(
					self.current_lane),
					value=h2,
					units='mV')
				self.log_key(key="lane:{}_h2_ticks".format(
					self.current_lane),
					value=h2_ticks,
					units='ticks')
				sign1 = self.get_bits((self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP1']), 21, 1)
				if sign1 is 1:
					h3_sign = -1
				else:
					h3_sign = 1
				h3_ticks = self.gray2dec(self.get_bits((self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP1']), 17, 4))
				h3 = h3_sign * CONVERSION_MULTIPLICATION_FACTORS["h3"] * h3_ticks
				self.log_key(key="lane:{}_h3".format(
					self.current_lane),
					value=h3,
					units='mV')
				self.log_key(key="lane:{}_h3_ticks".format(
					self.current_lane),
					value=h3_ticks,
					units='ticks')
				sign2 = self.get_bits((self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP1']), 24, 1)
				if sign2 is 1:
					h4_sign = -1
				else:
					h4_sign = 1
				h4_ticks = self.gray2dec(self.get_bits((self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP1']), 21, 3))
				h4 = h4_sign * CONVERSION_MULTIPLICATION_FACTORS["h4"] * h4_ticks

				self.log_key(key="lane:{}_h4".format(
					self.current_lane),
					value=h4,
					units='mV')
				self.log_key(key="lane:{}_h4_ticks".format(
					self.current_lane),
					value=h4_ticks,
					units='ticks')
				sign5 = self.get_bits((self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP1']), 28, 1)
				if sign5 is 1:
					h5_sign = -1
				else:
					h5_sign = 1
				h5 = h5_sign * CONVERSION_MULTIPLICATION_FACTORS["h5"] * \
					 self.gray2dec(self.get_bits((self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP1']), 25, 3))
				self.log_key(key="lane:{}_h5".format(
					self.current_lane),
					value=h5,
					units='mV')
				aus_eq_ctrl_raw_cap_dclk_pos = self.gray2dec(self.get_bits((self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP2']), 14, 7))
				self.log_key(key="lane:{}_aus_eq_ctrl_raw_cap_dclk_pos_raw".format(
					self.current_lane),
					value=aus_eq_ctrl_raw_cap_dclk_pos, units='ticks')

				aus_eq_ctrl_raw_cap_dclkb_pos = self.gray2dec(self.get_bits((self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP2']), 21, 7))

				self.log_key(key="lane:{}_aus_eq_ctrl_raw_cap_dclkb_pos_raw".format(
					self.current_lane),
					value=aus_eq_ctrl_raw_cap_dclkb_pos, units='ticks')

				aus_eq_ctrl_raw_cap_xclk_pos = self.gray2dec(self.get_bits((self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP2']), 0, 7))
				self.log_key(key="lane:{}_aus_eq_ctrl_raw_cap_xclk_pos_raw".format(
					self.current_lane),
					value=aus_eq_ctrl_raw_cap_xclk_pos, units='ticks')

				aus_eq_ctrl_raw_cap_xclkb_pos = self.gray2dec(self.get_bits((self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP2']), 7, 7))
				self.log_key(key="lane:{}aus_eq_ctrl_raw_cap_xclkb_pos_raw".format(
					self.current_lane),
					value=aus_eq_ctrl_raw_cap_xclkb_pos, units='ticks')
			elif initial is False:
				cs = CONVERSION_OFFSET_FACTORS["c"] + CONVERSION_MULTIPLICATION_FACTORS["c"] * \
					 self.gray2dec(self.get_bits((self.LANE_RP_OFFSET [self.LANE_COUNT.index(lane)]+ AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP1']), 4, 4))
				self.log_reg("lane:{}_cs{}_units{}".format(self.current_lane, cs, 'db'))
				rs = CONVERSION_OFFSET_FACTORS["r"] + CONVERSION_MULTIPLICATION_FACTORS["r"] * \
					 self.gray2dec(self.get_bits((self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP1']), 0, 4))
				self.log_reg("lane:{}_rs{}_units{}".format(self.current_lane, rs, 'db'))
				h1 = CONVERSION_MULTIPLICATION_FACTORS["h1"] * \
					 self.gray2dec(self.get_bits((self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP1']), 8, 5))
				self.log_reg("lane:{}_h1{}_units{}".format(self.current_lane, h1, 'mV'))
				h2 = CONVERSION_MULTIPLICATION_FACTORS["h2"] * \
					 self.gray2dec(self.get_bits((self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP1']), 13, 4))
				self.log_reg("lane:{}_h2{}_units{}".format(self.current_lane, h2, 'mV'))
				h3 = CONVERSION_MULTIPLICATION_FACTORS["h3"] * \
					 self.gray2dec(self.get_bits((self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] +
												 AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP1']), 17,
												 4))
				self.log_reg("lane:{}_h3{}_units{}".format(self.current_lane, h3, 'mV'))
				h4 = CONVERSION_MULTIPLICATION_FACTORS["h4"] * \
					 self.gray2dec(self.get_bits((self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] +
												 AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP1']), 21,
												 4))
				self.log_reg("lane:{}_h4{}_units{}".format(self.current_lane, h4, 'mV'))
				h5 = CONVERSION_MULTIPLICATION_FACTORS["h5"] * \
					 self.gray2dec(self.get_bits((self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] +
												 AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP1']), 25,
												 4))
				self.log_reg("lane:{}_h5{}_units{}".format(self.current_lane, h5, 'mV'))

				aus_eq_ctrl_raw_cap_dclk_pos = self.gray2dec(self.get_bits((self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP2']), 14, 7))
				self.log_reg("lane:{}_aus_eq_ctrl_raw_cap_dclk_pos_raw{}_{}".format(self.current_lane, aus_eq_ctrl_raw_cap_dclk_pos, 'ticks'))

				aus_eq_ctrl_raw_cap_dclkb_pos = self.gray2dec(self.get_bits((self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP2']), 21, 7))
				self.log_reg("lane:{}_aus_eq_ctrl_raw_cap_dclkb_pos_raw_{},{}".format(self.current_lane, aus_eq_ctrl_raw_cap_dclkb_pos, 'ticks'))

				aus_eq_ctrl_raw_cap_xclk_pos = self.gray2dec(self.get_bits((self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP2']), 0, 7))
				self.log_reg("lane:{}_aus_eq_ctrl_raw_cap_xclk_pos_raw{}_{}".format(self.current_lane, aus_eq_ctrl_raw_cap_xclk_pos, 'ticks'))

				aus_eq_ctrl_raw_cap_xclkb_pos = self.gray2dec(self.get_bits((self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP2']), 7, 7))
				self.log_reg("lane:{}aus_eq_ctrl_raw_cap_xclkb_pos_raw{}_{}".format(self.current_lane, aus_eq_ctrl_raw_cap_xclkb_pos, 'ticks'))

	def calculate_eye(self):
		"""Calculate the Eye Diagram for axis only"""
		# Get the data for the lane (list of margin values)
		for lane in self.LANE_COUNT:
			self.current_lane = lane
			print(f"Calculate Eye Lane: {self.current_lane}")
			if self.axis_only is True:
				data = self.res_pi_west_data[self.LANE_COUNT.index(lane)]
			else:
				data = self.res_data[self.LANE_COUNT.index(lane)] # No valid data here

			if len(data) > 0:
				self.seq_log.info("      Dumping eye for lane {}".format(self.current_lane))
				north, south, east, west = self.mid_y, self.mid_y, self.mid_x, self.mid_x

				# Visual diagram and Raw diagram
				diagram, coords = "", ""

				# Iterate thru the coordinate Top Left to Bottom Right
				print("Iterate thru the coordinate Top Left to Bottom Right 1")
				if self.axis_only is True:
					for y in range(self.min_y, self.max_y, 1):
						for x in range(self.min_x, self.max_x, 1):
							if y != self.mid_y and x != self.mid_x:
								diagram += " "
								coords += "{}".format("     ") if x == self.max_x else ",{}". \
									format("     ")
							else:
								if y == self.mid_y:
									if x <= self.mid_x:
										margin = self.res_pi_west_data[self.LANE_COUNT.index(lane)].pop(0)
										if x == self.mid_x:
											self.res_pi_east_data[self.LANE_COUNT.index(lane)].pop(0)
									else:
										margin = self.res_pi_east_data[self.LANE_COUNT.index(lane)].pop(0)
								else:
									if y <= self.mid_y:
										margin = self.res_vol_south_data[self.LANE_COUNT.index(lane)].pop(0)
										if y == self.mid_y:
											self.res_vol_north_data[self.LANE_COUNT.index(lane)].pop(0)
									else:
										margin = self.res_vol_north_data[self.LANE_COUNT.index(lane)].pop(0)
								# Add to the Coordinate file
								if margin <= self.threshold:
									diagram += "0"
								else:
									diagram += "1"
								coords += "{}".format(self.padded_hex(margin, 5))
						coords += "\n"
						diagram += "\n"
					margin_south = self.res_vol_south_data_1[self.LANE_COUNT.index(lane)].pop()
					if margin_south <= self.threshold:
						# raise Exception(" DAC 0 0s have errors")
						south = self.mid_y
						while margin_south <= self.threshold and abs(south) < abs(self.min_y):
							margin_south = self.res_vol_south_data_1[self.LANE_COUNT.index(lane)].pop()
							south = south - 1
					else:
						south = self.mid_y
					margin_north = self.res_vol_north_data_1[self.LANE_COUNT.index(lane)].pop(0)
					if margin_north <= self.threshold:
						# raise Exception(" DAC 0 0s have errors")
						north = self.mid_y
						while margin_north <= self.threshold and north < self.max_y:
							margin_north = self.res_vol_north_data_1[self.LANE_COUNT.index(lane)].pop(0)
							north = north + 1
					else:
						north = self.mid_y
					margin_west = self.res_pi_west_data_1[self.LANE_COUNT.index(lane)].pop()
					if margin_west <= self.threshold:
						# raise Exception(" DAC 0 0s have errors")
						west = self.mid_x
						while margin_west <= self.threshold and west > self.min_x:
							margin_west = self.res_pi_west_data_1[self.LANE_COUNT.index(lane)].pop()
							west = west - 1
					else:
						west = self.mid_x
					margin_east = self.res_pi_east_data_1[self.LANE_COUNT.index(lane)].pop(0)
					if margin_east <= self.threshold:
						# raise Exception(" DAC 0 0s have errors")
						east = self.mid_x
						while margin_east <= self.threshold and east < self.max_x - 1:
							margin_east = self.res_pi_east_data_1[self.LANE_COUNT.index(lane)].pop(0)
							east = east + 1
					else:
						east = self.mid_x
				else:
					# Iterate thru the coordinate Top Left to Bottom Right
					print("Iterate thru the coordinate Top Left to Bottom Right 2")
					for y in range(self.min_y, self.max_y, 1):
						for x in range(self.min_x, self.max_x, 1):
							margin = data.pop(0)
							# Add to the Coordinate file
							coords += "{}".format(self.padded_hex(margin, 5)) if x == self.max_x else ",{}". \
								format(self.padded_hex(margin, 5))

							# Log only values below the threshold
							if margin <= self.threshold:
								diagram += "0"
								# Set the North / South values
								south = y if y < south else south
								north = y if y > north else north

								# Set the East / West values
								west = x if x < west else west
								east = x if x > east else east
							else:
								diagram += "1"

						coords += "\n"
						diagram += "\n"

				# Write the coordinate and diagram files
				print("Write the Coordinate and Diagram files")
				self.write_coordinate_file(coords)
				self.write_eye_diagram_file(diagram)

				# Set the Height / Width
				factor = self.get_bits((self.LANE_RP_OFFSET[self.LANE_COUNT.index(lane)] + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DFE_CTRL11']), 1, 2)
				print(f"Factor: {factor}")
				if factor is 0:
					mf = 0.5
				elif factor is 1:
					mf = 1
				elif factor is 2:
					mf = 1.5
				else:
					mf = 1.75
				height = north + abs(south)
				width = (east - west)
				print(f"Lane {self.current_lane} Height {height} Width {width} Tick Voltage {self.TICK_TO_VOLTAGE} Tick Freq {self.TICK_TO_FREQUENCY} "
					  f"MF {mf} North {north} South {south} East {east} West {west}")

				if height >> 0 and width >> 0:
					self.eye_height[self.current_lane] = self.TICK_TO_VOLTAGE * mf * (north + abs(south))
					self.eye_width[self.current_lane] = self.TICK_TO_FREQUENCY * (east - west)
					self.eye_height_ticks[self.current_lane] = north + abs(south)
					self.eye_width_ticks[self.current_lane] = east - west
				else:
					if height >> 0:
						self.eye_height[self.current_lane] = self.TICK_TO_VOLTAGE * mf * (north + abs(south))
						self.eye_width[self.current_lane] = 0
						self.eye_height_ticks[self.current_lane] = north + abs(south)
						self.eye_width_ticks[self.current_lane] = 0
					elif width >> 0:
						self.eye_height[self.current_lane] = 0
						self.eye_width[self.current_lane] = self.TICK_TO_FREQUENCY * (east - west)
						self.eye_height_ticks[self.current_lane] = 0
						self.eye_width_ticks[self.current_lane] = east - west
					else:
						self.eye_height[self.current_lane] = 0
						self.eye_width[self.current_lane] = 0
						self.eye_height_ticks[self.current_lane] = 0
						self.eye_width_ticks[self.current_lane] = 0

				print(f"Lane {self.current_lane} Log to Results File")
				# Log them to the result file
				left_ew_ps = self.TICK_TO_FREQUENCY * (self.mid_x - west)
				right_ew_ps = self.TICK_TO_FREQUENCY * (east - self.mid_x)
				min_ew_ps = min(left_ew_ps, right_ew_ps)

				print("lane_{}_eh_mv: {} lane_{}_ew_ps: {} ".format(self.current_lane, self.eye_height[self.current_lane], self.current_lane, self.eye_width[self.current_lane]))
				self.log_key(key="lane_{}_north_ticks".format(self.current_lane), value=north, units='ticks')
				self.log_key(key="lane_{}_south_ticks".format(self.current_lane), value=south, units='ticks')
				self.log_key(key="lane_{}_east_ticks".format(self.current_lane), value=east, units='ticks')
				self.log_key(key="lane_{}_west_ticks".format(self.current_lane), value=west, units='ticks')
				self.log_key(key="lane_{}_eh_ticks".format(self.current_lane),
							 value=self.eye_height_ticks[self.current_lane], units='ticks')
				self.log_key(key="lane_{}_ew_ticks".format(self.current_lane),
							 value=self.eye_width_ticks[self.current_lane], units='ticks')
				self.log_key(key="lane_{}_leftright_2min_ew_ps".format(self.current_lane), value=2 * min_ew_ps,
							 units='ps', upperlimit=self.ew_max, lowerlimit=self.ew_min)
				self.log_key(key="lane_{}_eh_mv".format(self.current_lane), value=self.eye_height[self.current_lane],
							 units='mV', upperlimit=self.eh_max, lowerlimit=self.eh_min)
				self.log_key(key="lane_{}_ew_ps".format(self.current_lane), value=self.eye_width[self.current_lane],
							 units='ps')

				self.log_msg("Lane {}: north = {}, south = {}, east = {}, west = {}, ns = {}mV, ew = {}ps".format(
					self.current_lane,
					north,
					south,
					east,
					west,
					self.eye_height[self.current_lane],
					self.eye_width[self.current_lane]
				))


	def parse_margin_data(self):
		"""Parse data to the necessary format(s)"""
		return 1

	def clean_up(self):
		"""Clean up margining and reset the PHY"""
		print("Skipping Test End Verify Link Speed Until Olivier Can Investigate Failure")
		# self.verify_link_speed("Test End")
		self.status = 1

	#
	# Helpers
	#
	def progress(self):
		"""Progress in integer % increments"""
		self.log_msg("   {}%".format(self._fake_progress))
		return self._fake_progress

	def is_running(self):
		"""Check if Margining is running"""
		return self.progress < 100

	def all_lanes_scanned(self, lane):
		"""Check if all lanes scanned, Used for tools that need to have individual lanes scanned"""
		print(f"Lane {lane} self.LANE_COUNT {self.LANE_COUNT}")
		print("Since we loop through all lanes for each part, automatically assume all lanes scanned")
		self.log_msg("Since we loop through all lanes for each part, automatically assume all lanes scanned")
		return 1
		# if lane == self.LANE_COUNT:
		# 	return 1
		# else:
		# 	self.log_msg("Didnt complete all lanes")

	def wait_for_finish(self):
		return 1
