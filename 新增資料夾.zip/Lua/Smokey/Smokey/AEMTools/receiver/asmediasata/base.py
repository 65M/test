from ..base import AbstractBaseMarginTool
import os
import re
__all__ = [
    "AbstractReceiverMarginTool"
]


class AbstractReceiverMarginTool(AbstractBaseMarginTool):
    """Generic Interface for ANS (Apple NAND System) Margining"""
    LANE_COUNT = 1  # This needs to be set at run time (it's base on the system)
    TIMEOUT = 180  # Set timeout to 2min (Average is 1-1.5)
    POLL_TIME = 2  # Poll every 2 seconds
    margin_data=()

    def __init__(self, *args, **kwargs):
        super(AbstractReceiverMarginTool, self).__init__(*args, **kwargs)


    def configure_phy(self):
        """Configure the PHY Settings, Overrides, ECO, etc"""
        pass

    def apply_settings(self, retrain=True):
        """Apply EQ and other settings, retrain (if applicable)"""

    # No settings to apply
    def ensure_link(self):
        """Check Link meets Speed / Width requirements"""
        # Get the Link Status, and calculate the Link Width / Speed

    # Not applicable, all lanes are margined together

    def setup_margining(self):
        """Configure the PHY and Setup Margining"""

    def start_margining(self):
        """Start the Margining"""

    def parse_output(self, output, conversion_table):
        register_value = None
        for line in output.split('\n'):
            value_match = re.search(r".*Register offset (\w+).*mapped at (\w+).*value (\w+).*", line)
            if value_match is not None:
                register_offset = value_match.group(1)
                register_map = value_match.group(2)
                register_value = int(str(value_match.group(3)), 16)

                print(f"Register Offset: {register_offset} Register Map: {register_map} Register Value: {register_value}")

        if register_value is None:
            raise Exception("Unable to find matching register value")

        return conversion_table[register_value]

    def dump_registers(self, initial=False):
        """Dump Static Registers"""
        print(f"Calling Dump Registers with Initial {initial}")
        if initial:
            print("Dump PCIe EQ")
            """
            [00100] = 3.3dB manual mode = 4
            [00001] = 4.5dB manual mode = 1
            [00010] = 6.4dB manual mode = 2
            [00110] = 7.8dB manual mode = 6
            [01101] = 8.5dB manual mode = 13
            [01011] = 10.0dB manual mode = 11
            [00111] = 10.6dB manual mode = 7
            [01100] = 12.0dB manual mode = 12
            [01110] = 13.6dB manual mode = 14
            [11110] = 16.6dB manual mode = 30
            """
            conversion_table = [0.0] * 64
            conversion_table[4] = 3.3
            conversion_table[1] = 4.5
            conversion_table[2] = 6.4
            conversion_table[6] = 7.8
            conversion_table[13] =8.5
            conversion_table[11] = 10.0
            conversion_table[7] = 10.6
            conversion_table[12] = 12.0
            conversion_table[14] = 13.6
            conversion_table[30] = 16.6

            self.run_asmedia_cmd('device -k sata -e vendor_write 1 0xefe 0x0')

            output = self.run_asmedia_cmd('device -k sata -e vendor_read 1 0xc33')
            register_value_converted = self.parse_output(output, conversion_table)
            self.log_key(key="port_0_lane_0_pcie_rx_eq_db", value=register_value_converted, units='ticks', lowerlimit=None, upperlimit=None)

            output = self.run_asmedia_cmd('device -k sata -e vendor_read 1 0xc53')
            register_value_converted = self.parse_output(output, conversion_table)
            self.log_key(key="port_0_lane_1_pcie_rx_eq_db", value=register_value_converted, units='ticks', lowerlimit=None, upperlimit=None)

            self.run_asmedia_cmd('device -k sata -e vendor_write 1 0xefe 0x1')

            output = self.run_asmedia_cmd('device -k sata -e vendor_read 1 0xc33')
            register_value_converted = self.parse_output(output, conversion_table)
            self.log_key(key="port_1_lane_0_pcie_rx_eq_db", value=register_value_converted, units='ticks', lowerlimit=None, upperlimit=None)

            output = self.run_asmedia_cmd('device -k sata -e vendor_read 1 0xc53')
            register_value_converted = self.parse_output(output, conversion_table)
            self.log_key(key="port_1_lane_1_pcie_rx_eq_db", value=register_value_converted, units='ticks', lowerlimit=None, upperlimit=None)

            conversion_table = [0.0] * 64
            conversion_table[1] = 1.9
            conversion_table[2] = 3.0
            conversion_table[6] = 4.4
            conversion_table[13] = 5.3
            conversion_table[11] = 6.4
            conversion_table[15] = 7.3
            conversion_table[31] = 8.3
            conversion_table[63] = 9.8

            print("Write Port 0")
            self.run_asmedia_cmd('device -k sata -e vendor_write 1 0xefe 0x0')
            output = self.run_asmedia_cmd('device -k sata -e vendor_read 1 0xf35')
            register_value_converted = self.parse_output(output, conversion_table)
            self.log_key(key="port_0_sata_rx_eq_db", value=register_value_converted, units='ticks', lowerlimit=None, upperlimit=None)

            print("Write Port 1")
            self.run_asmedia_cmd('device -k sata -e vendor_write 1 0xefe 0x1')
            output = self.run_asmedia_cmd('device -k sata -e vendor_read 1 0xf35')
            register_value_converted = self.parse_output(output, conversion_table)
            self.log_key(key="port_1_sata_rx_eq_db", value=register_value_converted, units='ticks', lowerlimit=None, upperlimit=None)

    def parse_margin_data(self):
        """Parse data to the necessary format(s)"""
        print("No Margining Data to Process To Run")

    def calculate_eye(self):
        """Parse data to the necessary format(s)"""
        # Parse the output
        self.parse_margin_data()

    #
    # Helpers
    #
    def progress(self):
        """Progress in integer % increments"""
        self.log_msg("   {}%".format(self._fake_progress))
        return self._fake_progress

    def is_running(self):
        """Check if Margining is running"""
        return self.progress < 100

    def all_lanes_scanned(self, lane):
        """Check if all lanes scanned, Used for tools that need to have individual lanes scanned"""
        if lane == self.LANE_COUNT:
            return 1
        else:
            self.log_msg("Didnt complete all lanes")

    def wait_for_finish(self):
        return 1

