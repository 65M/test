"""Access for iEFI"""
import sys
import logging
from .base import AbstractReceiverMarginTool
from shell import run
import os
import re

__all__ = [
    "MarginTool"
]

seq_log = logging.getLogger("sequence")


class MarginTool(AbstractReceiverMarginTool):
    """Margin Tool Instance"""

    def ensure_link(self):
        """Check Link meets Speed / Width requirements"""
        print("Ensure Link")
        # ToDo: Long-Term Add Commonality To These Methods 
        try:
            run("device -k sata -e enable")
        except Exception as e:
            print(f"Found Exception: {e}, Device Might Have Already Been Powered On, Moving On")
        print("Turned on ASMedia SATA")
        run("device -k sata -g info")
        run("device -k sata -g ports")
        run("device -k sata -g error")
        print("Grabbed ASMedia SATA Data")

    def run_asmedia_cmd(self, cmd):
        print(cmd)
        return run(cmd)

    def start_margining(self):
        print("No Margining To Run")