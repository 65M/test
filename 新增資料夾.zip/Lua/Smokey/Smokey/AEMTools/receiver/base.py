import os
import time
import logging

from factorylogcollector import pdcaplist
from .defines import *
from pdca.record import ParametricPDCARecord
from pdca.run import PDCARun
from datetime import datetime
from datetime import timezone

__all__ = [
	"AbstractBaseMarginTool"
]


class AbstractBaseMarginTool:
	"""Generic Margin Tool"""

	TIMEOUT = 5  # Maximum time in seconds before a 'run' is timedout
	POLL_TIME = 2  # Polling interval
	LANE_COUNT = 1  # The Number of lanes (if applicable)

	def __init__(
			self,
			log_path,
			additional_pdca_name=None,
			device=None,
			device_index=0,
			cycle_count=1,
			current_cycle=0,
			adaptation_run=0,
			tool_cycle_count=1,
			debug=False,
			endpoint="None",
			root_port=0,
			product_code=None,
			letter_code=None,

			# Optional Scan Configuration
			axis_only=False,
			min_x=None,
			max_x=None,
			min_y=None,
			max_y=None,
			step_x=None,
			step_y=None,
			duration_ms=None,
			timeout_s=None,
			delay_us=None,
			threshold=0,
			adaptation_types=None,
			por_adaptations=[],
			ctle_sweep=False,
			dfe_off=False,
			traffic_type=TRAFFIC_TYPE.LIVE,
			vendor_specific=None,
			gen_width=0,
			gen_speed=0,
			module=None,
			tick_voltage=0,
			tick_frequency=0,
			doe=False,
			doe_no=None,
			soc=None,
			board_rev=None,
			plist=True,
			lane_no=None,
			eh_min=None,
			eh_max=None,
			ew_min=None,
			ew_max=None,
			die_location=None,
			disable_aspm_val=None,
			port_list=None,
			enable_aspm_val=None,
			folder_name=None,
			controller_count=None,
			controller_numbers=None,
			en_endpoints=None,
			link_status_endpoints=None,
			lane_count=None,
			route=None,
			atc_port=None,
			rt13_lane=None,
			rt13_layout=None,
			rt13_initialize=None,
			rt13_verify=None,
			rt13_dfe=None,
			load_fw=None,
			intel_hw=None,
			max_pcie_lanes=None,
			depth=5,
			phy=None,
			gen_version=None,
			microsemi_endpoint=None,
			port_enablement=None,
			score=None,
			pcie_lane_count=None,
			swing=None,
			camera_voltage_register=None,
			camera_voltage_translation=None,
			camera_linkrate=None,
			dump_h0=None,
			verify_linkrate=None,
			pfx84=None,
			bio_moly=None,
			moly_index_list=None,
			prbs_ports=None,
			prbs_loopback=None,
			host_name=None,
			port=None,
			uses_oss=None,
			pcie_port=None,
			pcie_startup=False,
			pcie_gpio=None,
			error_mask=0,
			special_pdca_format=False,
	):
		self.soc = soc
		self.board_rev = board_rev
		self.product_code = product_code
		self.letter_code = letter_code

		# Endpoint
		self.endpoint = endpoint
		self.device = device

		# Root-port
		self.root_port = root_port

		# Die Location
		self.die_location = die_location

		# AQC 113 Arguments
		self.disable_aspm_val = disable_aspm_val
		self.enable_aspm_val = enable_aspm_val
		self.folder_name = folder_name
		self.controller_count = controller_count
		self.controller_numbers = controller_numbers
		self.en_endpoints = en_endpoints
		self.link_status_endpoints = link_status_endpoints
		self.lane_count = lane_count

		# ASMedia Arguments
		self.max_pcie_lanes = max_pcie_lanes

		# Depth
		self.depth = depth

		# PHY
		self.phy = phy

		# PCIe
		self.pcie_lane_count = pcie_lane_count
		self.uses_oss = uses_oss

		# RT13 Arguments
		self.rt13_lane = rt13_lane
		self.rt13_layout = rt13_layout
		self.rt13_initialize = rt13_initialize
		self.rt13_verify = rt13_verify
		self.rt13_dfe = rt13_dfe
		self.dump_h0 = dump_h0
		self.prbs_ports = prbs_ports,
		self.prbs_loopback = prbs_loopback,
		self.port_list = port_list

		# Cobra
		self.atc_port = atc_port
		self.route = route

		self.pfx84 = pfx84
		self.bio_moly = bio_moly
		self.moly_index_list = moly_index_list

		self.load_fw = load_fw
		self.intel_hw = intel_hw

		# Camera
		self.swing = swing
		self.camera_voltage_translation = camera_voltage_translation
		self.camera_voltage_register = camera_voltage_register
		self.camera_linkrate = camera_linkrate
		self.verify_linkrate = verify_linkrate

		# Gen Version
		self.gen_version = gen_version

		# Microsemi Endpoints
		self.microsemi_endpoint = microsemi_endpoint
		self.port_enablement = port_enablement
		self.score = score

		# Device Index
		self.device_index = device_index

		#Lane no
		self.lane_no = lane_no

		# Cycling info
		self.cycle_count = cycle_count
		self.current_cycle = current_cycle
		self.tool_cycle_count = tool_cycle_count
		self.adaptation_run=0
		self.retry_count = 3
		self.retry_flag = 0
		self.retry_position = -1
		self.current_adaptation = None

		# Scan Configuration
		self.axis_only = axis_only  # Axis only (or Full)
		self.min_x = min_x  # Minimum X (tick) coordinate
		self.max_x = max_x  # Maximum X (tick) coordinate
		self.min_y = min_y  # Minimum Y (tick) coordinate
		self.max_y = max_y  # Maximum Y (tick) coordinate
		self.step_x = step_x  # Step size between X coordinates
		self.step_y = step_y  # Step size between Y coordinates
		self.delay_us = delay_us  # Delay time between coordinates
		self.duration_ms = duration_ms  # Total Duration or dwell at a coordinate
		self.timeout_s = timeout_s or self.TIMEOUT  # Timeout at a coordinate
		self.threshold = threshold  # Bit Error Threshold, 0 is default
		self.adaptation_types = adaptation_types or [0]  # Adaptation Types (list)
		self.traffic_type = traffic_type  # Traffic type (Live, PRBS7, etc)
		self.vendor_specific = vendor_specific or {}  # Vendor specific options
		self.gen_width = gen_width
		self.gen_speed = gen_speed
		self.module = module
		# Lane Number (for Parallel buses such as DP or PCIe)
		self.current_lane = 0
		# Eye Height / Width, Zero until we actually collect data and specs
		self.eh_min = eh_min
		self.eh_max = eh_max
		self.ew_min = ew_min
		self.ew_max = ew_max
		self.eye_height = {}
		self.eye_width = {}
		self.eye_height_ticks = {}
		self.eye_width_ticks = {}
		self.TICK_TO_VOLTAGE = tick_voltage  # Unit conversion from ticks to mV
		self.TICK_TO_FREQUENCY = tick_frequency  # Unit conversion from ticks to ps
		# Loop through tool for different settings on a give lane
		self.current_tool_cycle = 0
		# doe
		self.doe = doe
		self.doe_no = doe_no
		self.ctle_sweep = ctle_sweep
		self.dfe_off = dfe_off
		# plist creation True or False
		self.plist = plist
		self.por_adaptations = por_adaptations

		self.host_name = host_name
		self.port = port
		self.pcie_port = pcie_port
		self.pcie_startup = pcie_startup
		self.pcie_gpio = pcie_gpio
		self.error_mask = error_mask

		self.special_pdca_format = special_pdca_format

		# Configure Logging
		self.log_path = log_path
		try:
			os.makedirs(self.log_path)
		except OSError:
			pass

		if additional_pdca_name:
			self.additional_pdca_name = additional_pdca_name
		else:
			self.additional_pdca_name = "pdca.plist"

		try:
			# Results (data) Logging
			self.result_file = os.path.join(self.log_path, "results.txt")
			self.results_log = logging.getLogger("results")
			self.results_log.setLevel(logging.DEBUG if debug else logging.INFO)

			self.result_pdca = os.path.join(self.log_path, "results.txt")
			self.results_log = logging.getLogger("results")
			self.results_log.setLevel(logging.DEBUG if debug else logging.INFO)
		except OSError as e:
			print("OSError - Check Result_Path Parameter for Accuracy")
			raise Exception(e)

		for h in self.results_log.handlers[::-1]:
			self.results_log.removeHandler(h)

		res_fhdlr = logging.FileHandler(self.result_file)
		res_fhdlr.setFormatter(logging.Formatter('%(message)s'))
		self.results_log.addHandler(res_fhdlr)

		# Sequence (flow) Logging
		self.sequence_file = os.path.join(self.log_path, "sequence.log")
		self.seq_log = logging.getLogger("sequence")
		self.seq_log.setLevel(logging.DEBUG if debug else logging.INFO)
		for h in self.seq_log.handlers[::-1]:
			self.seq_log.removeHandler(h)

		seq_fhdlr = logging.FileHandler(self.sequence_file)
		seq_fhdlr.setFormatter(logging.Formatter('%(asctime)s %(message)s'))
		self.seq_log.addHandler(seq_fhdlr)

		# Registers Logging
		self.reg_file = os.path.join(self.log_path, "debug_registers.log")
		self.reg_log = logging.getLogger("registers")
		self.reg_log.setLevel(logging.DEBUG if debug else logging.INFO)
		for h in self.reg_log.handlers[::-1]:
			self.reg_log.removeHandler(h)

		reg_fhdlr = logging.FileHandler(self.reg_file)
		# reg_fhdlr.setFormatter(logging.Formatter('%(asctime)s %(message)s'))
		reg_fhdlr.setFormatter(logging.Formatter('%(message)s'))
		self.reg_log.addHandler(reg_fhdlr)

		# Set initial status to an unknown error (need to explicitly pass)
		self.status = RESULT_CODE.ERROR_UNKNOWN

		# For PDCA import
		self.run = PDCARun()

		try:
			self.run.start_time = datetime.now(timezone.utc)
		except Exception:
			print("datetime WA")
			from shell import run
			run("rtc --set 20230425121311")
			self.run.start_time = datetime.now(timezone.utc)
		# Bad Clock locally, but should work in factory. Comment above line and uncomment below for local testing
		# self.run.start_time = datetime(2021, 1, 22, 5, 29, 37, 796294, timezone.utc)

		print("DOE=", self.doe)

	#
	# Logging
	#

	def log_key(self, key, value, units, upperlimit=None, lowerlimit=None, register_file=False, retry=False, fom_key=None,
				endpoint_speed=None):
		"""Log keys to the the PDCA / Insight results.txt CSV file"""

		key = key.replace(" ", "_")

		# Adjust log endpoint to match prior projects
		log_endpoint = self.endpoint if "3nm" not in self.endpoint else self.endpoint.strip("3nm")
		log_endpoint = "cameraisp" if "camera" in log_endpoint else log_endpoint

		# Ensure keys stay unique even over cycles, so add cycle to the key name
		if retry:
			key = "r{}_{}".format(self.retry_position, key)
		key = key if self.cycle_count == 1 else "c{}_{}".format(self.current_cycle, key)

		# Ensure the key stays unique over figure of merits by adding adaptation run to the key name for DOEs
		if bool(self.doe) is True:
			if self.current_adaptation not in self.por_adaptations:
				upperlimit=None
				lowerlimit=None
			# Offset by 1 because we've already incremented by 1 at this point
			if fom_key is None:
				key = "fom{}_{}".format(self.adaptation_run-1, key)
			else:
				key = "{}{}_{}".format(fom_key, self.adaptation_run-1, key)

		if self.error_mask != 0:
			key = key + "_eyemask{}".format(self.error_mask)

		# Make all keys lowercase
		key = key.lower()
		if self.plist is True:
			if self.root_port is not None:
				# usb10g_0_port__0_lane__0_r0_c0_leftright_2min_ew_ps
				# usb10_0_port_0_lane_1_r0_c0_leftright_2min_ew_ps
				new_record = ParametricPDCARecord(**{
					'testname': log_endpoint + str(self.root_port),
					'subtestname': "cycle{}_{}{}".format(self.current_cycle, key, units),
					'value': value,
					'units': units,
					'upperlimit': upperlimit,
					'lowerlimit': lowerlimit
				})

				root_port_result = ""
				if isinstance(self.root_port, list):
					for port in self.root_port:
						root_port_result = root_port_result + "{}_".format(port)
				else:
					root_port_result = str(self.root_port) + "_"

				if self.special_pdca_format:
					# converts usb10_0_port:0_lane:1 & usb10_0_port_0_lane_1
					# to
					# usb10g_0_port__0_lane__1

					if "pcie" == log_endpoint:
						log_endpoint = log_endpoint.replace("pcie", self.module)

					log_endpoint = log_endpoint.replace("usb10", "usb10g")
					log_endpoint = log_endpoint.replace("usb5", "usb5g")

					if endpoint_speed is not None:
						if self.endpoint.lower() != "rt13":
							endpoint_speed_dict = {"CIO_GEN2": "10g", "USB_10G": "10g", "CIO_GEN3": "20g", "USB_5G": "5g", "DP_RBR": "dprbr", "DP_HBR": "dphbr", "DP_HBR2": "dphbr2", "DP_HBR3": "dphbr3"}
						else:
							endpoint_speed_dict = {"CIO_GEN2": "cio10g", "USB_10G": "10g", "CIO_GEN3": "cio20g", "USB_5G": "5g", "DP_RBR": "dprbr", "DP_HBR": "dphbr", "DP_HBR2": "dphbr2", "DP_HBR3": "dphbr3"}

						if endpoint_speed.upper() in endpoint_speed_dict:
							log_endpoint = log_endpoint+endpoint_speed_dict[endpoint_speed.upper()]
						else:
							raise Exception("Key is not found"+endpoint_speed.upper())

					key = key.replace(":", "_")

					if "port__" not in key:
						key = key.replace("port_", "port__")

					if "lane__" not in key:
						key = key.replace("lane_", "lane__")

					if "atc__" not in key:
						key = key.replace("atc_", "atc__")

				if register_file == False:
					self.results_log.info("{}_{}{} -> {}{}".format(log_endpoint, root_port_result, key, value, units))
				else:
					self.reg_log.info("{}_{}{} -> {}{}".format(log_endpoint, root_port_result, key, value, units))

			else:
				new_record = ParametricPDCARecord(**{
					'testname': log_endpoint,
					'subtestname': "cycle{}_{}".format(self.current_cycle, key),
					'value': value,
					'units': units,
					'upperlimit': upperlimit,
					'lowerlimit': lowerlimit

				})
				if register_file == False:
					self.results_log.info("{}_{} -> {}".format(log_endpoint, key, value))
				else:
					self.reg_log.info("{}_{} -> {}".format(log_endpoint, key, value))
			self.run.end_time = datetime.now(timezone.utc)
			# Bad Clock locally, but should work in factory. Comment above line and uncomment below for local testing
			# self.run.end_time = datetime(2021, 1, 22, 10, 29, 37, 796294, timezone.utc)
			self.run.store.add_record(new_record)
			with open(os.path.join(self.log_path, self.additional_pdca_name), 'wb') as fp:
				pdcaplist.dump([self.run], fp)
		else:
			if self.root_port is not None:
				root_port_result = ""
				if isinstance(self.root_port, list):
					for port in self.root_port:
						root_port_result = root_port_result + "{}_".format(port)
				else:
					root_port_result = str(self.root_port) + "_"

				self.results_log.info("{}_{}{} -> {}{}".format(log_endpoint, root_port_result, key, value, units))

			else:
				self.results_log.info("{}_{} -> {}".format(log_endpoint, key, value))

	def write_coordinate_file(self, content):
		"""Write the coordinate based eye diagram"""
		with open(os.path.join(self.log_path, "run_{}_eye_margin_lane{}.csv".format(self.adaptation_run, self.current_lane)), "w") as diagram:
			diagram.write(content)

	def write_eye_diagram_file(self, content):
		"""Write the visual eye diagram"""
		with open(os.path.join(self.log_path, "run_{}_eye_diagram_lane{}.txt".format(self.adaptation_run, self.current_lane)), "w") as diagram:
			diagram.write(content)

	def log_msg(self, msg):
		"""Log a message to the sequence log"""
		self.seq_log.info(msg)

	def log_reg(self, msg):
		"""Log a message to the debug registers log"""
		self.reg_log.info(msg)

	#
	# Execution Flow
	#

	def setup_code(self):
		"""Setup any aspects of the code that need to be setup"""

	def set_adaptation(self, figure_of_merit):
		"""Set the Adaptation Type (if applicable)"""

	def apply_settings(self, retrain=True):
		"""Apply EQ and other settings, retrain (if applicable)"""

	def ensure_link(self):
		"""Check Link meets Speed / Width requirements"""

	def disable_power_management(self):
		"""Disable Power Management Modes"""

	def set_traffic_type(self, traffic_type):
		"""Select the Traffic type (Live, PRBS, etc)"""

	def select_lane(self, lane):
		"""Select a Lane"""

	def _select_lane(self, lane):
		"""Select a Lane"""
		print(lane)
		# Select the Lane
		self.select_lane(lane)

		# Update the Lane Number
		self.current_lane = lane

	def configure_phy(self):
		"""Configure the PHY Settings, Overrides, ECO, etc"""

	def setup_margining(self):
		"""Configure Margin Settings"""

	def start_margining(self):
		"""Start the Margining"""

	def dump_registers(self, initial=False):
		"""Dump Static Registers"""

	def calculate_eye(self):
		"""Eye Calculation"""

	def clean_up(self):
		"""Clean up margining and reset the PHY"""

	def execute_margin(self):
		"""Execute margining in loops"""
		try:
			# Run Loops over adaptation types
			self.adaptation_run = 0

			flag = 0 # dump register flag so that even for cycling initial is only passed 1x

			print("adaptation types: {}".format(self.adaptation_types))
			if bool(self.doe) is False:
				print("DOE false, ignoring adaptation types")
				self.adaptation_types = [0]

			print("adaptation types: {}".format(self.adaptation_types))
			for figure_of_merit in self.adaptation_types:
				self.log_msg("Setting Figure of merit {}".format(figure_of_merit))
				self.current_adaptation = figure_of_merit
				# Special Code Setup / Array Settings That Are Cleared and Passed
				self.setup_code()

				self.set_adaptation(figure_of_merit)

				self.adaptation_run += 1

				# Apply Settings / Retrain
				self.apply_settings(retrain=True)

				self.current_cycle = 0

				# Run Loops
				while self.current_cycle < self.cycle_count:
					# Retry Count Initialized to 3, Flag to 0
					# Only PCIe Checks Flag and might set to 1
					for retry_iteration in range(self.retry_count):
						print("Retry Iteration: {} Retry Flag: {} Retry Count: {}".format(retry_iteration, self.retry_flag, self.retry_count))
						self.retry_position = retry_iteration

						# Disable PM
						self.log_msg("Disable ASPM")
						self.disable_power_management()

						# Ensure Link
						self.log_msg("Ensure Link is ready")
						self.ensure_link()

						# Setup PHY Settings
						self.log_msg("   Configure PHY")
						self.configure_phy()

						# Setup PHY for Clk freq / PRBS setup
						self.set_traffic_type(self.traffic_type)

						# Scanning Lanes
						print(f"Lane Count: {self.LANE_COUNT}")
						if isinstance(self.LANE_COUNT, list):
							self.log_msg(f"Running Lanes {self.LANE_COUNT[-1]} - {self.LANE_COUNT[0]}")
						else:
							self.log_msg("Running Lanes 0 - {}".format(self.LANE_COUNT - 1))

						# Repeat for all lanes
						lane = 0 if self.lane_no is None else int(self.lane_no)
						while 1:
							# Set the Lane Number before running margining
							self._select_lane(lane=lane)

							# Dump Static Registers
							self.log_msg("   Dump Data out")

							# for cycling adaptations, we run this block multiple times,
							# so after the first iteration initial should be False
							# otherwise we get failures where PDCA key name has to be unique
							if self.retry_position != 0:
								self.dump_registers(initial=False)
							else:
								self.dump_registers(initial=True)

							# Repeat for tool cycles
							self.current_tool_cycle = 0
							print(f" Current Tool Cycle: {self.current_tool_cycle} Tool Cycle Count: {self.tool_cycle_count}")
							while self.current_tool_cycle < self.tool_cycle_count:
								self.log_msg("   Tool Loop #{}".format(self.current_tool_cycle))

								# Setup Margining Settings
								self.log_msg("   Setup Margining")
								self.setup_margining()

								# Start Margining
								self.log_msg("   Start Margining")
								self.start_margining()

								# Wait for finish
								self.log_msg("   Wait for Completion")
								self.wait_for_finish()

								# Check for AER registers
								self.log_msg(" Check for Error registers")

								# Dump Static Registers
								self.log_msg("   Dump Data out")
								self.dump_registers(initial=False)

								# Parse Margin Data
								self.log_msg("   Parsing Data")
								self.calculate_eye()

								# Increment the Lane cycles
								self.current_tool_cycle += 1

								print("Retry Iteration: {} Retry Flag: {}".format(retry_iteration, self.retry_flag))

							# Increment the lane
							lane = lane + 1

							# Can't replace while 1 with this, won't do the first loop.
							# Break if all lanes scanned
							# ToDo: PCIESwitch doesn't need to independently cycle 16 or 24 lanes, this would handle it
							if self.all_lanes_scanned(lane):
								break

						if self.retry_flag == 0:
							print("Breaking because no failure detected")
							break
						else:
							print("Counting onwards because failure detected")

					# Update the Cycle Count (always at the end so we do Cycle 0, 1, 2...)
					self.current_cycle += 1

				# Check the Limits

			# Set Pass
			print("Set Pass")
			self.status = RESULT_CODE.PASS

		# Limit Checks as failures
		except MinHeightException:
			self.status = RESULT_CODE.FAIL_EXCEED_MIN_HEIGHT
			raise

		except MinWidthException:
			self.status = RESULT_CODE.FAIL_EXCEED_MIN_WIDTH
			raise

		except MaxWidthException:
			self.status = RESULT_CODE.FAIL_EXCEED_MAX_WIDTH
			raise

		# Timeout Failure
		except MaxTimeoutException:
			self.status = RESULT_CODE.FAIL_EXCEED_MAX_TIMEOUT
			raise

		# Catch everything else as a software error
		except Exception:
			self.status = RESULT_CODE.ERROR_UNKNOWN
			raise

		finally:
			# Clean Up
			self.clean_up()

			# Log it to the Results
			self.log_key(RESULT_KEY.RESULT_CODE, self.status, "status")

	#
	# Evaluate Limits
	#


	#
	# Helpers
	#

	def progress(self):
		"""Progress in integer % increments"""

	def is_running(self):
		"""Check if Margining is running"""

	def wait_for_finish(self):
		"""Monitor the Is running Flag"""
		start = time.time()
		while self.is_running() and time.time() - start < self.timeout_s:
			time.sleep(self.POLL_TIME)
			print(f"Is Running: {self.is_running()} Time Passed: {time.time() - start} Timeout: {self.timeout_s}")
			if time.time() - start > self.timeout_s:
				raise MaxTimeoutException("Exceeded maximum timeout of {} sec".format(self.timeout_s))

	def all_lanes_scanned(self, lane):
		"""Check if all lanes scanned, Used for tools that need to have individual lanes scanned"""

	def read_margin_data(self):
		"""Read margin data after scan of a setting"""
