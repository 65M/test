_all_ = [
    'SOC_0x8103',  # Tonga
    'SOC_0x8112',  # Staten
    'SOC_0x8122',  # Ibiza
    'SOC_0x6020',  # Rhodes C Chop
    'SOC_0x6021',  # Rhodes C Die
    'SOC_0x6022',  # Rhodes 2C
    'SOC_0x6030',  # Lobos
    'SOC_0x6031',  # Palma
    'SOC_0x6034',  # Palma M
    'SOC_0x8132',  # Donan
    'SOC_CONVERSION_CODE'
]

"""
Explanation:

ATC Offset = Base register address of ATC0
ATC Top Offset = Offset from ATC Offset to ATC Top 
				(Normally located within ATC Offset on SEG Docs)
ATC ACIO Offset = Offset from ATC Offset to ACIO Base Address
				(Normally located within ATC Offset on SEG Docs)
RP Offset = Offset From ATC Offset (ATC0 Base Address) to next ATC (ATC1) Base Address etc.
ACIO Phy Lane 0 = ACIO Phy Lane 0 Subsystem Offset From ATC Top Base Address
				(Normally located within ATC Top Offset on SEG Docs)
Lane Offset = ACIO Phy Lane 1 Offset from ACIO Phy Lane 0 Base Address
"""

# ToDo: Move all the Lifuka registers to defines.py

# Keep in mind that some of the registers are Lifuka side registers (RT-13) which is a separate platform
# That means they should stay the same between different SoC iterations

# No Sicily or Ellis or Cebu Drive Ports
# No Tonga or Jade RT-13


SOC_0x8103 = {  # Tonga
    'SOC_ATC_OFFSET': 0x380000000,
    'ATC_TOP_OFFSET': 0x3000000,
    'ATC_ACIO_OFFSET': 0x1000000,
    'RP_OFFSET': 0x180000000,
    'ACIOPHY_LANE0': 0x8000,
    'LANE_OFFSET': 0x7000,
    'USB10G_TX_OFFSET': 0x228d060,
    'USB5G_TX_OFFSET': 0x228c2c0,
    'EQ_CTRL_RAW_CAP1_LANE0': 0x4091309c,  # (PHY base register Lifuka A0)
    'EQ_CTRL_RAW_CAP2_LANE0': 0x409130a0,  # (PHY base register Lifuka A0)
    'TX_EQ_CTRL_REG2_LANE0': 0x4091403c,  # (PHY base register Lifuka A0)
    'ARUSB_PIPE_HANDLER_TX_DEEMPHASIS_USBGen1': 0x40d40024,
    # https://seg-docs.csg.apple.com/projects/lifuka/release/UserManual/regs/arusb_pipe_handler.html?baseaddr=0x40d40000#arusb_pipe_handler_tx_deemphasis_pr7
    'ARUSB_PIPE_HANDLER_TX_DEEMPHASIS_USBGen2': 0x40d40028,
    'AUSPMA_RT_RX_TOP_TJ_PMAFSM_REG0': 0x40911000,
    'AUSPMA_RX_SHM.AUSPMA_RT_RX_SHM_TJ.rxa_deser_ctrl1': 0x40913024,
    'AUSPMA_RX_SHM.AUSPMA_RT_RX_SHM_TJ.rxa_dcopi_ctrl2': 0x40913018,
    'AUSPMA_RX.AUSPMA_RX_EQ.AUSPMA_RT_RX_EQ_TJ.cfg27_eq': 0x40912098,
    'AUSPMA_RX_SHM_AUSPMA_RT_RX_SHM_TJ_rxa_eq_ctrl_g3g4_1': 0x40913088,
    # RXA_EQ_CTRL_G3G4_1 R/C value (PHY base register Lifuka A0)
    'AUSPMA_RX_SHM_AUSPMA_RT_RX_SHM_TJ_rxa_eq_ctrl_g3g4_2': 0x4091308C,
    # RXA_EQ_CTRL_G3G4_2 R/C value (PHY base register Lifuka A0)
    'AUSPMA_RX_SHM_AUSPMA_RT_RX_SHM_TJ_rxa_eq_ctrl_g3g4_3': 0x40913090,
    # RXA_EQ_CTRL_G3G4_3 R/C value (PHY base register Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg14_eq': 0x40912044,  # AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg14_eq (Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg28_eq': 0x4091209c,  # AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg28_eq (Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg29_eq': 0x409120a0,  # AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg29_eq (Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg15_eq_LANE0': 0x40912048,
    # seq_b_eng1 -> seq_b_eng3 (PHY base register Lifuka A0) 0x40912048
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg17_eq_LANE0': 0x40912054,
    # seq_b_eng1 -> seq_b_eng3 (PHY base register Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg57_eq': 0x40912110,
    # ctleoed_h1_th_cs -> ctleoed_h3_th_cs (PHY base register Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg58_eq': 0x40912114,
    # ctleoed_h4_th_cs -> ctleoed_h5_th_cs (PHY base register Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg59_eq': 0x40912118,  # ctleoed_h1_th_Rs (PHY base register Lifuka A0)
}

SOC_0x8112 = {  # Staten
    'SOC_ATC_OFFSET': 0x380000000,
    'ATC_TOP_OFFSET': 0x3000000,
    'ATC_ACIO_OFFSET': 0x1000000,
    'RP_OFFSET': 0x180000000,
    'ACIOPHY_LANE0': 0x8000,
    'LANE_OFFSET': 0x7000,
    'USB10G_TX_OFFSET': 0x228d060,
    'USB5G_TX_OFFSET': 0x228c2c0,
    'EQ_CTRL_RAW_CAP1_LANE0': 0x4091309c,  # (PHY base register Lifuka A0)
    'EQ_CTRL_RAW_CAP2_LANE0': 0x409130a0,  # (PHY base register Lifuka A0)
    'TX_EQ_CTRL_REG2_LANE0': 0x4091403c,  # (PHY base register Lifuka A0)
    'ARUSB_PIPE_HANDLER_TX_DEEMPHASIS_USBGen1': 0x40d40024,
    # https://seg-docs.csg.apple.com/projects/lifuka/release/UserManual/regs/arusb_pipe_handler.html?baseaddr=0x40d40000#arusb_pipe_handler_tx_deemphasis_pr7
    'ARUSB_PIPE_HANDLER_TX_DEEMPHASIS_USBGen2': 0x40d40028,
    'AUSPMA_RT_RX_TOP_TJ_PMAFSM_REG0': 0x40911000,
    'AUSPMA_RX_SHM.AUSPMA_RT_RX_SHM_TJ.rxa_deser_ctrl1': 0x40913024,
    'AUSPMA_RX_SHM.AUSPMA_RT_RX_SHM_TJ.rxa_dcopi_ctrl2': 0x40913018,
    'AUSPMA_RX.AUSPMA_RX_EQ.AUSPMA_RT_RX_EQ_TJ.cfg27_eq': 0x40912098,
    'AUSPMA_RX_SHM_AUSPMA_RT_RX_SHM_TJ_rxa_eq_ctrl_g3g4_1': 0x40913088,
    # RXA_EQ_CTRL_G3G4_1 R/C value (PHY base register Lifuka A0)
    'AUSPMA_RX_SHM_AUSPMA_RT_RX_SHM_TJ_rxa_eq_ctrl_g3g4_2': 0x4091308C,
    # RXA_EQ_CTRL_G3G4_2 R/C value (PHY base register Lifuka A0)
    'AUSPMA_RX_SHM_AUSPMA_RT_RX_SHM_TJ_rxa_eq_ctrl_g3g4_3': 0x40913090,
    # RXA_EQ_CTRL_G3G4_3 R/C value (PHY base register Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg14_eq': 0x40912044,  # AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg14_eq (Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg28_eq': 0x4091209c,  # AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg28_eq (Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg29_eq': 0x409120a0,  # AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg29_eq (Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg15_eq_LANE0': 0x40912048,
    # seq_b_eng1 -> seq_b_eng3 (PHY base register Lifuka A0) 0x40912048
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg17_eq_LANE0': 0x40912054,
    # seq_b_eng1 -> seq_b_eng3 (PHY base register Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg57_eq': 0x40912110,
    # ctleoed_h1_th_cs -> ctleoed_h3_th_cs (PHY base register Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg58_eq': 0x40912114,
    # ctleoed_h4_th_cs -> ctleoed_h5_th_cs (PHY base register Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg59_eq': 0x40912118,  # ctleoed_h1_th_Rs (PHY base register Lifuka A0)
}

SOC_0x8122 = {  # Ibiza
    'SOC_ATC_OFFSET': 0x700000000,
    'ATC_TOP_OFFSET': 0x3000000,
    'ATC_ACIO_OFFSET': 0x1000000,
    'RP_OFFSET': 0x400000000,
    'ACIOPHY_LANE0': 0x8000,
    'LANE_OFFSET': 0x7000,
    'USB10G_TX_OFFSET': 0x228d060,
    'USB5G_TX_OFFSET': 0x228c2c0,
    'EQ_CTRL_RAW_CAP1_LANE0': 0x4091309c,  # (PHY base register Lifuka A0)
    'EQ_CTRL_RAW_CAP2_LANE0': 0x409130a0,  # (PHY base register Lifuka A0)
    'TX_EQ_CTRL_REG2_LANE0': 0x4091403c,  # (PHY base register Lifuka A0)
    'ARUSB_PIPE_HANDLER_TX_DEEMPHASIS_USBGen1': 0x40d40024,
    # https://seg-docs.csg.apple.com/projects/lifuka/release/UserManual/regs/arusb_pipe_handler.html?baseaddr=0x40d40000#arusb_pipe_handler_tx_deemphasis_pr7
    'ARUSB_PIPE_HANDLER_TX_DEEMPHASIS_USBGen2': 0x40d40028,
    'AUSPMA_RT_RX_TOP_TJ_PMAFSM_REG0': 0x40911000,
    'AUSPMA_RX_SHM.AUSPMA_RT_RX_SHM_TJ.rxa_deser_ctrl1': 0x40913024,
    'AUSPMA_RX_SHM.AUSPMA_RT_RX_SHM_TJ.rxa_dcopi_ctrl2': 0x40913018,
    'AUSPMA_RX.AUSPMA_RX_EQ.AUSPMA_RT_RX_EQ_TJ.cfg27_eq': 0x40912098,
    'AUSPMA_RX_SHM_AUSPMA_RT_RX_SHM_TJ_rxa_eq_ctrl_g3g4_1': 0x40913088,
    # RXA_EQ_CTRL_G3G4_1 R/C value (PHY base register Lifuka A0)
    'AUSPMA_RX_SHM_AUSPMA_RT_RX_SHM_TJ_rxa_eq_ctrl_g3g4_2': 0x4091308C,
    # RXA_EQ_CTRL_G3G4_2 R/C value (PHY base register Lifuka A0)
    'AUSPMA_RX_SHM_AUSPMA_RT_RX_SHM_TJ_rxa_eq_ctrl_g3g4_3': 0x40913090,
    # RXA_EQ_CTRL_G3G4_3 R/C value (PHY base register Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg14_eq': 0x40912044,  # AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg14_eq (Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg28_eq': 0x4091209c,  # AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg28_eq (Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg29_eq': 0x409120a0,  # AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg29_eq (Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg15_eq_LANE0': 0x40912048,
    # seq_b_eng1 -> seq_b_eng3 (PHY base register Lifuka A0) 0x40912048
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg17_eq_LANE0': 0x40912054,
    # seq_b_eng1 -> seq_b_eng3 (PHY base register Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg57_eq': 0x40912110,
    # ctleoed_h1_th_cs -> ctleoed_h3_th_cs (PHY base register Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg58_eq': 0x40912114,
    # ctleoed_h4_th_cs -> ctleoed_h5_th_cs (PHY base register Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg59_eq': 0x40912118,  # ctleoed_h1_th_Rs (PHY base register Lifuka A0)
}

SOC_0x6020 = {  # Rhodes C Chop
    'SOC_ATC_OFFSET': 0x700000000,
    'ATC_TOP_OFFSET': 0x3000000,
    'ATC_ACIO_OFFSET': 0x1000000,
    'RP_OFFSET': 0x400000000,
    'ACIOPHY_LANE0': 0x8000,
    'LANE_OFFSET': 0x7000,
    'USB10G_TX_OFFSET': 0x228d060,
    'USB5G_TX_OFFSET': 0x228c2c0,
    'EQ_CTRL_RAW_CAP1_LANE0': 0x4091309c,  # (PHY base register Lifuka A0)
    'EQ_CTRL_RAW_CAP2_LANE0': 0x409130a0,  # (PHY base register Lifuka A0)
    'TX_EQ_CTRL_REG2_LANE0': 0x4091403c,  # (PHY base register Lifuka A0)
    'ARUSB_PIPE_HANDLER_TX_DEEMPHASIS_USBGen1': 0x40d40024,
    # https://seg-docs.csg.apple.com/projects/lifuka/release/UserManual/regs/arusb_pipe_handler.html?baseaddr=0x40d40000#arusb_pipe_handler_tx_deemphasis_pr7
    'ARUSB_PIPE_HANDLER_TX_DEEMPHASIS_USBGen2': 0x40d40028,
    'AUSPMA_RT_RX_TOP_TJ_PMAFSM_REG0': 0x40911000,
    'AUSPMA_RX_SHM.AUSPMA_RT_RX_SHM_TJ.rxa_deser_ctrl1': 0x40913024,
    'AUSPMA_RX_SHM.AUSPMA_RT_RX_SHM_TJ.rxa_dcopi_ctrl2': 0x40913018,
    'AUSPMA_RX.AUSPMA_RX_EQ.AUSPMA_RT_RX_EQ_TJ.cfg27_eq': 0x40912098,
    'AUSPMA_RX_SHM_AUSPMA_RT_RX_SHM_TJ_rxa_eq_ctrl_g3g4_1': 0x40913088,
    # RXA_EQ_CTRL_G3G4_1 R/C value (PHY base register Lifuka A0)
    'AUSPMA_RX_SHM_AUSPMA_RT_RX_SHM_TJ_rxa_eq_ctrl_g3g4_2': 0x4091308C,
    # RXA_EQ_CTRL_G3G4_2 R/C value (PHY base register Lifuka A0)
    'AUSPMA_RX_SHM_AUSPMA_RT_RX_SHM_TJ_rxa_eq_ctrl_g3g4_3': 0x40913090,
    # RXA_EQ_CTRL_G3G4_3 R/C value (PHY base register Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg14_eq': 0x40912044,  # AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg14_eq (Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg28_eq': 0x4091209c,  # AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg28_eq (Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg29_eq': 0x409120a0,  # AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg29_eq (Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg15_eq_LANE0': 0x40912048,
    # seq_b_eng1 -> seq_b_eng3 (PHY base register Lifuka A0) 0x40912048
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg17_eq_LANE0': 0x40912054,
    # seq_b_eng1 -> seq_b_eng3 (PHY base register Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg57_eq': 0x40912110,
    # ctleoed_h1_th_cs -> ctleoed_h3_th_cs (PHY base register Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg58_eq': 0x40912114,
    # ctleoed_h4_th_cs -> ctleoed_h5_th_cs (PHY base register Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg59_eq': 0x40912118,  # ctleoed_h1_th_Rs (PHY base register Lifuka A0)
}
# 74391A044

SOC_0x6021 = {  # Rhodes C Die
    'SOC_ATC_OFFSET': 0x700000000,
    'ATC_TOP_OFFSET': 0x3000000,
    'ATC_ACIO_OFFSET': 0x1000000,
    'RP_OFFSET': 0x400000000,
    'ACIOPHY_LANE0': 0x8000,
    'LANE_OFFSET': 0x7000,
    'USB10G_TX_OFFSET': 0x228d060,
    'USB5G_TX_OFFSET': 0x228c2c0,
    'DIE_OFFSET': 0x2000000000,
    'EQ_CTRL_RAW_CAP1_LANE0': 0x4091309c,  # (PHY base register Lifuka A0)
    'EQ_CTRL_RAW_CAP2_LANE0': 0x409130a0,  # (PHY base register Lifuka A0)
    'TX_EQ_CTRL_REG2_LANE0': 0x4091403c,  # (PHY base register Lifuka A0)
    'ARUSB_PIPE_HANDLER_TX_DEEMPHASIS_USBGen1': 0x40d40024,
    # https://seg-docs.csg.apple.com/projects/lifuka/release/UserManual/regs/arusb_pipe_handler.html?baseaddr=0x40d40000#arusb_pipe_handler_tx_deemphasis_pr7
    'ARUSB_PIPE_HANDLER_TX_DEEMPHASIS_USBGen2': 0x40d40028,
    'AUSPMA_RT_RX_TOP_TJ_PMAFSM_REG0': 0x40911000,
    'AUSPMA_RX_SHM.AUSPMA_RT_RX_SHM_TJ.rxa_deser_ctrl1': 0x40913024,
    'AUSPMA_RX_SHM.AUSPMA_RT_RX_SHM_TJ.rxa_dcopi_ctrl2': 0x40913018,
    'AUSPMA_RX.AUSPMA_RX_EQ.AUSPMA_RT_RX_EQ_TJ.cfg27_eq': 0x40912098,
    'AUSPMA_RX_SHM_AUSPMA_RT_RX_SHM_TJ_rxa_eq_ctrl_g3g4_1': 0x40913088,
    # RXA_EQ_CTRL_G3G4_1 R/C value (PHY base register Lifuka A0)
    'AUSPMA_RX_SHM_AUSPMA_RT_RX_SHM_TJ_rxa_eq_ctrl_g3g4_2': 0x4091308C,
    # RXA_EQ_CTRL_G3G4_2 R/C value (PHY base register Lifuka A0)
    'AUSPMA_RX_SHM_AUSPMA_RT_RX_SHM_TJ_rxa_eq_ctrl_g3g4_3': 0x40913090,
    # RXA_EQ_CTRL_G3G4_3 R/C value (PHY base register Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg14_eq': 0x40912044,  # AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg14_eq (Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg28_eq': 0x4091209c,  # AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg28_eq (Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg29_eq': 0x409120a0,  # AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg29_eq (Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg15_eq_LANE0': 0x40912048,
    # seq_b_eng1 -> seq_b_eng3 (PHY base register Lifuka A0) 0x40912048
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg17_eq_LANE0': 0x40912054,
    # seq_b_eng1 -> seq_b_eng3 (PHY base register Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg57_eq': 0x40912110,
    # ctleoed_h1_th_cs -> ctleoed_h3_th_cs (PHY base register Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg58_eq': 0x40912114,
    # ctleoed_h4_th_cs -> ctleoed_h5_th_cs (PHY base register Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg59_eq': 0x40912118,  # ctleoed_h1_th_Rs (PHY base register Lifuka A0)
}

SOC_0x6022 = {  # Rhodes 2C
    'SOC_ATC_OFFSET': 0x700000000,
    'ATC_TOP_OFFSET': 0x3000000,
    'ATC_ACIO_OFFSET': 0x1000000,
    'RP_OFFSET': 0x400000000,
    'ACIOPHY_LANE0': 0x8000,
    'LANE_OFFSET': 0x7000,
    'USB10G_TX_OFFSET': 0x228d060,
    'USB5G_TX_OFFSET': 0x228c2c0,
    'DIE_OFFSET': 0x2000000000,
    'EQ_CTRL_RAW_CAP1_LANE0': 0x4091309c,  # (PHY base register Lifuka A0)
    'EQ_CTRL_RAW_CAP2_LANE0': 0x409130a0,  # (PHY base register Lifuka A0)
    'TX_EQ_CTRL_REG2_LANE0': 0x4091403c,  # (PHY base register Lifuka A0)
    'ARUSB_PIPE_HANDLER_TX_DEEMPHASIS_USBGen1': 0x40d40024,
    # https://seg-docs.csg.apple.com/projects/lifuka/release/UserManual/regs/arusb_pipe_handler.html?baseaddr=0x40d40000#arusb_pipe_handler_tx_deemphasis_pr7
    'ARUSB_PIPE_HANDLER_TX_DEEMPHASIS_USBGen2': 0x40d40028,
    'AUSPMA_RX_SHM.AUSPMA_RT_RX_SHM_TJ.rxa_deser_ctrl1': 0x40913024,
    'AUSPMA_RX_SHM.AUSPMA_RT_RX_SHM_TJ.rxa_dcopi_ctrl2': 0x40913018,
    'AUSPMA_RX.AUSPMA_RX_EQ.AUSPMA_RT_RX_EQ_TJ.cfg27_eq': 0x40912098,
    'AUSPMA_RT_RX_TOP_TJ_PMAFSM_REG0': 0x40911000,
    'AUSPMA_RX_SHM_AUSPMA_RT_RX_SHM_TJ_rxa_eq_ctrl_g3g4_1': 0x40913088,
    # RXA_EQ_CTRL_G3G4_1 R/C value (PHY base register Lifuka A0)
    'AUSPMA_RX_SHM_AUSPMA_RT_RX_SHM_TJ_rxa_eq_ctrl_g3g4_2': 0x4091308C,
    # RXA_EQ_CTRL_G3G4_2 R/C value (PHY base register Lifuka A0)
    'AUSPMA_RX_SHM_AUSPMA_RT_RX_SHM_TJ_rxa_eq_ctrl_g3g4_3': 0x40913090,
    # RXA_EQ_CTRL_G3G4_3 R/C value (PHY base register Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg14_eq': 0x40912044,  # AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg14_eq (Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg28_eq': 0x4091209c,  # AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg28_eq (Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg29_eq': 0x409120a0,  # AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg29_eq (Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg15_eq_LANE0': 0x40912048,
    # seq_b_eng1 -> seq_b_eng3 (PHY base register Lifuka A0) 0x40912048
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg17_eq_LANE0': 0x40912054,
    # seq_b_eng1 -> seq_b_eng3 (PHY base register Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg57_eq': 0x40912110,
    # ctleoed_h1_th_cs -> ctleoed_h3_th_cs (PHY base register Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg58_eq': 0x40912114,
    # ctleoed_h4_th_cs -> ctleoed_h5_th_cs (PHY base register Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg59_eq': 0x40912118,  # ctleoed_h1_th_Rs (PHY base register Lifuka A0)
}

SOC_0x6030 = {  # Lobos
    'SOC_ATC_OFFSET': 0x700000000,
    'ATC_TOP_OFFSET': 0x3000000,
    'ATC_ACIO_OFFSET': 0x1000000,
    'RP_OFFSET': 0x400000000,
    'ACIOPHY_LANE0': 0x8000,
    'LANE_OFFSET': 0x7000,
    'USB10G_TX_OFFSET': 0x228d060,
    'USB5G_TX_OFFSET': 0x228c2c0,
    'EQ_CTRL_RAW_CAP1_LANE0': 0x4091309c,  # (PHY base register Lifuka A0)
    'EQ_CTRL_RAW_CAP2_LANE0': 0x409130a0,  # (PHY base register Lifuka A0)
    'TX_EQ_CTRL_REG2_LANE0': 0x4091403c,  # (PHY base register Lifuka A0)
    'ARUSB_PIPE_HANDLER_TX_DEEMPHASIS_USBGen1': 0x40d40024,
    # https://seg-docs.csg.apple.com/projects/lifuka/release/UserManual/regs/arusb_pipe_handler.html?baseaddr=0x40d40000#arusb_pipe_handler_tx_deemphasis_pr7
    'ARUSB_PIPE_HANDLER_TX_DEEMPHASIS_USBGen2': 0x40d40028,
    'AUSPMA_RT_RX_TOP_TJ_PMAFSM_REG0': 0x40911000,
    'AUSPMA_RX_SHM.AUSPMA_RT_RX_SHM_TJ.rxa_deser_ctrl1': 0x40913024,
    'AUSPMA_RX_SHM.AUSPMA_RT_RX_SHM_TJ.rxa_dcopi_ctrl2': 0x40913018,
    'AUSPMA_RX.AUSPMA_RX_EQ.AUSPMA_RT_RX_EQ_TJ.cfg27_eq': 0x40912098,
    'AUSPMA_RX_SHM_AUSPMA_RT_RX_SHM_TJ_rxa_eq_ctrl_g3g4_1': 0x40913088,
    # RXA_EQ_CTRL_G3G4_1 R/C value (PHY base register Lifuka A0)
    'AUSPMA_RX_SHM_AUSPMA_RT_RX_SHM_TJ_rxa_eq_ctrl_g3g4_2': 0x4091308C,
    # RXA_EQ_CTRL_G3G4_2 R/C value (PHY base register Lifuka A0)
    'AUSPMA_RX_SHM_AUSPMA_RT_RX_SHM_TJ_rxa_eq_ctrl_g3g4_3': 0x40913090,
    # RXA_EQ_CTRL_G3G4_3 R/C value (PHY base register Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg14_eq': 0x40912044,  # AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg14_eq (Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg28_eq': 0x4091209c,  # AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg28_eq (Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg29_eq': 0x409120a0,  # AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg29_eq (Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg15_eq_LANE0': 0x40912048,
    # seq_b_eng1 -> seq_b_eng3 (PHY base register Lifuka A0) 0x40912048
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg17_eq_LANE0': 0x40912054,
    # seq_b_eng1 -> seq_b_eng3 (PHY base register Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg57_eq': 0x40912110,
    # ctleoed_h1_th_cs -> ctleoed_h3_th_cs (PHY base register Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg58_eq': 0x40912114,
    # ctleoed_h4_th_cs -> ctleoed_h5_th_cs (PHY base register Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg59_eq': 0x40912118,  # ctleoed_h1_th_Rs (PHY base register Lifuka A0)
}

SOC_0x6031 = {  # Palma
    'SOC_ATC_OFFSET': 0x700000000,
    'ATC_TOP_OFFSET': 0x3000000,
    'ATC_ACIO_OFFSET': 0x1000000,
    'RP_OFFSET': 0x400000000,
    'ACIOPHY_LANE0': 0x8000,
    'LANE_OFFSET': 0x7000,
    'USB10G_TX_OFFSET': 0x228d060,
    'USB5G_TX_OFFSET': 0x228c2c0,
    'EQ_CTRL_RAW_CAP1_LANE0': 0x4091309c,  # (PHY base register Lifuka A0)
    'EQ_CTRL_RAW_CAP2_LANE0': 0x409130a0,  # (PHY base register Lifuka A0)
    'TX_EQ_CTRL_REG2_LANE0': 0x4091403c,  # (PHY base register Lifuka A0)
    'ARUSB_PIPE_HANDLER_TX_DEEMPHASIS_USBGen1': 0x40d40024,
    # https://seg-docs.csg.apple.com/projects/lifuka/release/UserManual/regs/arusb_pipe_handler.html?baseaddr=0x40d40000#arusb_pipe_handler_tx_deemphasis_pr7
    'ARUSB_PIPE_HANDLER_TX_DEEMPHASIS_USBGen2': 0x40d40028,
    'AUSPMA_RT_RX_TOP_TJ_PMAFSM_REG0': 0x40911000,
    'AUSPMA_RX_SHM.AUSPMA_RT_RX_SHM_TJ.rxa_deser_ctrl1': 0x40913024,
    'AUSPMA_RX_SHM.AUSPMA_RT_RX_SHM_TJ.rxa_dcopi_ctrl2': 0x40913018,
    'AUSPMA_RX.AUSPMA_RX_EQ.AUSPMA_RT_RX_EQ_TJ.cfg27_eq': 0x40912098,
    'AUSPMA_RX_SHM_AUSPMA_RT_RX_SHM_TJ_rxa_eq_ctrl_g3g4_1': 0x40913088,
    # RXA_EQ_CTRL_G3G4_1 R/C value (PHY base register Lifuka A0)
    'AUSPMA_RX_SHM_AUSPMA_RT_RX_SHM_TJ_rxa_eq_ctrl_g3g4_2': 0x4091308C,
    # RXA_EQ_CTRL_G3G4_2 R/C value (PHY base register Lifuka A0)
    'AUSPMA_RX_SHM_AUSPMA_RT_RX_SHM_TJ_rxa_eq_ctrl_g3g4_3': 0x40913090,
    # RXA_EQ_CTRL_G3G4_3 R/C value (PHY base register Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg14_eq': 0x40912044,  # AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg14_eq (Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg28_eq': 0x4091209c,  # AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg28_eq (Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg29_eq': 0x409120a0,  # AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg29_eq (Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg15_eq_LANE0': 0x40912048,
    # seq_b_eng1 -> seq_b_eng3 (PHY base register Lifuka A0) 0x40912048
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg17_eq_LANE0': 0x40912054,
    # seq_b_eng1 -> seq_b_eng3 (PHY base register Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg57_eq': 0x40912110,
    # ctleoed_h1_th_cs -> ctleoed_h3_th_cs (PHY base register Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg58_eq': 0x40912114,
    # ctleoed_h4_th_cs -> ctleoed_h5_th_cs (PHY base register Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg59_eq': 0x40912118,  # ctleoed_h1_th_Rs (PHY base register Lifuka A0)
}

SOC_0x6034 = {  # Palma M
    'SOC_ATC_OFFSET': 0x700000000,
    'ATC_TOP_OFFSET': 0x3000000,
    'ATC_ACIO_OFFSET': 0x1000000,
    'RP_OFFSET': 0x400000000,
    'ACIOPHY_LANE0': 0x8000,
    'LANE_OFFSET': 0x7000,
    'USB10G_TX_OFFSET': 0x228d060,
    'USB5G_TX_OFFSET': 0x228c2c0,
    'EQ_CTRL_RAW_CAP1_LANE0': 0x4091309c,  # (PHY base register Lifuka A0)
    'EQ_CTRL_RAW_CAP2_LANE0': 0x409130a0,  # (PHY base register Lifuka A0)
    'TX_EQ_CTRL_REG2_LANE0': 0x4091403c,  # (PHY base register Lifuka A0)
    'ARUSB_PIPE_HANDLER_TX_DEEMPHASIS_USBGen1': 0x40d40024,
    # https://seg-docs.csg.apple.com/projects/lifuka/release/UserManual/regs/arusb_pipe_handler.html?baseaddr=0x40d40000#arusb_pipe_handler_tx_deemphasis_pr7
    'ARUSB_PIPE_HANDLER_TX_DEEMPHASIS_USBGen2': 0x40d40028,
    'AUSPMA_RT_RX_TOP_TJ_PMAFSM_REG0': 0x40911000,
    'AUSPMA_RX_SHM.AUSPMA_RT_RX_SHM_TJ.rxa_deser_ctrl1': 0x40913024,
    'AUSPMA_RX_SHM.AUSPMA_RT_RX_SHM_TJ.rxa_dcopi_ctrl2': 0x40913018,
    'AUSPMA_RX.AUSPMA_RX_EQ.AUSPMA_RT_RX_EQ_TJ.cfg27_eq': 0x40912098,
    'AUSPMA_RX_SHM_AUSPMA_RT_RX_SHM_TJ_rxa_eq_ctrl_g3g4_1': 0x40913088,
    # RXA_EQ_CTRL_G3G4_1 R/C value (PHY base register Lifuka A0)
    'AUSPMA_RX_SHM_AUSPMA_RT_RX_SHM_TJ_rxa_eq_ctrl_g3g4_2': 0x4091308C,
    # RXA_EQ_CTRL_G3G4_2 R/C value (PHY base register Lifuka A0)
    'AUSPMA_RX_SHM_AUSPMA_RT_RX_SHM_TJ_rxa_eq_ctrl_g3g4_3': 0x40913090,
    # RXA_EQ_CTRL_G3G4_3 R/C value (PHY base register Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg14_eq': 0x40912044,  # AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg14_eq (Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg28_eq': 0x4091209c,  # AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg28_eq (Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg29_eq': 0x409120a0,  # AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg29_eq (Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg15_eq_LANE0': 0x40912048,
    # seq_b_eng1 -> seq_b_eng3 (PHY base register Lifuka A0) 0x40912048
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg17_eq_LANE0': 0x40912054,
    # seq_b_eng1 -> seq_b_eng3 (PHY base register Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg57_eq': 0x40912110,
    # ctleoed_h1_th_cs -> ctleoed_h3_th_cs (PHY base register Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg58_eq': 0x40912114,
    # ctleoed_h4_th_cs -> ctleoed_h5_th_cs (PHY base register Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg59_eq': 0x40912118,  # ctleoed_h1_th_Rs (PHY base register Lifuka A0)
}


SOC_0x8132 = {  # Donan
    'SOC_ATC_OFFSET': 0x400000000,
    'ATC_TOP_OFFSET': 0x3000000,
    'ATC_ACIO_OFFSET': 0x1000000,
    'RP_OFFSET': 0x8000000,
    'ACIOPHY_LANE0': 0x8000,
    'LANE_OFFSET': 0x7000,
    'USB10G_TX_OFFSET': 0x228d060,
    'USB5G_TX_OFFSET': 0x228c2c0,
    'EQ_CTRL_RAW_CAP1_LANE0': 0x4091309c,  # (PHY base register Lifuka A0)
    'EQ_CTRL_RAW_CAP2_LANE0': 0x409130a0,  # (PHY base register Lifuka A0)
    'TX_EQ_CTRL_REG2_LANE0': 0x4091403c,  # (PHY base register Lifuka A0)
    'ARUSB_PIPE_HANDLER_TX_DEEMPHASIS_USBGen1': 0x40d40024,
    # https://seg-docs.csg.apple.com/projects/lifuka/release/UserManual/regs/arusb_pipe_handler.html?baseaddr=0x40d40000#arusb_pipe_handler_tx_deemphasis_pr7
    'ARUSB_PIPE_HANDLER_TX_DEEMPHASIS_USBGen2': 0x40d40028,
    'AUSPMA_RT_RX_TOP_TJ_PMAFSM_REG0': 0x40911000,
    'AUSPMA_RX_SHM.AUSPMA_RT_RX_SHM_TJ.rxa_deser_ctrl1': 0x40913024,
    'AUSPMA_RX_SHM.AUSPMA_RT_RX_SHM_TJ.rxa_dcopi_ctrl2': 0x40913018,
    'AUSPMA_RX.AUSPMA_RX_EQ.AUSPMA_RT_RX_EQ_TJ.cfg27_eq': 0x40912098,
    'AUSPMA_RX_SHM_AUSPMA_RT_RX_SHM_TJ_rxa_eq_ctrl_g3g4_1': 0x40913088,
    # RXA_EQ_CTRL_G3G4_1 R/C value (PHY base register Lifuka A0)
    'AUSPMA_RX_SHM_AUSPMA_RT_RX_SHM_TJ_rxa_eq_ctrl_g3g4_2': 0x4091308C,
    # RXA_EQ_CTRL_G3G4_2 R/C value (PHY base register Lifuka A0)
    'AUSPMA_RX_SHM_AUSPMA_RT_RX_SHM_TJ_rxa_eq_ctrl_g3g4_3': 0x40913090,
    # RXA_EQ_CTRL_G3G4_3 R/C value (PHY base register Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg14_eq': 0x40912044,  # AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg14_eq (Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg28_eq': 0x4091209c,  # AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg28_eq (Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg29_eq': 0x409120a0,  # AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg29_eq (Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg15_eq_LANE0': 0x40912048,
    # seq_b_eng1 -> seq_b_eng3 (PHY base register Lifuka A0) 0x40912048
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg17_eq_LANE0': 0x40912054,
    # seq_b_eng1 -> seq_b_eng3 (PHY base register Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg57_eq': 0x40912110,
    # ctleoed_h1_th_cs -> ctleoed_h3_th_cs (PHY base register Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg58_eq': 0x40912114,
    # ctleoed_h4_th_cs -> ctleoed_h5_th_cs (PHY base register Lifuka A0)
    'AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg59_eq': 0x40912118,  # ctleoed_h1_th_Rs (PHY base register Lifuka A0)
}

SOC_CONVERSION_CODE = {
    '8103': SOC_0x8103,  # Tonga
    '8112': SOC_0x8112,  # Staten
    '8122': SOC_0x8122,  # Ibiza
    '6020': SOC_0x6020,  # Rhodes C Chop
    '6021': SOC_0x6021,  # Rhodes C Die
    '6022': SOC_0x6022,  # Rhodes 2C
    '6030': SOC_0x6030,  # Lobos
    '6031': SOC_0x6031,  # Palma
    '6034': SOC_0x6034,  # Palma M
    '8132': SOC_0x8132,  # Donan
}
