from ..base import AbstractBaseMarginTool
from .soc_defines import *
from shell import run
import time
import re

__all__ = [
    "AbstractReceiverMarginTool"
]


class AbstractReceiverMarginTool(AbstractBaseMarginTool):
    """Generic Interface for ANS (Apple NAND System) Margining"""
    margin_data=()


    def __init__(self, *args, **kwargs):
        super(AbstractReceiverMarginTool, self).__init__(*args, **kwargs)
        print("Init Code")
        self.start_time = time.time()
        print(f"Start Time: {self.start_time}")
        print(f"[Initialize] Time Progressed: {time.time()-self.start_time}")

        self.die_offset_addr = 0

        RT_DEVICE_LAYOUT = self.rt13_layout
        if RT_DEVICE_LAYOUT is None:
            raise Exception("No RT-13 Device Layout Provided")
        else:
            print("RT13 Device Layout: {}".format(RT_DEVICE_LAYOUT))

        # If no device index provided, port list is used, one must be provided.
        if self.device_index is None and self.port_list is None:
            raise Exception("No device index: {} passed in, but invalid port_list passed in: {}".format(self.device_index, self.port_list))

        print("Device Index: {}".format(self.device_index))
        if self.device_index is None:
            port_list_int = []
            for port in self.port_list:
                if port.isdigit():
                    port_list_int.append(int(port))
            port_list_int.sort()
            self.port_list = port_list_int
        else:
            self.port_list = [int(self.device_index)]

        print("Device Index: {} Port List: {}".format(self.device_index, self.port_list))

        bus_flag = 0
        self.product_code = self.product_code.upper()
        if self.product_code in ["J617", "J618", "J619", "J620", "J621", "J622"]:
            if (self.product_code in ["J618"] and self.board_rev >= 1) or (self.board_rev >= 2):
                bus_flag = 1

        print(f"Board Rev: {self.board_rev} Bus Flag: {bus_flag} Product Code: {self.product_code}")

        # Grab the bus, address, atc # and type for each port in port list
        self.bus = []
        self.address = []
        self.atc = []
        self.type = []
        for device in RT_DEVICE_LAYOUT:
            # for each port the equivalent index has an atc #, bus, address, and type
            if device[0] in self.port_list:
                self.atc.append(device[0])
                if bus_flag:
                    self.bus.append(int(device[1]) + 5)
                else:
                    self.bus.append(int(device[1]))
                self.address.append(device[2])
                self.type.append(device[3])

            print(f"Device {device} ATC {self.atc} Port List {self.port_list}")
        if len(self.bus) is 0:
            raise Exception("Invalid Device Index Provided: {} or invalid port_list: {} versus layout: {}".format(self.device_index, self.port_list, RT_DEVICE_LAYOUT))

        # Initialize die offset
        try:
            self.die_offset = SOC_CONVERSION_CODE[self.soc]['DIE_OFFSET']
        except KeyError:
            self.die_offset = None
        if self.die_location:
            self.die_length = int(len(self.die_location['0']))
            self.die_number = 0
            print("Number of ATC Ports on DIE: {}".format(self.die_length))
        else:
            self.die_length = 0
            self.die_number = 0
        self.die_offset_addr = 0

        # Initialize dclkb and dclk lanes for de
        self.dclkb_lanes = dict()
        self.dclk_lanes = dict()

        valid_gen_versions = ["CIO_GEN2", "USB_10G", "CIO_GEN3", "USB_5G", "DP_RBR", "DP_HBR", "DP_HBR2", "DP_HBR3"]
        if self.gen_version not in ["CIO_GEN2", "USB_10G", "CIO_GEN3", "USB_5G", "DP_RBR", "DP_HBR", "DP_HBR2",
                                    "DP_HBR3"]:
            raise Exception("Gen Version Required to be in: {}, but Gen Version provided: {}".format(valid_gen_versions,
                                                                                                     self.gen_version))

        if self.gen_version in ["CIO_GEN2", "CIO_GEN3", "DP_RBR", "DP_HBR"]:
            self.lane_count = [0, 1]  # 2x PHYs 1x D2R and the other R2D
        elif self.gen_version in ["DP_HBR2", "DP_HBR3"]:
            self.lane_count = [0, 1, 2, 3]
        else: # self.gen_version in ["USB_10G", "USB_5G"]:
            if self.rt13_lane == None or int(self.rt13_lane) not in [0, 1]:
                raise Exception("No valid RT-13 Lane: {} provided for Gen Version: {}, but 0 or 1 expected".format(self.rt13_lane, self.gen_version))
            else:
                self.lane_count = [int(self.rt13_lane)]

        print("Per Gen Version: {} Self Lane Count: {} and RT-13 Lane: {}".format(self.gen_version, self.lane_count, self.rt13_lane))

        # phy = 0 is CFP, phy = 1 is SFP
        if self.phy is None:
            if self.gen_version in ["CIO_GEN2", "CIO_GEN3", "USB_10G", "USB_5G"]:
                self.phy_count = [0, 1]  # 2x PHYs 1x D2R and the other R2D
            else: # "DP_RBR", "DP_HBR", "DP_HBR2", "DP_HBR3"
                self.phy_count = [1]
        elif self.phy == "SFP":
            self.phy_count = [1]
        elif self.phy == "CFP":
            self.phy_count = [0]
        else:
            raise Exception("Attempted to Pass in an Invalid PHY (not SFP or CFP)")
        print("PHY COUNT: {}".format(self.phy_count))

        # Potential source of Diags Slowdown with 0xA / 0xB registers on CIO10G
        # print("Grab FW Version")
        # for i in range(0, len(self.bus)):
        #     self.grab_fw_version(self.bus[i], self.address[i])
        print("Initialize RT13 registers: {} RT13 Verify: {}".format(self.rt13_initialize, self.rt13_verify))

        # ToDo: Verify this new flow
        if self.rt13_initialize:
            self.initialize_eyescan_registers()
            raise Exception("Done initializing eyescan registers")

        # self.disable_link()
        # self.reenable_link()
        # self.retrain_link()

        if not self.doe and str(self.rt13_verify).lower() == "true":
            print("Verifying Eyescan Registers")
            # print("Skipping Verify Registers Until New FW / Feature Officially Verified and Rolled Out")
            self.verify_eyescan_registers()
        elif not str(self.rt13_verify).lower() == "true":
            print("RT13 Verify False, Skipping Initial Verify")
        else:
            print("DOE True, Skip Initial Verify")

        # Note: Just like RT-13 Initialize, PRBS Loopback / Ports is Meant For Setup, Not Margining
        self.prbs_loopback, self.prbs_ports = self.prbs_loopback[0], self.prbs_ports[0]
        print(f"PRBS Loopback: {self.prbs_loopback} PRBS Ports: {self.prbs_ports}")
        if self.prbs_loopback and self.prbs_ports is None:
            raise Exception(f"Attempting to enable PRBS Loopback without Providing Ports")
        elif self.prbs_ports is not None:
            if len(self.prbs_ports.split(",")) != 2:
                raise Exception("Incorrect # of PRBS Ports")
            else:
                self.enable_prbs()

        print(f"[End Initialize] Time Progressed: {time.time() - self.start_time}")


    def enable_prbs(self):
        """Enable PRBS"""

        # rdar://94045676 (PRBS Enablement)
        rx_port = self.prbs_ports.split(",")[0]
        tx_port = self.prbs_ports.split(",")[1]
        print(f"RX Port: {rx_port} TX Port: {tx_port}")

        # ToDo:
        #  1. Support Multiple Link Speeds
        #  2. Organize into functions / helpers, make TBTUtil function

        run(f"device -k usbphy -e select {tx_port}")
        run("device -k usbphy -e disable")
        run("device -k usbphy -e enable cio20g", True)

        run(f"ace --pick ATC{rx_port}")
        run("ace --read 0x1A")
        run("ace --4cc DISC --txdata 1")
        run("wait 5000")

        run(f"device -k usbphy -e select {rx_port}", True)
        run("device -k usbphy -e disable")
        run("device -k usbphy -e enable cio20g", True)

        run("wait 5000")

        self.initialize_eyescan_registers()

        print("SetComplianceModeRX(RT13_RX_ID) ———")
        run(f"TbtUtil --write 0x1 --rid {rx_port} --port 1 --space 1 --offset 0x16")
        run(f"TbtUtil --write 0x81000409 --rid {rx_port} --port 1 --space 1 --offset 0x15")
        run("wait 1000")

        run(f"TbtUtil --write 0x4D435852 --rid {rx_port} --port 1 --space 1 --offset 0x16")
        run(f"TbtUtil --write 0x81000408 --rid {rx_port} --port 1 --space 1 --offset 0x15")
        run("wait 1000")

        run(f"TbtUtil --read 0x80000408 --rid {rx_port} --port 1 --space 1 --offset 0x15")
        run("wait 1000")
        run(f"TbtUtil --read --rid {rx_port} --port 1 --space 1 --offset 0x16")

        run(f"TbtUtil --write 0x41 --rid {rx_port} --port 1 --space 1 --offset 0x16")
        run(f"TbtUtil --write 0x81000409 --rid {rx_port} --port 1 --space 1 --offset 0x15")
        run("wait 1000")

        run(f"TbtUtil --write 0x4D435852 --rid {rx_port} --port 1 --space 1 --offset 0x16")
        run(f"TbtUtil --write 0x81000408 --rid {rx_port} --port 1 --space 1 --offset 0x15")
        run("wait 1000")

        run(f"TbtUtil --write 0x80000408 --rid {rx_port} --port 1 --space 1 --offset 0x15")
        run(f"TbtUtil --read --rid {rx_port} --port 1 --space 1 --offset 0x16")

        print("SetComplianceModeTx_TxEp(RT13_TX_ID) ——-")
        run(f"TbtUtil --write 0x1C1 --rid {tx_port} --port 1 --space 1 --offset 0x16")
        run(f"TbtUtil --write 0x1C1 --rid {tx_port} --port 1 --space 1 --offset 0x16")
        run(f"TbtUtil --write 0x81000409 --rid {tx_port} --port 1 --space 1 --offset 0x15")
        run("wait 1000")

        run(f"TbtUtil --write 0x4D435854 --rid {tx_port} --port 1 --space 1 --offset 0x16")
        run(f"TbtUtil --write 0x81000408 --rid {tx_port} --port 1 --space 1 --offset 0x15")
        run("wait 1000")

        print("SetComplianceModeTx_RxEp(2) —— ")
        run(f"TbtUtil --write 0x80000408 --rid {rx_port} --port 1 --space 1 --offset 0x15")
        run(f"TbtUtil --read --rid {rx_port} --port 1 --space 1 --offset 0x16")

        raise Exception("PRBS Enabled")


    def verify_new_register(self, valid_lanes, valid_auspma, valid_phy, rt13_auspma_separation, rt13_lane_separation, rt13_phy_separation, write_value, reg_name, register_address):
        # Read back the written values to confirm accuracy
        index = 0
        for port in range(0, len(self.bus)):
            for acio_lane in valid_lanes:
                for phy in valid_phy:  # only set SFP side
                    for auspma in valid_auspma:
                        lane_value = (acio_lane * len(valid_auspma)) + auspma
                        self.current_lane = lane_value
                        base_address_modifier = (phy * rt13_phy_separation) + (acio_lane * rt13_lane_separation) + (
                                    auspma * rt13_auspma_separation)

                        expected_value = write_value[index]
                        new_register_value = self.read_phy_register(register_address + base_address_modifier, self.bus[port], self.address[port])

                        self.log_key(key="atc_{}_{}_lane_{}_new_{}_reg_raw".format(port, phy, self.current_lane, reg_name), value=int(new_register_value), units='ticks')

                        print("New Value Register {} Output: {} Expected: {}".format(reg_name, new_register_value, expected_value))
                        if expected_value != new_register_value:
                            raise Exception("Tried to write new {} values, but didn't successfully write".format(reg_name))
                        else:
                            print("New Value Lines Up With Expected Value")

    def read_original_values(self, valid_lanes, valid_auspma, valid_phy, rt13_phy_separation, rt13_lane_separation, rt13_auspma_separation, reg_name, reg_value):
        # Grab the original register values when link is active
        original_array = []
        for port in range(0, len(self.bus)):
            for acio_lane in valid_lanes:
                for phy in valid_phy: # only set SFP side
                    for auspma in valid_auspma:
                        phy_value = "CFP" if phy == 0 else "SFP"
                        lane_value = (acio_lane * len(valid_auspma)) + auspma
                        self.current_lane = lane_value
                        base_address_modifier = (phy * rt13_phy_separation) + (acio_lane * rt13_lane_separation) + (auspma * rt13_auspma_separation)
                        print("Grabbing registers from base address modifier: {} reg_name: {} phy_value: {} lane value: {} auspma: {}".format(base_address_modifier, reg_name, phy_value, acio_lane, auspma))
                        original_array.append(self.read_phy_register(reg_value + base_address_modifier, self.bus[port], self.address[port]))

        print("Register: {} Register Value: {} Original Values: {}".format(reg_name, reg_value, original_array))
        return original_array

    def initialize_eyescan_registers(self):
        for port in range(0, len(self.bus)):
            print("Initialize Eyescan Registers Port: {}".format(port))
            self.initialize_original_eyescan(self.bus[port], self.address[port])

        return 0


    def verify_eyescan_registers(self):
        print("Initializing Eyescan Registers")
        rt13_auspma_separation = 0x8000
        rt13_lane_separation = 0x10000
        rt13_phy_separation = 0x100000

        RXA_DESER_CTRL1_LANE0 = SOC_CONVERSION_CODE[self.soc]['AUSPMA_RX_SHM.AUSPMA_RT_RX_SHM_TJ.rxa_deser_ctrl1']
        RXA_DCOPI_CTRL2_LANE0 = SOC_CONVERSION_CODE[self.soc]['AUSPMA_RX_SHM.AUSPMA_RT_RX_SHM_TJ.rxa_dcopi_ctrl2']
        # EQ_TJ_CFG27_LANE0 = SOC_CONVERSION_CODE[self.soc]['AUSPMA_RX.AUSPMA_RX_EQ.AUSPMA_RT_RX_EQ_TJ.cfg27_eq']

        valid_lanes = self.lane_count
        valid_auspma = [0]
        if self.gen_version in ["DP_HBR2", "DP_HBR3"]:
            valid_lanes = [0, 1]
            valid_auspma = [0, 1]
        valid_phy = self.phy_count

        print("BUS: {} Valid Lanes: {} Valid PHY: {} Valid AUSPMA: {}".format(self.bus, valid_lanes, valid_phy, valid_auspma))

        # Grab the original register values when link is active
        print("Grab Original Register Value")
        original_deser_ctrl1 = self.read_original_values(valid_lanes, valid_auspma, valid_phy, rt13_phy_separation, rt13_lane_separation, rt13_auspma_separation, 'CTRL1', RXA_DESER_CTRL1_LANE0)
        original_dcopi_ctrl2 = self.read_original_values(valid_lanes, valid_auspma, valid_phy, rt13_phy_separation, rt13_lane_separation, rt13_auspma_separation, 'CTRL2', RXA_DCOPI_CTRL2_LANE0)
        # original_cfg_27 = self.read_original_values(valid_lanes, valid_auspma, valid_phy, rt13_phy_separation, rt13_lane_separation, rt13_auspma_separation, 'CFG27', EQ_TJ_CFG27_LANE0)

        index = 0
        for port in range(0, len(self.bus)):
            for acio_lane in valid_lanes:
                for phy in valid_phy:
                    for auspma in valid_auspma:
                        lane_value = (acio_lane * len(valid_auspma)) + auspma
                        self.current_lane = lane_value

                        base_address_modifier = (phy * rt13_phy_separation) + (acio_lane * rt13_lane_separation) + (auspma * rt13_auspma_separation)
                        DESER_CTRL1_ADDRESS = RXA_DESER_CTRL1_LANE0 + base_address_modifier
                        DCOPI_CTRL2_ADDRESS = RXA_DCOPI_CTRL2_LANE0 + base_address_modifier
                        # EQ_TJ_CFG27_ADDRESS= EQ_TJ_CFG27_LANE0 + base_address_modifier

                        original_deser_ctrl1_value = original_deser_ctrl1[index]
                        original_dcopi_ctrl2_value = original_dcopi_ctrl2[index]
                        # original_cfg_27_value = original_cfg_27[index]
                        index = index + 1

                        self.log_key(key="atc_{}_phy_{}_lane_{}_orig_ctrl1_reg".format(self.port_list[port], phy, self.current_lane), value=int(original_deser_ctrl1_value), units='ticks')
                        self.log_key(key="atc_{}_phy_{}_lane_{}_orig_ctrl2_reg".format(self.port_list[port], phy, self.current_lane), value=int(original_dcopi_ctrl2_value), units='ticks')
                        # self.log_key(key="atc_{}_phy_{}_lane_{}_orig_cfg27_reg".format(self.port_list[port], phy, self.current_lane), value=int(original_cfg_27_value), units='ticks')

                        if int((original_deser_ctrl1_value >> 14) & 0x3) != 3:
                            raise Exception("ATC: {} PHY: {} Lane: {} Address: {} Ctrl1 Value: {} Does not have Bits 14/15 = 3".format(
                                self.port_list[port], phy, self.current_lane, DESER_CTRL1_ADDRESS, int(original_deser_ctrl1_value)))
                        else:
                            print("For ATC: {} PHY: {} LANE: {} Address: {} CTRL1 Value: {} Has Expected Bits".format(
                                self.port_list[port], phy, self.current_lane, DESER_CTRL1_ADDRESS, int(original_deser_ctrl1_value)
                            ))

                        # if int((original_deser_ctrl1_value >> 30) & 0x3) != 2:
                        #     raise Exception("ATC: {} PHY: {} Lane: {} Address: {} Ctrl1 Value: {} Does not have Bits 30/31 = 2".format(
                        #         self.port_list[port], phy, self.current_lane, DESER_CTRL1_ADDRESS, int(original_deser_ctrl1_value)))
                        # else:
                        #     print("For ATC: {} PHY: {} LANE: {} Address: {} CTRL1 Value: {} Has Expected Bits".format(
                        #         self.port_list[port], phy, self.current_lane, DESER_CTRL1_ADDRESS, int(original_deser_ctrl1_value)
                        #     ))

                        if int((original_dcopi_ctrl2_value >> 24) & 0x3) != 3:
                            raise Exception("ATC: {} PHY: {} Lane: {} Address: {} CTRL2 Value: {} Does not have Bits 30/31 = 2".format(
                                self.port_list[port], phy, self.current_lane, DCOPI_CTRL2_ADDRESS, int(original_dcopi_ctrl2_value)))
                        else:
                            print("For ATC: {} PHY: {} LANE: {} Address: {} CTRL2 Value: {} Has Expected Bits".format(
                                self.port_list[port], phy, self.current_lane, DCOPI_CTRL2_ADDRESS, int(original_dcopi_ctrl2_value)
                            ))

                        # if int((original_cfg_27_value >> 8) & 0x3) != 3:
                        #     raise Exception("ATC: {} PHY: {} Lane: {} Address: {} CFG27 Value: {} Does not have Bits 30/31 = 2".format(
                        #         self.port_list[port], phy, self.current_lane, EQ_TJ_CFG27_ADDRESS, int(original_cfg_27_value)))
                        # else:
                        #     print("For ATC: {} PHY: {} LANE: {} Address: {} CFG27 Value: {} Has Expected Bits".format(
                        #         self.port_list[port], phy, self.current_lane, EQ_TJ_CFG27_ADDRESS, int(original_cfg_27_value)
                        #     ))

        print("Verify New Register Values Complete")

    def setup_code(self):
        """Setup the blocks of code that need to be changed or reset each round"""
        print("Setup Code")

        self.cio_gen = []
        self.orientation = []
        self.present = []
        self.rounded_value = []


    def configure_phy(self):
        """Configure the PHY Settings, Overrides, ECO, etc"""
        pass


    def apply_settings(self, retrain=True):
        """Apply EQ and other settings, retrain (if applicable)"""


    def ensure_link(self):
        # No settings to apply
        """Check Link meets Speed / Width requirements"""
        # Get the Link Status, and calculate the Link Width / Speed


    def setup_margining(self):
        """Configure the PHY and Setup Margining"""


    def start_margining(self):
        """Start the Margining"""


    def disable_link(self):
        """Initial Ace Link Disablement"""

        print("Disable the Ace links")
        try:
            run("device -k usbphy -e disable", True) # disable the PHY at every start
        except Exception as e:
            print(f"Found Error: {e}, Continuing")
        if self.gen_version in ["DP_RBR", "DP_HBR", "DP_HBR2", "DP_HBR3"]:
            run("display --off")
            run("dptx --off")
        time.sleep(1)
        for port in range(0, len(self.port_list)):
            if len(self.port_list) > 1:
                print("DOEs are not designed to work with multiport")
            type = self.type[port]
            if type in ["USBC", "usbc"]:
                run("ace --pick {}".format(type))
            else:
                run("ace --pick {}{}".format(type, self.device_index))
        time.sleep(1)
        run("ace --4cc SCfg --txdata '0x36 0xaf 0xff' --rxdata 0")
        time.sleep(1)
        run("ace --4cc SCfg --txdata '0x34 0xaf 0xff' --rxdata 0")
        time.sleep(1)
        run("ace --4cc SCfg --txdata '0x30 0xaf 0xff' --rxdata 0")
        time.sleep(1)
        run("ace --4cc SCfg --txdata '0x2e 0xaf 0xff' --rxdata 0")
        time.sleep(1)
        run("ace --4cc VOUT --txdata '0x1'")
        time.sleep(1)


    def reenable_link(self):
        """Reenable the Ace Link"""
        print("Reenable the Ace links")
        time.sleep(1)
        run("ace --4cc SCfg --txdata '0x36 0xae 0xff' --rxdata 0")
        time.sleep(1)
        run("ace --4cc SCfg --txdata '0x34 0xae 0xff' --rxdata 0")
        time.sleep(1)
        run("ace --4cc SCfg --txdata '0x30 0xae 0xff' --rxdata 0")
        time.sleep(1)
        run("ace --4cc SCfg --txdata '0x2e 0xae 0xff' --rxdata 0")
        time.sleep(1)
        run("ace --4cc VOUT --txdata '0x0'")
        time.sleep(1)


    def retrain_link(self):
        """Retrain the Link"""
        # if self.adaptation_run > 0:
        #     print("Disabling Link Before Retraining")
        #     try:
        #         run("device -k usbphy -e disable") # disable the PHY at every start
        #         if self.gen_version in ["DP_RBR", "DP_HBR", "DP_HBR2", "DP_HBR3"]:
        #             run("display --off")
        #             run("dptx --off")
        #     except Exception as e:
        #         print(f"Found Disable Error {e} continue")
        #     time.sleep(1)
        print("Retraining Link with Gen Version: {}".format(self.gen_version))
        try:
            if type in ["USBC", "usbc"]:
                run("device -k usbphy -e select usbc")
            else:
                run("device -k usbphy -e select {}".format(self.device_index))
        except Exception as e:
            print(f"Found Retrain Error {e}, continuing")
        print("Selected")
        time.sleep(1)
        # valid_gen_versions = ["CIO_GEN2", "USB_10G", "CIO_GEN3", "USB_5G", "DP_RBR", "DP_HBR", "DP_HBR3"]
        try:
            if self.gen_version in ["CIO_GEN3"]:
                run("device -k usbphy -e enable cio20g")
            elif self.gen_version in ["CIO_GEN2"]:
                run("device -k usbphy -e enable cio10g")
            elif self.gen_version in ["USB_10G", "USB_5G"]:
                run("device -k usbphy -e enable usb")
            elif self.gen_version in ["DP_RBR", "DP_HBR", "DP_HBR2", "DP_HBR3"]:
                run("device -k usbphy -e enable dp")
                run("dptx --on")
                run("dptx --exectest tunnel --testopts 'false'")
                if type in ["USBC", "usbc"]:
                    run("dptx --route usbc")
                else:
                    run("dptx --route ATC{}".format(self.device_index))
                # dptx --sw_training 4 8.1
                if self.gen_version in ["DP_RBR"]:
                    run("dptx --set link-rate-override 2.7")
                elif self.gen_version in ["DP_HBR", "DP_HBR2"]:
                    run("dptx --set link-rate-override 5.4")
                else:
                    run("dptx --set link-rate-override 8.1")
                run("display --pick USBC")
                run("display --on")
                run("display --setmode 6")
                run("dptx --exectest const_color_bist --testopts 'true 0 0 255'")
        except Exception as e:
            print(f"Found Retrain Error2 {e}, continuing")
        time.sleep(2)
        print("Link Retrained")


    def rt13_initialize_reset(self):
        print("Initialize RT13 registers")
        self.initialize_eyescan_registers()
        print("Done Initializing RT13 registers")

        if self.gen_version in ["CIO_GEN3", "CIO_GEN2", "USB_10G", "USB_5G"]:
            print("Reset not handled by link training")
            run("ace --4cc 'GAID'")  # reset RT-13
            time.sleep(2)
            run("ace --4cc SSPS --txdata 0x00")
        else:
            print("Reset handled by link training")


    def set_rc(self, figure_of_merit):
        """Set RC value to figure of merit"""
        print("Setting RC to Value: {}".format(figure_of_merit))
        rt13_auspma_separation = 0x8000
        rt13_lane_separation = 0x10000
        rt13_phy_separation = 0x100000

        EQ_CTRL_G3G4_1_LANE0 = SOC_CONVERSION_CODE[self.soc]['AUSPMA_RX_SHM_AUSPMA_RT_RX_SHM_TJ_rxa_eq_ctrl_g3g4_1']

        valid_lanes = self.lane_count
        valid_auspma = [0]
        if self.gen_version in ["DP_HBR2", "DP_HBR3"]:
            valid_lanes = [0, 1]
            valid_auspma = [0, 1]

        if self.phy is None:
            if self.gen_version in ["CIO_GEN2", "CIO_GEN3", "USB_10G", "USB_5G"]:
                valid_phy = [0, 1]  # 2x PHYs 1x D2R and the other R2D
            else: # "DP_RBR", "DP_HBR", "DP_HBR2", "DP_HBR3"
                valid_phy = [1]
        elif self.phy == "SFP":
            valid_phy = [1]
        elif self.phy == "CFP":
            valid_phy = [0]
        else:
            raise Exception("Attempted to Pass in an Invalid PHY (not SFP or CFP)")

        print("BUS: {} Valid Lanes: {} Valid PHY: {} Valid AUSPMA: {}".format(self.bus, valid_lanes, valid_phy, valid_auspma))

        original_value_store, write_value_store = [], []

        r_value = self.dec2gray(figure_of_merit[0])
        c_value = self.dec2gray(figure_of_merit[1])

        print("Target R Decimal Value: {} Target C Decimal Value: {} Target R Gray Value: {} Target C Gray Value: {}".format(
            figure_of_merit[0], figure_of_merit[1], r_value, c_value
        ))

        self.retrain_link() # train link initially just once to start testing

        # Grab the original register values when link is active
        original_value_store = self.read_original_values(valid_lanes, valid_auspma, self.phy_count, rt13_phy_separation, rt13_lane_separation, rt13_auspma_separation, 'G3G4', EQ_CTRL_G3G4_1_LANE0)

        # Handle the I2C Nor Value and RT-13 Reset
        # ToDo: Can't do I2C Nor w/ Verify
        # if self.rt13_verify:
        #     self.rt13_initialize_reset()

        # Disable Link Once
        self.disable_link()  # disable the link after grabbing the value

        # Calculate new register values based on Gen / R&C and write them using the ovewrite method
        index = 0
        for port in range(0, len(self.bus)):
            for acio_lane in valid_lanes:
                for phy in valid_phy: # only set SFP side (user needs to pass in --phy SFP parameter)
                    for auspma in valid_auspma:
                        lane_value = (acio_lane * len(valid_auspma)) + auspma
                        self.current_lane = lane_value
                        base_address_modifier = (phy * rt13_phy_separation) + (acio_lane * rt13_lane_separation) + (auspma * rt13_auspma_separation)

                        original_value = original_value_store[index]
                        index = index + 1

                        if self.gen_version in ["CIO_GEN3", "USB_10G"]: # Gen 4
                            orig_r_value = int((original_value >> 15) & 0xF)
                            orig_c_value = int((original_value >> 5) & 0xF)
                        else:
                            orig_r_value = int((original_value >> 10) & 0xF)
                            orig_c_value = int(original_value & 0xF)

                        self.log_key(key="atc_{}_phy_{}_lane_{}_orig_g3g4_reg_r{}_c{}".format(port, phy, self.current_lane, orig_r_value, orig_c_value), value=int(original_value), units='ticks')
                        print("PHY register original value: {} r_gray value: {} c_gray value: {}".format(original_value, orig_r_value, orig_c_value))
                        print("Original R Decimal Value: {} Original C Decimal Value: {}".format(self.gray2dec(orig_r_value), self.gray2dec(orig_c_value)))

                        write_value = original_value
                        print(f"RT13 DFE {self.rt13_dfe} and Lower {str(self.rt13_dfe).lower()} False Comparison {str(self.rt13_dfe).lower() == 'false'}")

                        if phy == 1 and str(self.rt13_dfe).lower() == "false":
                            write_value = write_value & 0x000FFFFF
                            write_value = write_value | 0x82000000

                        if self.gen_version in ["CIO_GEN3", "USB_10G"]: # Gen 4
                            write_value = write_value & 0xFFF07C1F # zero out gen4 values - 1111 1111 1111 0000 0111 1100 0001 1111
                            write_value = write_value | (1 << 19) # set R gen4 override bit
                            write_value = write_value | (1 << 9)  # set C gen4 override bit
                            write_value = write_value | ((int(r_value) & 0xF) << 15)
                            write_value = write_value | ((int(c_value) & 0xF) << 5)
                        else: # Gen 3 (will need to add DP)
                            write_value = write_value & 0xFFFF83E0  # zero out gen3 values - 1111 1111 1111 1111 1000 0011 1110 0000
                            write_value = write_value | (1 << 14)  # set R gen3 override bit
                            write_value = write_value | (1 << 4)  # set C gen3 override bit
                            write_value = write_value | ((int(r_value) & 0xF) << 10)
                            write_value = write_value | (int(c_value) & 0xF) # no shift

                        print("New Register Value: {} R Gray Value: {} C Gray Value: {}".format(write_value, r_value, c_value))
                        print("New Register Value: {} R Decimal Value: {} C Decimal Value: {}".format(write_value, self.gray2dec(r_value), self.gray2dec(c_value)))
                        time.sleep(1)
                        write_value_store.append(write_value)
                        self.write_overwrite_register(EQ_CTRL_G3G4_1_LANE0 + base_address_modifier, self.bus[port], self.address[port], write_value)
                        time.sleep(1)

                        if str(self.rt13_dfe).lower() == "false":
                            EQ_CTRL_G3G4_1_LANE0 = SOC_CONVERSION_CODE[self.soc]['AUSPMA_RX_SHM_AUSPMA_RT_RX_SHM_TJ_rxa_eq_ctrl_g3g4_1']
                            EQ_CTRL_G3G4_2_LANE0 = SOC_CONVERSION_CODE[self.soc]['AUSPMA_RX_SHM_AUSPMA_RT_RX_SHM_TJ_rxa_eq_ctrl_g3g4_2']
                            EQ_CTRL_G3G4_3_LANE0 = SOC_CONVERSION_CODE[self.soc]['AUSPMA_RX_SHM_AUSPMA_RT_RX_SHM_TJ_rxa_eq_ctrl_g3g4_3']
                            if phy == 1:
                                # i2c --devwrite 6 0x18 0x3 0x8 0x8c 0x30 0xa1 0x40 0x20 0x08 0x82 0x20 multiple (Reg = 0x40A1308C)
                                self.write_overwrite_register(EQ_CTRL_G3G4_2_LANE0 + base_address_modifier, self.bus[port], self.address[port], 0x20820820)
                                time.sleep(1)
                                # i2c --devwrite 6 0x18 0x3 0x8 0x90 0x30 0xa1 0x40 0x20 0x08 0x02 0x00 multiple (Reg = 0x40A13090)
                                self.write_overwrite_register(EQ_CTRL_G3G4_3_LANE0 + base_address_modifier, self.bus[port], self.address[port], 0x00020820)
                                time.sleep(1)
                            else:
                                print(f"CFP PHY {phy}, skipping")

                        print("Done Setting DFE")


        # Setup the link just once
        self.reenable_link()
        self.retrain_link()
        # ToDo: Can't do I2C Nor w/ Verify
        # print("Verifying Eyescan Registers RC Sweep")
        # if self.rt13_verify:
        #     self.verify_eyescan_registers()
        # else:
        #     print("RT13_Verify Not Enabled, Skipping")

        # Read back the written values to confirm accuracy
        self.log_key(key="new_g3g4_reg_raw_r{}_c{}".format(r_value, c_value), value=int(0), units='ticks')
        self.verify_new_register(valid_lanes, valid_auspma, self.phy_count, rt13_auspma_separation, rt13_lane_separation, rt13_phy_separation, write_value_store, "G3G4", EQ_CTRL_G3G4_1_LANE0)


    def set_adaptation(self, figure_of_merit):
        """Run RT-13 margining"""
        if bool(self.doe) is True:
            print("Figure of Merit: {}, setup ace commands off initally".format(figure_of_merit))
            self.set_rc(figure_of_merit)
        else:
            print("Skip Set Adaptation, no DOE")
            return 1


    def dec2gray(self, i=0):
        """ convert dec to gray """
        return i ^ i >> 1


    def gray2dec(self, i=0, total_bits=63):
        """ convert gray to dec """
        return [self.dec2gray(d) for d in range(total_bits)].index(i)


    def oed_h1_h3_cs(self, register_address, lane, phy, initial, port, bus, address):
        """ Grab the ctleoed_h1_th_cs -> ctleoed_h3_th_cs values """
        oed_h1_h3_cs_value = self.read_phy_register(register_address, bus, address)

        oed_h1_cs = int((oed_h1_h3_cs_value >> 18) & 0x3F)
        oed_h2_cs = int((oed_h1_h3_cs_value >> 24) & 0xF)
        oed_h3_cs = int((oed_h1_h3_cs_value >> 28) & 0xF)

        print(
        "OED H1-3 CS Register Value: {} h1 Value: {} h2 Value: {} h3 Value: {} Lane: {} Phy: {} Port: {} Reg Address: {} Bus: {} Address: {}".format(
            oed_h1_h3_cs_value, oed_h1_cs, oed_h2_cs, oed_h3_cs, lane, phy, port, hex(register_address), bus, address))

        # Per Jongbae, we want to remove these keys.
        # if initial is True:
        #     self.log_key(key="atc_{}_{}_lane_{}_h1_h3_cs_{}_raw".format(port, phy, self.current_lane, hex(register_address)), value=oed_h1_h3_cs_value, units='ticks')
        #     self.log_key(key="atc_{}_{}_lane_{}_oed_h1_cs".format(port, phy, self.current_lane), value=oed_h1_cs, units='ticks')
        #     self.log_key(key="atc_{}_{}_lane_{}_oed_h2_cs".format(port, phy, self.current_lane), value=oed_h2_cs, units='ticks')
        #     self.log_key(key="atc_{}_{}_lane_{}_oed_h3_cs".format(port, phy, self.current_lane), value=oed_h3_cs, units='ticks')


    def oed_h4_h5_cs(self, register_address, lane, phy, initial, port, bus, address):
        print("OED H4 H5 PHY: {}".format(phy))

        """ Grab the ctleoed_h4_th_cs -> ctleoed_h5_th_cs values """
        oed_h4_h5_value = self.read_phy_register(register_address, bus, address)

        oed_h4_cs = int(oed_h4_h5_value & 0xF)
        oed_h5_cs = int((oed_h4_h5_value >> 4) & 0xF)
        bi_direc_mode = int((oed_h4_h5_value >> 18) & 0x1)

        print("Bi Directional Mode Value Register Value: {} Converted Value: {} Lane: {} Phy: {} Port: {} Reg Address: {} Bus: {} Address: {}".format(
            oed_h4_h5_value, bi_direc_mode, lane, phy, port, hex(register_address), bus, address))

        print("OED H4-5 CS Register Value: {} Converted h4 Value: {}  Converted h5 Value: {} Lane: {} Phy: {} Port: {} Reg Address: {} Bus: {} Address: {}".format(
            oed_h4_h5_value, oed_h4_cs, oed_h5_cs, lane, phy, port, hex(register_address), bus, address))

        if initial is True:
            self.log_key(key="atc_{}_{}_lane_{}_bidirec_reg_{}_raw".format(port, phy, self.current_lane, hex(register_address)), value=oed_h4_h5_value, units='ticks')
            self.log_key(key="atc_{}_{}_lane_{}_bidirec_mode".format(port, phy, self.current_lane), value=bi_direc_mode, units='ticks')
            # Per Jongbae, we want to remove these keys.
            # self.log_key(key="atc_{}_{}_lane_{}_h4_h5_cs_{}_raw".format(port, phy, self.current_lane, hex(register_address)), value=oed_h4_h5_value, units='ticks')
            # self.log_key(key="atc_{}_{}_lane_{}_oed_h4_cs".format(port, phy, self.current_lane), value=oed_h4_cs, units='ticks')
            # self.log_key(key="atc_{}_{}_lane_{}_oed_h5_cs".format(port, phy, self.current_lane), value=oed_h5_cs, units='ticks')


    def local_tx_preset(self, register_address, lane, phy, initial, port, bus, address):
        """ Grab the TX EQ value """
        print("RT-13 Side TxEQ Dump PHY: {}".format(phy))
        rt13_tx_eq_value = self.read_phy_register(register_address, bus, address)

        rt13_eq = (int(rt13_tx_eq_value) & 0x3FFFF) # 18 bits

        print("RT13 EQ Register Value: {} Converted Value: {} Lane: {} Phy: {} Port: {} Reg Address: {} Bus: {} Address: {}".format(
            rt13_tx_eq_value, rt13_eq, lane, phy, port, hex(register_address), bus, address))

        if initial is True:
            self.log_key(key="atc_{}_{}_lane_{}_local_tx_eq".format(port, phy, self.current_lane), value=rt13_eq, units='ticks')


    def oed_h1_rs(self, register_address, lane, phy, initial, port, bus, address):
        """ Grab the ctleoed_h1_th_Rs value """
        print("OED H1 RS PHY: {}".format(phy))

        oed_h1_rs_value = self.read_phy_register(register_address, bus, address)

        oed_h1_rs = int((oed_h1_rs_value >> 24) & 0x3F)

        print("OED H1 RS Register Value: {} Converted Value: {} Lane: {} Phy: {} Port: {} Reg Address: {} Bus: {} Address: {}".format(
            oed_h1_rs_value, oed_h1_rs, lane, phy, port, hex(register_address), bus, address))

        # Per Jongbae we want to remove these keys
        # if initial is True:
        #     self.log_key(key="atc_{}_{}_lane_{}_oed_h1_rs_reg_{}_raw".format(port, phy, self.current_lane, hex(register_address)), value=oed_h1_rs_value, units='ticks')
        #     self.log_key(key="atc_{}_{}_lane_{}_oed_h1_rs".format(port, phy, self.current_lane), value=oed_h1_rs, units='ticks')


    def seq_a_eng(self, register_address, lane, phy, initial, port, bus, address):
        """ Grab the 3x seq end register values """
        print("OED SEG PHY: {}".format(phy))

        seq_eng_value = self.read_phy_register(register_address, bus, address)

        seq_a_eng1 = int(seq_eng_value & 0xF)
        seq_a_eng2 = int((seq_eng_value >> 4) & 0xF)
        seq_a_eng3 = int((seq_eng_value >> 8) & 0xF)

        print("Lane: {} Phy: {} Seq A Eng register read from address: {} port: {} bus: {} address: {} original value: {} eng1: {} eng2: {} eng3: {}".format(
          lane, phy, hex(register_address), port, bus, address, seq_eng_value, seq_a_eng1, seq_a_eng2, seq_a_eng3
        ))

        if initial is True:
            self.log_key(key="atc_{}_{}_lane_{}_seq_eng_reg_{}_raw".format(port, phy, self.current_lane,
                         hex(register_address)), value=seq_eng_value, units='ticks', register_file=True)
            self.log_key(key="atc_{}_{}_lane_{}_seq_a_eng1".format(port, phy, self.current_lane), value=seq_a_eng1, units='ticks', register_file=True)
            self.log_key(key="atc_{}_{}_lane_{}_seq_a_eng2".format(port, phy, self.current_lane), value=seq_a_eng2, units='ticks', register_file=True)
            self.log_key(key="atc_{}_{}_lane_{}_seq_a_eng3".format(port, phy, self.current_lane), value=seq_a_eng3, units='ticks', register_file=True)


    def seq_b_eng(self, register_address, lane, phy, initial, port, bus, address):
        """ Grab the 3x seq end register values """
        print("OED SEG PHY: {}".format(phy))

        seq_eng_value = self.read_phy_register(register_address, bus, address)

        seq_b_eng1 = int(seq_eng_value & 0xF)
        seq_b_eng2 = int((seq_eng_value >> 4) & 0xF)
        seq_b_eng3 = int((seq_eng_value >> 8) & 0xF)

        print("Lane: {} Phy: {} Seq B Eng register read from address: {} port: {} bus: {} address: {} original value: {} eng1: {} eng2: {} eng3: {}".format(
          lane, phy, hex(register_address), port, bus, address, seq_eng_value, seq_b_eng1, seq_b_eng2, seq_b_eng3
        ))

        if initial is True:
            self.log_key(key="atc_{}_{}_lane_{}_seq_eng_reg_{}_raw".format(port, phy, self.current_lane,
                         hex(register_address)), value=seq_eng_value, units='ticks')
            self.log_key(key="atc_{}_{}_lane_{}_seq_b_eng1".format(port, phy, self.current_lane), value=seq_b_eng1, units='ticks')
            self.log_key(key="atc_{}_{}_lane_{}_seq_b_eng2".format(port, phy, self.current_lane), value=seq_b_eng2, units='ticks')
            self.log_key(key="atc_{}_{}_lane_{}_seq_b_eng3".format(port, phy, self.current_lane), value=seq_b_eng3, units='ticks')


    def eclock_dclock(self, register_address, lane, phy, initial, port, bus, address):
        """Grab and log the eclock and dclock decimal values"""
        eclock_dclock_value = self.read_phy_register(register_address, bus, address)
        print("Full EClock DClock Value: {}".format(eclock_dclock_value))

        dclkb = self.gray2dec(int((eclock_dclock_value >> 21) & 0x7F))
        dclk = self.gray2dec(int((eclock_dclock_value >> 14) & 0x7F))
        eclkb = self.gray2dec(int((eclock_dclock_value >> 7) & 0x7F))
        eclk = self.gray2dec(int(eclock_dclock_value & 0x7F))

        print("lane: {} phy: {} register: {} post conversion DCLKB Output: {} DCLK: {} ECLKB: {} ECLK: {}".format(
            lane, phy, hex(register_address), dclkb, dclk, eclkb, eclk))

        phy_id = 0 if phy == "CFP" else 1 # phy_str = "CFP" if phy_id == 0 else "SFP"

        # Need to save the values instead of overwriting with previous for each for calculation usage
        self.dclkb_lanes["Lane:{} Phy:{} ATC:{}".format(lane, phy_id, port)] = dclkb
        self.dclk_lanes["Lane:{} Phy:{} ATC:{}".format(lane, phy_id, port)] = dclk

        if initial is True:
            self.log_key(key="atc_{}_{}_lane_{}_eclk_dclk_{}_raw".format(port, phy, self.current_lane,
                                                                           hex(register_address)),
                         value=eclock_dclock_value, units='ticks')
            self.log_key(key="atc_{}_{}_lane_{}_dclkb_dec".format(port, phy, self.current_lane), value=dclkb, units='ticks')
            self.log_key(key="atc_{}_{}_lane_{}_dclk_dec".format(port, phy, self.current_lane), value=dclk, units='ticks')
            self.log_key(key="atc_{}_{}_lane_{}_eclkb_dec".format(port, phy, self.current_lane), value=eclkb, units='ticks')
            self.log_key(key="atc_{}_{}_lane_{}_eclk_dec".format(port, phy, self.current_lane), value=eclk, units='ticks')


    def grab_h0(self, cfg14, cfg28, cfg29, lane, phy, initial, port, bus, address):
        """Grab H0 registers"""
        print("Grabbing H0 Register")

        # Step 1 - (Register: 0x40912044) Please set the h0_src_sel_ov to 2 and set h0_src_ov to 1.
        # Bit 16 -> 1 and Bits 0->3 to 2
        print("Step 1")
        h0_step1_initial_value = int(self.read_phy_register(cfg14, bus, address))

        h0_step_1_value = h0_step1_initial_value & 0xFFFEFFF0
        h0_step_1_value = h0_step_1_value | (1 << 16)
        h0_step_1_value = h0_step_1_value | 2

        print(f"Writing Register - H0 Step 0 Initial Value: {hex(h0_step1_initial_value)} H0 Step 1 New Value: {hex(h0_step_1_value)}")
        self.write_phy_register(cfg14, bus, address, h0_step_1_value)

        print("Read Register to Confirm Step 1")
        h0_step1_initial_value = int(self.read_phy_register(cfg14, bus, address))
        print(f"Output Confirmed Step 1: {hex(h0_step1_initial_value)}")

        # Step 2 - (Register: 0x409120a0) Please toggle captured_adapted_eq_ctrl 1 then 0 with gape of at least 500ns.
        # Bit 0 to 1, wait at least 500 ns, Bit 0 to 0
        print("Step 2")
        h0_step2_initial_value = int(self.read_phy_register(cfg28, bus, address))

        h0_step_2_value = h0_step2_initial_value & 0xFFFFFFFE
        h0_step_2_value = h0_step_2_value | 1

        print(f"Writing Register - H0 Step 2 Initial Value: {hex(h0_step2_initial_value)} H0 Step 2 New Value: {hex(h0_step_2_value)}")
        self.write_phy_register(cfg28, bus, address, h0_step_2_value)

        print("Read Register to Confirm Step 2.1")
        h0_step2_initial_value = int(self.read_phy_register(cfg28, bus, address))
        print(f"Output Confirmed Step 2.1: {hex(h0_step2_initial_value)}")

        h0_step2_initial_value = int(self.read_phy_register(cfg28, bus, address))
        h0_step_2_value = h0_step2_initial_value & 0xFFFFFFFE

        print(f"Writing Register - H0 Step 2 Initial Value (Flip Back Post Sleep): {hex(h0_step2_initial_value)} H0 Step 2 New Value: {hex(h0_step_2_value)}")
        self.write_phy_register(cfg28, bus, address, h0_step_2_value)

        print("Read Register to Confirm Step 2.2")
        h0_step2_initial_value = int(self.read_phy_register(cfg28, bus, address))
        print(f"Output Confirmed: {hex(h0_step2_initial_value)}")

        # Step 3 - (Register: 0x4091209c) Please read the H0 value.
        # Bits 0 -> 5
        print("Step 3")
        h0_step3_initial_value = self.read_phy_register(cfg29, bus, address)
        h0_value = h0_step3_initial_value & 0x0000003F # Grab the last 6 bits
        h0_value = h0_value * 11.9 # Multiple by 11.9 for H0Dac Range = 3 which is the default

        print(f"Found H0 Value: {h0_value}")
        if initial is True:
            self.log_key(key="atc_{}_{}_lane_{}_h0".format(port, phy, self.current_lane), value=h0_value, units='mV')


    def grab_h1_h5_r_c(self, register_address, lane, phy, initial, port, bus, address):
        """Grab h1 to h5 registers"""
        h_values = self.read_phy_register(register_address, bus, address)

        h5_raw = int((h_values >> 25) & 0xF)
        h4_raw = int((h_values >> 21) & 0xF)
        h3_raw = int((h_values >> 17) & 0xF)
        h2_raw = int((h_values >> 13) & 0xF)
        h1_raw = int((h_values >> 8) & 0x1F)

        magnitude_3bit = int(h_values & 0x7)
        magnitude_5bit = int(h_values & 0x1F)


        sign_value_h2 = -1 if (int((h2_raw >> 3) & 0x1)) == 1 else 1
        sign_value_h3 = -1 if (int((h3_raw >> 3) & 0x1)) == 1 else 1
        sign_value_h4 = -1 if (int((h4_raw >> 3) & 0x1)) == 1 else 1
        sign_value_h5 = -1 if (int((h5_raw >> 3) & 0x1)) == 1 else 1

        cz_raw = self.gray2dec(int((h_values >> 4) & 0xF))
        rz_raw = self.gray2dec(int(h_values & 0xF))

        h1_dec = self.gray2dec(h1_raw)
        h2_dec = self.gray2dec(h2_raw)
        h3_dec = self.gray2dec(h3_raw)
        h4_dec = self.gray2dec(h4_raw)
        h5_dec = self.gray2dec(h5_raw)

        print("H1 Dec: {} H2 Dec: {} H3 Dec: {} H4 Dec: {} H5 Dec: {} H2 Sign: {} H3 Sign: {} H4 Sign: {} H5 Sign: {}".format(
            h1_dec, h2_dec,  h3_dec, h4_dec, h5_dec, sign_value_h2, sign_value_h3, sign_value_h4, sign_value_h5))

        h1_modified = h1_dec * 4.8
        h2_modified = (h2_dec & 0x7) * 4 * sign_value_h2
        h3_modified = (h3_dec & 0x7) * 4 * sign_value_h3
        h4_modified = (h4_dec & 0x7) * 4 * sign_value_h4
        h5_modified = (h5_dec & 0x7) * 4 * sign_value_h5

        print("Lane: {} Phy: {} Register: {} H1 Raw: {} H2 Raw: {} H3 Raw: {} H4 Raw: {} H5 Raw: {} CZ Raw: {} RZ Raw: {} magnitude 3: {} magnitude 5: {}".format(
            lane, phy, hex(register_address), h1_raw, h2_raw, h3_raw, h4_raw, h5_raw, cz_raw, rz_raw, magnitude_3bit, magnitude_5bit
        ))

        print("Lane: {} Phy: {} Register: {} H1 Modified: {} H2 Modified: {} H3 Modified: {} H4 Modified: {} H5 Modified: {} CZ Raw: {} RZ Raw: {}".format(
            lane, phy, hex(register_address), h1_modified, h2_modified, h3_modified, h4_modified, h5_modified, cz_raw, rz_raw
        ))

        # Range values from Jongbae, from SEG AMS folks
        if initial is True:
            self.log_key(key="atc_{}_{}_lane_{}_h1_h5_reg_{}_raw".format(port, phy, self.current_lane,
                                                                         hex(register_address)),
                         value=h_values, units='ticks')
            self.log_key(key="atc_{}_{}_lane_{}_h1".format(port, phy, self.current_lane), value=h1_modified, units='mV',
                         upperlimit=148.8, lowerlimit=0)
            self.log_key(key="atc_{}_{}_lane_{}_h2".format(port, phy, self.current_lane), value=h2_modified, units='mV',
                         upperlimit=28, lowerlimit=-28)
            self.log_key(key="atc_{}_{}_lane_{}_h3".format(port, phy, self.current_lane), value=h3_modified, units='mV',
                         upperlimit=28, lowerlimit=-28)
            self.log_key(key="atc_{}_{}_lane_{}_h4".format(port, phy, self.current_lane), value=h4_modified, units='mV',
                         upperlimit=28, lowerlimit=-28)
            self.log_key(key="atc_{}_{}_lane_{}_h5".format(port, phy, self.current_lane), value=h5_modified, units='mV',
                         upperlimit=28, lowerlimit=-28)

            self.log_key(key="atc_{}_{}_lane_{}_cz".format(port, phy, self.current_lane), value=cz_raw, units='ticks')
            self.log_key(key="atc_{}_{}_lane_{}_rz".format(port, phy, self.current_lane), value=rz_raw, units='ticks')

    def grab_divider_register(self, initial):
        """Grab the divider register values"""
        print("Grab Divider Register with Port List: {} Type: {}".format(self.port_list, self.type))
        for port_index in range(0, len(self.port_list)):
            if self.type[port_index].upper() != 'USBC':
                print("grabbing divider register from: {}".format(self.LANE_RP_OFFSET[port_index] + 0x90b0))
                divider = int(self.get_bits(self.LANE_RP_OFFSET[port_index] + 0x90b0, 0, 2))  # https://seg-docs.csg.apple.com/projects/staten/release/UserManual/regs/chip__ATC0__ATC_TOP__ACIOPHY__ACIOPHY_LANE__AUSPMA__AUSPMA_RX__AUSPMA_RX_TOP.html?baseaddr=0x383009000#AUSPMA_RX_TOP_AUSPMA_RX_TOP_TJ_cdr_cfg2
                print("divider register value: {}".format(divider))

                if initial == True:
                    self.log_key(key="atc_{}_lane_{}_divider_bits".format(self.port_list[port_index], self.current_lane), value=divider, units='ticks')
            else:
                print("Skipping grabbing divider register")

    def soc_tx_present_grab(self, port, register, initial):
        print(f"Port {port} ATC {self.atc} Port List {self.port_list}")
        port_list_index = self.port_list.index(port)
        print("SoC Side TxEQ Dump Initial: {} ATC Port Offset: {} Port: {} Port List Index: {}".format(initial, self.ATC_PORT_OFFSET, port, port_list_index))
        REGISTER_PORT = self.ATC_PORT_OFFSET[port_list_index] + register
        print("Register Address for Port: {}".format(REGISTER_PORT))
        if self.gen_version in ["USB_5G"]:
            txeq_dump_value = int(self.get_bits(REGISTER_PORT, 1, 2))
        else:
            txeq_dump_value = int(self.get_bits(REGISTER_PORT, 0, 18))

        print("TX EQ Dump register value: {}".format(txeq_dump_value))
        if initial is True:
            self.log_key(key="atc_{}_remote_lane_{}_tx_eq".format(port, self.current_lane), value=txeq_dump_value, units='ticks')

    def tx_local_tx_preset(self, register_address, lane, phy, initial, port, bus, address):
        """Grab tx local tx present values"""
        tx_local_tx_preset = int(self.read_phy_register(register_address, bus, address) & 0x3FFFF)
        print("TX Local TX Preset Output: {} Lane: {} from address: {}".format(tx_local_tx_preset, lane, hex(register_address)))

        if initial is True:
            self.log_key(key="atc_{}_{}_lane_{}_tx_local_tx_preset".format(port, phy, self.current_lane), value=tx_local_tx_preset, units='ticks')


    def dump_registers(self, initial=True):
        """Dump Static Registers"""
        print(f"[Start Dump Register] Time Progressed: {time.time() - self.start_time}")

        if initial is True: # Per JongBae, only want registers from before, not after
            print("Dump Registers for {} ports {} lanes {} phys".format(len(self.bus), self.lane_count, self.phy_count))
            rt13_auspma_separation = 0x8000
            rt13_lane_separation = 0x10000
            rt13_phy_separation = 0x100000

            EQ_CTRL_RAW_CAP1_LANE0 = SOC_CONVERSION_CODE[self.soc]['EQ_CTRL_RAW_CAP1_LANE0']
            EQ_CTRL_RAW_CAP2_LANE0 = SOC_CONVERSION_CODE[self.soc]['EQ_CTRL_RAW_CAP2_LANE0']
            TX_EQ_CTRL_REG2_LANE0 = SOC_CONVERSION_CODE[self.soc]['TX_EQ_CTRL_REG2_LANE0']
            SEG_ENG_A_LANE0 = SOC_CONVERSION_CODE[self.soc]['AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg15_eq_LANE0']
            SEG_ENG_B_LANE0 = SOC_CONVERSION_CODE[self.soc]['AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg17_eq_LANE0']
            OED_H1_H3_CS_LANE0 = SOC_CONVERSION_CODE[self.soc]['AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg57_eq']
            OED_H4_H5_CS_LANE0 = SOC_CONVERSION_CODE[self.soc]['AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg58_eq']
            OED_H1_RS_LANE0 = SOC_CONVERSION_CODE[self.soc]['AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg59_eq']
            EQ_TJ_CFG14_EQ = SOC_CONVERSION_CODE[self.soc]['AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg14_eq']
            EQ_TJ_CFG28_EQ = SOC_CONVERSION_CODE[self.soc]['AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg28_eq']
            EQ_TJ_CFG29_EQ = SOC_CONVERSION_CODE[self.soc]['AUSPMA_RX_EQ_AUSPMA_RT_RX_EQ_TJ_cfg29_eq']

            USB5G_REGISTER = SOC_CONVERSION_CODE[self.soc]['USB5G_TX_OFFSET']
            USB10G_REGISTER = SOC_CONVERSION_CODE[self.soc]['USB10G_TX_OFFSET']

            USB5G_LIFUKA = SOC_CONVERSION_CODE[self.soc]['ARUSB_PIPE_HANDLER_TX_DEEMPHASIS_USBGen1']
            USB10G_LIFUKA = SOC_CONVERSION_CODE[self.soc]['ARUSB_PIPE_HANDLER_TX_DEEMPHASIS_USBGen2']

            self.grab_divider_register(initial) # only need to call 1x because SoC side register

            valid_lanes = self.lane_count
            valid_auspma = [0]

            # For HBR2/3 they don't have 2 lanes for register dump register perspective
            if self.gen_version in ["DP_HBR2", "DP_HBR3"]:
                valid_lanes = [0, 1]
                valid_auspma = [0, 1]

            # Make Sure Port List is all Int
            new_port_list = []
            for value in self.port_list:
                new_port_list.append(int(value))
            self.port_list = new_port_list

            for port in range(0, len(self.bus)):
                print(f"ATC Self {self.atc} Port {port}")
                if self.gen_version in ["USB_5G"]:
                    self.soc_tx_present_grab(port=self.atc[port], register=USB5G_REGISTER, initial=initial)
                elif self.gen_version in ["USB_10G"]:
                    self.soc_tx_present_grab(port=self.atc[port], register=USB10G_REGISTER, initial=initial)
                else:
                    print("No USB5/10G for SoC Register Grab")

                try:
                    fusing = int(self.read_phy_register(0x400bc000, self.bus[port], self.address[port])) - int(0xA050C030) # Fuse Bits
                except Exception:
                    fusing = 0

                print(f"Bus: {self.bus[port]} Address: {self.address[port]} Fusing: {fusing}")

                if fusing > 0 and self.dump_h0:
                    print("Do you really want to dump H0 on a Prod Fused Unit, it'll Probably Fail")
                else:
                    print("Dump H0, Good to Go")

                for acio_lane in valid_lanes:
                    for phy in self.phy_count:
                        for auspma in valid_auspma:
                            phy_value = "CFP" if phy == 0 else "SFP"
                            lane_value = (acio_lane * len(valid_auspma)) + auspma
                            self.current_lane = lane_value
                            base_address_modifier = (phy * rt13_phy_separation) + (acio_lane * rt13_lane_separation) + (auspma * rt13_auspma_separation)
                            print("PHY Value: {} ACIO Lane: {} Lane Value: {} AUSPMA: {} Port: {} Base Address Modifier: {}".format(phy_value, acio_lane, lane_value, auspma, port, base_address_modifier))
                            print("Gen Version: {}".format(self.gen_version))

                            # Remove because this register won't be accessible in Prod Units
                            # ToDo: This is reading bad values because USB5/10G PHY (0/1) and Lane (0/1) don't have base address modifieed the same way
                            # ToDo: Not sure where those blocks are in ar_usb or which blocks to read.
                            # if self.gen_version in ["USB_5G"]:
                            #     self.local_tx_preset(USB5G_LIFUKA + base_address_modifier, lane_value, phy_value, initial, self.atc[port], self.bus[port], self.address[port])
                            # elif self.gen_version in ["USB_10G"]:
                            #     self.local_tx_preset(USB10G_LIFUKA + base_address_modifier, lane_value, phy_value, initial, self.atc[port], self.bus[port], self.address[port])
                            # else:
                            #     print("No USB5/10G for RT-13 Register Grab")

                            self.grab_tffe_values(port, lane_value, phy, phy_value)

                            print(f"Dump H0 Parameter: {self.dump_h0}")
                            if self.dump_h0:
                                self.grab_h0(EQ_TJ_CFG14_EQ + base_address_modifier, EQ_TJ_CFG28_EQ + base_address_modifier, EQ_TJ_CFG29_EQ + base_address_modifier, lane_value, phy_value, initial, self.atc[port], self.bus[port], self.address[port])
                            self.grab_h1_h5_r_c(EQ_CTRL_RAW_CAP1_LANE0 + base_address_modifier, lane_value, phy_value, initial, self.atc[port], self.bus[port], self.address[port])
                            self.eclock_dclock(EQ_CTRL_RAW_CAP2_LANE0 + base_address_modifier, lane_value, phy_value, initial, self.atc[port], self.bus[port], self.address[port])
                            # Per Jongbae, remove TX Local Preset because it's covered by TFFE values grab
                            # self.tx_local_tx_preset(TX_EQ_CTRL_REG2_LANE0 + base_address_modifier, lane_value, phy_value, initial, self.atc[port], self.bus[port], self.address[port])
                            self.seq_a_eng(SEG_ENG_A_LANE0 + base_address_modifier, lane_value, phy_value, initial, self.atc[port], self.bus[port], self.address[port])
                            self.seq_b_eng(SEG_ENG_B_LANE0 + base_address_modifier, lane_value, phy_value, initial, self.atc[port], self.bus[port], self.address[port])
                            self.oed_h1_h3_cs(OED_H1_H3_CS_LANE0 + base_address_modifier, lane_value, phy_value, initial, self.atc[port], self.bus[port], self.address[port])
                            self.oed_h4_h5_cs(OED_H4_H5_CS_LANE0 + base_address_modifier, lane_value, phy_value, initial, self.atc[port], self.bus[port], self.address[port])
                            self.oed_h1_rs(OED_H1_RS_LANE0 + base_address_modifier, lane_value, phy_value, initial, self.atc[port], self.bus[port], self.address[port])
        else:
            print("Initial is False, dumping no registers")

        print(f"[End Dump Register] Time Progressed: {time.time() - self.start_time}")


    def calculate_base_offset(self, port_num):
        """Calculate the base pcie offset based on the port_num"""
        self.die_offset_addr = 0
        # if die location isn't provided in project defines, we assume the project is single die.
        if self.die_location:
            for key, value in self.die_location.items():
                # grab which die the port_num is on
                if str(port_num) in value:
                    if self.die_offset:
                        die_offset_addr = int(key) * self.die_offset
                        self.die_offset_addr = die_offset_addr
                        self.die_number = int(key)
                        print("   Found Valid Key: {} in Die Location: {} for Port Num: {} New Die Offset ADDR: {}   ".format(key, self.die_location, port_num, self.die_offset_addr))
                        self.log_msg("   Found Valid Key: {} in Die Location: {} for Port Num: {}   ".format(key, self.die_location, port_num))
                        return
                    else:
                        # error if we have multiple dies but no offset for between the dies
                        print("    Die Location Exists (i.e. the product has multiple dies) but no offsett address provided    ")
                        raise("    Die Location Exists (i.e. the product has multiple dies) but no offsett address provided    ")
            print("    Port Number: {} not found in Die Location: {}    ".format(port_num, self.die_location))
            raise("    Port Number: {} not found in Die Location: {}    ".format(port_num, self.die_location))
        else:
            # print("    No Die Location, Moving On     ")
            self.log_msg("    No Die Location, Moving On     ")


    def get_bits(self, address, start_bit, length):
        """Change specific bits of a address"""


    def select_lane(self, lane):
        """Select a Lane"""
        previous_device_index = self.device_index

        print("Port List: {} for select lane".format(self.port_list))
        self.RP_OFFSET_ACIO = []
        self.LANE_RP_OFFSET = []
        self.ATC_PORT_OFFSET = []
        for port in self.port_list:
            print("Appending Port: {}".format(port))
            self.device_index = int(port)
            self.port_num = int(self.device_index)
            self.calculate_base_offset(self.port_num)
            self.soc_atc0_offset = SOC_CONVERSION_CODE[self.soc]['SOC_ATC_OFFSET']
            self.atc_top_offset = SOC_CONVERSION_CODE[self.soc]['ATC_TOP_OFFSET']
            self.atc_acio_offset = SOC_CONVERSION_CODE[self.soc]['ATC_ACIO_OFFSET']
            self.lane_offset = SOC_CONVERSION_CODE[self.soc]['LANE_OFFSET']
            self.RP_OFFSET = SOC_CONVERSION_CODE[self.soc]['RP_OFFSET']
            self.ATC_PORT_OFFSET.append(self.soc_atc0_offset + self.die_offset_addr + ((self.port_num - (self.die_number * self.die_length)) * self.RP_OFFSET))
            self.LANE_RP_OFFSET.append(self.soc_atc0_offset + self.die_offset_addr + \
                                      (self.port_num - (self.die_number * self.die_length)) * self.RP_OFFSET + \
                                      self.atc_top_offset + \
                                       self.current_lane * self.lane_offset)
            self.RP_OFFSET_ACIO.append(self.soc_atc0_offset + self.die_offset_addr + \
                                      self.atc_acio_offset +\
                                      (self.port_num - (self.die_number * self.die_length)) * self.RP_OFFSET)

        print("   Selecting Lane {} with LANE RP OFFSET: {} and RP OFFSET ACIO {}".format(lane, self.LANE_RP_OFFSET, self.RP_OFFSET_ACIO))
        self.log_msg("   Selecting Lane {} with LANE RP OFFSET: {} and RP OFFSET ACIO {}".format(lane, self.LANE_RP_OFFSET, self.RP_OFFSET_ACIO))
        self.device_index = previous_device_index


    def share_output(self, port, lane, phy, eye_north_tick, eye_south_tick, eye_east_tick, eye_west_tick, eye_eh_mv, eye_pk2pk_ew_ps,
                     eye_left_ew_ps, eye_right_ew_ps, eye_leftright_min_ew_ps, eye_leftright_2x_min_ew_ps, eye_left_dclkb_ew_ps, eye_right_dclkb_ew_ps,
                     eye_left_dclk_ew_ps, eye_right_dclk_ew_ps):
        """Share the output calculated"""
        print(f"[Start Share Output] Time Progressed: {time.time() - self.start_time}")

        phy = "CFP" if phy == 0 else "SFP"

        self.log_key(key="atc_{}_{}_lane_{}_north_ticks".format(port, phy, self.current_lane), value=eye_north_tick, units='ticks')
        self.log_key(key="atc_{}_{}_lane_{}_south_ticks".format(port, phy, self.current_lane), value=eye_south_tick, units='ticks')
        self.log_key(key="atc_{}_{}_lane_{}_east_ticks".format(port, phy, self.current_lane), value=eye_east_tick, units='ticks')
        self.log_key(key="atc_{}_{}_lane_{}_west_ticks".format(port, phy, self.current_lane), value=eye_west_tick, units='ticks')

        self.log_key(key="atc_{}_{}_lane_{}_eh_mv".format(port, phy, self.current_lane), value=eye_eh_mv,
                     units='mv', upperlimit=self.eh_max, lowerlimit=self.eh_min)
        self.log_key(key="atc_{}_{}_lane_{}_pk2pk_ew_ps".format(port, phy, self.current_lane), value=eye_pk2pk_ew_ps,
                     units='ps')

        self.log_key(key="atc_{}_{}_lane_{}_left_ew_ps".format(port, phy, self.current_lane), value=eye_left_ew_ps,
                     units='ps', upperlimit=self.ew_max, lowerlimit=self.ew_min)
        self.log_key(key="atc_{}_{}_lane_{}_right_ew_ps".format(port, phy, self.current_lane), value=eye_right_ew_ps,
                     units='ps', upperlimit=self.ew_max, lowerlimit=self.ew_min)

        self.log_key(key="atc_{}_{}_lane_{}_left_dclkb_ew_ps".format(port, phy, self.current_lane), value=eye_left_dclkb_ew_ps,
                     units='ps', upperlimit=self.ew_max, lowerlimit=self.ew_min)
        self.log_key(key="atc_{}_{}_lane_{}_right_dclkb_ew_ps".format(port, phy, self.current_lane), value=eye_right_dclkb_ew_ps,
                     units='ps', upperlimit=self.ew_max, lowerlimit=self.ew_min)

        self.log_key(key="atc_{}_{}_lane_{}_left_dclk_ew_ps".format(port, phy, self.current_lane), value=eye_left_dclk_ew_ps,
                     units='ps', upperlimit=self.ew_max, lowerlimit=self.ew_min)
        self.log_key(key="atc_{}_{}_lane_{}_right_dclk_ew_ps".format(port, phy, self.current_lane), value=eye_right_dclk_ew_ps,
                     units='ps', upperlimit=self.ew_max, lowerlimit=self.ew_min)

        self.log_key(key="atc_{}_{}_lane_{}_eh_ticks".format(port, phy, self.current_lane), value=(eye_north_tick - eye_south_tick),
                     units='ticks')
        self.log_key(key="atc_{}_{}_lane_{}_ew_ticks".format(port, phy, self.current_lane), value=(eye_east_tick - eye_west_tick),
                     units='ticks')

        self.log_key(key="atc_{}_{}_lane_{}_leftright_min_ew_ps".format(port, phy, self.current_lane), value=eye_leftright_min_ew_ps,
                     units='ps', upperlimit=self.ew_max, lowerlimit=self.ew_min)

        # CIO20 low limit = 11.5, high = 46, CIO10 low limit = 23, high = 95, USB3 SS+ low limit = 23, high = 95
        # USB3 SS low limit = 46, high = 190, HBR3 low limit = 50, high = 110, HBR2 low limit = 74, high = 175

        self.log_key(key="atc_{}_{}_lane_{}_leftright_2xmin_ew_ps".format(port, phy, self.current_lane), value=eye_leftright_2x_min_ew_ps,
                     units='ps', upperlimit=self.ew_max, lowerlimit=self.ew_min)

        self.log_msg("ATC: {} Phy: {} Lane {} north = {}, south = {}, east = {}, west = {}, ns = {}mv, ew = {}ps".format(
            port,
            phy,
            self.current_lane,
            eye_north_tick,
            eye_south_tick,
            eye_east_tick,
            eye_west_tick,
            (eye_north_tick + abs(eye_south_tick)),
            eye_pk2pk_ew_ps
        ))

        print(f"[End Share Output] Time Progressed: {time.time() - self.start_time}")


    def parse_limits_2d(self, margin_data_lane, dclk_index):
        # Iterate thru the coordinate Top Left to Bottom Right
        # Per Jongbae, for RT-13 East, West should be the furthest right / left
        # North / South should be off of the DCLKB  column
        self.mid_x = int(len(margin_data_lane[0]) / 2)
        self.mid_y = int(len(margin_data_lane) / 2)

        north, south, east, west = self.mid_y, self.mid_y, self.mid_x, self.mid_x
        north_bad, south_bad, east_bad, west_bad = self.mid_y + 32, self.mid_y - 32, self.mid_x + 32, self.mid_x - 32

        print(f"North: {north} South: {south} North Bad: {north_bad} South Bad: {south_bad}")
        print(f"West: {west} East: {east} West Bad: {west_bad} East Bad: {east_bad}")

        print(f"Mid X: {self.mid_x} Mid Y: {self.mid_y}")

        for y in range(len(margin_data_lane)):
            east_bad, west_bad = self.mid_x + 32, self.mid_x - 32 # reset for each row, east / west kept at extremes
            for x in range(len(margin_data_lane[0])):
                data_point = int(margin_data_lane[y][x])
                # print(f"X: {x} Datapoint: {data_point} West Bad: {west_bad} East Bad: {east_bad} East: {east} West: {west}")
                if data_point <= self.threshold:
                    # Set the East / West values
                    west = x if (west_bad < x < west) else west
                    east = x if (east_bad > x > east) else east
                else:
                    west_bad = x if (self.mid_x > x > west_bad) else west_bad
                    east_bad = x if (self.mid_x < x < east_bad) else east_bad

        x = self.dclkb_lanes[dclk_index] - 8 # dclk assumes eye is shifted right by 8
        print("Grabbing Eye Height for 2D Column: {} with DCLKB Lanes: {} and Index: {} Length: {}".format(x, self.dclkb_lanes, dclk_index, len(margin_data_lane[0])))
        for y in range(len(margin_data_lane)):
            data_point = int(margin_data_lane[y][x])
            print(f"Data Point: {data_point}")

            # rt13_0_r0_atc_0_sfp_lane_1_north_ticks -> 49ticks
            # rt13_0_r0_atc_0_sfp_lane_1_south_ticks -> 15ticks

            if data_point <= self.threshold:
                # Set the North / South values
                south = y if (south > y > south_bad) else south
                north = y if (north < y < north_bad) else north
            else:
                south_bad = y if (self.mid_y > y > south_bad) else south_bad
                north_bad = y if (self.mid_y < y < north_bad) else north_bad

        print("Post Modification")
        print(f"North: {north} South: {south} North Bad: {north_bad} South Bad: {south_bad}")
        print(f"West: {west} East: {east} West Bad: {west_bad} East Bad: {east_bad}")

        return north, south, east, west

    def parse_limits_axis(self, margin_data_lane):
        # Iterate thru the coordinate Top Left to Bottom Right
        row_data = margin_data_lane[64:]
        column_data = margin_data_lane[:64]
        print("column data: {} row data: {}".format(column_data, row_data))

        self.mid_x = int(len(row_data) / 2)
        self.mid_y = int(len(column_data) / 2)
        north, south, east, west = self.mid_y, self.mid_y, self.mid_x, self.mid_x
        north_bad, south_bad, east_bad, west_bad = self.mid_y + 32, self.mid_y - 32, self.mid_x + 32, self.mid_x - 32

        print(f"North: {north} South: {south} North Bad: {north_bad} South Bad: {south_bad}")
        print(f"West: {west} East: {east} West Bad: {west_bad} East Bad: {east_bad}")

        for y in range(len(column_data)):
            data_point = int(column_data[y])
            if data_point <= self.threshold:
                # Set the North / South values
                south = y if (south > y > south_bad) else south
                north = y if (north < y < north_bad) else north
            else:
                south_bad = y if (self.mid_y > y > south_bad) else south_bad
                north_bad = y if (self.mid_y < y < north_bad) else north_bad

        for x in range(len(row_data)):
            data_point = int(row_data[x])
            if data_point <= self.threshold:
                # Set the East / West values
                west = x if (west_bad < x < west) else west
                east = x if (east_bad > x > east) else east
            else:
                west_bad = x if (self.mid_x > x > west_bad) else west_bad
                east_bad = x if (east_bad > x > self.mid_x) else east_bad

        print("Post Modification")
        print(f"North: {north} South: {south} North Bad: {north_bad} South Bad: {south_bad}")
        print(f"West: {west} East: {east} West Bad: {west_bad} East Bad: {east_bad}")

        return north, south, east, west


    def parse_margin_data(self, lane, phy_idx, margin_data_lane, port_value, port_index):
        """Parse data to the necessary format(s)"""
        print("Parse Margining Data Lane: {} Phy: {} PHY IDX: {} Axis Only: {}".format(lane, self.phy_count[phy_idx], phy_idx, self.axis_only))
        print(f"[Start Parse Margin Data] Time Progressed: {time.time() - self.start_time}")

        dclk_index = "Lane:{} Phy:{} ATC:{}".format(lane & 0x1, self.phy_count[phy_idx], self.port_list[port_index])
        print("DCLKB Lanes: {} DCLK Index: {}".format(self.dclkb_lanes, dclk_index))

        if self.axis_only == True:
            north, south, east, west = self.parse_limits_axis(margin_data_lane)
        else:
            north, south, east, west = self.parse_limits_2d(margin_data_lane, dclk_index)

        # Per Jongbae, we want to increase east and west ticks by 8
        east = east + 8
        west = west + 8
        self.mid_x = self.mid_x + 8
        print("Mid X: {} Mid Y: {}".format(self.mid_x, self.mid_y))

        if self.gen_version in ["CIO_GEN2", "CIO_GEN3"]:
            # https://seg-docs.csg.apple.com/projects/staten/release/UserManual/regs_a0/ACIO_TOP.html?baseaddr=0x501ac0000#acio_top_ACIO_TOP_ACIO_GLOBAL_CFG0
            print("Grabbing Bits: {} from: {} and value: {}".format(self.RP_OFFSET_ACIO[port_index], self.RP_OFFSET_ACIO, port_value))
            cio_gen_temp = int(self.get_bits(self.RP_OFFSET_ACIO[port_index] + 0xac0004, 0, 2)) # ACIO_TOP_ACIO_GLOBAL_CFG0 = 0xac0004 - 0x501ac0004
            if cio_gen_temp < 2:
                self.rounded_value.append("Rounded")
            else:
                self.rounded_value.append("NonRounded")

            self.cio_gen.append(int(cio_gen_temp))

            print("CIO Gen: {} from RP Offset ACIO: {} and Top ACIO Global CFGO: {} rounded_status: {} last ciogen: {}".format(
                cio_gen_temp, self.RP_OFFSET_ACIO[port_index], 0xac0004, self.rounded_value[-1], self.cio_gen[-1]))

            if self.cio_gen[-1] == 0:
                print("CIO Gen 0 found")
                self.TICK_TO_FREQUENCY = 10 ** 12 / (10 * 10 ** 9 * 64)
            elif self.cio_gen[-1] == 1:
                print("CIO Gen 1 found")
                self.TICK_TO_FREQUENCY = 10 ** 12 / (20 * 10 ** 9 * 64)
            elif self.cio_gen[-1] == 2:
                print("CIO Gen 2 found")
                self.TICK_TO_FREQUENCY = 10 ** 12 / (10.3125 * 10 ** 9 * 64)
            else:
                print("Default CIO Gen found")
                self.TICK_TO_FREQUENCY = 10 ** 12 / (20.625 * 10 ** 9 * 64)
        elif self.gen_version in ["USB_5G"]:
            self.TICK_TO_FREQUENCY = 10 ** 12 / (5 * 10 ** 9 * 64)
        elif self.gen_version in ["USB_10G"]:
            self.TICK_TO_FREQUENCY = 10 ** 12 / (10 * 10 ** 9 * 64)
        elif self.gen_version in ["DP_HBR2"]:
            self.TICK_TO_FREQUENCY = 10 ** 12 / (5.4 * 10 ** 9 * 64)
        elif self.gen_version in ["DP_HBR3"]:
            self.TICK_TO_FREQUENCY = 10 ** 12 / (8.1 * 10 ** 9 * 64)
        else:
            print("Default Bandwidth Found")
            self.TICK_TO_FREQUENCY = 10 ** 12 / (20.625 * 10 ** 9 * 64)

        height = north - south

        H0_RANGE_SCALE = 1.00

        print("north: {} south: {} east: {} west: {} height: {} TICK_TO_VOLTAGE: {} TICK_TO_FREQUENCY: {} mid_x: {} dclkb: {} dclk: {} scale: {}".format(
            north, south, east, west, height, self.TICK_TO_VOLTAGE, self.TICK_TO_FREQUENCY, self.mid_x, self.dclkb_lanes, self.dclk_lanes, H0_RANGE_SCALE
        ))

        eye_north_tick = north
        eye_south_tick = south
        eye_east_tick = east
        eye_west_tick = west
        eye_eh_mv = round((self.TICK_TO_VOLTAGE * H0_RANGE_SCALE * height), 4) # tick_voltage = 5.44
        eye_left_ew_ps = round((self.TICK_TO_FREQUENCY * (self.mid_x - west)), 4)
        eye_right_ew_ps = round((self.TICK_TO_FREQUENCY * (east - self.mid_x)), 4)

        # work around since only 2 physical lanes for DCLK_index but 4 lanes for HBR3 margining
        # lanes 0 and 2 for HBR use dclk index for physical lane 0 and 1 and 3 use DCLK index for physical lane 1

        eye_left_dclkb_ew_ps = round((self.TICK_TO_FREQUENCY * (self.dclkb_lanes[dclk_index] - west)), 4)
        eye_right_dclkb_ew_ps = round((self.TICK_TO_FREQUENCY * (east - self.dclkb_lanes[dclk_index])), 4)
        eye_left_dclk_ew_ps = round((self.TICK_TO_FREQUENCY * (self.dclk_lanes[dclk_index] - west)), 4)
        eye_right_dclk_ew_ps = round((self.TICK_TO_FREQUENCY * (east - self.dclk_lanes[dclk_index])), 4)
        eye_pk2pk_ew_ps = round((self.TICK_TO_FREQUENCY * (east - west)), 4)

        eye_leftright_min_ew_ps = min(eye_left_dclk_ew_ps, eye_right_dclk_ew_ps, eye_left_dclkb_ew_ps, eye_right_dclkb_ew_ps)

        eye_leftright_2x_min_ew_ps = 2 * eye_leftright_min_ew_ps
        self.share_output(port_value, lane, self.phy_count[phy_idx], eye_north_tick, eye_south_tick, eye_east_tick, eye_west_tick, eye_eh_mv, eye_pk2pk_ew_ps,
                          eye_left_ew_ps, eye_right_ew_ps, eye_leftright_min_ew_ps, eye_leftright_2x_min_ew_ps, eye_left_dclkb_ew_ps, eye_right_dclkb_ew_ps,
                          eye_left_dclk_ew_ps, eye_right_dclk_ew_ps)

        print(f"[End Parse Margin Data] Time Progressed: {time.time() - self.start_time}")


    def save_data_2d(self, port_value, port_index, lane, phy, phy_str, phy_idx):
        """Draw a CSV file to save data for a 2D eye"""
        print("Parsing Margin Data for port: {} lane: {} and phy: {}, phy_idx: {} length margin data: {}".format(port_value, lane, phy, phy_idx, len(self.margin_data)))
        f = open(self.log_path + "\eyemargin_atc_{}_{}_lane{}.csv".format(port_value, phy_str, lane), "w")
        for row in self.margin_data["Lane:{} Phy:{} ATC:{}".format(lane, phy, self.port_list[port_index])]:
            row_write = ""
            for value in row:
                row_write += "{},".format(value)
            f.write(row_write + '\n')
        f.close()


    def save_data_axis(self, port_value, port_index, lane, phy, phy_str, phy_idx):
        """Draw a CSV file to save data for axis margining"""
        print("Parsing Margin Data for port: {} lane: {} and phy: {} phy_idx: {} length margin data: {}".format(port_value, lane, phy, phy_idx, len(self.margin_data)))
        f = open(self.log_path + "\eyemargin_atc_{}_{}_lane{}.csv".format(port_value, phy_str, lane), "w")
        margin_data_lane = self.margin_data["Lane:{} Phy:{} ATC:{}".format(lane, phy, self.port_list[port_index])]
        row_data = margin_data_lane[64:]
        column_data = margin_data_lane[:64]
        for y in range(0, len(column_data)):
            row_write = ""
            if y != (len(column_data) / 2):
                for x in range(0, (len(column_data) / 2)):
                    row_write += " ," # pad so that the column for axis is in the middle
                row_write += "{},".format(column_data[y])
            else:
                for value in row_data:
                    row_write += "{},".format(value)

            f.write(row_write + '\n')

        f.close()


    def calculate_eye(self):
        """Parse data to the necessary format(s)"""
        print("Calculate Eye")
        print(f"[Start Calculate Eye] Time Progressed: {time.time() - self.start_time}")

        for port_index in range(0, len(self.port_list)):
            # Iterate through all ports
            for lane in self.lane_count:
                for phy_idx in range(0, len(self.phy_count)):
                    phy = self.phy_count[phy_idx]
                    port_value = int(self.port_list[port_index])
                    phy_str = "CFP" if int(phy) == 0 else "SFP"
                    if self.axis_only == False:
                        self.save_data_2d(port_value, port_index, lane, phy, phy_str, phy_idx)
                    else:
                        self.save_data_axis(port_value, port_index, lane, phy, phy_str, phy_idx)

                    self.current_lane = lane
                    self.select_lane(self.current_lane)
                    self.parse_margin_data(lane, phy_idx,
                                           self.margin_data["Lane:{} Phy:{} ATC:{}".format(lane, phy, self.port_list[port_index])],
                                           port_value, port_index)

        for i in range(0, len(self.present)):
            self.log_key(key="{}_{}_plug_present".format(self.type[i], self.port_list[i]), value=self.present[i],
                         units='ticks')
            self.log_key(key="{}_{}_plug_orientation".format(self.type[i], self.port_list[i]), value=self.orientation[i],
                         units='ticks')
            if self.gen_version in ["CIO_GEN2", "CIO_GEN3"]:
                self.log_key(key="{}_{}_cio_gen_register_ticks_{}".format(self.type[i], self.port_list[i], self.rounded_value[i]), value=self.cio_gen[i], units='ticks')

        print(f"[End Calculate Eye] Time Progressed: {time.time() - self.start_time}")


    #
    # Helpers
    #
    def progress(self):
        """Progress in integer % increments"""
        self.log_msg("   {}%".format(self._fake_progress))
        return self._fake_progress

    def is_running(self):
        """Check if Margining is running"""
        return self.progress < 100

    def all_lanes_scanned(self, lane):
        """Check if all lanes scanned, Used for tools that need to have individual lanes scanned"""
        if lane == self.LANE_COUNT:
            return 1
        else:
            self.log_msg("Didnt complete all lanes")

    def wait_for_finish(self):
        return 1

    def log_key(self, key, value, units, upperlimit=None, lowerlimit=None, register_file=False, retry=False, fom_key=None, endpoint_speed=None):
        super().log_key(key=key, value=value, units=units, upperlimit=upperlimit, lowerlimit=lowerlimit,
                        register_file=register_file, retry=retry, fom_key=fom_key, endpoint_speed=self.gen_version)
