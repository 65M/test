"""Access for iEFI"""
import sys
import logging
import time
from .base import AbstractReceiverMarginTool
from shell import run
from .soc_defines import *
from .i2c import *
import os
import re

__all__ = [
	"MarginTool"
]

seq_log = logging.getLogger("sequence")

class MarginTool(AbstractReceiverMarginTool):
	"""Margin Tool Instance"""
	I2C_AP_REGISTER_ADDRESS_AP_COMMUNICATOR_CONTROL = 0x2
	I2C_AP_REGISTER_ADDRESS_AP_COMMUNICATOR_DATA = 0x3
	RETIMER_PHY_EYE_COLUMN_COUNT = 64 # this is the number of columns not the max column, start_colum -> start_colum + 64

	RETIMER_PHY_EYE_MODE_COLUMN = 2
	RETIMER_PHY_EYE_MODE_AXIS = 1
	RETIMER_PHY_EYE_MODE_FULL = 0


	def write_phy_register(self, phy_address, bus, address, value):
		"""Write a PHY register value"""
		# AP write 4B of data into DATA register and then follow the same flow as "read phy" but use request_type = '5' to indicate write.
		print("Writing Phy Register: {} from bus: {} address: {} to value: {}".format(hex(phy_address), bus, address, value))
		# Value Format Should be 0x00000000 for 4B

		# Write 4B of data to the data register
		self.write_register_four_byte(bus, address, self.I2C_AP_REGISTER_ADDRESS_AP_COMMUNICATOR_DATA, value)

		print("Write Control Register w/ Request Type 5 - which is shifted 2 bytes")
		self.write_register(bus, address, self.I2C_AP_REGISTER_ADDRESS_AP_COMMUNICATOR_CONTROL, phy_address, 5 << 2)

		output = self.grab_register_output(bus, address, 5)
		if output is None:
			print("write_phy_register returned no output")
			output = ""
		print(f"phy_register_output={output}")
		# Note: For grabbing output, we skip the first 2 *results* because the parsing has an empty bit and the first byte from devread is # bytes read.
		for line in output.split("\n"):
			if "Data:" in line:
				output = (line.split("Data:")[-1].replace(" 0x", "")).split(" ")
				output = "{}{}{}{}".format(output[5], output[4], output[3], output[2])
				output = int(output, 16)

		try:
			print(f"Register Output Post Write: {hex(output)}")
		except Exception:
			print(f"Register Output Post Write: {output}")

		return output


	def write_overwrite_register(self, phy_address, bus, address, value):
		"""Write a PHY register value (Overwrite) """
		print("Writing Phy Register: {} from bus: {} address: {} to value: {}".format(hex(phy_address), bus, address, value))
		# Value Format Should be 0x00000000 for 4B

		# Write 4B of data to the data register
		self.write_register(bus, address, self.I2C_AP_REGISTER_ADDRESS_AP_COMMUNICATOR_DATA, value, phy_address)

		print("Write Control Register w/ Request Type 6 - which is shifted 2 bytes + 1 for data ready = 1")
		self.write_register(bus, address, self.I2C_AP_REGISTER_ADDRESS_AP_COMMUNICATOR_CONTROL, phy_address, 0x00000018)

		cmnd_active = 1
		while cmnd_active:
			print("CMND Active")
			read_data = self.read_register(bus, address, self.I2C_AP_REGISTER_ADDRESS_AP_COMMUNICATOR_CONTROL, 9)
			data_ready, cmnd_active, active_request, request_result, num_bytes_to_send, num_bytes_sent = self.parse_read_register(read_data)
			time.sleep(1)

		return True


	def grab_register_output(self, bus, address, data_length):
		"""Grab register output for given phy register"""
		data_ready = 0
		max_timeout = 60
		current_time = 0
		fast_poll = 0
		while not data_ready:
			read_data = self.read_register(bus, address, self.I2C_AP_REGISTER_ADDRESS_AP_COMMUNICATOR_CONTROL, 9)
			data_ready, cmnd_active, active_request, request_result, num_bytes_to_send, num_bytes_sent = self.parse_read_register(
				read_data)

			if data_ready and request_result == 0:
				output = self.read_register(bus, address, self.I2C_AP_REGISTER_ADDRESS_AP_COMMUNICATOR_DATA, data_length)
				return output
			elif request_result == 5:
				print("Invalid Request Result (5) - Did you try to write a PHY register on a prod unit?")
			else:
				if fast_poll < 15:
					fast_poll = fast_poll + 1
				else:
					time.sleep(1)

			current_time = current_time + 1
			if current_time > max_timeout:
				print("Data Not Ready Post Timeout")
				raise Exception("Data Not Ready Post Timeout")


	def initialize_original_eyescan(self, bus, address):
		print("Initialize Original Eyescan, Write Data 0x2")
		self.write_register(bus, address, self.I2C_AP_REGISTER_ADDRESS_AP_COMMUNICATOR_DATA, 0x00000000, 0x00000002)
		print("Initialize Original Eyescan, Write Control 0x20")
		self.write_register(bus, address, self.I2C_AP_REGISTER_ADDRESS_AP_COMMUNICATOR_CONTROL, 0x00000000, 0x00000020)
		print("Done Initialization")


	def read_phy_register(self, phy_address, bus, address):
		"""Read a PHY Register"""
		print("Reading PHY Register: {} from bus: {} address: {}".format(hex(phy_address), bus, address))

		# Request Type 8 = 2 << 2
		self.write_register(bus, address, self.I2C_AP_REGISTER_ADDRESS_AP_COMMUNICATOR_CONTROL, phy_address,
							0x00000008)

		output = self.grab_register_output(bus, address, 5)
		if output is None:
			print("read_phy_register returned no output")
			output = ""
		print(f"phy_register_output={output}")
		# Note: For grabbing output, we skip the first 2 *results* because the parsing has an empty bit and the first byte from devread is # bytes read.
		for line in output.split("\n"):
			if "Data:" in line:
				output = (line.split("Data:")[-1].replace(" 0x", "")).split(" ")
				output = "{}{}{}{}".format(output[5], output[4], output[3], output[2])
				output = int(output, 16)
		return output


	def read_txffe_values(self, bus, address, lane, port):
		write_data_dword1, write_data_dword0 = self.package_write_register_txffe(lane, port)
		print("TFFE Values Sending: {} {}".format(write_data_dword1,  write_data_dword0))
		self.write_register(bus, address, self.I2C_AP_REGISTER_ADDRESS_AP_COMMUNICATOR_CONTROL, write_data_dword1, write_data_dword0)

		output = self.grab_register_output(bus, address, 6)
		if output is None:
			print("Grab_regsiter_output returned no output")
			output = ""
		# Note: For grabbing output, we skip the first 2 *results* because the parsing has an empty bit and the first byte from devread is # bytes read.
		for line in output.split("\n"):
			if "Data:" in line:
				output = (line.split("Data:")[-1].replace(" 0x", "")).split(" ")
				output = "{}{}{}{}{}".format(output[6], output[5], output[4], output[3], output[2])
				output = int(output, 16)
		read_output = output

		print("TFFE Value Output: {} for bus: {} address: {} lane:  {} port: {}".format(read_output, bus, address, lane, port))
		return read_output



	def get_bits(self, address, start_bit, length):
		"""Read register from start_bit and length"""
		hex_address = hex(address)
		print("Getting bits from address: {}".format(hex_address))
		mm_data = run("mm -w 4 -n {}".format(hex_address))
		if "MEM" in mm_data:
			a = mm_data.split(": ")
			reg_val = a[1].strip("\r\n")
			bin_val = '{:>032}'.format(bin(int(reg_val, 16))[2:])
			end_pos = 31 - start_bit + 1
			start_pos = 31 - start_bit - length + 1
			bits = int(bin_val[start_pos:end_pos], 2)
			print("Get Bits Output: {}".format(bits))
			return bits
		else:
			raise Exception("Get bits failed")


	def write_register_four_byte(self, bus, address, register, write_data_dword0):
		"""Write an i2c register"""
		# Write a given I2C register (expect 64-bits)
		#   --devwrite  [-v] <Bus> <Addr> <Reg> <data0 data1...> [multiple] :
		#                   Write register data
		# length / dword0 - byte0 / dword0 - byte1 / dword0 byte2 / dword0 - byte3 / dword1 - byte 0 / dword1 - byte1 / dword2 - byte2 / dword1 - byte3

		length = 4  # we always write 8 bytes for this code

		dword0_byte0 = (write_data_dword0 & 0xFF)
		dword0_byte1 = (write_data_dword0 >> 8) & 0xFF
		dword0_byte2 = (write_data_dword0 >> 16) & 0xFF
		dword0_byte3 = (write_data_dword0 >> 24) & 0xFF

		print("command i2c --devwrite {} {} {} {} {} {} {} {} multiple".format(
			bus, hex(address), hex(register), hex(length), hex(dword0_byte0), hex(dword0_byte1), hex(dword0_byte2),
			hex(dword0_byte3)))

		write_command = run("i2c --devwrite {} {} {} {} {} {} {} {} multiple".format(
			bus, hex(address), hex(register), hex(length), hex(dword0_byte0), hex(dword0_byte1), hex(dword0_byte2),
			hex(dword0_byte3)))

		# write_command = i2c_run(devwrite=[bus, hex(address), hex(register), hex(length), hex(dword0_byte0), hex(dword0_byte1), hex(dword0_byte2),
		# 	hex(dword0_byte3),
		# 	hex(dword1_byte0), hex(dword1_byte1), hex(dword1_byte2), hex(dword1_byte3)])
		return write_command


	def write_register(self, bus, address, register, write_data_dword1, write_data_dword0):
		"""Write an i2c register"""
		# Write a given I2C register (expect 64-bits)
		#   --devwrite  [-v] <Bus> <Addr> <Reg> <data0 data1...> [multiple] :
		#                   Write register data
		# length / dword0 - byte0 / dword0 - byte1 / dword0 byte2 / dword0 - byte3 / dword1 - byte 0 / dword1 - byte1 / dword2 - byte2 / dword1 - byte3

		length = 8  # we always write 8 bytes for this code

		dword0_byte0 = (write_data_dword0 & 0xFF)
		dword0_byte1 = (write_data_dword0 >> 8) & 0xFF
		dword0_byte2 = (write_data_dword0 >> 16) & 0xFF
		dword0_byte3 = (write_data_dword0 >> 24) & 0xFF
		dword1_byte0 = write_data_dword1 & 0xFF
		dword1_byte1 = (write_data_dword1 >> 8) & 0xFF
		dword1_byte2 = (write_data_dword1 >> 16) & 0xFF
		dword1_byte3 = (write_data_dword1 >> 24) & 0xFF

		print("command i2c --devwrite {} {} {} {} {} {} {} {} {} {} {} {} multiple".format(
			bus, hex(address), hex(register), hex(length), hex(dword0_byte0), hex(dword0_byte1), hex(dword0_byte2),
			hex(dword0_byte3),
			hex(dword1_byte0), hex(dword1_byte1), hex(dword1_byte2), hex(dword1_byte3)))

		write_command = run("i2c --devwrite {} {} {} {} {} {} {} {} {} {} {} {} multiple".format(
			bus, hex(address), hex(register), hex(length), hex(dword0_byte0), hex(dword0_byte1), hex(dword0_byte2),
			hex(dword0_byte3),
			hex(dword1_byte0), hex(dword1_byte1), hex(dword1_byte2), hex(dword1_byte3)))

		# write_command = i2c_run(devwrite=[bus, hex(address), hex(register), hex(length), hex(dword0_byte0), hex(dword0_byte1), hex(dword0_byte2),
		# 	hex(dword0_byte3),
		# 	hex(dword1_byte0), hex(dword1_byte1), hex(dword1_byte2), hex(dword1_byte3)])
		return write_command


	def read_register(self, bus, address, register, length):
		"""Read an i2c register"""
		# Read a given I2C register (expect 32-bits)
		#   --devread   [-d] <Bus> <Addr> <Reg> <Len> [multiple] :
		#                   Read register data
		print("command i2c --devread {} {} {} {} multiple".format(bus, hex(address), hex(register), length))
		# read_command = i2c_run(devread=[bus,hex(address),hex(register),length])
		read_command = run("i2c --devread {} {} {} {} multiple".format(bus, hex(address), hex(register), length))
		return read_command


	def grab_ace_output(self, atc_port, type):
		# PlugOrientation will tell you the orientation, but it's only valid if PlugPresent is set, so I'd recommend checking both
		# Plug present Bit 0, Plug Orientation Bit 4
		if type in ["USBC","usbc"]:
			run("ace --pick {}".format(type))
		else:
			run("ace --pick {}{}".format(type, atc_port))
		ace_1a_output = run("ace --read 0x1A")
		for line in ace_1a_output.split("\n"):
			if ": " in line:
				print("Line: {}".format(line))
				print("Split bytes: {}".format((line.split(": ")[-1]).split(" ")[0]))
				ace_output = int("0x" + (line.split(": ")[-1]).split(" ")[0], 16) & 0xFF
				print("Ace Output: {}".format(ace_output))
				return ace_output

		raise Exception("Unable to grab ACE register")

	def plug_orientation(self, atc_port, type):
		"""Grab the plug orientation"""
		print("Grab Plug Orientation for {}: {}".format(type, atc_port))
		return ((self.grab_ace_output(atc_port, type)) >> 4) & 0x1


	def plug_present(self, atc_port, type):
		"""Grab whether or not the plug is present, based on ace training for the device index, needs to be done first"""
		# PlugOrientation will tell you the orientation, but it's only valid if PlugPresent is set, so I'd recommend checking both
		# Plug present Bit 0, Plug Orientation Bit 4
		print("Grab Plug Present for {}: {}".format(type, atc_port))
		return (self.grab_ace_output(atc_port, type)) & 0x1


	def package_write_register_txffe(self, lane, port):
		"""
		Control Register write from AP payload formats: AP_COMM_REQUEST_TYPE_READ_TXFFE</span><span class="pln">

		|   63 ... 36 |   35 ... 34 |   33 ... 32 |   31 ... 10 |   9 ... 2      |         1           |        0       |
		|       28    |       2     |       2     |       22    |       8       |         1           |        1       |
		|   reserved  |     lane    |     port    |   reserved  |  request_type | request_abort_prev  | data_ready_ack |

		data_ready_ack = always "0"
		request_abort_prev - set to "1" if it wants to abort any active request, otherwise set to "0" (which will return error result if the Retimer is serving another request at the moment).
		request_type - "3" for read txffe.
		port - "0" for SFP (router facing), "1" for CFP (cable facing)
		lane - "0" for primary, "1" for subordinate

		"""
		write_data_dword1 = 0x00000000  # 8x = 32 bits
		write_data_dword1 = write_data_dword1 | (port)  # set port to bit 0-1
		write_data_dword1 = write_data_dword1 | (lane << 2)  # set lane to bit 2-3

		write_data_dword0 = 0x00000000  # 8x = 32 bits
		write_data_dword0 = write_data_dword0 | 0  # set data_ready_ack to bit 0
		write_data_dword0 = write_data_dword0 | (0 << 1)  # set request_abort_prev to bit 1
		write_data_dword0 = write_data_dword0 | (3 << 2)  # request_type - "3" for read txffe.

		return write_data_dword1, write_data_dword0


	def package_write_register(self, phy_id, lane, depth, column, margin_mode, pma=0, speed=0):
		# Package Write Register, Request Type 1 = Eye Scan
		"""
        // dword 0
        uint32_t data_ready_ack     : 1;  // [0] rw field. Do not change its layout
        uint32_t request_abort_prev : 1;  // [1]
        uint32_t request_type       : 8;  // [9:2] ap_communicator_request_type_t - ctrl_w.request_type = AP_COMMUNICATOR_REQUEST_TYPE_EYE_SCAN;
        uint32_t                    : 22; // [31:10]

        // dword 1
        struct {
            uint32_t phy            : 1;  // [0] - ctrl_w.eye_scan.phy = phy_id;
            uint32_t lane           : 1;  // [1] - ctrl_w.eye_scan.lane = lane;
            uint32_t pma            : 1;  // [2] - ctrl_w.eye_scan.pma = 0;
            uint32_t depth          : 3;  // [5:3] # - ctrl_w.eye_scan.depth = depth;
            uint32_t speed          : 2;  // [7:6] # default 0
            uint32_t mode           : 2;  // [9:8] - ctrl_w.eye_scan.mode = RETIMER_PHY_EYE_MODE_COLUMN;
            uint32_t column         : 8;  // [17:10] - ctrl_w.eye_scan.column = column;
            uint32_t                : 14; // [31:18]
        } eye_scan;
        """

		# length / dword0 - byte0 / dword0 - byte1 / dword0 byte2 / dword0 - byte3 / dword1 - byte 0 / dword1 - byte1 / dword2 - byte2 / dword1 - byte3
		# depth = 1, column = 1, speed = CIO 10g request type = 08 04 00 00 00 08 06 00 00

		# Handle that 4 lanes breaks into different lane / PMA bits
		print("Lane Count: {} Lane: {} PMA: {}".format(self.lane_count, lane, pma))
		if len(self.lane_count) == 4:
			# Lane 0 - ACIOPHY_RT_LANE[0], AUSPMA[0]
			# Lane 1 - ACIOPHY_RT_LANE[0], AUSPMA[1]
			# Lane 2 - ACIOPHY_RT_LANE[1], AUSPMA[0]
			# Lane 3 - ACIOPHY_RT_LANE[1], AUSPMA[1]
			# Lane 0 = lane 0, pma 0
			# Lane 1 = lane 0, pma 1
			# Lane 2 = lane 1, pma 0
			# Lane 3 = lane 1, pma 1
			lane = int(lane / 2)
			pma = lane % 2

		print("Lane Count: {} Lane: {} PMA: {}".format(self.lane_count, lane, pma))
		write_data_dword1 = 0x00000000  # 8x = 32 bits
		write_data_dword1 = write_data_dword1 | phy_id  # set phy_id to bit 0


		# Set PMA before lane bit to enable using PMA & lane bit for HBR3 lanes
		# (i.e. lane can actually be value 3 and set PMA even though it's technically 1 bit)
		write_data_dword1 = write_data_dword1 | (pma << 2)  # set pma to bit 2
		write_data_dword1 = write_data_dword1 | (lane << 1)  # set lane to bit 1

		write_data_dword1 = write_data_dword1 | (int(depth) << 3)  # set depth to bits 3-5
		write_data_dword1 = write_data_dword1 | (speed << 6)  # set depth to bits 6-7
		write_data_dword1 = write_data_dword1 | (margin_mode << 8)  # set depth to bits 8-9
		write_data_dword1 = write_data_dword1 | (column << 10)  # set depth to bits 10-17

		write_data_dword0 = 0x00000000  # 8x = 32 bits
		write_data_dword0 = write_data_dword0 | 0  # set data_ready_ack to bit 0
		write_data_dword0 = write_data_dword0 | (0 << 1)  # set request_abort_prev to bit 1
		write_data_dword0 = write_data_dword0 | (1 << 2)  # set request_type to bit 2-0 # AP_COMMUNICATOR_REQUEST_TYPE_EYE_SCAN

		print("Packaged Write Register with PHY ID: {} Lane: {} PMA: {} DEPTH: {} SPEED: {} MARGIN MODE: {} COLUMN: {} to get DWORD1: {} DWORD0: {}".format(
			phy_id, lane, pma, depth, speed, margin_mode, column, hex(write_data_dword1), hex(write_data_dword0)
		))
		return write_data_dword1, write_data_dword0


	def package_abort_previous(self):
		# Package just the abort previous register if a previous command is running unexpectedly

		write_data_dword1 = 0x00000000  # 8x = 32 bits

		write_data_dword0 = 0x00000000  # 8x = 32 bits
		write_data_dword0 = write_data_dword0 | (0 << 1)  # set request_abort_prev to bit 1

		return write_data_dword1, write_data_dword0


	def parse_read_register_data(self, output):
		"""Parse data read register, 65 bytes for a full read"""
		column_data = []
		# Note: For grabbing output, we skip the first 2 *results* because the parsing has an empty bit and the first byte from devread is # bytes read.
		for line in output.split("\n"):
			if "Data:" in line:
				output = (line.split("Data:")[-1].replace(" 0x", "")).split(" ")
				output = [x.rstrip() for x in output]
				output = [x for x in output if x]
				for item in output:
					column_data.append(item)

		column_data = column_data[1:] # skip 0th byte because it's length
		return column_data


	def parse_read_register(self, output):
		"""Parse read register, 8 bytes"""
		"""
        typedef struct {
            uint64_t data_ready        : 1;  // [0] rw field. Do not change its layout
            uint64_t cmnd_active       : 1;  // [1] rw field. Do not change its layout
            uint64_t active_request    : 8;  // [9:2] ap_communicator_request_result_t
            uint64_t request_result    : 3;  // [12:10] ap_communicator_request_result_t
            uint64_t num_bytes_to_send : 16; // [28:13]
            uint64_t num_bytes_sent    : 16; // [44:29]
            uint64_t                   : 19; // [63:45]
        } i2c_ap_register_ap_communicator_control_read_t;
        """
		# Note: For grabbing output, we skip the first 2 *results* because the parsing has an empty bit and the first byte from devread is # bytes read.
		for line in output.split("\n"):
			if "Data:" in line:
				output = (line.split("Data:")[-1].replace(" 0x", "")).split(" ")
				output = "{}{}{}{}{}{}{}{}".format(output[9], output[8], output[7], output[6], output[5], output[4],
												   output[3], output[2])
				output = int(output, 16)

		data_ready = int(output & 0x1)  # bit 0
		cmnd_active = int((output >> 1) & 0x1)  # bit 1
		active_request = int((output >> 2) & 0xFF)  # bit 2-9 - 8 bits
		request_result = int((output >> 10) & 0x7)  # bit 10 - 12 - 3 bits
		num_bytes_to_send = int((output >> 13) & 0xFFFF)  # bit 13 - 28 - 16 bits
		num_bytes_sent = int((output >> 29) & 0xFFFF)  # bit 29 - 44 - 16 bits

		return data_ready, cmnd_active, active_request, request_result, num_bytes_to_send, num_bytes_sent


	def return_read_error(self, output, string):
		"""Check for an error in a register read"""
		if output:
			print("Read Error Register Failed: {} with Output: {}".format(string, output))
		else:
			print("No Error For Read Task: {}".format(string))


	def return_write_error(self, output, string):
		"""Check for an error in a register write"""
		if output:
			print("Write Error Register Failed: {} with Output: {}".format(string, output))
		else:
			print("No Error For Write Task: {}".format(string))


	def run_sleep_time(self, depth):
		"""Calculate the sleep time and sleep for the appropriate amount of time"""
		# Sleep time based on run-times for depth, only sleep on first iteration
		if depth <= 4:
			sleep_time = 0
		elif depth == 5:
			sleep_time = 8
		else:
			if self.axis_only == True:
				sleep_time = 2 * ((7 * (10 ** (depth - 5))) + 15)
			else:
				sleep_time = (7 * (10 ** (depth - 5))) + 15
		print("Due to Depth: {}, sleeping: {} for column margining.".format(depth, sleep_time))
		time.sleep(int(sleep_time))


	def ber_speed_modify(self, data_value, gen_version, depth):
		"""Modify the data based on the passed in gen speed"""
		# wait_time_us = (uint32_t)10 *  (uint32_t)power(10, curr_depth);
		# UIs = wait_time / speed_multiplier (PS)
		speed_multiplier = 0
		if gen_version == "CIO_GEN2" or gen_version == "USB_10G":
			speed_multiplier = 100
		elif gen_version == "CIO_GEN3":
			# 20 gigabit link = 50 ps per data point (# data points = wait time / time per point)
			speed_multiplier = 50
		elif gen_version == "USB_5G":
			speed_multiplier = 200
		elif gen_version == "DP_RBR":
			speed_multiplier = 617
		elif gen_version == "DP_HBR":
			speed_multiplier = 370.3
		elif gen_version == "DP_HBR2":
			speed_multiplier = 185.1
		elif gen_version == "DP_HBR3":
			speed_multiplier = 123.5

		time_us = [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000]

		data_value = int(("0x" + data_value), 16)
		data_value_new = (data_value / (time_us[depth] * speed_multiplier)) * (1000 * 1000) # Ber Adjustment = 1000 * 1000
		return 1 if 0 < data_value_new < 1 else int(data_value_new) # Don't let non-zero errors be rounded to 0


	def grab_data_chunk(self, bus, address, depth):
		"""Grab a full data chunk of 65 bytes of data, including polling, and then packaging and modifying it appropriately"""
		data_ready = 0
		max_timeout = 60
		current_time = 0

		data_chunk = []
		cmnd_active = 1
		fast_poll = 0
		while not data_ready:
			print("Check for Data Ready")
			read_data = self.read_register(bus, address, self.I2C_AP_REGISTER_ADDRESS_AP_COMMUNICATOR_CONTROL, 9)
			data_ready, cmnd_active, active_request, request_result, num_bytes_to_send, num_bytes_sent = self.parse_read_register(
				read_data)

			if data_ready and request_result == 0:
				print("Found Data Ready, Grab Full Data")
				output = self.read_register(bus, address, self.I2C_AP_REGISTER_ADDRESS_AP_COMMUNICATOR_DATA, 65)
				column_parsed = self.parse_read_register_data(output)
				for value in range(0, len(column_parsed) / 2):
					combined_value = column_parsed[((2*value)+1)] + column_parsed[(2*value)]
					combined_value = self.ber_speed_modify(combined_value, self.gen_version, depth)
					data_chunk.append(combined_value)
			elif request_result == 5:
				print("Request Result = 5, Did you Try to Write a PHY Register?")
			else:
				print("Found Data Not Ready, Fast_Poll: {}".format(fast_poll))
				if fast_poll < 30:
					fast_poll = fast_poll + 1
				else:
					fast_poll = 0
					time.sleep(0.1)
					current_time = current_time + 0.1

			if current_time > max_timeout:
				print("Data Not Ready Post Timeout")
				raise Exception("Data Not Ready Post Timeout")

		return data_chunk, cmnd_active


	def verify_command_status(self, bus, address, phy_id, lane, depth, column, pma=0, speed=0):
		"""Verify if a command is running to determine whether margining can be kicked off"""
		# 0th byte is length of payload that follows, we want 9 bytes
		print("Starting Verify Command Status")
		read_data = self.read_register(bus, address, self.I2C_AP_REGISTER_ADDRESS_AP_COMMUNICATOR_CONTROL, 9)
		data_ready, cmnd_active, active_request, request_result, num_bytes_to_send, num_bytes_sent = self.parse_read_register(
			read_data)

		# putting this before error handling to get logs of values passed in
		print("Grab Bytes to Write")
		if self.axis_only == True:
			write_data_dword1, write_data_dword0 = self.package_write_register(phy_id, lane, depth, column,
																			   self.RETIMER_PHY_EYE_MODE_AXIS, pma,
																			   speed)
		else:
			write_data_dword1, write_data_dword0 = self.package_write_register(phy_id, lane, depth, column,
																			   self.RETIMER_PHY_EYE_MODE_COLUMN, pma, speed)


		if cmnd_active:
			print("Command Active reading again")
			read_data = self.read_register(bus, address, self.I2C_AP_REGISTER_ADDRESS_AP_COMMUNICATOR_CONTROL, 9)
			data_ready, cmnd_active, active_request, request_result, num_bytes_to_send, num_bytes_sent = self.parse_read_register(
				read_data)

			if cmnd_active:
				print("Command Active in Verify Command Status, Trying Abort")
				write_data_abort_dword1, write_data_abortd_dword0 = self.package_abort_previous()
				self.write_register(bus, address, self.I2C_AP_REGISTER_ADDRESS_AP_COMMUNICATOR_CONTROL,
									write_data_abort_dword1, write_data_abortd_dword0)

				time.sleep(1)
				read_data = self.read_register(bus, address, self.I2C_AP_REGISTER_ADDRESS_AP_COMMUNICATOR_CONTROL, 9)
				data_ready, cmnd_active, active_request, request_result, num_bytes_to_send, num_bytes_sent = self.parse_read_register(
					read_data)

				if cmnd_active:
					print("Another Command is Currently Active")
					raise Exception("Margin Column Failed, Another Command is Currently Active")
				else:
					print("Found Active Command, Aborted and Slept, No Longer An Issue")
			else:
				print("Command Active reading again sufficed")

		return data_ready, cmnd_active, active_request, request_result, num_bytes_to_send, num_bytes_sent, write_data_dword1, write_data_dword0

	def margin_axis(self, bus, address, phy_id, lane, depth, column, pma=0, speed=0):
		"""Margin a given column based on passed in parameters"""
		write_data_dword1 = []
		write_data_dword0 = []
		for i in range(0, len(bus)):
			data_ready, cmnd_active, active_request, request_result, num_bytes_to_send, num_bytes_sent, write_data_dword1_temp, write_data_dword0_temp = self.verify_command_status(
				bus[i], self.address[i], phy_id, lane, depth, column, pma, speed)
			write_data_dword1.append(write_data_dword1_temp)
			write_data_dword0.append(write_data_dword0_temp)

			print("Kicking off Axis Margining on bus: {} and address: {} for port: {}".format(bus[i], self.address[i],self.port_list[i]))

			self.write_register(bus[i], self.address[i], self.I2C_AP_REGISTER_ADDRESS_AP_COMMUNICATOR_CONTROL,
								write_data_dword1[i], write_data_dword0[i])

		self.run_sleep_time(depth)

		axis_data = []
		for port in range(0, len(bus)):
			axis_data_single_port = []
			i, cmnd_active = 0, 1
			# The write command either kicks off margining (the first time), or sends the next chunk of data (subsequent times)
			while cmnd_active:
				if i == 1:
					self.write_register(bus[port], address[port], self.I2C_AP_REGISTER_ADDRESS_AP_COMMUNICATOR_CONTROL,
											write_data_dword1[port], write_data_dword0[port])
				data_chunk, cmnd_active = self.grab_data_chunk(bus[port], address[port], depth)
				for data in data_chunk:
					axis_data_single_port.append(data)
				i = 1

			axis_data.append(axis_data_single_port)

		return axis_data


	def margin_column(self, bus, address, phy_id, lane, depth, column, pma=0, speed=0):
		"""Margin a given column based on passed in parameters"""
		"""
		Parallel Margining Strategy:
		
		1. Move initial command kick-off out of while loop.
		2. Convert variables to an array with that variable name as a key, value pair for each bus address
		3. Fill that array with initial values, and kick off command for that array
		4. While a command active in that array have a similar index column_data array and return that
		5. In the overall margining command grab by index.
		6. This progresses at the path of the slowest column (i.e. 1x column takes 5 seconds and the other 50 seconds the overall code
		will take 50 seconds * 64 columns rather than finishing the first one first).  
		
		"""
		print("Column: {} Start Margining, Lane: {} Phy: {}".format(column, lane, phy_id))
		write_data_dword1 = []
		write_data_dword0 = []
		for i in range(0, len(bus)):
			data_ready, cmnd_active, active_request, request_result, num_bytes_to_send, num_bytes_sent, write_data_dword1_temp, write_data_dword0_temp = self.verify_command_status(
					bus[i], self.address[i], phy_id, lane, depth, column, pma, speed)
			write_data_dword1.append(write_data_dword1_temp)
			write_data_dword0.append(write_data_dword0_temp)

			print("Kicking off Column Margining on bus: {} and address: {} for port: {}".format(bus[i], self.address[i], self.port_list[i]))

			self.write_register(bus[i], self.address[i], self.I2C_AP_REGISTER_ADDRESS_AP_COMMUNICATOR_CONTROL,
									write_data_dword1[i], write_data_dword0[i])

		self.run_sleep_time(depth)

		column_data = []
		for port in range(0, len(bus)):
			column_data_single_port = []
			i, cmnd_active = 0, 1
			# The write command either kicks off margining (the first time), or sends the next chunk of data (subsequent times)
			while cmnd_active:
				if i == 1:
					print("Send next chunk of data")
					self.write_register(bus[port], address[port], self.I2C_AP_REGISTER_ADDRESS_AP_COMMUNICATOR_CONTROL,
											write_data_dword1[port], write_data_dword0[port])
				else:
					print("Skip, first time, margining already kicked off")
				data_chunk, cmnd_active = self.grab_data_chunk(bus[port], address[port], depth)
				for data in data_chunk:
					column_data_single_port.append(data)
				i = 1

			print("Column: {} Margined, Lane: {} Phy: {} with Data Length: {} and Bus: {} Port: {}".format(column, lane, phy_id, len(column_data_single_port), bus[port], self.port_list[port]))

			column_data.append(column_data_single_port)

		return column_data


	def axis_margin(self, bus, address, phy_id, lane, depth, pma=0, speed=0):
		"""Margin along the Axis"""
		print("Axis Eye Margin")
		return self.margin_axis(bus, address, phy_id, lane, depth, 0, pma, speed)


	def multidimensional_eye_margin(self, bus, address, phy_id, lane, depth, pma=0, speed=0):
		"""Multidimensional Eye Margining, Full Margining"""
		print("Multidimensional Eye Margin")
		multidimensional_eye = []
		start_column = 0
		for column in range(start_column, (start_column + self.RETIMER_PHY_EYE_COLUMN_COUNT)):
			column_data = self.margin_column(bus, address, phy_id, lane, depth, column, pma, speed)
			if column == start_column:
				for port in range(0, len(bus)):
					multidimensional_eye.append([])
					multidimensional_eye[port].append(column_data[port])
			else:
				for port in range(0, len(bus)):
					multidimensional_eye[port].append(column_data[port])

		organized_eye = []
		for port in range(0, len(bus)):
			# Turn this data into an organized eye (columns by width)
			organized_eye.append([])
			organized_eye[port] = [[0] * len(multidimensional_eye[port]) for i in range(len(multidimensional_eye[port][0]))]
			for column in range(0, len(multidimensional_eye[port])):
				for row in range(0, len(multidimensional_eye[port][0])):
					organized_eye[port][row][column] = multidimensional_eye[port][column][row]

		return organized_eye


	def ensure_link(self):
		"""Ensure Link Validity"""
		# Grab the passed in speed and verify that if possible?
		print("Inside Ensure Link")
		for i in self.bus:
			try:
				print("Running Bus{} Sweep".format(i))
				run("i2c -s {}".format(i))
			except Exception:
				continue
		print("Done Bus Sweep")
		"""
            [00064948:1A80011E] :-) i2c -s 2
            Sweeping bus 2
            Bus 2 IC exists at Address: (7-bit) 0x18 (8-bit) 0x30
            Bus 2 IC exists at Address: (7-bit) 0x19 (8-bit) 0x32
            Bus 2 IC exists at Address: (7-bit) 0x78 (8-bit) 0xF0
        """

	def grab_fw_version(self, bus, address):
		print("Reading FW Status")
		read_command_one = run("i2c --devread {} {} {} {} multiple".format(bus, hex(address), 0xA, 0x41))
		read_command_two = run("i2c --devread {} {} {} {} multiple".format(bus, hex(address), 0xB, 0x41))

		output_str = ""
		for line in read_command_one.split("\n"):
			if "Data:" in line:
				group_data = line.split("  ")[1:]
				print("Group Data: {}".format(group_data))
				for data in group_data:
					if data != '':
						output_str += chr(int(data, 16))

		for line in read_command_two.split("\n"):
			if "Data:" in line:
				group_data = line.split("  ")[1:]
				print("Group Data: {}".format(group_data))
				for data in group_data:
					if data != '':
						output_str += chr(int(data, 16))

		# self.log_key(key="bus_{}_fw_version".format(bus),
		# 			 value=output_str,
		# 			 units='ticks')
		if "AppleRetimerTypeCFirmware" in output_str:
			print("Found Type C FW")
			fw_version = (output_str.split("@AppleRetimerTypeCFirmware-")[-1]).split("~")[0]
		elif "atcrt-fw-" in output_str:
			print("Found ATCRT FW")
			fw_version = (output_str.split("atcrt-fw-")[-1]).split("_")[0]
		else:
			print("No Match Found")
			fw_version = output_str[:40]

		print(f"FW Version: {output_str}")
		print(f"Parsed FW Version: {fw_version}")

		# Limit the FW to 40 char no matter what for PDCA issues
		fw_version = fw_version[:40]

		self.log_key(key="rt13_fw_{}".format(fw_version), value=0, units='ticks')


	def grab_tffe_values(self, port, lane, phy_id, phy_str):
		"""Grab TFFE Values"""
		# Normal margining has CFP = 0, SFP = 1, but TXFFE has SFP = 0, CFP = 1.
		if phy_str is "CFP":
			phy_id = 1
		else:
			phy_id = 0

		txffe_value = int(self.read_txffe_values(self.bus[port], self.address[port], lane, phy_id))
		# TX = local, RX = remote
		txffe_local_valid = int((txffe_value & 0xFF00000000) >> 32)
		txffe_local_preset = int((txffe_value & 0x00FF000000) >> 24)
		txffe_remote_fom = int((txffe_value & 0x0000FF0000) >> 16)
		txffe_remote_preset = int((txffe_value & 0x000000FF00) >> 8)
		txffe_remote_valid = int(txffe_value & 0x00000000FF)

		print("tffe value: {} Local FOM: {} Local Preset: {} Local Valid: {} Remote Valid {} Remote Preset: {}".format(
			hex(txffe_value), txffe_remote_fom, txffe_local_preset, txffe_local_valid, txffe_remote_valid, txffe_remote_preset))

		self.log_key(key="atc_{}_{}_lane_{}_remote_FOM".format(self.port_list[port], phy_str, lane), value=txffe_remote_fom, units='ticks')
		self.log_key(key="atc_{}_{}_lane_{}_local_Preset".format(self.port_list[port], phy_str, lane), value=txffe_local_preset,
					 units='ticks')
		self.log_key(key="atc_{}_{}_lane_{}_local_Valid".format(self.port_list[port], phy_str, lane), value=txffe_local_valid,
					 units='ticks')
		self.log_key(key="atc_{}_{}_lane_{}_remote_Valid".format(self.port_list[port], phy_str, lane), value=txffe_remote_valid,
					 units='ticks')
		self.log_key(key="atc_{}_{}_lane_{}_remote_Preset".format(self.port_list[port], phy_str, lane), value=txffe_remote_preset,
					 units='ticks')

	def grab_link_status_register(self, register_address, lane, phy, initial, port, bus, address):
		"""Grab link status register"""
		link_status = (int(self.read_phy_register(register_address, bus, address) >> 8) & 0x3F)
		print("Link Status Output: {} Lane: {} from address: {}".format(link_status, lane, hex(register_address)))

		if initial == True:
			self.log_key(key="atc_{}_{}_lane_{}_linkstatus_before".format(port, phy, self.current_lane, hex(register_address)), value=link_status, units='ticks')
		else:
			self.log_key(key="atc_{}_{}_lane_{}_linkstatus_after".format(port, phy, self.current_lane, hex(register_address)), value=link_status, units='ticks')


	def link_status_record(self, initial):
		rt13_auspma_separation = 0x8000
		rt13_lane_separation = 0x10000
		rt13_phy_separation = 0x100000

		valid_lanes = self.lane_count
		valid_auspma = [0]

		# For HBR2/3 they don't have 2 lanes for register dump register perspective
		if self.gen_version in ["DP_HBR2", "DP_HBR3"]:
			valid_lanes = [0, 1]
			valid_auspma = [0, 1]

		AUSPMA_RT_RX_TOP_TJ_PMAFSM_REG0 = SOC_CONVERSION_CODE[self.soc]['AUSPMA_RT_RX_TOP_TJ_PMAFSM_REG0']

		for port in range(0, len(self.bus)):
			for acio_lane in valid_lanes:
				for phy in self.phy_count:
					for auspma in valid_auspma:
						phy_value = "CFP" if phy == 0 else "SFP"
						lane_value = (acio_lane * len(valid_auspma)) + auspma
						self.current_lane = lane_value
						base_address_modifier = (phy * rt13_phy_separation) + (acio_lane * rt13_lane_separation) + (auspma * rt13_auspma_separation)
						print("PHY Value: {} ACIO Lane: {} Lane Value: {} AUSPMA: {} Port: {} Base Address Modifier: {}".format(phy_value, acio_lane, lane_value, auspma, port, base_address_modifier))
						self.grab_link_status_register(AUSPMA_RT_RX_TOP_TJ_PMAFSM_REG0 + base_address_modifier, lane_value, phy_value, initial, self.atc[port], self.bus[port], self.address[port])


	def start_margining(self):
		"""Start and run the margining process"""
		print(f"[Start Margining] Time Progressed: {time.time() - self.start_time}")

		print("Initial Link Status Check")
		self.link_status_record(True)
		print("Initial Link Status Check Complete")
		# ace --pick ATC1; ace --4cc SSPS --txdata "0x0" ; i2c -s 2; device -k usbphy -e select 1; device -k usbphy -e enable cio10g
		# Make these all optional parameters

		# even though we don't set the PMA value since it's the bit next to Lane for HBR3 which uses it lanes for 0->3 it gets set
		pma = 0  # C-code default
		speed = 0  # C-code default

		print("Axis Only: {} Lane Count: {}".format(self.axis_only, self.lane_count))
		if self.axis_only is False:
			self.margin_data = dict()
			for lane in self.lane_count:
				for phy_id in self.phy_count:
					phy_id = int(phy_id)
					print("Margining with Bus: {} Address: {} PHY ID: {} Lane: {} Depth: {} PMA: {} Speed: {}".format(self.bus, self.address, phy_id, lane, self.depth, pma, speed))
					for port in range(0, len(self.bus)):
						self.margin_data["Lane:{} Phy:{} ATC:{}".format(lane, phy_id, self.port_list[port])] = self.multidimensional_eye_margin(self.bus, self.address, phy_id, lane, int(self.depth), pma, speed)[port]
						print("Appending margin data for key: Lane:{} Phy:{} ATC:{}".format(lane, phy_id, self.port_list[port]))

			print("Completed margining for: {} lanes + {} PHY".format(len(self.lane_count), len(self.phy_count)))
		else:
			self.margin_data = dict()
			for lane in self.lane_count:
				for phy_id in self.phy_count:
					phy_id = int(phy_id)
					for port in range(0, len(self.bus)):
						self.margin_data["Lane:{} Phy:{} ATC:{}".format(lane, phy_id, self.port_list[port])] = self.axis_margin(self.bus, self.address, phy_id, lane, int(self.depth), pma, speed)[port]
						print("Appending margin data for key: Lane:{} Phy:{} ATC:{}".format(lane, phy_id, self.port_list[port]))
						print("Axis Margin Data: {} for Lane: {}".format(self.margin_data["Lane:{} Phy:{} ATC:{}".format(lane, phy_id, self.port_list[port])], lane))

		if self.device_index is not None:
			self.port_list = [self.device_index]

		for port in range(0, len(self.port_list)):
			self.orientation.append(self.plug_orientation(self.port_list[port], self.type[port]))
			self.present.append(self.plug_present(self.port_list[port], self.type[port]))
			print("Plug Orientation: {} and Plug Presence: {}".format(self.orientation[-1], self.present[-1]))
			if int(self.orientation[-1]) == 1:
				print("Plug Orientation Upside-Down")
			else:
				print("Plug Orientation Upside-Up")

		print("Done margining, with depth: {}".format(self.depth))

		print("Post Link Status Check")
		self.link_status_record(False)
		print("Post Link Status Check Complete")
		print(f"[End Start Margining] Time Progressed: {time.time() - self.start_time}")
