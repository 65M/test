from .base import AbstractReceiverMarginTool
from subprocess import run, PIPE
import os


__all__ = [
    "MarginTool"
]


class MarginTool(AbstractReceiverMarginTool):
    """Margin Tool Instance"""

    def start_margining(self):
        """Start the Margining"""
        self.data = {}
        # -interface Host -protocol CIO -rid 0x0 -route 0x1 -port 0 -lane 0
        self.data = run("./MellanoxMargining", shell=True, stdout=PIPE).stdout.decode()

        self.log_msg(self.data)
        print(self.data)
        self.data = self.data.split("\n")
        print("Done margining Lane{}".format(self.current_lane))
        return self.data

    def calculate_eye(self):

        max_number_lanes = 4
        key_match_network = {"north_ticks": [], "south_ticks": [], "east_ticks": [], "west_ticks": [], "eh_ticks": [],
                             "ew_ticks": [], "physical_grade": []}
        key_match_pcie = {"north_ticks": [], "south_ticks": [], "east_ticks": [], "west_ticks": [], "eh_ticks": [],
                          "ew_ticks": [], "physical_grade": []}

        for i, line in enumerate(self.data):
            key_match = key_match_pcie if "pcie_lane" in line else key_match_network
            for key in key_match.keys():
                if key in line:
                    key_match[key].append(line.split(":")[1])

        for key, value in key_match_network.items():
            if len(value) < max_number_lanes:
                print(f"Did not find the number of lanes for network found {value} vs expected {max_number_lanes} for {key}")
                return 0

        for key, value in key_match_pcie.items():
            if len(value) < max_number_lanes:
                print(f"Did not find the number of lanes for pcie found {value} vs expected {max_number_lanes} for {key}")
                return 0

        for lane in range(max_number_lanes):
            all_physical_grade = key_match_pcie["physical_grade"]
            all_north = key_match_pcie["north_ticks"]
            all_south = key_match_pcie["south_ticks"]
            all_east = key_match_pcie["east_ticks"]
            all_west = key_match_pcie["west_ticks"]
            all_eh_ticks = key_match_pcie["eh_ticks"]
            all_ew_ticks = key_match_pcie["ew_ticks"]

            self.log_key(key="pcie_lane_{}_physical_grade".format(lane), value=all_physical_grade[lane], units='ticks',
                         lowerlimit=60)
            self.log_key(key="pcie_lane_{}_north_ticks".format(lane), value=all_north[lane], units='ticks')
            self.log_key(key="pcie_lane_{}_south_ticks".format(lane), value=all_south[lane], units='ticks')
            self.log_key(key="pcie_lane_{}_east_ticks".format(lane), value=all_east[lane], units='ticks')
            self.log_key(key="pcie_lane_{}_west_ticks".format(lane), value=all_west[lane], units='ticks')
            self.log_key(key="pcie_lane_{}_eh_mv".format(lane), value=all_eh_ticks[lane], units='mV')
            self.log_key(key="pcie_lane_{}_ew_ps".format(lane), value=all_ew_ticks[lane], units='ps')

            self.log_msg("Lane {}: north = {}, south = {}, east = {}, west = {}, ns = {}mV, ew = {}ps".format(
                lane,
                all_north[lane],
                all_south[lane],
                all_east[lane],
                all_west[lane],
                all_eh_ticks[lane],
                all_ew_ticks[lane]
            ))

        for lane in range(max_number_lanes):
            all_physical_grade = key_match_network["physical_grade"]
            all_north = key_match_network["north_ticks"]
            all_south = key_match_network["south_ticks"]
            all_east = key_match_network["east_ticks"]
            all_west = key_match_network["west_ticks"]
            all_eh_ticks = key_match_network["eh_ticks"]
            all_ew_ticks = key_match_network["ew_ticks"]

            self.log_key(key="network_lane_{}_physical_grade".format(lane), value=all_physical_grade[lane], units='ticks',
                         lowerlimit=8000)
            self.log_key(key="network_lane_{}_north_ticks".format(lane), value=all_north[lane], units='ticks')
            self.log_key(key="network_lane_{}_south_ticks".format(lane), value=all_south[lane], units='ticks')
            self.log_key(key="network_lane_{}_east_ticks".format(lane), value=all_east[lane], units='ticks')
            self.log_key(key="network_lane_{}_west_ticks".format(lane), value=all_west[lane], units='ticks')
            self.log_key(key="network_lane_{}_eh_mv".format(lane), value=all_eh_ticks[lane], units='mV')
            self.log_key(key="network_lane_{}_ew_ps".format(lane), value=all_ew_ticks[lane], units='ps')

            self.log_msg("network_Lane {}: north = {}, south = {}, east = {}, west = {}, ns = {}mV, ew = {}ps".format(
                lane,
                all_north[lane],
                all_south[lane],
                all_east[lane],
                all_west[lane],
                all_eh_ticks[lane],
                all_ew_ticks[lane]
            ))


