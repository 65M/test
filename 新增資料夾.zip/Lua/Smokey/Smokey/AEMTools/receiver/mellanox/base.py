import time
from ..base import AbstractBaseMarginTool

try:
    from shell import run
except:
    print("Cannot run shell")
    pass

__all__ = [
    "AbstractReceiverMarginTool"
]

class AbstractReceiverMarginTool(AbstractBaseMarginTool):
    """Generic Interface for Widget Pass Margining"""
    LANE_COUNT = 1  # The Number of lanes (if applicable)
    POLL_TIME = 1  # Polling interval
    TIMEOUT = 20.000  # Maximum time in seconds before a 'run' is timedout
    result = []
    data = {}
    
    def __init__(self, *args, **kwargs):
        super(AbstractReceiverMarginTool, self).__init__(*args, **kwargs)
        self._fake_progress = 0

    #
    #  Accessors
    #
    def write_register(self, address, value):
        """Set Register to a value"""

    def read_register(self, address):
        """Get a Register value"""

    #
    # Execution Flow
    def set_adaptation(self, figure_of_merit):
        """Set the Adaptation Type (if applicable)"""
        #   TODO: Do we have to support different adaptation types?

    def apply_settings(self, retrain=True):
        """Apply EQ and other settings, retrain (if applicable)"""

    def ensure_link(self):
        """Check Link meets Speed / Width requirements"""

    def disable_power_management(self):
        """Disable Power Management Modes"""
        self.log_msg("   Disable Power Management")
        # TODO: Are there system management profiles relevant to iefI?

    def set_traffic_type(self, traffic_type):
        """Select the Traffic type (Live, PRBS, etc)"""
        # TODO: Anil to check if SOC supports PRBS

    def select_lane(self, lane):
        """Select a Lane"""
        self.log_msg("   Selecting Lane {}".format(lane))

    def configure_phy(self):
        """Configure the PHY Settings, Overrides, ECO, etc"""
        pass

    def setup_margining(self):
        """Configure Margin Settings"""

    def _update_status(self):
        """Fake Progress updater"""
        for i in range(0, 101):
            self._fake_progress = i
            time.sleep(0.05)

    def start_margining(self):
        pass

    def dump_registers(self, initial=False):
        """Dump Static Registers check adaptation converged values"""


    def parse_margin_data(self):
        """Parse data to the necessary format(s)"""
        self.result = []
        for i in range(23, 56, 1):
            vol_data = self.data[i].split("\t")
            for j in range(1, len(vol_data) - 1):
                self.result.append(int(vol_data[j]))
        print(self.result)
        return self.result

    def padded_hex(self, i, l):
        given_int = i
        given_len = l

        hex_result = hex(given_int)[2:]  # remove '0x' from beginning of str
        num_hex_chars = len(hex_result)
        extra_zeros = '0' * (given_len - num_hex_chars)  # may not get used..

        return ('0x' + hex_result if num_hex_chars == given_len else
                '?' * given_len if num_hex_chars > given_len else
                '0x' + extra_zeros + hex_result if num_hex_chars < given_len else
                None)

    def calculate_eye(self):
        """Calculate the Eye Diagram for axis only"""
        # Get the data for the lane (list of margin values)
        data = self.parse_margin_data()
        if len(data) > 0:
            self.seq_log.info("      Dumping eye for lane {}".format(self.current_lane))
            north, south, east, west = self.min_y, self.max_y, self.min_x, self.max_x

            # Visual diagram and Raw diagram
            diagram, coords = "", ""
            # Iterate thru the coordinate Top Left to Bottom Right
            for y in range(self.min_y, self.max_y, 1):
                for x in range(self.min_x, self.max_x, 1):
                    margin = data.pop(0)
                    # Add to the Coordinate file
                    coords += "{}".format(self.padded_hex(margin, 5)) if x == self.max_x else ",{}". \
                    format(self.padded_hex(margin, 5))

                    # Log only values below the threshold
                    if margin <= self.threshold:
                        diagram += "0"
                        # Set the North / South values
                        south = y if y < south else south
                        north = y if y > north else north

                        # Set the East / West values
                        west = x if x < west else west
                        east = x if x > east else east
                    else:
                        diagram += "1"

                coords += "\n"
                diagram += "\n"

            # Write the coordinate and diagram files
            self.write_coordinate_file(coords)
            self.write_eye_diagram_file(diagram)

            # Set the Height / Width
            self.eye_height[self.current_lane] = float((north + abs(south)) * self.TICK_TO_VOLTAGE)
            self.eye_width[self.current_lane] = float((west + abs(east)) * self.TICK_TO_FREQUENCY)

            # Log them to the result file
            self.log_key(key="lane_{}_north_ticks".format(self.current_lane), value=north, units='ticks')
            self.log_key(key="lane_{}_south_ticks".format(self.current_lane), value=south, units='ticks')
            self.log_key(key="lane_{}_east_ticks".format(self.current_lane), value=east, units='ticks')
            self.log_key(key="lane_{}_west_ticks".format(self.current_lane), value=west, units='ticks')
            self.log_key(key="lane_{}_eh_mv".format(self.current_lane), value=self.eye_height[self.current_lane],
                         units='mV')
            self.log_key(key="lane_{}_ew_ps".format(self.current_lane), value=self.eye_width[self.current_lane],
                         units='ps')

            self.log_msg("Lane {}: north = {}, south = {}, east = {}, west = {}, ns = {}mV, ew = {}ps".format(
                self.current_lane,
                north,
                south,
                east,
                west,
                self.eye_height[self.current_lane],
                self.eye_width[self.current_lane]
            ))

    def clean_up(self):
        """Clean up margining and reset the PHY"""

    # Helpers

    def progress(self):
        """Progress in integer % increments"""
        self.log_msg("   {}%".format(self._fake_progress))
        return self._fake_progress
    # TODO Progress is a blocking command

    def is_running(self):
        """Check if Margining is running"""
        return 1

    def all_lanes_scanned(self, lane):
        """Check if all lanes scanned, Used for tools that need to have individual lanes scanned"""
        if lane == self.LANE_COUNT:
            # All lanes are done in one shot
            return True

    def wait_for_finish(self):
        return 1
