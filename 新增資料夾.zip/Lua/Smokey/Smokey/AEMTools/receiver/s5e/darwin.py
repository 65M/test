from .base import ReceiverMarginTool
from ..ans2.darwin import MarginTool as ANS2MarginTool

__all__ = [
	"MarginTool"
]


class MarginTool(ANS2MarginTool, ReceiverMarginTool):
	"""Margin Tool Instance"""
