"""Access for iEFI"""
import sys
import logging
from .base import AbstractReceiverMarginTool
from shell import run

__all__ = [
    "MarginTool"
]

seq_log = logging.getLogger("sequence")


class MarginTool(AbstractReceiverMarginTool):
    """Margin Tool Instance"""

    def get_identify_controller(self):
        """Get Identify Controller Data"""
        print("[COMMAND] Get Identify Controller: nand --get Identify")
        data = run("nand --get Identify")
        print("NAND Controller Identify Command Output: {}".format(data))
        data = data.strip("OK\r\n")
        data = data.split("\r\n")
        identity_controller = {}
        for i in range(1, len(data)):
            temp = data[i].split(":")
            identity_controller[temp[0].strip(" ")] = temp[1].strip(" ")
        return identity_controller

    def get_lane_count(self):
        """Return the number of MCP Landings present using the 'NUM_OF_LANDINGS' from Identify Controller"""
        identity_controller = self.get_identify_controller()
        return int(identity_controller['NUM_OF_LANDINGS'], 16)

    def get_nand_size(self):
        """Return the NAND capacity"""
        identity_controller = self.get_identify_controller()
        return identity_controller['SSD capacity']

    def debug_service_write(self, register, value):
        """Debug Service Write"""
        print("[COMMAND] Debug Service Write: nand --debugwrite {} {}".format(hex(register), value))
        seq_log.debug("      Debug Service Write 0x{:04X} = 0x{:04X}".format(register, value))
        data = run("nand --debugwrite {} {}".format(hex(register), value))
        if "OK" in data:
            pass
        else:
            raise Exception("Write Failed")

    def debug_service_read(self, register):
        """Debug Service Read"""
        print("[COMMAND] Debug Service Read: nand --debugread {}".format(hex(register)))
        seq_log.debug("      Debug Service Read {}".format(hex(register)))
        data = run("nand --debugread {}".format(hex(register)))
        if "OK" in data:
            data = data.strip("\r\nOK")
            print("Here is the value")
            value = data.split("value =")[1].strip(" ")
        else:
            raise Exception("Read from register failed")
        return int(value, 16)

    def debug_data_read(self, log_id, param0, param1, log_size):
        """Debug Data Read"""
        print("[COMMAND] Debug Data Read: nand --debuglogread {} {}".format(hex(log_id), hex(param0)))
        seq_log.debug(
            "      Debug Data Read id=0x{:04X}, p0={}, p1={} for {} bytes".format(log_id, param0, param1, log_size))

        data = run("nand --debuglogread {} {}".format(hex(log_id), hex(param0)))
        if "OK" in data:
            data = data.split("\r\n")[1]
            seq_log.debug("      Debug Data Read {} bytes".format(len(data)))
            return data
        else:
            raise Exception("Debug Read failed")

