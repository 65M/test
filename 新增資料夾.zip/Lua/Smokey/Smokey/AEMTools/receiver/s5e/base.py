from .defines import S4E_REGISTERS
from ..ans3.base import AbstractReceiverMarginTool as ANS2ReceiverMarginTool

__all__ = [
    "AbstractReceiverMarginTool"
]


class AbstractReceiverMarginTool(ANS2ReceiverMarginTool):
    """Generic Interface for S4E (MSP Storage Controller) Margining"""

    # The PHY Register and Data Debug Services
    ROOT_PORT = False  # Root Port
    STATIC_REGISTERS = S4E_REGISTERS  # Static Registers


