
__all__ = [
	"S4E_REGISTERS",
]

S4E_REGISTERS = {
	# Raw register values
	"0x8e90": "S4E_RX_EQ_CTRL_RAW_CAP1",
	"0x8e94": "S4E_RX_EQ_CTRL_RAW_CAP2",
	"0xb098": "ANS2_RX_EQ_CTRL_RAW_CAP1",
	"0xb09c": "ANS2_RX_EQ_CTRL_RAW_CAP2"
}
