# Date: 10/30/2020
import logging
import argparse
from efi.AppleDeviceInfo import *
import uefi

logging.basicConfig(format='%(levelname)s: %(message)s')

gEfiSmbusHcProtocolGuid        = guid("e49d33ed-513d-4634-b698-6f55aa751c1b")
gAppleDeviceInfoProtocolGuid   = guid("487E8E93-EF97-4E77-A428-163E70715F62")

EFI_SMBUS_UDID = OrderedDict([
    ("VendorSpecificId", "L"),
    ("SubsystemDeviceId", "H"),
    ("SubsystemVendorId", "H"),
    ("Interface", "H"),
    ("DeviceId", "H"),
    ("VendorId", "H"),
    ("VendorRevision", "B"),
    ("DeviceCapabilities", "B")
])

EFI_SMBUS_DEVICE_MAP = OrderedDict([
    ("SmbusDeviceAddress", "O#EFI_SMBUS_DEVICE_ADDRESS"),
    ("SmbusDeviceUdid", "O#EFI_SMBUS_UDID")
])

EFI_SMBUS_HC_PROTOCOL = OrderedDict([
    ("Execute", "FE(PO#EFI_SMBUS_HC_PROTOCOL,N,N,i,B,PN,P)"),
    ("ArpDevice", "FE(PO#EFI_SMBUS_HC_PROTOCOL,B,PO#EFI_SMBUS_UDID,PO#EFI_SMBUS_DEVICE_ADDRESS)"),
    ("GetArpMap", "FE(PO#EFI_SMBUS_HC_PROTOCOL,PN,PPO#EFI_SMBUS_DEVICE_MAP)"),
    ("Notify", "FE(PO#EFI_SMBUS_HC_PROTOCOL,O#EFI_SMBUS_DEVICE_ADDRESS,N,F)"),
])

### EFI_SMBUS_OPERATION
EfiSmbusQuickRead = 0
EfiSmbusQuickWrite = 1
EfiSmbusReceiveByte = 2
EfiSmbusSendByte = 3
EfiSmbusReadByte = 4
EfiSmbusWriteByte = 5
EfiSmbusReadWord = 6
EfiSmbusWriteWord = 7
EfiSmbusReadBlock = 8
EfiSmbusWriteBlock = 9
EfiSmbusProcessCall = 10
EfiSmbusBWBRProcessCal = 11


class I2cCmd(object):

    def __init__(self):
        self.Buffer = mem('B')
        HandleCount = mem('N')
        HandleBufferPtr = mem('PT')

        uefi.bs.LocateHandleBuffer(ByProtocol, gEfiSmbusHcProtocolGuid, null, HandleCount.REF(), HandleBufferPtr.REF())
        self.Smbus = [None for i in range(HandleCount.VALUE)]

        HandleCount.FREE()
        HandleBufferPtr.FREE()

    def __del__(self):
        if isinstance(self.Buffer, mem):
            self.Buffer.FREE()

    def locateSmbus(self, desiredSmbus=0):

        if self.Smbus[desiredSmbus] is not None:
            return self.Smbus[desiredSmbus]

        HandleCount = mem('N')
        HandleBufferPtr = mem('PT')

        uefi.bs.LocateHandleBuffer(ByProtocol, gEfiSmbusHcProtocolGuid, null, HandleCount.REF(), HandleBufferPtr.REF())
        HandleBuffer = HandleBufferPtr.DREF("P%dT" % HandleCount.VALUE)

        DeviceInfo = mem()
        Key = mem('a')
        SmbusType = mem('B')
        Size = mem('N')
        Size.VALUE = 1

        for idx in range(0, HandleCount.VALUE):
            uefi.bs.HandleProtocol(HandleBuffer[idx], gAppleDeviceInfoProtocolGuid, DeviceInfo.REF().REF())
            DeviceInfo.CAST("O#APPLE_DEVICE_INFO")

            if DeviceInfo.VALUE:
                Key.VALUE = '\0'
                DeviceInfo.Get(DeviceInfo, Key, SmbusType.REF(), Size)

                if SmbusType.VALUE == desiredSmbus:
                    try:
                        self.Smbus[desiredSmbus] = mem()
                        uefi.bs.HandleProtocol(HandleBuffer[idx], gEfiSmbusHcProtocolGuid, self.Smbus[desiredSmbus].REF().REF())
                        self.Smbus[desiredSmbus].CAST("O#EFI_SMBUS_HC_PROTOCOL")
                        break
                    except efistatus as e:
                        logging.error("Couldn't find Smbus Handle")
                        raise e

        HandleCount.FREE()
        HandleBufferPtr.FREE()
        Key.FREE()
        SmbusType.FREE()
        Size.FREE()

    def I2cSweepBus(self, bus=0):
        """
        Sweep I2C bus for devices:
            i2c --sweep [-s] <Bus>

        :param bus:
        :return devices: the response address on the bus
        """
        self.locateSmbus(bus)

        chipCount = 0

        print("Sweeping bus %d" % bus)
        # EFI_SMBUS_DEVICE_ADDRESS struct has 8 Bytes space
        # deviceAddress.SmbusRegAddrSize = 1
        deviceAddress = mem('N')
        deviceAddress.VALUE = 0x0100

        # store the response address
        devices = list()

        for chipId in range(0x00, 0x80):
            # deviceAddress.SmbusDeviceAddress = chipId
            deviceAddress.VALUE = 0x0100 | chipId

            try:
                self.Smbus[bus].Execute(self.Smbus[bus], deviceAddress, 0, EfiSmbusQuickRead, 0, null, null)
                chipCount += 1
                print("Bus %d IC exists at Address: (7-bit) 0x%X (8-bit) 0x%X" % (bus, chipId, chipId<<1))
                # record the response address
                devices.append(chipId)
                uefi.bs.Stall(35000)
            except efistatus as e:
                # print(chipId, str(e))
                pass
            except AttributeError as e:
                logging.error("Not Found: Smbus protocol not found!")
                return None

        deviceAddress.FREE()

        return devices

    def I2cRead(self, bus=0, address=0x00, data_length=1, addrsize=1):
        """
        Read raw data:
            i2c --read [-r] <Bus> <Addr> <Len>

        :param bus:
        :param address:
        :param data_length:
        :param addrsize:
        :return readValue:
        """
        self.locateSmbus(bus)

        self.Buffer.FREE()
        self.Buffer = mem('{}B'.format(data_length))
        
        # EFI_SMBUS_DEVICE_ADDRESS struct has 8 Bytes space
        # deviceAddress.SmbusRegAddrSize = 1
        deviceAddress = mem('N')
        deviceAddress.VALUE = (addrsize << 8) | address

        dataLength = mem('N')
        dataLength.VALUE = data_length

        readValue = list()

        try:
            self.Smbus[bus].Execute(self.Smbus[bus], deviceAddress, 0, EfiSmbusReceiveByte, 0, dataLength.REF(), self.Buffer.REF())
            for i in range(dataLength.VALUE):
                readValue.append(self.Buffer[i])

        except efistatus as e:
            logging.error("Smbus returned error: {}".format(str(e)))
            raise e
        finally:
            dataLength.FREE()
            deviceAddress.FREE()

        return readValue

    def I2cWrite(self, bus=0, address=0x00, data=[0x00], multiple=False, addrsize=1):
        """
        Write raw data:
            i2c --write [-w] <Bus> <Addr> <data0 data1...> [multiple]
        :param bus:
        :param address:
        :param data:
        :param multiple:
        :return:
        """
        self.locateSmbus(bus)

        # EFI_SMBUS_DEVICE_ADDRESS struct has 8 Bytes space
        # deviceAddress.SmbusRegAddrSize = 1
        deviceAddress = mem('N')
        deviceAddress.VALUE = (addrsize << 8) | address

        data_length = len(data)
        self.Buffer.FREE()
        self.Buffer = mem('%dB' % data_length)

        for i, d in enumerate(data):
            self.Buffer[i] = int(d)

        stride = mem('N')

        if multiple:
            stride.VALUE = data_length
        else:
            stride.VALUE = 1
        try:
            i = 0
            while i < data_length:
                # print("Buffer Address: {} , self.Buffer.ADDR + i))
                self.Smbus[bus].Execute(self.Smbus[bus], deviceAddress, 0, EfiSmbusSendByte, 0, stride.REF(), self.Buffer.ADDR + i)
                uefi.bs.Stall(5000)
                i += stride.VALUE
        except efistatus as e:
            logging.error("Smbus returned error: {}".format(str(e)))
            raise e
        finally:
            deviceAddress.FREE()
            stride.FREE()

    def I2cMaskWrite(self, bus=0, address=0x00, register=0x00, mask=0x00, data=[0x00], multiple=False, addrsize=1):
        """
        Write register data:
            i2c --maskwrite [-m] <Bus> <Addr> <Reg> <Mask> <data0 data1...> [multiple]
        :param bus:
        :param address:
        :param register:
        :param mask:
        :param data:
        :param multiple:
        :return:
        """
        self.locateSmbus(bus)

        # EFI_SMBUS_DEVICE_ADDRESS struct has 8 Bytes space
        # deviceAddress.SmbusRegAddrSize = 1
        deviceAddress = mem('N')
        deviceAddress.VALUE = (addrsize << 8) | address

        data_length = len(data)
        dataLength = mem('N')
        dataLength.VALUE = data_length

        self.Buffer.FREE()
        self.Buffer = mem('%dB' % data_length)
        try:
            self.Smbus[bus].Execute(self.Smbus[bus], deviceAddress, register, EfiSmbusReadBlock, 0, dataLength.REF(), self.Buffer.REF())

            self.Buffer[0] = (data[0] & mask) | (self.Buffer[0] & ~mask)

            self.Smbus[bus].Execute(self.Smbus[bus], deviceAddress, register, EfiSmbusWriteBlock, 0, dataLength.REF(), self.Buffer.REF())
        except efistatus as e:
            logging.error('Smbus Protocol returned error.')
            raise e
        finally:
            deviceAddress.FREE()
            dataLength.FREE()

    def I2cDevRead(self, bus=0, address=0x00, register=0x00, data_length=1, multiple=False, addrsize=1):
        """
        Read register data:
            i2c --devread [-d] <Bus> <Addr> <Reg> <Len> [multiple]
        :param bus:
        :param address:
        :param register:
        :param data_length:
        :param multiple:
        :return readValue:
        """
        self.locateSmbus(bus)

        # EFI_SMBUS_DEVICE_ADDRESS struct has 8 Bytes space
        # deviceAddress.SmbusRegAddrSize = 1
        deviceAddress = mem('N')
        deviceAddress.VALUE = (addrsize << 8) | address

        self.Buffer.FREE()
        self.Buffer = mem('{}B'.format(data_length))

        stride = mem('N')

        if multiple:
            stride.VALUE = data_length
        else:
            stride.VALUE = 1

        readValue = list()

        try:
            i=0
            while i < data_length:
                regAddr = register + i

                self.Smbus[bus].Execute(self.Smbus[bus], deviceAddress, regAddr, EfiSmbusReadBlock, 0, stride.REF(), self.Buffer.ADDR + i)
                # print("Buffer Address: {}, Buffer Value: {}".format(self.Buffer.ADDR + i, self.Buffer[i]))
                i += stride.VALUE

        except efistatus as e:
            logging.error("Smbus returned error: {}".format(str(e)))
            raise e
        finally:
            deviceAddress.FREE()
            stride.FREE()

        for i in range(data_length):
            readValue.append(self.Buffer[i])

        return readValue

    def I2cDevWrite(self, bus, address, register, data=[0x00], multiple=False, addrsize=1):
        """
        Write register data:
            i2c --devwrite [-v] <Bus> <Addr> <Reg> <data0 data1...>

        :param address:
        :param register:
        :param data:
        :return:
        """
        self.locateSmbus(bus)

        # EFI_SMBUS_DEVICE_ADDRESS struct has 8 Bytes space
        # deviceAddress.SmbusRegAddrSize = 1
        deviceAddress = mem('N')
        deviceAddress.VALUE = (addrsize << 8) | address

        stride = mem('N')
        data_length = len(data)

        self.Buffer.FREE()
        self.Buffer = mem('{}B'.format(data_length))

        for i, d in enumerate(data):
            self.Buffer[i] = int(d)

        if multiple:
            stride.VALUE = data_length
        else:
            stride.VALUE = 1

        try:
            i=0
            while i < data_length:
                regAddr = register + i
                logging.debug("regAddr: 0x%02X" % regAddr)
                self.Smbus[bus].Execute(self.Smbus[bus], deviceAddress, regAddr, EfiSmbusWriteBlock, 0, stride.REF(), self.Buffer.ADDR + i)
                uefi.bs.Stall(5000)
                i += stride.VALUE
        except efistatus as e:
            logging.error("Smbus returned error")
            raise e
        finally:
            deviceAddress.FREE()
            stride.FREE()

    def printHelp(self):
        print("Command for generic read/write to I2C device.")
        print(" ")
        print("[i2c <Command>]")
        print(" ")
        print("  --addrsize  [-z] <1|2|4> : ")
        print("                 Register address size in bytes (1, 2, 4) (default: 1)")
        print("  --read      [-r] <Bus> <Addr> <Len> : ")
        print("                  Read raw data")
        print("  --devread   [-d] <Bus> <Addr> <Reg> <Len> [multiple] : ")
        print("                  Read register data")
        print("  --write     [-w] <Bus> <Addr> <data0 data1...> [multiple] : ")
        print("                  Write raw data")
        print("  --devwrite  [-v] <Bus> <Addr> <Reg> <data0 data1...> : ")
        print("                  Write register data")
        print("  --compact   [-c] :  ")
        print("                  Option for write/devwrite when data in compacted format  ")
        print("                      (e.g. compact 0x12 0xAB to 12AB)")
        print("  --maskwrite [-m] <Bus> <Addr> <Reg> <Mask> <data0 data1...> [multiple]: ")
        print("                  Write register data")
        print("  --sweep     [-s] <Bus> : ")
        print("                  Sweep I2C bus for devices.")
        print("    Defines:")
        print("        Bus         - I2C bus 0, 1, or 2 (in decimal)")
        print("        Addr        - device address (in hex), expected to be 7-bit ")
        print("                      (omitting the read/write bit)")
        print("        Reg         - bank and reg addr")
        print("        Mask        - mask to apply to data0")
        print("        Len         - read data length")
        print("        data        - data to write (in hex), assume data0 is regAddr")
        print("        multiple    - optional arg, write/read data in multiple bytes")
        print(" ")


def i2c_run(addrsize=None,read=None,devread=None,write=None,devwrite=None,compact=None,maskwrite=None,sweep=None):
    i2cCmd = I2cCmd()
    addressSize = 1

    if addrsize:
        # --addrsize  [-z] <1|2|4> 
        if int(addrsize) in [1, 2, 4]:
            addressSize = int(addrsize)
        else:
            raise Exception("Invalid argument addrsize: ", addrsize)

    if sweep:
        # --sweep     [-s] <Bus> 
        DesiredSmbusType = int(sweep)
        i2cCmd.I2cSweepBus(DesiredSmbusType)

    elif read:
        # --read      [-r] <Bus> <Addr> <Len> 
        Bus = int(read[0])
        DeviceAddress = int(read[1])
        data_length = int(read[2])

        readValue = i2cCmd.I2cRead(Bus, DeviceAddress, data_length, addressSize)
        print("Reading %d bytes into 0x%08X, buffer read:\t" % (data_length, i2cCmd.Buffer.ADDR & 0xFFFFFFFF), end="")
        for val in readValue:
            print(" 0x%02X " % val, end="")
        print("")

    elif write:
        # --write     [-w] <Bus> <Addr> <data0 data1...> [multiple] 
        Bus = int(write[0])
        DeviceAddress = int(write[1])
        writeData = write[2:]
        multiple = True
        data = list()

        if writeData[-1] == "multiple":
            multiple = True
            writeData.remove(writeData[-1])

        if compact:
            data_length = len(writeData) // 2
            for i in range(0, data_length):
                data.append(int("0x" + writeData[2*i:2*i+2]))
        else:
            data = list(map((lambda x: int(x)), writeData))

        i2cCmd.I2cWrite(Bus, DeviceAddress, data, multiple, addressSize)

        print("Set bytes:\t", end="")
        data_length = len(data)
        for i in range(0, data_length):
            print("0x%02X " % i2cCmd.Buffer[i], end="")
        print("\tWriting %d bytes" % data_length)

    elif maskwrite:
        # --maskwrite [-m] <Bus> <Addr> <Reg> <Mask> <data0 data1...> [multiple]
        Bus = int(maskwrite[0])
        DeviceAddress = int(maskwrite[1])
        Register = int(maskwrite[2])
        Mask = int(maskwrite[3])
        writeData = maskwrite[4:]
        multiple = True

        if maskwrite[-1] == "multiple":
            multiple = True
            writeData.remove(writeData[-1])

        data = list(map((lambda x: int(x)), writeData))

        i2cCmd.I2cMaskWrite(Bus, DeviceAddress, Register, Mask, data, multiple, addressSize)

        print("Set  bytes:\t", end="")
        data_length = len(data)
        for i in range(data_length):
            print("0x%02X " % data[i], end="")
        print("\tWritting %d bytes" % data_length)

    elif devread:
        # --devread   [-d] <Bus> <Addr> <Reg> <Len> [multiple] 
        Bus = int(devread[0])
        DeviceAddress = int(devread[1])
        Register = int(devread[2])
        data_length = int(devread[3])
        multiple = True

        if devread[-1] == "multiple":
            multiple = True

        readValue = i2cCmd.I2cDevRead(Bus, DeviceAddress, Register, data_length, multiple, addressSize)

        output_str = "Reading {} bytes from register offset 0x{:02x} into 0x{:08x}, buffer read:\t\nData: ".format(data_length, Register, i2cCmd.Buffer.ADDR & 0xFFFFFFFF)
        print("Reading %d bytes from register offset 0x%02X into 0x%08X, buffer read:\t\nData: " %
              (data_length, Register, i2cCmd.Buffer.ADDR & 0xFFFFFFFF), end="")
        for val in readValue:
            print(" 0x%02X " % val, end="")
            output_str = output_str + (" 0x{:02x} ".format(val))
        print("")

        return output_str

    elif devwrite:
        # --devwrite  [-v] <Bus> <Addr> <Reg> <data0 data1...> [multiple] 
        Bus = int(devwrite[0])
        DeviceAddress = int(devwrite[1])
        Register = int(devwrite[2])
        writeData = devwrite[3:]
        data = list()
        multiple = True

        if devwrite[-1] == "multiple":
                multiple = True
                writeData.remove(writeData[-1])

        if compact:
            data_length = len(writeData) // 2
            for i in range(0, data_length):
                data.append(int("0x" + writeData[2*i:2*i+2]))
        else:
            data = list(map((lambda x: int(x)), writeData))

        i2cCmd.I2cDevWrite(Bus, DeviceAddress, Register, data, multiple, addressSize)

        output_str = "Set bytes:\t"
        print("Set bytes:\t", end="")
        data_length = len(data)
        for i in range(0, data_length):
            print("0x%02X " % i2cCmd.Buffer[i], end="")
            output_str = output_str + "0x{:02X} ".format(i2cCmd.Buffer[i])

        print("\t Writing %d bytes" % data_length)
        output_str = output_str + "\t Writing {} bytes".format(data_length)

        return output_str


if __name__ == '__main__':
    main()
