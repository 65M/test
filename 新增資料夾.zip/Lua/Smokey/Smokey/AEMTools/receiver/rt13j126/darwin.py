from . import iefi
import os
import subprocess

# !/usr/bin/env python3
#
# Copyright (C) 2022 Apple Inc. All rights reserved.
#
# This document is the property of Apple Inc.
# It is considered confidential and proprietary.
#
# This document may not be reproduced or transmitted in any form,
# in whole or in part, without the express written permission of
# Apple Inc.
'''Overrides for iefi.MarginTool which redirect I2C transactions to a
remote E126 microcontroller.
'''

import asyncio
import logging
import os

from . import iefi
from .base import AbstractReceiverMarginTool
from . import tcp_i2c


logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)


class I2cmServiceHost:
    '''Connect to the KalEl microcontroller service which directly
    injects I2C traffic on arbitrary buses.'''

    '''
    How to write registers
    
    1. write the register 
        i2c write lfk0 25 0x2  -- writes that we want the I2C_AP_REGISTER_ADDRESS_AP_COMMUNICATOR_CONTROL (0x2)
    2. write the data packet to the register
        i2c write lkf0 25 1 12
    3. read the data packet 
        
    How to read registers 
    1. write the address to the register
    2. write the address
    3. read the register 

    '''

    def __init__(self, loop, host, port, bus, address):
        self.loop = loop
        self.host = host
        self.port = port
        self.bus = bus
        self.address = address

    def connect(self):
        self.reader, self.writer = self.loop.run_until_complete(
            asyncio.open_connection(self.host, self.port))
        logger.info('Connected to remote host i2cm_service')
        self.service = tcp_i2c.Service(loop=self.loop,
                                       reader=self.reader,
                                       writer=self.writer,
                                       bus=self.bus,
                                       addr=self.address)

    def i2c_read(self, index, register, length):
        logger.debug('i2c_read(index={}, register=0x{:02x}, length={})'.format(
            index, register, length))
        # Write register address, then read back data. First byte
        # returned is the length of data to follow.
        coro = self.service.transact(data=bytes([register]),
                                     read_len=length + 1)
        data = self.loop.run_until_complete(coro)
        return data[0], data[1:]

    def i2c_write(self, index, register, data):
        logger.debug('i2c_write(index={}, register=0x{:02x}, data={}'.format(
            index, register, data.hex()))
        # Write register address, data length, then data.
        out_blob = bytes([register, len(data)]) + data
        coro = self.service.transact(data=out_blob)
        self.loop.run_until_complete(coro)


# For this to work we need to pass in host_name & port
# We also need rt13_layout to be [0, 0, 0, 0x18]
class MarginTool(iefi.MarginTool):
    # Override the default path separator.
    PATH_SEP = os.path.sep

    def __init__(self, *args, **kwargs):

        # Connect to the remote I2C gateway before running the
        # superclass init. The superclass goes straight to work.
        # Carrier, rt13_number, CFP/SFP
        # [0, 0, 0, 0x18]
        device_index = kwargs['device_index']
        rt13_layout = kwargs["rt13_layout"][device_index]

        self.host_name = kwargs['host_name']
        self.port = kwargs['port']

        self.rt13_number = device_index
        # port == ? network port aka 5120
        # bus  == ? lfk{x}
        loop = asyncio.get_event_loop()
        self.host = I2cmServiceHost(loop=loop, host=self.host_name, port=self.port,
                                    bus=f"lfk{self.rt13_number}",
                                    address=rt13_layout[2])
        self.host.connect()
        super(iefi.MarginTool, self).__init__(*args, **kwargs)

    def get_bits(self, address, start_bit, length):
        # Override so we can return fixed values, as we are not
        # actually the SoC connected to an RT13.
        # acio_top_ACIO_TOP_ACIO_GLOBAL_CFG0
        # Force to bonded, legacy 20.625GHz rate.
        value = 0x13
        print('get_bits 0x{:x} value forced to 0x{:x}'.format(
            address, value))
        return (value >> start_bit) & ((1 << length) - 1)

    def write_register_four_byte(self, bus, address, register, write_data_dword0):
        raise NotImplementedError()

    def write_register(self, bus, address, register,
                       write_data_dword1, write_data_dword0):
        data = ((write_data_dword1 << 32) |
                (write_data_dword0 << 0)).to_bytes(8, 'little')
        print('write bus={} register={} data={}'.format(bus, register,
                                                        data.hex()))
        self.host.i2c_write(index=bus, register=register,
                            data=data)

    def read_register(self, bus, address, register, length):
        got, data = self.host.i2c_read(index=bus, register=register,
                                       length=length - 1)
        data = bytes([got]) + data
        s = 'Data: ' + ''.join([' 0x{:02x} '.format(b) for b in data])
        print('read bus={} register={} data={} s={}'.format(bus, register,
                                                            data.hex(), s))
        return s

    def grab_ace_output(self, atc_port, type):
        print("Dummy grab_ace_output")
        pass

    def ensure_link(self):
        print("Dummy ensure link for J126")
        pass

    def grab_fw_version(self, bus, address):
        print("Dummy grab_fw_version for J126")
        pass

    def plug_orientation(self, atc_port, type):
        return 0

    def plug_present(self, atc_port, type):
        return 1

    def grab_divider_register(self, initial):
        ''' SoC Side of it'''
        print("Tried to grab_divider_register but cannot")
        pass

#
# class MarginTool(iefi.MarginTool):
#     # Override the default path separator.
#     PATH_SEP = os.path.sep
#
#     # user must provide
#     # Host_name = mantactl mcu console -d ncm-0 carrier:0 en7
#     def __init__(self, *args, **kwargs):
#         # Connect to the remote I2C gateway before running the
#         # superclass init. The superclass goes straight to work.
#         device_index = kwargs['device_index']
#         rt13_layout = kwargs['rt13_layout'][device_index]
#
#         self.host_name = kwargs['host_name']
#         self.interface_name = kwargs['interface_name']
#         self.rt13_number = rt13_layout[1]
#
#         # Carrier, rt13_number, CFP, SFP
#         # [0, 0, 0, 0x18]
#         # remotectl list
#         # mantanct -d ncm-0 mcu list
#         # mantanct -d ncm-0 mcu console carrier:0
#         # "mantactl mcu console -d self.host_name f"carrier:{rt13_layout[0]}
#         self.host = subprocess.Popen(["conn", "-n", "FE80::cc:B9FF:FE10:589E%vlan0", "5000"])
#         # self.host = subprocess.Popen(["mantactl", "mcu", "console", "-d", self.host_name, f"carrier:{rt13_layout[0]}",
#         #                             self.interface_name], shell=False, stdin=subprocess.PIPE, stdout=subprocess.PIPE)
#         self.output = self.host.communicate(timeout=10)[0].decode()
#
#         if "Remote connected" in self.output:
#             print(f"Mantactl is able to load correctly pid: {self.host.pid} --- {self.output}")
#         else:
#             print(f"Unable to load mantactl correctly! {self.output}")
#             raise Exception(f"Unable to load mantactl. Check carrier {rt13_layout[0]} is reachable on host "
#                             f"{self.host_name} / {self.interface_name}")
#
#         super(iefi.MarginTool, self).__init__(*args, **kwargs)
#
#     def get_bits(self, address, start_bit, length):
#         """ output
#         > i2c read i2c5 0x34 4
#         Received from 0x34 on i2c5: 0x1C 0x1C 0x1C 0x1C
#         """
#         # iic read busname addr len
#         hex_address = hex(address)
#         print(f"Getting bits from address: {hex_address}")
#         output = self.host.communicate(f"i2c read lfk{self.rt13_number} {hex_address} 4", timeout=10)[0].decode()
#         if "error:" in output:
#             print(f"Unable to get bits from address: {address} start_bit: {start_bit} length: {length}")
#             raise Exception(f"Unable to get bits from address: {address} start_bit: {start_bit} length: {length}")
#
#         output = output.split(": ")[1].split(" ")
#         if len(output) != 4:
#             print("Unable to read all 4 bytes of data. This will not work")
#         reg_value = ""
#         for register in output:
#             reg_value = reg_value + register.replace("0x", "")
#
#         reg_value = "0x" + reg_value
#         try:
#             bin_val = '{:>032}'.format(bin(int(reg_value, 16))[2:])
#             end_pos = 31 - start_bit + 1
#             start_pos = 31 - start_bit - length + 1
#             bits = int(bin_val[start_pos:end_pos], 2)
#             print("Get Bits Output: {}".format(bits))
#         except Exception:
#             print("Unable to split get_bits return result")
#             raise
#         return bits
#
#     def write_register_four_byte(self, bus, address, register, write_data_dword0):
#         # Write a given I2C register (expect 64-bits)
#         length = 4  # we always write 8 bytes for this code
#
#         dword0_byte0 = (write_data_dword0 & 0xFF)
#         dword0_byte1 = (write_data_dword0 >> 8) & 0xFF
#         dword0_byte2 = (write_data_dword0 >> 16) & 0xFF
#         dword0_byte3 = (write_data_dword0 >> 24) & 0xFF
#
#         print("command i2c write lfk{} {} {} {} {} {} {} {} {} multiple".format(
#             self.rt13_number, hex(address), hex(register), hex(length), hex(dword0_byte0), hex(dword0_byte1),
#             hex(dword0_byte2),
#             hex(dword0_byte3)))
#
#         write_command = self.host.communicate(f"i2c write lfk{self.rt13_number} {hex(address)} {hex(register)} "
#                                               f"{hex(dword0_byte0)} {hex(dword0_byte1)} {hex(dword0_byte2)} "
#                                               f"{hex(dword0_byte3)}",
#                                               timeout=10)[0]
#         if "error" in write_command:
#             raise Exception("I2C bus write failed to command "
#                             "i2c write lfk{} {} {} {} {} {} {} {} multiple".format(self.rt13_number, hex(address),
#                                                                                    hex(register),
#                                                                                    hex(length), hex(dword0_byte0),
#                                                                                    hex(dword0_byte1),
#                                                                                    hex(dword0_byte2),
#                                                                                    hex(dword0_byte3)))
#         return write_command
#
#     def write_register(self, bus, address, register, write_data_dword1, write_data_dword0):
#         """Write an i2c register"""
#         length = 8  # we always write 8 bytes for this code
#
#         dword0_byte0 = (write_data_dword0 & 0xFF)
#         dword0_byte1 = (write_data_dword0 >> 8) & 0xFF
#         dword0_byte2 = (write_data_dword0 >> 16) & 0xFF
#         dword0_byte3 = (write_data_dword0 >> 24) & 0xFF
#         dword1_byte0 = write_data_dword1 & 0xFF
#         dword1_byte1 = (write_data_dword1 >> 8) & 0xFF
#         dword1_byte2 = (write_data_dword1 >> 16) & 0xFF
#         dword1_byte3 = (write_data_dword1 >> 24) & 0xFF
#
#         print("command i2c write lfk {} {} {} {} {} {} {} {} {} {} {} {} multiple".format(
#             bus, hex(address), hex(register), hex(length), hex(dword0_byte0), hex(dword0_byte1), hex(dword0_byte2),
#             hex(dword0_byte3),
#             hex(dword1_byte0), hex(dword1_byte1), hex(dword1_byte2), hex(dword1_byte3)))
#
#         write_command = self.host.communicate(f"i2c write lfk{self.rt13_number} {hex(address)} {hex(register)} "
#                                               f"{hex(dword0_byte0)} {hex(dword0_byte1)} {hex(dword0_byte2)} "
#                                               f"{hex(dword0_byte3)} {hex(dword1_byte0)} {hex(dword1_byte1)} "
#                                               f"{hex(dword1_byte2)} {hex(dword1_byte3)} ",
#                                               timeout=10)[0]
#         if "error" in write_command:
#             raise Exception("I2C bus write failed to command "
#                             "i2c write lfk{} {} {} {} {} {} {} {} {} multiple".format(self.rt13_number, hex(address),
#                                                                                       hex(register),
#                                                                                       hex(length), hex(dword0_byte0),
#                                                                                       hex(dword0_byte1),
#                                                                                       hex(dword0_byte2),
#                                                                                       hex(dword0_byte3),
#                                                                                       hex(dword1_byte0),
#                                                                                       hex(dword1_byte1),
#                                                                                       hex(dword1_byte2),
#                                                                                       hex(dword1_byte3)))
#         return write_command
#
#     def read_register(self, bus, address, register, length):
#         print("command i2c --devread {} {} {} {} multiple".format(bus, hex(address), hex(register), length))
#         # read_command = i2c_run(devread=[bus,hex(address),hex(register),length])
#         # read_command = run("i2c --devread {} {} {} {} multiple".format(bus, hex(address), hex(register), length))
#
#         read_command = self.host.communicate(f"i2c read lfk{self.rt13_number} {hex(address)} {hex(register)} 4", timeout=10)[0]
#
#         # return read_command
#
#     def grab_ace_output(self):
#         print("tried to grab ace output")
#         pass
#
#     def ensure_link(self):
#         print("Tried to ensure_link...")
#         pass
#
#     def grab_fw_version(self, bus, address):
#         print("Tried to get fw_version")
#         pass

