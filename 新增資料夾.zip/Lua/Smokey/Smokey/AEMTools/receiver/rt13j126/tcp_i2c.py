#!/usr/bin/env python3
#
# Copyright (C) 2021 Apple Inc. All rights reserved.
#
# This document is the property of Apple Inc.
# It is considered confidential and proprietary.
#
# This document may not be reproduced or transmitted in any form,
# in whole or in part, without the express written permission of
# Apple Inc.

'''
Interface to a remote Kal-El TCP I2C service.
'''

import asyncio
import binascii
import logging


logger = logging.getLogger(__name__)


class Frame:
    'I2C TCP service common command/response frame.'

    def __init__(self, data):
        assert len(data) < 255
        self.data = data

    async def write(self, writer):
        'Write the frame to a writer stream'
        frame = bytes([len(self.data) + 1]) + self.data
        logger.debug('write frame={}'.format(frame))
        logger.debug(binascii.hexlify(frame, sep=' '))
        writer.write(frame)
        await writer.drain()

    @classmethod
    async def from_reader(cls, reader):
        '''
        Reads and returns a frame from a reader stream.

        TODO: This needs a timeout feature.
        '''
        while True:
            length = (await reader.readexactly(1))[0]
            if length == 0:
                logger.debug(f'Frame size {length} invalid')
                continue
            remainder = await reader.readexactly(length - 1)
            frame = bytes([length]) + remainder
            logger.debug('read frame={}'.format(frame))
            logger.debug(binascii.hexlify(frame, sep=' '))
            return cls(data=frame[1:])


class Command:
    'I2C TCP service command packet.'

    def __init__(self, bus: str, addr: int, data: bytes, read_len: int):
        self.bus = bus
        self.addr = addr
        self.data = data
        self.read_len = read_len

    async def write(self, writer):
        'Frame and write this command packet to a stream writer'
        bus_bytes = self.bus.encode('latin-1')
        packet = (bytes([len(bus_bytes)]) + bus_bytes +
                  bytes([self.addr, len(self.data), self.read_len]) +
                  self.data)
        await Frame(data=packet).write(writer)


class Response:
    'I2C TCP service response packet.'

    def __init__(self, status: int, data: bytes):
        self.status = status
        self.data = data

    @classmethod
    async def from_reader(cls, reader):
        'Read a frame from a stream reader and extract the response packet'
        frame = await Frame.from_reader(reader)
        return cls(status=frame.data[0], data=frame.data[1:])


class Service:
    'Remote kal-el TCP I2C service.'

    class ResponseError(Exception):
        pass

    def __init__(self, loop, reader, writer, bus, addr):
        self.loop = loop
        self.reader = reader
        self.writer = writer
        self.bus = bus
        self.addr = addr

    async def transact(self, data=bytes(), read_len=0):
        command = Command(bus=self.bus, addr=self.addr,
                          data=data, read_len=read_len)
        await command.write(self.writer)
        response = await Response.from_reader(self.reader)
        assert response is not None
        logger.debug(f'Response status={response.status} data={response.data}')
        if response.status == 0x00:
            return response.data
        else:
            raise self.ResponseError(
                'response status = 0x{:02x}'.format(response.status))


if __name__ == '__main__':
    raise RuntimeError('Not to be invoked directly - sorry, no tests')