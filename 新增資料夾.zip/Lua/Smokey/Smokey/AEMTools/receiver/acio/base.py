import time
from .defines import *
from ..base import AbstractBaseMarginTool
from .conversion import *
from .soc_defines import *
from shell import run

__all__ = [
    "AbstractReceiverMarginTool"
]


class AbstractReceiverMarginTool(AbstractBaseMarginTool):
    """Generic Interface for Widget Pass Margining"""
    LANE_COUNT = 2   # The Number of lanes (if applicable)
    POLL_TIME = 1  # Polling interval
    TIMEOUT = 20.000  # Maximum time in seconds before a 'run' is timedout
    res_data = []
    res_vol_north_data = []
    res_vol_south_data = []
    res_pi_east_data = []
    res_pi_west_data = []
    res_vol_north_data_1 = []
    res_vol_south_data_1 = []
    res_pi_east_data_1 = []
    res_pi_west_data_1 = []
    LANE_RP_OFFSET = 0
    mid_x = 0
    mid_y = 0
    mid_x_dclkb = 0

    RP_OFFSET = 0
    lane_offset = 0x7000
    r = None
    c = None
    soc_atc0_offset = 0
    aciophy_lane0 = 0
    atc_top_offset = 0
    RP_OFFSET_ACIO = 0
    atc_acio_offset = 0
    LANE0_RP_OFFSET = 0
    port_num = None

    def __init__(self, *args, **kwargs):
        super(AbstractReceiverMarginTool, self).__init__(*args, **kwargs)
        self._fake_progress = 0
        self.soc_atc0_offset = SOC_CONVERSION_CODE[self.soc]['SOC_ATC_OFFSET']
        self.atc_top_offset = SOC_CONVERSION_CODE[self.soc]['ATC_TOP_OFFSET']
        self.atc_acio_offset = SOC_CONVERSION_CODE[self.soc]['ATC_ACIO_OFFSET']
        self.RP_OFFSET = SOC_CONVERSION_CODE[self.soc]['RP_OFFSET']
        self.aciophy_lane0 = SOC_CONVERSION_CODE[self.soc]['ACIOPHY_LANE0']
        self.lane_offset = SOC_CONVERSION_CODE[self.soc]['LANE_OFFSET']
        if self.die_location:
            self.die_length = int(len(self.die_location['0']))
            self.die_number = 0
            print("Number of ATC Ports on DIE: {}".format(self.die_length))
        else:
            self.die_length = 0
            self.die_number = 0
        try:
            self.die_offset = SOC_CONVERSION_CODE[self.soc]['DIE_OFFSET']
        except KeyError:
            self.die_offset = None

    #
    #  Accessors
    #
    def write_register(self, address, value):
        """Set Register to a value"""

    def read_register(self, address):
        """Get a Register value"""

    def set_bits(self, address, start_bit, length, value):
        """Change specific bits of a address"""

    def get_bits(self, address, start_bit, length):
        """Change specific bits of a address"""

    def int2sa_vos_code(self, intval):
        """ convert to gray code from sign int 5 bits """
        if (intval < -31) or (intval > 31):
            return None
        elif intval >= 0:
            return intval ^ intval >> 1
        return abs(intval ^ intval >> 1) + 32

    def dec2gray(self, i=0):
        """ convert dec to gray """
        return i ^ i >> 1

    def gray2dec(self, i=0, total_bits=63):
        """ convert gray to dec """
        return [self.dec2gray(d) for d in range(total_bits)].index(i)
    #
    # Execution Flow
    #

    def set_adaptation_ace(self):
        if bool(self.vendor_specific['run']) is True and self.adaptation_run is 0:
            run("ace --list; "
                "ace --pick ATC2; "
                "ace --write {}".format(self.vendor_specific['ace']))
            run("ace --4cc {} --txdata {}".format("DISC", "0x3"))
            time.sleep(5)
        else:
            pass

    def set_iqa_dfe(self):
        print("Enabling iqa_dfe!")
        '''
        ATC1.ATC_TOP.ACIOPHY.ACIOPHY_LANE1.AUSPMA.AUSPMA_RX.AUSPMA_RX_EQ.AUSPMA_RX_EQ_TJ.cfg17_eq
        seq_b_eng1 = 5
        seq_b_eng2 = 2


        ATC1.ATC_TOP.ACIOPHY.ACIOPHY_LANE1.AUSPMA.AUSPMA_RX.AUSPMA_RX_EQ.AUSPMA_RX_EQ_TJ.cfg43_eq
        err_th0 = 0x3e8
        ui_th = 0xf4240

        ATC1.ATC_TOP.ACIOPHY.ACIOPHY_LANE1.AUSPMA.AUSPMA_RX.AUSPMA_RX_EQ.AUSPMA_RX_EQ_TJ.cfg44_eq
        Err_th1 = 0x2710

        ATC1.ATC_TOP.ACIOPHY.ACIOPHY_LANE1.AUSPMA.AUSPMA_RX.AUSPMA_RX_EQ.AUSPMA_RX_EQ_TJ.cfg36_eq
        iqa_ctrl0 = 4

        ATC1.ATC_TOP.ACIOPHY.ACIOPHY_LANE1.AUSPMA.AUSPMA_RX.AUSPMA_RX_EQ.AUSPMA_RX_EQ_TJ.cfg38_eq
        iqa_ctrl12 = 0x49e
        '''
        # ATC1.ATC_TOP.ACIOPHY.ACIOPHY_LANE1.AUSPMA.AUSPMA_RX.AUSPMA_RX_EQ.AUSPMA_RX_EQ_TJ.cfg17_eq
        #         seq_b_eng1 = 5
        self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG17_EQ'], 0, 4, 5)
        self.set_bits(self.LANE0_RP_OFFSET +self.lane_offset+AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG17_EQ'], 0, 4, 5)

        # ATC1.ATC_TOP.ACIOPHY.ACIOPHY_LANE1.AUSPMA.AUSPMA_RX.AUSPMA_RX_EQ.AUSPMA_RX_EQ_TJ.cfg17_eq
        #         seq_b_eng2 = 2
        self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG17_EQ'], 4, 4, 2)
        self.set_bits(
            self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG17_EQ'], 4, 4,
            2)

        # ATC1.ATC_TOP.ACIOPHY.ACIOPHY_LANE1.AUSPMA.AUSPMA_RX.AUSPMA_RX_EQ.AUSPMA_RX_EQ_TJ.cfg43_eq
        #         err_th0 = 0x3e8
        self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG43_EQ'], 20, 12, 0x64)
        self.set_bits(
            self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG43_EQ'], 20, 12, 0x64)

        # ATC1.ATC_TOP.ACIOPHY.ACIOPHY_LANE1.AUSPMA.AUSPMA_RX.AUSPMA_RX_EQ.AUSPMA_RX_EQ_TJ.cfg43_eq
        #         ui_th = 0xf4240
        self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG43_EQ'], 0, 20, 0xf4240)
        self.set_bits(
            self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG43_EQ'], 0,
            20, 0xf4240)

        # ATC1.ATC_TOP.ACIOPHY.ACIOPHY_LANE1.AUSPMA.AUSPMA_RX.AUSPMA_RX_EQ.AUSPMA_RX_EQ_TJ.cfg44_eq
        #         Err_th1 = 0x2710
        self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG44_EQ'], 0, 12, 0x2710)
        self.set_bits(
            self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG44_EQ'], 0,
            12, 0x2710)

        # ATC1.ATC_TOP.ACIOPHY.ACIOPHY_LANE1.AUSPMA.AUSPMA_RX.AUSPMA_RX_EQ.AUSPMA_RX_EQ_TJ.cfg36_eq
        #         iqa_ctrl0 = 4
        self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG36_EQ'], 0, 4, 4)
        self.set_bits(
            self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG36_EQ'], 0,
            4, 4)

        # ATC1.ATC_TOP.ACIOPHY.ACIOPHY_LANE1.AUSPMA.AUSPMA_RX.AUSPMA_RX_EQ.AUSPMA_RX_EQ_TJ.cfg38_eq
        #         iqa_ctrl12 = 0x49e
        self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG38_EQ'], 19, 12, 0x49e)
        self.set_bits(
            self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG38_EQ'], 19,
            12, 0x49e)


    def set_adaptation_dfe(self):
        if bool(self.dfe_off) is True:
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DFE_CTRL10'], 3, 5, 0)
            self.set_bits(self.LANE0_RP_OFFSET + self.lane_offset +
                          AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DFE_CTRL10'], 3, 5, 0)
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DFE_CTRL10'], 11, 5, 0)
            self.set_bits(self.LANE0_RP_OFFSET + self.lane_offset +
                          AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DFE_CTRL10'], 11, 5, 0)
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DFE_CTRL10'], 19, 5, 0)
            self.set_bits(self.LANE0_RP_OFFSET + self.lane_offset +
                          AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DFE_CTRL10'], 19, 5, 0)
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DFE_CTRL10'], 8, 1, 1)
            self.set_bits(self.LANE0_RP_OFFSET + self.lane_offset +
                          AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DFE_CTRL10'], 8, 1, 1)
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DFE_CTRL10'], 16, 1, 1)
            self.set_bits(self.LANE0_RP_OFFSET + self.lane_offset +
                          AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DFE_CTRL10'], 16, 1, 1)
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DFE_CTRL10'], 24, 1, 1)
            self.set_bits(self.LANE0_RP_OFFSET + self.lane_offset +
                          AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DFE_CTRL10'], 24, 1, 1)
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DFE_CTRL11'], 7, 5, 0)
            self.set_bits(self.LANE0_RP_OFFSET + self.lane_offset +
                          AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DFE_CTRL11'], 7, 5, 0)
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DFE_CTRL11'], 12, 1, 1)
            self.set_bits(self.LANE0_RP_OFFSET + self.lane_offset +
                          AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DFE_CTRL11'], 12, 1, 1)
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_1'], 20, 5, 0)
            self.set_bits(
                self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_1'],
                20, 5, 0)
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_1'], 25, 1, 1)
            self.set_bits(self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_1'], 25, 1, 1)
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_1'], 26, 5, 0)
            self.set_bits(
                self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_1'],
                26, 5, 0)
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_1'], 31, 1, 1)
            self.set_bits(self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_1'], 31, 1, 1)

            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_2'], 0, 5, 0)
            self.set_bits(
                self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_2'], 0, 5,
                0)
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_2'], 5, 1, 1)
            self.set_bits(
                self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_2'], 5, 1,
                1)
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_2'], 6, 5, 0)
            self.set_bits(
                self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_2'], 6, 5,
                0)
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_2'], 11, 1, 1)
            self.set_bits(
                self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_2'], 11, 1,
                1)
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_2'], 12, 5, 0)
            self.set_bits(
                self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_2'], 12, 5,
                0)
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_2'], 17, 1, 1)
            self.set_bits(
                self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_2'], 17, 1,
                1)
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_2'], 18, 5, 0)
            self.set_bits(
                self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_2'], 18, 5,
                0)
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_2'], 23, 1, 1)
            self.set_bits(
                self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_2'], 23, 1,
                1)
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_2'], 24, 5, 0)
            self.set_bits(
                self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_2'], 24, 5,
                0)
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_2'], 29, 1, 1)
            self.set_bits(
                self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_2'], 29, 1,
                1)
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_3'], 0, 5, 0)
            self.set_bits(
                self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_3'], 0, 5,
                0)
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_3'], 5, 1, 1)
            self.set_bits(
                self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_3'], 5, 1,
                1)
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DFE_CTRL11'], 15, 5, 0)
            self.set_bits(self.LANE0_RP_OFFSET + self.lane_offset +
                          AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DFE_CTRL11'], 15, 5, 0)
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DFE_CTRL11'], 20, 1, 1)
            self.set_bits(self.LANE0_RP_OFFSET + self.lane_offset +
                          AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DFE_CTRL11'], 20, 1, 1)
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_3'], 6, 5, 0)
            self.set_bits(
                self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_3'], 6, 5,
                0)
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_3'], 11, 1, 1)
            self.set_bits(
                self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_3'], 11, 1,
                1)
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_3'], 12, 5, 0)
            self.set_bits(
                self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_3'], 12, 5,
                0)
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_3'], 17, 1, 1)
            self.set_bits(
                self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_3'], 17, 1,
                1)
        else:
            pass

    def set_rc(self, figure_of_merit):
        if bool(self.ctle_sweep) is True:
            self.r = figure_of_merit[0]
            self.c = figure_of_merit[1]
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_1'], 4, 1, 1)
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_1'], 14, 1, 1)
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_1'], 19, 1, 1)
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_1'], 9, 1, 1)
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_CTLE_CTRL2'], 4, 1, 1)
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_CTLE_CTRL2'], 18, 1, 1)
            self.set_bits(
                self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_1'], 4,
                1, 1)
            self.set_bits(
                self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_1'],
                14, 1, 1)
            self.set_bits(
                self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_1'],
                19, 1, 1)
            self.set_bits(
                self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_1'], 9,
                1, 1)
            self.set_bits(
                self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_CTLE_CTRL2'], 4, 1,
                1)
            self.set_bits(
                self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_CTLE_CTRL2'], 18, 1,
                1)

            #   C override
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_1'], 0, 4,
                          self.dec2gray(self.c))
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_1'], 5, 4,
                          self.dec2gray(self.c))
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_CTLE_CTRL2'], 0, 4,
                          self.dec2gray(self.c))
            self.set_bits(
                self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_1'], 0,
                4,
                self.dec2gray(self.c))
            self.set_bits(
                self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_1'], 5,
                4,
                self.dec2gray(self.c))
            self.set_bits(
                self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_CTLE_CTRL2'], 0, 4,
                self.dec2gray(self.c))
            #   R override
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_CTLE_CTRL2'], 14, 4,
                          self.dec2gray(self.r))
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_1'], 10, 4,
                          self.dec2gray(self.r))
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_1'], 15, 4,
                          self.dec2gray(self.r))
            self.set_bits(
                self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_CTLE_CTRL2'], 14, 4,
                self.dec2gray(self.r))
            self.set_bits(
                self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_1'],
                10, 4,
                self.dec2gray(self.r))
            self.set_bits(
                self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RXA_EQ_CTRL_G3G4_1'],
                15, 4,
                self.dec2gray(self.r))
        else:
            pass

    def set_adaptation(self, figure_of_merit):
        """Set the Adaptation Type (if applicable)"""
        if bool(self.doe) is True:
            protocol = None
            if self.gen_version is not None:
                # 'usb' or 'cio10g' or 'cio20g' or 'ciodp' or 'dp'
                if self.gen_version in ["CIO_GEN3"]:
                    protocol = "cio20g"
                elif self.gen_version in ["CIO_GEN2", "USB_10G"]:
                    protocol = "cio10g"
                elif self.gen_version in ["DP_HBR2", "DP_HBR3"]:
                    protocol = "ciodp"
                elif self.gen_version in ["DP_RBR", "DP_HBR"]:
                    protocol = "dp"
                else:
                    protocol = "usb"

            for port in range(0, len(self.root_port), 1):
                self.port_num = self.root_port[port]
                self.calculate_base_offset(self.port_num)
                # self.set_adaptation_ace()
                run("device -k usbphy -e select {}".format(self.port_num))
                if protocol is not None:
                    run("device -k usbphy -e powerup {}".format(protocol))
                else:
                    run("device -k usbphy -e powerup")
                self.LANE0_RP_OFFSET = self.soc_atc0_offset + self.die_offset_addr + (self.port_num - (self.die_number * self.die_length)) * self.RP_OFFSET + self.atc_top_offset
                self.set_adaptation_dfe()

                print(self.ctle_sweep)
                # self.set_iqa_dfe()
                self.set_rc(figure_of_merit)
                if protocol is not None:
                    run("device -k usbphy -e linktrain {}".format(protocol))
                else:
                    run("device -k usbphy -e linktrain")

        else:
            return 1

    def apply_settings(self, retrain=True):
        """Apply EQ and other settings, retrain (if applicable)"""

    def ensure_link(self):
        """Check Link meets Speed / Width requirements"""

    def disable_power_management(self):
        """Disable Power Management Modes"""
        self.log_msg("   Disable Power Management")

    def set_traffic_type(self, traffic_type):
        """Select the Traffic type (Live, PRBS, etc)"""

    def calculate_base_offset(self, port_num):
        """Calculate the base atc offset based on the port_num"""
        self.die_offset_addr = 0
        # if die location isn't provided in project defines, we assume the project is single die.
        if self.die_location:
            for key, value in self.die_location.items():
                # grab which die the port_num is on
                if str(port_num) in value:
                    if self.die_offset is not None:
                        die_offset_addr = int(key) * self.die_offset
                        self.die_offset_addr = die_offset_addr
                        self.die_number = int(key)
                        print("   Found Valid Key: {} in Die Location: {} for Port Num: {} New Die Offset ADDR: {}   ".format(key, self.die_location, port_num, self.die_offset_addr))
                        self.log_msg("   Found Valid Key: {} in Die Location: {} for Port Num: {}   ".format(key, self.die_location, port_num))
                        return
                    else:
                        # error if we have multiple dies but no offset for between the dies
                        print("    Die Location Exists (i.e. the product has multiple dies) but no offsett address provided    ")
                        raise("    Die Location Exists (i.e. the product has multiple dies) but no offsett address provided    ")
            print("    Port Number: {} not found in Die Location: {}    ".format(port_num, self.die_location))
            raise("    Port Number: {} not found in Die Location: {}    ".format(port_num, self.die_location))
        # else:
            # print("    No Die Location, Moving On     ")
            # self.log_msg("    No Die Location, Moving On     ")


    def select_lane(self, lane):
        """Select a Lane"""
        self.current_lane = lane
        self.port_num = self.root_port[0]
        self.calculate_base_offset(self.port_num)
        self.LANE_RP_OFFSET = self.soc_atc0_offset + self.die_offset_addr + \
                              (self.port_num - (self.die_number * self.die_length)) * self.RP_OFFSET + \
                              self.atc_top_offset + \
                               self.current_lane * self.lane_offset
        self.RP_OFFSET_ACIO = self.soc_atc0_offset + self.die_offset_addr + \
                              self.atc_acio_offset +\
                              (self.port_num - (self.die_number * self.die_length)) * self.RP_OFFSET
        self.log_msg("   Selecting Lane {} with LANE RP OFFSET: {} and RP OFFSET ACIO {}".format(lane, self.LANE_RP_OFFSET, self.RP_OFFSET_ACIO))

    def select_lane_rp(self, lane):
        """Select a Lane"""
        self.current_lane = lane
        self.calculate_base_offset(self.port_num)
        self.LANE_RP_OFFSET = self.soc_atc0_offset + self.die_offset_addr + \
                              (self.port_num - (self.die_number * self.die_length)) * self.RP_OFFSET + \
                              self.atc_top_offset + \
                               self.current_lane * self.lane_offset
        self.RP_OFFSET_ACIO = self.soc_atc0_offset + self.die_offset_addr + \
                              self.atc_acio_offset +\
                              (self.port_num - (self.die_number * self.die_length)) * self.RP_OFFSET

    def configure_phy(self):
        """Configure the PHY Settings, Overrides, ECO, etc"""

    def setup_margining(self):
        """Configure Margin Settings"""

        for port in range(0, len(self.root_port), 1):
            self.port_num = self.root_port[port]
            for lane in range(0, self.LANE_COUNT, 1):
                self.select_lane_rp(lane)
                self.read_register(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG27_EQ'])
                self.read_register(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DESER_CTRL9'])
                self.read_register(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DCOPI_CTRL6'])

                #   Check Link status
                data = self.read_register(self.LANE_RP_OFFSET +
                                          AUSPMA_LANE0_ADAPTATION_CHECK["APCIE_DOWN_AUS_LANE0_AUSPMA_RX_TOP_PMAFSM_REG0"])
                self.log_reg("PMAFSM_REG0 is {}".format(data))
                data = self.read_register(self.LANE_RP_OFFSET +
                                          AUSPMA_LANE0_ADAPTATION_CHECK["APCIE_DOWN_AUS_LANE0_AUSPMA_RX_TOP_PMAFSM_REG1"])
                self.log_reg("PMAFSM_REG1 is {}".format(data))

                #   Override for eclk, eclkb and and gray position overrides

                self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DCOPI_CTRL6'], 25,
                              1, 1)
                self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DCOPI_CTRL6'], 24,
                              1, 1)
                self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DCOPI_CTRL6'], 23,
                              1, 1)
                self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DCOPI_CTRL6'], 15,
                              1, 1)


                #    Overrides for enabling voltage scan, and setting the voltage to the the center of the eye
                self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DESER_CTRL9'], 22,
                              1, 1)
                self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DESER_CTRL9'], 21,
                              1, 1)
                self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DESER_CTRL9'], 20,
                              1, 1)
                self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DESER_CTRL9'], 19,
                              1, 1)
                self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DESER_CTRL9'], 29,
                              1, 1)
                self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DESER_CTRL9'], 23, 6,
                              self.int2sa_vos_code(0))
                self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DFE_CTRL10'], 0, 1, 1)

                self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DFE_CTRL11'], 3, 1, 1)
                self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DFE_CTRL11'], 1, 2, 3)

                self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DESER_CTRL9'], 14,
                              1, 1)
                self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DESER_CTRL9'], 16,
                              1, 1)
                self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DESER_CTRL9'], 15,
                              1, 1)
                self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DESER_CTRL9'], 17,
                              1, 1)

                #  Error mask override and clearing the error accumulator enabling register
                self.write_register(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG46_EQ'], 0)
                print("Setting error_mask to ", self.error_mask)
                self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG42_EQ'], 3, 1, 1)
                self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG42_EQ'], 1, 2, self.error_mask)

    def _update_status(self):
        """Fake Progress updater"""
        for i in range(0, 101):
            self._fake_progress = i
            time.sleep(0.05)

    def padded_hex(self, i, l):
        given_int = i
        given_len = l

        hex_result = hex(given_int)[2:]  # remove '0x' from beginning of str
        num_hex_chars = len(hex_result)
        extra_zeros = '0' * (given_len - num_hex_chars)  # may not get used..

        return ('0x' + hex_result if num_hex_chars == given_len else
                '?' * given_len if num_hex_chars > given_len else
                '0x' + extra_zeros + hex_result if num_hex_chars < given_len else
                None)

    def xor_err_counter_read(self):
        # Enable capture of D XOR E accumulator output
        data = []
        for port in range(0, len(self.root_port), 1):
            self.port_num = self.root_port[port]
            for lane in range(0, self.LANE_COUNT, 1):
                self.select_lane_rp(lane)
                self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG46_EQ'], 20, 1, 1)
        time.sleep_ms(self.duration_ms)
        #  Read the error register
        for port in range(0, len(self.root_port), 1):
            self.port_num = self.root_port[port]
            data.append([])
            for lane in range(0, self.LANE_COUNT, 1):
                self.select_lane_rp(lane)
                self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG46_EQ'], 19, 1,
                              1)
                data[port].append(self.get_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG44_EQ'], 12, 20))
                #  Disable Error accumulator enable
                self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG46_EQ'], 19, 1, 0)
                self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG46_EQ'], 20, 1, 0)
        return data

    def start_margining(self):
        """Start the Margining"""
        self.res_vol_north_data = []
        self.res_vol_south_data = []
        self.res_pi_east_data = []
        self.res_pi_west_data = []
        self.res_vol_north_data_1 = []
        self.res_vol_south_data_1 = []
        self.res_pi_east_data_1 = []
        self.res_pi_west_data_1 = []
        pi_idx = list(range(self.min_x, self.max_x))
        print(self.mid_x)
        for port in range(0, len(self.root_port), 1):
            self.port_num = self.root_port[port]
            self.res_vol_north_data.append([])
            self.res_vol_south_data.append([])
            self.res_pi_west_data.append([])
            self.res_pi_east_data.append([])
            self.res_vol_north_data_1.append([])
            self.res_vol_south_data_1.append([])
            self.res_pi_west_data_1.append([])
            self.res_pi_east_data_1.append([])
            for lane in range(0, self.LANE_COUNT, 1):
                self.select_lane_rp(lane)
                self.res_vol_north_data[port].append([])
                self.res_vol_south_data[port].append([])
                self.res_pi_west_data[port].append([])
                self.res_pi_east_data[port].append([])
                self.res_vol_north_data_1[port].append([])
                self.res_vol_south_data_1[port].append([])
                self.res_pi_west_data_1[port].append([])
                self.res_pi_east_data_1[port].append([])
                for i in range(self.mid_x[port][self.current_lane], pi_idx[0], -1):
                    #  Make sure you bring to the edge of the PI code before scan, and only move by one step at a time.
                    self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DCOPI_CTRL6'], 16,
                          7,
                          self.dec2gray(i))
                    self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DCOPI_CTRL6'], 8,
                          7,
                          self.dec2gray(i))
        if self.axis_only is True:
            self.mid_y = (self.min_y + self.max_y) // 2
            # Pi scan, again make sure you only move 1 step at a time
            for pi_val in pi_idx:
                for port in range(0, len(self.root_port), 1):
                    self.port_num = self.root_port[port]
                    for lane in range(0, self.LANE_COUNT, 1):
                        self.select_lane_rp(lane)
                        self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DCOPI_CTRL6'],
                              16, 7,
                              self.dec2gray(pi_val))
                        self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DCOPI_CTRL6'],
                              8, 7,
                              self.dec2gray(pi_val))

                error_data = self.xor_err_counter_read()
                print(f"Pi Val: {pi_val} Error Data: {error_data}")

                for port in range(0, len(self.root_port), 1):
                    self.port_num = self.root_port[port]
                    for lane in range(0, self.LANE_COUNT, 1):
                        self.select_lane_rp(lane)
                        print(f"Pi Val: {pi_val} Mid X: {self.mid_x[port][self.current_lane]}")
                        if pi_val <= self.mid_x[port][self.current_lane]:
                            self.res_pi_west_data[port][self.current_lane].\
                                                                    append(error_data[port][self.current_lane])
                            self.res_pi_west_data_1[port][self.current_lane].\
                                                                    append(error_data[port][self.current_lane])
                            if pi_val == self.mid_x[port][self.current_lane]:
                                self.res_pi_east_data[port][self.current_lane].\
                                                                    append(error_data[port][self.current_lane])
                                self.res_pi_east_data_1[port][self.current_lane].\
                                                                    append(error_data[port][self.current_lane])

                        elif pi_val > self.mid_x[port][self.current_lane]:
                            self.res_pi_east_data[port][self.current_lane].\
                                                                    append(error_data[port][self.current_lane])
                            self.res_pi_east_data_1[port][self.current_lane].\
                                                                    append(error_data[port][self.current_lane])
            # Bring pi back to mid, for voltage scan.
            for port in range(0, len(self.root_port), 1):
                self.port_num = self.root_port[port]
                for lane in range(0, self.LANE_COUNT, 1):
                    self.select_lane_rp(lane)
                    for j in range(self.max_x, self.mid_x[port][self.current_lane] - 1, -1):
                        self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DCOPI_CTRL6'],
                              16, 7, self.dec2gray(j))
                        self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DCOPI_CTRL6'],
                              8, 7, self.dec2gray(j))
                        self.read_register(self.LANE_RP_OFFSET +
                                   AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DCOPI_CTRL6'])
            # Do the voltage scan
            for vol in range(self.min_y, self.max_y + 1, self.step_y):
                for port in range(0, len(self.root_port), 1):
                    self.port_num = self.root_port[port]
                    for lane in range(0, self.LANE_COUNT, 1):
                        self.select_lane_rp(lane)
                        self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DESER_CTRL9'],
                              23, 6, self.int2sa_vos_code(vol))
                        self.read_register(self.LANE_RP_OFFSET +
                                   AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DESER_CTRL9'])
                if vol <= self.mid_y:
                    error_data = self.xor_err_counter_read()
                    for port in range(0, len(self.root_port), 1):
                        self.port_num = self.root_port[port]
                        for lane in range(0, self.LANE_COUNT, 1):
                            self.select_lane_rp(lane)
                            self.res_vol_south_data[port][self.current_lane].\
                                                                    append(error_data[port][self.current_lane])
                            self.res_vol_south_data_1[port][self.current_lane].\
                                                                    append(error_data[port][self.current_lane])
                    if vol == self.mid_y:
                        for port in range(0, len(self.root_port), 1):
                            self.port_num = self.root_port[port]
                            for lane in range(0, self.LANE_COUNT, 1):
                                self.select_lane_rp(lane)
                                self.res_vol_north_data[port][self.current_lane].\
                                                                    append(error_data[port][self.current_lane])
                                self.res_vol_north_data_1[port][self.current_lane].append(error_data[port][self.current_lane])
                elif vol > self.mid_y:
                    error_data = self.xor_err_counter_read()
                    for port in range(0, len(self.root_port), 1):
                        self.port_num = self.root_port[port]
                        for lane in range(0, self.LANE_COUNT, 1):
                            self.select_lane_rp(lane)
                            self.res_vol_north_data[port][self.current_lane].\
                                                                    append(error_data[port][self.current_lane])
                            self.res_vol_north_data_1[port][self.current_lane].\
                                                                    append(error_data[port][self.current_lane])

        # else:
        #     #self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG44_EQ'], 0, 12, 2)
        #     #self.set_bits(`self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DESER_CTRL9'], 29,
        #                  # 1, 1)
        #    # for vol in range(self.min_y, self.max_y, self.step_y):
        #         #self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DESER_CTRL9'], 23, 6, self.int2sa_vos_code(vol))
        #     for pi_val in pi_idx:
        #         self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DCOPI_CTRL6'], 16, 7, self.dec2gray(pi_val))
        #         self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DCOPI_CTRL6'], 8, 7, self.dec2gray(pi_val))
        #         for vol in range(self.min_y, self.max_y, self.step_y):
        #             self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DESER_CTRL9'], 23, 6,
        #             self.int2sa_vos_code(vol))
        #             error_data = self.xor_err_counter_read()
        #             self.res_data.append(error_data)
        #
        #         for j in range(pi_val, pi_idx[0], -1):
        #              self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DCOPI_CTRL6'], 16, 7,
        #                        self.dec2gray(j))
        #              self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DCOPI_CTRL6'], 8, 7,
        #                        self.dec2gray(j))
        else:
            raise Exception("Full scan not vetted out")

    def dump_registers(self, initial=True):
        """Dump Static Registers check adaptation converged values"""
        # Set below to make sure h0,h1 etc are read right
        # Convert CTLE and DFE to actual training parameters
        # Read out dclk, xclk, dclkb and xclkb positions
        if initial is True:
            self.mid_x = []
            self.mid_x_dclkb = []
            for port in range(0,len(self.root_port),1):
                self.port_num = self.root_port[port]
                self.mid_x.append([])
                self.mid_x_dclkb.append([])

                for lane in range(self.LANE_COUNT):
                    output = run(
                        f"nandfs:AppleInternal\Diags\Apps\TbtUtil.efi --read --rid {self.port_num} --port {lane+1}  --space 1 --offset 0x46")

                    if "Success" in output:
                        for line in output.split("\n"):
                            try:
                                if "Register offset 0x46 Port" in line:
                                    value = int(line.split("Value ")[1], 16)
                                    self.log_msg(f"TxFFE_remote={value}")
                                    original_value = value
                                    value = f"{value:32b}"
                                    value = int(value[8:16], 2)
                                    print("txffe_remote=", hex(value))
                            except Exception as e:
                                print(f"Tried to parse TxFFE_remote but failed! {e}")
                                value = -1
                                original_value = -1
                    else:
                        print("Command failed to read register")
                        value = -1
                        original_value = -1

                    self.log_key(key=f"port:{self.port_num}_lane:{lane}_txffe_remote",
                                 value=value,
                                 units='')
                    self.log_key(key=f"port:{self.port_num}_lane:{lane}_txffe_remote_raw",
                                 value=original_value,
                                 units='')
                    self.select_lane_rp(lane)
                    self.mid_x[port].append([])
                    self.mid_x_dclkb[port].append([])
                    cs_ticks = self.gray2dec(self.get_bits((self.LANE_RP_OFFSET +
                                                            AUS_LANE0_DEBUG[
                                                                'APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP1']),
                                                           4,
                                                           4))
                    self.log_key(key="port:{}_lane:{}_cs_ticks".format(
                        self.port_num,
                        self.current_lane),
                        value=cs_ticks,
                        units='ticks')
                    cs = CONVERSION_OFFSET_FACTORS["c"] + CONVERSION_MULTIPLICATION_FACTORS["c"] * cs_ticks
                    self.log_key(key="port:{}_lane:{}_cs".format(
                        self.port_num,
                        self.current_lane),
                        value=cs,
                        units='db')
                    rs_ticks = self.gray2dec(self.get_bits(self.LANE_RP_OFFSET +
                                                           AUS_LANE0_DEBUG[
                                                               'APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP1'], 0,
                                                           4))
                    self.r = rs_ticks
                    self.c = cs_ticks
                    self.log_key(key="port:{}_lane:{}_rs_ticks".format(
                        self.port_num,
                        self.current_lane),
                        value=rs_ticks,
                        units='ticks')
                    rs = CONVERSION_OFFSET_FACTORS["r"] + CONVERSION_MULTIPLICATION_FACTORS["r"] * rs_ticks
                    self.log_key(key="port:{}_lane:{}_rs".format(
                        self.port_num,
                        self.current_lane),
                        value=rs,
                        units='db')
                    h1 = CONVERSION_MULTIPLICATION_FACTORS["h1"] * \
                         self.gray2dec(self.get_bits(self.LANE_RP_OFFSET +
                                                     AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP1'], 8,
                                                     5))
                    self.log_key(key="port:{}_lane:{}_h1".format(
                        self.port_num,
                        self.current_lane),
                        value=h1,
                        units='mV')
                    sign = self.get_bits(self.LANE_RP_OFFSET +
                                                     AUS_LANE0_DEBUG[
                                                         'APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP1'], 16,
                                                     1)
                    if sign is 1:
                        h2_sign = -1
                    else:
                        h2_sign = 1
                    h2 = h2_sign * CONVERSION_MULTIPLICATION_FACTORS["h2"] * \
                         self.gray2dec(self.get_bits(self.LANE_RP_OFFSET +
                                                     AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP1'], 13,
                                                     3))
                    self.log_key(key="port:{}_lane:{}_h2".format(
                        self.port_num,
                        self.current_lane),
                        value=h2,
                        units='mV')
                    sign_2 = self.get_bits(self.LANE_RP_OFFSET +
                                                     AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP1'], 20,
                                                     1)
                    if sign_2 is 1:
                        h3_sign = -1
                    else:
                        h3_sign = 1
                    h3 = h3_sign * CONVERSION_MULTIPLICATION_FACTORS["h3"] * \
                         self.gray2dec(self.get_bits(self.LANE_RP_OFFSET +
                                                     AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP1'], 17,
                                                     3))
                    self.log_key(key="port:{}_lane:{}_h3".format(
                        self.port_num,
                        self.current_lane),
                        value=h3,
                        units='mV')
                    sign_4 = self.get_bits(self.LANE_RP_OFFSET +
                                                     AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP1'], 24,
                                                     1)
                    if sign_4 is 1:
                        h4_sign = -1
                    else:
                        h4_sign = 1
                    h4 = h4_sign * CONVERSION_MULTIPLICATION_FACTORS["h4"] * \
                         self.gray2dec(self.get_bits(self.LANE_RP_OFFSET +
                                                     AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP1'], 21,
                                                     3))
                    self.log_key(key="port:{}_lane:{}_h4".format(
                        self.port_num,
                        self.current_lane),
                        value=h4,
                        units='mV')
                    sign_5 = self.get_bits(self.LANE_RP_OFFSET +
                                                     AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP1'], 28,
                                                     1)
                    if sign_5 is 1:
                        h5_sign = -1
                    else:
                        h5_sign = 1

                    h5 = h5_sign * CONVERSION_MULTIPLICATION_FACTORS["h5"] * \
                         self.gray2dec(self.get_bits(self.LANE_RP_OFFSET +
                                                     AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP1'], 25,
                                                     3))
                    self.log_key(key="port:{}_lane:{}_h5".format(
                        self.port_num,
                        self.current_lane),
                        value=h5,
                        units='mV')
                    aus_eq_ctrl_raw_cap_dclk_pos = self.get_bits(
                        self.LANE_RP_OFFSET +
                        AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP2'],
                        14, 7)
                    print(f"Setting Mid X: {self.gray2dec(aus_eq_ctrl_raw_cap_dclk_pos)}")
                    self.mid_x[port][self.current_lane] = self.gray2dec(aus_eq_ctrl_raw_cap_dclk_pos)
                    self.log_key(key="port:{}_lane:{}_aus_eq_ctrl_raw_cap_dclk_pos_raw".format(
                        self.port_num,
                        self.current_lane),
                        value=self.gray2dec(aus_eq_ctrl_raw_cap_dclk_pos), units='ticks')

                    aus_eq_ctrl_raw_cap_dclkb_pos = self.get_bits(
                        self.LANE_RP_OFFSET +
                        AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP2'],
                        21, 7)
                    self.mid_x_dclkb[port][self.current_lane] =self.gray2dec(aus_eq_ctrl_raw_cap_dclkb_pos)


                    self.log_key(key="port:{}_lane:{}_aus_eq_ctrl_raw_cap_dclkb_pos_raw".format(
                        self.port_num,
                        self.current_lane),
                        value=self.gray2dec(aus_eq_ctrl_raw_cap_dclkb_pos), units='ticks')

                    aus_eq_ctrl_raw_cap_xclk_pos = self.get_bits(
                        self.LANE_RP_OFFSET +
                        AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP2'],
                        0, 7)
                    self.log_key(key="port:{}_lane:{}_aus_eq_ctrl_raw_cap_xclk_pos_raw".format(
                        self.port_num,
                        self.current_lane),
                        value=self.gray2dec(aus_eq_ctrl_raw_cap_xclk_pos), units='ticks')
                    aus_eq_ctrl_raw_cap_xclkb_pos = self.get_bits(
                        self.LANE_RP_OFFSET +
                        AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_EQ_CTRL_RAW_CAP2'],
                        7, 7)
                    self.log_key(key="port:{}_lane:{}_aus_eq_ctrl_raw_cap_xclkb_pos_raw".format(
                        self.port_num,
                        self.current_lane),
                        value=self.gray2dec(aus_eq_ctrl_raw_cap_xclkb_pos), units='ticks')
        elif initial is False:
            print("Initial is False")

    def calculate_eye(self):
        """Calculate the Eye Diagram for axis only"""
        # Get the data for the lane (list of margin values)
        for port in range(0, len(self.root_port), 1):
            self.port_num =self.root_port[port]
            print(f"Port Num: {port} Lane Count: {self.LANE_COUNT}")
            self.eye_height = {}
            self.eye_width = {}
            self.eye_height_ticks = {}
            self.eye_width_ticks = {}
            for lane in range(0, self.LANE_COUNT, 1):
                self.current_lane = lane
                if self.axis_only is True:
                    data = self.res_pi_west_data[port][self.current_lane]
                else:
                    data = self.res_data[self.current_lane]
                print(f"Data: {data}")
                if len(data) > 0:
                    self.seq_log.info("      Dumping eye for lane {}".format(self.current_lane))
                    print(self.mid_x)
                    north, south, east, west = self.mid_y, self.mid_y, self.mid_x[port][self.current_lane], self.mid_x[port][self.current_lane]

                    # Visual diagram and Raw diagram
                    diagram, coords = "", ""

                    # Iterate thru the coordinate Top Left to Bottom Right
                    if self.axis_only is True:
                        for y in range(self.min_y, self.max_y, 1):
                            for x in range(self.min_x, self.max_x, 1):
                                if y != self.mid_y and x != self.mid_x[port][self.current_lane]:
                                    diagram += " "
                                    coords += "{}".format("     ") if x == self.max_x else ",{}". \
                                        format("     ")
                                else:
                                    if y == self.mid_y:
                                        if x <= self.mid_x[port][self.current_lane]:
                                            margin = self.res_pi_west_data[port][self.current_lane].pop(0)
                                            if x == self.mid_x[port][self.current_lane]:
                                                self.res_pi_east_data[port][self.current_lane].pop(0)
                                        else:
                                            margin = self.res_pi_east_data[port][self.current_lane].pop(0)
                                    else:
                                        if y <= self.mid_y:
                                            margin = self.res_vol_south_data[port][self.current_lane].pop(0)
                                            if y == self.mid_y:
                                                self.res_vol_north_data[port][self.current_lane].pop(0)
                                        else:
                                            margin = self.res_vol_north_data[port][self.current_lane].pop(0)
                                    # Add to the Coordinate file
                                    if margin <= self.threshold:
                                        diagram += "0"
                                    else:
                                        diagram += "1"
                                    coords += "{}".format(self.padded_hex(margin, 5))
                            coords += "\n"
                            diagram += "\n"
                        margin_south = self.res_vol_south_data_1[port][self.current_lane].pop()
                        if margin_south <= self.threshold:
                            # raise Exception(" DAC 0 0s have errors")
                            south = self.mid_y
                            while margin_south <= self.threshold and abs(south) < abs(self.min_y):
                                margin_south = self.res_vol_south_data_1[port][self.current_lane].pop()
                                south = south - 1
                        else:
                            south = self.mid_y
                        margin_north = self.res_vol_north_data_1[port][self.current_lane].pop(0)
                        if margin_north <= self.threshold:
                            # raise Exception(" DAC 0 0s have errors")
                            north = self.mid_y
                            while margin_north <= self.threshold and north < self.max_y:
                                margin_north = self.res_vol_north_data_1[port][self.current_lane].pop(0)
                                north = north + 1
                        else:
                            north = self.mid_y
                        margin_west = self.res_pi_west_data_1[port][self.current_lane].pop()
                        if margin_west <= self.threshold:
                            # raise Exception(" DAC 0 0s have errors")
                            west = self.mid_x[port][self.current_lane]
                            while margin_west <= self.threshold and west > self.min_x:
                                margin_west = self.res_pi_west_data_1[port][self.current_lane].pop()
                                west = west - 1
                        else:
                            west = self.mid_x[port][self.current_lane]
                        margin_east = self.res_pi_east_data_1[port][self.current_lane].pop(0)
                        if margin_east <= self.threshold:
                            # raise Exception(" DAC 0 0s have errors")
                            east = self.mid_x[port][self.current_lane]
                            while margin_east <= self.threshold and east < self.max_x-1:
                                margin_east = self.res_pi_east_data_1[port][self.current_lane].pop(0)
                                east = east + 1
                        else:
                            east = self.mid_x[port][self.current_lane]
                    else:
                        # Iterate thru the coordinate Top Left to Bottom Right
                        for y in range(self.min_y, self.max_y, 1):
                            for x in range(self.min_x, self.max_x, 1):
                                margin = data.pop(0)
                                # Add to the Coordinate file
                                coords += "{}".format(self.padded_hex(margin, 5)) if x == self.max_x else ",{}". \
                                    format(self.padded_hex(margin, 5))

                                # Log only values below the threshold
                                if margin <= self.threshold:
                                    diagram += "0"
                                    # Set the North / South values
                                    south = y if y < south else south
                                    north = y if y > north else north

                                    # Set the East / West values
                                    west = x if x < west else west
                                    east = x if x > east else east
                                else:
                                    diagram += "1"

                            coords += "\n"
                            diagram += "\n"

                    # Write the coordinate and diagram files
                    self.write_coordinate_file(coords)
                    print(diagram)
                    self.write_eye_diagram_file(diagram)

                    # Set the Height / Width
                    # Read the converion factor for height and width
                    factor = self.get_bits(self.LANE_RP_OFFSET +
                                           AUSPMA_LANE0['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_SHM_RXA_DFE_CTRL11'], 1, 2)
                    if factor is 0:
                        mf = 0.5
                    elif factor is 1:
                        mf = 1
                    elif factor is 2:
                        mf = 1.5
                    else:
                        mf = 1.75
                    cio_gen = self.get_bits(self.RP_OFFSET_ACIO + ACIO_TOP['ACIO_TOP_ACIO_GLOBAL_CFG0'], 0, 2)

                    self.log_key(key="port:{}_lane:{}_rounded_nonrounded".format(
                        self.port_num,
                        self.current_lane),
                        value=cio_gen,
                        units='ticks')
                    if cio_gen is 0:
                        self.TICK_TO_FREQUENCY = 10 ** 12 / (10 * 10 ** 9 * 64)
                    elif cio_gen is 1:
                        self.TICK_TO_FREQUENCY = 10 ** 12 / (20 * 10 ** 9 * 64)
                    elif cio_gen is 2:
                        self.TICK_TO_FREQUENCY = 10 ** 12 / (10.3125 * 10 ** 9 * 64)
                    else:
                        self.TICK_TO_FREQUENCY = 10 ** 12 / (20.625 * 10 ** 9 * 64)

                    height = north + abs(south)
                    width = (east - west)
                    left_ew_ps = self.TICK_TO_FREQUENCY * (self.mid_x[port][self.current_lane] - west)
                    right_ew_ps = self.TICK_TO_FREQUENCY * (east - self.mid_x[port][self.current_lane])
                    left_ew_dclkb_ps = self.TICK_TO_FREQUENCY * (self.mid_x_dclkb[port][self.current_lane] - west)
                    right_ew_dclkb_ps = self.TICK_TO_FREQUENCY * (east - self.mid_x_dclkb[port][self.current_lane])

                    min_ew_ps = min(left_ew_ps, right_ew_ps, left_ew_dclkb_ps, right_ew_dclkb_ps)

                    if height >> 0 and width >> 0:
                        self.eye_height[self.current_lane] = self.TICK_TO_VOLTAGE * mf * (north + abs(south))
                        self.eye_width[self.current_lane] = self.TICK_TO_FREQUENCY * (east - west)
                        self.eye_height_ticks[self.current_lane] = north + abs(south)
                        self.eye_width_ticks[self.current_lane] = east - west
                    else:
                        if height >> 0:
                            self.eye_height[self.current_lane] = self.TICK_TO_VOLTAGE * mf * (north + abs(south))
                            self.eye_width[self.current_lane] = 0
                            self.eye_height_ticks[self.current_lane] = north + abs(south)
                            self.eye_width_ticks[self.current_lane] = 0
                        elif width >> 0:
                            self.eye_height[self.current_lane] = 0
                            self.eye_width[self.current_lane] = self.TICK_TO_FREQUENCY * (east - west)
                            self.eye_height_ticks[self.current_lane] = 0
                            self.eye_width_ticks[self.current_lane] = east - west
                        else:
                            self.eye_height[self.current_lane] = 0
                            self.eye_width[self.current_lane] = 0
                            self.eye_height_ticks[self.current_lane] = 0
                            self.eye_width_ticks[self.current_lane] = 0
                    # Log them to the result file
                    if self.doe is False:
                        self.r = 0
                        self.c = 0
                    self.log_key(key="port_{}_lane_{}_r{}_c{}_north_ticks".format(self.port_num,
                                                        self.current_lane, self.r, self.c), value=north, units='ticks')
                    self.log_key(key="port_{}_lane_{}_r{}_c{}_south_ticks".format(self.port_num,
                                                        self.current_lane, self.r, self.c), value=south, units='ticks')
                    self.log_key(key="port_{}_lane_{}_r{}_c{}_east_ticks".format(self.port_num,
                                                         self.current_lane, self.r, self.c), value=east, units='ticks')
                    self.log_key(key="port_{}_lane_{}_r{}_c{}_west_ticks".format(self.port_num,
                                                         self.current_lane, self.r, self.c), value=west, units='ticks')
                    self.log_key(key="port_{}_lane_{}_r{}_c{}_eh_mv".format(self.port_num,
                                self.current_lane, self.r, self.c), value=self.eye_height[self.current_lane], units='mV', upperlimit=self.eh_max, lowerlimit=self.eh_min)
                    self.log_key(key="port_{}_lane_{}_r{}_c{}_ew_ps".format(self.port_num,
                                self.current_lane,self.r, self.c), value=self.eye_width[self.current_lane], units='ps')
                    self.log_key(key="port_{}_lane_{}_r{}_c{}_left_ew_ps".format(self.port_num,
                                                                            self.current_lane, self.r, self.c),
                                 value=left_ew_ps, units='ps')
                    self.log_key(key="port_{}_lane_{}_r{}_c{}_right_ew_ps".format(self.port_num,
                                                                            self.current_lane, self.r, self.c),
                                 value=right_ew_ps, units='ps')
                    self.log_key(key="port_{}_lane_{}_r{}_c{}_left_dclkb_ew_ps".format(self.port_num,
                                                                            self.current_lane, self.r, self.c),
                                 value=left_ew_dclkb_ps, units='ps')
                    self.log_key(key="port_{}_lane_{}_r{}_c{}_right_dclkb_ew_ps".format(self.port_num,
                                                                            self.current_lane, self.r, self.c),
                                 value=right_ew_dclkb_ps, units='ps')
                    self.log_key(key="port_{}_lane_{}_r{}_c{}_leftright_min_ew_ps".format(self.port_num,
                                                                            self.current_lane, self.r, self.c),
                                 value=min_ew_ps, units='ps')
                    self.log_key(key="port_{}_lane_{}_r{}_c{}_leftright_2min_ew_ps".format(self.port_num,
                                                                            self.current_lane, self.r, self.c), upperlimit=self.ew_max, lowerlimit=self.ew_min,
                                 value=2 * min_ew_ps, units='ps')
                    self.log_key(key="port_{}_lane_{}_r{}_c{}_eh_ticks".format(self.port_num,
                                self.current_lane, self.r, self.c), value=self.eye_height_ticks[self.current_lane],
                                 units='ticks')
                    self.log_key(key="port_{}_lane_{}_r{}_c{}_ew_ticks".format(self.port_num,
                                self.current_lane, self.r, self.c), value=self.eye_width_ticks[self.current_lane],
                                 units='ticks')
                    self.log_msg("port_{}_lane {}_r{}_c{}: north = {}, south = {}, east = {}, west = {}, ns = {}mV, ew = {}ps".format(
                        self.port_num,
                        self.current_lane,
                        self.r,
                        self.c,
                        north,
                        south,
                        east,
                        west,
                        self.eye_height[self.current_lane],
                        self.eye_width[self.current_lane]
                    ))
                    print("port_{}_lane {}: north = {}, south = {}, east = {}, west = {}, ns = {}mV, ew = {}ps".format(
                        self.port_num,
                        self.current_lane,
                        north,
                        south,
                        east,
                        west,
                        self.eye_height[self.current_lane],
                        self.eye_width[self.current_lane]
                    ))
        if bool(self.doe) is True:
            run("device -k usbphy -e disable")

    def parse_margin_data(self):
        """Parse data to the necessary format(s)"""
        return 1

    def clean_up(self):
        """Clean up margining and reset the PHY"""
        if self.doe is True:
            run("device -k usbphy -e disable")
        else:
            return 1

    #
    # Helpers
    #
    def progress(self):
        """Progress in integer % increments"""
        self.log_msg("   {}%".format(self._fake_progress))
        return self._fake_progress

    def is_running(self):
        """Check if Margining is running"""
        return self.progress < 100

    def all_lanes_scanned(self, lane):
        """Check if all lanes scanned, Used for tools that need to have individual lanes scanned"""
        return 1

    def wait_for_finish(self):
        return 1
