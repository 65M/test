from ..base import AbstractBaseMarginTool
from .pcie_dump import *
# from .mrpc import mrpc

__all__ = [
    "AbstractReceiverMarginTool"
]


class AbstractReceiverMarginTool(AbstractBaseMarginTool):
    """Generic Interface for ANS (Apple NAND System) Margining"""
    LANE_COUNT = 1  # This needs to be set at run time (it's base on the system)
    TIMEOUT = 180  # Set timeout to 2min (Average is 1-1.5)
    POLL_TIME = 2  # Poll every 2 seconds
    margin_data=()

    def __init__(self, *args, **kwargs):
        super(AbstractReceiverMarginTool, self).__init__(*args, **kwargs)
        print(f"Running with Board Rev: {self.board_rev}")

        valid_endpoint = ["WLBT", "ENETA", "ENETB", "BIOUSBA", "Slot1", "Slot2", "Slot3", "Slot4", "Slot5", "Slot6", "BIO", "SATA", "USBA", "ALL", "MOLY8", "MOLY16", "MOLY4", "ALL_SLOTS", "ALL_CARDS"]

        if self.moly_index_list:
            print(f"Moly Index List: {self.moly_index_list}")
            moly_index = []
            for index in self.moly_index_list.split(","):
                moly_index.append(int(index))
            self.moly_index_list = moly_index
            print(f"Clean Moly Index List: {self.moly_index_list}")
        elif self.device_index:
            self.moly_index_list = [int(self.device_index)]

        self.my_mrpc_mapping = {}

        print(f"Minimum Score: {self.score}")
        print(f"Microsemi Endpoint: {self.microsemi_endpoint} Valid Endpoints: {valid_endpoint} Root Port: {self.root_port} Port Enablement: {self.port_enablement} Bio Moly: {self.bio_moly}.")

        self.valid_lanes = []
        self.microsemi_endpoint = str(self.microsemi_endpoint)
        if self.microsemi_endpoint in ["ALL"]: # all 100 lanes on Microsemi switch
            for lane in range(0, 100):
                self.valid_lanes.append(lane)
        elif self.microsemi_endpoint in ["SOC"]: # 24 lanes connecting SoC (16 Die 0 + 8 Die 1) to Microsemi switch
            for lane in range(0, 24):
                self.valid_lanes.append(lane)
        elif self.microsemi_endpoint in ["MOLY16"]: # 16 lanes for the Moly external card switch
            for lane in range(16, 32):
                self.valid_lanes.append(lane)
        elif self.microsemi_endpoint in ["MOLY8"]: # 16 lanes for the Moly external card switch
            for lane in range(16, 24):
                self.valid_lanes.append(lane)
        elif self.microsemi_endpoint in ["MOLY4"]: # 4 lanes for the Moly switch on BIO Moly card
            for lane in range(16, 20):
                self.valid_lanes.append(lane)
        elif self.microsemi_endpoint in ["USBA"]: # 2 lanes outward from Microsemi to USBA
            for lane in range(24, 26):
                self.valid_lanes.append(lane)
        elif self.microsemi_endpoint in ["SATA"]: # 2 lanes outward from Microsemi to SATA
            for lane in range(26, 28):
                self.valid_lanes.append(lane)
        elif self.microsemi_endpoint in ["BIO"]: # 2 lanes outward from Microsemi to BIO
            for lane in range(28, 30):
                self.valid_lanes.append(lane)
        elif self.microsemi_endpoint in ["BIOUSBA"]: # 4 lanes outward from Microsemi to BIO USBA
            for lane in range(28, 32):
                self.valid_lanes.append(lane)
        elif self.microsemi_endpoint in ["Slot6"]: # 8 lanes outward from Microsemi to Slot6
            for lane in range(32, 40):
                self.valid_lanes.append(lane)
        elif self.microsemi_endpoint in ["Slot5"]: # 8 lanes outward from Microsemi to Slot5
            for lane in range(40, 48):
                self.valid_lanes.append(lane)
        elif self.microsemi_endpoint in ["Slot4"]: # 8 lanes outward from Microsemi to Slot4
            for lane in range(48, 56):
                self.valid_lanes.append(lane)
        elif self.microsemi_endpoint in ["Slot3"]: # 8 lanes outward from Microsemi to Slot3
            for lane in range(56, 64):
                self.valid_lanes.append(lane)
        elif self.microsemi_endpoint in ["Slot2"]: # 16 lanes outward from Microsemi to Slot2
            for lane in range(64, 80):
                self.valid_lanes.append(lane)
        elif self.microsemi_endpoint in ["Slot1"]: # 16 lanes outward from Microsemi to Slot1
            for lane in range(80, 96):
                self.valid_lanes.append(lane)
        elif self.microsemi_endpoint in ["ALL_SLOTS"]: # Slot 1 -> 6
            for lane in range(32, 96):
                self.valid_lanes.append(lane)
        elif self.microsemi_endpoint in ["ALL_CARDS"]: # Slot 1->6 + BIO CARD
            for lane in range(28, 96):
                self.valid_lanes.append(lane)
        elif self.microsemi_endpoint in ["ENETA"]: # 1 lane outward from Microsemi to ENETA
            self.valid_lanes = [96]
        elif self.microsemi_endpoint in ["ENETB"]: # 1 lane outward from Microsemi to ENETB
            self.valid_lanes = [98]
        elif self.microsemi_endpoint in ["WLBT"]: # 1 lane outward from Microsemi to WLBT
            self.valid_lanes = [99]
        else:
            raise Exception("Invalid Microsemi Endpoint")

        print(f" Board Rev: {self.board_rev} PFX84: {self.pfx84}")
        if (self.board_rev == 4 or self.pfx84) and (self.device_index is None or int(self.device_index) == 0):
            # Remove all lanes 0->15 and subtract 16 from all lane numbers
            print("Modifying Lanes Due to 84-Lane Switch")
            new_lanes = []
            for lane in self.valid_lanes:
                if lane > 15:
                    new_lanes.append(lane)

            self.valid_lanes = new_lanes

        print(f"For Microsemi Endpoint: {self.microsemi_endpoint} Valid Lanes: {self.valid_lanes}")
        self.my_mrpc = None

    def configure_phy(self):
        """Configure the PHY Settings, Overrides, ECO, etc"""
        pass

    def apply_settings(self, retrain=True):
        """Apply EQ and other settings, retrain (if applicable)"""

    # No settings to apply
    def ensure_link(self):
        """Check Link meets Speed / Width requirements"""
        # Get the Link Status, and calculate the Link Width / Speed

    # Not applicable, all lanes are margined together

    def setup_margining(self):
        """Configure the PHY and Setup Margining"""

    def start_margining(self):
        """Start the Margining"""

    def dump_registers(self, initial=False):
        """Dump Static Registers"""

    def parse_margin_data(self):
        """Parse data to the necessary format(s)"""
        print("Parsing Margin Data: {}".format(self.margin_data))

    def calculate_eye(self):
        """Parse data to the necessary format(s)"""
        # Parse the output
        self.parse_margin_data()

    #
    # Helpers
    #
    def progress(self):
        """Progress in integer % increments"""
        self.log_msg("   {}%".format(self._fake_progress))
        return self._fake_progress

    def is_running(self):
        """Check if Margining is running"""
        return self.progress < 100

    def all_lanes_scanned(self, lane):
        """Check if all lanes scanned, Used for tools that need to have individual lanes scanned"""
        if lane == self.LANE_COUNT:
            return 1
        else:
            self.log_msg("Didnt complete all lanes")

    def wait_for_finish(self):
        return 1

