from shell import run


def verify_j180d_dut():
    output = run("system")
    for line in output.split('\n'):
        if "model-name" in line:
            print(line)
            dut = line.split(":")[-1].strip()
            print(dut)
            if dut == "j180ddev" or dut == "j180dap":
                return True
    return False


def power_up():
    # Power to WiFi/BT
    run("egpio -p pmu -n 13 -w 1")
    # Power to USB HCs
    run("egpio -p pmu2 -n 1 -w 1")
    run("egpio -p pmu -n 19 -w 1")
    run("pcie --pick 4 --on")
    run("pcie --pick 21 --on")
    # PERST to WiFi/BT
    run("egpio -p soc -n 4 -w 1")


def enumerate():
    """
    [000C1129:01C0011E] :-) dh -p PciRootBridgeIo
    Handle dump by protocol 'PCIRootBridgeIO'
    5A4: PCIRootBridgeIO(PciRootBridgeIo) DevicePath(PcieRoot(0x0))
    5AD: PCIRootBridgeIO(PciRootBridgeIo) DevicePath(PcieRoot(0x1))
    """
    output = run("dh -p PciRootBridgeIo")
    for line in output.split('\n'):
        if "PcieRoot" in line:
            handle = line.split(":")[0]
            run("connect {}".format(handle))



# ROOT_PORT_BDFS = [(0, 0, 0, 0), (1, 0, 0, 0)]
ROOT_PORTS = {
    "Die0 GE" : (0,0,0,0),
    "Die1 GE" : (1,0,0,0)
}


# ENDPOINT_BDFS = [(1,3,0,0), (1,4,0,0), (1,6,0,0), (1,7,0,0), (1,8,0,0)]
ENDPOINTS = {
    "SATA" : (1,4,0,0),
    "Eth0" : (1,6,0,0),
    "Eth1" : (1,7,0,0),
    "USB0" : (1,3,0,0),
    "USB1" : (1,5,0,0),
    "WLAN" : (1,8,0,0)
}


INFO_STRINGS = ["Current Link Speed", "Negotiated Link Width"]


def print_sbdf_info(segment, bus, device, function):
    try:
        output = run("pci -s {} {} {} {} -i".format(segment, bus, device, function), True)

        for line in output.split('\n'):
            for info_string in INFO_STRINGS:
                if info_string in line:
                    print(line.strip())
    except Exception as e:
        print(f"Exception: {e} for Segment: {segment} Bus: {bus} Device: {device} Function: {function}")


def print_root_port_info():
    print("Root Ports:")
    for name, sbdf in ROOT_PORTS.items():
    # for sbdf in ROOT_PORT_BDFS:
        print("{} ({}:{}:{}:{})".format(name, *sbdf))
        print_sbdf_info(*sbdf)


def print_endpoint_info():
    print("Endpoints:")
    for name, sbdf in ENDPOINTS.items():
    # for sbdf in ENDPOINT_BDFS:
        print("{} ({}:{}:{}:{})".format(name, *sbdf))
        print_sbdf_info(*sbdf)


def grab_sbdf_info(segment, bus, device, function):
    sbdf_info = []
    try:
        output = run("pci -s {} {} {} {} -i".format(segment, bus, device, function), True)

        for line in output.split('\n'):
            for info_string in INFO_STRINGS:
                if info_string in line:
                    sbdf_info.append(line.strip())
    except Exception as e:
        print(f"Exception: {e} for Segment: {segment} Bus: {bus} Device: {device} Function: {function}")

    return sbdf_info


def grab_endpoint_info():
    endpoint_info = []
    endpoint_info.append("Endpoints:")
    for name, sbdf in ENDPOINTS.items():
        endpoint_info.append("{} ({}:{}:{}:{})".format(name, *sbdf))
        for line in grab_sbdf_info(*sbdf):
            endpoint_info += line
    return endpoint_info


# if __name__ == '__main__':
#     if not verify_j180d_dut():
#         print("This script can only run on J180d")
#
#     power_up()
#     enumerate()
#     print_root_port_info()
#     print_endpoint_info()

