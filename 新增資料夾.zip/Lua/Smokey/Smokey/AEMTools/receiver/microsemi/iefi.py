"""Access for iEFI"""
import logging
from .base import AbstractReceiverMarginTool
from shell import run
from .pcie_dump import *
import re
from pci.mrpc import mrpc
import time

__all__ = [
    "MarginTool"
]

seq_log = logging.getLogger("sequence")


class MarginTool(AbstractReceiverMarginTool):
    """Margin Tool Instance"""
    # General Commands
    DIE_TEMP_COMMAND_ID = 4
    DIE_TEMP_COMMAND_VALUE = 2
    MRPC_CROSSHAIR = 56
    MRPC_CROSSHAIR_ENABLE_ALL_LANES = 65536  # 0x00/01/00/00
    MRPC_CROSSHAIR_ENABLE_ONE_LANES = 0  # 0x00/00/00/00
    LANE_OUTPUT_SIZE = 3
    MRPC_CROSSHAIR_STATUS = 2

    RESULT_CODE = 0
    RETEST_DATA = []


    def ensure_link(self):
        """Ensure PCIe Link for MRPC Margining"""
        print(f"Port Enablement: {self.port_enablement}")
        root_ports = self.port_enablement['ALL'] if self.microsemi_endpoint not in ['WLBT'] else self.port_enablement[self.microsemi_endpoint]
        for port in root_ports:
            print(f"Turning on Port {port} Out Of {root_ports}")
            try:
                run(f"pcie --pick {port} --on")
            except Exception as e:
                print(f"Exception: {e}")

        if self.microsemi_endpoint in ["WLBT"]:
            # Turn on WLBT
            print("Turning on Wifi")
            try:
                run("wifi --on")
            except Exception as e:
                print(f"Exception: {e}")
        else:
            try:
                output = run("dh -p PciRootBridgeIo")
                for line in output.split("\n"):
                    m = re.search(r"(\w+): PCIRoot.*", line)
                    if m:
                        connect = m.group(1)
                        print(f"Found Connect Port: {connect}")
                        run(f"connect {connect}")

            except Exception as e:
                print(f"Exception: {e}")

        print("Ensure Link Done")

        if (self.device_index is None or int(self.device_index) == 0) and (self.board_rev != 4 and not self.pfx84):
            print("Setup MYMRPC Non 84 Lane (100 Lane Default) switch")
            self.my_mrpc = mrpc(vendor_id=0x11F8, device_id=0x4000)
            self.my_mrpc.print_id()
            self.my_mrpc.locate()
            output = self.my_mrpc.list()
            print(f" Found MRPC: {output} Selecting Device 0 (J180 Controller)")
            self.my_mrpc.select(0)
        elif (self.device_index is None or int(self.device_index) == 0) and (self.board_rev == 4 or self.pfx84):
            print("Setup MYMRPC 84 Lane Switch")
            self.my_mrpc = mrpc(vendor_id=0x11F8, device_id=0x4084)
            self.my_mrpc.print_id()
            self.my_mrpc.locate()
            output = self.my_mrpc.list()
            print(f" Found MRPC: {output} Selecting Device 0 (J180 Controller)")
            self.my_mrpc.select(0)
        else: # Moly card provided (device index location) -> always put into a mrpc list for parallelization
            self.my_mrpc = []
            count = 0
            for index in self.moly_index_list:
                print(f"Finding MRPC For Index: {index} Out Of Moly Index: {self.moly_index_list}")
                temp_mrpc = mrpc(vendor_id=0x11F8, device_id=0x4036)
                temp_mrpc.print_id()
                temp_mrpc.locate()
                output = temp_mrpc.list()
                if self.board_rev == 4 or self.pfx84:  # Device Index Mapping Table PFX84
                    print("Mapping Table 84-Lane Switch")
                    mapping_table = [5, 4, 3, 2, 1, 0]
                    mapping_table_index = index - 1
                    print(f" Found MRPC: {output} Selecting Device Index - 1 (Moly Controller): {mapping_table_index} Mapping Index: {mapping_table[mapping_table_index]}")
                    temp_mrpc.select(mapping_table[mapping_table_index])
                else:  # Device Index Mapping Table Normal 100 Lane Switch
                    print("Mapping Table Normal Switch")
                    if self.bio_moly:  # Bio Moly enumerates before Moly6, assign --device_index 7
                        print("Using BIO Moly Mapping")
                        mapping_table = [4, 3, 2, 1, 0, 6, 5]
                    else:
                        mapping_table = [4, 3, 2, 1, 0, 5]
                    mapping_table_index = index - 1

                    print(f" Found MRPC: {output} Selecting Device Index - 1 (Moly Controller): {mapping_table_index} Mapping Index: {mapping_table[mapping_table_index]}")
                    temp_mrpc.select(mapping_table[mapping_table_index])

                print(f"Appending Temp MRPC: {temp_mrpc}")

                # Track the index of which device index corresponds to which mrpc
                self.my_mrpc_mapping[count] = index
                count += 1
                self.my_mrpc.append(temp_mrpc)

            print(f"Margining the MRPC List: {self.my_mrpc}")

        print_endpoint_info()


    def mrpc_command(self, my_mrpc, command_id, output_len, input_data):
        """Run MRPC Command Using Built-in Functionality"""
        print(f"MRPC Command ID: {command_id} Output Length: {output_len} Input Data: {input_data}")
        data = my_mrpc.send_return_cmd(cmd_id=command_id, output_size=output_len, input_data=input_data)
        print(f"MRPC Data: {data}")
        return data


    def crosshair_lane_grab(self, start_lane, lane_count):
        """Calculate Crosshair with Lane Grab"""
        base_value = self.MRPC_CROSSHAIR_STATUS
        base_value = base_value | (start_lane << 8) | (lane_count << 24)
        return base_value


    def crosshair_lane_enable(self, lane_count):
        """Calculate Crosshair For a Particular Lane"""
        base_value = 0 | (lane_count << 8)
        return base_value


    def die_temp(self, my_mrpc):
        """Grab the DIE Temp"""
        temp = self.mrpc_command(my_mrpc=my_mrpc, command_id=0x4, output_len=1, input_data=[0x2])
        print("Unformatted Temp: {}".format(temp))
        print("Die Temp: {:.1f}C".format(temp[0] / 100.))


    def kickoff_crosshair(self, my_mrpc):
        """Kickoff Crosshair Command"""
        print("Kickoff Crosshair Command")
        self.mrpc_command(my_mrpc=my_mrpc, command_id=56, output_len=0, input_data=[65536])


    def validate_result(self, lane, eye_left_limit, eye_right_limit, eye_bottom_left_limit, eye_bottom_right_limit, eye_top_left_limit, eye_top_right_limit):
        """ Validate the Result Value"""
        score = ((eye_right_limit - eye_left_limit) + 1) * (((eye_top_left_limit - eye_bottom_left_limit) + 1) + ((eye_top_right_limit - eye_bottom_right_limit) + 1))
        print(f"Lane: {lane} has score: {score}")
        if score > 2048:
            result = 0
        elif 2048 >= score >= 1024:
            result = 1
        else:
            result = 2
        return result, score


    def parse_byte(self, register_data, byte_index):
        """Parse the byte at a given index position"""
        byte_output = (register_data >> (8 * byte_index)) & 0xFF
        return byte_output


    def log_mrpc_key(self, mrpc, key, value, units, upperlimit=None, lowerlimit=None):
        """Log an MRPC Key, Accounting for the Potential For Multiple Device Indices"""
        if isinstance(self.my_mrpc, list):
            device_index = self.my_mrpc_mapping[self.my_mrpc.index(mrpc)]
            print(f"Logging Key Device Index: {device_index}")
            key = f"d{device_index}_" + key

        if upperlimit or lowerlimit:
            self.log_key(key=key, value=value, units=units, upperlimit=upperlimit, lowerlimit=lowerlimit)
        else:
            self.log_key(key=key, value=value, units=units)


    def twos_complement(self, number):
        """Grab the 2s complement (and then inverse sign)"""
        # Micropython from bytes doesn't handle signed=True, so we convert the unsigned.
        if (number >> 15) & 0x1 == 1:
            return -(-number + int(0xFFFF) + 1)
        else:
            return number


    def parse_lane_data(self, lane_data):
        """Parse out lane data per Microsemi specification"""
        lane = int(self.parse_byte(lane_data[0], 0))
        current_state = int(self.parse_byte(lane_data[0], 1))

        byte0 = int(self.parse_byte(lane_data[0], 2))
        byte1 = int(self.parse_byte(lane_data[0], 3))

        # Need to convert word such as 65536 as binary that should be interpreted as a signed (negative) number
        # Micropython Doesn't Allow passing keyword arguments i.e. signed=True, and signed doesn't work, so we need to do the 2s complement conversion
        word0 = self.twos_complement(int.from_bytes(bytes([self.parse_byte(lane_data[1], 1), self.parse_byte(lane_data[1], 0)]), 'big'))
        word1 = self.twos_complement(int.from_bytes(bytes([self.parse_byte(lane_data[1], 3), self.parse_byte(lane_data[1], 2)]), 'big'))
        word2 = self.twos_complement(int.from_bytes(bytes([self.parse_byte(lane_data[2], 1), self.parse_byte(lane_data[2], 0)]), 'big'))
        word3 = self.twos_complement(int.from_bytes(bytes([self.parse_byte(lane_data[2], 3), self.parse_byte(lane_data[2], 2)]), 'big'))

        print(f"Lane: {lane} Current State: {current_state} Byte0: {byte0} Byte1: {byte1} Word0: {word0} Word1: {word1} Word2: {word2} Word3: {word3}")
        return lane, current_state, byte0, byte1, word0, word1, word2, word3


    def grab_data(self, my_mrpc, start_lane, failure_flag):
        """Grab Output Data for a Particular Single Lane"""
        # Failure flag qualifies the highest # (worst failure so far). We return T/F based on whether margining is done.
        # We run margining with 5s delays until we get the data for all lanes in valid lanes (once margining is kicked off).
        # If the state is 0, 1 Crosshair is Disabled / Reserved for Internal Use and we assume it won't be running

        command_value = self.crosshair_lane_grab(start_lane, 1)

        print(f"Grabbing Data For Lane: {start_lane} with command: {command_value}")
        cross_hair_packed = self.mrpc_command(my_mrpc=my_mrpc, command_id=self.MRPC_CROSSHAIR, output_len=self.LANE_OUTPUT_SIZE, input_data=[command_value])

        lane, current_state, byte0, byte1, word0, word1, word2, word3 = self.parse_lane_data(cross_hair_packed)

        if 2 <= current_state <= 20:
            print(f"Found Lane Not Done {lane}")
            return False, failure_flag
        elif current_state != 21 and current_state != 22:
            print(f"Invalid Data for Lane: {lane} Current State: {current_state}")
        elif current_state == 21:
            print(f"Lane: {lane} Done Valid Data State: {current_state}")
            eye_left_limit = byte0
            eye_right_limit = byte1
            eye_bottom_left_limit = word0
            eye_bottom_right_limit = word1
            eye_top_left_limit = word2
            eye_top_right_limit = word3

            # ToDo: For J170, if the score was invalid, we retried up to 3x. Not carrying that over for now.
            result, score = self.validate_result(lane, eye_left_limit, eye_right_limit, eye_bottom_left_limit, eye_bottom_right_limit, eye_top_left_limit, eye_top_right_limit)

            print(f"Lane {lane} Result {result} Score {score}")
            print(f"Lane {lane} Eye Left Limit {eye_left_limit} Eye Right Limit {eye_right_limit} Eye Bottom Left {eye_bottom_left_limit} "
                  f"Eye Bottom Right {eye_bottom_right_limit} Eye Top Left {eye_top_left_limit}  Eye Top Rigth {eye_top_right_limit}")
            self.log_mrpc_key(mrpc=my_mrpc, key=f"{self.microsemi_endpoint}_lane:{lane}_result", value=result, units='ticks')
            self.log_mrpc_key(mrpc=my_mrpc, key=f"{self.microsemi_endpoint}_lane:{lane}_score", value=score, units='ticks', upperlimit=None, lowerlimit=self.score)
            self.log_mrpc_key(mrpc=my_mrpc, key=f"{self.microsemi_endpoint}_lane:{lane}_eye_left_limit", value=eye_left_limit, units='ticks')
            self.log_mrpc_key(mrpc=my_mrpc, key=f"{self.microsemi_endpoint}_lane:{lane}_eye_right_limit", value=eye_right_limit, units='ticks')
            self.log_mrpc_key(mrpc=my_mrpc, key=f"{self.microsemi_endpoint}_lane:{lane}_eye_bottom_left_limit", value=eye_bottom_left_limit, units='ticks')
            self.log_mrpc_key(mrpc=my_mrpc, key=f"{self.microsemi_endpoint}_lane:{lane}_eye_bottom_right_limit", value=eye_bottom_right_limit, units='ticks')
            self.log_mrpc_key(mrpc=my_mrpc, key=f"{self.microsemi_endpoint}_lane:{lane}_eye_top_left_limit", value=eye_top_left_limit, units='ticks')
            self.log_mrpc_key(mrpc=my_mrpc, key=f"{self.microsemi_endpoint}_lane:{lane}_eye_top_right_limit", value=eye_top_right_limit, units='ticks')
        elif current_state == 22:
            print(f"FOUND ERROR!!! for lane: {lane} current state: {current_state}")
            failure_flag = 1
            previous_crosshair_state = byte0
            x_position_if_error = word0
            y_position_if_error = word1

            print(f"Lane: {lane} Previous Crosshair State: {previous_crosshair_state} x_position_if_error: {x_position_if_error} y_position_if_error: {y_position_if_error}")
            self.log_mrpc_key(mrpc=my_mrpc, key=f"{self.microsemi_endpoint}_lane:{lane}_error_previous_crosshair_state", value=previous_crosshair_state, units='ticks')
            self.log_mrpc_key(mrpc=my_mrpc, key=f"{self.microsemi_endpoint}_lane:{lane}_error_x_position_if_error", value=x_position_if_error, units='ticks')
            self.log_mrpc_key(mrpc=my_mrpc, key=f"{self.microsemi_endpoint}_lane:{lane}_error_y_position_if_error", value=y_position_if_error, units='ticks')
        else:
            print(f"Lane: {lane} Current State 0/1 (Not Able to Run Margining)")
            self.log_mrpc_key(mrpc=my_mrpc, key=f"{self.microsemi_endpoint}_lane:{lane}_unable_run_margining_state", value=current_state, units='ticks')

        print("Done with Cross Hair Command")
        return True, failure_flag


    def cross_hair(self, my_mrpc):
        """Crosshair Command for Margining"""
        # Kickoff Crosshair on all Lanes - Go lane by lane for the lanes we expect to have data and grab
        failure_flag = 0

        for lane in self.valid_lanes:
            print(f"Grabbing Margining Data for Lane: {lane}")
            data_output = False
            while not data_output:
                data_output, temp_failure_flag = self.grab_data(my_mrpc, lane, failure_flag)
                if temp_failure_flag > failure_flag:
                    print("Found Temp Failure Flag")
                    failure_flag = temp_failure_flag

                sleep_time = 1
                if not data_output:
                    print(f"Margining Not Done Lane: {lane}, Wait {sleep_time} Additional Second(s)")
                time.sleep(sleep_time) # Accelerate sleep to help margin test run faster for large number of lanes


    def start_margining(self):
        """Run Margining Process"""
        print("Start Margining")
        if isinstance(self.my_mrpc, list):
            print(f"MRPC List: {self.my_mrpc}")
            for mrpc in self.my_mrpc:
                print(f"DIE Temp: {self.die_temp(mrpc)}")
                print(f"Kickoff Margining Crosshair on MRPC: {mrpc}")
                self.kickoff_crosshair(mrpc)

            for mrpc in self.my_mrpc:
                print(f"Grab Crosshair on MRPC: {mrpc}")
                self.cross_hair(mrpc)
        else:
            print(f"MRPC Not List: {self.my_mrpc}")
            print(f"DIE Temp: {self.die_temp(self.my_mrpc)}")
            print("Run Margining Crosshair")
            self.kickoff_crosshair(my_mrpc=self.my_mrpc)
            self.cross_hair(my_mrpc=self.my_mrpc)