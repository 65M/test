import math
import time
from .conversion import *
from ..base import AbstractBaseMarginTool
from .defines import *
from.soc_defines import *
from shell import run


__all__ = [
    "AbstractReceiverMarginTool"
]


# Source: https://seg-docs.csg.apple.com/projects/ibiza/release/specs/Apple/AUSPMA/Ibiza_AUSPMA_Specification.pdf Pg. 367
class AbstractReceiverMarginTool(AbstractBaseMarginTool):
    LANE_COUNT = 1  # This needs to be set at run time (it's base on the system)
    TIMEOUT = 180  # Set timeout to 2min (Average is 1-1.5)
    POLL_TIME = 2  # Poll every 2 seconds
    margin_data=()
    ref_div = 5
    ref_clk = 533.3333 * 10 ** 6
    fref = 0
    f0 = 0
    f1 = 0
    fvco = 0
    res_data = []
    LANE_RP_OFFSET = 0
    mid_x = 0
    mid_y = 0
    res_vol_north_data = []
    res_vol_south_data = []
    res_pi_east_data = []
    res_pi_west_data = []
    res_vol_north_data_1 = []
    res_vol_south_data_1 = []
    res_pi_east_data_1 = []
    res_pi_west_data_1 = []
    mf=0

    def __init__(self, *args, **kwargs):
        super(AbstractReceiverMarginTool, self).__init__(*args, **kwargs)

        # Dynamically set the number of lanes by using Identify Controller
        self.sleep_time = 1
        self.LANE_COUNT = 1
        self._previous_percent = -1
        self.sisp_offset = SOC_CONVERSION_CODE[self.soc]['SOC_SISP_OFFSET']
        self.lane0_offset = SOC_CONVERSION_CODE[self.soc]['SOC_LANE0_OFFSET']
        self.lpdp_rx0_offset = SOC_CONVERSION_CODE[self.soc]['SOC_LPDP_RX0_OFFSET']

        self.camera_base_offset = self.sisp_offset + self.lane0_offset + self.lpdp_rx0_offset

        self.x_axis = []
        self.y_axis = []
        self.vco_bsel_div_code_r = 0

    def set_bits(self, address, start_bit, length, value):
        """Change specific bits of a address"""

    def get_bits(self, address, start_bit, length):
        """Change specific bits of a address"""

    def dump_registers(self, initial=False):
        """Dump Static Registers check adaptation converged values"""
        # Set below to make sure h0,h1 etc are read right
        # Convert CTLE and DFE to actual training parameters
        # Read out dclk, xclk, dclkb and xclkb positions
        if initial is True:
            cs_ticks = self.gray2dec(self.get_bits((self.camera_base_offset +
                                                    LPDP_CAMERA_REG['AFE_CTRL16_RO']),
                                                   7,
                                                   4))
            self.log_key(key="lane:{}_cs_ticks".format(
                self.current_lane),
                value=cs_ticks,
                units='ticks')
            cs = CONVERSION_OFFSET_FACTORS["c"] + CONVERSION_MULTIPLICATION_FACTORS["c"] * cs_ticks
            self.log_key(key="lane:{}_cs".format(
                self.current_lane),
                value=cs,
                units='db')
            rs_ticks = self.gray2dec(self.get_bits(self.camera_base_offset +
                                                   LPDP_CAMERA_REG['AFE_CTRL16_RO'], 19,
                                                   4))
            self.log_key(key="lane:{}_rs_ticks".format(
                self.current_lane),
                value=rs_ticks,
                units='ticks')
            rs = CONVERSION_OFFSET_FACTORS["r"] + CONVERSION_MULTIPLICATION_FACTORS["r"] * rs_ticks
            self.log_key(key="lane:{}_rs".format(
                self.current_lane),
                value=rs,
                units='db')

            dfeh5fb_en = self.get_bits(self.camera_base_offset + LPDP_CAMERA_REG['DFE_CTRL13_RO'], 28, 1)
            dfeh4fb_en = self.get_bits(self.camera_base_offset + LPDP_CAMERA_REG['DFE_CTRL13_RO'], 22, 1)
            dfeh3fb_en = self.get_bits(self.camera_base_offset + LPDP_CAMERA_REG['DFE_CTRL13_RO'], 21, 1)
            dfeh2fb_en = self.get_bits(self.camera_base_offset + LPDP_CAMERA_REG['DFE_CTRL13_RO'], 20, 1)
            dfeh1fb_en = self.get_bits(self.camera_base_offset + LPDP_CAMERA_REG['DFE_CTRL13_RO'], 19, 1)

            self.log_key(key="lane:{}_dfeh5fb_en".format(self.current_lane), value=dfeh5fb_en, units='')
            self.log_key(key="lane:{}_dfeh4fb_en".format(self.current_lane), value=dfeh4fb_en, units='')
            self.log_key(key="lane:{}_dfeh3fb_en".format(self.current_lane), value=dfeh3fb_en, units='')
            self.log_key(key="lane:{}_dfeh2fb_en".format(self.current_lane), value=dfeh2fb_en, units='')
            self.log_key(key="lane:{}_dfeh1fb_en".format(self.current_lane), value=dfeh1fb_en, units='')

            h1_ticks = self.gray2dec(self.get_bits(self.camera_base_offset +
                                                   LPDP_CAMERA_REG['DFE_CTRL13_RO'], 10,
                                                   5))
            sign = self.gray2dec(self.get_bits(self.camera_base_offset +
                                               LPDP_CAMERA_REG['DFE_CTRL13_RO'], 15,
                                               1))
            if sign is 1:
                h1_sign = -1
            else:
                h1_sign = 1
            h1 = h1_sign * CONVERSION_MULTIPLICATION_FACTORS["h1"] * h1_ticks
            self.log_key(key="lane:{}_h1".format(
                self.current_lane),
                value=h1,
                units='mV')
            self.log_key(key="lane:{}_h1_ticks".format(
                self.current_lane),
                value=h1_ticks,
                units='ticks')

            sign = self.get_bits(self.camera_base_offset +
                                 LPDP_CAMERA_REG['DCORING_CTRL712_RO'], 24,
                                 1)
            if sign is 1:
                h2_sign = -1
            else:
                h2_sign = 1
            h2_ticks = self.gray2dec(self.get_bits(self.camera_base_offset +
                                                   LPDP_CAMERA_REG['DCORING_CTRL712_RO'], 21,
                                                   3))
            h2 = h2_sign * CONVERSION_MULTIPLICATION_FACTORS["h2"] * h2_ticks
            self.log_key(key="lane:{}_h2".format(
                self.current_lane),
                value=h2,
                units='mV')
            self.log_key(key="lane:{}_h2_ticks".format(
                self.current_lane),
                value=h2_ticks,
                units='ticks')
            sign1 = self.get_bits(self.camera_base_offset +
                                  LPDP_CAMERA_REG['DCORING_CTRL712_RO'], 29, 1)
            if sign1 is 1:
                h3_sign = -1
            else:
                h3_sign = 1
            h3_ticks = self.gray2dec(self.get_bits(self.camera_base_offset +
                                                   LPDP_CAMERA_REG['DCORING_CTRL712_RO'], 26, 3))
            h3 = h3_sign * CONVERSION_MULTIPLICATION_FACTORS["h3"] * h3_ticks
            self.log_key(key="lane:{}_h3".format(
                self.current_lane),
                value=h3,
                units='mV')
            self.log_key(key="lane:{}_h3_ticks".format(
                self.current_lane),
                value=h3_ticks,
                units='ticks')
            sign2 = self.get_bits(self.camera_base_offset +
                                  LPDP_CAMERA_REG['DFE_CTRL13_RO'], 3, 1)
            if sign2 is 1:
                h4_sign = -1
            else:
                h4_sign = 1
            h4_ticks = self.gray2dec(self.get_bits(self.camera_base_offset +
                                                   LPDP_CAMERA_REG['DFE_CTRL13_RO'], 0, 3))
            h4 = h4_sign * CONVERSION_MULTIPLICATION_FACTORS["h4"] * h4_ticks

            self.log_key(key="lane:{}_h4".format(
                self.current_lane),
                value=h4,
                units='mV')
            self.log_key(key="lane:{}_h4_ticks".format(
                self.current_lane),
                value=h4_ticks,
                units='ticks')
            sign5 = self.get_bits(self.camera_base_offset +
                                  LPDP_CAMERA_REG['DFE_CTRL13_RO'], 8, 1)
            if sign5 is 1:
                h5_sign = -1
            else:
                h5_sign = 1
            h5 = h5_sign * CONVERSION_MULTIPLICATION_FACTORS["h5"] * \
                 self.gray2dec(self.get_bits(self.camera_base_offset +
                                             LPDP_CAMERA_REG['DFE_CTRL13_RO'], 5, 3))
            self.log_key(key="lane:{}_h5".format(
                self.current_lane),
                value=h5,
                units='mV')

            aus_eq_ctrl_raw_cap_dclk_pos = self.gray2dec(self.get_bits(
                self.camera_base_offset +
                LPDP_CAMERA_REG['RXA_DCO_CTRL89_RO'],
                14, 7))
            self.log_key(key="lane:{}_aus_eq_ctrl_raw_cap_dclk_pos_raw".format(
                self.current_lane),
                value=aus_eq_ctrl_raw_cap_dclk_pos, units='ticks')

            aus_eq_ctrl_raw_cap_dclkb_pos = self.gray2dec(self.get_bits(
                self.camera_base_offset +
                LPDP_CAMERA_REG['RXA_DCO_CTRL89_RO'],
                21, 7))

            self.log_key(key="lane:{}_aus_eq_ctrl_raw_cap_dclkb_pos_raw".format(
                self.current_lane),
                value=aus_eq_ctrl_raw_cap_dclkb_pos, units='ticks')

            aus_eq_ctrl_raw_cap_xclk_pos = self.gray2dec(self.get_bits(
                self.camera_base_offset +
                LPDP_CAMERA_REG['DCOPI_CTRL10_RO'],
                0, 7))
            self.log_key(key="lane:{}_aus_eq_ctrl_raw_cap_xclk_pos_raw".format(
                self.current_lane),
                value=aus_eq_ctrl_raw_cap_xclk_pos, units='ticks')

            aus_eq_ctrl_raw_cap_xclkb_pos = self.gray2dec(self.get_bits(
                self.camera_base_offset +
                LPDP_CAMERA_REG['DCOPI_CTRL10_RO'],
                7, 7))
            self.log_key(key="lane:{}aus_eq_ctrl_raw_cap_xclkb_pos_raw".format(
                self.current_lane),
                value=aus_eq_ctrl_raw_cap_xclkb_pos, units='ticks')
        elif initial is False:
            cs = CONVERSION_OFFSET_FACTORS["c"] + CONVERSION_MULTIPLICATION_FACTORS["c"] * \
                 self.gray2dec(self.get_bits((self.camera_base_offset +
                                              LPDP_CAMERA_REG['AFE_CTRL16_RO']),
                                             7,
                                             4))
            self.log_reg("lane:{}_cs{}_units{}".format(self.current_lane, cs, 'db'))
            rs = CONVERSION_OFFSET_FACTORS["r"] + CONVERSION_MULTIPLICATION_FACTORS["r"] * \
                 self.gray2dec(self.get_bits(self.camera_base_offset +
                                             LPDP_CAMERA_REG['AFE_CTRL16_RO'], 19,
                                             4))
            self.log_reg("lane:{}_rs{}_units{}".format(self.current_lane, rs, 'db'))
            h1 = CONVERSION_MULTIPLICATION_FACTORS["h1"] * \
                 self.gray2dec(self.get_bits(self.camera_base_offset +
                                             LPDP_CAMERA_REG['DFE_CTRL13_RO'], 10,
                                             5))
            self.log_reg("lane:{}_h1{}_units{}".format(self.current_lane, h1, 'mV'))
            h2 = CONVERSION_MULTIPLICATION_FACTORS["h2"] * \
                 self.gray2dec(self.get_bits(self.camera_base_offset +
                                             LPDP_CAMERA_REG['DCORING_CTRL712_RO'], 21,
                                             3))
            self.log_reg("lane:{}_h2{}_units{}".format(self.current_lane, h2, 'mV'))
            h3 = CONVERSION_MULTIPLICATION_FACTORS["h3"] * \
                 self.gray2dec(self.get_bits(self.camera_base_offset +
                                             LPDP_CAMERA_REG['DCORING_CTRL712_RO'], 26, 3))
            self.log_reg("lane:{}_h3{}_units{}".format(self.current_lane, h3, 'mV'))
            h4 = CONVERSION_MULTIPLICATION_FACTORS["h4"] * \
                 self.gray2dec(self.get_bits(self.camera_base_offset +
                                             LPDP_CAMERA_REG['DFE_CTRL13_RO'], 0, 3))
            self.log_reg("lane:{}_h4{}_units{}".format(self.current_lane, h4, 'mV'))
            h5 = CONVERSION_MULTIPLICATION_FACTORS["h5"] * \
                 self.gray2dec(self.get_bits(self.camera_base_offset +
                                             LPDP_CAMERA_REG['DFE_CTRL13_RO'], 5, 3))
            self.log_reg("lane:{}_h5{}_units{}".format(self.current_lane, h5, 'mV'))

            aus_eq_ctrl_raw_cap_dclk_pos = self.gray2dec(self.get_bits(
                self.camera_base_offset +
                LPDP_CAMERA_REG['RXA_DCO_CTRL89_RO'],
                14, 7))
            self.log_reg("lane:{}_aus_eq_ctrl_raw_cap_dclk_pos_raw{}_{}".format(
                self.current_lane, aus_eq_ctrl_raw_cap_dclk_pos, 'ticks'))

            aus_eq_ctrl_raw_cap_dclkb_pos = self.gray2dec(self.get_bits(
                self.camera_base_offset +
                LPDP_CAMERA_REG['RXA_DCO_CTRL89_RO'],
                21, 7))

            self.log_reg("lane:{}_aus_eq_ctrl_raw_cap_dclkb_pos_raw_{},{}".format(self.current_lane,
                                                                                  aus_eq_ctrl_raw_cap_dclkb_pos,
                                                                                  'ticks'))

            aus_eq_ctrl_raw_cap_xclk_pos = self.gray2dec(self.get_bits(
                self.camera_base_offset +
                LPDP_CAMERA_REG['DCOPI_CTRL10_RO'],
                0, 7))
            self.log_reg("lane:{}_aus_eq_ctrl_raw_cap_xclk_pos_raw{}_{}".format(self.current_lane,
                                                                                aus_eq_ctrl_raw_cap_xclk_pos,
                                                                                'ticks'))
            aus_eq_ctrl_raw_cap_xclkb_pos = self.gray2dec(self.get_bits(
                self.camera_base_offset +
                LPDP_CAMERA_REG['DCOPI_CTRL10_RO'],
                7, 7))
            self.log_reg("lane:{}_aus_eq_ctrl_raw_cap_xclkb_pos_raw{}_{}".format(self.current_lane,
                                                                                aus_eq_ctrl_raw_cap_xclkb_pos, 'ticks'))

            for key, value in AUSPMA_LANE0_SMGR_registers.items():
                register_value = self.get_bits(self.camera_base_offset + value, 0, 32)

                try:
                    self.log_key(key="lane:{}_{}".format(
                        self.current_lane,
                        key.replace("APCIE_DOWN_AUS_LANE0_AUSPMA_", "").lower()),
                        value=register_value, units='')
                except Exception as e:
                    print("Unable to read register: ", key, " due to ", e)



    def padded_hex(self, i, l):
        given_int = i
        given_len = l

        hex_result = hex(given_int)[2:]  # remove '0x' from beginning of str
        num_hex_chars = len(hex_result)
        extra_zeros = '0' * (given_len - num_hex_chars)  # may not get used..

        return ('0x' + hex_result if num_hex_chars == given_len else
                '?' * given_len if num_hex_chars > given_len else
                '0x' + extra_zeros + hex_result if num_hex_chars < given_len else
                None)

    def int2sa_vos_code(self, intval):
        """Convert to gray code from sign int 5 bits"""
        if (intval < -31) or (intval > 31):
            return None
        elif intval >= 0:
            return intval ^ intval >> 1
        intval = abs(intval)
        return (intval ^ intval >> 1) + 32

    def dec2gray(self, i=0):
        """ convert dec to gray """
        return i ^ i >> 1

    def gray2dec(self, i=0, total_bits=63):
        """ convert gray to dec """
        return [self.dec2gray(d) for d in range(total_bits)].index(i)

    def swing_level(self, figure_of_merit):
        print("Ensure Link")
        # Remove "sep --init" from before consolerouter on Jade+ programs (removal needed for J41x margining).
        try:
            print("Exit Camera")
            run("camisp --exit")
        except Exception as e:
            print(f"Continue Stream Off: {e}")

        try:
            print("Turn off Stream Current State")
            run("camisp --stream off", True)
        except Exception as e:
            print(f"Continue Stream Off: {e}")

        print("Setup Stream")
        run("consolerouter -a -s imageprocessor.* --dest serial")
        run("camisp --dbgfw on; camisp --on")

        print("set next swing level to {}mV".format(figure_of_merit))
        run("camisp --method sethsoutputlevel {}".format(figure_of_merit))

        print('Finish enabling')
        run("camisp --stream on")
        run("camisp --method setmipifreq -1")

        print('read swing')
        run("camisp --i2cread 0 0x36 0x0518 2 1")
        run("camisp --i2cread 0 0x36 0x0519 2 1")
        run("camisp --i2cread 0 0x36 0x0550 2 1")
        run("camisp --i2cread 0 0x36 0x0525 2 1")

    #
    # Execution Flow
    #
    def set_adaptation(self, figure_of_merit):
        """Set the Adaptation Type (if applicable)"""
        if bool(self.doe) is True:
            print("Figure of Merit: {}, Set Swing Level".format(figure_of_merit))
            self.swing_level(figure_of_merit)
        else:
            print("Skip Set Adaptation, no DOE")
            return 1

    def configure_phy(self):
        """Configure the PHY"""
        # The following steps of the eyescan sequence should be executed before de-assertion of lane reset and after de-assertion of apb_reset.

        # Step 1 (a)
        # Enable byte clock for EQ engine
        #   Write lane’s RX EQ register, eq_smgr_override
        #   clk_en = 1
        """
        print("Skip Configure PHY Temporarily")


        print("The following steps (1/2) of the eyescan sequence should be executed before de-assertion of lane reset and after de-assertion of apb_reset.")

        print("Step 1(a) - Enable byte clock for EQ engine")
        self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RX_EQ_EQ_SMGR_OVERRIDE'], 0, 1, 1)

        # Step 2 (a)
        #   Write lane’s RX SHIM register, rxa_dcopi_ctrl61 to enable Error PI
        #       pma_rxa_dcopi_eclk_en_ov = 1
        #       pma_rxa_dcopi_eclk_en = 1

        print("Step 2(a) - Write lane’s RX SHIM register, rxa_dcopi_ctrl61 to enable Error PI")
        self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DCOPI_CTRL61'], 17, 1, 1)
        self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DCOPI_CTRL61'], 16, 1, 1)

        # Step 2 (b)
        #   Write lane’s RX SHIM register, rxa_dcopi_ctrl1 to enable eclk
        #       pma_rxa_dcoclk_eck_en_ov = 1;
        #       pma_rxa_dcoclk_eck_en = 1;

        print("Step 2(b) - Write lane’s RX SHIM register, rxa_dcopi_ctrl1 to enable eclk")
        self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DCOPI_CTRL1'], 1, 1, 1)
        self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DCOPI_CTRL1'], 0, 1, 1)

        # Step 2 (c)
        #   Write lane’s RX SHIM register, rxa_dcopi_ctrl1 to disable the bypass eclk DCO PI
        #       pma_rxa_dcopi_eclk_bypass_en_ov = 1
        #       pma_rxa_dcopi_eclk_bypass_en = 0
        #       pma_rxa_dcopi_xdclk_bypass_en_ov = 1
        #       pma_rxa_dcopi_xdclk_bypass_en = 0

        print("Step 2(c) - Write lane’s RX SHIM register, rxa_dcopi_ctrl1 to disable the bypass eclk DCO PI")
        self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DCOPI_CTRL1'], 10, 1, 1)
        self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DCOPI_CTRL1'], 9, 1, 0)

        # print("Temp Disable")
        self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DCOPI_CTRL1'], 12, 1, 1)
        self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DCOPI_CTRL1'], 11, 1, 0)

    
        # pma_rxa_dco_spare_2_ov	17	1	rw	0x1		pma_rxa_dco_spare_2 SHM override enable
        # pma_rxa_dco_spare_2	16	1	rw	0x1		Reserved for future use inside DCO to support changes in frequency lock algorithms
        # pma_rxa_dco_spare_1_ov	15	1	rw	0x1		pma_rxa_dco_spare_1 SHM override enable
        # pma_rxa_dco_spare_1	14	1	rw	0x0		Reserved for future use inside DCO to support changes in frequency lock algorithms
        # pma_rxa_dco_spare_0_ov	13	1	rw	0x1		pma_rxa_dco_spare_0 SHM override enable
        # pma_rxa_dco_spare_0	12

        print("Olivier additional step - Can you force the 3 OV ([0:2]) to 0")
        self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DCO_CTRL31'], 0, 3, 0)

        output = self.get_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DCO_CTRL31'], 0, 3)
        print(f"Read out OV: {output}")
        """


    def setup_margining(self):
        """Configure the PHY and Setup Margining"""
        # Per Olivier, Skip Steps 5b / 5c -> instead read E-Clock / D-Clock
        # The Error PI Codes, PMA RXA DCOPI ECLK POS GRAY, and EXCLKB Should Only Change 1x At A Time and Not By >1

        # ToDo: (Questions)
        # AUS40PMA_RX_APB_OVERRIDE_REG_50
        # Conversion factor mV to Ticks?

        # Presume that steps 1 / 2(a)(b)(c) are handled by the FW.

        # Step 3(a) - Setup Error PI to Align EClk Pos Gray
        # RXA_DCOPI_CTRL61 - https://seg-docs.csg.apple.com/projects/ibiza/release/UserManual/regs/trunk/default/AUSPMA_RX_SHM.html?baseaddr=0x2a671a000#AUSPMA_RX_SHM_auspma_rx_rxa_dcopi_ctrl61
        #   eclk_pos_gray_ov = 1
        #   eclk_pos_gray = binary2gray(8) = 12
        #   eclkb_pos_gray_ov = 1
        #   eclkb_pos_gray = binary2gray(8) = 12

        print("Step 3(a) Setup Error PI To Align EClk Pos Gray")
        print("Skip setting values to 8 and instead align ECLK / ECLKB to DCLK / DCLKB")
        print("Check ECLK/ECLKB and DCLK/DCLKB are in the same location (center of the eye) - if not, walk them back")

        dclk_pos_decimal = self.gray2dec(self.get_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DCO_CTRL89_RO'], 14, 7))
        dclkb_pos_decimal = self.gray2dec(self.get_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DCO_CTRL89_RO'], 21, 7))

        eclk_pos_decimal = self.gray2dec(self.get_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DCOPI_CTRL611_RO'], 0, 7))
        eclkb_pos_decimal = self.gray2dec(self.get_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DCOPI_CTRL611_RO'], 7, 7))

        # Set 61 to value from CTRL611
        self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DCOPI_CTRL61'], 0, 7, self.dec2gray(eclk_pos_decimal))
        self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DCOPI_CTRL61'], 7, 1, 1)
        time.sleep(10 / 1000000.0)

        self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DCOPI_CTRL61'], 8, 7, self.dec2gray(eclkb_pos_decimal))
        self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DCOPI_CTRL61'], 15, 1, 1)
        time.sleep(10 / 1000000.0)
        print(f" Touching DCOPI 61 Bits 0->6 and 8->14 Decimal: {eclk_pos_decimal} Gray: {self.dec2gray(eclk_pos_decimal)}")

        # Override bits
        print(f"DCLK: {dclk_pos_decimal} DCLKB: {dclkb_pos_decimal} ECLK :{eclk_pos_decimal} ECLKB: {eclkb_pos_decimal}")

        # Fix ECLK
        if eclk_pos_decimal != dclk_pos_decimal:
            if dclk_pos_decimal > eclkb_pos_decimal:
                direction = 1
            elif dclk_pos_decimal < eclkb_pos_decimal:
                direction = -1
            print(f" Direction: {direction}")
            for difference in range(eclk_pos_decimal, dclk_pos_decimal, direction):
                print(f" Walking Back Difference: {difference} Gray Value: {self.dec2gray(difference)}")
                self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DCOPI_CTRL61'], 0, 7, self.dec2gray(difference))
                time.sleep(10 / 1000000.0)
                self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DCOPI_CTRL61'], 8, 7, self.dec2gray(difference))
                time.sleep(10 / 1000000.0)
                print(f" Touching DCOPI 61 Bits 0->6 and 8->14 Decimal: {difference} Gray: {self.dec2gray(difference)}")

            self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DCOPI_CTRL61'], 0, 7, self.dec2gray(dclk_pos_decimal))
            time.sleep(10 / 1000000.0)

            self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DCOPI_CTRL61'], 8, 7, self.dec2gray(dclkb_pos_decimal))
            print(f" Touching DCOPI 61 Bits 0->6 and 8->14 Decimal: {dclkb_pos_decimal} Gray: {self.dec2gray(dclkb_pos_decimal)}")
            time.sleep(10 / 1000000.0)

            dclk_pos_decimal = self.gray2dec(self.get_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DCO_CTRL89_RO'], 14, 7))
            dclkb_pos_decimal = self.gray2dec(self.get_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DCO_CTRL89_RO'], 21, 7))

            eclk_pos_decimal = self.gray2dec(self.get_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DCOPI_CTRL611_RO'], 0, 7))
            eclkb_pos_decimal = self.gray2dec(self.get_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DCOPI_CTRL611_RO'], 7, 7))

            print(f"DCLK: {dclk_pos_decimal} DCLKB: {dclkb_pos_decimal} ECLK :{eclk_pos_decimal} ECLKB: {eclkb_pos_decimal}")

        # Step 4(a) - Enable H0 DAC (set it 0 to begin with, also enable error deserializer)
        # The register write should happen in following order with a gap of 1 μs between each write.
        # rxa_deser_ctrl91 not required if cfg0_eq.h0_dac_en is 1 (https://seg-docs.csg.apple.com/projects/ibiza/release/UserManual/regs/trunk/default/AUSPMA_RX_EQ.html?baseaddr=0x2a6719000#AUSPMA_RX_EQ_cfg0_eq)
        # rxa_deser_ctrl91 - https://seg-docs.csg.apple.com/projects/ibiza/release/UserManual/regs/trunk/default/AUSPMA_RX_SHM.html?baseaddr=0x2a671a000#AUSPMA_RX_SHM_auspma_rx_rxa_deser_ctrl91
        #   dfeh0dac_sml_en_ov = 1
        #   dfeh0dac_big_en_ov = 1
        #   dfeh0dac_sml_en = 1
        #   dfeh0dac_big_en = 1
        #   dfeh0dac_gray_ov = 1
        #   dfeh0dac_gray = 0

        print("Step 4(a) Enable H0 Dac (set it to 0 to begin with) also enable error deserializer.")

        self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DESER_CTRL91'], 17, 1, 1)
        self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DESER_CTRL91'], 18, 1, 1)

        self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DESER_CTRL91'], 15, 1, 1)
        self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DESER_CTRL91'], 16, 1, 1)

        self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DESER_CTRL91'], 19, 6, 0)
        self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DESER_CTRL91'], 25, 1, 1)

        # Step 4(b) - Write lane’s RX SHIM register, rxa_dfe_ctrl111 to control H0 DAC
        # rxa_dfe_ctrl111 - https://seg-docs.csg.apple.com/projects/ibiza/release/UserManual/regs/trunk/default/AUSPMA_RX_SHM.html?baseaddr=0x2a671a000#AUSPMA_RX_SHM_auspma_rx_rxa_dfe_ctrl111
        #   dfeh0dac_range_ov = 1
        #   dfeh0dac_range = 3

        print("Step 4(b)")
        self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DFE_CTRL111'], 0, 2, 3)
        self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DFE_CTRL111'], 2, 1, 1)

        # Step 5(a) - Enable Error deserializer (Data and Edge should already be enabled by PCTRL)
        # rxa_deser_ctrl91
        #   pma_rxa_deser_e_en_ov = 1
        #   pma_rxa_deser_e_en = 1

        print("Step 5(a) - Enable Error Deserializer (Data and Edge should already be enabled by PCTRL)")
        self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DESER_CTRL91'], 10, 1, 1)
        self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DESER_CTRL91'], 11, 1, 1)

        print("Skip 5(b) and 5(c)")

        # Skip 5(b) and 5(c)
        # Alternative 5(b) and 5(c) from Olivier
        # AUSPMA_RX_RXA_DCO_CTRL89_RO : for DCLK/DCLKB and AUSPMA_RX_RXA_DCOPI_CTRL611_RO for ECLK/ECLKB
        # Make sure they are at the same location. This should be the center of the eye
        # If ECLK/ECLKB are not at the same location as DCLK/DCLKB move them back to those locations (the rule that you can only move by one step at a time, still applies
        # AUSPMA_RX_SHM_auspma_rx_rxa_dco_ctrl89_ro - https://seg-docs.csg.apple.com/projects/ibiza/release/UserManual/regs/trunk/default/AUSPMA_RX_SHM.html?baseaddr=0x2a671a000#AUSPMA_RX_SHM_auspma_rx_rxa_dco_ctrl89_ro
        # AUSPMA_RX_SHM_auspma_rx_rxa_dco_ctrl611_ro - https://seg-docs.csg.apple.com/projects/ibiza/release/UserManual/regs/trunk/default/AUSPMA_RX_SHM.html?baseaddr=0x2a671a000#AUSPMA_RX_SHM_auspma_rx_rxa_dcopi_ctrl611_ro

        # To walk them back - AUSPMA_RX_RXA_DCOPI_CTRL61 - https://seg-docs.csg.apple.com/projects/ibiza/release/UserManual/regs/trunk/default/AUSPMA_RX_SHM.html?baseaddr=0x2a671a000#AUSPMA_RX_SHM_auspma_rx_rxa_dcopi_ctrl61

        print("Step 6 - Choose eye scan mask, to choose between composite, even/odd bits")
        print("Setting error mask to", self.error_mask)
        self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RX_EQ_CFG42_EQ'], 1, 2, self.error_mask)
        self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RX_EQ_CFG42_EQ'], 3, 1, 1)
        # Step 6 - Choose eye scan mask, to choose between composite, even/odd bits
        # RX EQ register, cfg42_eq - https://seg-docs.csg.apple.com/projects/ibiza/release/UserManual/regs/trunk/default/AUSPMA_RX_EQ.html?baseaddr=0x2a6719000#AUSPMA_RX_EQ_cfg42_eq
        # error_mask = 0x0 – composite scan (both even and odd are active)
        #            = 0x1 – only odd samplers’ output is used
        #            = 0x2 – only even samplers’ output is used
        #            = 0x3 – gated both even and odd samplers’ output
        # error_mask_ov = 1, if user wants to do either even or odd eye scan else write error_mask_ov = 0

    def capture_errors(self):
        """Enable the error accumulator, wait desired time, capture errors"""
        ##### Step B --> E helper method #####
        # Step B - Enable Error Accumulator
        # Write Rx Eq Register CFG46_EQ: EN_ERR_ACC=1

        # Step C - Wait for desired number of bits (dwell time)
        # PCIe Gen3, one UI = 125 ps (one bit) so for 10^12 bits the wait is 125 seconds

        # Step D - Read number of errors
        # Write Rx EQ register to capture the error count
        # CFG46_EQ Cap Err Acc = 1
        # Read Rx EQ Register CFG44_EQ ERR ACC
        # Write Rx EQ Register
        # CFG46_EQ CAP ERR ACC = 0

        # Step E - Disable Error Accumulator
        # Write Rx EQ Register CFG46 EQ EN_ERR_ACC = 0
        ##### Step B --> E helper method #####

        print("Capture Errors")
        print("Enable Error Accumulator - EN ERR ACC = 1")
        # en_err_acc = 1
        self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RX_EQ_CFG46_EQ'], 20, 1, 1)

        print(f"Wait Desired Time: {self.sleep_time}")
        # wait for desired number of bits
        time.sleep(self.sleep_time)

        print("Read Number of Errors - Write to Capture to Error, Read Register, Cancel Error Accumulate")
        self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RX_EQ_CFG46_EQ'], 19, 1, 1)
        errors = int(self.get_bits(self.camera_base_offset + LPDP_CAMERA_REG['RX_EQ_CFG44_EQ'], 12, 20))
        self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RX_EQ_CFG46_EQ'], 19, 1, 0)

        print(f"Found Errors: {errors}")

        print("Disable Error Accumulator - EN ERR ACC = 0")
        # en_err_acc = 0
        self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RX_EQ_CFG46_EQ'], 20, 1, 0)

        return errors


    def start_margining(self):
        """Start the Margining"""
        # Eyescan Steps A->G for vertical scan and H->I for horizontal scan
        # X-Value Pi-Codes, Y-Value-H0 Dac

        self.mid_x = int((self.min_x + self.max_x) / 2)
        self.mid_x = self.gray2dec(self.get_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DCO_CTRL89_RO'], 14, 7))
        self.min_x = self.mid_x - 32
        self.max_x = self.mid_x + 32

        # Sweep 64 to each side if not running full eye
        self.vco_bsel_div_code_r = int(self.get_bits(self.camera_base_offset + LPDP_CAMERA_REG['RX_TOP_CDR_CFG2'], 0, 2))
        self.log_key(key="lane_{}_div_code".format(self.current_lane), value=self.vco_bsel_div_code_r, units='ticks')
        # if vco_bsel_div_code_r < 3:
        #     self.min_x = self.mid_x - 64
        #     self.max_x = self.mid_x + 64
        # else:

        if int(self.vco_bsel_div_code_r) < 3:
            self.min_x = 0
            self.max_x = 127
        else:
            print("No Update Needed")

        # standard eye width ps
        self.TICK_TO_FREQUENCY = (self.TICK_TO_FREQUENCY / (2 ** abs(3-self.vco_bsel_div_code_r)))
        print(f"New Div Code: {self.vco_bsel_div_code_r} Tick To Freq: {self.TICK_TO_FREQUENCY}")

        print(f" Mid X: {self.mid_x} Min X: {self.min_x} Max X: {self.max_x}")
        print(f" Mid Y: {self.mid_y} Min Y: {self.min_y} Max Y: {self.max_y}")

        self.sleep_time = self.duration_ms / 1000

        print("Step A - Setup H0 Dac - CTRL91")

        # 20 -> 60
        # -31 -> 31

        # Start Position = 40

        # Can't presume starting at mid_x
        dclk_pos_decimal = self.gray2dec(self.get_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DCO_CTRL89_RO'], 14, 7))

        print("Start by bringing Timing to Min-X For Eye Scan")
        for time_coord in range(self.mid_x, self.min_x - 1, -1):
            print(f"Walking Back Time_Coord: {time_coord} Gray Value: {self.dec2gray(time_coord)}")
            # Walk back to Pi (Time) value = min_x
            self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DCOPI_CTRL61'], 0, 7, self.dec2gray(time_coord))
            time.sleep(10 / 1000000.0)
            self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DCOPI_CTRL61'], 8, 7, self.dec2gray(time_coord))
            time.sleep(10 / 1000000.0)

            print(f" Touching DCOPI 61 Bits 0->6 and 8->14 Decimal: {time_coord} Gray: {self.dec2gray(time_coord)}")

        self.x_axis = [] # 32 code each direction + 1 center
        print("Margin X-Axis")
        for time_coord in range(self.min_x, self.max_x + 1):
            print(f"Setting X-Axis Coord Value: {time_coord} Gray Value: {self.dec2gray(time_coord)}")
            self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DCOPI_CTRL61'], 0, 7, self.dec2gray(time_coord))
            time.sleep(10 / 1000000.0)
            self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DCOPI_CTRL61'], 8, 7, self.dec2gray(time_coord))
            time.sleep(10 / 1000000.0)

            print(f" Touching DCOPI 61 Bits 0->6 and 8->14 Decimal: {time_coord} Gray: {self.dec2gray(time_coord)}")

            print(f"Scanning X-Axis Time Coord {time_coord} for Error")
            self.x_axis.append(self.capture_errors())

            ### Additional Logging ###
            deserializer_output = self.get_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_LPBK_CTRL_OBS4_RO'], 0, 20)
            vco_bsel_range_code_r = self.get_bits(self.camera_base_offset + LPDP_CAMERA_REG['RX_TOP_CDR_CFG2'], 2, 2)
            self.vco_bsel_div_code_r = self.get_bits(self.camera_base_offset + LPDP_CAMERA_REG['RX_TOP_CDR_CFG2'], 0, 2)
            print(f"Setting X-Cord Decimal: {time_coord} Gray: {self.dec2gray(time_coord)} Deserializer Output: {deserializer_output} "
                  f"BSEL Range Code: {vco_bsel_range_code_r} BSEL Div Code: {self.vco_bsel_div_code_r}")

        print("Bring X Timing Coordinate Back to Middle for Voltage Scan")
        for time_coord in range(self.max_x, self.mid_x - 1, -1):
            print(f"Walking Back Time_Coord: {time_coord} Gray Value: {self.dec2gray(time_coord)}")
            # Walk back to Pi (Time) value = min_x
            self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DCOPI_CTRL61'], 0, 7, self.dec2gray(time_coord))
            time.sleep(10 / 1000000.0)
            self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DCOPI_CTRL61'], 8, 7, self.dec2gray(time_coord))
            time.sleep(10 / 1000000.0)

            print(f" Touching DCOPI 61 Bits 0->6 and 8->14 Decimal: {time_coord} Gray: {self.dec2gray(time_coord)}")

        # ToDo: Once done iterating X what does AUS40PMA_RX_APB_OVERRIDE_REG_50 mean?

        self.y_axis = []
        for voltage in range(self.min_y, self.max_y + 1):
            print(f"Scanning Y-Axis Voltage: {voltage} Dec to Grey: {self.dec2gray(abs(voltage))} INT2SA Vos Code: {self.int2sa_vos_code(voltage)}")
            self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DESER_CTRL91'], 19, 6, self.int2sa_vos_code(voltage))
            time.sleep(1 / 1000000.0)
            self.y_axis.append(self.capture_errors())

        print("Walk back h0dac")
        for voltage in range(self.max_y, self.mid_y-1, -1):
            print(
                f"Scanning Y-Axis Voltage: {voltage} Dec to Grey: {self.dec2gray(abs(voltage))} INT2SA Vos Code: {self.int2sa_vos_code(voltage)}")
            self.set_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_DESER_CTRL91'], 19, 6,
                          self.int2sa_vos_code(voltage))
            time.sleep(1 / 1000000.0)

        print(f"X-Axis: {self.x_axis}")
        print(f"Y-Axis: {self.y_axis}")

        # Pi - Time - X-Axis - Steps H/I
        # Vol - Voltage - Y-Axis - Steps A/G

        # Step A - Setup H0 Dac - CTRL91
        #   DFEH0DAC_GRAY[5] = sign bit - 0 for positive sign and 1 for negative sign
        #   DFEH0DAC_GRAY[4:0] = DEC2GRAY(Value)

        # Step F - Iterate h0dac
        # Decrerment H0 DAC
        # Write Rx SHIM Register RX_DESER_CTRL91
        # DFEH0DAC_GRAY[5] = Sign Bit
        # DFEh0DAC_GRAY[4:0] = DEC2Gray(Prev_value-1)

        # At the end of Y-axis
        # Write RRx SHIM Register RX DESER CTRL91.DFEH0DAC_GRAY[5:0] Walk Back to Mid Value for X-axis

        # Step H Iterate Pi Codes
        # Covered all values? AUS40PMA_RX_APB_OVERRIDE_REG_50
        # ECKL_POS_GRAY / ECLKB_POS_GRAY -> Once Done Walk Back to the middle

        # Otherwise Increment Err_Pos by 1
        # Write RX SHIM Register RXA DCOPI_CTRL61
        # ECLK_POS_GRAY = Dec2Gray(Prev + 1)
        # ECLKB_POS_GRAY = Dec2Gray(Prev + 1)

        # At the end of the testing clear all margining registers and retrain link

    def save_eye(self):
        """Save the Eye Diagram"""
        f = open(self.log_path + "\eyemargin_camera.csv", "w")
        for y in range(0, len(self.y_axis)):
            row_write = ""
            self.mid_y = int((self.min_y + self.max_y) / 2)
            if y != int(self.mid_y - self.min_y):
                for x in range(0, self.mid_x - self.min_x):
                    row_write += " ,"  # pad so that the column for axis is in the middle
                row_write += f"{self.y_axis[y]},"
                for x in range(self.mid_x - self.min_x, self.max_x - self.min_x):
                    row_write += " ,"  # pad so that the column for axis is in the middle
            else:
                for value in self.x_axis:
                    row_write += f"{value},"
            row_write = row_write + '\n'
            f.write(row_write)
            print(f" Row: {row_write}")

        f.close()

    def calculate_eye(self):
        """Calculate the Eye Diagram for axis only"""
        self.save_eye()

        north, south, east, west = self.mid_y, self.mid_y, self.mid_x, self.mid_x

        print(f"Y-axis: {self.y_axis} X-axis {self.x_axis}")

        for coord in range(self.mid_y, self.max_y + 1):
            if self.y_axis[coord - self.min_y] == 0:
                north = coord
            if self.y_axis[coord - self.min_y] != 0:
                break

        for coord in range(self.mid_y, self.min_y - 1, -1):
            if self.y_axis[coord - self.min_y] == 0:
                south = coord
            if self.y_axis[coord - self.min_y] != 0:
                break

        for coord in range(self.mid_x, self.max_x + 1):
            if self.x_axis[coord - self.min_x] == 0:
                east = coord
            if self.x_axis[coord - self.min_x] != 0:
                break

        for coord in range(self.mid_x, self.min_x - 1, -1):
            if self.x_axis[coord - self.min_x] == 0:
                west = coord
            if self.x_axis[coord - self.min_x] != 0:
                break

        print(f"North: {north} South: {south} East: {east} West: {west}")

        height = north + abs(south)
        width = (east - west)
        print(f"Height: {height} Width: {width}")

        dfe_range_factor = self.get_bits(self.camera_base_offset + LPDP_CAMERA_REG['DFE_CTRL13_RO'], 29, 2)
        if dfe_range_factor is 0:
            dfeh0dac_range = 0.5
        elif dfe_range_factor is 1:
            dfeh0dac_range = 1
        elif dfe_range_factor is 2:
            dfeh0dac_range = 1.5
        else:
            dfeh0dac_range = 2

        afe_spare_0 = self.get_bits(self.camera_base_offset + LPDP_CAMERA_REG['RXA_ACCAP_CTRL5_RO'], 26, 1)
        print(f"dfe_range_factor: {dfe_range_factor} and afe_spare_0: {afe_spare_0}")

        if int(self.vco_bsel_div_code_r) >= 3:
            num_pi_codes = 64
        elif int(self.vco_bsel_div_code_r) == 2:
            num_pi_codes = 128
        elif int(self.vco_bsel_div_code_r)  == 1:
            num_pi_codes = 256
        elif int(self.vco_bsel_div_code_r) == 0:
            num_pi_codes = 512

        max_ps = num_pi_codes * self.TICK_TO_FREQUENCY
        print(f"Total width in ps: {max_ps}")

        if height >> 0 and width >> 0:
            self.eye_height[self.current_lane] = self.TICK_TO_VOLTAGE * (1+0.25*afe_spare_0) * dfeh0dac_range * (north + abs(south))
            self.eye_width[self.current_lane] = self.TICK_TO_FREQUENCY * (east - west)
            self.eye_height_ticks[self.current_lane] = north + abs(south)
            self.eye_width_ticks[self.current_lane] = east - west
        else:
            if height >> 0:
                self.eye_height[self.current_lane] = self.TICK_TO_VOLTAGE * (1+0.25*afe_spare_0) * dfeh0dac_range * (north + abs(south))
                self.eye_width[self.current_lane] = 0
                self.eye_height_ticks[self.current_lane] = north + abs(south)
                self.eye_width_ticks[self.current_lane] = 0
            elif width >> 0:
                self.eye_height[self.current_lane] = 0
                self.eye_width[self.current_lane] = self.TICK_TO_FREQUENCY * (east - west)
                self.eye_height_ticks[self.current_lane] = 0
                self.eye_width_ticks[self.current_lane] = east - west
            else:
                self.eye_height[self.current_lane] = 0
                self.eye_width[self.current_lane] = 0
                self.eye_height_ticks[self.current_lane] = 0
                self.eye_width_ticks[self.current_lane] = 0

        # Log them to the result file
        self.log_key(key="lane_{}_north_ticks".format(self.current_lane), value=north, units='ticks')
        self.log_key(key="lane_{}_south_ticks".format(self.current_lane), value=south, units='ticks')
        self.log_key(key="lane_{}_east_ticks".format(self.current_lane), value=east, units='ticks')
        self.log_key(key="lane_{}_west_ticks".format(self.current_lane), value=west, units='ticks')
        self.log_key(key="lane_{}_eh_mv".format(self.current_lane), value=self.eye_height[self.current_lane],
                     units='mV', upperlimit=self.eh_max, lowerlimit=self.eh_min)
        self.log_key(key="lane_{}_ew_ui".format(self.current_lane), value=(self.eye_width[self.current_lane] /  max_ps),
                     units='ui')
        self.log_key(key="lane_{}_ew_ps".format(self.current_lane), value=self.eye_width[self.current_lane],
                     units='ps', upperlimit=self.ew_max, lowerlimit=self.ew_min)
        self.log_key(key="lane_{}_eh_ticks".format(self.current_lane), value=self.eye_height_ticks[self.current_lane],
                     units='ticks')
        self.log_key(key="lane_{}_ew_ticks".format(self.current_lane), value=self.eye_width_ticks[self.current_lane],
                     units='ticks')

        self.log_msg("Lane {}: north = {}, south = {}, east = {}, west = {}, ns = {}mV, ew = {}ui".format(
            self.current_lane,
            north,
            south,
            east,
            west,
            self.eye_height[self.current_lane],
            self.eye_width[self.current_lane]
        ))

    #
    # Helpers
    #
    def progress(self):
        """Progress in integer % increments"""
        self.log_msg("   {}%".format(self._fake_progress))
        return self._fake_progress

    def is_running(self):
        """Check if Margining is running"""
        return self.progress < 100

    def all_lanes_scanned(self, lane):
        """Check if all lanes scanned, Used for tools that need to have individual lanes scanned"""
        if lane == self.LANE_COUNT:
            return 1
        else:
            self.log_msg("Didnt complete all lanes")

    def wait_for_finish(self):
        return 1