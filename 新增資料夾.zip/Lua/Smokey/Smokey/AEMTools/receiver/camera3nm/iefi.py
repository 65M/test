"""Access for iEFI"""
from .base import AbstractReceiverMarginTool
from shell import run


__all__ = [
	"MarginTool"
]


def n_lsb(x):
	return (1 << x) - 1


def n_to_m(n, m):
	return n_lsb(n) & ~ n_lsb(m)


class MarginTool(AbstractReceiverMarginTool):
	"""Margin Tool Instance"""
	def grab_camera_voltage_i2c_register(self, register):
		"""Grab an I2C Register Value"""
		output = run(f"camisp --i2cread 0 0x36 {register} 2 1")
		value = None
		for line in output.split('\n'):
			if ("0x" in line) and ("RunI2cRead" not in line):
				value = line.strip().split("0x")[-1]
				value = value.split(" ")[0]
				value = int(value, 16)
				print(f"Found {register} Output Value: {value}")
		return value

	def dump_link_voltage(self):
		"""Dump the Camera Link Voltage"""
		print("Dump Link Voltage")
		value = self.grab_camera_voltage_i2c_register(hex(self.camera_voltage_register))
		# 0->4 = 200 mV 0->3 (crip)
		# 5 - 225 mV
		# 6 - 250 mV
		# 7 - 275 mV
		# 8 - 300 mV
		# 9 - 325 mV
		# 10 - 350 mV
		# 11 - 375 mV
		# 12 - 400 mV
		# 13 - 425 mV
		# 14 - 450 mV (default)
		# 15 - 450 mV (crip)
		self.log_key(key="camera_voltage_level", value=self.camera_voltage_translation[value], units='mV')
		print(f"Dump Link Voltage - Completed With Found Voltage Level: {self.camera_voltage_translation[value]}")
		return value

	def dump_link_datarate(self):
		"""Dump the Camera Link Data Rate"""
		print("Dump Link Data Rate")
		value1 = self.grab_camera_voltage_i2c_register("0x528")
		value2 = self.grab_camera_voltage_i2c_register("0x529")
		value3 = self.grab_camera_voltage_i2c_register("0x52A")
		print(f"Value 1: {value1} Value 2: {value2} Value 3: {value3}")

		# (0x0528 * 1024 + 0x529 * 4 + 0x52A) * 50,000
		link_rate = int(((value1 * 1024) + (value2 * 4) + value3) * 50000)

		# Validate LinkRate
		if self.camera_linkrate is not None:
			print(f"Verify LinkRate: {self.verify_linkrate}")
			if self.camera_linkrate != link_rate and str(self.verify_linkrate) == "True":
				raise Exception(f"Expected Project Linkrate: {self.camera_linkrate} does not match measured rate: {link_rate}")
			elif self.camera_linkrate != link_rate:
				print("Link Rate Doesn't Match Up, But Verification Skipped")
		else:
			print("No Camera Linkrate Provided For Project")

		print(f"Link Rate: {link_rate}")
		self.log_key(key="camera_link_rate", value=link_rate, units='ticks')
		self.TICK_TO_FREQUENCY = 10 ** 12 / (link_rate * 64)


	def ensure_link(self):
		"""Check Link meet Speed / Width requirements"""
		if bool(self.doe) is not True:
			# Confirm stream is off
			try:
				print("Turn off Stream Current State")
				run("camisp --stream off", True)
			except Exception as e:
				print(f"Continue Stream Off: {e}")

			run("consolerouter -a -s imageprocessor.* --dest serial")
			# run("debug --on")
			run("camisp --dbgfw on ;camisp --on; camisp --stream on")
			run("camisp --method setmipifreq -1")
		else:
			print("DOE Mode, Skipping Ensure Link Because Swing Level Handles This")

		if self.swing:
			print(f"Found Desired Swing Level: {int(self.swing)}")

			try:
				print("Turn off Stream Current State")
				run("camisp --stream off", True)
			except Exception as e:
				print(f"Continue Stream Off: {e}")

			run("consolerouter -a -s imageprocessor.* --dest serial")
			# run("debug --on")
			run("camisp --dbgfw on ;camisp --on;")

			print("set next swing level to {}mV".format(int(self.swing)))
			run("camisp --method sethsoutputlevel {}".format(int(self.swing)))

			print('Finish enabling')
			run("camisp --stream on")
			run("camisp --method setmipifreq -1")

			print('read swing')
			run("camisp --i2cread 0 0x36 0x0518 2 1")
			run("camisp --i2cread 0 0x36 0x0519 2 1")
			run("camisp --i2cread 0 0x36 0x0550 2 1")
			run("camisp --i2cread 0 0x36 0x0525 2 1")

		self.dump_link_voltage()
		self.dump_link_datarate()


	def set_bits(self, address, start_bit, length, value):
		"""Read registers"""
		mm_data = run("mm -w 4 -n {}".format(hex(address)))
		if "MEM" in mm_data:
			end_bit = start_bit + length
			a = mm_data.split(": ")
			reg_val = a[1].strip("\r\n")
			result = hex((int(reg_val, 16) & ~n_to_m(end_bit, start_bit)) | value << start_bit)
			run("mm -w 4 -n {} {}".format(hex(address), result))
			run("mm -w 4 -n {}".format(hex(address)))
		else:
			raise Exception("Set bits failed")

	def get_bits(self, address, start_bit, length):
		"""Read registers"""
		mm_data = run("mm -w 4 -n {}".format(hex(address)))
		if "MEM" in mm_data:
			a = mm_data.split(": ")
			reg_val = a[1].strip("\r\n")
			bin_val = '{:>032}'.format(bin(int(reg_val, 16))[2:])
			end_pos = 31 - start_bit + 1
			start_pos = 31 - start_bit - length + 1
			bits = int(bin_val[start_pos:end_pos], 2)
			return bits
		else:
			raise Exception("Get bits failed")

	def write_register(self, address, data):
		"""Write an offset"""

		run("mm -w 4 -n {}".format(hex(address)))

		mm_data = run("mm -w 4 -n {} {}".format(hex(address), hex(data)))
		run("mm -w 4 -n {}".format(hex(address)))

		if "Error" in mm_data:
			raise Exception("Write Register failed")

	def read_register(self, address):
		"""Read an offset"""
		mm_data = run("mm -w 4 -n {}".format(hex(address)))
		if "MEM" in mm_data:
			a = mm_data.split(": ")
			reg_val = a[1].strip("\r\n")
			return reg_val
		else:
			raise Exception("Read Register failed")
