# Camera Receiver New N3 Margining equence


References from https://stashweb.sd.apple.com/projects/LLDIAGS/repos/factoryllscriptsplatforms/browse/Smokey/CAM_LPDP