_all_ = [
    'SOC_0x8122',  # Ibiza
    'SOC_0x8130',  # Coll
    'SOC_0x8120',  # Crete
    'SOC_0x6030',  # Lobos
    'SOC_0x6031',  # Palma 1 C
    'SOC_0x6034',  # Palma M
    'SOC_0x8132',  # Donan
    'SOC_CONVERSION_CODE'
]

"""
----- Register Definition ----
	SOC SISP Offset = Base Register Address of SISP Subsystem
					(Normally located within an AFNC Fabric on SEG Docs or Stand Alone)
	SOC Lane0 Offset = Offset from SOC SISP Offset to LPDPRX Lane 0 Subsystem Address 
					(Normally located within an SISP -> LPDPC Subsystem -> LPDP RX 2L on SEG Docs
	SOC LPDPRX Lane Offset = Offset from SOC Lane0 Offset to SOC Lane 1 Base Address
"""

SOC_0x8112 = {  # Ibiza
    'SOC_SISP_OFFSET': 0x2a4000000, # 0x2a4000000
    'SOC_LANE0_OFFSET':  0x25D0000, # 0x2a65d0000
    'SOC_LPDP_RX0_OFFSET':0x140000,#  0x2a6710000
    'SOC_LPDPRX_LANE_OFFSET': 0x8000,
}

SOC_0x8130 = {  # Coll
    'SOC_SISP_OFFSET':    0x298000000, # 0x298000000
    'SOC_LANE0_OFFSET':     0x25D0000, # 0x29a5d0000
    'SOC_LPDP_RX0_OFFSET':   0x140000, # 0x29a710000
    'SOC_LPDPRX_LANE_OFFSET':  0x8000, #
}

SOC_0x8120 = { # Crete
    'SOC_SISP_OFFSET':    0x22a000000, # 0x22a000000
    'SOC_LANE0_OFFSET':     0x25D0000, # 0x22c5d0000
    'SOC_LPDP_RX0_OFFSET':   0x140000, #
    'SOC_LPDPRX_LANE_OFFSET': 0x8000,
}

SOC_0x6030 = {  # Lobos
    'SOC_SISP_OFFSET':  0x2c8000000,
    'SOC_LANE0_OFFSET':   0x25D0000,  # 0x0002ca5d0000
    'SOC_LPDP_RX0_OFFSET': 0x140000,  # 0x0002ca710000
    'SOC_LPDPRX_LANE_OFFSET': 0x8000, #
}

SOC_0x6031 = {  # Palma 1 C
    'SOC_SISP_OFFSET':   0x38c000000, # 0x38c000000
    'SOC_LANE0_OFFSET':    0x25D0000, # 0x38e5d0000
    'SOC_LPDP_RX0_OFFSET':  0x140000, # 0x38e710000
    'SOC_LPDPRX_LANE_OFFSET': 0x8000, #
}

SOC_0x6034 = {  # PalmaM
    'SOC_SISP_OFFSET':   0x38c000000, # 0x38c000000
    'SOC_LANE0_OFFSET':    0x25D0000, # 0x38e5d0000
    'SOC_LPDP_RX0_OFFSET':  0x140000, # 0x38e710000
    'SOC_LPDPRX_LANE_OFFSET': 0x8000, #
}


SOC_0x8132 = { # Donan
    'SOC_SISP_OFFSET': 0x48c000000,   # 0x48c000000
    'SOC_LANE0_OFFSET':  0x29D0000,   # 0x48e9d0000
    'SOC_LPDP_RX0_OFFSET': 0x140000,  # 0x48eb10000
    'SOC_LPDPRX_LANE_OFFSET': 0x8000, # 0x48eb18000
}


SOC_CONVERSION_CODE = {
    '8122': SOC_0x8112,  # Ibiza
    '8130': SOC_0x8130,  # Coll
    '8120': SOC_0x8120,  # Crete
    '6030': SOC_0x6030,  # Lobos
    '6031': SOC_0x6031,  # Palma
    '6034': SOC_0x6034,  # PalmaM
    '8132': SOC_0x8132,  # Donan
}
