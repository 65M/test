from .defines import *
from ..base import AbstractBaseMarginTool
from ..defines import MarginException
import re
import sys
import time
__all__ = [
    "AbstractReceiverMarginTool"
]

# Add -dp2hdmi-update-mode to boot-args
# ./goldrestore2_cobra ps190 stage assettype=localfile assetlocation=0x02_0x48_S_0x00_DmemImem.bin

class AbstractReceiverMarginTool(AbstractBaseMarginTool):
    """Generic Interface for Cobra (HDMI) Margining"""
    LANE_COUNT = 4  # Number of Lanes
    dprx = 0


    def __init__(self, *args, **kwargs):
        super(AbstractReceiverMarginTool, self).__init__(*args, **kwargs)
        print("Init Code")

        self.eq_value_check = 0
        self.figure_of_merit = 0
        self.ioavtool_root = None
        print(f"Device Index: {self.device_index}")
        if self.device_index is not None and not sys.platform.startswith('uefi'):
            print("Matching Root")
            matched_root = self.match_root_display()
            self.ioavtool_root = self.match_root_index(matched_root)

            if self.ioavtool_root is None:
                raise Exception("Unable to find ioavtool HDMI root with Bit 6 = Device Index."
                                "Halting margining to prevent unexpected behavior")

        print(f"Current Ioavtool Root: {self.ioavtool_root} Device Index: {self.device_index}")


    def parse_ioavtool_roots(self):
        """Parse ioavtool roots"""

    def match_root_index(self, matched_root):
        """Match HDMI Roots to Valid Index"""

    def match_root_display(self):
        """Match each root to an ioavtool display"""

    def read_register(self, device_index, offset, length):
        """Read an offset"""

    def read_register_bytes(self, device_index, offset, length):
        """Read an offset"""

    def write_register(self, device_index, offset, length, values):
        """Write an offset"""

    def ensure_link(self):
        """Check Link meets Speed / Width requirements"""

    def ensure_link_doe(self):
        """Check Link meets Speed / Width requirements"""

    def is_running(self):
        """Check if Margining is running"""
        print("Kickoff Is Running")
        # bit 6 to 1 and bit 7 to 0 to indicate running
        # bit 6 to 0 and bit 7 to 1 to indicate completion
        print("Starting 65s Sleep Running (Due to Longer Running Delay)")
        time.sleep(65) # Don't overload the requests with polling
        print("Sleep Done")
        status_register = -1
        try:
            status_register = int(self.read_register(device_index=self.ioavtool_root, offset=DPCD_REG.BATHTUB_STATUS, length=1), 16)
            bit6 = (status_register >> 6) & 0x1
            bit7 = (status_register >> 7) & 0x1
        except ValueError:
            # If value error reading, keep trying until timeout
            bit6 = 1
            bit7 = 0
        status = bit6 or int(not bit7)
        print(f"Status Register: {hex(status_register)} Bit 6: {bit6} Bit 7: {bit7} Net Status: {status}")
        # bit 6 to 0 and bit 7 to 1 to indicate complete
        return status

    #
    # Standard Methods
    #

    def disable_power_management(self):
        """Disable Power Management Modes"""
        pass  # Nothing to do

    def select_lane(self, lane):
        """Select a Lane"""
        self.current_lane = lane

    def check_eq_value(self):
        # Check Current EQ Value
        print("Read EQ Value")
        """
        enableCobraRegAccess()
	    print ("Final trained RxCTLE band:", readCobraRegByte(0x0f, 0xaf) & 0x0f)
	    disableCobraRegAccess()
        """
        # Enable Cobra Register Access
        self.write_register(
            device_index=self.ioavtool_root,
            offset=BATHTUB_START.DPCD_REGISTER_1,
            length=1,
            values="0x50"
        )
        self.write_register(
            device_index=self.ioavtool_root,
            offset=BATHTUB_START.DPCD_REGISTER_1,
            length=1,
            values="0x41"
        )
        self.write_register(
            device_index=self.ioavtool_root,
            offset=BATHTUB_START.DPCD_REGISTER_1,
            length=1,
            values="0x52"
        )
        self.write_register(
            device_index=self.ioavtool_root,
            offset=BATHTUB_START.DPCD_REGISTER_1,
            length=1,
            values="0x41"
        )
        self.write_register(
            device_index=self.ioavtool_root,
            offset=BATHTUB_START.DPCD_REGISTER_1,
            length=1,
            values="0x41"
        )
        self.write_register(
            device_index=self.ioavtool_root,
            offset=BATHTUB_START.DPCD_REGISTER_1,
            length=1,
            values="0x55"
        )
        self.write_register(
            device_index=self.ioavtool_root,
            offset=BATHTUB_START.DPCD_REGISTER_1,
            length=1,
            values="0x58"
        )
        self.write_register(
            device_index=self.ioavtool_root,
            offset=BATHTUB_START.DPCD_REGISTER_1,
            length=1,
            values="0x02"
        )
        self.write_register(
            device_index=self.ioavtool_root,
            offset=BATHTUB_START.DPCD_REGISTER_1,
            length=1,
            values="0x52"
        )
        self.write_register(
            device_index=self.ioavtool_root,
            offset=BATHTUB_START.DPCD_REGISTER_1,
            length=1,
            values="0x45"
        )
        self.write_register(
            device_index=self.ioavtool_root,
            offset=BATHTUB_START.DPCD_REGISTER_1,
            length=1,
            values="0x47"
        )

        # Read Cobra Register Byte
        self.write_register(
            device_index=self.ioavtool_root,
            offset=BATHTUB_START.DPCD_REGISTER_2,
            length=1,
            values="0x40"
        )
        self.write_register(
            device_index=self.ioavtool_root,
            offset=BATHTUB_START.DPCD_REGISTER_3,
            length=1,
            values="0x10"
        )
        self.write_register(
            device_index=self.ioavtool_root,
            offset=BATHTUB_START.DPCD_REGISTER_4,
            length=1,
            values="0x0F"
        )
        self.write_register(
            device_index=self.ioavtool_root,
            offset=BATHTUB_START.DPCD_REGISTER_5,
            length=1,
            values="0xAF"
        )

        output = self.read_register(
            device_index=self.ioavtool_root,
            offset=BATHTUB_START.DPCD_REGISTER_6,
            length=1,
        )
        eq_value = int(output, 16) & 0xF
        print("EQ Value: {} ".format(eq_value))

        self.write_register(
            device_index=self.ioavtool_root,
            offset=BATHTUB_START.DPCD_REGISTER_1,
            length=1,
            values="0x00"
        )
        output = self.read_register(
            device_index=self.ioavtool_root,
            offset=BATHTUB_START.DPCD_REGISTER_1,
            length=1,
        )
        if not int(output, 16) == 0:
            raise Exception("Register Disable Eerror")
        print("Register Disable OK")

        return eq_value


    def setup_margining(self):
        """Configure the PHY and Setup Margining"""
        print("Current Lane: {}".format(self.current_lane))
        print("Enable EDID Override")
        output = self.read_register(
            device_index=self.ioavtool_root,
            offset=EDID_OVERRIDE.REGISTER_OVERRIDE,
            length=1
        )
        print("Setting output: {} bit 1 to 1".format(output))
        output = hex(int(output, 16) | 0x2)
        print("New output: {}".format(output))

        print("Overriding EDID override register")
        self.write_register(
            device_index=self.ioavtool_root,
            offset=EDID_OVERRIDE.REGISTER_OVERRIDE,
            length=1,
            values=output
        )

        # Steve investigating required delay
        # print("Set Register 514 to a 3000 ms Delay from 800 ms")
        # output = int(0x6E) # 20 ms delay increments
        # self.write_register(
        #     device_index=self.ioavtool_root,
        #     offset=DPCD_REG.DELAY_SETUP,
        #     length=1,
        #     values=output
        # )
        # print("Done With Setting Register 514 to a 3000 ms Delay from 800 ms")
        # self.log_key(key="slot:{}_lane:{}_eq_bypass".format(self.device_index, self.current_lane), value=eq_value, units="ticks")

    def start_margining(self):
        """Run Margining"""
        print("Do EQ Read Here Post EDID Override - Final Trained RX CTLE Band")

        print("Poll for EQ Value Stabilization")
        values = [-1, -1, -1, -1]
        for attempt in range(60):
            time.sleep(1)
            index = attempt % 4
            eq_value = self.check_eq_value()
            print(f"Attempt: {attempt} Index: {index} Values: {values} EQ Value: {eq_value}")
            values[index] = eq_value

            expected_value = sum(values) / 4
            if all([v == expected_value for v in values]):
                break

        if bool(self.doe) is True:
            if self.figure_of_merit != expected_value:
                raise Exception(f"Unable to verify updated EQ to: {int(self.figure_of_merit)}")
            else:
                print(f"Confirmed Updated EQ Value: {expected_value} Matches FOM: {int(self.figure_of_merit)}")

        print("Save Final Trained EQ Values")
        for index in range(0, self.gen_width):
            print(f"Finding Trained EQ for lane in Gen Width: {index}")
            eq_value = self.check_eq_value()
            self.log_key(key="Slot:{}_Lane:{}_Trained_EQ".format(self.device_index, index), value=eq_value,
                         units='ticks', fom_key="EQ", retry=True)

        print("Dump Cobra FW")
        output = self.read_register(
            device_index=self.ioavtool_root,
            offset=DPCD_REG.COBRA_FW_1,
            length=1,
        )
        print(f"Dump Cobra FW 1: {output}")
        output = self.read_register(
            device_index=self.ioavtool_root,
            offset=DPCD_REG.COBRA_FW_2,
            length=1,
        )
        print(f"Dump Cobra FW 2: {output}")

        print("Current Lane: {}".format(self.current_lane))
        output = self.read_register(
            device_index=self.ioavtool_root,
            offset=DPCD_REG.BATHTUB_CTRL,
            length=1,
        )
        # keep the previous value and set bit 0 of 0x518 to 1 to kick off margining
        print("Kick off margining by setting bit 0 of 0x518 to 0 and then 1 - ignoring the old value")
        self.write_register(
            device_index=self.ioavtool_root,
            offset=DPCD_REG.BATHTUB_CTRL,
            length=1,
            values=hex(int(output, 16) & 0xFE)  # Bit 0 of 0x518 to 0 to start margining, preserve rest
        )
        print("Set Register to 1")
        self.write_register(
            device_index=self.ioavtool_root,
            offset=DPCD_REG.BATHTUB_CTRL,
            length=1,
            values=hex(int(output, 16) | 0x1)  # Bit 0 of 0x518 to 1 to kick off margining
        )
        print("Done Start Margining")

    def dump_registers(self, initial=False):
        """Dump  Registers"""
        print("Dump Registers with Initial: {}, Skipping For Now".format(initial))
        print("Final Trained Voltage Swing")
        if initial:
            for index in range(0, self.gen_width):
                output = int(self.read_register(
                    device_index=self.ioavtool_root,
                    offset=EQ_SETTINGS.LANE[index],
                    length=1,
                ), 16)
                if index % 2 == 1: # lanes 1, 3 are bits 4-5 else bits 0->1
                    output = output >> 4
                output = output & 3
                self.log_key(key="Slot:{}_Lane:{}_Swing".format(self.device_index, index), value=output, units='ticks', fom_key="EQ", retry=True)

            print("Final Trained Pre-Emphasis")
            for index in range(0, self.gen_width):
                output = int(self.read_register(
                    device_index=self.ioavtool_root,
                    offset=EQ_SETTINGS.LANE[index],
                    length=1,
                ), 16)
                if index % 2 == 1: # lanes 1, 3 are bits 6-7 else bits 2-3
                    output = output >> 6
                else:
                    output = output >> 2
                output = output & 3
                self.log_key(key="Slot:{}_Lane:{}_PreEmphasis".format(self.device_index, index), value=output, units='ticks', fom_key="EQ", retry=True)


    def parse_margin_data(self):
        """Parse data to the necessary format(s)"""
        print("Dumping 0x205 At Margining End")
        try:
            output = self.read_register(
                device_index=self.ioavtool_root,
                offset="0x205",
                length=1,
            )
            print("Parse Margin Data Output 0x205: {}".format(output))
        except IndexError:
            print("Index Error 0x205 Read")
        print("Current Lane: {}".format(self.current_lane))
        data_lanes = []
        for lane in range(0, self.gen_width):
            print("Parse Data for Lane: {} checking index: {}".format(lane, (lane * 2)))
            # Only need to read one byte per because values are 0000 -> 0007
            data = self.read_register_bytes(
                                      device_index=self.ioavtool_root,
                                      offset=DPCD_REG.BATHTUB_RESULT[lane * 2],
                                      length=1)[0]
            jitter = {"00": 0, "01": 40, "02": 80, "03": 120, "04": 161, "05": 202, "06": 244, "07": 286}
            # Jitter Equivalences: 000 == > 0 001 == > 40 010 == > 80 011 == > 120 100 == > 161 101 == > 202 110 == > 244 111 == > 286
            # ToDo: Fix how EQ is reported while setting up for DOEs.
            print("Found Max Jitter Value: {} and Jitter Amount: {}".format(data, jitter[data]))

            if jitter[data] <= self.eh_min:
                print("Failure detected...Retrying the command")
                self.retry_flag = 1
                time.sleep(10)
                return
            else:
                self.retry_flag = 0

            self.log_key(
                key="Slot:{}_Lane:{}_MaxJitterLevel_mUI".format(self.device_index, lane),
                value=jitter[data], units='ticks', lowerlimit=self.eh_min, fom_key="EQ", retry=True)
            self.log_msg(
                "Slot:{}_Lane:{}_EQ:{}_MaxJitterLevel:{}".format(
                    self.device_index,
                    lane,
                    self.eq_value_check, jitter[data]))
            data_lanes.append(data)

        return data_lanes

    def clean_up(self):
        """Clean up margining and reset the PHY"""
        print("CleanUp, Try Reading a Random Register to see if it's Up")
        try:
            output = self.read_register(
                device_index=self.ioavtool_root,
                offset="0x0",
                length=1,
            )
            print("CleanUp Output 0x0: {}".format(output))
        except IndexError:
            print("Index Error 0x0 Read")

        try:
            output = self.read_register(
                device_index=self.ioavtool_root,
                offset="0x205",
                length=1,
            )
            print("CleanUp Output 0x205: {}".format(output))
        except IndexError:
            print("Index Error 0x205 Read")

        try:
            output = self.read_register(
                device_index=self.ioavtool_root,
                offset="0x200",
                length=1,
            )
            print("CleanUp Output 0x200: {}".format(output))
        except IndexError:
            print("Index Error 0x200 Read")

    def calculate_eye(self):
        """Calculate the Eye Diagram"""
        # Get the data for the lane (list of margin values)
        # Simple flow of checking the max jitter value for each from Cobra
        self.parse_margin_data()

        if self.retry_flag == 1:
            return

        # read extra registers
        result = self.read_register_bytes(device_index=self.ioavtool_root, offset=0x210, length=8)
        print('Dumping registers 0x210-0x217: ', result)
        self.log_msg(f'Dumping registers 0x210-0x217: {result}')
        self.seq_log.info(f'Dumping registers 0x210-0x217: {result}')

        print("Final Post Test Trained RX CTLE Band")
        for index in range(0, self.gen_width):
            print(f"Finding Trained EQ for lane in Gen Width: {index}")
            eq_value = self.check_eq_value()
            self.log_key(key="Slot:{}_Lane:{}_PostTest_Trained_EQ".format(self.device_index, index), value=eq_value, units='ticks', fom_key="EQ", retry=True)


        # Post Execution Clear Eye Per Steve
        print("Write 0x518 Bit 0 = 0")
        output = self.read_register(
            device_index=self.ioavtool_root,
            offset=DPCD_REG.BATHTUB_CTRL,
            length=1,
        )
        self.write_register(
            device_index=self.ioavtool_root,
            offset=DPCD_REG.BATHTUB_CTRL,
            length=1,
            values=hex(int(output, 16) & 0xFE)  # Bit 0 of 0x518 to 1 to kick off margining
        )

        print("Write 0x517 Bit 0/1 = 0")
        time.sleep(0.1)  # 0.1s delay between 0x517 modifications
        output = self.read_register(
            device_index=self.ioavtool_root,
            offset=DPCD_REG.EQ_VALUE,
            length=1,
        )
        time.sleep(0.1)  # 0.1s delay between 0x517 modifications
        self.write_register(
            device_index=self.ioavtool_root,
            offset=DPCD_REG.EQ_VALUE,
            length=1,
            values=hex(int(output, 16) & 0xFE)
        )

        print("Write 0x517 Bit 2:6 = 0")
        time.sleep(0.1)  # 0.1s delay between 0x517 modifications
        output = self.read_register(
            device_index=self.ioavtool_root,
            offset=DPCD_REG.EQ_VALUE,
            length=1,
        )
        time.sleep(0.1)  # 0.1s delay between 0x517 modifications
        self.write_register(
            device_index=self.ioavtool_root,
            offset=DPCD_REG.EQ_VALUE,
            length=1,
            values=hex(int(output, 16) & 0x83)
        )

        print("Write 0x517 Bit 7 = 0")
        time.sleep(0.1)  # 0.1s delay between 0x517 modifications
        output = self.read_register(
            device_index=self.ioavtool_root,
            offset=DPCD_REG.EQ_VALUE,
            length=1,
        )
        time.sleep(0.1)  # 0.1s delay between 0x517 modifications
        self.write_register(
            device_index=self.ioavtool_root,
            offset=DPCD_REG.EQ_VALUE,
            length=1,
            values=hex(int(output, 16) & 0x7F)
        )

    #
    # Execution Flow
    #
    def set_adaptation(self, figure_of_merit):
        """Set the Adaptation Type (if applicable)"""
        if bool(self.doe) is True:
            print("Figure of Merit: {}, Set EQ Level".format(figure_of_merit))
            self.figure_of_merit = figure_of_merit

            print("Ensure Link")
            self.ensure_link_doe()

            print("Setup Margining")
            self.setup_margining()

            # Start by setting the new EQ value we want
            print("Cast new EQ value to Hex for register writing accurately")
            time.sleep(0.1)  # 0.1s delay between 0x517 modifications
            output = self.read_register(
                device_index=self.ioavtool_root,
                offset=DPCD_REG.EQ_VALUE,
                length=1,
            )
            output = int(output, 16) & 0x03
            new_eq_value = hex(output | (int(figure_of_merit) << 2))
            print("Set New EQ Value Register: {}".format(new_eq_value))

            time.sleep(0.1) # 0.1s delay between 0x517 modifications
            self.write_register(
                device_index=self.ioavtool_root,
                offset=DPCD_REG.EQ_VALUE,
                length=1,
                values=new_eq_value  # Set the new EQ value
            )


            # Set bit 0 = 1 for the I2C override
            print("Set Bit0 = 1 for the I2C Override")
            time.sleep(0.1)  # 0.1s delay between 0x517 modifications
            output = self.read_register(
                device_index=self.ioavtool_root,
                offset=DPCD_REG.EQ_VALUE,
                length=1,
            )
            print("Output: {}".format(output))
            time.sleep(0.1)  # 0.1s delay between 0x517 modifications
            self.write_register(
                device_index=self.ioavtool_root,
                offset=DPCD_REG.EQ_VALUE,
                length=1,
                values=hex(int(output, 16) | 0x1)  # Set the 0x518 bit 0 to 1
            )

            for i in range(60):
                # Poll bit 7 to confirm that the override has passed
                time.sleep(0.1)
                output = self.read_register(
                    device_index=self.ioavtool_root,
                    offset=DPCD_REG.EQ_VALUE,
                    length=1,
                )
                value = (int(output, 16) >> 7) & 0x1
                print("Bit7 Overrides EQ Output: {} Value: {} Test Attempt: {}".format(output, value, i))
                if value == 1:
                    break
                if i == (60 - 1):
                    raise Exception("Unable to Change EQ")

            # move check from here because EQ_value has to stabilize before reading value
        else:
            print("Skip Set Adaptation, no DOE")
            return 1

    def apply_settings(self, retrain=True):
        """Apply EQ and other settings, retrain (if applicable)"""

    def configure_phy(self):
        """Configure the PHY Settings, Overrides, ECO, etc"""

    def all_lanes_scanned(self, lane):
        """Check if all lanes scanned, Used for tools that need to have individual lanes scanned"""
        return 1

    def progress(self):
        """Progress in integer % increments"""

    def set_traffic_type(self, traffic_type):
        """Select the Traffic type (Live, PRBS, etc)"""


