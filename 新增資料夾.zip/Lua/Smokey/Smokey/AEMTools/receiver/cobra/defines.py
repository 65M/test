

__all__ = [
    "DPCD_GAIN_BOOST",
    "DPCD_VOLTAGE_SWING_PRE_EMPHASIS",
    "DPCD_REG",
    "LANE_REGS",
    "PATTERN_TYPE",
    "BATHTUB_CTRL",
    "EQ_SETTINGS",
    "CURRENT_CPTRIM",
    "BATHTUB_START",
    "TIME_UNIT",
    "EQ_SCAN",
    "DPCD_VOLTAGE_SWING_LOOKUP",
    "DPCD_PREEMPHASIS_LOOKUP",
    "EDID_OVERRIDE"
]


# DPCD Gain / Boost Lookup
DPCD_GAIN_BOOST = {
    '00': [-6.24040, 11.60580],
    '01': [-5.18000, 10.54540],
    '02': [-3.91000, 09.27540],
    '03': [-2.69060, 08.05600],
    '04': [-1.99760, 07.36300],
    '05': [-1.23180, 06.59720],
    '06': [-0.36633, 05.73173],
    '07': [0.61378, 04.75162]
}

# DPCD Voltage Swing Pre-Emphasis
DPCD_VOLTAGE_SWING_PRE_EMPHASIS = {
    '00': 0,
    '01': 1,
    '10': 2,
    '11': 3,
}

# DPCD Voltage Swing bits offsets per lane left dict value is lane
DPCD_VOLTAGE_SWING_LOOKUP = {
    0: 6,
    1: 2,
    2: 6,
    3: 2,
}

# DPCD Preemphasis bits offsets per lane, left dict value is lane
DPCD_PREEMPHASIS_LOOKUP = {
    0: 4,
    1: 0,
    2: 4,
    3: 0,
}

# EQ_SCAN VALUES
EQ_SCAN = {
     0: "0x00",
     1: "0x01",
     2: "0x02",
     3: "0x03",
     4: "0x04",
     5: "0x05",
     6: "0x06",
     7: "0x07",
     8: "0x08",
     9: "0x09",
    10: "0x10",
    11: "0x11",
    12: "0x12",
    13: "0x13",
    14: "0x14",
    15: "0x15",
}


# See Register notes in rdar://problem/37626101
class DPCD_REG(object):
    """Display Port Configuration Data (DPCD) Register Addresses"""
    VOLTAGE_SWING_PRE_EMPHASIS_LANE_0_1 = "0x206"		# VOLTAGE SWING AND PRE EMPHASIS VALUES for Lanes 0 and 1
    VOLTAGE_SWING_PRE_EMPHASIS_LANE_2_3 = "0x207"		# VOLTAGE SWING AND PRE EMPHASIS VALUES for Lanes 2 and 3

    # Standard Bathtub Registers (see context below)
    BATHTUB_REG0 = "0x30B"
    BATHTUB_REG1 = "0x30C"
    BATHTUB_REG2 = "0x30D"
    BATHTUB_REG3 = "0x30E"

    COBRA_FW_1 = "0x50A"
    COBRA_FW_2 = "0x50B"

    # Control Register
    DELAY_SETUP = "0x514"
    EQ_VALUE = "0x517"
    BATHTUB_CTRL = "0x518"

    # Test Results
    BATHTUB_RESULT = ["0x519", "0x51A", "0x51B", "0x51C", "0x51D", "0x51E", "0x51F", "0x520"]
    # BATHTUB_RESULT0 = "0x519"		# CPTRIM values 07-00 (bit set indicates max noise injection amplitude without errors 0000 -> 0007)
    # BATHTUB_RESULT1 = "0x51A"		# CPTRIM values 15-08 (bit set indicates max noise injection amplitude without errors 0000 -> 0007)
    # BATHTUB_RESULT2 = "0x51B"		# CPTRIM values 23-16 (bit set indicates max noise injection amplitude without errors 0000 -> 0007)
    # BATHTUB_RESULT3 = "0x51C"		# CPTRIM values 31-24 (bit set indicates max noise injection amplitude without errors 0000 -> 0007)
    # BATHTUB_RESULT4 = "0x51D"		# CPTRIM values 39-32 (bit set indicates max noise injection amplitude without errors 0000 -> 0007)
    # BATHTUB_RESULT5 = "0x51E"		# CPTRIM values 47-40 (bit set indicates max noise injection amplitude without errors 0000 -> 0007)
    # BATHTUB_RESULT6 = "0x51F"		# CPTRIM values 55-48 (bit set indicates max noise injection amplitude without errors 0000 -> 0007)
    # BATHTUB_RESULT7 = "0x520"		# CPTRIM values 63-56 (bit set indicates max noise injection amplitude without errors 0000 -> 0007)

    BATHTUB_RESULTCOUNT = 8

    # Status Register
    BATHTUB_STATUS = "0x518"		# Test Complete: 0bxxxx0 when running, 0bxxxx1 when finished


LANE_REGS = [DPCD_REG.BATHTUB_REG0, DPCD_REG.BATHTUB_REG1, DPCD_REG.BATHTUB_REG2, DPCD_REG.BATHTUB_REG3]


class PATTERN_TYPE(object):
    """Pattern Types"""
    ANSI8B10B = "0x0"
    PRBS7 = "0x1"


class BATHTUB_CTRL(object):
    """Bathtub Control Register Values for 0x510"""
    EQ_BYPASS = "0x66"
    # TODO: This value is not documented:		0x7
    EQ_SETTINGS = "0xAA"		# Use 0x30B - 0x30E for reading per Lane Values
    CURRENT_CPTRIM = "0xCC"		# Use 0x30B - 0x30E for reading per Lane Values
    START = "0xEE"				# Set the settings before starting
    # Per rdar://problem/37626101, commands E0, E1 and D1 are not implemented.
    DISABLE = "0xE0"				# Needs to be written after bathtub curve testing and before normal operation
    ENABLE = "0xE1"				# Needs to be written before writing EEh


#
# Register Contexts
#
class EQ_SETTINGS(object):
    """EQs can be read from accessing below when 0x510 = 0xAA"""
    LANE = ["0x206", "0x206", "0x207", "0x207"]


class CURRENT_CPTRIM(object):
    """CPTrims can be read from accessing below when 0x510 = 0xCC"""
    LANE_0 = "0x30B"
    LANE_1 = "0x30C"
    LANE_2 = "0x30D"
    LANE_3 = "0x30E"


class BATHTUB_START(object):
    """When conducting the actual bath tub test the following are accessed when 0x510 = 0xEE"""
    LANE_NUMBER = "0x30B"			# Lane number under Bathtub test:	0x0 for Lane 0, 0x1 for Lane 1, etc
    PATTERN_TYPE = "0x30C"		# Pattern Type:						0x0 = ANSI8B/10B data, 0x1 = PRBS7
    TIME_UNIT = "0x30D" 		# Time Unit:						0x0 = 1ms, 0x1 = 10ms, 0x2 = 100ms
    TEST_PERIOD = "0x30E"			# Time value:						Time Period = Time Value * Time Unit
    EQ_SETTING = "0x30F"		# EQ Setting Value to Test:			Valid ranges from 0 - 7

    DPCD_REGISTER_1 = "0x5D1"
    DPCD_REGISTER_2 = "0x5D2"
    DPCD_REGISTER_3 = "0x5D3"
    DPCD_REGISTER_4 = "0x5D4"
    DPCD_REGISTER_5 = "0x5D5"
    DPCD_REGISTER_6 = "0x5D6"


class TIME_UNIT(object):
    """Time Units"""
    ONE_MILL = "0x00"
    TEN_MILL = "0x01"
    HUNDRED_MILL = "0x02"


class EDID_OVERRIDE(object):
    """ TO SET EDID OVERRIDE"""
    REGISTER_OVERRIDE = "0x53B"      # REGISTER TO ENABLE EDID OVERRIDE
    VALUE_OVERRIDE = "0xFB"
    REGISTER_SETUP = "0x52E"
    VALUE_SETUP = "0x2"