"""Access for OS"""
import os
import re
import time
from .defines import *
from .base import AbstractReceiverMarginTool


__all__ = [
    "MarginTool"
]


class MarginTool(AbstractReceiverMarginTool):
    """Margin Tool Instance"""
    def parse_ioavtool_roots(self):
        """Parse ioavtool roots"""
        data = os.popen("ioavtool -roots").read()
        root_list = []
        for line in data.split('\n'):
            if len(line) > 0:
                root_list.append(line)

        return root_list


    def match_root_display(self):
        """Match each root to an ioavtool display"""
        root_list = self.parse_ioavtool_roots()
        matched_root = []
        for root in root_list:
            # read registers 500 -> 508 for Apple OUI and pHDMIg
            data = self.read_register_bytes(root, 500, 9)
            print("Root: {} Length Data: {} Data: {}".format(root, len(data), data))
            if len(data) != 0 and data == ['00', '10', 'fa', '70', '48', '44', '4d', '49', '67']:
                print("Matched Root: {}".format(root))
                matched_root.append(root)

        print("Found Total Matched Roots: {}".format(matched_root))
        return matched_root


    def match_root_index(self, matched_root):
        """Match HDMI Roots to Valid Index"""
        for root in matched_root:
            output = int(self.read_register(device_index=root, offset=EDID_OVERRIDE.REGISTER_OVERRIDE, length=1), 16)
            cobraid = (output >> 6) & 0x1
            print("Output: {} for Root: {} CobraID: {} Device Index: {}".format(output, root, cobraid, self.device_index))
            if int(cobraid) == self.device_index:
                return root

        return None


    def read_register(self, device_index, offset, length):
        """Read registers"""
        # If there is no device index this isn't a J170 so we want to skip it along with Intel HW parameter
        retry_count = 5
        data = ""
        for attempt in range(0, retry_count):
            print("Timestamp: {} Device Index Read Register: {} Intel HW: {} Offset: {} Length: {}".format(time.time(), device_index, self.intel_hw, offset, length))
            if self.intel_hw is False:
                if device_index is None:
                    data = os.popen("displayport -rdpcd {} {}".format(offset, length)).read()
                else:
                    print("Running Device Index Command: {}".format(device_index))
                    data = os.popen("displayport -root {} -rdpcd {} {}".format(device_index, offset, length)).read()
            else:
                data = os.popen("pconctl -index {} -rdpcd {} {}".format(device_index, offset, length)).read()

            print("Data: {} Length: {}".format(data, len(data)))
            if len(data) > 0:
                data = data.strip("\n")
                data = data.split(":")[1]
                data = data.strip(" ")
                data = data.split(" ")
                break
            time.sleep(0.1)

        return data[0]

    def write_register(self, device_index, offset, length, values):
        """Write an offset"""
        print("Timestamp: {} Device Index Write Register: {} Intel HW: {} Offset: {} Length: {} Values: {}".format(time.time(), device_index, self.intel_hw, offset, length, values))
        if self.intel_hw:
            output = os.system("pconctl -index {} -wdpcd {} {} {}".format(device_index, offset, length, values))
        else:
            if device_index is None:
                output = os.system("displayport -wdpcd {} {} {}".format(offset, length, values))
            else:
                output = os.system("displayport -root {} -wdpcd {} {} {}".format(device_index, offset, length, values))

        print("Output: {}".format(output))
        return output

    def read_register_bytes(self, device_index, offset, length):
        """Read registers"""
        print("Timestamp: {} Device Index Read Bytes: {} Intel HW: {} Offset: {} Length: {}".format(time.time(), device_index, self.intel_hw, offset, length))
        if self.intel_hw is False:
            if device_index is None:
                data = os.popen("displayport -rdpcd {} {}".format(offset, length)).read()
            else:
                data = os.popen("displayport -root {} -rdpcd {} {}".format(device_index, offset, length)).read()
        else:
            data = os.popen("pconctl -index {} -rdpcd {} {}".format(device_index, offset, length)).read()

        print("Data: {}".format(data))
        data = data.strip("\n")
        if len(data) != 0:
            data = data.split(":")[1]
            data = data.strip(" ")
            data = data.split(" ")
        return data