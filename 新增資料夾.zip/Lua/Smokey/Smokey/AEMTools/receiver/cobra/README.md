# MegaChip Cobra HDMI Device

### Device Capabilities:
  - X4 DP Up To HBR3 (once link training is enabled it trains to the highest speed possible)


### Cobra Margining Procedure: 
https://compass.scv.apple.com/confluence/display/SYSTEM/Cobra

1. Configure dongle-factory-mode boot-arg (or write DPCD 52E=FB) and av_protection_enabled 
boot-args. 

2. Enable Virtual EDID with DPCD 53B Bit 1.

3. Program DPCD 518[0] to 1 to kick-off margining .

4. Poll DPCD 518[6] to confirm = 1 (i.e. margining in progress). Fail if != 1 
(and DPCD518[7]) is not already 1 indicating margining is done. 

5. Continue to poll until DPCD518[6] is 0 and DPCD518[7] is 1. 

6. Read out registers 519 -> 520 (519, 51A, 51B, 51C, 51D, 51E, 51F, 520) 2 registers 
each with 8 bits per lane to get the max jitter level for that lane that keeps error to 0.

7. Output the results. 

### Open Questions: 

1. Confirm what functions / bits need to be set to kick off margining. 

2. What bits need to be set to DPCD 517 to set EQ values and how does the 5-bit value written
to 6:2 map to different DPRX EQ values (and what values
do we want to sweep through)?

3. The 16 bit value we get back for each lane that represents the maximum jitter amplitdude level,
what does that actually mean and what are its limitations. 

### Function Breakdown: 

Level 1:

    a. Read single DPCD register. 
    b. Write single DPCD register. 

Level 2:

    a. Package a write register for various tasks:
        1. Kicking off margining. 
        2. DPCD RX changes. 
        3. Boot-args to kickoff margining. 
    b. Parse / grab read registers for various tasks:
        1. Lane outputs of margining and max jitter leve. 
        2. Margining Status. 
        3. General read register output. 

Level 3: 

    a. Run a full set of margining and output results for all the different lanes. 
    b. RX / EQ sweep for the different supported values. 