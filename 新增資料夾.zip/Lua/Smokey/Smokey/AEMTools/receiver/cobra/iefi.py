"""Access for iEFI"""
from .base import AbstractReceiverMarginTool
from shell import run
import re
import time

__all__ = [
	"MarginTool"
]


class MarginTool(AbstractReceiverMarginTool):
	"""Margin Tool Instance"""
	def cobra_command(self, cmd):
		"""Run and Dump Cobra Command"""
		print(f"CMD: {cmd}")
		return run(cmd)

	def disable_phy(self):
		"""Disable the Cobra PHY"""
		if self.device_index is not None and self.device_index != 0:
			die_pick = "4"
		else:
			die_pick = ""

		print(f"-------Turn off PHY------- Device Index: {die_pick}")
		print(f"Cobra ATC Port: {self.atc_port} Cobra Route: {self.route}")

		output = self.cobra_command("display --listdisplays")
		if "external-hdmi" in output:
			self.cobra_command("dprepeater --select external-hdmi")
			self.cobra_command(f"dptx --pick external-hdmi{die_pick}")
		else:
			self.cobra_command(f"dptx --pick external{die_pick}")

		self.cobra_command("dptx --off")

		if len(self.atc_port) is not 0:
			self.cobra_command(f"device -k usbphy -e select {self.atc_port[0]}; device -k usbphy -e disable")

		self.cobra_command("dprepeater --off")

	def enable_phy(self):
		"""Enable the Cobra PHY"""
		if self.device_index is not None and self.device_index != 0:
			die_pick = "4"
		else:
			die_pick = ""

		print(f"-------Turn on PHY------- Device Index: {die_pick}")
		print(f"Cobra ATC Port: {self.atc_port} Cobra Route: {self.route}")

		output = self.cobra_command("display --listdisplays")
		if "external-hdmi" in output:
			# New driver method of turning on link
			self.cobra_command("dprepeater --select external-hdmi")
			self.cobra_command("dprepeater --on")

			if len(self.atc_port) is not 0:
				self.cobra_command(f"device -k usbphy -e select {self.atc_port[0]}; device -k usbphy -e enable dp")

			self.cobra_command(f"dptx --pick external-hdmi{die_pick}")
			self.cobra_command(f"dptx --route {self.route}")
			self.cobra_command("dptx --on")
		else:
			# old method of turning on link ... for legacy
			self.cobra_command("dprepeater --on")

			if len(self.atc_port) is not 0:
				self.cobra_command(f"device -k usbphy -e select {self.atc_port[0]}; device -k usbphy -e enable dp")

			self.cobra_command(f"dptx --pick external{die_pick};")

			self.cobra_command(f"dptx --route {self.route}")
			self.cobra_command("dptx --on")

		print("Sleep to confirm link is up")
		time.sleep(5)

	def ensure_link_doe(self):
		"""Check Link meets Speed / Width requirements"""
		self.disable_phy()
		self.enable_phy()

	def ensure_link(self):
		"""Check Link meets Speed / Width requirements"""
		if not self.doe:
			self.disable_phy()
			self.enable_phy()

	def read_register(self, device_index, offset, length):
		"""Read registers"""
		print("Read Register Device Index: {} Offset: {} Length: {}".format(device_index, offset, length))
		aux_read_data = run("dptx --auxread dpcd {} {}".format(offset, length))
		if "OK" in aux_read_data:
			a = re.search(": ([\wx]*)", aux_read_data).group(0)
			print("Aux Data: {} Result: {}".format(aux_read_data, a.strip(":").split("x")[1]))
			return a.strip(":").split("x")[1]
		else:
			raise Exception("Read failed")

	def read_register_bytes(self, device_index, offset, length):
		"""Read registers"""
		print("Read Register Bytes Device Index: {} Offset: {} Length: {}".format(device_index, offset, length))
		aux_read_data = run("dptx --auxread dpcd {} {}".format(offset, length))
		if "OK" in aux_read_data:
			print(aux_read_data)
			print(aux_read_data.split(":")[2].strip("\r\nOK"))
			data = aux_read_data.split(":")[2].strip("\r\nOK")
			data = data.strip(" ")
			data = data.split(" ")
			print("AUX Read Data: {} Final Data: {}".format(aux_read_data, data))
			for index in range(0, len(data)):
				data[index] = data[index].split("x")[-1]
			return data

		else:
			raise Exception("Read failed")

	def write_register(self, device_index, offset, length, values):
		"""Write an offset"""
		print("Write Register Device Index: {} Offset: {} Length: {} Values: {}".format(device_index, offset, length, values))
		values = values if isinstance(values, list) else [values]
		for i in range(0, length):
			print(values[i])
			if(type(values[i])) is str:
				aux_write_data = run("dptx --auxwrite dpcd {} {}".format(hex(int(offset, 16)+i), hex(int(values[i], 16))))
				print((hex(int(offset, 16) + i)))
				# Don't read the register immediately after writing some aren't designed for that
				# m = self.read_register(device_index, (hex(int(offset, 16)+i)), 1)
				# print(m)
			else:
				aux_write_data = run("dptx --auxwrite dpcd {} {}".format(hex(int(offset, 16)+i), hex(values[i])))
				print((hex(int(offset, 16) + i)))
				# Don't read the register immediately after writing some aren't designed for that
				# m = self.read_register(device_index, (hex(int(offset, 16)+i)), 1)
				# print(m)
			if "OK" in aux_write_data:
				continue
			else:
				raise Exception("Write failed")

