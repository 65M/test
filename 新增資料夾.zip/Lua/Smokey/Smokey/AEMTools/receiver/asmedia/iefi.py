"""Access for iEFI"""
import sys
import logging
from .base import AbstractReceiverMarginTool
from shell import run
import os
import re

__all__ = [
    "MarginTool"
]

seq_log = logging.getLogger("sequence")


class MarginTool(AbstractReceiverMarginTool):
    """Margin Tool Instance"""

    def ensure_link(self):
        """Check Link meets Speed / Width requirements"""
        print(f"Product Code: {self.product_code}")
        if self.product_code.upper() not in ["J180"]:
            print("Check Link meets Speed / Width requirements. Running with root port: {}".format(self.root_port))
            run("pcie --pick {}".format(self.root_port))
            # Check PCIE Gen
            run("pcie --on")
            print("Turned on ASMedia")
        else:
            print("Skip PCIe Enablement Sequence")

    def run_asmedia_cmd(self, cmd):
        print(cmd)
        return run(cmd)

    def setup_fw_jade(self):
        self.run_asmedia_cmd("nandfs:\AppleInternal\Diags\Apps\\asmfud.efi -f nandfs:\AppleInternal\Diags\\USBC\J375\\asm3142_fw.bin")
        self.run_asmedia_cmd("nandfs:\AppleInternal\Diags\Apps\\asmfud.efi -v")

    def setup_fw_rhodes(self):
        self.run_asmedia_cmd("upy nandfs:\AppleInternal\Diags\Scripts\J180D\\UsbHcFwUpdater\\asm3142_fw_load.py")

    def setup_fw_staten(self):
        self.run_asmedia_cmd("debug --off")
        self.run_asmedia_cmd("pcie --pick 1")
        self.run_asmedia_cmd("pcie --on")
        out = self.run_asmedia_cmd("devtree")

        handle = ""
        for line in out.split('\n'):
            if "eXtensible Host Controller" in line:
                handle = line.split('[')[1].split(']')[0]

        self.run_asmedia_cmd("disconnect " + handle)
        self.run_asmedia_cmd('nandfs:\AppleInternal\Diags\Apps\\asmfud.efi')
        self.run_asmedia_cmd("wait 1000")
        self.run_asmedia_cmd("connect " + handle)

    def start_margining(self):
        print(f"Load FW: {self.load_fw} Product Code: {self.product_code}")
        if self.load_fw:
            print("Load FW (not included)")
            if self.product_code.upper() == "J473":
                self.setup_fw_staten()
            elif self.product_code.upper() == "J375":
                self.setup_fw_jade()
            elif self.product_code.upper() == "J180":
                self.setup_fw_rhodes()
            else:
                print("WARNING!!!! FW Loaded (Ignore Error for non-J473 / FW projects)")
            # os.popen('upy nandfs:\\AppleInternal\\Diags\\Scripts\\J473\\UsbHcFwUpdater\\asm3142_fw_load.py > nandfs:\\asmedia.txt').read()
            print("Load FW Complete")

        print("Start  Margining")
        self.margin_data = run("nandfs:\\AppleInternal\\Diags\\Apps\\eyexhci.efi -d")
        print("Completed Running Margining Command")