from ..base import AbstractBaseMarginTool
import os
import re
__all__ = [
    "AbstractReceiverMarginTool"
]


class AbstractReceiverMarginTool(AbstractBaseMarginTool):
    """Generic Interface for ANS (Apple NAND System) Margining"""
    LANE_COUNT = 1  # This needs to be set at run time (it's base on the system)
    TIMEOUT = 180  # Set timeout to 2min (Average is 1-1.5)
    POLL_TIME = 2  # Poll every 2 seconds
    margin_data=()

    def __init__(self, *args, **kwargs):
        super(AbstractReceiverMarginTool, self).__init__(*args, **kwargs)


    def configure_phy(self):
        """Configure the PHY Settings, Overrides, ECO, etc"""
        pass

    def apply_settings(self, retrain=True):
        """Apply EQ and other settings, retrain (if applicable)"""

    # No settings to apply
    def ensure_link(self):
        """Check Link meets Speed / Width requirements"""
        # Get the Link Status, and calculate the Link Width / Speed

    # Not applicable, all lanes are margined together

    def setup_margining(self):
        """Configure the PHY and Setup Margining"""

    def start_margining(self):
        """Start the Margining"""

    def dump_registers(self, initial=False):
        """Dump Static Registers"""

    def parse_margin_data(self):
        """Parse data to the necessary format(s)"""
        point_value_array = [0, 0, 0, 0] # xmin, xmax, ymin, ymax
        current_type = None
        current_lane_port = None
        current_lane_status = None
        result_dict = {}
        device_index = -1
        for line in self.margin_data.split("\n"):
            pcie_match = re.search(r".*PCIE Lane.*(\d): (\w+).*", line) # PCIE Lane 0: Pass
            usb_match = re.search(r".*USB Port.*(\d): (\w+).*", line) # USB Port 0: Fail
            p_match = re.search(r".*P\d+:.*\((.+),(.+)\) .*P\d+:\((.+), (.+)\).*", line) # P0:(-1000, 000) P1:(000, 1000)
            
            if pcie_match is not None or usb_match is not None:
                if current_type is not None:
                    result_dict["Device {} ".format(device_index) + current_type + " " + str(current_lane_port) + " " + str(current_lane_status)] = point_value_array
                    point_value_array = [0, 0, 0, 0]
                    self.seq_log.info("Assigned Point Value Array, Current Results Dictionary: {}".format(result_dict))

                if pcie_match is not None:
                    current_type = "PCIE"
                    current_lane_port = pcie_match.group(1)
                    current_lane_status = pcie_match.group(2)

                    # Don't include invalid PCIE lanes (i.e. lane # >= max pcie lanes since it's 0 indexed)
                    if int(current_lane_port) >= self.max_pcie_lanes:
                        pcie_match = None
                        current_type = None
                        current_lane_status = "Pass"
                else:
                    current_type = "USB"
                    current_lane_port = usb_match.group(1)
                    current_lane_status = usb_match.group(2)
                    
            
            pcie_match, usb_match = None, None
                
            self.seq_log.info("current type: {} current lane port: {} current lane status: {}".format(current_type, current_lane_port, current_lane_status))

            if p_match is not None:
                # point_value_array = [0, 0, 0, 0] xmin, xmax, ymin, ymax
                x_coordinate_1 = int(p_match.group(1))
                y_coordinate_1 = int(p_match.group(2))
                x_coordinate_2 = int(p_match.group(3))
                y_coordinate_2 = int(p_match.group(4))
                
                self.seq_log.info("testing coordinates: {} {} {} {}".format(x_coordinate_1, y_coordinate_1, x_coordinate_2, y_coordinate_2))

                if x_coordinate_1 < point_value_array[0]:
                    point_value_array[0] = int(x_coordinate_1)
                if x_coordinate_2 < point_value_array[0]:
                    point_value_array[0] = int(x_coordinate_2)

                if x_coordinate_1 > point_value_array[1]:
                    point_value_array[1] = int(x_coordinate_1)
                if x_coordinate_2 > point_value_array[1]:
                    point_value_array[1] = int(x_coordinate_2)

                if y_coordinate_1 < point_value_array[2]:
                    point_value_array[2] = int(y_coordinate_1)
                if y_coordinate_2 < point_value_array[2]:
                    point_value_array[2] = int(y_coordinate_2)

                if y_coordinate_1 > point_value_array[3]:
                    point_value_array[3] = int(y_coordinate_1)
                if y_coordinate_2 > point_value_array[3]:
                    point_value_array[3] = int(y_coordinate_2)

            self.seq_log.info("Current point value array: {}".format(point_value_array))
            if "ASM3142 on bus" in line:
                if current_type is not None:
                    result_dict["Device {} ".format(device_index) + current_type + " " + str(current_lane_port) + " " + str(
                            current_lane_status)] = point_value_array
                    point_value_array = [0, 0, 0, 0]  # xmin, xmax, ymin, ymax
                    self.seq_log.info("Assigned Point Value Array, Current Results Dictionary: {}".format(result_dict))

                device_index += 1 # Found the first device and then the second
                print(f"Found Device: {line} Device Index: {device_index}")

        if current_type is not None:
            result_dict["Device {} ".format(device_index) + current_type + " " + str(current_lane_port) + " " + str(current_lane_status)] = point_value_array
            point_value_array = [0, 0, 0, 0] # xmin, xmax, ymin, ymax
            self.seq_log.info("Assigned Point Value Array, Current Results Dictionary: {}".format(result_dict))

        
        print("Final Result Dictionary: {}".format(result_dict))
        self.seq_log.info("Final Result Dictionary: {}".format(result_dict))
        for key, value in result_dict.items():
            if value[0] > self.min_x or value[1] < self.max_x or value[2] > self.min_y or value[3] < self.max_y:
                self.seq_log.info("----- FAIL KEY: {} -----".format(key))
                print("----- FAIL KEY: {} -----".format(key))

            else:
                self.seq_log.info("----- PASS KEY: {} -----".format(key))
                print("----- PASS KEY: {} -----".format(key))


            # point_value_array = [0, 0, 0, 0] xmin (P0), xmax (P2), ymin (P3), ymax (P1)
            components = key.split(" ")
            merged_key = components[0] + "_" + components[1] + "_" + components[2] + "_" + components[3]
            print(f"Merged Key: {merged_key} Component 0: {components[0]} 1: {components[1]} 2: {components[2]} 3: {components[3]}")

            self.log_key(key="{}_ew_ticks_minx".format(merged_key), value=(0-value[0]),
                         units='ticks', lowerlimit=(0-self.min_x), upperlimit=float('inf'))

            self.log_key(key="{}_ew_ticks_maxx".format(merged_key), value=value[1],
                         units='ticks', lowerlimit=self.max_x, upperlimit=float('inf'))

            self.log_key(key="{}_eh_ticks_miny".format(merged_key), value=(0-value[2]),
                         units='ticks', lowerlimit=(0-self.min_y), upperlimit=float('inf'))

            self.log_key(key="{}_eh_ticks_maxy".format(merged_key), value=value[3],
                         units='ticks', lowerlimit=(self.max_y), upperlimit=float('inf'))
        """
        Sample:
        Final Result Dictionary: {'USB 0 Fail': [-200, 200, -200, 200], 'PCIE 1 Fail': [-200, 200, 0, 0], 'USB 1 Fail': [-200, 200, -200, 200],
        'PCIE 0 Pass': [-1000, 1000, -1000, 1000]}
        """
        self.result = result_dict

    def calculate_eye(self):
        """Parse data to the necessary format(s)"""
        # Parse the output
        self.parse_margin_data()

    #
    # Helpers
    #
    def progress(self):
        """Progress in integer % increments"""
        self.log_msg("   {}%".format(self._fake_progress))
        return self._fake_progress

    def is_running(self):
        """Check if Margining is running"""
        return self.progress < 100

    def all_lanes_scanned(self, lane):
        """Check if all lanes scanned, Used for tools that need to have individual lanes scanned"""
        if lane == self.LANE_COUNT:
            return 1
        else:
            self.log_msg("Didnt complete all lanes")

    def wait_for_finish(self):
        return 1

