import io
import logging
from collections import namedtuple

__all__ = [
    "TRAFFIC_TYPE",
    "traffic_types",
    "endpoints",
    "RESULT_CODE",
    "RESULT_KEY",
    "CsvFormatter",
    "MinWidthException",
    "MaxWidthException",
    "MinHeightException",
    "MaxTimeoutException",
    "MarginException"
]

traffic_type = namedtuple("traffic_type", "name")


class TRAFFIC_TYPE(object):
    """Data Traffic Type"""
    LIVE = traffic_type("Live")
    PRBS7 = traffic_type("PRBS7")
    ALL_TYPES = [LIVE.name, PRBS7.name]


def traffic_types():
    """Traffic types as a list"""
    return TRAFFIC_TYPE.ALL_TYPES


def endpoints():
    """Get all end points"""
    ep = ["ans2", "madea"]
    return ep


class RESULT_CODE(object):
    """Result Codes"""
    ERROR_UNKNOWN = -1
    PASS = 0
    FAIL_UNKNOWN = 1
    FAIL_EXCEED_MIN_HEIGHT = 2
    FAIL_EXCEED_MIN_WIDTH = 3
    FAIL_EXCEED_MAX_WIDTH = 4
    FAIL_EXCEED_MAX_TIMEOUT = 5


class RESULT_KEY(object):
    """Result Key"""
    RESULT_CODE = "resultCode"


class CsvFormatter(logging.Formatter):
    """CSV Format Logger"""
    def __init__(self):
        super(CsvFormatter, self).__init__()
        self.output = io.StringIO()
        self.writer = csv.writer(self.output, quoting=csv.QUOTE_ALL)

    def format(self, record):
        """Log messages as key,value"""
        self.writer.writerow([record.key_name, record.msg])
        data = self.output.getvalue()
        self.output.truncate(0)
        self.output.seek(0)
        return data.strip()


#
# Exceptions
#
class MarginException(Exception):
    """Margining Exceptions"""


class MinWidthException(MarginException):
    """Minimum Width Exception"""


class MaxWidthException(MarginException):
    """Maximum Width Exception"""


class MinHeightException(MarginException):
    """Minimum Height Exception"""


class MaxTimeoutException(MarginException):
    """Maximum Timeout Exception"""
