# Camera ISP LPDP Receiver


References from https://stashweb.sd.apple.com/projects/LLDIAGS/repos/factoryllscriptsplatforms/browse/Smokey/CAM_LPDP