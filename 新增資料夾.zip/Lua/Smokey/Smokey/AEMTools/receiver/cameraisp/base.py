from ..base import AbstractBaseMarginTool
from .defines import *
from.soc_defines import *
from shell import run
import math
import time
__all__ = [
    "AbstractReceiverMarginTool"
]


class AbstractReceiverMarginTool(AbstractBaseMarginTool):
    """Generic Interface for ANS (Apple NAND System) Margining"""
    LANE_COUNT = 1  # This needs to be set at run time (it's base on the system)
    TIMEOUT = 180  # Set timeout to 2min (Average is 1-1.5)
    POLL_TIME = 2  # Poll every 2 seconds
    margin_data=()
    data_rate = 2.7e9
    ref_div = 5
    ref_clk = 533.3333 * 10 ** 6
    fref = 0
    f0 = 0
    f1 = 0
    fvco = 0
    res_data = []
    LANE_RP_OFFSET = 0
    mid_x = 0
    mid_y = 0
    res_vol_north_data = []
    res_vol_south_data = []
    res_pi_east_data = []
    res_pi_west_data = []
    res_vol_north_data_1 = []
    res_vol_south_data_1 = []
    res_pi_east_data_1 = []
    res_pi_west_data_1 = []
    mf=0

    def __init__(self, *args, **kwargs):
        super(AbstractReceiverMarginTool, self).__init__(*args, **kwargs)

        # Dynamically set the number of lanes by using Identify Controller
        self.LANE_COUNT = 1
        self._previous_percent = -1
        self.soc_sisp_offset = SOC_CONVERSION_CODE[self.soc]['SOC_SISP_OFFSET']
        self.soc_lane0_offset= SOC_CONVERSION_CODE[self.soc]['SOC_LANE0_OFFSET']
        self.soc_lppdprx_lane_offset =SOC_CONVERSION_CODE[self.soc]['SOC_LPDPRX_LANE_OFFSET']

        self.SDP_ERR_THRESHOLD = SOC_CONVERSION_CODE[self.soc]['SDP_ERR_THRESHOLD']
        self.MAIN_LINK_STATUS_0 = SOC_CONVERSION_CODE[self.soc]['MAIN_LINK_STATUS_0']
        self.MAIN_LINK_STATUS_1 = SOC_CONVERSION_CODE[self.soc]['MAIN_LINK_STATUS_1']
        self.MAIN_LINK_STATUS_2 = SOC_CONVERSION_CODE[self.soc]['MAIN_LINK_STATUS_2']


    def padded_hex(self, i, l):
        given_int = i
        given_len = l

        hex_result = hex(given_int)[2:]  # remove '0x' from beginning of str
        num_hex_chars = len(hex_result)
        extra_zeros = '0' * (given_len - num_hex_chars)  # may not get used..

        return ('0x' + hex_result if num_hex_chars == given_len else
                '?' * given_len if num_hex_chars > given_len else
                '0x' + extra_zeros + hex_result if num_hex_chars < given_len else
                None)

    def disable_power_management(self):
        """Disable Power Management Modes"""

    #
    # Active Lane (ANS or MCP) Register RW functions
    #


    def int2sa_vos_code(self, intval):
        """ convert to gray code from sign int 5 bits """
        if (intval < -31) or (intval > 31):
            return None
        elif intval >= 0:
            return intval ^ intval >> 1
        return abs(intval ^ intval >> 1) + 32

    def dec2gray(self, i=0):
        """ convert dec to gray """
        return i ^ i >> 1

    def gray2dec(self, i=0, total_bits=63):
        """ convert gray to dec """
        return [self.dec2gray(d) for d in range(total_bits)].index(i)

    def swing_level(self, figure_of_merit):
        print("Ensure Link")
        # Remove "sep --init" from before consolerouter on Jade+ programs (removal needed for J41x margining).
        try:
            print("Exit Camera")
            run("camisp --exit")
        except Exception as e:
            print(f"Continue Stream Off: {e}")

        try:
            print("Turn off Stream Current State")
            run("camisp --stream off", True)
        except Exception as e:
            print(f"Continue Stream Off: {e}")

        print("Setup Stream")
        run("consolerouter -a -s imageprocessor.* --dest serial")
        run("camisp --dbgfw on; camisp --on")

        print("set next swing level to {}mV".format(figure_of_merit))
        run("camisp --method sethsoutputlevel {}".format(figure_of_merit))

        print('Finish enabling')
        run("camisp --stream on")
        run("camisp --method setmipifreq -1")

        print('read swing')
        run("camisp --i2cread 0 0x36 0x0518 2 1")
        run("camisp --i2cread 0 0x36 0x0519 2 1")
        run("camisp --i2cread 0 0x36 0x0550 2 1")
        run("camisp --i2cread 0 0x36 0x0525 2 1")

    #
    # Execution Flow
    #
    def set_adaptation(self, figure_of_merit):
        """Set the Adaptation Type (if applicable)"""
        if bool(self.doe) is True:
            print("Figure of Merit: {}, setup ace commands off initally".format(figure_of_merit))
            self.swing_level(figure_of_merit)
        else:
            print("Skip Set Adaptation, no DOE")
            return 1

    def configure_phy(self):
        """Configure the PHY Settings, Overrides, ECO, etc"""
        pass

    def set_traffic_type(self, traffic_type):
        """Select the Traffic type (Live, PRBS, etc)"""
        self.log_msg("   Setting Traffic Type to {}".format(traffic_type))

    def apply_settings(self, retrain=True):
        """Apply EQ and other settings, retrain (if applicable)"""

    # No settings to apply
    def ensure_link(self):
        """Check Link meets Speed / Width requirements"""
        # Get the Link Status, and calculate the Link Width / Speed

    def select_lane(self, lane):
        """Select a Lane"""
        print("lane is {}".format(lane))
        self.current_lane = lane
        print(f" SOC SISP Offset: {hex(self.soc_sisp_offset)} Lane0 Offset: {hex(self.soc_lane0_offset)} Current Lane: {hex(self.current_lane)} Per Lane Offset: {hex(self.soc_lppdprx_lane_offset)}")
        self.LANE_RP_OFFSET = self.soc_sisp_offset + self.soc_lane0_offset + \
                               self.current_lane * self.soc_lppdprx_lane_offset
        print(f"Lane RP Offset: {self.LANE_RP_OFFSET}")

    # Not applicable, all lanes are margined together

    def setup_margining(self):
        """Configure the PHY and Setup Margining"""
        self.fref = self.ref_clk / self.ref_div
        self.f0 = math.floor((256 * self.data_rate) / self.fref)
        self.fvco = (self.data_rate *.9)/1.0
        self.f1 = math.floor((256 * self.fvco) / self.fref)
        f1s = self.f1 << 16
        f1f0 = f1s + self.f0
        h0dac_range = 3
        self.write_register(self.MAIN_LINK_STATUS_0, 255)
        self.write_register(self.MAIN_LINK_STATUS_1, 255)
        self.write_register(self.MAIN_LINK_STATUS_2, 30719)
        self.set_bits(self.LANE_RP_OFFSET + LPDPRX_PHY_REG['LPDPRX_RXA_DFE_CTRL11'], 1, 2, h0dac_range)
        self.set_bits(self.LANE_RP_OFFSET + LPDPRX_PHY_REG['LPDPRX_RXA_DFE_CTRL11'], 3, 1, 1)
        if h0dac_range is 1 :
            self.mf = 1.0
        elif h0dac_range is 2 :
            self.mf = 1.5
        else:
            self.mf=1.75
        self.set_bits(self.LANE_RP_OFFSET + LPDPRX_PHY_REG['LPDPRX_CFG27_EQ'], 9, 1, 1)
        self.set_bits(self.LANE_RP_OFFSET + LPDPRX_PHY_REG['LPDPRX_CFG27_EQ'], 8, 1, 1)
        self.set_bits(self.LANE_RP_OFFSET + LPDPRX_PHY_REG['LPDPRX_RXA_DESER_CTRL9'], 29, 1, 1)
        self.write_register(self.MAIN_LINK_STATUS_0, 255)
        self.write_register(self.MAIN_LINK_STATUS_1, 255)
        self.write_register(self.MAIN_LINK_STATUS_2, 30719)

        self.write_register(self.LANE_RP_OFFSET + LPDPRX_PHY_REG['LPDPPRX_CFG0_PATCHK'], 0x41)
        self.write_register(self.LANE_RP_OFFSET + LPDPRX_PHY_REG['LPDPPRX_CFG0_PATCHK'], 0x45)
        patchk = int(self.read_register(self.LANE_RP_OFFSET + LPDPRX_PHY_REG['LPDPPRX_PATCHK_CFG0']), 16)
        self.log_key(key="LPDPPRX_PATCHK_CFG0 {}".format(
            self.current_lane),
            value=patchk,
            units='ticks')
        self.log_msg("PATCH_CFG0 {}".format(patchk))
        pmafsm = int(self.read_register(self.LANE_RP_OFFSET + LPDPRX_PHY_REG['LPDPRX_PMAFSM_REG0']), 16)
        self.log_key(key="LPDPRX_PMAFSM_REG0 {}".format(
            self.current_lane),
            value=pmafsm,
            units='ticks')
        self.log_msg("LPDPRX_PMAFSM_REG0 {}".format(pmafsm))

        pmafsm1 = int(self.read_register(self.LANE_RP_OFFSET + LPDPRX_PHY_REG['LPDPRX_PMAFSM_REG1']), 16)
        self.log_key(key="LPDPRX_PMAFSM_REG1 {}".format(
            self.current_lane),
            value=pmafsm1,
            units='ticks')
        self.log_msg("LPDPRX_PMAFSM_REG1 {}".format(pmafsm1))

        rxa_obs_1 = int(self.read_register(self.LANE_RP_OFFSET + LPDPRX_PHY_REG['LPDPRX_RXA_DESER_OSB1']), 16)
        self.log_key(key="LPDPRX_RXA_DESER_OSB1 {}".format(
            self.current_lane),
            value=rxa_obs_1,
            units='ticks')
        self.log_msg("LPDPRX_RXA_DESER_OSB1 {}".format(rxa_obs_1))

        rxa_obs_2 = int(self.read_register(self.LANE_RP_OFFSET + LPDPRX_PHY_REG['LPDPRX_RXA_DESER_OSB1']), 16)
        self.log_key(key="LPDPRX_RXA_DESER_OSB1_2 {}".format(
            self.current_lane),
            value=rxa_obs_2,
            units='ticks')
        self.log_msg("LPDPRX_RXA_DESER_OSB1_2 {}".format(rxa_obs_2))
        rxa_obs_3 = int(self.read_register(self.LANE_RP_OFFSET + LPDPRX_PHY_REG['LPDPRX_RXA_DESER_OSB1']), 16)
        self.log_key(key="LPDPRX_RXA_DESER_OSB1_3 {}".format(
            self.current_lane),
            value=rxa_obs_3,
            units='ticks')
        self.log_msg("LPDPRX_RXA_DESER_OSB1_3 {}".format(rxa_obs_3))
        lock = self.get_bits(self.LANE_RP_OFFSET + LPDPRX_PHY_REG['LPDPRX_BIST_CFG8'],1 ,2)
        self.log_key(key="LOCK_CHECK {}".format(
            self.current_lane),
            value=lock,
            units='ticks')


        # self.write_register(self.LANE_RP_OFFSET + LPDPRX_PHY_REG['LPDPRX_BIST_CFG1'], f1f0)
        # self.write_register(self.LANE_RP_OFFSET + LPDPRX_PHY_REG['LPDPRX_BIST_CFG1'], 0x60a)
        # self.set_bits(self.LANE_RP_OFFSET + LPDPRX_PHY_REG['LPDPRX_PMAFSM_REG1'], 8, 1, 1)
        # self.write_register(self.LANE_RP_OFFSET + LPDPRX_PHY_REG['LPDPRX_CFG0_COM'], 0x00202060)
        # self.set_bits(self.LANE_RP_OFFSET + LPDPRX_PHY_REG['LPDPRX_CFG1_COM'], 0, 16, 6500)
        # self.set_bits(self.LANE_RP_OFFSET+ LPDPRX_PHY_REG['LPDPRX_RXA_DESER_CTRL9'], 15, 1, 1)
        # self.set_bits(self.LANE_RP_OFFSET+ LPDPRX_PHY_REG['LPDPRX_RXA_DESER_CTRL9'], 14, 1, 1)
        # self.set_bits(self.LANE_RP_OFFSET+ LPDPRX_PHY_REG['LPDPRX_RXA_DESER_CTRL9'], 30, 1, 0)
        # self.set_bits(self.LANE_RP_OFFSET+ LPDPRX_PHY_REG['LPDPRX_RXA_DCOPI_CTRL5'], 27, 1, 1)
        # self.set_bits(self.LANE_RP_OFFSET+ LPDPRX_PHY_REG['LPDPRX_RXA_DCOPI_CTRL5'], 15, 1, 1)
        # self.set_bits(self.LANE_RP_OFFSET+ LPDPRX_PHY_REG['LPDPRX_RXA_DCOPI_CTRL6'], 25, 1, 1)
        # self.set_bits(self.LANE_RP_OFFSET+ LPDPRX_PHY_REG['LPDPRX_RXA_DCOPI_CTRL6'], 24, 1, 1)
        # self.set_bits(self.LANE_RP_OFFSET+ LPDPRX_PHY_REG['LPDPRX_RXA_DCOPI_CTRL6'], 23, 1, 1)
        # self.set_bits(self.LANE_RP_OFFSET+ LPDPRX_PHY_REG['LPDPRX_RXA_DCOPI_CTRL6'], 15, 1, 1)
        # self.set_bits(self.LANE_RP_OFFSET+ LPDPRX_PHY_REG['LPDPRX_RXA_DCORING_CTRL7'], 23, 1, 1)
        # self.set_bits(self.LANE_RP_OFFSET+ LPDPRX_PHY_REG['LPDPRX_RXA_DCORING_CTRL7'], 11, 1, 1)
        # self.set_bits(self.LANE_RP_OFFSET+ LPDPRX_PHY_REG['LPDPRX_RXA_DCORING_CTRL7'], 6, 5, 28)
        # self.set_bits(self.LANE_RP_OFFSET+ LPDPRX_PHY_REG['LPDPRX_RXA_DCORING_CTRL7'], 18, 5, 28)


    def start_margining(self):
        """Start the Margining"""
        self.mid_x = (self.min_x + self.max_x)//2
        self.mid_y = (self.min_y + self.max_y) // 2
        self.res_vol_north_data = []
        self.res_vol_south_data = []
        self.res_pi_east_data = []
        self.res_pi_west_data = []
        self.res_vol_north_data_1 = []
        self.res_vol_south_data_1 = []
        self.res_pi_east_data_1 = []
        self.res_pi_west_data_1 = []
        pi_idx = list(range(self.min_x, self.max_x+1))
        self.set_bits(self.LANE_RP_OFFSET + LPDPRX_PHY_REG['LPDPRX_RXA_DCOPI_CTRL5'], 7, 1, 1)
        self.set_bits(self.LANE_RP_OFFSET + LPDPRX_PHY_REG['LPDPRX_RXA_DCOPI_CTRL5'], 15, 1, 1)
        if self.axis_only is True:
            self.set_bits(self.SDP_ERR_THRESHOLD, 0, 8,1)
            self.set_bits(self.LANE_RP_OFFSET + LPDPRX_PHY_REG['LPDPRX_RXA_DESER_CTRL9'], 23, 6, 0)
            # Pi scan, again make sure you only move 1 step at a time
            for i in range(self.mid_x, pi_idx[0], -1):
                self.set_bits(self.LANE_RP_OFFSET+ LPDPRX_PHY_REG['LPDPRX_RXA_DCOPI_CTRL5'], 0, 7, self.dec2gray(i))
                self.set_bits(self.LANE_RP_OFFSET+ LPDPRX_PHY_REG['LPDPRX_RXA_DCOPI_CTRL5'], 8, 7, self.dec2gray(i))

            for pi_val in pi_idx:
                print(pi_val)
                self.set_bits(self.LANE_RP_OFFSET+ LPDPRX_PHY_REG['LPDPRX_RXA_DCOPI_CTRL5'], 0, 7, self.dec2gray(pi_val))
                self.set_bits(self.LANE_RP_OFFSET+ LPDPRX_PHY_REG['LPDPRX_RXA_DCOPI_CTRL5'], 8, 7, self.dec2gray(pi_val))
                self.set_bits(self.MAIN_LINK_STATUS_0, 0, 8, 255)
                self.set_bits(self.MAIN_LINK_STATUS_1, 0, 8, 255)
                self.set_bits(self.MAIN_LINK_STATUS_2, 0, 15, 30719)
                time.sleep_ms(self.duration_ms)
                status0=self.get_bits(self.MAIN_LINK_STATUS_0, 0, 8)
                status1=self.get_bits(self.MAIN_LINK_STATUS_1, 0, 8)
                status2=self.get_bits(self.MAIN_LINK_STATUS_2, 0, 15)
                print(hex(status0), hex(status1), hex(status2))
                # print(f"X Value: {pi_val} Status 0: {hex(status0)} Status 1: {hex(status1)} Status 2: {hex(status2)}"
                #       f"LPDP Error Count: {int(self.get_bits(0x22c71b044, 0, 16))} 20 Bit Error Code: {int(self.get_bits(0x22c71a074, 0, 20))}")
                if pi_val <= self.mid_x:
                    if hex(status0).lower() in ["0xd0", '0x50', '0x90', '0x10']:
                        print("hex condition satisfied")
                        self.res_pi_west_data.append(0)
                        self.res_pi_west_data_1.append(0)
                        if pi_val == self.mid_x:
                            self.res_pi_east_data.append(0)
                            self.res_pi_east_data_1.append(0)
                    else:
                        self.res_pi_west_data.append(1)
                        self.res_pi_west_data_1.append(1)
                        if pi_val == self.mid_x:
                            self.res_pi_east_data.append(1)
                            self.res_pi_east_data_1.append(1)
                elif pi_val > self.mid_x:
                    if hex(status0).lower() in ["0xd0", '0x50', '0x90', '0x10']:
                        print("hex condition satisfied")
                        self.res_pi_east_data.append(0)
                        self.res_pi_east_data_1.append(0)
                    else:
                        self.res_pi_east_data.append(1)
                        self.res_pi_east_data_1.append(1)


             # Bring pi back to mid, for voltage scan.
            for j in range(self.max_x, self.mid_x - 1, -1):
                print(j)
                self.set_bits(self.LANE_RP_OFFSET+ LPDPRX_PHY_REG['LPDPRX_RXA_DCOPI_CTRL5'], 0, 7, self.dec2gray(j))
                self.set_bits(self.LANE_RP_OFFSET+ LPDPRX_PHY_REG['LPDPRX_RXA_DCOPI_CTRL5'], 8, 7, self.dec2gray(j))
                self.read_register(self.LANE_RP_OFFSET+ LPDPRX_PHY_REG['LPDPRX_RXA_DCOPI_CTRL5'])

                self.set_bits(self.MAIN_LINK_STATUS_0, 0, 8, 255)
                self.set_bits(self.MAIN_LINK_STATUS_1, 0, 8, 255)
                self.set_bits(self.MAIN_LINK_STATUS_2, 0, 15, 30719)
                time.sleep_ms(self.duration_ms)
                status0 = self.get_bits(self.MAIN_LINK_STATUS_0, 0, 8)
                status1 = self.get_bits(self.MAIN_LINK_STATUS_1, 0, 8)
                status2 = self.get_bits(self.MAIN_LINK_STATUS_2, 0, 15)

            print("Set CTRL16")
            self.set_bits(self.LANE_RP_OFFSET + LPDPRX_PHY_REG['LPDPRX_RXA_SAVOS_CTRL16'], 7, 2,3)
            self.set_bits(self.LANE_RP_OFFSET + LPDPRX_PHY_REG['LPDPRX_RXA_SAVOS_CTRL16'], 9, 1,1)

            print("Set CTRL15 / 14 (Original Margining)")
            self.set_bits(self.LANE_RP_OFFSET + LPDPRX_PHY_REG['LPDPRX_RXA_SAVOS_CTRL15'], 20, 1,1)
            self.set_bits(self.LANE_RP_OFFSET + LPDPRX_PHY_REG['LPDPRX_RXA_SAVOS_CTRL14'], 28, 1,1)

            # print("Set CTRL15")
            # self.set_bits(self.LANE_RP_OFFSET + LPDPRX_PHY_REG['LPDPRX_RXA_SAVOS_CTRL15'], 20, 1,1)
            # self.set_bits(self.LANE_RP_OFFSET + LPDPRX_PHY_REG['LPDPRX_RXA_SAVOS_CTRL15'], 18, 1,1)
            #
            # print("Set CTRL14")
            # self.set_bits(self.LANE_RP_OFFSET + LPDPRX_PHY_REG['LPDPRX_RXA_SAVOS_CTRL14'], 28, 1,1)
            # self.set_bits(self.LANE_RP_OFFSET + LPDPRX_PHY_REG['LPDPRX_RXA_SAVOS_CTRL14'], 26, 1,1)
            #
            # print("Set CTRL2")
            # self.set_bits(self.LANE_RP_OFFSET + LPDPRX_PHY_REG['LPDPRX_RXA_CTLE_CTRL2'], 14, 4, 0)
            # self.set_bits(self.LANE_RP_OFFSET + LPDPRX_PHY_REG['LPDPRX_RXA_CTLE_CTRL2'], 0, 4, 0)

            for vol in range(self.min_y, self.max_y + 1, self.step_y):
                # print(f"Vol: {vol} - No Longer Setting CTRL14/15 To Vol, Setting CTRL9")
                # self.set_bits(self.LANE_RP_OFFSET + LPDPRX_PHY_REG['LPDPRX_RXA_DESER_CTRL9'], 23, 6, self.dec2gray(vol))
                # print("Reading Obs 3 100x (1000 total bits) and counting # of Bits = 1")
                # RXA_DESER_OBS3 = '0x22c71a074'
                # RXA_DESER_OBS1 = '0x22c71a06c'
                # total_value = 0
                # for i in range(100):
                #     print(f"Ten Bit Iteration: {i}")
                #     ten_bits = int(self.get_bits(int(RXA_DESER_OBS1), 21, 10))
                #     output = self.count_ones(ten_bits)
                #     print(f"Value: {ten_bits} One Bit Count: {output}")
                #     total_value += output
                # self.log_key(key="Y-Value_{}_one_bit_100x".format(vol), value=total_value, units='ticks')
                self.set_bits(self.LANE_RP_OFFSET + LPDPRX_PHY_REG['LPDPRX_RXA_SAVOS_CTRL15'], 14, 6, self.dec2gray(vol))
                self.set_bits(self.LANE_RP_OFFSET + LPDPRX_PHY_REG['LPDPRX_RXA_SAVOS_CTRL14'], 22, 6, self.dec2gray(vol))
                time.sleep(1)
                self.set_bits(self.MAIN_LINK_STATUS_0, 0, 8, 255)
                self.set_bits(self.MAIN_LINK_STATUS_1, 0, 8, 255)
                self.set_bits(self.MAIN_LINK_STATUS_2, 0, 15, 30719)
                time.sleep_ms(self.duration_ms)
                status0 = self.get_bits(self.MAIN_LINK_STATUS_0, 0, 8)
                status1 = self.get_bits(self.MAIN_LINK_STATUS_1, 0, 8)
                status2 = self.get_bits(self.MAIN_LINK_STATUS_2, 0, 15)
                # print(f"Y Value: {vol} Status 0: {hex(status0)} Status 1: {hex(status1)} Status 2: {hex(status2)}"
                #       f"LPDP Error Count: {int(self.get_bits(0x22c71b044, 0, 16))} 20 Bit Error Code: {int(self.get_bits(0x22c71a074, 0, 20))}")
                if vol <= self.mid_y:
                    if hex(status0).lower() in ["0xd0", '0x50', '0x90', '0x10']:
                        print("hex condition satisfied")
                        self.res_vol_south_data.append(0)
                        self.res_vol_south_data_1.append(0)
                        if vol == self.mid_y:
                            self.res_vol_north_data.append(0)
                            self.res_vol_north_data_1.append(0)
                    else:
                        self.res_vol_south_data.append(1)
                        self.res_vol_south_data_1.append(1)
                        if vol == self.mid_y:
                            self.res_vol_north_data.append(1)
                            self.res_vol_north_data_1.append(1)
                elif vol > self.mid_y:
                    if hex(status0).lower() in ["0xd0", '0x50', '0x90', '0x10']:
                        print("hex condition satisfied")
                        print(vol)
                        self.res_vol_north_data.append(0)
                        self.res_vol_north_data_1.append(0)
                    else:
                        self.res_vol_north_data.append(1)
                        self.res_vol_north_data_1.append(1)
            print(self.res_vol_south_data)

    def count_ones(self, value):
        # Count number of 1s in the value,
        one_bit_count = 0
        while value != 0:
            if value & 0x1 == 1:
                one_bit_count += 1
            value = value >> 1

        return one_bit_count

    def dump_registers(self, initial=False):
        """Dump Static Registers"""

    def parse_margin_data(self):
        """Parse data to the necessary format(s)"""

    def calculate_eye(self):
        """Calculate the Eye Diagram for axis only"""
        # Get the data for the lane (list of margin values)
        if self.axis_only is True:
            data = self.res_pi_west_data
        else:
            data = self.res_data

        if len(data) > 0:
            self.seq_log.info(
                "      Dumping eye for lane {}".format(self.current_lane))
            north, south, east, west = self.mid_y, self.mid_y, self.mid_x, self.mid_x

            # Visual diagram and Raw diagram
            diagram, coords = "", ""

            # Iterate thru the coordinate Top Left to Bottom Right
            if self.axis_only is True:
                for y in range(self.min_y, self.max_y+1, 1):
                    for x in range(self.min_x, self.max_x+1, 1):
                        if y != self.mid_y and x != self.mid_x:
                            diagram += " "
                            coords += "{}".format("     ") if x == self.max_x else ",{}". \
                                format("     ")
                        else:
                            if y == self.mid_y:
                                if x <= self.mid_x:
                                    margin = self.res_pi_west_data.pop(0)
                                    if x == self.mid_x:
                                        self.res_pi_east_data.pop(0)
                                else:
                                    margin = self.res_pi_east_data.pop(0)
                            else:
                                if y <= self.mid_y:
                                    margin = self.res_vol_south_data.pop(0)
                                    if y == self.mid_y:
                                        self.res_vol_north_data.pop(0)
                                else:
                                    margin = self.res_vol_north_data.pop(0)
                            # Add to the Coordinate file
                            if margin <= self.threshold:
                                diagram += "0"
                            else:
                                diagram += "1"
                            coords += "{}".format(self.padded_hex(margin, 5))
                    coords += "\n"
                    diagram += "\n"
                margin_south = self.res_vol_south_data_1.pop()
                if margin_south <= self.threshold:
                    # raise Exception(" DAC 0 0s have errors")
                    south = self.mid_y
                    while margin_south <= self.threshold and abs(south) < abs(self.min_y):
                        margin_south = self.res_vol_south_data_1.pop()
                        south = south - 1
                else:
                    south = self.mid_y
                margin_north = self.res_vol_north_data_1.pop(0)
                if margin_north <= self.threshold:
                    # raise Exception(" DAC 0 0s have errors")
                    north = self.mid_y
                    while margin_north <= self.threshold and north < self.max_y:
                        margin_north = self.res_vol_north_data_1.pop(0)
                        north = north + 1
                else:
                    north = self.mid_y
                margin_west = self.res_pi_west_data_1.pop()
                if margin_west <= self.threshold:
                    # raise Exception(" DAC 0 0s have errors")
                    west = self.mid_x
                    while margin_west <= self.threshold and west > self.min_x:
                        margin_west = self.res_pi_west_data_1.pop()
                        west = west - 1
                else:
                    west = self.mid_x
                margin_east = self.res_pi_east_data_1.pop(0)
                if margin_east <= self.threshold:
                    # raise Exception(" DAC 0 0s have errors")
                    east = self.mid_x
                    while margin_east <= self.threshold and east < self.max_x:
                        margin_east = self.res_pi_east_data_1.pop(0)
                        east = east + 1
                else:
                    east = self.mid_x
            else:
                # Iterate thru the coordinate Top Left to Bottom Right
                for y in range(self.min_y, self.max_y, 1):
                    for x in range(self.min_x, self.max_x, 1):
                        margin = data.pop(0)
                        # Add to the Coordinate file
                        coords += "{}".format(self.padded_hex(margin, 5)) if x == self.max_x else ",{}". \
                            format(self.padded_hex(margin, 5))

                        # Log only values below the threshold
                        if margin <= self.threshold:
                            diagram += "0"
                            # Set the North / South values
                            south = y if y < south else south
                            north = y if y > north else north

                            # Set the East / West values
                            west = x if x < west else west
                            east = x if x > east else east
                        else:
                            diagram += "1"

                    coords += "\n"
                    diagram += "\n"
            print(diagram)
            # Write the coordinate and diagram files
            self.write_coordinate_file(coords)
            self.write_eye_diagram_file(diagram)

            # Set the Height / Width
            # Set the Height / Width
            height = north + abs(south)
            width = (east - west)
            print(height,width)
            if height >> 0 and width >> 0:
                self.eye_height[self.current_lane] = self.TICK_TO_VOLTAGE * self.mf * (north + abs(south))
                self.eye_width[self.current_lane] = self.TICK_TO_FREQUENCY * (east - west)
                self.eye_height_ticks[self.current_lane] = north + abs(south)
                self.eye_width_ticks[self.current_lane] = east - west
            else:
                if height >> 0:
                    self.eye_height[self.current_lane] = self.TICK_TO_VOLTAGE * self.mf * (north + abs(south))
                    self.eye_width[self.current_lane] = 0
                    self.eye_height_ticks[self.current_lane] = north + abs(south)
                    self.eye_width_ticks[self.current_lane] = 0
                elif width >> 0:
                    self.eye_height[self.current_lane] = 0
                    self.eye_width[self.current_lane] = self.TICK_TO_FREQUENCY * (east - west)
                    self.eye_height_ticks[self.current_lane] = 0
                    self.eye_width_ticks[self.current_lane] = east - west
                else:
                    self.eye_height[self.current_lane] = 0
                    self.eye_width[self.current_lane] = 0
                    self.eye_height_ticks[self.current_lane] = 0
                    self.eye_width_ticks[self.current_lane] = 0
            # Log them to the result file
            self.log_key(key="lane_{}_north_ticks".format(self.current_lane), value=north, units='ticks')
            self.log_key(key="lane_{}_south_ticks".format(self.current_lane), value=south, units='ticks')
            self.log_key(key="lane_{}_east_ticks".format(self.current_lane), value=east, units='ticks')
            self.log_key(key="lane_{}_west_ticks".format(self.current_lane), value=west, units='ticks')
            self.log_key(key="lane_{}_eh_mv".format(self.current_lane), value=self.eye_height[self.current_lane],
                         units='mV', upperlimit=self.eh_max, lowerlimit=self.eh_min)
            self.log_key(key="lane_{}_ew_ui".format(self.current_lane), value=self.eye_width[self.current_lane],
                         units='ui', upperlimit=self.ew_max, lowerlimit=self.ew_min)
            self.log_key(key="lane_{}_eh_ticks".format(self.current_lane), value=self.eye_height_ticks[self.current_lane],
                         units='ticks')
            self.log_key(key="lane_{}_ew_ticks".format(self.current_lane), value=self.eye_width_ticks[self.current_lane],
                         units='ticks')

            self.log_msg("Lane {}: north = {}, south = {}, east = {}, west = {}, ns = {}mV, ew = {}ui".format(
                self.current_lane,
                north,
                south,
                east,
                west,
                self.eye_height[self.current_lane],
                self.eye_width[self.current_lane]
            ))
    #
    # Helpers
    #
    def progress(self):
        """Progress in integer % increments"""
        self.log_msg("   {}%".format(self._fake_progress))
        return self._fake_progress

    def is_running(self):
        """Check if Margining is running"""
        return self.progress < 100

    def all_lanes_scanned(self, lane):
        """Check if all lanes scanned, Used for tools that need to have individual lanes scanned"""
        if lane == self.LANE_COUNT:
            return 1
        else:
            self.log_msg("Didnt complete all lanes")

    def wait_for_finish(self):
        return 1