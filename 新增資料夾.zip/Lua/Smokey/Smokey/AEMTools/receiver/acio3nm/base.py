import time
from .defines import *
from ..base import AbstractBaseMarginTool
from .conversion import *
from .soc_defines import *
from shell import run
import math

__all__ = [
    "AbstractReceiverMarginTool"
]


class AbstractReceiverMarginTool(AbstractBaseMarginTool):
    """Generic Interface for Widget Pass Margining"""
    LANE_COUNT = 2   # The Number of lanes (if applicable)
    POLL_TIME = 1  # Polling interval
    TIMEOUT = 20.000  # Maximum time in seconds before a 'run' is timeout
    res_data = []
    res_vol_north_data = []
    res_vol_south_data = []
    res_pi_east_data = []
    res_pi_west_data = []
    res_vol_north_data_1 = []
    res_vol_south_data_1 = []
    res_pi_east_data_1 = []
    res_pi_west_data_1 = []
    LANE_RP_OFFSET = 0
    mid_x = 0
    mid_y = 0
    mid_x_dclkb = 0

    RP_OFFSET = 0
    lane_offset = 0x7000
    r = None
    c = None
    soc_atc0_offset = 0
    aciophy_lane0 = 0
    atc_top_offset = 0
    RP_OFFSET_ACIO = 0
    atc_acio_offset = 0
    LANE0_RP_OFFSET = 0
    port_num = None

    def __init__(self, *args, **kwargs):
        super(AbstractReceiverMarginTool, self).__init__(*args, **kwargs)
        self._fake_progress = 0
        self.soc_atc0_offset = SOC_CONVERSION_CODE[self.soc]['SOC_ATC_OFFSET']
        self.atc_top_offset = SOC_CONVERSION_CODE[self.soc]['ATC_TOP_OFFSET']
        self.atc_acio_offset = SOC_CONVERSION_CODE[self.soc]['ATC_ACIO_OFFSET']
        self.RP_OFFSET = SOC_CONVERSION_CODE[self.soc]['RP_OFFSET']
        self.aciophy_lane0 = SOC_CONVERSION_CODE[self.soc]['ACIOPHY_LANE0']
        self.lane_offset = SOC_CONVERSION_CODE[self.soc]['LANE_OFFSET']
        if self.die_location:
            self.die_length = int(len(self.die_location['0']))
            self.die_number = 0
            print("Number of ATC Ports on DIE: {}".format(self.die_length))
        else:
            self.die_length = 0
            self.die_number = 0
        try:
            self.die_offset = SOC_CONVERSION_CODE[self.soc]['DIE_OFFSET']
        except KeyError:
            self.die_offset = None

        valid_gen_versions = ["CIO_GEN2", "USB_10G", "CIO_GEN3", "USB_5G", "DP_RBR", "DP_HBR", "DP_HBR2", "DP_HBR3"]
        print("Gen Version: {}".format(self.gen_version))
        if self.gen_version is not None and self.gen_version not in ["CIO_GEN2", "USB_10G", "CIO_GEN3", "USB_5G", "DP_RBR", "DP_HBR", "DP_HBR2", "DP_HBR3"]:
            raise Exception("Gen Version Required to be in: {}, but Gen Version provided: {}".format(valid_gen_versions, self.gen_version))

    #
    #  Accessors
    #
    def write_register(self, address, value):
        """Set Register to a value"""

    def read_register(self, address):
        """Get a Register value"""

    def set_bits(self, address, start_bit, length, value):
        """Change specific bits of a address"""

    def get_bits(self, address, start_bit, length):
        """Change specific bits of a address"""

    def int2sa_vos_code(self, intval):
        """ convert to gray code from sign int 5 bits """
        if (intval < -31) or (intval > 31):
            return None
        elif intval >= 0:
            return intval ^ intval >> 1
        return abs(intval ^ intval >> 1) + 32

    def dec2gray(self, i=0):
        """ convert dec to gray """
        return i ^ i >> 1

    def gray2dec(self, i=0, total_bits=63):
        """ convert gray to dec """
        return [self.dec2gray(d) for d in range(total_bits)].index(i)
    #
    # Execution Flow
    #

    def set_adaptation_ace(self):
        if bool(self.vendor_specific['run']) is True and self.adaptation_run is 0:
            run("ace --list; "
                "ace --pick ATC2; "
                "ace --write {}".format(self.vendor_specific['ace']))
            run("ace --4cc {} --txdata {}".format("DISC", "0x3"))
            time.sleep(5)
        else:
            pass

    def set_adaptation_dfe(self):
        if bool(self.dfe_off) is True:
            # 10g to 20g DFEH1 to 0
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['AEQ_CTRL_DFE_CFG0'], 18, 6, 0)
            self.set_bits(self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['AEQ_CTRL_DFE_CFG0'], 18, 6, 0)

            # 10g to 20g DFEH2 to 0
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['AEQ_CTRL_DFE_CFG1'], 4, 4, 0)
            self.set_bits(self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['AEQ_CTRL_DFE_CFG1'], 4, 4, 0)

            # 10g to 20g DFEH3 to 0
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['AEQ_CTRL_DFE_CFG1'], 20, 4, 0)
            self.set_bits(self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['AEQ_CTRL_DFE_CFG1'], 20, 4, 0)

            # 10g to 20g DFEH4 to 0
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['AEQ_CTRL_DFE_CFG2'], 4, 4, 0)
            self.set_bits(self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['AEQ_CTRL_DFE_CFG2'], 20, 4, 0)

            # 10g to 20g DFEH5 to 0
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['AEQ_CTRL_DFE_CFG2'], 20, 4, 0)
            self.set_bits(self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['AEQ_CTRL_DFE_CFG2'], 20, 4, 0)

            # Set all 5 override bits to 1
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['AEQ_CTRL_DFE_CFG8'], 0, 5, 31)
            self.set_bits(self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['AEQ_CTRL_DFE_CFG8'], 0, 5, 31)
        else:
            pass

    def set_rc(self, figure_of_merit):
        if bool(self.ctle_sweep) is True:
            self.r = figure_of_merit[0]
            self.c = figure_of_merit[1]

            # R/C Speed Override Bits for all Protocols
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['AEQ_CTRL_CTLE_CFG3'], 0, 2, 3)
            self.set_bits(self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['AEQ_CTRL_CTLE_CFG3'], 0, 2, 3)

            #   C override (all protocols)
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['AEQ_CTRL_CTLE_CFG0'], 0, 4, self.dec2gray(self.c))
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['AEQ_CTRL_CTLE_CFG0'], 4, 4, self.dec2gray(self.c))
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['AEQ_CTRL_CTLE_CFG0'], 8, 4, self.dec2gray(self.c))
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['AEQ_CTRL_CTLE_CFG0'], 12, 4, self.dec2gray(self.c))

            self.set_bits(self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['AEQ_CTRL_CTLE_CFG0'], 0, 4, self.dec2gray(self.c))
            self.set_bits(self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['AEQ_CTRL_CTLE_CFG0'], 4, 4, self.dec2gray(self.c))
            self.set_bits(self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['AEQ_CTRL_CTLE_CFG0'], 8, 4, self.dec2gray(self.c))
            self.set_bits(self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['AEQ_CTRL_CTLE_CFG0'], 12, 4, self.dec2gray(self.c))

            #   R override (all protocols)
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['AEQ_CTRL_CTLE_CFG0'], 16, 4, self.dec2gray(self.r))
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['AEQ_CTRL_CTLE_CFG0'], 20, 4, self.dec2gray(self.r))
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['AEQ_CTRL_CTLE_CFG0'], 24, 4, self.dec2gray(self.r))
            self.set_bits(self.LANE0_RP_OFFSET + AUSPMA_LANE0['AEQ_CTRL_CTLE_CFG0'], 28, 4, self.dec2gray(self.r))

            self.set_bits(self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['AEQ_CTRL_CTLE_CFG0'], 16, 4, self.dec2gray(self.r))
            self.set_bits(self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['AEQ_CTRL_CTLE_CFG0'], 20, 4, self.dec2gray(self.r))
            self.set_bits(self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['AEQ_CTRL_CTLE_CFG0'], 24, 4, self.dec2gray(self.r))
            self.set_bits(self.LANE0_RP_OFFSET + self.lane_offset + AUSPMA_LANE0['AEQ_CTRL_CTLE_CFG0'], 28, 4, self.dec2gray(self.r))
        else:
            pass

    def set_adaptation(self, figure_of_merit):
        """Set the Adaptation Type (if applicable)"""
        if bool(self.doe) is True:
            protocol = None
            if self.gen_version is not None:
                # 'usb' or 'cio10g' or 'cio20g' or 'ciodp' or 'dp'
                if self.gen_version in ["CIO_GEN3"]:
                    protocol = "cio20g"
                elif self.gen_version in ["CIO_GEN2", "USB_10G"]:
                    protocol = "cio10g"
                elif self.gen_version in ["DP_HBR2", "DP_HBR3"]:
                    protocol = "ciodp"
                elif self.gen_version in ["DP_RBR", "DP_HBR"]:
                    protocol = "dp"
                else:
                    protocol = "usb"

            for port in range(0, len(self.root_port), 1):
                self.port_num = self.root_port[port]
                self.calculate_base_offset(self.port_num)
                self.set_adaptation_ace()
                run("device -k usbphy -e select {}".format(self.port_num))

                if protocol is not None:
                    run("device -k usbphy -e powerup {}".format(protocol))
                else:
                    run("device -k usbphy -e powerup")
                self.LANE0_RP_OFFSET = self.soc_atc0_offset + self.die_offset_addr + (self.port_num - (self.die_number * self.die_length)) * self.RP_OFFSET + self.atc_top_offset

                self.set_adaptation_dfe()
                print(self.ctle_sweep)
                self.set_rc(figure_of_merit)

                if protocol is not None:
                    run("device -k usbphy -e linktrain {}".format(protocol))
                else:
                    run("device -k usbphy -e linktrain")
        else:
            return 1

    def apply_settings(self, retrain=True):
        """Apply EQ and other settings, retrain (if applicable)"""

    def ensure_link(self):
        """Check Link meets Speed / Width requirements"""

    def disable_power_management(self):
        """Disable Power Management Modes"""
        self.log_msg("   Disable Power Management")

    def set_traffic_type(self, traffic_type):
        """Select the Traffic type (Live, PRBS, etc)"""

    def calculate_base_offset(self, port_num):
        """Calculate the base atc offset based on the port_num"""
        self.die_offset_addr = 0
        # if die location isn't provided in project defines, we assume the project is single die.
        if self.die_location:
            for key, value in self.die_location.items():
                # grab which die the port_num is on
                if str(port_num) in value:
                    if self.die_offset is not None:
                        die_offset_addr = int(key) * self.die_offset
                        self.die_offset_addr = die_offset_addr
                        self.die_number = int(key)
                        print("   Found Valid Key: {} in Die Location: {} for Port Num: {} New Die Offset ADDR: {}   ".format(key, self.die_location, port_num, self.die_offset_addr))
                        self.log_msg("   Found Valid Key: {} in Die Location: {} for Port Num: {}   ".format(key, self.die_location, port_num))
                        return
                    else:
                        # error if we have multiple dies but no offset for between the dies
                        print("    Die Location Exists (i.e. the product has multiple dies) but no offsett address provided    ")
                        raise("    Die Location Exists (i.e. the product has multiple dies) but no offsett address provided    ")
            print("    Port Number: {} not found in Die Location: {}    ".format(port_num, self.die_location))
            raise("    Port Number: {} not found in Die Location: {}    ".format(port_num, self.die_location))
        # else:
            # print("    No Die Location, Moving On     ")
            # self.log_msg("    No Die Location, Moving On     ")


    def select_lane(self, lane):
        """Select a Lane"""
        self.current_lane = lane
        self.port_num = self.root_port[0]
        self.calculate_base_offset(self.port_num)
        self.LANE_RP_OFFSET = self.soc_atc0_offset + self.die_offset_addr + \
                              (self.port_num - (self.die_number * self.die_length)) * self.RP_OFFSET + \
                              self.atc_top_offset + \
                               self.current_lane * self.lane_offset
        self.RP_OFFSET_ACIO = self.soc_atc0_offset + self.die_offset_addr + \
                              self.atc_acio_offset +\
                              (self.port_num - (self.die_number * self.die_length)) * self.RP_OFFSET
        self.log_msg("   Selecting Lane {} with LANE RP OFFSET: {} and RP OFFSET ACIO {}".format(lane, self.LANE_RP_OFFSET, self.RP_OFFSET_ACIO))

    def select_lane_rp(self, lane):
        """Select a Lane"""
        self.current_lane = lane
        self.calculate_base_offset(self.port_num)
        self.LANE_RP_OFFSET = self.soc_atc0_offset + self.die_offset_addr + \
                              (self.port_num - (self.die_number * self.die_length)) * self.RP_OFFSET + \
                              self.atc_top_offset + \
                               self.current_lane * self.lane_offset
        self.RP_OFFSET_ACIO = self.soc_atc0_offset + self.die_offset_addr + \
                              self.atc_acio_offset +\
                              (self.port_num - (self.die_number * self.die_length)) * self.RP_OFFSET

    def configure_phy(self):
        """Configure the PHY Settings, Overrides, ECO, etc"""

    def setup_margining(self):
        """Configure Margin Settings"""

        for port in range(0, len(self.root_port), 1):
            self.port_num = self.root_port[port]
            for lane in range(0, self.LANE_COUNT, 1):
                self.select_lane_rp(lane)
                # Per Olivier, Skip Steps 5b / 5c -> instead read E-Clock / D-Clock
                # The Error PI Codes, PMA RXA DCOPI ECLK POS GRAY, and EXCLKB Should Only Change 1x At A Time and Not By >1

                # ToDo: (Questions)
                # AUS40PMA_RX_APB_OVERRIDE_REG_50
                # Conversion factor mV to Ticks?

                # Presume that steps 1 / 2(a)(b)(c) are handled by the FW.

                # Step 3(a) - Setup Error PI to Align EClk Pos Gray
                # RXA_DCOPI_CTRL61 - https://seg-docs.csg.apple.com/projects/ibiza/release/UserManual/regs/trunk/default/AUSPMA_RX_SHM.html?baseaddr=0x2a671a000#AUSPMA_RX_SHM_auspma_rx_rxa_dcopi_ctrl61
                #   eclk_pos_gray_ov = 1
                #   eclk_pos_gray = binary2gray(8) = 12
                #   eclkb_pos_gray_ov = 1
                #   eclkb_pos_gray = binary2gray(8) = 12

                print("Step 3(a) Setup Error PI To Align EClk Pos Gray")
                print("Skip setting values to 8 and instead align ECLK / ECLKB to DCLK / DCLKB")
                print(
                    "Check ECLK/ECLKB and DCLK/DCLKB are in the same location (center of the eye) - if not, walk them back")

                dclk_pos_decimal = self.gray2dec(
                    self.get_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCO_CTRL89_RO'], 14, 7))
                dclkb_pos_decimal = self.gray2dec(
                    self.get_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCO_CTRL89_RO'], 21, 7))

                eclk_pos_decimal = self.gray2dec(
                    self.get_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL611_RO'], 0, 7))
                eclkb_pos_decimal = self.gray2dec(
                    self.get_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL611_RO'], 7, 7))
                print(
                    f"DCLK: {dclk_pos_decimal} DCLKB: {dclkb_pos_decimal} ECLK :{eclk_pos_decimal} ECLKB: {eclkb_pos_decimal}")
                # Set 61 to value from CTRL611
                self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL61'], 0, 7, self.dec2gray(eclk_pos_decimal))
                self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL61'], 7, 1, 1)
                time.sleep(10 / 1000000.0)

                self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL61'], 8, 7, self.dec2gray(eclkb_pos_decimal))
                self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL61'], 15, 1, 1)
                time.sleep(10 / 1000000.0)

                print(f" Touching DCOPI 61 Bits 0->6 and 8->14 Decimal: {eclk_pos_decimal} Gray: {self.dec2gray(eclk_pos_decimal)}")

                if eclk_pos_decimal != dclk_pos_decimal and eclkb_pos_decimal != dclkb_pos_decimal:
                    if dclk_pos_decimal > eclk_pos_decimal:
                        direction = 1
                    elif dclk_pos_decimal < eclk_pos_decimal:
                        direction = -1
                    print(f" Direction: {direction}")
                    for difference in range(eclk_pos_decimal, dclk_pos_decimal, direction):
                        print(f" Walking Back Difference: {difference} Gray Value: {self.dec2gray(difference)}")
                        self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL61'], 0, 7, self.dec2gray(difference))
                        time.sleep(10 / 1000000.0)
                        self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL61'], 8, 7, self.dec2gray(difference))
                        time.sleep(10 / 1000000.0)
                        print(
                            f" Touching DCOPI 61 Bits 0->6 and 8->14 Decimal: {difference} Gray: {self.dec2gray(difference)}")

                    self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL61'], 0, 7, self.dec2gray(dclk_pos_decimal))
                    time.sleep(10 / 1000000.0)
                    self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL61'], 8, 7, self.dec2gray(dclkb_pos_decimal))
                    time.sleep(10 / 1000000.0)
                    print(f" Touching DCOPI 61 Bits 0->6 and 8->14 Decimal: {dclk_pos_decimal} Gray: {self.dec2gray(dclk_pos_decimal)}")

                    dclk_pos_decimal = self.gray2dec(
                        self.get_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCO_CTRL89_RO'], 14, 7))
                    dclkb_pos_decimal = self.gray2dec(
                        self.get_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCO_CTRL89_RO'], 21, 7))

                    eclk_pos_decimal = self.gray2dec(
                        self.get_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL611_RO'], 0, 7))
                    eclkb_pos_decimal = self.gray2dec(
                        self.get_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL611_RO'], 7, 7))

                    print(f"DCLK: {dclk_pos_decimal} DCLKB: {dclkb_pos_decimal} ECLK :{eclk_pos_decimal} ECLKB: {eclkb_pos_decimal}")

                # Step 4(a) - Enable H0 DAC (set it 0 to begin with, also enable error deserializer)
                # The register write should happen in following order with a gap of 1 μs between each write.
                # rxa_deser_ctrl91 not required if cfg0_eq.h0_dac_en is 1 (https://seg-docs.csg.apple.com/projects/ibiza/release/UserManual/regs/trunk/default/AUSPMA_RX_EQ.html?baseaddr=0x2a6719000#AUSPMA_RX_EQ_cfg0_eq)
                # rxa_deser_ctrl91 - https://seg-docs.csg.apple.com/projects/ibiza/release/UserManual/regs/trunk/default/AUSPMA_RX_SHM.html?baseaddr=0x2a671a000#AUSPMA_RX_SHM_auspma_rx_rxa_deser_ctrl91
                #   dfeh0dac_sml_en_ov = 1
                #   dfeh0dac_big_en_ov = 1
                #   dfeh0dac_sml_en = 1
                #   dfeh0dac_big_en = 1
                #   dfeh0dac_gray_ov = 1
                #   dfeh0dac_gray = 0

                print("Step 4(a) Enable H0 Dac (set it to 0 to begin with) also enable error deserializer.")
                self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DESER_CTRL91'], 17, 1, 1)
                self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DESER_CTRL91'], 18, 1, 1)

                self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DESER_CTRL91'], 15, 1, 1)
                self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DESER_CTRL91'], 16, 1, 1)

                self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DESER_CTRL91'], 19, 6, 0)
                self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DESER_CTRL91'], 25, 1, 1)

                # Step 4(b) - Write lane’s RX SHIM register, rxa_dfe_ctrl111 to control H0 DAC
                # rxa_dfe_ctrl111 - https://seg-docs.csg.apple.com/projects/ibiza/release/UserManual/regs/trunk/default/AUSPMA_RX_SHM.html?baseaddr=0x2a671a000#AUSPMA_RX_SHM_auspma_rx_rxa_dfe_ctrl111
                #   dfeh0dac_range_ov = 1
                #   dfeh0dac_range = 3

                print("Step 4(b)")
                self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DFE_CTRL111'], 0, 2, 3)
                self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DFE_CTRL111'], 2, 1, 1)


                # Step 5(a) - Enable Error deserializer (Data and Edge should already be enabled by PCTRL)
                # rxa_deser_ctrl91
                #   pma_rxa_deser_e_en_ov = 1
                #   pma_rxa_deser_e_en = 1

                print("Step 5(a) - Enable Error Deserializer (Data and Edge should already be enabled by PCTRL)")
                self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DESER_CTRL91'], 10, 1, 1)
                self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DESER_CTRL91'], 11, 1, 1)

                print("Skip 5(b) and 5(c)")

                # Skip 5(b) and 5(c)
                # Alternative 5(b) and 5(c) from Olivier
                # AUSPMA_RX_RXA_DCO_CTRL89_RO : for DCLK/DCLKB and AUSPMA_RX_RXA_DCOPI_CTRL611_RO for ECLK/ECLKB
                # Make sure they are at the same location. This should be the center of the eye
                # If ECLK/ECLKB are not at the same location as DCLK/DCLKB move them back to those locations (the rule that you can only move by one step at a time, still applies
                # AUSPMA_RX_SHM_auspma_rx_rxa_dco_ctrl89_ro - https://seg-docs.csg.apple.com/projects/ibiza/release/UserManual/regs/trunk/default/AUSPMA_RX_SHM.html?baseaddr=0x2a671a000#AUSPMA_RX_SHM_auspma_rx_rxa_dco_ctrl89_ro
                # AUSPMA_RX_SHM_auspma_rx_rxa_dco_ctrl611_ro - https://seg-docs.csg.apple.com/projects/ibiza/release/UserManual/regs/trunk/default/AUSPMA_RX_SHM.html?baseaddr=0x2a671a000#AUSPMA_RX_SHM_auspma_rx_rxa_dcopi_ctrl611_ro

                # To walk them back - AUSPMA_RX_RXA_DCOPI_CTRL61 - https://seg-docs.csg.apple.com/projects/ibiza/release/UserManual/regs/trunk/default/AUSPMA_RX_SHM.html?baseaddr=0x2a671a000#AUSPMA_RX_SHM_auspma_rx_rxa_dcopi_ctrl61

                print("Step 6 - Choose eye scan mask, to choose between composite, even/odd bits")
                print("Setting error mask to", self.error_mask)
                self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RX_EQ_CFG42_EQ'], 1, 2, self.error_mask)
                self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RX_EQ_CFG42_EQ'], 3, 1, 1)
                # Step 6 - Choose eye scan mask, to choose between composite, even/odd bits
                # RX EQ register, cfg42_eq - https://seg-docs.csg.apple.com/projects/ibiza/release/UserManual/regs/trunk/default/AUSPMA_RX_EQ.html?baseaddr=0x2a6719000#AUSPMA_RX_EQ_cfg42_eq
                # error_mask = 0x0 – composite scan (both even and odd are active)
                #            = 0x1 – only odd samplers’ output is used
                #            = 0x2 – only even samplers’ output is used
                #            = 0x3 – gated both even and odd samplers’ output
                # error_mask_ov = 1, if user wants to do either even or odd eye scan else write error_mask_ov = 0

    def _update_status(self):
        """Fake Progress updater"""
        for i in range(0, 101):
            self._fake_progress = i
            time.sleep(0.05)

    def padded_hex(self, i, l):
        given_int = i
        given_len = l

        hex_result = hex(given_int)[2:]  # remove '0x' from beginning of str
        num_hex_chars = len(hex_result)
        extra_zeros = '0' * (given_len - num_hex_chars)  # may not get used..

        return ('0x' + hex_result if num_hex_chars == given_len else
                '?' * given_len if num_hex_chars > given_len else
                '0x' + extra_zeros + hex_result if num_hex_chars < given_len else
                None)

    def capture_errors(self):
        """Enable the error accumulator, wait desired time, capture errors"""
        ##### Step B --> E helper method #####
        # Step B - Enable Error Accumulator
        # Write Rx Eq Register CFG46_EQ: EN_ERR_ACC=1

        # Step C - Wait for desired number of bits (dwell time)
        # PCIe Gen3, one UI = 125 ps (one bit) so for 10^12 bits the wait is 125 seconds

        # Step D - Read number of errors
        # Write Rx EQ register to capture the error count
        # CFG46_EQ Cap Err Acc = 1
        # Read Rx EQ Register CFG44_EQ ERR ACC
        # Write Rx EQ Register
        # CFG46_EQ CAP ERR ACC = 0

        # Step E - Disable Error Accumulator
        # Write Rx EQ Register CFG46 EQ EN_ERR_ACC = 0
        ##### Step B --> E helper method #####

        print("Capture Errors")

        print("Enable Error Accumulator - EN ERR ACC = 1")
        # en_err_acc = 1
        self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RX_EQ_CFG46_EQ'], 20, 1, 1)

        print(f"Wait Desired Time: {self.sleep_time}")
        # wait for desired number of bits
        time.sleep(self.sleep_time)

        print("Read Number of Errors - Write to Capture to Error, Read Register, Cancel Error Accumulate")
        self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RX_EQ_CFG46_EQ'], 19, 1, 1)
        errors = int(self.get_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RX_EQ_CFG44_EQ'], 12, 20))
        self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RX_EQ_CFG46_EQ'], 19, 1, 0)

        print(f"Found Errors: {errors}")

        print("Disable Error Accumulator - EN ERR ACC = 0")
        # en_err_acc = 0
        self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RX_EQ_CFG46_EQ'], 20, 1, 0)

        return errors

    def start_margining(self):
        """Start the Margining"""
        # Eyescan Steps A->G for vertical scan and H->I for horizontal scan
        # X-Value Pi-Codes, Y-Value-H0 Dac

        # self.mid_x = int((self.min_x + self.max_x) / 2)
        # self.mid_x = self.gray2dec(self.get_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCO_CTRL89_RO'], 14, 7))

        # self.mid_y = self.gray2dec(self.get_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCO_CTRL89_RO'], 14, 7))
        # self.min_y = self.mid_y - 32
        # self.max_y = self.mid_y + 32

        self.sleep_time = self.duration_ms / 1000

        print("Step A - Setup H0 Dac - CTRL91")

        self.x_axis, self.y_axis = [], []  # 32 code each direction + 1 center
        for port in range(0, len(self.root_port), 1):
            self.x_axis.append([])
            self.y_axis.append([])
            self.port_num = self.root_port[port]
            # Can't presume starting at mid_x
            for lane in range(0, self.LANE_COUNT, 1):
                self.select_lane_rp(lane)

                # Sweep 64 to each side if not running full eye
                vco_bsel_div_code_r = int(self.get_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RX_TOP_CDR_CFG2'], 0, 2))
                self.log_key(key="port:{}_lane:{}_div_code".format(
                    self.port_num,
                    self.current_lane),
                    value=vco_bsel_div_code_r,
                    units='ticks')

                if int(vco_bsel_div_code_r) < 3:
                    self.min_x = 0
                    self.max_x = 127
                else:
                    print("No Update Needed")
                # if vco_bsel_div_code_r < 3:
                #     self.min_x = self.mid_x[port][self.current_lane] - 64
                #     self.max_x = self.mid_x[port][self.current_lane] + 64
                # else:
                #     self.min_x = self.mid_x[port][self.current_lane] - 32
                #     self.max_x = self.mid_x[port][self.current_lane] + 32

                cio_gen = self.get_bits(self.RP_OFFSET_ACIO + ACIO_TOP['ACIO_TOP_ACIO_GLOBAL_CFG0'], 0, 2)
                if cio_gen is 0:
                    self.TICK_TO_FREQUENCY = 10 ** 12 / (10 * 10 ** 9 * 64)
                elif cio_gen is 1:
                    self.TICK_TO_FREQUENCY = 10 ** 12 / (20 * 10 ** 9 * 64)
                elif cio_gen is 2:
                    self.TICK_TO_FREQUENCY = 10 ** 12 / (10.3125 * 10 ** 9 * 64)
                else:
                    self.TICK_TO_FREQUENCY = 10 ** 12 / (20.625 * 10 ** 9 * 64)

                # standard eye width ps
                self.TICK_TO_FREQUENCY = (self.TICK_TO_FREQUENCY / (2 ** abs(3-vco_bsel_div_code_r)))
                print(f"New Div Code: {vco_bsel_div_code_r} Tick To Freq: {self.TICK_TO_FREQUENCY}")

                print(f" Mid X: {self.mid_x} Min X: {self.min_x} Max X: {self.max_x} Port: {port} Lane: {self.current_lane}")
                self.x_axis[port].append([])
                self.y_axis[port].append([])
                dclk_pos_decimal = self.gray2dec(self.get_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCO_CTRL89_RO'], 14, 7))

                print("Start by bringing Timing to Min-X For Eye Scan")
                for time_coord in range(dclk_pos_decimal, self.min_x - 1, -1):
                    print(f"Walking Back Time_Coord: {time_coord} Gray Value: {self.dec2gray(time_coord)}")
                    # Walk back to Pi (Time) value = min_x
                    self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL61'], 0, 7, self.dec2gray(time_coord))
                    time.sleep(10 / 1000000.0)
                    self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL61'], 8, 7, self.dec2gray(time_coord))
                    time.sleep(10 / 1000000.0)
                    print(f" Touching DCOPI 61 Bits 0->6 and 8->14 Decimal: {time_coord} Gray: {self.dec2gray(time_coord)}")

                print("Margin X-Axis")
                for time_coord in range(self.min_x, self.max_x + 1):
                    print(f"Setting X-Axis Coord Value: {time_coord} Gray Value: {self.dec2gray(time_coord)}")
                    self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL61'], 0, 7, self.dec2gray(time_coord))
                    time.sleep(10 / 1000000.0)
                    self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL61'], 8, 7, self.dec2gray(time_coord))
                    time.sleep(10 / 1000000.0)
                    print(f" Touching DCOPI 61 Bits 0->6 and 8->14 Decimal: {time_coord} Gray: {self.dec2gray(time_coord)}")
                    print(f"Scanning X-Axis Time Coord {time_coord} for Error")
                    self.x_axis[port][self.current_lane].append(self.capture_errors())

                    ### Additional Logging ###
                    deserializer_output = self.get_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_LPBK_CTRL_OBS4_RO'], 0, 20)
                    vco_bsel_range_code_r = self.get_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RX_TOP_CDR_CFG2'], 0, 2)
                    vco_bsel_div_code_r = self.get_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RX_TOP_CDR_CFG2'], 2, 2)
                    print(f"Setting X-Cord Decimal: {time_coord} Gray: {self.dec2gray(time_coord)} Deserializer Output: {deserializer_output} "
                          f"BSEL Range Code: {vco_bsel_range_code_r} BSEL Div Code: {vco_bsel_div_code_r}")

                print("Bring X Timing Coordinate Back to Middle for Voltage Scan")
                for time_coord in range(self.max_x, self.mid_x[port][self.current_lane] - 1, -1):
                    print(f"Walking Back Time_Coord: {time_coord} Gray Value: {self.dec2gray(time_coord)}")
                    # Walk back to Pi (Time) value = min_x
                    self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL61'], 0, 7, self.dec2gray(time_coord))
                    time.sleep(10 / 1000000.0)
                    self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DCOPI_CTRL61'], 8, 7, self.dec2gray(time_coord))
                    time.sleep(10 / 1000000.0)

                    print(f" Touching DCOPI 61 Bits 0->6 and 8->14 Decimal: {time_coord} Gray: {self.dec2gray(time_coord)}")

                for voltage in range(self.min_y, self.max_y + 1):
                    print(f"Scanning Y-Axis Voltage: {voltage} Dec to Grey: {self.dec2gray(abs(voltage))} INT2SA Vos Code: {self.int2sa_vos_code(voltage)}")
                    self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DESER_CTRL91'], 19, 6, self.int2sa_vos_code(voltage))
                    time.sleep(1 / 1000000.0)
                    self.y_axis[port][self.current_lane].append(self.capture_errors())

                print("Walk back h0dac")
                for voltage in range(self.max_y, self.mid_y-1, -1):
                    print(f"Scanning Y-Axis Voltage: {voltage} Dec to Grey: {self.dec2gray(abs(voltage))} INT2SA Vos Code: {self.int2sa_vos_code(voltage)}")
                    self.set_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_DESER_CTRL91'], 19, 6, self.int2sa_vos_code(voltage))
                    time.sleep(1 / 1000000.0)

                print(f"X-Axis Port: {port} Lane: {self.current_lane} Is: {self.x_axis[port][self.current_lane]}")
                print(f"Y-Axis Port: {port} Lane: {self.current_lane} Is: {self.y_axis[port][self.current_lane]}")

                # Pi - Time - X-Axis - Steps H/I
                # Vol - Voltage - Y-Axis - Steps A/G

                # Step A - Setup H0 Dac - CTRL91
                #   DFEH0DAC_GRAY[5] = sign bit - 0 for positive sign and 1 for negative sign
                #   DFEH0DAC_GRAY[4:0] = DEC2GRAY(Value)

                # Step F - Iterate h0dac
                # Decrerment H0 DAC
                # Write Rx SHIM Register RX_DESER_CTRL91
                # DFEH0DAC_GRAY[5] = Sign Bit
                # DFEh0DAC_GRAY[4:0] = DEC2Gray(Prev_value-1)

                # At the end of Y-axis
                # Write RRx SHIM Register RX DESER CTRL91.DFEH0DAC_GRAY[5:0] Walk Back to Mid Value for X-axis

                # Step H Iterate Pi Codes
                # Covered all values? AUS40PMA_RX_APB_OVERRIDE_REG_50
                # ECKL_POS_GRAY / ECLKB_POS_GRAY -> Once Done Walk Back to the middle

                # Otherwise Increment Err_Pos by 1
                # Write RX SHIM Register RXA DCOPI_CTRL61
                # ECLK_POS_GRAY = Dec2Gray(Prev + 1)
                # ECLKB_POS_GRAY = Dec2Gray(Prev + 1)

                # At the end of the testing clear all margining registers and retrain link

    def dump_registers(self, initial=True):
        """Dump Static Registers check adaptation converged values"""
        # Set below to make sure h0,h1 etc are read right
        # Convert CTLE and DFE to actual training parameters
        # Read out dclk, xclk, dclkb and xclkb positions
        if initial is True:
            self.mid_x = []
            self.mid_x_dclkb = []
            for port in range(0,len(self.root_port),1):
                self.port_num = self.root_port[port]
                self.mid_x.append([])
                self.mid_x_dclkb.append([])

                for lane in range(self.LANE_COUNT):
                    print(f"Tbtutil command output=nandfs:AppleInternal\Diags\Apps\TbtUtil.efi --read --rid {self.port_num} --port {lane+1}  --space 1 --offset 0x46")
                    output = run(
                        f"nandfs:AppleInternal\Diags\Apps\TbtUtil.efi --read --rid {self.port_num} --port {lane+1}  --space 1 --offset 0x46")

                    if "Success" in output:
                        for line in output.split("\n"):
                            try:
                                if "Register offset 0x46 Port" in line:
                                    txffe_value = int(line.split("Value ")[1], 16)
                                    self.log_msg(f"TxFFE_remote={txffe_value}")
                                    original_value = txffe_value
                                    txffe_value = f"{txffe_value:32b}"
                                    txffe_value = int(txffe_value[8:16], 2)
                                    print("txffe_remote=", hex(txffe_value))
                            except Exception as e:
                                print(f"Tried to parse TxFFE_remote but failed! {e}")
                                txffe_value = -1
                                original_value = -1
                    else:
                        print("Command failed to read register")
                        txffe_value = -1
                        original_value = -1

                    self.log_key(key=f"port:{self.port_num}_lane:{lane}_txffe_remote",
                                 value=txffe_value,
                                 units='')
                    self.log_key(key=f"port:{self.port_num}_lane:{lane}_txffe_remote_raw",
                                 value=original_value,
                                 units='')

                    self.select_lane_rp(lane)
                    self.mid_x[port].append([])
                    self.mid_x_dclkb[port].append([])
                    cs_ticks = self.gray2dec(self.get_bits((self.LANE_RP_OFFSET +
                                              AUS_LANE0_DEBUG['AFE_CTRL16_RO']),
                                                   7,
                                                   4))

                    self.log_key(key="port:{}_lane:{}_cs_ticks".format(
                        self.port_num,
                        self.current_lane),
                        value=cs_ticks,
                        units='ticks')

                    cs = CONVERSION_OFFSET_FACTORS["c"] + CONVERSION_MULTIPLICATION_FACTORS["c"] * cs_ticks
                    self.log_key(key="port:{}_lane:{}_cs".format(
                        self.port_num,
                        self.current_lane),
                        value=cs,
                        units='db')
                    rs_ticks = self.gray2dec(self.get_bits(self.LANE_RP_OFFSET +
                                             AUS_LANE0_DEBUG['AFE_CTRL16_RO'], 19,
                                                   4))
                    self.r = rs_ticks
                    self.c = cs_ticks
                    self.log_key(key="port:{}_lane:{}_rs_ticks".format(
                        self.port_num,
                        self.current_lane),
                        value=rs_ticks,
                        units='ticks')
                    rs = CONVERSION_OFFSET_FACTORS["r"] + CONVERSION_MULTIPLICATION_FACTORS["r"] * rs_ticks
                    self.log_key(key="port:{}_lane:{}_rs".format(
                        self.port_num,
                        self.current_lane),
                        value=rs,
                        units='db')

                    SMGR_seq_ptr = self.get_bits(self.LANE_RP_OFFSET +
                                                     AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_EQ_REQ_CFG4'], 28,
                                                     4)
                    SMGR_best_eng = self.get_bits(self.LANE_RP_OFFSET +
                                                     AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_EQ_REQ_CFG4'], 4,
                                                     4)

                    self.log_key(key="port:{}_lane:{}_SMGR_seq_ptr".format(
                        self.port_num,
                        self.current_lane),
                        value=SMGR_seq_ptr,
                        units='')

                    self.log_key(key="port:{}_lane:{}_SMGR_best_eng".format(
                        self.port_num,
                        self.current_lane),
                        value=SMGR_best_eng,
                        units='')

                    h0_smgr = CONVERSION_MULTIPLICATION_FACTORS["h0_smgr"] *  self.get_bits(self.LANE_RP_OFFSET + AUS_LANE0_DEBUG['APCIE_DOWN_AUS_LANE0_AUSPMA_RX_EQ_CFG13_EQ'], 0, 6)

                    self.log_key(key="port:{}_lane:{}_h0".format(
                        self.port_num,
                        self.current_lane),
                        value=h0_smgr,
                        units='mV')

                    dfeh5fb_en = self.get_bits(self.LANE_RP_OFFSET + AUS_LANE0_DEBUG['DFE_CTRL13_RO'], 28, 1)
                    dfeh4fb_en = self.get_bits(self.LANE_RP_OFFSET + AUS_LANE0_DEBUG['DFE_CTRL13_RO'], 22, 1)
                    dfeh3fb_en = self.get_bits(self.LANE_RP_OFFSET + AUS_LANE0_DEBUG['DFE_CTRL13_RO'], 21, 1)
                    dfeh2fb_en = self.get_bits(self.LANE_RP_OFFSET + AUS_LANE0_DEBUG['DFE_CTRL13_RO'], 20, 1)
                    dfeh1fb_en = self.get_bits(self.LANE_RP_OFFSET + AUS_LANE0_DEBUG['DFE_CTRL13_RO'], 19, 1)

                    self.log_key(key="port:{}_lane:{}_dfeh5fb_en".format(self.port_num, self.current_lane), value=dfeh5fb_en, units='')
                    self.log_key(key="port:{}_lane:{}_dfeh4fb_en".format(self.port_num, self.current_lane), value=dfeh4fb_en, units='')
                    self.log_key(key="port:{}_lane:{}_dfeh3fb_en".format(self.port_num, self.current_lane), value=dfeh3fb_en, units='')
                    self.log_key(key="port:{}_lane:{}_dfeh2fb_en".format(self.port_num, self.current_lane), value=dfeh2fb_en, units='')
                    self.log_key(key="port:{}_lane:{}_dfeh1fb_en".format(self.port_num, self.current_lane), value=dfeh1fb_en, units='')

                    h1 = CONVERSION_MULTIPLICATION_FACTORS["h1"] * \
                         self.gray2dec(self.get_bits(self.LANE_RP_OFFSET +
                                                     AUS_LANE0_DEBUG['DFE_CTRL13_RO'], 10,
                                                     5))
                    sign = self.gray2dec(self.get_bits(self.LANE_RP_OFFSET +
                                                       AUS_LANE0_DEBUG['DFE_CTRL13_RO'], 15,
                                                       1))
                    if sign is 1:
                        h1_sign = -1
                    else:
                        h1_sign = 1
                    h1 = h1_sign * h1
                    self.log_key(key="port:{}_lane:{}_h1".format(
                        self.port_num,
                        self.current_lane),
                        value=h1,
                        units='mV')
                    sign = self.get_bits(self.LANE_RP_OFFSET +
                                             AUS_LANE0_DEBUG['DCORING_CTRL712_RO'], 24,
                                             1)
                    if sign is 1:
                        h2_sign = -1
                    else:
                        h2_sign = 1
                    h2 = h2_sign * CONVERSION_MULTIPLICATION_FACTORS["h2"] * \
                         self.gray2dec(self.get_bits(self.LANE_RP_OFFSET +
                                                     AUS_LANE0_DEBUG['DCORING_CTRL712_RO'], 21,
                                                     3))
                    self.log_key(key="port:{}_lane:{}_h2".format(
                        self.port_num,
                        self.current_lane),
                        value=h2,
                        units='mV')
                    sign_2 = self.get_bits(self.LANE_RP_OFFSET +
                                             AUS_LANE0_DEBUG['DCORING_CTRL712_RO'], 29, 1)
                    if sign_2 is 1:
                        h3_sign = -1
                    else:
                        h3_sign = 1
                    h3 = h3_sign * CONVERSION_MULTIPLICATION_FACTORS["h3"] * \
                         self.gray2dec(self.get_bits(self.LANE_RP_OFFSET +
                                                     AUS_LANE0_DEBUG['DCORING_CTRL712_RO'], 26, 3))
                    self.log_key(key="port:{}_lane:{}_h3".format(
                        self.port_num,
                        self.current_lane),
                        value=h3,
                        units='mV')
                    sign_4 = self.get_bits(self.LANE_RP_OFFSET +
                                             AUS_LANE0_DEBUG['DFE_CTRL13_RO'], 3, 1)
                    if sign_4 is 1:
                        h4_sign = -1
                    else:
                        h4_sign = 1
                    h4 = h4_sign * CONVERSION_MULTIPLICATION_FACTORS["h4"] * \
                         self.gray2dec(self.get_bits(self.LANE_RP_OFFSET +
                                                     AUS_LANE0_DEBUG['DFE_CTRL13_RO'], 0, 3))
                    self.log_key(key="port:{}_lane:{}_h4".format(
                        self.port_num,
                        self.current_lane),
                        value=h4,
                        units='mV')
                    sign_5 = self.get_bits(self.LANE_RP_OFFSET +
                                             AUS_LANE0_DEBUG['DFE_CTRL13_RO'], 8, 1)
                    if sign_5 is 1:
                        h5_sign = -1
                    else:
                        h5_sign = 1

                    h5 = h5_sign * CONVERSION_MULTIPLICATION_FACTORS["h5"] * \
                         self.gray2dec(self.get_bits(self.LANE_RP_OFFSET +
                                                     AUS_LANE0_DEBUG['DFE_CTRL13_RO'], 5, 3))
                    self.log_key(key="port:{}_lane:{}_h5".format(
                        self.port_num,
                        self.current_lane),
                        value=h5,
                        units='mV')
                    aus_eq_ctrl_raw_cap_dclk_pos = self.get_bits(
                            self.LANE_RP_OFFSET +
                            AUS_LANE0_DEBUG['RXA_DCO_CTRL89_RO'],
                            14, 7)
                    print(f"Setting Mid X: {self.gray2dec(aus_eq_ctrl_raw_cap_dclk_pos)}")
                    self.mid_x[port][self.current_lane] = self.gray2dec(aus_eq_ctrl_raw_cap_dclk_pos)
                    self.log_key(key="port:{}_lane:{}_aus_eq_ctrl_raw_cap_dclk_pos_raw".format(
                        self.port_num,
                        self.current_lane),
                        value=self.gray2dec(aus_eq_ctrl_raw_cap_dclk_pos), units='ticks')

                    aus_eq_ctrl_raw_cap_dclkb_pos = self.get_bits(
                        self.LANE_RP_OFFSET +
                        AUS_LANE0_DEBUG['RXA_DCO_CTRL89_RO'],
                        21, 7)
                    self.mid_x_dclkb[port][self.current_lane] =self.gray2dec(aus_eq_ctrl_raw_cap_dclkb_pos)


                    self.log_key(key="port:{}_lane:{}_aus_eq_ctrl_raw_cap_dclkb_pos_raw".format(
                        self.port_num,
                        self.current_lane),
                        value=self.gray2dec(aus_eq_ctrl_raw_cap_dclkb_pos), units='ticks')

                    aus_eq_ctrl_raw_cap_xclk_pos = self.get_bits(
                        self.LANE_RP_OFFSET +
                        AUS_LANE0_DEBUG['DCOPI_CTRL10_RO'],
                        0, 7)
                    self.log_key(key="port:{}_lane:{}_aus_eq_ctrl_raw_cap_xclk_pos_raw".format(
                        self.port_num,
                        self.current_lane),
                        value=self.gray2dec(aus_eq_ctrl_raw_cap_xclk_pos), units='ticks')
                    aus_eq_ctrl_raw_cap_xclkb_pos = self.get_bits(
                        self.LANE_RP_OFFSET +
                        AUS_LANE0_DEBUG['DCOPI_CTRL10_RO'],
                        7, 7)
                    self.log_key(key="port:{}_lane:{}_aus_eq_ctrl_raw_cap_xclkb_pos_raw".format(
                        self.port_num,
                        self.current_lane),
                        value=self.gray2dec(aus_eq_ctrl_raw_cap_xclkb_pos), units='ticks')

                    for key, value in AUSPMA_LANE0_SMGR_registers.items():
                        register_value = self.get_bits(self.LANE_RP_OFFSET + value, 0, 32)

                        try:
                            self.log_key(key="port:{}_lane:{}_{}".format(
                                self.port_num,
                                self.current_lane,
                                key.replace("APCIE_DOWN_AUS_LANE0_AUSPMA_", "").lower()),
                                value=register_value, units='')
                        except Exception as e:
                            print("Unable to read register: ", key, " due to ", e)

        elif initial is False:
            print("Initial is False")

    def save_eye(self, port, lane, y_axis_eye, x_axis_eye):
        """Save the Eye Diagram"""
        f = open(self.log_path + f"\eyemargin_acio_p{port}_l{lane}.csv", "w")
        for y in range(0, len(y_axis_eye)):
            row_write = ""
            self.mid_y = int((self.min_y + self.max_y) / 2)
            if y != int(self.mid_y - self.min_y):
                for x in range(0, self.mid_x[port][self.current_lane] - self.min_x):
                    row_write += " ,"  # pad so that the column for axis is in the middle
                row_write += f"{y_axis_eye[y]},"
                for x in range(self.mid_x[port][self.current_lane] - self.min_x, self.max_x - self.min_x):
                    row_write += " ,"  # pad so that the column for axis is in the middle
            else:
                for value in x_axis_eye:
                    row_write += f"{value},"
            row_write = row_write + '\n'
            f.write(row_write)
            print(f" Row: {row_write}")

        f.close()

    def calculate_eye(self):
        """Calculate the Eye Diagram for axis only"""
        for port in range(0, len(self.root_port), 1):
            self.port_num =self.root_port[port]
            for lane in range(0, self.LANE_COUNT, 1):
                self.select_lane_rp(lane)
                print(f"Port Num: {port} Lane Count: {self.LANE_COUNT} Lane: {lane}")

                current_y_axis = self.y_axis[port][self.current_lane]
                current_x_axis = self.x_axis[port][self.current_lane]

                self.save_eye(port, lane, current_y_axis, current_x_axis)

                north, south, east, west = self.mid_y, self.mid_y, self.mid_x[port][self.current_lane], self.mid_x[port][self.current_lane]

                print(f"Y-axis: {current_y_axis} X-axis {current_x_axis}")

                for coord in range(self.mid_y, self.max_y + 1):
                    if current_y_axis[coord - self.min_y] == 0:
                        north = coord
                    if current_y_axis[coord - self.min_y] != 0:
                        break

                for coord in range(self.mid_y, self.min_y - 1, -1):
                    if current_y_axis[coord - self.min_y] == 0:
                        south = coord
                    if current_y_axis[coord - self.min_y] != 0:
                        break

                for coord in range(self.mid_x[port][self.current_lane], self.max_x + 1):
                    if current_x_axis[coord - self.min_x] == 0:
                        east = coord
                    if current_x_axis[coord - self.min_x] != 0:
                        break

                for coord in range(self.mid_x[port][self.current_lane], self.min_x - 1, -1):
                    if current_x_axis[coord - self.min_x] == 0:
                        west = coord
                    if current_x_axis[coord - self.min_x] != 0:
                        break

                print(f"North: {north} South: {south} East: {east} West: {west}")

                print(f"Port: {self.port_num} Lane: {self.current_lane}")

                cio_gen = self.get_bits(self.RP_OFFSET_ACIO + ACIO_TOP['ACIO_TOP_ACIO_GLOBAL_CFG0'], 0, 2)
                self.log_key(key="port:{}_lane:{}_rounded_nonrounded".format(
                    self.port_num,
                    self.current_lane),
                    value=cio_gen,
                    units='ticks')

                # if cio_gen is 0:
                #     self.TICK_TO_FREQUENCY = 10 ** 12 / (10 * 10 ** 9 * 64)
                # elif cio_gen is 1:
                #     self.TICK_TO_FREQUENCY = 10 ** 12 / (20 * 10 ** 9 * 64)
                # elif cio_gen is 2:
                #     self.TICK_TO_FREQUENCY = 10 ** 12 / (10.3125 * 10 ** 9 * 64)
                # else:
                #     self.TICK_TO_FREQUENCY = 10 ** 12 / (20.625 * 10 ** 9 * 64)

                height = north + abs(south)
                width = (east - west)
                print(f"Height: {height} Width: {width}")
                # EH equation: 0.75 (when referred to the CTLE output) * 7.16 * H0_range * (1+0.25*AFE_SPARE[0]) * 0.85 (this is a compression factor to represent worst case PVT) *Nb_of_steps
                # tick_to_voltage = 4.5645 * H0_range * (1+0.25*AFE_SPARE[0])
                # EH = tick_to_voltage * Number_ticks
                dfe_range_factor = self.get_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['DFE_CTRL13_RO'], 29, 2)
                if dfe_range_factor is 0:
                    dfeh0dac_range = 0.5
                elif dfe_range_factor is 1:
                    dfeh0dac_range = 1
                elif dfe_range_factor is 2:
                    dfeh0dac_range = 1.5
                else:
                    dfeh0dac_range = 2

                # RXA_ACCAP_CTRL5_RO.pma_rxa_afe_spare_0
                afe_spare_0 = self.get_bits(self.LANE_RP_OFFSET + AUSPMA_LANE0['RXA_ACCAP_CTRL5_RO'], 26, 1)
                print(f"dfe_range_factor: {dfe_range_factor} and afe_spare_0: {afe_spare_0}")

                left_ew_ps = self.TICK_TO_FREQUENCY * (self.mid_x[port][self.current_lane] - west)
                right_ew_ps = self.TICK_TO_FREQUENCY * (east - self.mid_x[port][self.current_lane])
                left_ew_dclkb_ps = self.TICK_TO_FREQUENCY * (self.mid_x_dclkb[port][self.current_lane] - west)
                right_ew_dclkb_ps = self.TICK_TO_FREQUENCY * (east - self.mid_x_dclkb[port][self.current_lane])

                min_ew_ps = min(left_ew_ps, right_ew_ps, left_ew_dclkb_ps, right_ew_dclkb_ps)

                if height >> 0 and width >> 0:
                    self.eye_height[self.current_lane] = self.TICK_TO_VOLTAGE * (1+0.25*afe_spare_0) * dfeh0dac_range * (north + abs(south))
                    self.eye_width[self.current_lane] = self.TICK_TO_FREQUENCY * (east - west)
                    self.eye_height_ticks[self.current_lane] = north + abs(south)
                    self.eye_width_ticks[self.current_lane] = east - west
                else:
                    if height >> 0:
                        self.eye_height[self.current_lane] = self.TICK_TO_VOLTAGE * (1+0.25*afe_spare_0) * dfeh0dac_range  * (north + abs(south))
                        self.eye_width[self.current_lane] = 0
                        self.eye_height_ticks[self.current_lane] = north + abs(south)
                        self.eye_width_ticks[self.current_lane] = 0
                    elif width >> 0:
                        self.eye_height[self.current_lane] = 0
                        self.eye_width[self.current_lane] = self.TICK_TO_FREQUENCY * (east - west)
                        self.eye_height_ticks[self.current_lane] = 0
                        self.eye_width_ticks[self.current_lane] = east - west
                    else:
                        self.eye_height[self.current_lane] = 0
                        self.eye_width[self.current_lane] = 0
                        self.eye_height_ticks[self.current_lane] = 0
                        self.eye_width_ticks[self.current_lane] = 0

                # Set R/C
                if self.doe is False:
                    self.r = 0
                    self.c = 0

                # Log to results file
                print("Log to Results File")
                self.log_key(key="port_{}_lane_{}_r{}_c{}_north_ticks".format(self.port_num,
                                                                              self.current_lane, self.r,
                                                                              self.c), value=north,
                             units='ticks')
                self.log_key(key="port_{}_lane_{}_r{}_c{}_south_ticks".format(self.port_num,
                                                                              self.current_lane, self.r,
                                                                              self.c), value=south,
                             units='ticks')
                self.log_key(key="port_{}_lane_{}_r{}_c{}_east_ticks".format(self.port_num,
                                                                             self.current_lane, self.r, self.c),
                             value=east, units='ticks')
                self.log_key(key="port_{}_lane_{}_r{}_c{}_west_ticks".format(self.port_num,
                                                                             self.current_lane, self.r, self.c),
                             value=west, units='ticks')
                self.log_key(key="port_{}_lane_{}_r{}_c{}_eh_mv".format(self.port_num,
                                                                        self.current_lane, self.r, self.c),
                             value=self.eye_height[self.current_lane], units='mV', upperlimit=self.eh_max,
                             lowerlimit=self.eh_min)
                self.log_key(key="port_{}_lane_{}_r{}_c{}_ew_ps".format(self.port_num,
                                                                        self.current_lane, self.r, self.c),
                             value=self.eye_width[self.current_lane], units='ps')
                self.log_key(key="port_{}_lane_{}_r{}_c{}_left_ew_ps".format(self.port_num,
                                                                             self.current_lane, self.r, self.c),
                             value=left_ew_ps, units='ps')
                self.log_key(key="port_{}_lane_{}_r{}_c{}_right_ew_ps".format(self.port_num,
                                                                              self.current_lane, self.r,
                                                                              self.c),
                             value=right_ew_ps, units='ps')
                self.log_key(key="port_{}_lane_{}_r{}_c{}_left_dclkb_ew_ps".format(self.port_num,
                                                                                   self.current_lane, self.r,
                                                                                   self.c),
                             value=left_ew_dclkb_ps, units='ps')
                self.log_key(key="port_{}_lane_{}_r{}_c{}_right_dclkb_ew_ps".format(self.port_num,
                                                                                    self.current_lane, self.r,
                                                                                    self.c),
                             value=right_ew_dclkb_ps, units='ps')
                self.log_key(key="port_{}_lane_{}_r{}_c{}_leftright_min_ew_ps".format(self.port_num,
                                                                                      self.current_lane, self.r,
                                                                                      self.c),
                             value=min_ew_ps, units='ps')
                self.log_key(key="port_{}_lane_{}_r{}_c{}_leftright_2min_ew_ps".format(self.port_num,
                                                                                       self.current_lane,
                                                                                       self.r, self.c),
                             upperlimit=self.ew_max,
                             lowerlimit=self.ew_min,
                             value=2 * min_ew_ps, units='ps')
                self.log_key(key="port_{}_lane_{}_r{}_c{}_eh_ticks".format(self.port_num,
                                                                           self.current_lane, self.r, self.c),
                             value=self.eye_height_ticks[self.current_lane],
                             units='ticks')
                self.log_key(key="port_{}_lane_{}_r{}_c{}_ew_ticks".format(self.port_num,
                                                                           self.current_lane, self.r, self.c),
                             value=self.eye_width_ticks[self.current_lane],
                             units='ticks')
                self.log_msg(
                    "port_{}_lane {}_r{}_c{}: north = {}, south = {}, east = {}, west = {}, ns = {}mV, ew = {}ps".format(
                        self.port_num,
                        self.current_lane,
                        self.r,
                        self.c,
                        north,
                        south,
                        east,
                        west,
                        self.eye_height[self.current_lane],
                        self.eye_width[self.current_lane]
                    ))
                print(
                    "port_{}_lane {}: north = {}, south = {}, east = {}, west = {}, ns = {}mV, ew = {}ps".format(
                        self.port_num,
                        self.current_lane,
                        north,
                        south,
                        east,
                        west,
                        self.eye_height[self.current_lane],
                        self.eye_width[self.current_lane]
                    ))

        if bool(self.doe) is True:
            run("device -k usbphy -e disable")

    def parse_margin_data(self):
        """Parse data to the necessary format(s)"""
        return 1

    def clean_up(self):
        """Clean up margining and reset the PHY"""
        if self.doe is True:
            run("device -k usbphy -e disable")
        else:
            return 1

    def log_key(self, key, value, units, upperlimit=None, lowerlimit=None, register_file=False, retry=False, fom_key=None, endpoint_speed=None):
        super().log_key(key=key, value=value, units=units, upperlimit=upperlimit, lowerlimit=lowerlimit,
                        register_file=register_file, retry=retry, fom_key=fom_key, endpoint_speed=self.gen_version)


    #
    # Helpers
    #
    def progress(self):
        """Progress in integer % increments"""
        self.log_msg("   {}%".format(self._fake_progress))
        return self._fake_progress

    def is_running(self):
        """Check if Margining is running"""
        return self.progress < 100

    def all_lanes_scanned(self, lane):
        """Check if all lanes scanned, Used for tools that need to have individual lanes scanned"""
        return 1

    def wait_for_finish(self):
        return 1
