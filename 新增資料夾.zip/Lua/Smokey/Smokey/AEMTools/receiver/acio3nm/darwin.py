"""Access for iEFI"""
from .base import AbstractReceiverMarginTool
import os
import re
__all__ = [
	"MarginTool"
]


class MarginTool(AbstractReceiverMarginTool):
	"""Margin Tool Instance"""

	def ensure_link(self):
		"""Check Link meets Speed / Width requirements"""

	def set_bits(self, address, start_bit, length, value):
		"""Read registers"""

	def get_bits(self, address, start_bit, length, value):
		"""Read registers"""

	def write_register(self, address, data):
		"""Write an offset"""
		os.system("mm -w 4 -n ..{}".format(address))

	def read_register(self, address):
		"""Read an offset"""
