# Apple Type C Consolidated IO (CIO)


### Margining Procedure (per https://seg-docs.csg.apple.com/projects/tonga/release/specs/Apple/AUSPMA/AUSPMA_Specification.pdf pg. 198):

1. START: Set err pos to start with edge

    a. Write RX SHIM register, rxa_dcopi_ctrl6:

        - pma_rxa_eclkb_pos_gray_ov = 1
        - pma_rxa_eclk_pos_gray_ov = 1
        - pma_rxa_eclkb_pos_gray = 0
        - pma_rxa_eclk_pos_gray = 0

2. STEP A: Setup h0 DAC = +31

    a. Write RX SHIM register, rxa_deser_ctrl9:

        - pma_rxa_dfeh0dac_gray[5] = sign bit, 0 for positive and 1 for negative
        - pma_rxa_df3h0dac_gray[4:0] = dec2gray(31) = 16

3. STEP B: Enable Error Accumulator

    a. Write RX EQ register, cfg46_eq:

        - en_err_acc = 1

4. STEP C: Wait for desired number of bits

    a. Example PCIe Gen3, one UI = 125ps, For 10^12 user should wait 125ps * 10 ^ 12 = 125 seconds

5. STEP D: Read number of errors

    a. Write RX EQ register, cfg46_eq:

        - cap_err_acc = 1

    b. Read RX EQ register, cfg44_eq:

        - error_acc field of cfg44_eq gives error count

    c. Write RX EQ register, cfg46_eq:

        - cap_err_acc = 0

6. STEP E: Disable error accumulator

    a. Write RX EQ register, cfg46_eq:

        - cap_err_acc = 0


7. STEP F: Check:

    a. If h0_dac != 31: and rxa_deser_ctrl9's def h0_dac != 40:  YES

        - GOTO STEP G

    b. Else:

        - GOTO STEP H

8. STEP G: Decrement h0 dac

    a. Write RX SHIM register, rxa_deser_ctrl9:

        - pma_rxa_dfeh0dac_gray[5] = sign bit, 0 for positive, 1 for negative
        - pma_rxa_dfeh0dac_gray[4:0] = dec2gray([previous h0 DAC] - 1)

    b. GOTO STEP B

9. STEP H: error_pos != 63

    a. IF rxa_dcopi_ctrl6:

        - pma_rxa_eclkb_pos_gray != 32
        - pma_rxa_eclk_pos_gray != 32
        - GOTO END

    b. Else:
        - GOTO STEP I

10. STEP I: Increment err_pos by 1

    a. Write RX SHIM register, rxa_dcopi_ctrl6:

            - pma_rxa_eclkb_pos_gray = dec2gray([eclk_pos]+1)
            - pma_rxa_eclk_pos_gray = dec2gray([eclk_pos]+1)

    b. GOTO STEP A

11. END

    a. Clear all registers which were written for eyescan and perform link retrain.