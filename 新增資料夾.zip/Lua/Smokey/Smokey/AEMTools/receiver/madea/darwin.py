"""Access for OS"""
import os
from .base import AbstractReceiverMarginTool
import time


__all__ = [
    "MarginTool"
]


class MarginTool(AbstractReceiverMarginTool):
    """Margin Tool Instance"""

    def dump_madea_info(self):
        """Dump Madea Information"""
        data = os.popen("madea -info").read()
        print("Dump Madea Information Data: {}".format(data))
        return data

    def read_register(self, device_index, offset, length):
        """Read registers"""
        # If there is no device index this isn't a J170 so we want to skip it along with Intel HW parameter
        # Add up to 5x retries for a register
        retry_count = 5
        data = ""
        for attempt in range(0, retry_count):
            print("Attempt: {} Device Index Read Register: {} Intel HW: {} Offset: {} Length: {}".format(attempt, device_index, self.intel_hw, offset, length))
            if self.intel_hw is False:
                if device_index is None:
                    data = os.popen("displayport -rdpcd {} {}".format(offset, length)).read()
                else:
                    data = os.popen("displayport -index {} -rdpcd {} {}".format(device_index, offset, length)).read()
            else:
                data = os.popen("pconctl -index {} -rdpcd {} {}".format(device_index, offset, length)).read()

            print("Data: {} Length: {}".format(data, len(data)))
            if len(data) > 0:
                data = data.strip("\n")
                data = data.split(":")[1]
                data = data.strip(" ")
                data = data.split(" ")
                break
            time.sleep(0.1) # sleep in between retries

        return data[0]

    def write_register(self, device_index, offset, length, values):
        """Write an offset"""
        print("Device Index Write Register: {} Intel HW: {} Offset: {} Length: {} Values: {}".format(device_index, self.intel_hw, offset, length, values))
        if self.intel_hw:
            output = os.system("pconctl -index {} -wdpcd {} {} {}".format(device_index, offset, length, values))
        else:
            if device_index is None:
                output = os.system("displayport -wdpcd {} {} {}".format(offset, length, values))
            else:
                output = os.system("displayport -index {} -wdpcd {} {} {}".format(device_index, offset, length, values))

        print("Output: {}".format(output))
        return output

    def read_register_bytes(self, device_index, offset, length):
        """Read registers"""
        retry_count = 5
        data = ""
        for attempt in range(0, retry_count):
            print("Attempt: {} Device Index Read Bytes: {} Intel HW: {} Offset: {} Length: {}".format(attempt, device_index, self.intel_hw, offset, length))
            if self.intel_hw is False:
                if device_index is None:
                    data = os.popen("displayport -rdpcd {} {}".format(offset, length)).read()
                else:
                    data = os.popen("displayport -index {} -rdpcd {} {}".format(device_index, offset, length)).read()
            else:
                data = os.popen("pconctl -index {} -rdpcd {} {}".format(device_index, offset, length)).read()

            print("Data: {}".format(data))
            data = data.strip("\n")
            data = data.split(":")[1]
            data = data.strip(" ")
            data = data.split(" ")
            if len(data) > 0:
                break
            time.sleep(1) # sleep in between retries

        return data