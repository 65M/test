# MegaChip Madea HDMI Device

### Device Capabilities:
  - X4 DP Link


### Margining Procedure (per rdar://problem/37626101):

1. Configure target lane, pattern type, test period and EQ setting by writing appropriate value to DPCD 0x30B – 0x30F

    a. DPCD 0x30B, lane number: write 0x0 for lane 0, 0x1 for lane 1 etc.

    b. DPCD 0x30C, 8b10b type: should be 0x0 for normal video

    c. DPCD 0x30D, Time unit (0x0: 1ms, 0x1: 10ms, 0x2: 100ms): 0x0 should be fine normally

    d. DPCD 0x30E, Test period: write 0x5 i.e. 5ms would be fine

2. Change EQ setting value to test by writing to DPCD 0x30F, value ranges from 0 to 7

3. Enable Bathtub curve test by writing 0xe0 to DPCD 0x510

4. Start bathtub curve testing by writing 0xee to DPCD 0x510

5. Confirm that the bathtub curve test is finished by reading 0x1 from DPCD 0x519

6. Read test result from DPCD 0x511 – 0x518. Results are also printed on serial console.

7. Disable bathtub function by writing 0xd1 to DPCD 0x510

8. To test with another EQ level on same lane, write desired value (0 to 7) to DPCD 0x30F and
repeat step 2-7.
