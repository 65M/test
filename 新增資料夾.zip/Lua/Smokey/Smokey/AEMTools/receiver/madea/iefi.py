"""Access for iEFI"""
from .base import AbstractReceiverMarginTool
from shell import run
import re
import time
__all__ = [
	"MarginTool"
]


class MarginTool(AbstractReceiverMarginTool):
	"""Margin Tool Instance"""

	def dump_madea_info(self):
		"""Dump Madea Information"""
		data = run("madea -info")
		print("Dump Madea Information Data: {}".format(data))
		return data

	def ensure_link(self):
		"""Check Link meets Speed / Width requirements"""
		run("device -k usbphy -e select 3;device -k usbphy -e enable dp;dptx --pick DPTX_EXT0;dptx --on;"
					 "dprepeater --on; dptx --route ATC3")
		time.sleep(3)
		device1 =run("dptx --sw_training 4 5.4")
		if "OK" in device1:
			pass
		else:
			device2 =run("dptx --sw_training 4 5.4")
			if "OK" in device2:
				pass
			else:
				raise Exception("Device does-not Exist, Please check if relevant")
		# link = run("dptx --on")
		# if "OK" in link:
		# 	return 1
		# else:
		# 	raise Exception("Link does-not Exist")

	def read_register(self, device_index, offset, length):
		"""Read registers"""
		aux_read_data = run("dptx --auxread dpcd {} {}".format(offset, length))
		if "OK" in aux_read_data:
			a = re.search(": ([\dx]*)", aux_read_data).group(0)
			return a.strip(":").split("x")[1]
		else:
			raise Exception("Read failed")

	def read_register_bytes(self, device_index, offset, length):
		"""Read registers"""
		aux_read_data = run("dptx --auxread dpcd {} {}".format(offset, length))
		if "OK" in aux_read_data:
			print(aux_read_data)
			print(aux_read_data.split(":")[2].strip("\r\nOK"))
			data = aux_read_data.split(":")[2].strip("\r\nOK")
			data = data.strip(" ")
			return data.split(" ")

		else:
			raise Exception("Read failed")

	def write_register(self, device_index, offset, length, values):
		"""Write an offset"""
		values = values if isinstance(values, list) else [values]
		for i in range(0, length):
			print(values[i])
			if(type(values[i])) is str:
				aux_write_data = run("dptx --auxwrite dpcd {} {}".format(hex(int(offset, 16)+i), hex(int(values[i], 16))))
				print((hex(int(offset, 16) + i)))
				m = self.read_register(device_index, (hex(int(offset, 16)+i)), 1)
				print(m)
			else:
				aux_write_data = run("dptx --auxwrite dpcd {} {}".format(hex(int(offset, 16)+i), hex(values[i])))
				print((hex(int(offset, 16) + i)))
				m = self.read_register(device_index, (hex(int(offset, 16)+i)), 1)
				print(m)
			if "OK" in aux_write_data:
				continue
			else:
				raise Exception("Write failed")

