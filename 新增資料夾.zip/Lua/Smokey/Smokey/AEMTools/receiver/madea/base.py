from .defines import *
from ..base import AbstractBaseMarginTool
from ..defines import MarginException
import re
__all__ = [
    "AbstractReceiverMarginTool"
]


class AbstractReceiverMarginTool(AbstractBaseMarginTool):
    """Generic Interface for Madea (HDMI) Margining"""
    LANE_COUNT = 4  # Number of Lanes
    dprx = 0
    def read_register(self, device_index, offset, length):
        """Read an offset"""

    def read_register_bytes(self, device_index, offset, length):
        """Read an offset"""

    def write_register(self, device_index, offset, length, values):
        """Write an offset"""

    def ensure_link(self):
        """Check Link meets Speed / Width requirements"""

    def dump_madea_info(self):
        """Dump Madea Info"""

    #
    # Helpers
    #
    def _select_space(self, space):
        """Configure the DPCD control register to do one of EQ settings:AA or CPTRIM values CC"""
        self.write_register(device_index=self.device_index, offset=DPCD_REG.BATHTUB_CTRL, values=space, length=1)

    def is_running(self):
        """Check if Margining is running"""
        return not(0x01 & int(
            self.read_register(device_index=self.device_index, offset=DPCD_REG.BATHTUB_STATUS, length=1)))

    #
    # Standard Methods
    #

    def disable_power_management(self):
        """Disable Power Management Modes"""
        pass  # Nothing to do

    def select_lane(self, lane):
        """Select a Lane"""
        self.current_lane = lane

    def setup_margining(self):
        """Configure the PHY and Setup Margining"""
        self.write_register(
            device_index=self.device_index,
            offset=EDID_OVERRIDE.REGISTER,
            length=1,
            values=EDID_OVERRIDE.VALUE
        )
        self.write_register(
            device_index=self.device_index,
            offset=BATHTUB_START.LANE_NUMBER,
            length=5,
            values=[
                self.current_lane,
                PATTERN_TYPE.ANSI8B10B,
                TIME_UNIT.ONE_MILL,
                0x05,  # 5ms
                EQ_SCAN[self.current_tool_cycle]  # EQ Setting scan
            ]
        )

    def start_margining(self):
        """Run Margining"""
        self.write_register(
            device_index=self.device_index,
            offset=DPCD_REG.BATHTUB_CTRL,
            length=1,
            values= BATHTUB_CTRL.START
        )
        self.read_register(
            device_index=self.device_index,
            offset=DPCD_REG.BATHTUB_CTRL,
            length=1,
        )

    def _read_register_for_space(self, space, length=1):
        """Select a space and return the respective register"""
        self._select_space(space)
        return self.read_register(device_index=self.device_index, offset=LANE_REGS[self.current_lane], length=length)

    def dump_registers(self, initial=False):
        """Dump  Registers"""
        print("Dumping Madea Information")
        self.dump_madea_info()
        print("Dumping Madea Information Done")

        if initial is True:
            # Dump Static Registers
            if self.current_lane in [0, 1]:
                val = self.read_register(
                    device_index=self.device_index,
                    offset=DPCD_REG.VOLTAGE_SWING_PRE_EMPHASIS_LANE_0_1,
                    length=1
                )
                print("val is {}".format(val))
                adjrequestbinary = '{:>08}'.format(str(bin(int(val, 16))[2:]))

            elif self.current_lane in [2, 3]:
                val = self.read_register(
                    device_index=self.device_index, offset=DPCD_REG.VOLTAGE_SWING_PRE_EMPHASIS_LANE_2_3, length=1)
                adjrequestbinary = '{:>08}'.format(str(bin(int(val, 16))[2:]))

            else:
                raise MarginException("Invalid Lane Number {}".format(self.current_lane))

            # Per Lane requested voltage swing and preemphasis values
            self.log_key(key="slot:{}_lane:{}_Adjust Request Voltage Swing".format(
                        self.device_index, self.current_lane),
                         value=DPCD_VOLTAGE_SWING_PRE_EMPHASIS[(
                               adjrequestbinary[DPCD_VOLTAGE_SWING_LOOKUP[self.current_lane]:
                                                DPCD_VOLTAGE_SWING_LOOKUP[self.current_lane]+2])], units="ticks")
            self.log_key(key="slot:{}_lane:{}_Adjust Request Pre Emphasis".format(
                        self.device_index,
                        self.current_lane),
                         value=DPCD_VOLTAGE_SWING_PRE_EMPHASIS[(
                               adjrequestbinary[DPCD_PREEMPHASIS_LOOKUP[self.current_lane]:
                                                DPCD_PREEMPHASIS_LOOKUP[self.current_lane]+2])], units="ticks")

            # Per Lane Gain and Boost
            self.dprx = self._read_register_for_space(space=BATHTUB_CTRL.EQ_SETTINGS)
            self.log_key(key="slot:{}_lane:{}_eq_trained".format(self.device_index, self.current_lane), value=int(self.dprx), units="ticks")
            val = DPCD_GAIN_BOOST[self.dprx]
            self.log_key(key="slot:{}_lane:{}_dc-gain".format(self.device_index, self.current_lane), value=val[0], units="ticks")
            self.log_key(key="slot:{}_lane:{}_boost".format(self.device_index, self.current_lane), value=val[1], units="ticks")

            # cptrim settings
            cptrimsetting = self._read_register_for_space(space=BATHTUB_CTRL.CURRENT_CPTRIM)
            self.log_key(key="slot:{}_lane:{}_Cptrim".format(
                        self.device_index,
                        self.current_lane),
                        value=int(cptrimsetting,16), units="ticks"
                        )

            # Per Lane EQ Bypass
            val = self._read_register_for_space(space=BATHTUB_CTRL.EQ_BYPASS)
            self.log_key(key="slot:{}_lane:{}_eq_bypass".format(
                         self.device_index,
                         self.current_lane),
                         value=int(val,16), units="ticks")

    def parse_margin_data(self):
        """Parse data to the necessary format(s)"""
        data = self.read_register_bytes(
                                  device_index=self.device_index,
                                  offset=DPCD_REG.BATHTUB_RESULT0,
                                  length=DPCD_REG.BATHTUB_RESULTCOUNT)
        self.log_msg(
            "Slot:{}_Lane:{}_EQ:{}_data:{}".format(
                self.device_index,
                self.current_lane,
                EQ_SCAN[self.current_tool_cycle].split("x")[1], data))
        return data

    def clean_up(self):
        """Clean up margining and reset the PHY"""
        print("Madea Cleanup")
        self.write_register(device_index=self.device_index, offset=DPCD_REG.BATHTUB_CTRL, length=1,
                            values=BATHTUB_CTRL.DISABLE)
        self.dump_madea_info()

    def calculate_eye(self):
        """Calculate the Eye Diagram"""
        # Get the data for the lane (list of margin values)
        data = self.parse_margin_data()
        str_temp_binary = ""
        for i in range(len(data)-1, -1, -1):
            str_temp_binary += ('{:>08}'.format(str(bin(int(data[i], 16))[2:])))
        self.log_msg("Slot:{}_Lane:{}_EQ:{}_eye:{}".format(
            self.device_index,
            self.current_lane,
            EQ_SCAN[self.current_tool_cycle].split("x")[1],
            str_temp_binary
        ))
        s = []

        i=0
        while i < len(str_temp_binary):
            if str_temp_binary[i] == "0":
                data = re.match(r'0+',str_temp_binary[i:] ).group(0)
                count = len(data)
                i = i + count
                s.append(count)
            else:
                i=i+1

        if len(s) == 0:
            raise Exception("Len of s: {} is 0, implies fully closed eye".format(s))

        if int(self.dprx) == int(EQ_SCAN[self.current_tool_cycle].split("x")[1]):
            self.log_key(key="Slot:{}_Lane:{}_TickCount_trained".format(self.device_index, self.current_lane,
                                                                      EQ_SCAN[self.current_tool_cycle].split("x")[1]),
                         value=max(s),
                         lowerlimit = self.ew_min,
                         upperlimit= None,
                         units="ticks")
        # rdar://problem/75081283 if max_ticks empty
        self.log_key(key="Slot:{}_Lane:{}_EQ:{}_TickCount".format(self.device_index, self.current_lane,
                                                                  EQ_SCAN[self.current_tool_cycle].split("x")[1]),
                     value=max(s), units="ticks")

    #
    # Execution Flow
    #
    def set_adaptation(self, figure_of_merit):
        """Set the Adaptation Type (if applicable)"""

    def apply_settings(self, retrain=True):
        """Apply EQ and other settings, retrain (if applicable)"""

    def configure_phy(self):
        """Configure the PHY Settings, Overrides, ECO, etc"""

    def all_lanes_scanned(self, lane):
        """Check if all lanes scanned, Used for tools that need to have individual lanes scanned"""
        if self.LANE_COUNT is lane:
            return 1
        else:
            return 0

    def progress(self):
        """Progress in integer % increments"""

    def set_traffic_type(self, traffic_type):
        """Select the Traffic type (Live, PRBS, etc)"""


