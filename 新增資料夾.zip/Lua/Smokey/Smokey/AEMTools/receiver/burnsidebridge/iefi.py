"""Access for iEFI"""
from .base import AbstractReceiverMarginTool
from shell import run
import re
__all__ = [
	"MarginTool"
]


class MarginTool(AbstractReceiverMarginTool):
	"""Margin Tool Instance"""

	def ensure_link(self):
		"""Check Link meets Speed / Width requirements"""
		run("device -k usbphy -e select 1")
		run("device -k usbphy -e enable cio")


