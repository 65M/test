from .base import ReceiverMarginTool

__all__ = [
	"MarginTool"
]


def n_lsb(x):
	return (1 << x) - 1


def n_to_m(n, m):
	return n_lsb(n) & ~ n_lsb(m)


class MarginTool(ReceiverMarginTool):
	"""Margin Tool Instance"""

	def set_register(self, address, value):
		"""Set Register to a value"""
		self.seq_log.debug("Writing Register {} to value {}".format(address, value))

	def get_register(self, address):
		"""Get a Register value"""
		value = 0
		self.seq_log.debug("Read Register {} with value {}".format(address, value))
		return value

	def set_bits(self, address, start_bit, length, value):
		""" Modify bits of certain range, end_bit is always greater than start_bit"""
		end_bit = start_bit + length
		return (address & ~n_to_m(end_bit, start_bit)) | (value << start_bit)
