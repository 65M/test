#!/usr/bin/env python3
import sys
import argparse
import importlib
import os
from os import environ
from receiver.defines import *
import re

# {Date Last Update MM / DD / YY}.{Iteration From That Day}
__version__ = "Mar.20.2023"
# Numeric version
__version_numeric__ = 1.2
# git ToT
__git_commit__ = "089eb0a9c9afdf673f16b1efa088cd519172de4b"

__all__ = [
    "run_margining"
]


def run_margining(input_variables=None):
    # Get the End Points
    if input_variables is None:
        input_variables = []

    print("Running AEMTools version {}".format(__version__))

    # Determine the Platform
    if sys.platform == "darwin":
        env = "darwin"
    elif sys.platform.startswith('uefi'):
        from shell import run
        env = "iefi"
    elif sys.platform.startswith("linux"):
        env = "linux"
    else:
        raise Exception("Unknown system environment, {}".format(sys.platform))

    letter_code = "-1"
    board_rev = 0

    if env == "iefi":
        try:
            data = run("soc --properties model")
            soc_code = data.split("\r\n")[1].split(": ")[1].strip("\r\n")
            ver = run("system")
            product_code = re.search("model-name.*([A-Za-z]{1}[\d]+).*", ver).group(1)
            letter_code = re.search("[A-Za-z]{1}[\d]+[\w+]", ver).group(0).upper().strip(product_code.upper())
            print("Using Product Code: {} Letter Code: {}".format(product_code.upper() + "_defines",
                                                                  letter_code))
            try:
                params = importlib.import_module(product_code.upper() + "_defines")
            except ImportError:
                try:
                    if "J5" or "j5" in product_code:
                        params = importlib.import_module("DUT_defines")
                    else:
                        params = importlib.import_module(product_code.lower() + "_defines")
                except ImportError:
                    # ToDo:  Do we want to make DUT_defines.py the default, or raise error.
                    raise Exception(
                        "Unable to find defines file for product {}".format(product_code.lower() + "_defines"))

            board_id = run("boardrev")
            for line in board_id.split("\n"):
                revision = re.search(r".*Board Revision: 0x([0-9A-Fa-f]+).*", line)
                if revision:
                    board_rev = int(revision.group(1), 16)

            print(f"Found Board Rev: {board_rev}")

        except ImportError:
            raise Exception("Something went wrong loading defines")

    parser = argparse.ArgumentParser(description="Apple Eye Margin Tool")

    # Required Arguments
    parser.add_argument('--soc_code', default=None, help="forces the soc_code")
    parser.add_argument('--product_code', default=None, help="forces the product_code")
    parser.add_argument('--special_pdca_format', dest='special_pdca_format', action="store_true", default=False,
                        help="Activates a different way for pdca formats ")
    parser.add_argument('--r_value', default=None, help="forces the R value")
    parser.add_argument('--c_value', default=None, help="forces the C value")
    parser.add_argument('--error_mask', type=int, default=0, help="Sets the error mask: 0-composite, 1-odd, 2-even")
    parser.add_argument('--host_name', default=None, help="forces the host_name")
    parser.add_argument('--port', default=None, help="forces the port")
    parser.add_argument('--debug', dest='debug', action='store_true', default=False, help="Enable debug logging")
    parser.add_argument('--end_point', dest='end_point', default=None, help="End points, valid options: {}")
    parser.add_argument('--result_path', dest='result_path', type=str, default=None,
                        help="Location for the final result")
    parser.add_argument('--additional_pdca', dest='additional_pdca', type=str, default=None,
                        help="File name for additional pdca")
    parser.add_argument('--current_cycle', dest='current_cycle', type=int, default=0,
                        help="The Current cycle number (when rebooting)")
    parser.add_argument('--device', dest='device', type=str, default=None,
                        help="Device name to perform the margining across, "
                             "if not specified OS based will be native")
    parser.add_argument('--device_index', dest='device_index', type=int, default=None,
                        help="The device index incase of multiple devices")
    parser.add_argument('--ports_location', dest='ports_location', type=int, default=None,
                        help="The ports location incase of multiple groups of ports")
    parser.add_argument('--lane_no', dest='lane_no', type=int, default=None,
                        help="To specify the active lane in cases where dormant lanes exist")
    parser.add_argument('--plist', dest='plist', type=int, default=True,
                        help="To deicde if you want to write pdca plist")
    parser.add_argument('--doe', dest='doe', type=bool, default=False,
                        help="Do you need to do a DOE?")
    parser.add_argument('--doe_no', dest='doe_no', type=int, default=None,
                        help="doe number")
    parser.add_argument('--ctle_sweep', dest='ctle_sweep', type=int, default=False,
                        help="ctle_sweep")
    parser.add_argument('--user_axis_only', dest='user_axis_only', type=str, default=None,
                        help="User input to kickoff axis only margining")
    parser.add_argument('--dfe_off', dest='dfe_off', type=int, default=False,
                        help="True if you want to turn off DFE")
    parser.add_argument('--depth', dest='depth', type=str, default="5", help="RT-13 Margining Depth Parameter")
    parser.add_argument('--phy', dest='phy', type=str, default=None, help="PHY To Run Margining On, SFP or CFP")
    parser.add_argument('--rt13_lane', dest='rt13_lane', type=int, default=None,
                        help="RT-13 Lane to Run Margining On, 0 or 1")
    parser.add_argument('--rt13_initialize', dest='rt13_initialize', type=bool, default=False,
                        help="RT-13 Initialize Margining Registers")
    parser.add_argument('--rt13_verify', dest='rt13_verify', action="store_false", default=False,
                        help="RT-13 Verify Margining Registers")
    parser.add_argument('--rt13_dfe', dest='rt13_dfe', type=bool, default=True, help="RT-13 DFE Enablement")
    parser.add_argument('--gen_version', dest='gen_version', type=str, default=None, help="Gen Version")
    parser.add_argument('--microsemi_endpoint', dest='microsemi_endpoint', type=str, default=None,
                        help="Microsemi Endpoint")
    parser.add_argument('--pfx84', dest='pfx84', type=bool, default=False, help="84-Lane Microsemi Switch")
    parser.add_argument('--bio_moly', dest='bio_moly', type=bool, default=False, help="Bio Moly Card Attached")
    parser.add_argument('--moly_index_list', dest='moly_index_list', type=str, default=None,
                        help="List of Moly Index Cards to Margin")
    parser.add_argument('--port_list', dest='port_list', type=list, default=None,
                        help="List of ATC ports to run RT-13 margining")
    parser.add_argument('--swing', dest='swing', type=int, default=None, help="Camera Swing Level")
    parser.add_argument('--dump_h0', dest='dump_h0', type=bool, default=False, help="Grab H0 Register")
    parser.add_argument('--prbs_loopback', dest='prbs_loopback', type=bool, default=False,
                        help="Enable PRBS Loopback")
    parser.add_argument('--prbs_ports', dest='prbs_ports', type=list, default=None,
                        help="PRBS Loopback Ports, Rx First, Tx Second")
    parser.add_argument('--verify_linkrate', dest='verify_linkrate', type=bool, default=True,
                        help="Verify Link Rate for Camera")

    if len(input_variables) == 0:
        args = parser.parse_args()
    else:
        args = parser.parse_args(input_variables)

    if args.soc_code is None and args.product_code is None and env == "darwin":
        try:
            data = os.popen("smcif -kd RPlt")
            ver = data.read()
            product_code = re.search("([A-Za-z]{1}[\d]+)+", ver)
            letter_code = re.search("[A-Za-z]{1}[\d]+[\w+]", ver).group(0).upper().strip(product_code.upper())
            print("Using Product Code: {} Letter Code: {}".format(product_code.upper() + "_defines",
                                                                  letter_code))

            soc_code = None  # pls change to OS soc code version read
            params = importlib.import_module(product_code.upper() + "_defines")
        except ImportError:
            data = os.popen("smcif -kd RPlt")
            ver = data.read()
            product_code = re.search("[A-Za-z]{1}[\d]+", ver)
            raise Exception(
                "Unable to find defines file for product {}".format(product_code))
    elif args.soc_code is not None and args.product_code is not None:
        soc_code = args.soc_code
        product_code = args.product_code
        params = importlib.import_module(args.product_code.upper() + "_defines")

    end_points = endpoints()

    # Get the Traffic types
    traffics = traffic_types()

    print(f"Manual Input Variables: {input_variables}")

    # Configurations
    if args.device is None:
        defines_params = args.end_point
    elif args.device_index is not None:
        defines_params = args.end_point + str(args.device_index)
    else:
        defines_params = args.end_point + args.device
    parser.add_argument('--root_port', dest='root_port', type=int, default=
                        params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].root_port
                        if args.device_index is None else [int(args.device_index)]
                        , help="Root port where valid")
    parser.add_argument('--axis_only', dest='axis_only', action='store_true',
                        default=params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].axis_only,
                        help="Axis only Scan, default is Full scan")
    parser.add_argument('--tool_cycle_count', dest='tool_cycle_count', type=int,
                        default=params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].tool_cycle_count,
                        help="The number of tool cycle to run, Default is 1 cycle")
    parser.add_argument('--cycles', dest='cycles', type=int,
                        default=params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].cycles,
                        help="The total number of cycles to run, Default is 1 cycle")
    parser.add_argument('--min_x', dest='min_x', type=int,
                        default=params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].min_x,
                        help="Minimum X (tick), default is Full")
    parser.add_argument('--max_x', dest='max_x', type=int,
                        default=params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].max_x,
                        help="Maximum X (tick), default is Full")
    parser.add_argument('--min_y', dest='min_y', type=int,
                        default=params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].min_y,
                        help="Minimum Y (tick), default is Full")
    parser.add_argument('--max_y', dest='max_y', type=int,
                        default=params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].max_y,
                        help="Maximum Y (tick), default is Full")
    parser.add_argument('--step_x', dest='step_x', type=int,
                        default=params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].step_x,
                        help="Step size of X axis, default to tool step")
    parser.add_argument('--step_y', dest='step_y', type=int,
                        default=params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].step_y,
                        help="Step size of Y axis, default to tool step")
    parser.add_argument('--duration_ms', dest='duration_ms', type=int,
                        default=params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].duration_ms,
                        help="Duration time (s) of each coordinate measurement")
    parser.add_argument('--timeout_s', dest='timeout_s', type=int,
                        default=params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].timeout_s,
                        help="Timeout to finish measurement (s) of each coordinate measurement")
    parser.add_argument('--delay_us', dest='delay_us', type=int,
                        default=params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].delay_us,
                        help="Delay time (us) between measurements of each coordinate measurement")
    parser.add_argument('--threshold', dest='threshold', type=int,
                        default=params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].threshold,
                        help="Bit error Threshold to indicate good / bad, default is zero")
    parser.add_argument('--adaptations', dest='adaptations', type=str,
                        default=params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].
                        adaptations[int(args.doe_no)] if bool(args.doe) is True and args.doe_no is not None
                        else params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].
                        adaptations if bool(args.doe) is True and args.doe_no is None
                        else None, help="Comma seperated list of adaption types (ie. 0,1,2)")
    parser.add_argument('--traffic', dest='traffic', type=str,
                        default=params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].traffic,
                        help="Traffic Type, valid options: {}".format(", ".join(traffics)))
    parser.add_argument('--vendor_specific', dest='vendor_specific', type=str,
                        default=params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].vendor_specific,
                        help="Vendor specifications")
    parser.add_argument('--gen_width', dest='gen_width', type=int,
                        default=params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].gen_width,
                        help="Gen width where relevant")
    parser.add_argument('--gen_speed', dest='gen_speed', type=str,
                        default=params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].gen_speed,
                        help="Gen speed where relevant")
    parser.add_argument('--module', dest='module', type=str,
                        default=params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].module,
                        help="Module name for pcie case")
    parser.add_argument('--tick_voltage', dest='tick_voltage', type=int,
                        default=params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].tick_voltage,
                        help="Tick Voltage")
    parser.add_argument('--tick_frequency', dest='tick_frequency', type=int,
                        default=params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].tick_frequency,
                        help="Tick frequency")

    # Limits
    try:
        parser.add_argument('-eh_min', dest='eh_min', type=int, default=
                            params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].eh_min if
                            params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].spec_check is True else None,
                            help="Required min Eye Height (tick), default is disable Check")
    except AttributeError:
        parser.add_argument('-eh_min', dest='eh_min', type=int, default=None,
                            help="Required min Eye Height (tick), default is disable Check")

    try:
        parser.add_argument("--por_adaptations", dest='por_adaptations', nargs='+',
                            default=params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].por_adaptations,
                            help="Used only when adaptations are provided. If the adaptation is inside of this list, then eye values will be checked")
    except AttributeError:
        parser.add_argument("--por_adaptations", dest='por_adaptations', nargs='+',
                            default=[],
                            help="Used only when adaptations are provided. If the adaptation is inside of this list, then eye values will be checked")

    try:
        parser.add_argument('-eh_max', dest='eh_max', type=int, default=
                        params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].eh_max if
                        params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].spec_check is True else None,
                        help="Required min Eye Height (tick), default is disable Check")
    except AttributeError:
        parser.add_argument('-eh_max', dest='eh_max', type=int, default=None,
                            help="Required min Eye Height (tick), default is disable Check")

    try:
        parser.add_argument('-ew_min', dest='ew_min', type=int,
                        default=params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].ew_min if
                        params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].spec_check is True else None,
                        help="Required min Eye Width (tick), default is disable Check")
    except AttributeError:
        parser.add_argument('-ew_min', dest='ew_min', type=int,
                            default=None,
                            help="Required min Eye Width (tick), default is disable Check")

    try:
        parser.add_argument('-ew_max', dest='ew_max', type=int,
                        default=params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].ew_max if
                        params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].spec_check is True else None,
                        help="Required max Eye Width (tick), default is disable Check")
    except AttributeError:
        parser.add_argument('-ew_max', dest='ew_max', type=int,
                            default=None,
                            help="Required max Eye Width (tick), default is disable Check")

    # Additional Non-Guaranteed Attribute Arguments
    try:
        parser.add_argument('--camera_linkrate', dest='camera_linkrate', type=list,
                            default=params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].camera_linkrate,
                            help="Camera Link Rate")
    except AttributeError:
        print("No Optional Camera Link Rate")
        parser.add_argument('--camera_linkrate', dest='camera_linkrate', type=int, default=None,
                            help="Camera Link Rate")

    try:
        parser.add_argument('--port_location_breakdown', dest='port_location_breakdown', type=list,
                            default=params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].port_location_breakdown,
                            help="Port Location Breakdown")
    except AttributeError:
        print("No Optional Port Location Breakdown")
        parser.add_argument('--port_location_breakdown', dest='port_location_breakdown', type=list, default=None,
                            help="Port Location Breakdown")

    try:
        parser.add_argument('--die_location', dest='die_location', type=dict,
                            default=params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].die_location,
                            help="Die Location of Different ATC ports")
    except AttributeError:
        parser.add_argument('--die_location', dest='die_location', type=dict, default=None,
                            help="Die Location of Different ATC ports")

    try:
        parser.add_argument('--disable_aspm_val', dest='disable_aspm_val', type=list, default=
        params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].disable_aspm_val,
                            help="AQC 113 Disable ASPM Values")
    except AttributeError:
        parser.add_argument('--disable_aspm_val', dest='disable_aspm_val', type=list, default=None,
                            help="AQC 113 Disable ASPM Values")

    try:
        parser.add_argument('--enable_aspm_val', dest='enable_aspm_val', type=list, default=
        params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].enable_aspm_val,
                            help="AQC 113 Enable ASPM Values")
    except AttributeError:
        parser.add_argument('--enable_aspm_val', dest='enable_aspm_val', type=list, default=None,
                            help="AQC 113 Enable ASPM Values")

    try:
        parser.add_argument('--folder_name', dest='folder_name', type=str, default=
        params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].folder_name,
                            help="AQC 113 Folder Name")
    except AttributeError:
        parser.add_argument('--folder_name', dest='folder_name', type=str, default=None,
                            help="AQC 113 Folder Name")

    try:
        parser.add_argument('--en_endpoints', dest='en_endpoints', type=list, default=
        params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].en_endpoints,
                            help="AQC 113 EN Endpoints")
    except AttributeError:
        parser.add_argument('--en_endpoints', dest='en_endpoints', type=list, default=None,
                            help="AQC 113 EN Endpoints")

    try:
        parser.add_argument('--controller_count', dest='controller_count', type=int, default=
        params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].controller_count,
                            help="AQC 113 Number Controllers")
    except AttributeError:
        parser.add_argument('--controller_count', dest='controller_count', type=int, default=None,
                            help="AQC 113 Number Controllers")

    try:
        parser.add_argument('--controller_numbers', dest='controller_numbers', type=list, default=
        params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].controller_numbers,
                            help="AQC113 Controller Numbers")
    except AttributeError:
        parser.add_argument('--controller_numbers', dest='controller_numbers', type=list, default=None,
                            help="AQC113 Controller Numbers")

    try:
        parser.add_argument('--link_status_endpoints', dest='link_status_endpoints', type=list, default=
        params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].link_status_endpoints,
                            help="AQC113 Link Status Endpoints")
    except AttributeError:
        parser.add_argument('--link_status_endpoints', dest='link_status_endpoints', type=list, default=None,
                            help="AQC113 Link Status Endpoints")

    try:
        parser.add_argument('--lane_count', dest='lane_count', type=int, default=
        params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].lane_count,
                            help="AQC113 Lane Count Endpoints")
    except AttributeError:
        parser.add_argument('--lane_count', dest='lane_count', type=list, default=None,
                            help="AQC113 Lane Count Endpoints")

    try:
        parser.add_argument('--max_pcie_lanes', dest='max_pcie_lanes', type=int, default=
        params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].max_pcie_lanes,
                            help="ASMedia Max PCIE Lanes")
    except AttributeError:
        parser.add_argument('--max_pcie_lanes', dest='max_pcie_lanes', type=int, default=None,
                            help="ASMedia Max PCIE Lanes")

    try:
        parser.add_argument('--rt13_layout', dest='rt13_layout', type=int, default=
        params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].rt13_layout,
                            help="RT13 Layout")
    except AttributeError:
        parser.add_argument('--rt13_layout', dest='rt13_layout', type=int, default=None,
                            help="RT13 Layout")

    try:
        parser.add_argument('--atc_port', dest='atc_port', type=list, default=
        params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].atc_port,
                            help="ATC Port")
    except AttributeError:
        parser.add_argument('--atc_port', dest='atc_port', type=list, default=None,
                            help="ATC Port")

    try:
        parser.add_argument('--route', dest='route', type=str, default=
        params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].route,
                            help="Cobra Route")
    except AttributeError:
        parser.add_argument('--route', dest='route', type=str, default=None,
                            help="Cobra Route")

    try:
        parser.add_argument('--load_fw', dest='load_fw', type=bool, default=
        params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].load_fw,
                            help="Load FW")
    except AttributeError:
        parser.add_argument('--load_fw', dest='load_fw', type=bool, default=False,
                            help="Load FW")

    try:
        parser.add_argument('--intel_hw', dest='intel_hw', type=bool, default=
        params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].intel_hw,
                            help="Is The DUT Intel or Apple Silicon")
    except AttributeError:
        parser.add_argument('--intel_hw', dest='intel_hw', type=bool, default=False,
                            help="Is The DUT Intel or Apple Silicon")

    try:
        parser.add_argument('--port_enablement', dest='port_enablement', type=bool, default=
        params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].port_enablement,
                            help="Ports to Enable")
    except AttributeError:
        parser.add_argument('--port_enablement', dest='port_enablement', type=bool, default=False,
                            help="Ports to Enable")

    try:
        parser.add_argument('--camera_voltage_register', dest='camera_voltage_register', type=str, default=
        params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].camera_voltage_register,
                            help="What Register To Ues For Camera Voltage Level")
    except AttributeError:
        parser.add_argument('--camera_voltage_register', dest='camera_voltage_register', type=str, default=[0],
                            help="What Register To Ues For Camera Voltage Level")

    try:
        parser.add_argument('--camera_voltage_translation', dest='camera_voltage_translation', type=list, default=
        params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].camera_voltage_translation,
                            help="Camera Voltage Translation")
    except AttributeError:
        parser.add_argument('--camera_voltage_translation', dest='camera_voltage_translation', type=str, default=[0],
                            help="Camera Voltage Translation")
    try:
        parser.add_argument('--pcie_uses_oss', dest='pcie_uses_oss', type=str,
                            default=params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].uses_oss,
                            help="If enabled, will use GP0 to turn on GP endpoint. Otherwise will use the root_port to turn on endpoint")
    except AttributeError:
        parser.add_argument('--pcie_uses_oss', dest='pcie_uses_oss', type=str,
                            default=False,
                            help="If enabled, will use GP0 to turn on GP endpoint. Otherwise will use the root_port to turn on endpoint")
    try:
        parser.add_argument('--pcie_port', dest='pcie_port', type=str,
                            default=params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].pcie_port,
                            help="Which port number to use for pcie --pick")
    except AttributeError:
        parser.add_argument('--pcie_port', dest='pcie_port', type=str,
                            default=None,
                            help="Which port number to use for pcie --pick")

    try:
        parser.add_argument('--pcie_startup', dest='pcie_startup', type=str,
                            default=params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].pcie_startup,
                            help="Uses 'pcie --set setup_eyescan true' to setup auspma margining registers")
    except AttributeError:
        parser.add_argument('--pcie_startup', dest='pcie_startup', type=str,
                            default=False,
                            help="Uses 'pcie --set setup_eyescan true' to setup auspma margining registers")

    try:
        parser.add_argument('--pcie_gpio', dest='pcie_gpio', type=str,
                            default=params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].pcie_gpio,
                            help="If provided uses the gpio pin to turn on the device")
    except AttributeError:
        parser.add_argument('--pcie_gpio', dest='pcie_gpio', type=str,
                            default=None,
                            help="If provided uses the gpio pin to turn on the device")


    try:
        parser.add_argument('--score', dest='score', type=bool, default=
        params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].score,
                            help="Minimum Score")
    except AttributeError:
        parser.add_argument('--score', dest='score', type=bool, default=False,
                            help="Minimum Score")

    try:
        parser.add_argument('--pcie_lane_count', dest='pcie_lane_count', type=bool, default=
        params.params_data.CONVERSION_PARAMS_DATA[0][defines_params]["func"].pcie_lane_count,
                            help="PCIe Lane Count")
    except AttributeError:
        parser.add_argument('--pcie_lane_count', dest='pcie_lane_count', type=bool, default=False,
                            help="PCIe Lane Count")

    if len(input_variables) == 0:
        args = parser.parse_args()
    else:
        args = parser.parse_args(input_variables)
    # Choose the Margin Module

    # Override defines axis only argument with user passed in one if provided.
    if args.user_axis_only is not None and args.user_axis_only == "False":
        axis_only = False
        print("User Axis Only Argument: {} Found, Overriding Defines Axis Only From: {} Passed Arg: {}".format(args.user_axis_only, args.axis_only, axis_only))
    elif args.user_axis_only is not None and args.user_axis_only == "True":
        axis_only = True
        print("User Axis Only Argument: {} Found, Overriding Defines Axis Only From: {} Passed Arg: {}".format(args.user_axis_only, args.axis_only, axis_only))
    else:
        axis_only = args.axis_only
        print("No User Axis Only Arg Passed, Using Defines File Axis Only Arg: {}".format(axis_only))


    try:
        print("end point: {} and env: {}".format(args.end_point, env))
        module = importlib.import_module("receiver.{}.{}".format(args.end_point, env))
    except ImportError as e:
        raise Exception(
            "Unable to find endpoint with error: {}, {} with env {}, valid endpoints: {}".format(e, args.end_point, env, end_points))

    if args.traffic not in traffics:
        raise Exception("Invalid traffic type '{}', please choose from {}".format(args.traffic, ", ".join(traffics)))

    # Include port breakdown for root ports
    print("Root Port: {} Ports Location: {}".format(args.root_port, args.ports_location))
    root_port = args.root_port
    if args.ports_location is not None:
        root_port=args.port_location_breakdown[int(args.ports_location)]
        print("Args: {} Input: {} Root Port: {}".format(args.ports_location, args.port_location_breakdown, root_port))

    if args.doe and args.r_value is not None and args.c_value is not None:
        args.adaptations.append([int(args.r_value), int(args.c_value)])

    # Initialize the margin tool
    margin_tool = module.MarginTool(
        endpoint=args.end_point,
        root_port=root_port,
        device=args.device,
        # Standard Configurations
        log_path=environ.get('Foo', args.result_path),
        additional_pdca_name=args.additional_pdca,
        device_index=args.device_index,
        cycle_count=args.cycles,
        current_cycle=args.current_cycle,
        tool_cycle_count=args.tool_cycle_count,
        debug=args.debug,
        plist=args.plist,
        lane_no=args.lane_no,
        product_code=product_code,
        letter_code=letter_code,

    # Scan Configuration (optional)
        axis_only=axis_only,
        min_x=args.min_x,
        max_x=args.max_x,
        min_y=args.min_y,
        max_y=args.max_y,
        step_x=args.step_x,
        step_y=args.step_y,
        duration_ms=args.duration_ms,
        timeout_s=args.timeout_s,
        delay_us=args.delay_us,
        threshold=args.threshold,
        adaptation_types=args.adaptations,
        por_adaptations=args.por_adaptations,
        ctle_sweep=args.ctle_sweep,
        dfe_off=args.dfe_off,
        vendor_specific=args.vendor_specific,
        traffic_type=args.traffic,
        module=args.module,
        gen_width=args.gen_width,
        gen_speed=args.gen_speed,
        tick_voltage=args.tick_voltage,
        tick_frequency=args.tick_frequency,
        depth=args.depth,
        phy=args.phy,
        rt13_lane=args.rt13_lane,
        rt13_initialize=args.rt13_initialize,
        rt13_verify=args.rt13_verify,
        rt13_dfe=args.rt13_dfe,
        gen_version=args.gen_version,
        microsemi_endpoint=args.microsemi_endpoint,
        moly_index_list=args.moly_index_list,
        doe=args.doe,
        doe_no=args.doe_no,
        soc=soc_code,
        board_rev=board_rev,
        eh_min=args.eh_min,
        eh_max=args.eh_max,
        ew_min=args.ew_min,
        ew_max=args.ew_max,
        die_location=args.die_location,
        en_endpoints=args.en_endpoints,
        disable_aspm_val=args.disable_aspm_val,
        port_list=args.port_list,
        enable_aspm_val=args.enable_aspm_val,
        folder_name=args.folder_name,
        controller_count=args.controller_count,
        controller_numbers=args.controller_numbers,
        link_status_endpoints=args.link_status_endpoints,
        max_pcie_lanes=args.max_pcie_lanes,
        rt13_layout=args.rt13_layout,
        route=args.route,
        atc_port=args.atc_port,
        load_fw=args.load_fw,
        intel_hw=args.intel_hw,
        lane_count=args.lane_count,
        port_enablement=args.port_enablement,
        score=args.score,
        pcie_lane_count=args.pcie_lane_count,
        swing=args.swing,
        dump_h0=args.dump_h0,
        verify_linkrate=args.verify_linkrate,
        camera_voltage_translation=args.camera_voltage_translation,
        camera_voltage_register=args.camera_voltage_register,
        camera_linkrate=args.camera_linkrate,
        pfx84=args.pfx84,
        bio_moly=args.bio_moly,
        prbs_loopback=args.prbs_loopback,
        prbs_ports=args.prbs_ports,
        host_name=args.host_name,
        port=args.port,
        uses_oss=args.pcie_uses_oss,
        pcie_port=args.pcie_port,
        pcie_startup=args.pcie_startup,
        pcie_gpio=args.pcie_gpio,
        error_mask=int(args.error_mask),
        special_pdca_format=args.special_pdca_format,
     )

    margin_tool.seq_log.info(f"Running margining on {args.end_point} in {env} environment")

    # Save Version to Log Files
    margin_tool.seq_log.info(f"Running margining with AEMTools Version: {__version__}")
    margin_tool.log_key(key='aemtools_version: {}'.format(__version__), value=__version_numeric__, units='')
    margin_tool.log_key(key='aemtools_numeric_version', value=__version_numeric__, units='')

    # Run margining
    margin_tool.execute_margin()

    # Exit with the Status code
    sys.exit()


if __name__ == "__main__":
    run_margining()
