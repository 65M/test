from defines import *

_all_ = [
    "params_data"
]


class params_data:

    class pcie0(AbstractEndpointsParams):
        min_x = 8
        max_x = 72
        step_x = 1
        min_y = -31
        max_y = 31
        step_y = 1
        duration_ms = 200
        threshold = 0
        gen_speed = 2
        module = "wifi"
        vendor_specific = {"run": False}
        tick_voltage =4.5645
        tick_frequency = 10 ** 12 / (5 * 10 ** 9 * 64)
        axis_only = True
        cycle = 1
        root_port = 0
        spec_check = True
        eh_min = 100
        eh_max = None
        ew_min = 50
        ew_max = 200


    class pcie1(AbstractEndpointsParams):
        min_x = 8
        max_x = 72
        step_x = 1
        min_y = -31
        max_y = 31
        step_y = 1
        duration_ms = 200
        threshold = 0
        gen_speed = 2
        module = "sdcard"
        vendor_specific = "6mV"
        tick_voltage =4.5645
        tick_frequency = 10 ** 12 / (5 * 10 ** 9 * 64)
        axis_only = True
        cycle = 1
        root_port = 1
        spec_check = False
        eh_min = 250
        eh_max = None
        ew_min= 80
        ew_max = 200


    # 174mv(gen2) and 30mv(gen4)
    # 20ps(gen2)

    class acio(AbstractEndpointsParams):
        min_x = 8
        max_x = 72
        step_x = 1
        min_y = -31
        max_y = 31
        step_y = 1
        duration_ms = 48
        threshold = 0
        gen_speed = 20
        module = "cio"
        vendor_specific = "6mV"
        axis_only = True
        tick_voltage =4.5645
        cycles = 1
        adaptations = []
        root_port = [0, 1]
        spec_check = False
        doe = False
        if doe is True:
            for i in range(1, -1, -1):
                for j in range(0, 1, 1):
                    adaptations.append([i, j])

    # 174mv(gen2) and 30mv(gen4)
    # 20ps(gen2)


    class usb5(AbstractEndpointsParams):
        min_x = 8
        max_x = 72
        step_x = 1
        min_y = -31
        max_y = 31
        step_y = 1
        duration_ms = 200
        threshold = 0
        gen_speed = 5
        module = "usb"
        vendor_specific = "6mV"
        axis_only = True
        tick_voltage =4.5645
        cycles = 1
        adaptations = []
        spec_check = False
        doe = False
        if doe is True:
            for i in range(1, -1, -1):
                for j in range(0, 1, 1):
                    adaptations.append([i, j])

    # 174mv(gen2) and 30mv(gen4)
    # 20ps(gen2)

    class usb10(AbstractEndpointsParams):
        min_x = 8
        max_x = 72
        step_x = 1
        min_y = -31
        max_y = 31
        step_y = 1
        duration_ms = 96
        threshold = 0
        gen_speed = 10
        module = "usb"
        vendor_specific = "6mV"
        axis_only = True
        tick_voltage = 4.5645
        cycles = 1
        adaptations = []
        spec_check = False
        doe = False
        if doe is True:
            for i in range(1, -1, -1):
                for j in range(0, 1, 1):
                    adaptations.append([i, j])

    # 174mv(gen2) and 30mv(gen4)
    # 20ps(gen2)

    class ans3(AbstractEndpointsParams):
        min_x = 8
        max_x = 71
        step_x = 1
        min_y = -31
        max_y = 31
        step_y = 1
        duration_ms = 60
        timeout_s = 520
        threshold = 0
        gen_speed = 4
        module = None
        gen_width = 4
        axis_only = False
        tick_voltage = 9.129
        tick_frequency = 0.9766
        spec_check = True
        eh_min = 100
        eh_max = None
        ew_min = 20
        ew_max = 63

    class s5e(AbstractEndpointsParams):
        min_x = 8
        max_x = 71
        step_x = 1
        min_y = -31
        max_y = 31
        step_y = 1
        duration_ms = 60
        timeout_s = 520
        threshold = 0
        gen_speed = 4
        module = None
        gen_width = 4
        axis_only = False
        tick_voltage = 9.52
        tick_frequency = 0.9766
        spec_check = True
        eh_min = 100
        eh_max = None
        ew_min = 20
        ew_max = 63

    class camera(AbstractEndpointsParams):
        min_x = 8
        max_x = 71
        step_x = 1
        min_y = -31
        max_y = 31
        step_y = 1
        duration_ms = 500
        timeout_s = 520
        threshold = 0
        gen_speed = 4
        module = None
        gen_width = 4
        axis_only = True
        tick_voltage = 4.5645
        tick_frequency = 10 ** 12 / (2 * 10 ** 9 * 64)
        spec_check = True
        eh_min = 90
        eh_max = None
        ew_min = 0.25
        ew_max = None
        doe = True
        adaptations = []
        camera_linkrate = 2400000000
        camera_voltage_register = 0x519
        camera_voltage_translation = [200, 200, 200, 200, 200, 225, 250, 275, 300, 325, 350, 375, 400, 425, 450, 450]
        if doe is True:
            for i in range(400, 175, -25):
                adaptations.append(i)

    CONVERSION_PARAMS_DATA = [{
        "pcie3nmwifi": {"func": pcie0},
        "pcie3nmsdcard": {"func": pcie1},
        "ans3": {"func": ans3},
        "acio3nm": {"func": acio},
        "usb103nm": {"func": usb10},
        "usb53nm": {"func": usb5},
        "s5e": {"func": s5e},
        "camera3nm": {"func": camera},
    }]

    def __init__(self, *args, **kwargs):
        super(conversion_registers, self).__init__(*args, **kwargs)
