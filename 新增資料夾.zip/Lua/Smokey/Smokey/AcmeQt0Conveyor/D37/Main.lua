local Dotara = require("Dotara")
local Utils = require("Utils")
local LogCollectorPath = "Logs:\\MobileMediaFactoryLogs\\LogCollector\\AcmeQt0Conveyor\\"
local SmokeyPath = "nandfs:\\AppleInternal\\Diags\\Logs\\Smokey\\AcmeQt0Conveyor\\"
local overallHFLPPResult = true
---------------------------------------------------------

local function InitLogs()
    -- Initialize the log collection directory for Heat Soak
    pcall(Shell, "mkdir " .. LogCollectorPath)
    -- Create empty PDCA.plist
    Shell("writefile --create --truncate --text '' " .. LogCollectorPath .. "PDCA.plist")
    -- WARNING: Don't point the semaphore file at a file that does not exist! It will prevent units from being restored!
    -- Semaphore file for SWDL to collect logs and process the PDCA.plist
    Shell("writefile --create --truncate --text '' " .. LogCollectorPath .. ".FactoryLogsWaitingToBeCollected")
    Shell("event -s media-sync")
end

local function FlushLogs()
    -- Flush PDCA.plist and Smokey.log to the Logs:\ partition
    Utils.opsLog("ACME:: Flush PDCA.plist and Smokey.log to the Logs partition")
    Shell("cp " .. SmokeyPath .. "PDCA.plist " .. LogCollectorPath)
    Shell("cp " .. SmokeyPath .. "Smokey.log " .. LogCollectorPath .. "HFLPP.log")
    Shell("rm " .. SmokeyPath .. "Smokey.log")
    Shell("rm " .. SmokeyPath .. "PDCA.plist")
    Shell("event -s media-sync")
end

function Prologue() 
    Utils.opsLog("ACME:: Prologue start")
    InitLogs()
    Utils.DisplayText("Press POWER button")
    Utils.WaitForPowerButtonPressed()
    Utils.opsLog("ACME:: Prologue end")
end

function EpilogueTest()
    Utils.opsLog("ACME:: Epilogue start", overallHFLPPResult)
    if overallHFLPPResult then
        Utils.DisplayText("Epilogue")
    else
        Utils.DisplayText("Epilogue", "FAIL")
    end
    
    Shell("bl -m")
    Shell("cbcolor")
    FlushLogs()
    Shell("station --parse")
    Shell("station --stop HFLPP")
end

function DotaraHFLPPTest()
    Utils.opsLog("ACME:: DotaraHFLPPTest")
    Utils.DisplayText("HFLPP running")
    local success, result, didRetried = Utils.runAFunctionIfPossible(Dotara.HFLPPTest)
    if success and not didRetried then
        Utils.opsLog("ACME:: DotaraHFLPPTest pass without a retry.")
        Utils.DisplayText("PASS", "PASS")
    elseif success then
        Utils.opsLog("ACME:: DotaraHFLPPTest pass with retry.")
        Utils.DisplayText("PASS with retry", "PASS")
    else
        Utils.opsLog("DotaraHFLPPTest failed, flushing logs now as Epilogue will not run.")
        FlushLogs()
        error("HFLPP failed: "..result)
    end
    
    Utils.opsLog("Finished running HFLPPTest", success, result, didRetried)
    overallHFLPPResult = success
end