local Dotara = {}


---------------------------------------------------------
-- Dotara.
-- Tests related to Dotara.

local Universal = require "Universal.14A"
require 'hw'

local function ParseADCresult(channel)
    require "Burnin"
    Shell('c26 exec adc ' .. channel)
    return DiagsParse('adc', Last.Output)
end

local function hex(number)
    return string.format("%x", number)
end

-- ======================================== --
-- ======================================== --
-- =========== DOTARA MEMORY FNs ========== --
-- ======================================== --
-- ======================================== --

function DotaraReg_Wr(reg_addr,v2rd)

    if v2rd ~= nil then
        v2rd = string.format("0x%08x",v2rd) 
        reg_addr = string.format("0x%08x",reg_addr) 
    else
        print("\nFCT ERROR! nil value writing requested")
        return "FAIL"
    end

    Shell("c26 exec write "..reg_addr.." "..v2rd)
    return "PASS"
end

function DotaraReg_Rd(reg_addr)
    local reg_v = {}
    reg_addr = string.format("0x%x", reg_addr)
    Shell("c26 exec read "..reg_addr)
    reg_v[0],reg_v[1],reg_v[2],reg_v[3] = string.match(Last.Output, "00:%s+([%x]+)%s+([%x]+)%s+([%x]+)%s+([%x]+)")
    reg_v[4] = "0x"..reg_v[3]..reg_v[2]..reg_v[1]..reg_v[0]
    print("FCT Msg: get register value: "..reg_addr.." = "..reg_v[4].."\n")
    return reg_v[4]
end

-- ======================================== --
-- ======================================== --
-- ============ DOTARA TESTS ============== --
-- ======================================== --
-- ======================================== --

function SimpleMask(Word, Mask, Shift)
    return bit32.rshift(bit32.band(Word, Mask), Shift)
end


function DotaraInitTest_REL()
    require "Burnin"
    local Passed = RelAutoTest:DiagsMenuWrapper(DotaraInitTest, "Dotara Init Test")
    DotaraCleanup()

    return Passed
end

---------------------------------------------------------
-- Function to extract ANA2 ADC reading from Dotara.
function DotaraANAGPIOTest()
    require "Burnin"
    local ntc_temperature

    SetupDotara('rx')

    Shell('c26 exec embox 3 5 0')
    tmp_response=Last.Output
    PrintString(tmp_response)
    
    byte_1, byte_2 = string.match(tmp_response, 'Returned data: 0x%x+ 0x%x+ 0x%x+ 0x%x+ 0x%x+ 0x%x+ 0x%x+ 0x%x+ 0x(%x+) 0x(%x+) 0x%x+ 0x%x+ 0x%x+ 0x%x+ 0x%x+ 0x%x+')

    if string.len(byte_1)==1 then
        byte_1 = '0' .. byte_1
    end
    if string.len(byte_2)==1 then
        byte_2 = '0' .. byte_2
    end

    -- snag ANA2 ADC reading
    -- ana2_voltage = ParseADCresult('ANA2_DIV5')

    -- convert all keys to numbers
    ntc_temperature=(tonumber(byte_2 .. byte_1,16))*0.01 -- value in deci degC
    -- ana2_voltage = tonumber(ana2_voltage)

    -- now report to station
    Universal:ReportDataToStationAndPDCA('Temperature_NTC_TEMP', ntc_temperature, 'C', 20, 50)
    -- Universal:ReportDataToStationAndPDCA('ANA2_VOLT', ana2_voltage, 'mV', 0, 45)

end

---------------------------------------------------------
-- Dotara Reset Test.
function DotaraResetTest()
    require "Burnin"

    local initResetVal, valueWritten, postResetVal = ExecDotaraResetTest()
    local diffExpected = valueWritten - initResetVal
    local diffFound = valueWritten - postResetVal

    Universal:ReportDataToStation('Reset_Init', initResetVal, nil, nil, nil)
    Universal:ReportDataToStation('Reset_Pre_Reset', valueWritten, nil, nil, nil)
    Universal:ReportDataToStation('Reset_Post_Reset', postResetVal, nil, nil, nil)
    Universal:ReportDataToStationAndPDCA('Reset_Diff', diffFound, nil, diffExpected, diffExpected)

end

function DotaraInitTestWrapper()
    require "Burnin"

    DotaraInitTest()
end

---------------------------------------------------------
-- Resets Dotara and leave it in Rx mode.
function DotaraCleanup()
    require "Burnin"
    -- Reset Dotara and leave it in RX
    SetupDotara("rx")
    -- Turn off Baseband
    pcall(Shell, 'baseband --off')
end

local function average_samples(data, length_of_data)
    -- this function takes in a table of samples and returns the average of those samples
    local avg = 0

    for i=1,length_of_data do
        avg = avg + data[i]
    end

    avg = avg / length_of_data

    return avg
end


-- ======================================== --
-- ======================================== --
-- ============ DOTARA SETUP/WRITES  ====== --
-- ======================================== --
-- ======================================== --

-- Setting Vboost is required for OTP burn
function set_boost(v2set)
    if v2set=="disable" or v2set==0 or v2set==false then
        PrintString("Disable Boost Converter")  
        Shell ("c26 exec reqformat 1 3 u16[0] u16[50]")
        Shell('wait 260')
    elseif v2set=="enable" or v2set==true then
        PrintString("Enable Boost Converter")
        fw_setBitMask(registers.BOOST_BOOST_CTRL1, 0x00000001)
        --turn on boost need some delay
        Shell("wait 200")
    else
        PrintString("Enabled boost and setting voltage to "..v2set.."mV")
        Shell ("c26 exec reqformat 1 3 u16["..v2set.."] u16[50]")
        Shell('wait 260')
    end
end

-- Custome reading funciton for OTP
function read_otp_range_fw(row_start, num_rows)
    local row_last = row_start+num_rows-1
    local otp_data = {}

    Shell("c26 exec otp read "..row_start.." "..row_last)
    
    for i=row_start,row_last do
        local val1, val2
        val1, val2 = string.match(Last.Output, "Row: "..i.."......%s-([%a%w]+)%s-([%a%w]+)")
        table.insert(otp_data,{val1,val2})
    end
    return otp_data
end

-- Check if OTP has been locked
function dotara_otp_lock_check()
    Shell('wait 1000')
    local data = read_otp_range_fw(11,2)
    local lock_check = 0
    
    for _,value in ipairs(data) do
        if (tonumber(value[1])~=0 or tonumber(value[2])~=0) then
            lock_check = 1
            break
        end 
    end   
    --jt_print(lock_check,"dotara_otp_lock_check") -- 0 = PASS (unlocked), 1 = FAIL (locked)
    return lock_check
end

--Finds next available empty row space
function get_free_otp_row_fw(first_row, last_row)

    local start_row = first_row
    local end_row = last_row
    local otp_size = end_row - start_row +1
    --mask_uart("on")
    local data = read_otp_range_fw(start_row,otp_size)
    --mask_uart("off")

--    for index,value in ipairs(data) do
--      print (index..' Row:'..(index+start_row-1).."......"..value[1]..' '..value[2])
--    end

    local empty_row1 = start_row
    local empty_row2 = start_row
    for i=otp_size,1,-1 do
        local val1 = tonumber(data[i][1])
        local val2 = tonumber(data[i][2])

        if (val1~=0 or val2~=0) then
            empty_row1 = start_row+i
            break
        end
    end

    local i=1
    while (i <= (empty_row1-start_row)) do
        local val1 = tonumber(data[i][1])
        local val2 = tonumber(data[i][2])
        if (bit32.band(val1,0x3) == 0x2 and bit32.rshift(val1,16)~=0) then
            local size_block = bit32.rshift(val1,16)
            empty_row2 = empty_row2 + (size_block+1)
            i = i + (size_block+1)
        else
            i = i+1
        end
    end

    local row_avail = math.max(empty_row1,empty_row2)

    if (row_avail<start_row or row_avail>end_row) then
        PrintString("No empty OTP rows available between "..start_row.." and "..end_row)
        return nil
    else
        return row_avail, data
    end

end

-- ======================================== --
-- ======================================== --
-- ========== HFLPP Test HELPERS  ========= --
-- ======================================== --
-- ======================================== --


function syscfg_gen_CRC(syscfg_key)
    --[[
    Function that calculates s CRC 16. The polynomial is described as following:
    x^16+x^12+x^5+ 1
    
    inData is the data array of 4 bytes each {0x10000000, 0x20000000, 0x30000000, .....}
    --]]
    local cummBytes = cummbytes or 4
    local inCRC = 0xFFFF
    print("Initial CRC: "..inCRC)

    for pair_idx = 1,syscfg_key.numPairs-1 do
        local pair_data = syscfg_key.calibrationPairs[pair_idx].data
        local byteData = {bit32.band(pair_data,0xFF), bit32.band(bit32.rshift(pair_data,8),0xFF)}
        for i=1,#byteData do
            inCRC = bit32.bor(bit32.rshift(inCRC,8), bit32.lshift(inCRC,8))
            inCRC = bit32.bxor(inCRC, byteData[i])
            inCRC = bit32.bxor(inCRC, bit32.rshift(bit32.band(inCRC,0xFF),4))
            inCRC = bit32.bxor(inCRC, bit32.lshift(inCRC,12))
            inCRC = bit32.bxor(inCRC, bit32.lshift(bit32.band(inCRC,0xFF),5))
            inCRC = bit32.band(inCRC,0xFFFF)
        end
    end

    print("Calculated CRC: "..inCRC)
    return inCRC

end


-- Convert hexidecimal string into various native formats
-- https://confluence.sd.apple.com/pages/viewpage.action?spaceKey=EDG&title=Lua+Hardware+Access#LuaHardwareAccess-StructAPIs
-- decode_format: 
--     * hw.struct.[INT8, INT16 , INT32 , UINT8 , UINT16, UINT32, FLOAT , DOUBLE]
function hex_decode(hex_string, decode_format)
    -- Convert four byte string '%x%x%x%x%x%x%x%x' hex into bytestring representation
    local byte_string = ''
    for byte in hex_string:gmatch("%x%x") do
        byte_string = byte_string .. string.char(tonumber(byte, 16))
    end
    local byte_struct = hw.struct.new(byte_string)
    PrintString('decode_format  ' .. decode_format)
    PrintString('hex_string  ' ..hex_string)
    local converted_value  = byte_struct:decode(decode_format)
    return converted_value
end


-- Swap between big and small endian data formats for 32bit hex values
-- Note - assumes value is not prepended with 0x
function endian_reverse(input_text)
    local string_length = string.len(input_text)
    if string_length>4 then
        b0, b1, b2, b3 = string.match(input_text,'(%w%w)(%w%w)(%w%w)(%w%w)')
        return b3 .. b2 .. b1 .. b0
    else
        b0, b1 = string.match(input_text,'(%w%w)(%w%w)')
        return b1 .. b0
    end
    
end


-- Convert from twos complement format to signed integer
function two_comp_to_signed(val,n)

    if (val >= math.pow(2,n)/2) then
        return val - math.pow(2,n)
    else
        return val
    end

end


-- Minimalistic complex number library
local Complex = {}
Complex.Angle = function (Z)
    local angle_q1 = math.atan(math.abs(Z.i)/math.abs(Z.r))
    local angle_result = 0
    if Z.r >=0 then
        if Z.i >=0 then
            angle_result = angle_q1
        else
            angle_result = -angle_q1
        end
    else
        if Z.i >=0 then
            angle_result = math.pi - angle_q1
        else
            angle_result = -(math.pi-angle_q1)
        end
    end
    return angle_result
end
Complex.Magnitude = function (Z)
    local magnitude_result = math.sqrt(math.abs(Z.r)^2 + math.abs(Z.i)^2)
    return magnitude_result
end
Complex.Multiply = function (Za, Zb)
    local angle = Complex.Angle(Za) + Complex.Angle(Zb)
    local magnitude = Complex.Magnitude(Za) * Complex.Magnitude(Zb)
    return {r=magnitude*math.cos(angle), i=magnitude*math.sin(angle)}
end
Complex.Divide = function (Za, Zb)
    local angle = Complex.Angle(Za) - Complex.Angle(Zb)
    local magnitude = Complex.Magnitude(Za) / Complex.Magnitude(Zb)
    return {r=magnitude*math.cos(angle), i=magnitude*math.sin(angle)}
end
Complex.Add = function (Za, Zb)
    return {r= Za.r + Zb.r, i=Za.i + Zb.i}
end
Complex.Subtract = function (Za, Zb)
    return {r= Za.r - Zb.r, i=Za.i - Zb.i}
end

-- ======================================== --
-- ======================================== --
-- ============ OTP and Registers  ======== --
-- ======================================== --
-- ======================================== --

-- Copied from DotaraLC driver
-- Todo: condense to minimum required register addresses in future
local registers =
{
    FADC_ENABLE_REG =  0xf0001400,
    FADC_STATUS_REG =  0xf0001404,
    FADC_CONTROL_REG =  0xf0001408,
    FADC_SAMPLING_CNTRL =  0xf000140c,
    FADC_FADC_RESULT =  0xf0001410,
    FADC_INT_EN =  0xf0001414,
    FADC_FADC_REQUEST =  0xf0001418,
    FADC_GAIN_OFFSET =  0xf000141c,
    FADC_FW_TRIMREG =  0xf0001420,
    FADC_FADCTRIM =  0xf0001424,

    --ASKDEMOD
    ASK_DEMOD_CTRL =  0xf0001800 ,
    ASK_DEMOD_FRONTEND =  0xf0001804,
    ASK_DEMOD_BACKEND_0_I =  0xf0001810,
    ASK_DEMOD_BACKEND_1_I =  0xf0001814,
    ASK_DEMOD_BACKEND_2_I =  0xf0001818,
    ASK_DEMOD_BACKEND_3_I =  0xf000181c,
    ASK_DEMOD_BACKEND_4_I =  0xf0001820,
    ASK_DEMOD_BACKEND_5_I =  0xf0001824,
    ASK_DEMOD_BACKEND_6_I =  0xf0001828,
    ASK_DEMOD_BACKEND_7_I =  0xf000182c,
    ASK_DEMOD_PACKET_0_I =  0xf0001830,
    ASK_DEMOD_PACKET_1_I =  0xf0001834,
    ASK_DEMOD_PACKET_2_I =  0xf0001838,
    ASK_DEMOD_PACKET_3_I =  0xf000183c,
    ASK_DEMOD_PACKET_4_I =  0xf0001840,
    ASK_DEMOD_INT_0_I =  0xf0001844,
    ASK_DEMOD_INT_1_I =  0xf0001848,
    ASK_DEMOD_DATA_0_I =  0xf000184c,
    ASK_DEMOD_DATA_1_I =  0xf0001850,
    ASK_DEMOD_DATA_2_I =  0xf0001854,
    ASK_DEMOD_DATA_3_I =  0xf0001858,
    ASK_DEMOD_BACKEND_0_Q =  0xf0001860,
    ASK_DEMOD_BACKEND_1_Q =  0xf0001864,
    ASK_DEMOD_BACKEND_2_Q =  0xf0001868,
    ASK_DEMOD_BACKEND_3_Q =  0xf000186c,
    ASK_DEMOD_BACKEND_4_Q =  0xf0001870,
    ASK_DEMOD_BACKEND_5_Q =  0xf0001874,
    ASK_DEMOD_BACKEND_6_Q =  0xf0001878,
    ASK_DEMOD_BACKEND_7_Q =  0xf000187c,
    ASK_DEMOD_PACKET_0_Q =  0xf0001880,
    ASK_DEMOD_PACKET_1_Q =  0xf0001884,
    ASK_DEMOD_PACKET_2_Q =  0xf0001888,
    ASK_DEMOD_PACKET_3_Q =  0xf000188c,
    ASK_DEMOD_PACKET_4_Q =  0xf0001890,
    ASK_DEMOD_INT_0_Q =  0xf0001894,
    ASK_DEMOD_INT_1_Q =  0xf0001898,
    ASK_DEMOD_DATA_0_Q =  0xf000189c,
    ASK_DEMOD_DATA_1_Q =  0xf00018a0,
    ASK_DEMOD_DATA_2_Q =  0xf00018a4,
    ASK_DEMOD_DATA_3_Q =  0xf00018a8,
    ASK_DEMOD_DMA_READ_PORT =  0xf00018b0,
    ASK_DEMOD_DMA_READ_PORT_CTRL =  0xf00018b4,

    --BSC
    BSC_SLAVEID =  0xf0000b00,
    BSC_BSCCTRL1 =  0xf0000b04,
    BSC_BSCAPRTR =  0xf0000b08,
    BSC_BSC_TSUDAT_FS =  0xf0000b0c,
    BSC_BSC_TSUDAT_FP =  0xf0000b10,
    BSC_BSC_TSUDAT_HS =  0xf0000b14,
    BSC_BSCMBOX0 =  0xf0000b80,
    BSC_BSCMBOX1 =  0xf0000b84,
    BSC_BSCMBOX2 =  0xf0000b88,
    BSC_BSCMBOX3 =  0xf0000b8c,
    BSC_BSCMBOX4 =  0xf0000b90,
    BSC_BSCMBOX5 =  0xf0000b94,
    BSC_BSCMBOX6 =  0xf0000b98,
    BSC_BSCMBOX7 =  0xf0000b9c,
    BSC_BSCINT =  0xf0000ba0,

    --Boost
    BOOST_BOOST_CTRL1 =  0xf0001600,
    BOOST_BOOST_CTRL2 =  0xf0001604,
    BOOST_BOOST_TRIM1 =  0xf0001608,
    BOOST_BOOST_TRIM2 =  0xf000160c,
    BOOST_BOOST_STATUS1 =  0xf0001610,

    --CMD
    CMP_CMPGPDAC =  0xf0001a00,
    CMP_CMPGPEN =  0xf0001a04,
    CMP_CMPMVRDAC =  0xf0001a08,
    CMP_CMPMVREN =  0xf0001a10,
    CMP_CMPSTS =  0xf0001a14,
    CMP_CMPTEST =  0xf0001a18,

    --DMA
    DMA_R_DMACINTSTATUS = 0xf0008000,
    DMA_R_DMACINTTCSTATUS = 0xf0008004,
    DMA_R_DMACINTTCCLEAR = 0xf0008008,
    DMA_R_DMACINTERRORSTATUS = 0xf000800c,
    DMA_R_DMACINTERRCLR = 0xf0008010,
    DMA_R_DMACRAWINTTCSTATUS = 0xf0008014,
    DMA_R_DMACRAWINTERRORSTATUS = 0xf0008018,
    DMA_R_DMACENBLDCHNS = 0xf000801c,
    DMA_R_DMACSOFTBREQ = 0xf0008020,
    DMA_R_DMACSOFTSREQ = 0xf0008024,
    DMA_R_DMACSOFTLBREQ = 0xf0008028,
    DMA_R_DMACSOFTLSREQ = 0xf000802c,
    DMA_R_DMACCONFIGURATION = 0xf0008030,
    DMA_R_DMACSYNC = 0xf0008034,
    DMA_R_DMACC0SRCADDR = 0xf0008100,
    DMA_R_DMACC0DESTADDR = 0xf0008104,
    DMA_R_DMACC0LLI = 0xf0008108,
    DMA_R_DMACC0CONTROL = 0xf000810c,
    DMA_R_DMACC0CONFIGURATION = 0xf0008110,
    DMA_R_DMACC1SRCADDR = 0xf0008120,
    DMA_R_DMACC1DESTADDR = 0xf0008124,
    DMA_R_DMACC1LLI = 0xf0008128,
    DMA_R_DMACC1CONTROL = 0xf000812c,
    DMA_R_DMACC1CONFIGURATION = 0xf0008130,
    DMA_R_DMACC2SRCADDR = 0xf0008140,
    DMA_R_DMACC2DESTADDR = 0xf0008144,
    DMA_R_DMACC2LLI = 0xf0008148,
    DMA_R_DMACC2CONTROL = 0xf000814c,
    DMA_R_DMACC2CONFIGURATION = 0xf0008150,
    DMA_R_DMACC3SRCADDR = 0xf0008160,
    DMA_R_DMACC3DESTADDR = 0xf0008164,
    DMA_R_DMACC3LLI = 0xf0008168,
    DMA_R_DMACC3CONTROL = 0xf000816c,
    DMA_R_DMACC3CONFIGURATION = 0xf0008170,
    DMA_R_DMACC4SRCADDR = 0xf0008180,
    DMA_R_DMACC4DESTADDR = 0xf0008184,
    DMA_R_DMACC4LLI = 0xf0008188,
    DMA_R_DMACC4CONTROL = 0xf000818c,
    DMA_R_DMACC4CONFIGURATION = 0xf0008190,
    DMA_R_DMACC5SRCADDR = 0xf00081a0,
    DMA_R_DMACC5DESTADDR = 0xf00081a4,
    DMA_R_DMACC5LLI = 0xf00081a8,
    DMA_R_DMACC5CONTROL = 0xf00081ac,
    DMA_R_DMACC5CONFIGURATION = 0xf00081b0,
    DMA_R_DMACC6SRCADDR = 0xf00081c0,
    DMA_R_DMACC6DESTADDR = 0xf00081c4,
    DMA_R_DMACC6LLI = 0xf00081c8,
    DMA_R_DMACC6CONTROL = 0xf00081cc,
    DMA_R_DMACC6CONFIGURATION = 0xf00081d0,
    DMA_R_DMACC7SRCADDR = 0xf00081e0,
    DMA_R_DMACC7DESTADDR = 0xf00081e4,
    DMA_R_DMACC7LLI = 0xf00081e8,
    DMA_R_DMACC7CONTROL = 0xf00081ec,
    DMA_R_DMACC7CONFIGURATION = 0xf00081f0,
    DMA_R_DMACITCR = 0xf0008500,
    DMA_R_DMACITOP1 = 0xf0008504,
    DMA_R_DMACITOP2 = 0xf0008508,
    DMA_R_DMACITOP3 = 0xf000850c,
    DMA_R_DMACPERIPHID0 = 0xf0008fe0,
    DMA_R_DMACPERIPHID1 = 0xf0008fe4,
    DMA_R_DMACPERIPHID2 = 0xf0008fe8,
    DMA_R_DMACPERIPHID3 = 0xf0008fec,
    DMA_R_DMACPCELLID0 = 0xf0008ff0,
    DMA_R_DMACPCELLID1 = 0xf0008ff4,
    DMA_R_DMACPCELLID2 = 0xf0008ff8,
    DMA_R_DMACPCELLID3 = 0xf0008ffc,

    --FADCI
    FADCI_ENABLE_REG =  0xf0001500,
    FADCI_STATUS_REG =  0xf0001504,
    FADCI_CONTROL_REG =  0xf0001508,
    FADCI_SAMPLING_CNTRL =  0xf000150c,
    FADCI_FADC_RESULT =  0xf0001510,
    FADCI_INT_EN =  0xf0001514,
    FADCI_FADC_REQUEST =  0xf0001518,
    FADCI_GAIN_OFFSET =  0xf000151c,
    FADCI_FW_TRIMREG =  0xf0001520,
    FADCI_FADCTRIM =  0xf0001524,

    --FIFO
    FFIFO_I_FADC_FIFO_OUT =  0xf0009520,
    FFIFO_I_FADC_FIFO_LEVEL =  0xf0009524,
    FFIFO_I_FADC_FIFO_INTEN =  0xf0009528,
    FFIFO_I_FADC_FIFO_CONFIG =  0xf000952c,
    FFIFO_I_FADC_ENV_VALUE =  0xf0009530,
    FFIFO_FADC_FIFO_OUT =  0xf0009500,
    FFIFO_FADC_FIFO_LEVEL =  0xf0009504,
    FFIFO_FADC_FIFO_INTEN =  0xf0009508,
    FFIFO_FADC_FIFO_CONFIG =  0xf000950c,
    FFIFO_FADC_ENV_VALUE =  0xf0009510,

    --FMOD
    FMOD_POWERPWMPARAMS =  0xf0001700,
    FMOD_MODPWMPARAMS =  0xf0001704,
    FMOD_GENPWMPARAMS =  0xf0001708,
    FMOD_PWM2CONFIG =  0xf000170c,
    FMOD_PWMFIFOENTRY =  0xf0001710,
    FMOD_PWMMANUALCTRL =  0xf0001714,
    FMOD_PWMFIFOTHRESHOLD =  0xf0001718,
    FMOD_PWMFIFOSTATUS =  0xf000171c,
    FMOD_FADCREQCOUNTS =  0xf0001720,
    FMOD_FADCREQCOUNTS2 =  0xf0001724,
    FMOD_FADCREQCTRL =  0xf0001728,
    FMOD_GENPWMCTRL =  0xf000172c,

    --Freq Detect
    FREQDET_FREQEN =  0xf0000800,
    FREQDET_FREQCTRL1 =  0xf0000804,
    FREQDET_FREQTIMING =  0xf0000808,
    FREQDET_FREQFCLKMINMAX =  0xf000080c,
    FREQDET_FREQIDLETHRESH =  0xf0000810,
    FREQDET_FREQNONIDLETHRESH =  0xf0000814,
    FREQDET_FREQFILTER =  0xf0000818,
    FREQDET_FREQAVEVALUE =  0xf000081c,
    FREQDET_FREQFIFO =  0xf0000820,
    FREQDET_FREQPRESPARAM =  0xf0000824,
    FREQDET_FREQCLKEN =  0xf0000828,
    FREQDET_FREQFIELDPRES =  0xf000082c,
    FREQDET_BPF_A1 =  0xf0000830,
    FREQDET_BPF_A2 =  0xf0000834,
    FREQDET_BPF_LOAD =  0xf0000838,
    FREQDET_CIC_BPF_CTRL =  0xf000083c,
    FREQDET_BPF_CONFIG =  0xf0000840,
    FREQDET_MEAN_VALUE =  0xf0000844,
    FREQDET_ENV_LOW_VALUE =  0xf0000848,
    FREQDET_ENV_HIGH_VALUE =  0xf000084c,
    FREQDET_FILTER_UPDT =  0xf0000850,

    --GPIO
    GPIO_GPIO0_CTRL =  0xf0000c00,
    GPIO_GPIO1_CTRL =  0xf0000c04,
    GPIO_GPIO2_CTRL =  0xf0000c08,
    GPIO_GPIO3_CTRL =  0xf0000c0c,
    GPIO_GPIO4_CTRL =  0xf0000c10,
    GPIO_GPIO5_CTRL =  0xf0000c14,
    GPIO_GPIO6_CTRL =  0xf0000c18,
    GPIO_GPIO7_CTRL =  0xf0000c1c,
    GPIO_GPIO8_CTRL =  0xf0000c20,
    GPIO_GPIO_STATUS =  0xf0000c30,
    GPIO_GPIO_OUTPUT =  0xf0000c34,
    GPIO_GPIO3_GPIO0_IOCTRL =  0xf0000c38,
    GPIO_GPIO5_GPIO4_IOCTRL =  0xf0000c3c,
    GPIO_GPIO7_GPIO6_IOCTRL =  0xf0000c40,
    GPIO_INT_IO_CTRL =  0xf0000c44,
    GPIO_EN_BOOST_IO_CTRL =  0xf0000c48,
    GPIO_FPWM_BOOST_IO_CTRL =  0xf0000c4c,
    GPIO_BSC_IO_CTRL =  0xf0000c50,
    GPIO_SPMI_IO_CTRL =  0xf0000c54,
    GPIO_RESET_L_IO_CTRL =  0xf0000c58,
    GPIO_CLK_IN_IO_CTRL =  0xf0000c5c,
    GPIO_FPWM_IN_IO_CTRL =  0xf0000c60,
    GPIO_ANADBG1 =  0xf0000c64,
    GPIO_ANADBG2 =  0xf0000c68,

    --ILOAD
    ILOAD_ILOADCTRL1 =  0xf0000e00,
    ILOAD_ILOADSETTING =  0xf0000e04,
    ILOAD_ILOADCTRL2 =  0xf0000e08,
    ILOAD_ILOADCTRL3 =  0xf0000e0c,
    ILOAD_ILOADCTRL4 =  0xf0000e10,
    ILOAD_ILOADCTRL5 =  0xf0000e14,
    ILOAD_ILOADTFBEN =  0xf0000e18,
    ILOAD_ILOADTRIM1 =  0xf0000e1c,
    ILOAD_TSNSPTATTRIM =  0xf0000e20,
    ILOAD_TSNSCTATTRIM =  0xf0000e24,
    ILOAD_TSNSALPHATRIM =  0xf0000e28,
    ILOAD_ILOADSTATUS1 =  0xf0000e2c,

    --ISNS
    ISNS_ISNSCTRL1 =  0xf0000d00,
    ISNS_ISNSCTRL2 =  0xf0000d04,
    ISNS_ISNSTRIMRX =  0xf0000d08,
    ISNS_ISNSTRIMTX =  0xf0000d0c,
    ISNS_ISNSRTTRIMRX =  0xf0000d10,
    ISNS_ISNSHTTRIMRX =  0xf0000d14,
    ISNS_ISNSRTTRIMTX =  0xf0000d18,
    ISNS_ISNSHTTRIMTX =  0xf0000d1c,
    ISNS_ISNSTSNS =  0xf0000d20,

    --LFOD
    LFOD_LFOD_DUTY_CYCLE_SETTINGS1 =  0xf0001900,
    LFOD_LFOD_DUTY_CYCLE_SETTINGS2 =  0xf0001904,
    LFOD_LFOD_DUTY_CYCLE_SETTINGS3 =  0xf0001908,
    LFOD_LFOD_DUTY_CYCLE_SETTINGS4 =  0xf000190c,
    LFOD_LF_PULSE_CONTROL =  0xf0001910,
    LFOD_LFOD_CONTROL0 =  0xf0001914,
    LFOD_LFOD_CONTROL1 =  0xf0001918,
    LFOD_LFOD_ENABLE =  0xf000191c,
    LFOD_LFOD_TRIM0 =  0xf0001920,
    LFOD_LFOD_TRIM1 =  0xf0001924,
    LFOD_LFOD_TRIM_LOCKREG =  0xf0001928,
    LFOD_LFOD_ANALOG =  0xf000192c,
    LFOD_LFOD_ANALOG2 =  0xf0001930,

    --MVR
    MVR_MVRCTRL1 =  0xf0000900,
    MVR_MVRCTRL2 =  0xf0000904,
    MVR_MVRCTRL3 =  0xf0000908,
    MVR_MVRCTRL4 =  0xf000090c,
    MVR_MVRCTRL5 =  0xf0000910,
    MVR_MVRCTRL6 =  0xf0000914,
    MVR_MVRTRIM1 =  0xf0000918,
    MVR_MVRTRIM2 =  0xf000091c,
    MVR_MVRDELTAV =  0xf0000920,
    MVR_MVRTEST1 =  0xf0000924,
    MVR_MVRTEST2 =  0xf0000928,
    MVR_MVRTEST3 =  0xf000092c,
    MVR_MVRTEST5 =  0xf0000930,

    --OTP
    OTP_OTPCNFG =  0xf0000a00,
    OTP_OTPPWR =  0xf0000a04,
    OTP_OTPADDR =  0xf0000a08,
    OTP_OTPWDATA1 =  0xf0000a0c,
    OTP_OTPWDATA2 =  0xf0000a10,
    OTP_OTPCTRL =  0xf0000a14,
    OTP_OTPSTATUS =  0xf0000a18,
    OTP_OTPWDATA3 =  0xf0000a1c,
    OTP_OTPRDATA1 =  0xf0000a20,
    OTP_OTPRDATA2 =  0xf0000a24,
    OTP_OTPRDATA3 =  0xf0000a28,
    OTP_OTPRDATAECC =  0xf0000a2c,
    OTP_OTPPROGMODECTRL =  0xf0000a30,

    --PLL
    PLL_PLL_REFSRC =  0xf0001c00,
    PLL_PLL_EN =  0xf0001c04,
    PLL_PLL_CTRL =  0xf0001c08,
    PLL_PLL_ADJ =  0xf0001c0c,
    PLL_PLL_STAT =  0xf0001c10,

    --POLYCAL
    POLYCAL_POLY_CAL_CTRL =  0xf0000600,
    POLYCAL_POLY_CAL_RESULT =  0xf0000604,
    POLYCAL_POLY_CAL_ISNS_BASELINE =  0xf0000608,
    POLYCAL_POLY_CAL_LFOD_BASELINE =  0xf000060c,

    --PowerAcc
    POWERACC_ENABLE_REG =  0xf0001f00,
    POWERACC_I_V_CONFIG =  0xf0001f04,
    POWERACC_P_CONFIG =  0xf0001f08,
    POWERACC_IRMS_CONFIG =  0xf0001f0c,
    POWERACC_AVE_I_RESULT =  0xf0001f10,
    POWERACC_AVE_V_RESULT =  0xf0001f14,
    POWERACC_AVE_P_RESULT =  0xf0001f18,
    POWERACC_IRMS_RESULT =  0xf0001f1c,
    POWERACC_POWER_ACCUM_READ_PORT =  0xf0001f20,
    POWERACC_POWER_ACCUM_READ_PORT_STS =  0xf0001f24,

    --PWM
    PWMTIMER_PWM_CTRL0 =  0xf0001e00,
    PWMTIMER_PWM_PERIOD_COUNT0 =  0xf0001e04,
    PWMTIMER_PWM_HIGH_COUNT0 =  0xf0001e08,
    PWMTIMER_PWM_CTRL1 =  0xf0001e0c,
    PWMTIMER_PWM_PERIOD_COUNT1 =  0xf0001e10,
    PWMTIMER_PWM_HIGH_COUNT1 =  0xf0001e14,
    PWMTIMER_PWM_CTRL2 =  0xf0001e18,
    PWMTIMER_PWM_PERIOD_COUNT2 =  0xf0001e1c,
    PWMTIMER_PWM_HIGH_COUNT2 =  0xf0001e20,
    PWMTIMER_PWM_CTRL3 =  0xf0001e24,
    PWMTIMER_PWM_PERIOD_COUNT3 =  0xf0001e28,
    PWMTIMER_PWM_HIGH_COUNT3 =  0xf0001e2c,

    --PWRMGR
    PWRMANGR_BG_CTRL1 =  0xf0000f00,
    PWRMANGR_BG_CTRL2 =  0xf0000f04,
    PWRMANGR_BG_TRIM1 =  0xf0000f08,
    PWRMANGR_PWRMNGR_STATUS1 =  0xf0000f0c,
    PWRMANGR_TSNSCTRL =  0xf0000f10,
    PWRMANGR_TSNSTSHUTEN =  0xf0000f14,
    PWRMANGR_TSNSPTATTRIM =  0xf0000f18,
    PWRMANGR_TSNSCTATTRIM =  0xf0000f1c,
    PWRMANGR_TSNSALPHATRIM =  0xf0000f20,

    --RCO
    RCO_RCOCTRL1 =  0xf0000500,
    RCO_RCOCTRL2 =  0xf0000504,
    RCO_RCOTEST =  0xf0000508,
    RCO_RCO_TRIM =  0xf000050c,
    RCO_RCO_STATUS =  0xf0000510,
    RCO_CLKDIV1 =  0xf0000524,
    RCO_CLKDIV2 =  0xf0000528,
    RCO_CLKDIV3 =  0xf000052c,
    RCO_CLKDIV4 =  0xf0000530,
    RCO_CLKDIV5 =  0xf0000534,
    RCO_ADC_CLK_TIMEBASE_CFG =  0xf0000538,
    RCO_ADC_CLK_EDGE_CFG =  0xf000053c,
    RCO_ADC_MUX_EN_CFG =  0xf0000540,
    RCO_ADC_SEL_LOADEDGE_CFG =  0xf0000544,

    --RECT
    RECT_RECTSTATE =  0xf0000300,
    RECT_RECTTXCTRL =  0xf0000304,
    RECT_RECTTXCONFIG =  0xf0000308,
    RECT_RECTBOOTCTRL =  0xf000030c,
    RECT_RECTSUPPLY =  0xf0000310,
    RECT_RECTMODECTRL =  0xf0000314,
    RECT_RECTCLAMPTH1 =  0xf0000318,
    RECT_RECTCLAMPTH2 =  0xf000031c,
    RECT_RECTCLAMPTH3 =  0xf0000320,
    RECT_RECTCLAMPCTRL =  0xf0000324,
    RECT_RECTCONFIG =  0xf0000328,
    RECT_RECTCOMMSEL =  0xf000032c,
    RECT_RECTPD =  0xf0000330,
    RECT_RECTCMFIX =  0xf0000334,
    RECT_RECTTRIM =  0xf0000338,
    RECT_RECTTXMINPLS =  0xf000033c,
    RECT_RECTSTARTLOADDIS =  0xf0000340,
    RECT_RECTSPAREIN =  0xf0000344,

    --RINGOSC
    RINGOSC_RING_OSC_SETTINGS1 =  0xf0001d00,
    RINGOSC_RING_OSC_STATUS =  0xf0001d04,
    RINGOSC_RING_OSC_DATA0 =  0xf0001d08,
    RINGOSC_RING_OSC_DATA1 =  0xf0001d0c,
    RINGOSC_RING_OSC_DATA2 =  0xf0001d10,
    RINGOSC_RING_OSC_DATA3 =  0xf0001d14,
    RINGOSC_RING_OSC_DATA4 =  0xf0001d18,
    RINGOSC_RING_OSC_DATA5 =  0xf0001d1c,
    RINGOSC_RING_OSC_DATA6 =  0xf0001d20,
    RINGOSC_RING_OSC_DATA7 =  0xf0001d24,
    RINGOSC_RING_OSC_DATA8 =  0xf0001d28,
    RINGOSC_RING_OSC_DATA9 =  0xf0001d2c,
    RINGOSC_RING_OSC_DATA10 =  0xf0001d30,
    RINGOSC_RING_OSC_DATA11 =  0xf0001d34,
    RINGOSC_RING_OSC_DATA12 =  0xf0001d38,
    RINGOSC_RING_OSC_DATA13 =  0xf0001d3c,
    RINGOSC_RING_OSC_DATA14 =  0xf0001d40,
    RINGOSC_RING_OSC_DATA15 =  0xf0001d44,
    RINGOSC_RING_OSC_DATA16 =  0xf0001d48,
    RINGOSC_RING_OSC_DATA17 =  0xf0001d4c,
    RINGOSC_RING_OSC_DATA18 =  0xf0001d50,
    RINGOSC_RING_OSC_DATA19 =  0xf0001d54,
    RINGOSC_RING_OSC_DATA20 =  0xf0001d58,
    RINGOSC_RING_OSC_DATA21 =  0xf0001d5c,
    RINGOSC_RING_OSC_DATA22 =  0xf0001d60,
    RINGOSC_RING_OSC_DATA23 =  0xf0001d64,
    RINGOSC_RING_OSC_DATA24 =  0xf0001d68,
    RINGOSC_RING_OSC_DATA25 =  0xf0001d6c,
    RINGOSC_RING_OSC_DATA26 =  0xf0001d70,
    RINGOSC_RING_OSC_DATA27 =  0xf0001d74,
    RINGOSC_RING_OSC_DATA28 =  0xf0001d78,
    RINGOSC_RING_OSC_DATA29 =  0xf0001d7c,
    RINGOSC_RING_OSC_DATA30 =  0xf0001d80,
    RINGOSC_RING_OSC_DATA31 =  0xf0001d84,

    --SARADC
    SARADC_ADC_SEQ_EN =  0xf0001000,
    SARADC_ADC_CHAN_CTRL =  0xf0001004,
    SARADC_ADC1_SLOT_SEL1 =  0xf0001008,
    SARADC_ADC1_SLOT_SEL2 =  0xf000100c,
    SARADC_ADC1_SLOT_SEL3 =  0xf0001010,
    SARADC_ADC1_SLOT_SEL4 =  0xf0001014,
    SARADC_ADC1_SLOT_SEL5 =  0xf0001018,
    SARADC_ADC1_SLOT_SEL6 =  0xf000101c,
    SARADC_ADC1_SLOT_SEL7 =  0xf0001020,
    SARADC_ADC1_SLOT_SEL8 =  0xf0001024,
    SARADC_ADC1_SLOT_EN =  0xf0001028,
    SARADC_ADC1_SEQ_CTRL =  0xf000102c,
    SARADC_ADC1_TRIM1 =  0xf0001030,
    SARADC_ADC1_TRIM2 =  0xf0001034,
    SARADC_ADC1_TEST =  0xf000103c,
    SARADC_ADC1_STAT1 =  0xf0001040,
    SARADC_ADC1_STAT2 =  0xf0001044,
    SARADC_ADC1_CONV_MODE =  0xf0001048,
    SARADC_ADC1_MAN_RESULT =  0xf000104c,
    SARADC_ADC1_MAN_CHAN_SEL =  0xf0001050,
    SARADC_ADC1_ACC_RESULT =  0xf0001054,
    SARADC_ADC1_ACC_AMOUNT =  0xf0001058,
    SARADC_ADC1_ACC_CHAN_SEL =  0xf000105c,
    SARADC_ADC1_SLOT_INT_EN =  0xf0001060,
    SARADC_ADC1_INT_EN =  0xf0001064,
    SARADC_ADC1_FRESH =  0xf0001068,
    SARADC_ADC1_FRESH_WITH_DATA_EN =  0xf000106c,
    SARADC_ADC1_RR_OVFL_INT =  0xf0001070,
    SARADC_ADC1_SLOT_DATA0 =  0xf0001080,
    SARADC_ADC1_SLOT_DATA1 =  0xf0001084,
    SARADC_ADC1_SLOT_DATA2 =  0xf0001088,
    SARADC_ADC1_SLOT_DATA3 =  0xf000108c,
    SARADC_ADC1_SLOT_DATA4 =  0xf0001090,
    SARADC_ADC1_SLOT_DATA5 =  0xf0001094,
    SARADC_ADC1_SLOT_DATA6 =  0xf0001098,
    SARADC_ADC1_SLOT_DATA7 =  0xf000109c,
    SARADC_ADC1_SLOT_DATA8 =  0xf00010a0,
    SARADC_ADC1_SLOT_DATA9 =  0xf00010a4,
    SARADC_ADC1_SLOT_DATA10 =  0xf00010a8,
    SARADC_ADC1_SLOT_DATA11 =  0xf00010ac,
    SARADC_ADC1_SLOT_DATA12 =  0xf00010b0,
    SARADC_ADC1_SLOT_DATA13 =  0xf00010b4,
    SARADC_ADC1_SLOT_DATA14 =  0xf00010b8,
    SARADC_ADC1_SLOT_DATA15 =  0xf00010bc,
    SARADC_ADC1_SLOT_DATA16 =  0xf00010c0,
    SARADC_ADC1_SLOT_DATA17 =  0xf00010c4,
    SARADC_ADC1_SLOT_DATA18 =  0xf00010c8,
    SARADC_ADC1_SLOT_DATA19 =  0xf00010cc,
    SARADC_ADC1_SLOT_DATA20 =  0xf00010d0,
    SARADC_ADC1_SLOT_DATA21 =  0xf00010d4,
    SARADC_ADC1_SLOT_DATA22 =  0xf00010d8,
    SARADC_ADC1_SLOT_DATA23 =  0xf00010dc,
    SARADC_ADC1_SLOT_DATA24 =  0xf00010e0,
    SARADC_ADC1_SLOT_DATA25 =  0xf00010e4,
    SARADC_ADC1_SLOT_DATA26 =  0xf00010e8,
    SARADC_ADC1_SLOT_DATA27 =  0xf00010ec,
    SARADC_ADC1_SLOT_DATA28 =  0xf00010f0,
    SARADC_ADC1_SLOT_DATA29 =  0xf00010f4,
    SARADC_ADC1_SLOT_DATA30 =  0xf00010f8,
    SARADC_ADC1_SLOT_DATA31 =  0xf00010fc,
    SARADC_ADC2_SLAVE =  0xf0001100,
    SARADC_ADC2_SLOT_SEL1 =  0xf0001104,
    SARADC_ADC2_SLOT_SEL2 =  0xf0001108,
    SARADC_ADC2_SLOT_SEL3 =  0xf000110c,
    SARADC_ADC2_SLOT_SEL4 =  0xf0001110,
    SARADC_ADC2_SLOT_SEL5 =  0xf0001114,
    SARADC_ADC2_SLOT_SEL6 =  0xf0001118,
    SARADC_ADC2_SLOT_SEL7 =  0xf000111c,
    SARADC_ADC2_SLOT_SEL8 =  0xf0001120,
    SARADC_ADC2_SLOT_EN =  0xf0001124,
    SARADC_ADC2_SEQ_CTRL =  0xf000112c,
    SARADC_ADC2_TRIM1 =  0xf0001130,
    SARADC_ADC2_TRIM2 =  0xf0001134,
    SARADC_ADC2_ISNS_TRIM =  0xf0001138,
    SARADC_ADC2_TEST =  0xf000113c,
    SARADC_ADC2_STAT1 =  0xf0001140,
    SARADC_ADC2_STAT2 =  0xf0001144,
    SARADC_ADC2_CONV_MODE =  0xf0001148,
    SARADC_ADC2_MAN_RESULT =  0xf000114c,
    SARADC_ADC2_MAN_CHAN_SEL =  0xf0001150,
    SARADC_ADC2_ACC_RESULT =  0xf0001154,
    SARADC_ADC2_ACC_AMOUNT =  0xf0001158,
    SARADC_ADC2_ACC_CHAN_SEL =  0xf000115c,
    SARADC_ADC2_SLOT_INT_EN =  0xf0001160,
    SARADC_ADC2_INT_EN =  0xf0001164,
    SARADC_ADC2_FRESH =  0xf0001168,
    SARADC_ADC2_FRESH_WITH_DATA_EN =  0xf000116c,
    SARADC_ADC2_RR_OVFL_INT =  0xf0001170,
    SARADC_ADC2_SLOT_DATA0 =  0xf0001180,
    SARADC_ADC2_SLOT_DATA1 =  0xf0001184,
    SARADC_ADC2_SLOT_DATA2 =  0xf0001188,
    SARADC_ADC2_SLOT_DATA3 =  0xf000118c,
    SARADC_ADC2_SLOT_DATA4 =  0xf0001190,
    SARADC_ADC2_SLOT_DATA5 =  0xf0001194,
    SARADC_ADC2_SLOT_DATA6 =  0xf0001198,
    SARADC_ADC2_SLOT_DATA7 =  0xf000119c,
    SARADC_ADC2_SLOT_DATA8 =  0xf00011a0,
    SARADC_ADC2_SLOT_DATA9 =  0xf00011a4,
    SARADC_ADC2_SLOT_DATA10 =  0xf00011a8,
    SARADC_ADC2_SLOT_DATA11 =  0xf00011ac,
    SARADC_ADC2_SLOT_DATA12 =  0xf00011b0,
    SARADC_ADC2_SLOT_DATA13 =  0xf00011b4,
    SARADC_ADC2_SLOT_DATA14 =  0xf00011b8,
    SARADC_ADC2_SLOT_DATA15 =  0xf00011bc,
    SARADC_ADC2_SLOT_DATA16 =  0xf00011c0,
    SARADC_ADC2_SLOT_DATA17 =  0xf00011c4,
    SARADC_ADC2_SLOT_DATA18 =  0xf00011c8,
    SARADC_ADC2_SLOT_DATA19 =  0xf00011cc,
    SARADC_ADC2_SLOT_DATA20 =  0xf00011d0,
    SARADC_ADC2_SLOT_DATA21 =  0xf00011d4,
    SARADC_ADC2_SLOT_DATA22 =  0xf00011d8,
    SARADC_ADC2_SLOT_DATA23 =  0xf00011dc,
    SARADC_ADC2_SLOT_DATA24 =  0xf00011e0,
    SARADC_ADC2_SLOT_DATA25 =  0xf00011e4,
    SARADC_ADC2_SLOT_DATA26 =  0xf00011e8,
    SARADC_ADC2_SLOT_DATA27 =  0xf00011ec,
    SARADC_ADC2_SLOT_DATA28 =  0xf00011f0,
    SARADC_ADC2_SLOT_DATA29 =  0xf00011f4,
    SARADC_ADC2_SLOT_DATA30 =  0xf00011f8,
    SARADC_ADC2_SLOT_DATA31 =  0xf00011fc,
    SARADC_ADC_PRODACC_EN =  0xf0001200,
    SARADC_ADC_PRODACC_LOW =  0xf0001204,
    SARADC_ADC_PRODACC_HIGH =  0xf0001208,

    --SERIAL
    SERIAL_SERCTRL1 =  0xf0000700,
    SERIAL_SERCTRL2 =  0xf0000704,
    SERIAL_SERFIFO_ENTRY =  0xf0000708,
    SERIAL_SERFIFO_STATUS =  0xf0000710,

    --SPMI
    SPMI_REG0_REGISTER =  0xf0009000,
    SPMI_SPM_INT_ENABLE =  0xf0009004,
    SPMI_SPM_INT_STATUS =  0xf0009008,
    SPMI_SPM_VERSION =  0xf000900c,
    SPMI_SPM_AHB_MST_BASE_ADDR0 =  0xf0009010,
    SPMI_SPM_AHB_MST_BASE_ADDR1 =  0xf0009014,
    SPMI_SPM_MAILBOX_WRITE_DATA =  0xf0009018,
    SPMI_SPM_MAILBOX_READ_DATA =  0xf000901c,
    SPMI_SPM_MAILBOX_WRITE_TH =  0xf0009020,
    SPMI_SPM_MAILBOX_READ_TH =  0xf0009024,
    SPMI_SPM_MAILBOX_WR_STATUS =  0xf0009028,
    SPMI_SPM_MAILBOX_RD_STATUS =  0xf000902c,
    SPMI_SPM_MAILBOX_WR_FIFO_DEPTH =  0xf0009030,
    SPMI_SPM_MAILBOX_RD_FIFO_DEPTH =  0xf0009034,
    SPMI_SPM_MAILBOX_WR_FIFO_AVAIL =  0xf0009038,
    SPMI_SPM_MAILBOX_RD_FIFO_AVAIL =  0xf000903c,
    SPMI_SPM_MAILBOX_FIFO_FLUSH =  0xf0009040,
    SPMI_SPM_READ_LATENCY_RW =  0xf0009044,
    SPMI_SPM_DEVICE_CAPABILITY =  0xf0009048,
    SPMI_SPM_TBT_DIVIDER_LO =  0xf000904c,
    SPMI_SPM_TBT_DIVIDER_HIGH =  0xf0009050,
    SPMI_SPM_REQ_COMMAND =  0xf0009054,
    SPMI_SPM_REQ_SLVA_BC =  0xf0009058,
    SPMI_SPM_REQ_ADDRESS_LO =  0xf000905c,
    SPMI_SPM_REQ_ADDRESS_HIGH =  0xf0009060,
    SPMI_SPM_REQ_FREE_LO =  0xf0009064,
    SPMI_SPM_REQ_FREE_HIGH =  0xf0009068,
    SPMI_SPM_REQ_RETRY_LIMIT =  0xf000906c,
    SPMI_SPM_REQ_COMMAND_STATUS =  0xf0009070,
    SPMI_SPM_DEBUG_SEL =  0xf0009074,
    SPMI_SPM_STATUS =  0xf0009078,
    SPMI_SPM_SPMI_0LAT_REG_ADDR =  0xf000907c,
    SPMI_SPM_REQ_AUTO_FREE_LO =  0xf0009080,
    SPMI_SPM_REQ_AUTO_FREE_HIGH =  0xf0009084,
    SPMI_SPM_REQ_CONTROL =  0xf0009088,
    SPMI_SPM_REQ_HOLD_TIMEOUT_LO =  0xf000908c,
    SPMI_SPM_REQ_HOLD_TIMEOUT_HIGH =  0xf0009090,
    SPMI_SPM_SPMI_RST_WIDTH =  0xf0009094,
    SPMI_SPM_IRQH_RST_CONTROL =  0xf0009098,
    SPMI_SPM_REQ_WR_DATA0 =  0xf000909c,
    SPMI_SPM_REQ_WR_DATA1 =  0xf00090a0,
    SPMI_SPM_REQ_WR_DATA2 =  0xf00090a4,
    SPMI_SPM_REQ_WR_DATA3 =  0xf00090a8,
    SPMI_SPM_REQ_WR_DATA4 =  0xf00090ac,
    SPMI_SPM_REQ_WR_DATA5 =  0xf00090b0,
    SPMI_SPM_REQ_WR_DATA6 =  0xf00090b4,
    SPMI_SPM_REQ_WR_DATA7 =  0xf00090b8,
    SPMI_SPM_REQ_WR_DATA8 =  0xf00090bc,
    SPMI_SPM_REQ_WR_DATA9 =  0xf00090c0,
    SPMI_SPM_REQ_WR_DATA10 =  0xf00090c4,
    SPMI_SPM_REQ_WR_DATA11 =  0xf00090c8,
    SPMI_SPM_REQ_WR_DATA12 =  0xf00090cc,
    SPMI_SPM_REQ_WR_DATA13 =  0xf00090d0,
    SPMI_SPM_REQ_WR_DATA14 =  0xf00090d4,
    SPMI_SPM_REQ_WR_DATA15 =  0xf00090d8,
    SPMI_SPM_REQ_RD_STATUS0 =  0xf00090dc,
    SPMI_SPM_REQ_RD_STATUS1 =  0xf00090e0,
    SPMI_SPM_REQ_RD_STATUS2 =  0xf00090e4,
    SPMI_SPM_REQ_RD_STATUS3 =  0xf00090e8,
    SPMI_SPM_REQ_RD_STATUS4 =  0xf00090ec,
    SPMI_SPM_REQ_RD_STATUS5 =  0xf00090f0,
    SPMI_SPM_REQ_RD_STATUS6 =  0xf00090f4,
    SPMI_SPM_REQ_RD_STATUS7 =  0xf00090f8,
    SPMI_SPM_REQ_RD_STATUS8 =  0xf00090fc,
    SPMI_SPM_REQ_RD_STATUS9 =  0xf0009100,
    SPMI_SPM_REQ_RD_STATUS10 =  0xf0009104,
    SPMI_SPM_REQ_RD_STATUS11 =  0xf0009108,
    SPMI_SPM_REQ_RD_STATUS12 =  0xf000910c,
    SPMI_SPM_REQ_RD_STATUS13 =  0xf0009110,
    SPMI_SPM_REQ_RD_STATUS14 =  0xf0009114,
    SPMI_SPM_REQ_RD_STATUS15 =  0xf0009118,
    SPMI_SPM_SLV_COMMAND =  0xf000911c,
    SPMI_SPM_SLV_BC =  0xf0009120,
    SPMI_SPM_SLV_ADDRESS_BO =  0xf0009124,
    SPMI_SPM_SLV_ADDRESS_B1 =  0xf0009128,
    SPMI_SPM_SLV_ADDRESS_B2 =  0xf000912c,
    SPMI_SPM_SLV_ADDRESS_B3 =  0xf0009130,
    SPMI_SPM_SLV_DATA0 =  0xf0009134,
    SPMI_SPM_SLV_DATA1 =  0xf0009138,
    SPMI_SPM_SLV_DATA2 =  0xf000913c,
    SPMI_SPM_SLV_DATA3 =  0xf0009140,
    SPMI_SPM_SLV_DATA4 =  0xf0009144,
    SPMI_SPM_SLV_DATA5 =  0xf0009148,
    SPMI_SPM_SLV_DATA6 =  0xf000914c,
    SPMI_SPM_SLV_DATA7 =  0xf0009150,
    SPMI_SPM_SLV_DATA8 =  0xf0009154,
    SPMI_SPM_SLV_DATA9 =  0xf0009158,
    SPMI_SPM_SLV_DATA10 =  0xf000915c,
    SPMI_SPM_SLV_DATA11 =  0xf0009160,
    SPMI_SPM_SLV_DATA12 =  0xf0009164,
    SPMI_SPM_SLV_DATA13 =  0xf0009168,
    SPMI_SPM_SLV_DATA14 =  0xf000916c,
    SPMI_SPM_SLV_DATA15 =  0xf0009170,
    SPMI_SPM_CONTROL =  0xf0009174,
    SPMI_SPM_INT_ENABLE2 =  0xf0009178,
    SPMI_SPM_INT_STATUS2 =  0xf000917c,
    SPMI_SPM_INT_ENABLE3 =  0xf0009180,
    SPMI_SPM_INT_STATUS3 =  0xf0009184,
    SPMI_SPM_GSID_CONTROL =  0xf0009188,
    SPMI_SPM_HREADY_TIMEOUT_CONTROL =  0xf000918c,
    SPMI_SPM_SPMI_ERROR_STATUS =  0xf0009190,
    SPMI_SPM_AUTO_2D_8B_0 =  0xf0009240,
    SPMI_SPM_AUTO_2D_8B_1 =  0xf0009244,
    SPMI_SPM_AUTO_2D_8B_2 =  0xf0009248,
    SPMI_SPM_AUTO_2D_8B_3 =  0xf000924c,
    SPMI_SPM_AUTO_2D_8B_4 =  0xf0009250,
    SPMI_SPM_AUTO_2D_8B_5 =  0xf0009254,
    SPMI_SPM_AUTO_2D_8B_6 =  0xf0009258,
    SPMI_SPM_AUTO_2D_8B_7 =  0xf000925c,
    SPMI_SPM_DDB_2D_8B_0 =  0xf0009280,
    SPMI_SPM_DDB_2D_8B_1 =  0xf0009284,
    SPMI_SPM_DDB_2D_8B_2 =  0xf0009288,
    SPMI_SPM_DDB_2D_8B_3 =  0xf000928c,
    SPMI_SPM_DDB_2D_8B_4 =  0xf0009290,
    SPMI_SPM_DDB_2D_8B_5 =  0xf0009294,
    SPMI_SPM_DDB_2D_8B_6 =  0xf0009298,
    SPMI_SPM_DDB_2D_8B_7 =  0xf000929c,
    SPMI_SPM_DDB_2D_8B_8 =  0xf00092a0,
    SPMI_SPM_DDB_2D_8B_9 =  0xf00092a4,
    SPMI_SPM_SPMI_CTRL =  0xf0009400,
    SPMI_SPM_SPMI_REVISION =  0xf0009404,
    SPMI_SPM_MASTER_HOST_ID =  0xf0009408,
    SPMI_SPM_READ_LATENCY =  0xf000940c,
    SPMI_SPM_INTERRUPT_ADDR =  0xf0009410,
    SPMI_SPM_INTERRUPT_OFFSET =  0xf0009414,
    SPMI_SPM_DEVICE_CAPABILITY_TYPE =  0xf0009418,
    SPMI_SPM_DEVICE_CAPABILITY_CMD =  0xf000941c,
    SPMI_SPM_INTERRUPT_VW_ADDR =  0xf0009420,

    --SSP
    SSP_SSPCR0 =  0xf0002000,
    SSP_SSPCR1 =  0xf0002004,
    SSP_SSPDR =  0xf0002008,
    SSP_SSPSR =  0xf000200c,
    SSP_SSPCPSR =  0xf0002010,
    SSP_SSPIMSC =  0xf0002014,
    SSP_SSPRIS =  0xf0002018,
    SSP_SSPMIS =  0xf000201c,
    SSP_SSPICR =  0xf0002020,
    SSP_SSPDMACR =  0xf0002024,
    SSP_SSPTCR =  0xf0002080,
    SSP_SSPITIP =  0xf0002084,
    SSP_SSPITOP =  0xf0002088,
    SSP_SSPTDR =  0xf000208c,
    SSP_SSPPERIPHID0 =  0xf0002fe0,
    SSP_SSPPERIPHID1 =  0xf0002fe4,
    SSP_SSPPERIPHID2 =  0xf0002fe8,
    SSP_SSPPERIPHID3 =  0xf0002fec,
    SSP_SSPPCELLID0 =  0xf0002ff0,
    SSP_SSPPCELLID1 =  0xf0002ff4,
    SSP_SSPPCELLID2 =  0xf0002ff8,
    SSP_SSPPCELLID3 =  0xf0002ffc,

    --SYSSAVE
    SYSSAVE_SAVE_HW_STATUS =  0xf0000200,
    SYSSAVE_FW1 =  0xf0000204,
    SYSSAVE_FW2 =  0xf0000208,
    SYSSAVE_FW3 =  0xf000020c,
    SYSSAVE_FW4 =  0xf0000210,

    --SYSTEM
    SYSTEM_CHIP_ID =  0xf0000000,
    SYSTEM_HW_STATUS =  0xf0000004,
    SYSTEM_FW =  0xf0000008,
    SYSTEM_SCRATCH0 =  0xf000000c,
    SYSTEM_SCRATCH1 =  0xf0000010,
    SYSTEM_SYSCTRL1 =  0xf0000014,
    SYSTEM_LPM_TIMER_VAL =  0xf0000018,
    SYSTEM_LPM_VDD2_WAIT =  0xf000001c,
    SYSTEM_LPM_REASON =  0xf0000020,
    SYSTEM_LOW_POWER_MODE =  0xf0000024,
    SYSTEM_SYSTEM_INT =  0xf0000028,
    SYSTEM_BROWNOUT =  0xf000002c,
    SYSTEM_SOFTWARE_INT =  0xf0000034,
    SYSTEM_ANALOG_REV =  0xf0000038,
    SYSTEM_FAULT_CTRL =  0xf0000044,
    SYSTEM_FAULT =  0xf0000048,
    SYSTEM_UNIQUE_ID1 =  0xf000004c,
    SYSTEM_UNIQUE_ID2 =  0xf0000050,
    SYSTEM_SYSTEM_CONFIG =  0xf0000054,
    SYSTEM_SPMICTRL =  0xf0000058,
    SYSTEM_INT_CTRL_0 =  0xf000005c,
    SYSTEM_INT_CTRL_1 =  0xf0000060,
    SYSTEM_INT_CTRL_2 =  0xf0000064,
    SYSTEM_INT_CTRL_3 =  0xf0000068,
    SYSTEM_INT_CTRL_4 =  0xf000006c,
    SYSTEM_INT_CTRL_5 =  0xf0000070,
    SYSTEM_INT_CTRL_6 =  0xf0000074,
    SYSTEM_INT_CTRL_7 =  0xf0000078,
    SYSTEM_INT_CTRL_8 =  0xf000007c,
    SYSTEM_INT_CTRL_9 =  0xf0000080,
    SYSTEM_CMPENSEPTIME =  0xf0000084,
    SYSTEM_DMA_RQST_CLEAR =  0xf0000090,
    SYSTEM_DMA_RQST_SELECT_REG0 =  0xf0000094,
    SYSTEM_DMA_RQST_SELECT_REG1 =  0xf0000098,
    SYSTEM_CRYPTO_SRAM_CTRL =  0xf000009c,
    SYSTEM_RAM_PWRSW_CTRL =  0xf00000a0,
    SYSTEM_SPMI_0LAT_CONFIG_INFO =  0xf00000a4,
    SYSTEM_SPMI_0LAT_ID_INFO =  0xf00000a8,
    SYSTEM_SPMI_0LAT_IADRS_INFO =  0xf00000ac,
    SYSTEM_SPMI_RCS_ACCESS_LIST =  0xf00000b0,
    SYSTEM_SPMI_SECURITY_INT_EN =  0xf00000b4,
    SYSTEM_SPMI_SECURITY_INT_STS =  0xf00000b8,
    SYSTEM_SPMI_SECURE_LOG =  0xf00000bc,
    SYSTEM_FW_BLOCK_RESET =  0xf00000c0,
    SYSTEM_SPMI_ADDR_MATCH_CLR =  0xf00000c4,
    SYSTEM_FW_TRIMREG1 =  0xf00000c8,
    SYSTEM_FW_TRIMREG2 =  0xf00000cc,
    SYSTEM_FW_TRIMREG3 =  0xf00000d0,
    SYSTEM_FW_TRIMREG4 =  0xf00000d4,
    SYSTEM_ROMCTRL =  0xf00000d8,
    SYSTEM_ANATOPSPARE =  0xf00000dc,
    SYSTEM_UNIQIDLOCK =  0xf00000e0,
    SYSTEM_SPMI_STATUS_DEBUG =  0xf00000e4,

    --TIMER
    TIMER_TIMER1_CONTROL =  0xf0001300,
    TIMER_TIMER1_MAXCOUNT =  0xf0001304,
    TIMER_TIMER1_STATUS =  0xf0001308,
    TIMER_TIMER2_CONTROL =  0xf000130c,
    TIMER_TIMER2_MAXCOUNT =  0xf0001310,
    TIMER_TIMER2_STATUS =  0xf0001314,

    --WDT
    WDT_WDTCTRL =  0xf0000400,
    WDT_WDTCLR =  0xf0000404,
    WDT_WDTTIME_LOW =  0xf0000408,
    WDT_WDTTIME_HIGH =  0xf000040c,
    }


-- TODO: Replace with EFI function
local function int2signed16bit(c) --By Zach Harris
-- USAGE, this will not work if c > 16bit
    if c == 0 then return 0.0 end
    local n

    if c < 0 then
        n = (c + 2^16)
    else
        n = c
    end

    return n
end


function ReadRDSONCal(TSNS)
    require "Burnin"

    -- funtion that reads 32 bits and splits it into four bytes and then converting each byte to a 2s complement int
    local function ReadAndMask(read_address)

        local raw_data = DotaraRead32(read_address)
        local bytemask_bit8 = 0xFF
        local bytemask_bit7 = 0x7F
        -- second and fourth bytes are in 7bit 2s complement format, as opposed to 8 bit
        local signed_bytes = {
            two_comp_to_signed(bit32.band(bit32.rshift(raw_data,0),bytemask_bit8), 8),
            two_comp_to_signed(bit32.band(bit32.rshift(raw_data,8),bytemask_bit7), 7),
            two_comp_to_signed(bit32.band(bit32.rshift(raw_data,16),bytemask_bit8), 8),
            two_comp_to_signed(bit32.band(bit32.rshift(raw_data,24),bytemask_bit7), 7)
        }
        PrintString(string.format('Reading calibration from address: %08x', read_address))
        PrintString(string.format('1) %d\n2)%d\n3) %d\n4) %d\n',signed_bytes[1],signed_bytes[2],signed_bytes[3],signed_bytes[4]))
        return signed_bytes
    end
    
    -- Read all calibration values for RDSON
    local SYSTEM_FW_TRIMREG1 = ReadAndMask(registers.SYSTEM_FW_TRIMREG1)
    local SYSTEM_FW_TRIMREG2 = ReadAndMask(registers.SYSTEM_FW_TRIMREG2)
    local SYSTEM_FW_TRIMREG3 = ReadAndMask(registers.SYSTEM_FW_TRIMREG3)
    local SYSTEM_FW_TRIMREG4 = ReadAndMask(registers.SYSTEM_FW_TRIMREG4)

    -- Calculate AC1 and Clamp 1 RDSON calibration
    local RDSON_Calibration = {
        -- RDSON of inverter FETs at full drive and room temp
        AC1_LS_FD_ROOM = 1e-3*(55 + 0.25*SYSTEM_FW_TRIMREG1[1]),
        AC1_HS_FD_ROOM = 1e-3*(55 + 0.25*SYSTEM_FW_TRIMREG1[3]),
        -- RDSON of inverter FETs at quarter drive and room temp
        AC1_LS_QD_ROOM = 1e-3*(220 + 1*SYSTEM_FW_TRIMREG2[1]),
        AC1_HS_QD_ROOM = 1e-3*(220 + 1*SYSTEM_FW_TRIMREG2[3]),
        -- RDSON of Clamp FETs at full drive at room temp and hot temp
        CLAMP1_ROOM = 1e-3*(1000 + 5*SYSTEM_FW_TRIMREG3[1]),
        CLAMP1_HOT = 1e-3*(1000 + 5*SYSTEM_FW_TRIMREG3[3]),
        -- RDSON of inverter FETs at full drive and hot temp
        AC1_LS_FD_HOT = 1e-3*(55 + 0.25*SYSTEM_FW_TRIMREG4[1]),
        AC1_HS_FD_HOT = 1e-3*(55 + 0.25*SYSTEM_FW_TRIMREG4[3])
    }
    -- Calculate AC2 and Clamp 2 RDSON calibration
    RDSON_Calibration.AC2_LS_FD_ROOM = 1e-3*(1e3*RDSON_Calibration.AC1_LS_FD_ROOM + 0.25*SYSTEM_FW_TRIMREG1[2])
    RDSON_Calibration.AC2_HS_FD_ROOM = 1e-3*(1e3*RDSON_Calibration.AC1_HS_FD_ROOM + 0.25*SYSTEM_FW_TRIMREG1[4])
    RDSON_Calibration.AC2_LS_QD_ROOM = 1e-3*(1e3*RDSON_Calibration.AC1_LS_QD_ROOM + 1*SYSTEM_FW_TRIMREG2[2])
    RDSON_Calibration.AC2_HS_QD_ROOM = 1e-3*(1e3*RDSON_Calibration.AC1_HS_QD_ROOM + 1*SYSTEM_FW_TRIMREG2[4])
    RDSON_Calibration.CLAMP2_ROOM = 1e-3*(1e3*RDSON_Calibration.CLAMP1_ROOM + 5*SYSTEM_FW_TRIMREG3[2])
    RDSON_Calibration.CLAMP2_HOT = 1e-3*(1e3*RDSON_Calibration.CLAMP1_HOT + 5*SYSTEM_FW_TRIMREG3[4])
    RDSON_Calibration.AC2_LS_FD_HOT = 1e-3*(1e3*RDSON_Calibration.AC1_LS_FD_HOT + 0.25*SYSTEM_FW_TRIMREG4[2])
    RDSON_Calibration.AC2_HS_FD_HOT = 1e-3*(1e3*RDSON_Calibration.AC1_HS_FD_HOT + 0.25*SYSTEM_FW_TRIMREG4[4])

    -- Estimate AC1/AC2 LS/HS QD HOT based on FD results
    local ratio_ac1 = RDSON_Calibration.AC1_LS_FD_HOT/RDSON_Calibration.AC1_LS_FD_ROOM
    local ratio_ac2 = RDSON_Calibration.AC2_LS_FD_HOT/RDSON_Calibration.AC2_LS_FD_ROOM
    RDSON_Calibration.AC1_LS_QD_HOT = RDSON_Calibration.AC1_LS_QD_ROOM * ratio_ac1
    RDSON_Calibration.AC1_HS_QD_HOT = RDSON_Calibration.AC1_HS_QD_ROOM * ratio_ac1
    RDSON_Calibration.AC2_LS_QD_HOT = RDSON_Calibration.AC2_LS_QD_ROOM * ratio_ac2
    RDSON_Calibration.AC2_HS_QD_HOT = RDSON_Calibration.AC2_HS_QD_ROOM * ratio_ac2

    -- Read calibration temperatures
    local ISNS_ISNSTSNS = DotaraRead32(registers.ISNS_ISNSTSNS)
    local THOT = bit32.band(bit32.rshift(ISNS_ISNSTSNS,0),0xFF)
    local TROOM = bit32.band(bit32.rshift(ISNS_ISNSTSNS,16),0xFF)
    RDSON_Calibration.THOT = THOT
    RDSON_Calibration.TROOM = TROOM

    -- Only required for P1 units that do not have calibration implemented yet
    if THOT==0 or TROOM==0 then
        TROOM = 25
        THOT = 85
    end

    -- Print calibration data
    PrintString('RDSON Calibration Data:')
    for k in pairs(RDSON_Calibration) do
        PrintString(k .. ': ' .. RDSON_Calibration[k] .. ' Ohm')
    end
    PrintString('TSNS Room: ' .. TROOM .. ' degC')
    PrintString('TSNS Hot: ' .. THOT .. ' degC')

    -- Perform temperature compensation 
    local function t_compensate(R_hot, R_nom, T_hot, Tnom, Tnow)
        local gradient = (R_hot -  R_nom) / (T_hot - Tnom)
        local R_compensated = R_nom + gradient * (Tnow - Tnom)
        return R_compensated
    end

    -- Temperature compensation using broadcom cal
    RDSON_Calibration.AC1_LS_FD_COMP = t_compensate(RDSON_Calibration.AC1_LS_FD_HOT, RDSON_Calibration.AC1_LS_FD_ROOM, THOT, TROOM, TSNS)
    RDSON_Calibration.AC2_LS_FD_COMP = t_compensate(RDSON_Calibration.AC2_LS_FD_HOT, RDSON_Calibration.AC2_LS_FD_ROOM, THOT, TROOM, TSNS)
    RDSON_Calibration.AC1_LS_QD_COMP = t_compensate(RDSON_Calibration.AC1_LS_QD_HOT, RDSON_Calibration.AC1_LS_QD_ROOM, THOT, TROOM, TSNS)
    RDSON_Calibration.AC2_LS_QD_COMP = t_compensate(RDSON_Calibration.AC2_LS_QD_HOT, RDSON_Calibration.AC2_LS_QD_ROOM, THOT, TROOM, TSNS)
    RDSON_Calibration.CLAMP2_COMP = RDSON_Calibration.AC2_LS_QD_COMP*4.363 ------- Improved accuracy compared to internal cal for clamp according to Broadcom 
    RDSON_Calibration.RDSON_DELTA_COMP1 = (RDSON_Calibration.AC1_LS_QD_COMP-RDSON_Calibration.AC1_LS_FD_COMP)+(RDSON_Calibration.AC2_LS_QD_COMP-RDSON_Calibration.AC2_LS_FD_COMP) --- for reference of previous Rsys calculation
    RDSON_Calibration.RDSON_DELTA_COMP = ((RDSON_Calibration.AC2_LS_QD_ROOM-RDSON_Calibration.AC2_LS_FD_ROOM)+(RDSON_Calibration.AC1_LS_QD_ROOM-RDSON_Calibration.AC1_LS_FD_ROOM))*(1+1e-6*3700*(TSNS - TROOM)) 

    PrintString('Temperature compensated RDSON:')
    PrintString(string.format('RDSON Temperature Compensation [%.2f, %.2f, %.2f]', TROOM, TSNS, THOT))
    PrintString('AC1_LS_FD_COMP: ' .. RDSON_Calibration.AC1_LS_FD_COMP)
    PrintString('AC2_LS_FD_COMP: ' .. RDSON_Calibration.AC2_LS_FD_COMP)
    PrintString('AC1_LS_QD_COMP: ' .. RDSON_Calibration.AC1_LS_QD_COMP)
    PrintString('AC2_LS_QD_COMP: ' .. RDSON_Calibration.AC2_LS_QD_COMP)
    PrintString('CLAMP2_COMP: ' .. RDSON_Calibration.CLAMP2_COMP)
    PrintString('RDSON_DELTA_COMP: ' .. RDSON_Calibration.RDSON_DELTA_COMP)



    -- Track delta compared to past temp comp method
    local approx_comp_factor = (TSNS+273.15)/300
    local internal_comp_factor = RDSON_Calibration.AC2_LS_QD_COMP / RDSON_Calibration.AC2_LS_QD_ROOM
    RDSON_Calibration.temp_comp_rel = internal_comp_factor/approx_comp_factor
    PrintString('This script uses the vendor side calibration for Temp Comp')
    PrintString('internal compensation / approx compensation: ' .. RDSON_Calibration.temp_comp_rel)
    
    return RDSON_Calibration
end


-- This function writes a syscfg key according to rdar://70357328 and rdar://70357610
function sysCFG_write(WChSysCfgKey)
    -- WChSysCfgKey should have the following format:
    -- WChSysCfgKey = {name = '', numPairs = 7, info = 0x1234, calibrationPairs={}, checksum = nil}
    -- Calibration pairs should have format:
    -- calibrationPairs[1] = {offset = 0, data= 0}

    -- function to swap endianess with regards to bytes
    local function swap_endianness(word32, numbytes)
        word32 = bit32.band(word32,0xFFFFFFFF)
        local word32_r = 0
        for byte_idx = 1,numbytes do
            local byte = bit32.band(bit32.rshift(word32,8*(byte_idx-1)),0xFF)
            word32_r = bit32.bor(word32_r,bit32.lshift(byte,(numbytes-byte_idx)*8))
        end
        return word32_r
    end

    -- Convert two uint16 numbers to hex, swap order and then change endianess for addbyte command
    local function numbers_to_32word(number_a, number_b, endian_flip)
        local word32 = bit32.bor(
            bit32.lshift(bit32.band(0xFFFF,number_b),16),
            bit32.band(0xFFFF,number_a)
        )
        if (endian_flip==nil) or (endian_flip==true) then
            return string.format('%08x',swap_endianness(word32,4))
        else
            return string.format('%08x',word32)
        end
    end

    PrintString('##################### Writing the syscfg key ' .. WChSysCfgKey.name .. ' ############################')

    -- Build command to write syscfg key and calculate checksum
    PrintString('numPairs: ' .. WChSysCfgKey.numPairs .. ', info: ' .. WChSysCfgKey.info .. ', hex: 0x' .. numbers_to_32word(WChSysCfgKey.numPairs, WChSysCfgKey.info, false))
    local add_sysCFG_command = 'syscfg addbyte ' .. WChSysCfgKey.name .. ' ' .. numbers_to_32word(WChSysCfgKey.numPairs, WChSysCfgKey.info)
    WChSysCfgKey.checksum = bit32.bxor(WChSysCfgKey.numPairs, WChSysCfgKey.info)
    for i,v in ipairs(WChSysCfgKey.calibrationPairs) do
        PrintString('Calibration Pair [' .. i .. ']: offset=' .. v.offset .. ', data=' .. v.data .. ', hex: 0x' .. numbers_to_32word(v.offset, v.data, false))
        add_sysCFG_command = add_sysCFG_command .. ' ' .. numbers_to_32word(v.offset, v.data)
        WChSysCfgKey.checksum = bit32.bxor(WChSysCfgKey.checksum, v.offset)
        WChSysCfgKey.checksum = bit32.bxor(WChSysCfgKey.checksum, v.data)
    end

    -- Generate checksum
    WChSysCfgKey.checksum = bit32.band(WChSysCfgKey.checksum,0xFFFF)
    PrintString('checksum: ' .. WChSysCfgKey.checksum .. string.format(', hex: 0x%04x',WChSysCfgKey.checksum))
    add_sysCFG_command = add_sysCFG_command .. string.format(' %04x',swap_endianness(WChSysCfgKey.checksum, 2))

    -- Execute syscfg write command
    Shell(add_sysCFG_command)
end


-- This function reads sysconfig keys WCh0 or WCh1 and returns a datastructure with the data
function sysCFG_read(name, numPairs)
    -- Create syscfg key structure and a raw results table
    local WChSysCfgKey = {name = name, numPairs = numPairs, info = nil, calibrationPairs={}, checksum = nil}
    local raw_data = {}

    -- function to convert numbers to hex
    local function hex32_to_uint16(hex32_data)
        -- Split 32bit hex into two 16bit parts
        local hex_data_a = bit32.band(tonumber(hex32_data,16),0xFFFF)
        local hex_data_b = bit32.band(bit32.rshift(tonumber(hex32_data,16),16),0xFFFF)

        -- return uint16's
        return hex_data_a, hex_data_b
    end

    PrintString('##################### Reading the syscfg key ' .. WChSysCfgKey.name .. ' ############################')
    
    -- Execute command to read the syscfg key
    Shell('syscfg print ' .. name)
    local syscfg_data = Last.Output

    -- Print error if the key does not exist
    if string.match(syscfg_data,'Not Found!') then
        PrintString('Error could not find this key')
        WChSysCfgKey.numPairs = 0
    else
        -- PrintString('match_string: '.. matching_string)
        local result_idx = 1
        for word_match in string.gmatch(syscfg_data, '0x(%w+)') do
            raw_data[result_idx] = word_match
            result_idx = result_idx + 1
        end
        -- Process the raw data
        for idx = 1,numPairs+2 do
            local a, b = hex32_to_uint16(raw_data[idx])
            -- First word contains numPairs and info
            if idx==1 then
                WChSysCfgKey.numPairs = a
                WChSysCfgKey.info = b
                PrintString('numPairs: ' .. WChSysCfgKey.numPairs)
                PrintString('info: ' .. WChSysCfgKey.info)
            -- Last half word contains the checksum
            elseif idx==numPairs+2 then
                WChSysCfgKey.checksum = a
                PrintString('checksum: ' .. WChSysCfgKey.checksum)
            -- Data between first and last word are all for the calibratino pairs
            else
                WChSysCfgKey.calibrationPairs[idx-1] = {offset = a, data = b}
                PrintString('Calibration Pair [' .. idx-1 .. ']: offset=' .. WChSysCfgKey.calibrationPairs[idx-1].offset .. ', data=' .. WChSysCfgKey.calibrationPairs[idx-1].data)
            end
        end
    end

    return WChSysCfgKey
end


-- This function reads sysconfig key NoCl to check if we're in REL mode
-- In REL mode, NoCl = 1
-- On main line NoCl = 0 or the key does not exist
local function is_REL_Mode()
    -- By default we are not in REL mode
    local in_REL = false

    PrintString('Checking if test is running in REL mode.')

    -- Execute command to read the NoCl syscfg key
    Shell('syscfg print NoCl')
    local syscfg_data = Last.Output

    -- If any of the words have a value equal to 1, set REL mode to true
    for word_match in string.gmatch(syscfg_data, '0x(%x+)') do
        if tonumber(word_match)==1 then
            in_REL = true
        end
    end

    return in_REL
end

---------------------------------------------------------
-- High Freq LPP test for calibration.
function Dotara.HFLPPTest(TestMode)
    require "Burnin"

    -- Test plan:
    -- Run the following commmand in diags mode, expected to pass
    -- smokey --run Wildfire --test DotaraHFLPPTest LogBehavior=ConsoleOnly ResultsBehavior=NoFile ControlBitAccess=ReadOnly BrickRequired=None DisplayBehavior=NoDisplay
    -- ************************************
    -- ALL CONSTANTS HERE
    -- ************************************    
    local HFLPP_VERSION = {year = 22, month=12, day=07, revision=1} -- Year should be >= 20
    Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP Version',  (100*(100*(100*(HFLPP_VERSION.year)+HFLPP_VERSION.month)+HFLPP_VERSION.day)+HFLPP_VERSION.revision), nil, nil, nil)

    -- ************************************
    -- ALL DEFAULT VARIABLES HERE
    -- ************************************
    local lpp = {
        -- full drive
        full_drive = {
            f = 126.9e3,
            Q = 9.31,
            decay_linearity=0, 
            adc_max=2^11, 
            adc_min=-2^11, 
            adc_dc=0
        },
        -- quarter drive
        quarter_drive = {
            f = 126.9e3,
            Q = 9.31,
            decay_linearity=0, 
            adc_max=2^11, 
            adc_min=-2^11, 
            adc_dc=0
        },
        -- calculated
        L = 9.26e-6,
        C = 169.9e-9,
        R = 792e-3
    }
    local hflpp = {
        f = 360e3, 
        Q = 12.5, 
        decay_linearity=0,
        adc_max=2^11,
        adc_min=-2^11,
        adc_dc=0
    }

    -- DotaraCleanup --- investigating the occasional retest failures in QT0 dry run. Adding Dotara Cleanup before and after the HFLPP test
    pcall(Shell, 'baseband --off')
    pcall(Shell, 'smc write WAFC 0x6 0 0 0')
    Shell('wait 100')
    pcall(Shell, 'smc write WAFC 0x6 0 1 0')
    Shell('wait 500')

    -- ************************************
    -- To measure NTC, set to RX mode first and send command
    -- ************************************

    PrintString("Measure NTC temperature")
    local fw_vers = SetupDotara('rx')
    Shell('c26 exec embox 3 5 0')
    tmp_response=Last.Output
    PrintString(tmp_response)
    
    byte_1, byte_2 = string.match(tmp_response, 'Returned data: 0x%x+ 0x%x+ 0x%x+ 0x%x+ 0x%x+ 0x%x+ 0x%x+ 0x%x+ 0x(%x+) 0x(%x+) 0x%x+ 0x%x+ 0x%x+ 0x%x+ 0x%x+ 0x%x+')

    if string.len(byte_1)==1 then
        byte_1 = '0' .. byte_1
    end
    if string.len(byte_2)==1 then
        byte_2 = '0' .. byte_2
    end

    T_NTC=(tonumber(byte_2 .. byte_1,16))*0.01 -- value in deci degC
    PrintString(T_NTC) -- degC

   
    -- ************************************
    -- Setup
    -- ************************************

    -- Set Dotara in tx mode
    local fw_vers = SetupDotara('tx')
    PrintString(string.format('TX FW version: %s', fw_vers))
    Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP FW-Version', tonumber(fw_vers), nil, nil, nil)

    -- ************************************
    -- Product, Flex Vendor and Test Station
    -- ************************************

    -- Get product version and convert it to a number
    local platform = string.match(string.upper(PlatformInfo("PlatformName")),'%a%d+')
    if string.match(platform,'%d+') then
        platform = tonumber(string.match(platform,'%d+'))
    else
        platform = -1
    end

    -- Placeholder for flex tracking
    local flex_vendor = 'default'

    -- Determine station script is running at
    local test_station = 'QT0'
    if GlobalArguments ~= nil then
        test_station = GlobalArguments.HFLPP_Station or test_station
        test_station = string.upper(test_station)
    end

    -- Send data to Insight
    if platform<=38 then
        Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP Platform',  platform, nil, 37, 38)
    else 
        Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP Platform',  platform, nil, 83, 84)
    end

    -- ************************************
    -- HFLPP
    -- ************************************
    -- irontoollc reqformat 1 5 u8[cmd_type] u8[vboost1_100mv] u8[vboost2_100mv] u8[t_lpp_10ns]  u8[t_precharge_1_100us] u8[t_precharge_2_100us] u8[t_highz_delay_5us] u8[rect_drive_strength]  u8[loop_count] u8[parallel_cap]  out[u32] out[u32] out[u16] out[u16]
    -- https://compass.scv.apple.com/confluence/display/hidpt/PoweroutLC+Commands+-+HIDWPLC-8#PoweroutLCCommandsHIDWPLC8-ReadADC

    -- clear indication buffer before running HFLPP command
    for i=1,5 do 
        Shell('c26 exec indication 1 5 out[u32] out[float] out[float]')
        Shell('wait 50')
    end
    --Shell('wait 300')
    
    -- Run HFLPP FW command
    PrintString("Run HFLPP")
    Shell('c26 exec reqformat 1 5 u8[0] u8[70] u8[140] u8[10] u8[100] u8[100] u8[50] u8[3] u8[40] u8[0] out[u32] out[u32] out[u16] out[u16]')

    -- extract adc dump address "example: u32[1107640 0x0010E6B8] u32[1149028 0x00118864] u16[936 0x03A8] u16[952 0x03B8]"
    hflpp_cmd_response = Last.Output
    dummy1,address_adcdump,dummy2,dummy3 = string.match(hflpp_cmd_response,'.*u32.*(0x%x).*u32.*(0x%x*).*u16.*(0x%x).*u16.*(0x%x)')
    PrintString("----adc dump address----")
    PrintString(address_adcdump)
    Shell('wait 100')

    -- Get indication structure address and average frequency and Q
    local ind_count = 0
    address,f,Q=0,0,0
    while ind_count < 40 do
        Shell('c26 exec indication 1 5 out[u32] out[float] out[float]')
        ind_response_hflpp = Last.Output
        -- u32[1113784 0x0010FEB8] float[379163.593750 0x48B92373] float[9.857024 0x411DB65F]
        address,f,Q = string.match(ind_response_hflpp,'.*u32.*(0x%x*).*float.(%d+.%d*).*float.(%d+.%d*)')
        ind_type = string.match(ind_response_hflpp,'%x+: (%x+ %x+)')
        PrintString(ind_type)
        Shell('wait 100')
        if tonumber(Q) ~= 0 and ind_type=='05 90' then
            PrintString('----ind packet matches----')
            break
        else
            ind_count = ind_count + 1
            PrintString('----ind packet DOESNT match! Retry----')
        end
    end

    -- dump adc from HFLPP
    PrintString("Dump ADC raw of HFLPP")
    Shell('c26 exec read '..address_adcdump..' 896 2')

    -- Read full HFLPP results data structure from memory into variables
    Shell('c26 exec read '..address..' 40')
    ind_response=Last.Output
    ind_response = string.gsub(ind_response,' ', '')
    PrintString(ind_response)
    twobyte = '(%w%w%w%w)'
    fourbyte = '(%w%w%w%w%w%w%w%w)'
    version, avg, Q, f, min_d = string.match(ind_response,'00:' .. twobyte .. twobyte .. fourbyte .. fourbyte .. fourbyte)
    max_adc, min_adc, maxQ, minQ, maxf = string.match(ind_response,'10:' .. twobyte .. twobyte .. fourbyte .. fourbyte .. fourbyte)
    minf = string.match(ind_response,'20:' .. fourbyte)

    --Converting little endian hexidecimal strings to big endian floats
    Q_hflpp,f_hflpp,min_d_hflpp = hex_decode(Q, hw.struct.FLOAT), hex_decode(f, hw.struct.FLOAT), hex_decode(min_d, hw.struct.FLOAT)
    maxQ,minQ = hex_decode(maxQ, hw.struct.FLOAT), hex_decode(minQ, hw.struct.FLOAT)
    maxf,minf = hex_decode(maxf, hw.struct.FLOAT), hex_decode(minf, hw.struct.FLOAT)
    hflpp.f = f_hflpp
    hflpp.Q = Q_hflpp
    hflpp.decay_linearity = min_d_hflpp
    hflpp.adc_max = hex_decode(max_adc, hw.struct.UINT16)
    hflpp.adc_min = hex_decode(min_adc, hw.struct.UINT16)
 
    -- ************************************
    -- LPP Full Drive
    -- ************************************
    -- https://compass.scv.apple.com/confluence/display/hidpt/PoweroutLC+Commands+-+HIDWPLC-8

    -- clear indication packets
    for i=1,5 do 
        Shell('c26 exec indication 1 5 out[u32] out[float] out[float]')
        Shell('wait 50')
    end
    --Shell('wait 300')

    -- Run LPP in full drive mode
    PrintString("Run LPP full drive mode")
    Shell ('c26 exec reqformat 1 5 u8[1] u8[70] u8[140] u8[20] u8[100] u8[100] u8[50] u8[3] u8[40] u8[0] out[u32] out[u32] out[u16] out[u16]')

    -- extract adc dump address "example: u32[1107640 0x0010E6B8] u32[1149028 0x00118864] u16[936 0x03A8] u16[952 0x03B8]"
    lppfd_cmd_response = Last.Output
    dummy1,address_adcdump,dummy2,dummy3 = string.match(lppfd_cmd_response,'.*u32.*(0x%x).*u32.*(0x%x*).*u16.*(0x%x).*u16.*(0x%x)')
    PrintString("----adc dump address----")
    PrintString(address_adcdump)
    Shell('wait 100')

    -- Get indication structure address and average frequency and Q 
    local ind_count = 0
    address,f,Q=0,0,0
    while ind_count < 40 do
        Shell('c26 exec indication 1 5 out[u32] out[float] out[float]')
        ind_response_lpp = Last.Output
        address,f,Q = string.match(ind_response_lpp,'.*u32.*(0x%x*).*float.(%d+.%d*).*float.(%d+.%d*)')
        ind_type = string.match(ind_response_lpp,'%x+: (%x+ %x+)')
        PrintString(ind_type)
        Shell('wait 100')
        if tonumber(Q) ~= 0 and ind_type=='05 90' then
            PrintString('----ind packet matches----')
            break
        else
            ind_count = ind_count + 1
            PrintString('----ind packet DOESNT match! Retry----')
        end
    end

    -- dump adc from LPP FD
    PrintString("Dump ADC raw of LPP FD")
    Shell('c26 exec read '..address_adcdump..' 896 2')

    -- Read full LPP results data structure from memory into variables
    Shell('c26 exec read '..address..' 40')
    ind_response=Last.Output
    ind_response = string.gsub(ind_response,' ', '')
    PrintString(ind_response)
    twobyte = '(%w%w%w%w)'
    fourbyte = '(%w%w%w%w%w%w%w%w)'
    version, avg, Q, f, min_d = string.match(ind_response,'00:' .. twobyte .. twobyte .. fourbyte .. fourbyte .. fourbyte)
    max_adc, min_adc, maxQ, minQ, maxf = string.match(ind_response,'10:' .. twobyte .. twobyte .. fourbyte .. fourbyte .. fourbyte)
    minf = string.match(ind_response,'20:' .. fourbyte)

    --Converting little endian hexidecimal strings to big endian floats
    Q_lppfd, f_lppfd, min_d_lppfd = hex_decode(Q, hw.struct.FLOAT), hex_decode(f, hw.struct.FLOAT), hex_decode(min_d, hw.struct.FLOAT)
    PrintString(Q_lppfd .. " " .. f_lppfd .. " " .. min_d_lppfd)
    lpp.full_drive.f = f_lppfd
    lpp.full_drive.Q = Q_lppfd
    lpp.full_drive.decay_linearity = min_d_lppfd
    lpp.full_drive.adc_max = hex_decode(max_adc, hw.struct.UINT16)
    lpp.full_drive.adc_min = hex_decode(min_adc, hw.struct.UINT16)

    -- ************************************
    -- LPP Quarter Drive
    -- ************************************
    -- https://compass.scv.apple.com/confluence/display/hidpt/PoweroutLC+Commands+-+HIDWPLC-8
    
    -- clear indication packets
    for i=1,5 do 
        Shell('c26 exec indication 1 5 out[u32] out[float] out[float]')
        Shell('wait 50')
    end
    --Shell('wait 300')

    -- Run LPP in full quarter drive mode
    PrintString("Run LPP quarter drive mode")
    Shell ('c26 exec reqformat 1 5 u8[1] u8[70] u8[140] u8[20] u8[100] u8[100] u8[50] u8[1] u8[40] u8[0] out[u32] out[u32] out[u16] out[u16]')

    -- extract adc dump address "example: u32[1107640 0x0010E6B8] u32[1149028 0x00118864] u16[936 0x03A8] u16[952 0x03B8]"
    lppqd_cmd_response = Last.Output
    dummy1,address_adcdump,dummy2,dummy3 = string.match(lppqd_cmd_response,'.*u32.*(0x%x).*u32.*(0x%x*).*u16.*(0x%x).*u16.*(0x%x)')
    PrintString("----adc dump address----")
    PrintString(address_adcdump)
    Shell('wait 100')

    -- Get indication structure address and average frequency and Q 
    local ind_count = 0
    address,f,Q=0,0,0
    while ind_count < 40 do
        Shell('c26 exec indication 1 5 out[u32] out[float] out[float]')
        ind_response_lpp = Last.Output
        address,f,Q = string.match(ind_response_lpp,'.*u32.*(0x%x*).*float.(%d+.%d*).*float.(%d+.%d*)')
        ind_type = string.match(ind_response_lpp,'%x+: (%x+ %x+)')
        PrintString(ind_type)
        Shell('wait 100')   
        if tonumber(Q) ~= 0 and ind_type=='05 90' then
            PrintString('----ind packet matches----')
            break
        else
            ind_count = ind_count + 1
            PrintString('----ind packet DOESNT match! Retry----')
        end
    end

    -- dump adc from LPP QD
    PrintString("Dump ADC raw of LPP FD")
    Shell('c26 exec read '..address_adcdump..' 896 2')

    -- Read full LPP results data structure from memory into variables
    Shell('c26 exec read '..address..' 40')
    ind_response=Last.Output
    ind_response = string.gsub(ind_response,' ', '')
    PrintString(ind_response)
    twobyte = '(%w%w%w%w)'
    fourbyte = '(%w%w%w%w%w%w%w%w)'
    version, avg, Q, f, min_d = string.match(ind_response,'00:' .. twobyte .. twobyte .. fourbyte .. fourbyte .. fourbyte)
    max_adc, min_adc, maxQ, minQ, maxf = string.match(ind_response,'10:' .. twobyte .. twobyte .. fourbyte .. fourbyte .. fourbyte)
    minf = string.match(ind_response,'20:' .. fourbyte)

    --Converting little endian hexadecimal strings to big endian floats
    Q_lppqd,f_lppqd,min_d_lppqd= hex_decode(Q, hw.struct.FLOAT), hex_decode(f, hw.struct.FLOAT), hex_decode(min_d, hw.struct.FLOAT)
    PrintString(Q_lppqd .. " " .. f_lppqd .. " " .. min_d_lppqd)
    lpp.quarter_drive.f = f_lppqd
    lpp.quarter_drive.Q = Q_lppqd
    lpp.quarter_drive.decay_linearity = min_d_lppqd
    lpp.quarter_drive.adc_max = hex_decode(max_adc, hw.struct.UINT16)
    lpp.quarter_drive.adc_min = hex_decode(min_adc, hw.struct.UINT16)

    
    -- -- ************************************
    -- -- Temperature Measurement
    -- -- ************************************

    -- Measure Dotara LC rectifier temperature
    PrintString("Measure ITsns Deg")
    Shell('c26 exec reqformat 3 1 u8[59] u8[0] u8[10] out[float]')
    T_Rect = string.match(Last.Output,'.*float.(%d+.%d*)')

    -- Measure Dotara LC ILOAD temperature
    PrintString("Measure ILOAD temp Deg")
    Shell('c26 exec reqformat 3 1 u8[60] u8[0] u8[10] out[float]')
    T_ILOAD = string.match(Last.Output,'.*float.(%d+.%d*)')

    -- Measure battery temperature if test is run at QT0 station / FATP
    if test_station == 'QT0' then
       Shell('device -k gasgauge -p')
       T_Bat = tonumber(string.match(string.lower(Last.Output),'temperature: "(%d+%.*%d*)c"'))
    else
       T_Bat = 0
    end
    PrintString('T_bat = ' .. T_Bat )
    PrintString('T_ITsns = ' .. T_Rect )


    
    -- -- ************************************
    -- -- Delta R calculations
    -- -- ************************************

    -- Read calibration
    local RDSON_cal = ReadRDSONCal(T_Rect)
    local delta_R = RDSON_cal.RDSON_DELTA_COMP
    print('deltaR')
    print(delta_R)


    lpp.R = delta_R*lpp.quarter_drive.Q /(lpp.full_drive.Q -lpp.quarter_drive.Q )
    lpp.C = 1/(2*math.pi*lpp.full_drive.f*lpp.R*lpp.full_drive.Q)
    lpp.L = 1/((2*math.pi*lpp.full_drive.f)^2*lpp.C )
    print(lpp.R)
    print(lpp.L)
    print(lpp.C)

    -- -- ************************************
    -- -- Perform RAC Calculations
    -- -- ************************************

    -- Checking MLB config ----
    Shell('socgpio --port 0 --pin 98 --get')
    MLB_config=tonumber(string.match(Last.Output,'= (%d)'))
    local MlbSimConfig = (MLB_config == 1) and "psim" or "esim"
    PrintString(MlbSimConfig .. " MLB detected for D"..platform)    

    if MlbSimConfig == "esim" and platform ==83 then
        MLB_resistance = 167.72e-3 -- updated for P2
    elseif MlbSimConfig == "psim" and platform ==83 then
        MLB_resistance = 99.61e-3 -- updated for P2
    elseif MlbSimConfig == "esim" and platform ==84 then
        MLB_resistance = 167.72e-3 -- updated for P2
    elseif MlbSimConfig == "psim" and platform ==84 then
        MLB_resistance = 99.61e-3 -- updated for P2
    end
    
    local rac = {}
   
    local flex_resistance_options = {
        D38={default=111.9e-3},  -- updated for P2
        D37={default=104.62e-3}, -- updated for P2
        D83={default=64.27e-3}, -- updated for P2
        D84={default=57.07e-3} -- updated for P2
    }
    local pcb_resistance_options = {
        D38=46.74e-3,-- updated for P2
        D37=46.74e-3,-- updated for P2
        D83=MLB_resistance, -- ESIM/PSIM version
        D84=MLB_resistance --  ESIM/PSIM version
    }
    local R_PATH = {R_Cres = 19.7e-3, R_PCB = pcb_resistance_options['D' .. platform], R_FLEX = flex_resistance_options['D' .. platform][flex_vendor], C_RES_DELTA = 9.2e-3} -- reference

    PrintString("------------------------PCB resistance is "..R_PATH.R_PCB.."-------------------------------")

    -- Calculate RLC for HFLPP path
    rac.L = lpp.L/(1.21911955435105e-13*(lpp.full_drive.f^2) - 1.18530876022416e-07*lpp.full_drive.f + 1.02671059435800) 
    hflpp.L = rac.L * (1.21911955435105e-13*(hflpp.f^2) - 1.18530876022416e-07*hflpp.f + 1.02671059435800)
    hflpp.R = (2 * math.pi * hflpp.f) * hflpp.L/(hflpp.Q)
    hflpp.C = 1/((2 * math.pi * hflpp.f)^2 * hflpp.L)

    -- Temperature compensation to current temperatures
    local temperature_reference = {room = 22, ntc = 38, battery = 31}
    local temperature_coefficient = {flex = 0.00210, c_esr = 0.00330, mlb = 0.00380, coil = 0.00210}
    local k_mlb, k_flex, k_cesr, k_coil
    k_mlb = 1 + (T_NTC - temperature_reference.room)*temperature_coefficient.mlb
    k_cesr = 1 + (T_NTC - temperature_reference.room)*temperature_coefficient.c_esr
    k_flex =  1 + (T_Bat - temperature_reference.room)*temperature_coefficient.flex
    PrintString('Temperature compensation of RsysL')
    PrintString('k_mlb: ' .. k_mlb)
    PrintString('k_cesr: ' .. k_cesr)
    PrintString('k_flex: ' .. k_flex)

    -- Calculate R coil at HFLPP frequency
    local Za = {r=(RDSON_cal.CLAMP2_COMP + k_cesr*2e-3), i=1/(-2*math.pi*hflpp.f*20e-9)}
    local Zb = {r=k_cesr*5e-3, i=1/(-2*math.pi*hflpp.f*560e-12)} -- AC1 Coss FET
    local Zc = {r=k_cesr*40e-3, i=1/(-2*math.pi*hflpp.f*440e-12)} -- Cdesense 2x220pF
    local Zd = Complex.Divide(Complex.Multiply(Zb,Zc),Complex.Add(Zb,Zc))
    local Ze = Complex.Add( Complex.Divide(Complex.Multiply(Za,Zd),Complex.Add(Za,Zd)), {r=RDSON_cal.AC1_LS_FD_COMP,i=0})
    local Zf = {r=k_cesr*5e-3, i=1/(-2*math.pi*hflpp.f*2.2e-9)} -- Cpar
    local Z_equivalent = Complex.Divide(Complex.Multiply(Ze,Zf),Complex.Add(Ze,Zf))
    hflpp.R_coil = hflpp.R - Z_equivalent.r - k_cesr*R_PATH.R_Cres - k_mlb*R_PATH.R_PCB - k_flex*R_PATH.R_FLEX

    -- Compensate coil resistance back to a fixed temperature reference for comparison / hard-code Q evaluation
    k_coil =  1 + (temperature_reference.battery-T_Bat)*temperature_coefficient.coil
    hflpp.R_coil_compensated = hflpp.R_coil*k_coil
    
    -- Calculate R coil at 360kHz frequency using curve fit
    rac.R_coil = hflpp.R_coil/(1.64550666158319e-12*(hflpp.f^2) + 1.36763117331338e-06*hflpp.f + 0.294392883026495) -- Based on D5X CRB

    -- Calculate the power path resistance at 360kHz
    --      * remove clamp fet impact,replace with inverter mosfets, correct coil RAC delta and correct for parallel swicthed in resonant capacitor
    rac.R = hflpp.R - Z_equivalent.r + RDSON_cal.AC1_LS_FD_COMP + RDSON_cal.AC2_LS_FD_COMP + (rac.R_coil-hflpp.R_coil) + k_cesr*R_PATH.C_RES_DELTA

    -- Metrics useful for debug
    local R_series_switch_off = hflpp.R - Z_equivalent.r + RDSON_cal.AC1_LS_FD_COMP + RDSON_cal.AC2_LS_FD_COMP
    PrintString('hflpp.R: ' .. hflpp.R)
    PrintString('Equivalent resistance clamp MOSFET & Parallel cap: ' .. Z_equivalent.r)
    PrintString('hflpp.R_coil: ' .. hflpp.R_coil)
    PrintString('hflpp.R_coil (Tbat=31): ' .. hflpp.R_coil_compensated)
    PrintString('rac.R_coil: ' .. rac.R_coil)
    PrintString('rac.R: ' .. rac.R_coil)


    -- -- ************************************
    -- -- Perform RPP Calculations 
    -- -- ************************************
    -- Constants defined in spec V8: https://specs.apple.com/perspective.req?docId=399381&projectId=527

    local Rsys_Arcas_FD_options = {
        D38=1111,
        D37=1094,
        D83=1094,
        D84=1115
    }
    local Rsys_Arcas_QD_options = {
        D38=1518,
        D37=1501,
        D83=1501,
        D84=1522
    }
    local Rsys_Ironman_FD_options = {
        D38=3140,
        D37=3140,
        D83=3140,
        D84=3140
    }
    local Rsys_Ironman_QD_options = {
        D38=3540,
        D37=3540,
        D83=3540,
        D84=3540
    }

    Arcas_FD_Rsys_mated = Rsys_Arcas_FD_options['D' .. platform]
    Arcas_QD_Rsys_mated = Rsys_Arcas_QD_options['D' .. platform]
    Ironman_FD_Rsys_mated = Rsys_Ironman_FD_options['D' .. platform]
    Ironman_QD_Rsys_mated = Rsys_Ironman_QD_options['D' .. platform]

    PrintString('*********************************************** This is a DOE of Rsys and AC1 Rdson failure recovery. These are not used for calibration ***********************************************')

    local delta_R_DOE = RDSON_cal.RDSON_DELTA_COMP1
    lpp.R_DOE = delta_R_DOE*lpp.quarter_drive.Q /(lpp.full_drive.Q -lpp.quarter_drive.Q )
    lpp.C_DOE = 1/(2*math.pi*lpp.full_drive.f*lpp.R_DOE*lpp.full_drive.Q)
    lpp.L_DOE = 1/((2*math.pi*lpp.full_drive.f)^2*lpp.C_DOE )
    rac.L_DOE = lpp.L_DOE/(1.21911955435105e-13*(lpp.full_drive.f^2) - 1.18530876022416e-07*lpp.full_drive.f + 1.02671059435800) 
    hflpp.L_DOE = rac.L_DOE * (1.21911955435105e-13*(hflpp.f^2) - 1.18530876022416e-07*hflpp.f + 1.02671059435800)
    hflpp.R_DOE = (2 * math.pi * hflpp.f) * hflpp.L_DOE/(hflpp.Q)
    hflpp.C_DOE = 1/((2 * math.pi * hflpp.f)^2 * hflpp.L_DOE)
    hflpp.R_coil_DOE = hflpp.R_DOE - Z_equivalent.r - k_cesr*R_PATH.R_Cres - k_mlb*R_PATH.R_PCB - k_flex*R_PATH.R_FLEX
    hflpp.R_coil_compensated_DOE = hflpp.R_coil_DOE*k_coil
    rac.R_coil_DOE = hflpp.R_coil_DOE/(1.64550666158319e-12*(hflpp.f^2) + 1.36763117331338e-06*hflpp.f + 0.294392883026495) 
    rac.R_DOE = hflpp.R_DOE - Z_equivalent.r + RDSON_cal.AC1_LS_FD_COMP + RDSON_cal.AC2_LS_FD_COMP + (rac.R_coil_DOE-hflpp.R_coil_DOE) + k_cesr*R_PATH.C_RES_DELTA
    RDSON_ratio=RDSON_cal.AC1_LS_FD_COMP/RDSON_cal.AC2_LS_FD_COMP
    PrintString('reference RDS_DELTA: ' .. RDSON_cal.RDSON_DELTA_COMP1)
    PrintString('reference LPP_R: ' .. lpp.R_DOE)
    PrintString('reference LPP C: ' .. lpp.C_DOE)
    PrintString('reference LPP L: ' .. lpp.L_DOE)
    PrintString('reference HFLPP L: ' .. hflpp.L_DOE)
    PrintString('reference HFLPP R: ' .. hflpp.R_DOE)
    PrintString('reference R_coil: ' .. rac.R_coil_DOE)
    PrintString('reference AC1/AC2 ratio' ..RDSON_ratio)

    
    PrintString('*********************************************** end of DOE value calculation ******************************************************')
    
    -- -- ************************************
    -- -- REPORT RESTULTS HERE
    -- -- ************************************

    -- Q and f limits dependent on test station and platform
    -- NOTE: Limits are relaxed a bit for P1 minibuild ---- to be updated
    Universal:ReportDataToStationAndPDCA('ObjectDetect_ESIM_PSIM', MLB_config, nil, 0, 1) ----added metric
    if test_station == 'QT0' then
        if platform==38 then

            Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP Q',  hflpp.Q, nil, 10.475, 12.626) -- GBD
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF Q_FD', lpp.full_drive.Q, nil, 7.884, 10.393) -- GBD
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF Q_QD', lpp.quarter_drive.Q, nil, 5.504, 7.142) -- GBD
            Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP f',  hflpp.f, 'Hz', 356000, 392000) -- GBD rounded off
            Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP R',  hflpp.R, 'Ohm', 1.662, 1.996) -- GBD
            Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC R_sys',  rac.R, 'Ohm', 1.07, 1.392) -- GBD
            Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC R_coil',  rac.R_coil, 'Ohm', 0.6, 1.3) -- wide limits (to be determined in P1 mini)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP DR',  hflpp.decay_linearity, nil, 0.92, 1.0)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF DR_FD',  lpp.full_drive.decay_linearity, nil, 0.92, 1.0)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF DR_QD',  lpp.quarter_drive.decay_linearity, nil, 0.92, 1.0)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF f', lpp.full_drive.f, 'Hz', 116000, 138000) -- GBD rounded off
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF R', lpp.R, 'Ohm', 0.7, 0.88) -- GBD 
            -- Catch low Q coils using the new metric
            Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP R_coil_comp', hflpp.R_coil_compensated, 'Ohm', 0.6, 1.3) -- wide limits and determine in P1 mini
            --if hflpp.R_coil_compensated < 1.048 and hflpp.R_coil_compensated > 1.02 then
            --    Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP Q_hardcode',  1, nil, 0, 0)
            --else
            --    Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP Q_hardcode',  0, nil, 0, 0)
            --end
        elseif platform==37 then
            Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP Q',  hflpp.Q, nil, 10.78, 12.43) -- initial P2 GBD
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF Q_FD', lpp.full_drive.Q, nil, 8.36, 10.4) -- initial P2 GBD
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF Q_QD', lpp.quarter_drive.Q, nil, 5.87, 7.17) -- initial P2 GBD
            Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP f',  hflpp.f, 'Hz', 354193, 385615) -- based on P2 early distribution 
            Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP R',  hflpp.R, 'Ohm', 1.626, 1.951) -- initial P2 GBD
            Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC R_sys',  rac.R, 'Ohm', 1.023, 1.307) -- initial P2 GBD
            Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC R_coil',  rac.R_coil, 'Ohm', 0.745, 1.028) -- P1 distribution based
            Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP DR',  hflpp.decay_linearity, nil, 0.92, 1.0)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF DR_FD',  lpp.full_drive.decay_linearity, nil, 0.92, 1.0)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF DR_QD',  lpp.quarter_drive.decay_linearity, nil, 0.92, 1.0)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF f', lpp.full_drive.f, 'Hz', 117900, 138200)-- initial P2 GBD
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF R', lpp.R, 'Ohm', 0.75202, 0.88822)-- revised P2 limits using P2 build distribution
            -- Catch low Q coils using the new metric
            Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP R_coil_comp', hflpp.R_coil_compensated, 'Ohm', 0.78, 1.06) -- P1 distribution based
            -- if hflpp.R_coil_compensated < 0.98 and hflpp.R_coil_compensated > 0.952 then
            --    Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP Q_hardcode',  1, nil, 0, 0)
            --else
            --    Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP Q_hardcode',  0, nil, 0, 0)
            --end
        elseif platform==83 then
            if MlbSimConfig == "esim" then-- esim config
                Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP Q',  hflpp.Q, nil, 10.546, 14) -- P2 dry run wide limits
                Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF Q_FD', lpp.full_drive.Q, nil, 6.757, 12) -- P2 dry run wide limits
                Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF Q_QD', lpp.quarter_drive.Q, nil, 4.962, 8) -- P2 dry run wide limits
                Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP R',  hflpp.R, 'Ohm', 1.3, 1.996) -- P2 dry run wide limits
                Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC R_sys',  rac.R, 'Ohm', 0.9, 1.353) -- P2 dry run wide limits
                Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF R', lpp.R, 'Ohm', 0.65, 1.025) -- P2 dry run wide limits
            else-- 1 psim config
                Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP Q',  hflpp.Q, nil, 11, 14) -- P2 dry run wide limits
                Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF Q_FD', lpp.full_drive.Q, nil, 7.602, 12) -- P2 dry run wide limits
                Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF Q_QD', lpp.quarter_drive.Q, nil, 5.377, 8) -- P2 dry run wide limits
                Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP R',  hflpp.R, 'Ohm', 1.3, 1.915) -- P2 dry run wide limits
                Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC R_sys',  rac.R, 'Ohm', 0.9, 1.275) -- P2 dry run wide limits
                Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF R', lpp.R, 'Ohm', 0.65, 1.025) -- P2 dry run wide limits
            end
            Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP f',  hflpp.f, 'Hz', 356100, 387800) -- based from P1 distribution +/- 6 sigma
            Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC R_coil',  rac.R_coil, 'Ohm', 0.672, 0.957) -- based from P1 distribution +/- 6 sigma
            Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP DR',  hflpp.decay_linearity, nil, 0.92, 1.0)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF DR_FD',  lpp.full_drive.decay_linearity, nil, 0.92, 1.0)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF DR_QD',  lpp.quarter_drive.decay_linearity, nil, 0.92, 1.0)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF f', lpp.full_drive.f, 'Hz', 117800, 138200) -- intial P2 GBD
            -- Catch low Q coils using the new metric
            Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP R_coil_comp', hflpp.R_coil_compensated, 'Ohm', 0.686, 1) -- based from P1 distribution +/- 6 sigma
            --if hflpp.R_coil_compensated < 0.995 and hflpp.R_coil_compensated > 0.967 then 
            --    Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP Q_hardcode',  1, nil, 0, 0)
            --else
            --    Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP Q_hardcode',  0, nil, 0, 0)
            --end
        else
            if MlbSimConfig == "esim" then-- esim config
                Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP Q',  hflpp.Q, nil, 10.212, 12.396) --GBD
                Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF Q_FD', lpp.full_drive.Q, nil, 7.396, 10.003) --GBD
                Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF Q_QD', lpp.quarter_drive.Q, nil, 5.281, 6.939) --GBD
                Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP R',  hflpp.R, 'Ohm', 1.655, 2.047)
                Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC R_sys',  rac.R, 'Ohm', 1.065, 1.443)
                Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF R', lpp.R, 'Ohm', 0.690, 0.938)
            else -- 1 psim config
                Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP Q',  hflpp.Q, nil, 10.464, 12.671) -- GBD
                Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF Q_FD', lpp.full_drive.Q, nil, 7.85, 10.492) --GBD
                Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF Q_QD', lpp.quarter_drive.Q, nil, 5.496, 7.182) --GBD
                Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP R',  hflpp.R, 'Ohm', 1.655, 2.047)
                Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC R_sys',  rac.R, 'Ohm', 1.065, 1.443)
                Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF R', lpp.R, 'Ohm', 0.690, 0.938)
            end 
            Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP f',  hflpp.f, 'Hz', 357000, 383000) 
            Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC R_coil',  rac.R_coil, 'Ohm', 0.6, 1.2) -- wide limits (to be determined in P1 mini)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP DR',  hflpp.decay_linearity, nil, 0.92, 1.0)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF DR_FD',  lpp.full_drive.decay_linearity, nil, 0.92, 1.0)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF DR_QD',  lpp.quarter_drive.decay_linearity, nil, 0.92, 1.0)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF f', lpp.full_drive.f, 'Hz', 122000, 137000) -- GBD
            -- Catch low Q coils using the new metric
            Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP R_coil_comp', hflpp.R_coil_compensated, 'Ohm', 0.6, 1.2) -- wide limits to be determined in P1
            --if hflpp.R_coil_compensated < 0.967 and hflpp.R_coil_compensated > 0.939 then
            --    Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP Q_hardcode',  1, nil, 0, 0)
            --else
            --    Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP Q_hardcode',  0, nil, 0, 0)
            --end
        end
        -- Only report Tbat if test station is QT0
        Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC T_Bat', T_Bat, 'degC', 20, 50)
    else
        if platform==38 then
            Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP Q',  hflpp.Q, nil, 10.5, 14.5)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF Q_FD', lpp.full_drive.Q, nil, 7, 14)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF Q_QD', lpp.quarter_drive.Q, nil, 5, 9)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP f',  hflpp.f, 'Hz', 350000, 390000)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP R',  hflpp.R, 'Ohm', 1.4, 2.1)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC R_sys',  rac.R, 'Ohm', 0.4, 1.7)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC R_coil',  rac.R_coil, 'Ohm', 0.4, 1.5)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP DR',  hflpp.decay_linearity, nil, 0.9, 1.0)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF DR_FD',  lpp.full_drive.decay_linearity, nil, 0.9, 1.0)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF DR_QD',  lpp.quarter_drive.decay_linearity, nil, 0.9, 1.0)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF f', lpp.full_drive.f, 'Hz', 118000, 140000)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF R', lpp.R, 'Ohm', 0.6, 0.9)
        elseif platform==37 then
            Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP Q',  hflpp.Q, nil, 10.5, 14.5)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF Q_FD', lpp.full_drive.Q, nil, 7, 14)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF Q_QD', lpp.quarter_drive.Q, nil, 5, 9)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP f',  hflpp.f, 'Hz', 350000, 390000)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP R',  hflpp.R, 'Ohm', 1.4, 2.1)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC R_sys',  rac.R, 'Ohm', 0.4, 1.7)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC R_coil',  rac.R_coil, 'Ohm', 0.4, 1.5)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP DR',  hflpp.decay_linearity, nil, 0.9, 1.0)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF DR_FD',  lpp.full_drive.decay_linearity, nil, 0.9, 1.0)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF DR_QD',  lpp.quarter_drive.decay_linearity, nil, 0.9, 1.0)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF f', lpp.full_drive.f, 'Hz', 118000, 140000)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF R', lpp.R, 'Ohm', 0.6, 0.9)
        elseif platform==83 then
            Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP Q',  hflpp.Q, nil, 10.5, 14.5)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF Q_FD', lpp.full_drive.Q, nil, 7, 14)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF Q_QD', lpp.quarter_drive.Q, nil, 5, 9)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP f',  hflpp.f, 'Hz', 350000, 390000)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP R',  hflpp.R, 'Ohm', 1.4, 2.1)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC R_sys',  rac.R, 'Ohm', 0.4, 1.7)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC R_coil',  rac.R_coil, 'Ohm', 0.4, 1.5)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP DR',  hflpp.decay_linearity, nil, 0.94, 1.0)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF DR_FD',  lpp.full_drive.decay_linearity, nil, 0.9, 1.0)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF DR_QD',  lpp.quarter_drive.decay_linearity, nil, 0.9, 1.0)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF f', lpp.full_drive.f, 'Hz', 118000, 140000)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF R', lpp.R, 'Ohm', 0.6, 0.9)
        else
            Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP Q',  hflpp.Q, nil, 10.5, 14.5)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF Q_FD', lpp.full_drive.Q, nil, 7, 14)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF Q_QD', lpp.quarter_drive.Q, nil, 5, 9)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP f',  hflpp.f, 'Hz', 350000, 390000)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP R',  hflpp.R, 'Ohm', 1.4, 2.1)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC R_sys',  rac.R, 'Ohm', 0.4, 1.7)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC R_coil',  rac.R_coil, 'Ohm', 0.4, 1.5)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP DR',  hflpp.decay_linearity, nil, 0.9, 1.0)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF DR_FD',  lpp.full_drive.decay_linearity, nil, 0.9, 1.0)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF DR_QD',  lpp.quarter_drive.decay_linearity, nil, 0.9, 1.0)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF f', lpp.full_drive.f, 'Hz', 118000, 140000)
            Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF R', lpp.R, 'Ohm', 0.6, 0.9)
        end
    end

    -- Station reports that are platform independent
    Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP ADC_Min',  hflpp.adc_min, nil, 8200, 27000)  -- P1 bring-up
    Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP ADC_Max',  hflpp.adc_max, nil, 29000, 49100) -- P1 bring-up
    Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP ADC_Min_FD',  lpp.full_drive.adc_min, nil, 4000, 29000)  -- P1 bring-up
    Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP ADC_Max_FD',  lpp.full_drive.adc_max, nil, 35000, 57000) -- P1 bring-up
    Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP ADC_Min_QD',  lpp.quarter_drive.adc_min, nil, 1000, 34800) -- P1 bring-up
    Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP ADC_Max_QD',  lpp.quarter_drive.adc_max, nil, 30800, 58000) -- P1 bring-up
    Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC T_Rect', T_Rect, 'degC', 20, 70)
    Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC T_NTC', T_NTC, 'degC', 20, 70)
    Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC T_comp_check', RDSON_cal.temp_comp_rel, 'degC', 0, 2)
    Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF C', lpp.C, 'F', 1.5e-7, 1.85e-7) 
    Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP C',  hflpp.C, 'F', 18.0e-9, 23.0e-9) 
    Universal:ReportDataToStationAndPDCA('ObjectDetect_LPP_174nF L', lpp.L, 'H', 8.15e-6, 10.15e-6) -- based on GBD (combined D7x/D2y)
    Universal:ReportDataToStationAndPDCA('ObjectDetect_HFLPP L',  hflpp.L, 'H', 8.1e-6, 10e-6) --- based on GBD (combined D7x/D2y)
    Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC RDS_AC1_FD',  RDSON_cal.AC1_LS_FD_COMP, 'Ohm', 0.04, 0.07)
    Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC RDS_AC2_FD',  RDSON_cal.AC2_LS_FD_COMP, 'Ohm', 0.04, 0.07)
    Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC RDS_AC1_QD',  RDSON_cal.AC1_LS_QD_COMP, 'Ohm', 0.16, 0.28) --- added metric
    Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC RDS_AC2_QD',  RDSON_cal.AC2_LS_QD_COMP, 'Ohm', 0.16, 0.28) --- added metric
    Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC RDS_Clamp2_FD',  RDSON_cal.CLAMP2_COMP, 'Ohm', 0.5, 1.2)
    Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC RDS_Delta', RDSON_cal.RDSON_DELTA_COMP, 'Ohm', 0.25, 0.35)
    PrintString('------------reference parameters --------------')
    Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC R_sys_ref',  rac.R_DOE, 'Ohm', nil, nil)
    Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC RDS_Delta_ref', RDSON_cal.RDSON_DELTA_COMP1, 'Ohm', nil, nil)
    Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC RDS_ratio_ref', RDSON_ratio, 'Ohm', nil, nil)
    Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC T_ILOAD', T_ILOAD, 'Ohm', nil, nil) ----added metric
    Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC RDS_AC1_FD_ROOM', RDSON_cal.AC1_LS_FD_ROOM, 'Ohm', nil, nil) ----added metric
    Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC RDS_AC2_FD_ROOM', RDSON_cal.AC2_LS_FD_ROOM, 'Ohm', nil, nil) ----added metric
    Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC RDS_AC1_FD_HOT', RDSON_cal.AC1_LS_FD_HOT, 'Ohm', nil, nil) ----added metric
    Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC RDS_AC2_FD_HOT', RDSON_cal.AC2_LS_FD_HOT, 'Ohm', nil, nil) ----added metric
    Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC RDS_AC1_QD_ROOM', RDSON_cal.AC1_LS_QD_ROOM, 'Ohm', nil, nil) ----added metric
    Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC RDS_AC2_QD_ROOM', RDSON_cal.AC2_LS_QD_ROOM, 'Ohm', nil, nil) ----added metric
    Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC RDS_AC1_QD_HOT', RDSON_cal.AC1_LS_QD_HOT, 'Ohm', nil, nil) ----added metric
    Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC RDS_AC2_QD_HOT', RDSON_cal.AC2_LS_QD_HOT, 'Ohm', nil, nil) ----added metric
    Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC RDS_TSNS_ROOM', RDSON_cal.TROOM, 'Ohm', nil, nil) ----added metric
    Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC RDS_TSNS_HOT', RDSON_cal.THOT, 'Ohm', nil, nil) ----added metric
    

    -- -- ************************************
    -- -- Write Calibtation to SysCFG
    -- -- ************************************
    -- Structure documented in <rdar://problem/75013284>

    -- Only write sysconfig if we're NOT in REL mode or NOT using the interposer script
    local in_REL_mode = is_REL_Mode()
    local enable_cal = true
    if in_REL_mode or TestMode == 'interposer' then
        Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC REL_Mode', 1, nil, 1, 1)
        enable_cal = false
        -- Read existing key
        local read_key = sysCFG_read('WCh0', 36)
        -- Check that key read back has correct number of pairs / exists
        if read_key.numPairs==36 then
            Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC SYSCFG', 1, '', 1, 1)
         else
            Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC SYSCFG', 0, '', 1, 1)
         end
    end
    
    -- Function to convert data into right format (multiply, round, mask)
    local function syscfg_sanitize(data_in, multiplier, size_bytes)
        local scaled_data = data_in * multiplier
        local rounded_data = math.floor(scaled_data)
        local size_mask = bit32.rshift(0xFFFFFFFF,8*(4 - size_bytes))
        return bit32.band(size_mask,rounded_data)
    end

    -- Write sysconfig only if test is run at QT0 station and calibration write is enabled
    if test_station == 'QT0' and enable_cal then
        local WChSysCfgKey = {}
        WChSysCfgKey = {name = 'WCh0', numPairs = 36, info = 0x1023, calibrationPairs={}, checksum = nil}
        -- QT0 version
        -- format: 0xWXYZ -> W=year, X=month, YZ = day
        local qt0_ver_syscfg = bit32.band(bit32.lshift(HFLPP_VERSION.year-20,12)+bit32.lshift(HFLPP_VERSION.month,8)+HFLPP_VERSION.day,0xFFFF)
        -- to be uncommented once updated WCh0 has been updated
        WChSysCfgKey.calibrationPairs[1] = {offset = 92, data = syscfg_sanitize(hflpp.f,1,2)} -- freq with Cclamp_20nF LSBytes [Hz]
        WChSysCfgKey.calibrationPairs[2] = {offset = 94, data = syscfg_sanitize(hflpp.f,1/(2^16),2)} -- freq with Cclamp_20nF MSBytes [Hz]
        WChSysCfgKey.calibrationPairs[3] = {offset = 96, data = syscfg_sanitize(lpp.full_drive.f,1,2)} -- freq with Cres_174nF LSBytes [Hz]
        WChSysCfgKey.calibrationPairs[4] = {offset = 98, data = syscfg_sanitize(lpp.full_drive.f,1/(2^16),2)} -- freq with Cres_174nF MSBytes [Hz]
        WChSysCfgKey.calibrationPairs[5] = {offset = 100, data = syscfg_sanitize(0,1,2)} -- freq with Cres_710nF LSBytes [Hz]
        WChSysCfgKey.calibrationPairs[6] = {offset = 102, data = syscfg_sanitize(0,1/(2^16),2)} -- freq with Cres_710nF MSBytes [Hz]
        WChSysCfgKey.calibrationPairs[7] = {offset = 104, data = syscfg_sanitize(hflpp.Q,1e3,2)} -- Qres_Cclamp_20nF [mQ]
        WChSysCfgKey.calibrationPairs[8] = {offset = 106, data = syscfg_sanitize(lpp.full_drive.Q,1e3,2)} -- Qres_Cclamp_174nF [mQ]
        WChSysCfgKey.calibrationPairs[9] = {offset = 108, data = syscfg_sanitize(0,1e3,2)} -- Qres_Cclamp_710nF [mQ]
        WChSysCfgKey.calibrationPairs[10] = {offset = 110, data = syscfg_sanitize(rac.R,1e3,2)} -- Rsys_360Khz_powerpath [mohm]
        WChSysCfgKey.calibrationPairs[11] = {offset = 112, data = syscfg_sanitize(lpp.R,1e3,2)} -- Rsys_Cres_174nF [mohm]
        WChSysCfgKey.calibrationPairs[12] = {offset = 114, data = syscfg_sanitize(0,1e3,2)} -- Rsys_Cres_710nF [mohm]
        WChSysCfgKey.calibrationPairs[13] = {offset = 116, data = syscfg_sanitize(hflpp.L,1e9,2)} -- Lres_Cclamp_20nF LSBytes [nH]
        WChSysCfgKey.calibrationPairs[14] = {offset = 118, data = syscfg_sanitize(hflpp.L,1e9/(2^16),2)} -- Lres_Cclamp_20nF MSBytes [nH]
        WChSysCfgKey.calibrationPairs[15] = {offset = 120, data = syscfg_sanitize(lpp.L,1e9,2)} -- Lres_Cres_174nF LSBytes [nH]
        WChSysCfgKey.calibrationPairs[16] = {offset = 122, data = syscfg_sanitize(lpp.L,1e9/(2^16),2)} -- Lres_Cres_174nF MSBytes [nH]
        WChSysCfgKey.calibrationPairs[17] = {offset = 124, data = syscfg_sanitize(0,1e9,2)} -- Lres_Cres_710nF LSBytes [nH]
        WChSysCfgKey.calibrationPairs[18] = {offset = 126, data = syscfg_sanitize(0,1e9/(2^16),2)} -- Lres_Cres_710nF MSBytes [nH]
        WChSysCfgKey.calibrationPairs[19] = {offset = 128, data = syscfg_sanitize(hflpp.C,1e12,2)} -- Cres_Cclamp_20nF LSBytes [pF]
        WChSysCfgKey.calibrationPairs[20] = {offset = 130, data = syscfg_sanitize(hflpp.C,1e12/(2^16),2)} -- Cres_Cclamp_20nF MSBytes [pF]
        WChSysCfgKey.calibrationPairs[21] = {offset = 132, data = syscfg_sanitize(lpp.C,1e12,2)} -- Cres_Cres_174nF LSBytes [pF]
        WChSysCfgKey.calibrationPairs[22] = {offset = 134, data = syscfg_sanitize(lpp.C,1e12/(2^16),2)} -- Cres_Cres_174nF MSBytes [pF]
        WChSysCfgKey.calibrationPairs[23] = {offset = 136, data = syscfg_sanitize(rac.R_coil,1e4,2)} -- Coil_ACR_360KHz at battery temp)(C) [0.1mohm]
        WChSysCfgKey.calibrationPairs[24] = {offset = 138, data = syscfg_sanitize(flex_resistance_options['D' .. platform][flex_vendor],1e3,2)} -- flex_ACR_360KHz at battery temp)(C) [1mohm]
        WChSysCfgKey.calibrationPairs[25] = {offset = 140, data = syscfg_sanitize(Arcas_FD_Rsys_mated, 1, 2)} -- Rsys_Arcas_FD [mohm]
        WChSysCfgKey.calibrationPairs[26] = {offset = 142, data = syscfg_sanitize(Ironman_FD_Rsys_mated, 1, 2)} -- Rsys_Ironman_FD [mohm]
        WChSysCfgKey.calibrationPairs[27] = {offset = 144, data = syscfg_sanitize(Arcas_QD_Rsys_mated, 1, 2)} -- Rsys_Arcas_QD [mohm]
        WChSysCfgKey.calibrationPairs[28] = {offset = 146, data = syscfg_sanitize(Ironman_QD_Rsys_mated, 1, 2)} -- Rsys_Ironman_QD [mohm]
        WChSysCfgKey.calibrationPairs[29] = {offset = 148, data = syscfg_sanitize(T_Bat,10,2)} -- Temperature battery(Coil) [deci deg]
        WChSysCfgKey.calibrationPairs[30] = {offset = 150, data = syscfg_sanitize(T_Rect,10,2)} -- Temperature Rectifier [deci deg]
        WChSysCfgKey.calibrationPairs[31] = {offset = 152, data = syscfg_sanitize(T_NTC,10,2)} -- Temperature NTC [deci deg]
        WChSysCfgKey.calibrationPairs[32] = {offset = 154, data = syscfg_sanitize(qt0_ver_syscfg,1,2)} -- QT0 version
        WChSysCfgKey.calibrationPairs[33] = {offset = 156, data = syscfg_sanitize(30,1,2)} -- Q_EPP (1byte) Freq_EPP (1byte LSBytes)
        WChSysCfgKey.calibrationPairs[34] = {offset = 158, data = 0} -- Freq_EPP (2 MSBytes)
        WChSysCfgKey.calibrationPairs[35] = {offset = 160, data = syscfg_sanitize(0x4567,1,2)} -- QT0_OTP_loaded (SysCFG)
        WChSysCfgKey.calibrationPairs[36] = {offset = 162, data = 0} -- CRC - QT0 constant 
        local crc_calc = syscfg_gen_CRC(WChSysCfgKey)
        PrintString('crc' .. crc_calc)
        WChSysCfgKey.calibrationPairs[36] = {offset = 162, data = crc_calc} -- CRC - QT0 constant 

        -- Write key
        sysCFG_write(WChSysCfgKey)
 
        -- Read back key
        local read_key = sysCFG_read(WChSysCfgKey.name, WChSysCfgKey.numPairs)
        -- Compare write/read keys
        local syscfg_write_successful = (WChSysCfgKey.numPairs==read_key.numPairs) and (WChSysCfgKey.info==read_key.info) and (WChSysCfgKey.checksum==read_key.checksum)
        for i,v in ipairs(WChSysCfgKey.calibrationPairs) do
           if (v.offset ~= read_key.calibrationPairs[i].offset) or (v.data ~= read_key.calibrationPairs[i].data) then
               syscfg_write_successful = false
           end
        end
        if syscfg_write_successful then
           syscfg_write_successful = 1
        else
           syscfg_write_successful = 0
        end
    
        Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC SYSCFG', syscfg_write_successful, '', 1, 1)
    else
        Universal:ReportDataToStationAndPDCA('ObjectDetect_RAC CAL', 0, '', 0, 0)
    end

    DotaraRead32(0x127F1C, 2*36)

    -- DotaraCleanup
    --pcall(Shell, 'baseband --off') improves test time
    pcall(Shell, 'smc write WAFC 0x6 0 0 0')
    Shell('wait 100')
    pcall(Shell, 'smc write WAFC 0x6 0 1 0')

end


-- ======================================== --
-- ======================================== --
-- ==== DOTARA OTP BURN AND LOCK FNs ====== --
-- ======================================== --
-- ======================================== --

-- Setting Vboost is required for OTP burn
function set_boost(v2set)
    if v2set=="disable" or v2set==0 or v2set==false then
        PrintString("Disable Boost Converter")  
        Shell ("c26 exec reqformat 1 3 u16[0] u16[50]")
        Shell('wait 260')
    elseif v2set=="enable" or v2set==true then
        PrintString("Enable Boost Converter")
        fw_setBitMask(registers.BOOST_BOOST_CTRL1, 0x00000001)
        --turn on boost need some delay
        Shell("wait 200")
    else
        PrintString("Enabled boost and setting voltage to "..v2set.."mV")
        Shell ("c26 exec reqformat 1 3 u16["..v2set.."] u16[50]")
        Shell('wait 260')
    end
end

function get_tx_ADC(channel)
    Shell("c26 exec reqformat 3 1 u8["..channel.."] u8[0] u8[62] out[float]")
    return 1000*tonumber(string.match(Last.Output, 'float%[(-?%d[%d.,]*)'))
end

-- Custome reading funciton for OTP
function read_otp_range_fw(row_start, num_rows)
    local row_last = row_start+num_rows-1
    local otp_data = {}

    Shell("c26 exec otp read "..row_start.." "..row_last)
    
    for i=row_start,row_last do
        local val1, val2
        val1, val2 = string.match(Last.Output, "Row: "..i.."......%s-([%a%w]+)%s-([%a%w]+)")
        table.insert(otp_data,{val1,val2})
    end
    return otp_data
end

-- Check if OTP has been locked
function dotara_otp_lock_check()
    local data = read_otp_range_fw(11,2)
    local lock_check = 0
    
    for _,value in ipairs(data) do
        if (tonumber(value[1])~=0 or tonumber(value[2])~=0) then
            lock_check = 1
            break
        end 
    end
    PrintString("OTP Lock Status = " .. lock_check)
    --jt_print(lock_check,"dotara_otp_lock_check") -- 0 = PASS (unlocked), 1 = FAIL (locked)
    return lock_check
end

--
function idle_check_status_fw()

    local regval
    local timeout

    Shell('wait 10')

    timeout = os.time()
    while (os.time() - timeout < 2) do
            regval = DotaraReg_Rd(registers.OTP_OTPSTATUS)
            print("OTP Status: 0x"..hex(regval))
            if (bit32.band(regval,0x2) > 0) then
                break
            end
    end

        if (regval == nil) then
            print("Regval is nil, while loop was not entered. Reading OTPSTATUS")
            regval = DotaraReg_Rd(registers.OTP_OTPSTATUS)
        end

        if (bit32.band(regval,0x2) == 0) then
            print("Command could not complete within 1s")
            halt_script_fw()
        end

end

function check_otp_status_write_fw()

    local tstart = os.time()
    local regval

    while ((os.time()-tstart) < 10) do

        regval = DotaraReg_Rd(registers.OTP_OTPSTATUS)
        if (bit32.band(regval,bit32.lshift(0x1,31)) > 0) then
            if (bit32.band(regval,bit32.lshift(0x1,30)) == 0) then
                if (bit32.band(regval,bit32.lshift(0x1,28)) > 0) then
                    if (bit32.band(regval,bit32.lshift(0x1,27)) > 0) then
                        if (bit32.band(regval,bit32.lshift(0x1,29)) > 0) then
                            return 1
                        end
                    end
                end
            end
        end
    end

    return 0

end

-- Set up the clock for OTP write
function configure_otp_clock_fw(clk_mhz)

    local regval
    local div

    regval = bit32.band(DotaraReg_Rd(registers.RCO_RCOCTRL2),0x1)

    if (regval == 1) then
        div = math.floor(48/clk_mhz) - 1
    else
        div = math.floor(24/clk_mhz) - 1
    end

    regval = DotaraReg_Rd(registers.RCO_CLKDIV5)
    regval = bit32.band(regval, 0xFFFFFFF0)
    regval = bit32.bor(regval,div)
    DotaraReg_Wr(registers.RCO_CLKDIV5,div) 

end

-- Write values to OTP lock rows, used for locking OTP
function otp_lock_burn_to_row_fw(row, val)
    --write data to OTP
    DotaraReg_Wr(registers.OTP_OTPADDR, row)  --program row
    DotaraReg_Wr(registers.OTP_OTPWDATA1, val)  --row data, lsb word
    DotaraReg_Wr(registers.OTP_OTPWDATA2, 0)     --row data, msb word
    DotaraReg_Wr(registers.OTP_OTPCTRL, 0x119)  --PROG_LOCK command
    otp_lock_row_write_check_status_fw()
end

function otp_lock_row_write_check_status_fw()

    Shell('wait 1')
    local VAUX_3V3 = get_tx_ADC(45)
    print("VAUX_3V3: "..get_tx_ADC(45).."V")
    
    local regval

    local t_start = os.time()
    while (os.time() - t_start < 2) do
        regval = DotaraReg_Rd(registers.OTP_OTPSTATUS)
        print("OTP Status: 0x"..hex(regval))
        if (bit32.band(regval,0x2) > 0) then
            break
        end
    end

    if (regval == nil) then
        print("Regval is nil, while loop was not entered. Reading OTPSTATUS")
        regval = DotaraReg_Rd(registers.OTP_OTPSTATUS)
    end

    if (bit32.band(regval,0x2) == 0) then
        print("Command could not complete within 1s")
        halt_script_fw()
    else
        if (bit32.band(regval,bit32.lshift(0x1,10)) > 0) then
            print("PROG_WORD_FAIL = 1")
            halt_script_fw()
        end

    end

end

function fw_setBitMask(registerAddr, mask)
    local current_val, old_val, set_val

    old_val = DotaraReg_Rd(registerAddr)
    set_val = bit32.bor(old_val, mask)
    
    DotaraReg_Wr(registerAddr, set_val)
    current_val = DotaraReg_Rd(registerAddr)
    
    -- PrintString('old_val: ' .. old_val)
    -- PrintString('set_val: ' .. string.format("0x%X", set_val))
    -- PrintString('current_val: ' .. current_val)
end

-- Immediately halt script in case of OTP write error
function halt_script_fw()

    mask_uart("off")
    error("Error occurred. Halt script now")

end



--Finds next available empty row space
function get_free_otp_row_fw(first_row, last_row)

    local start_row = first_row
    local end_row = last_row
    local otp_size = end_row - start_row +1
    --mask_uart("on")
    local data = read_otp_range_fw(start_row,otp_size)
    --mask_uart("off")

    --    for index,value in ipairs(data) do
    --      print (index..' Row:'..(index+start_row-1).."......"..value[1]..' '..value[2])
    --    end

    local empty_row1 = start_row
    local empty_row2 = start_row
    for i=otp_size,1,-1 do
        local val1 = tonumber(data[i][1])
        local val2 = tonumber(data[i][2])

        if (val1~=0 or val2~=0) then
            empty_row1 = start_row+i
            break
        end
    end

    local i=1
    while (i <= (empty_row1-start_row)) do
        local val1 = tonumber(data[i][1])
        local val2 = tonumber(data[i][2])
        if (bit32.band(val1,0x3) == 0x2 and bit32.rshift(val1,16)~=0) then
            local size_block = bit32.rshift(val1,16)
            empty_row2 = empty_row2 + (size_block+1)
            i = i + (size_block+1)
        else
            i = i+1
        end
    end

    local row_avail = math.max(empty_row1,empty_row2)

    if (row_avail<start_row or row_avail>end_row) then
        PrintString("No empty OTP rows available between "..start_row.." and "..end_row)
        return nil
    else
        return row_avail, data
    end

end

---------------------------------------------------------
-- Function to burn OTP FW at burnin station.
function DotaraBurnOTP()
    require "Burnin"
    -- smokey --run Wildfire --test DotaraBurnOTP LogBehavior=ConsoleOnly ResultsBehavior=NoFile ControlBitAccess=ReadOnly BrickRequired=None DisplayBehavior=NoDisplay
    PrintString('Board Revision: ' .. PlatformInfo('BoardRevision'))

    -- variable definitions
    local tx_fw_version, otp_fw_version = nil, nil
    local lock_check, row_available = nil, nil
    local dotara_hw_status = nil
    local otp_fw_version_expected_min = tonumber('0x30007')
    local otp_fw_version_expected_max = tonumber('0x30007')

    -- Need to run DotaraInitTest first
    -- check if OTP has already been locked by SS station
    lock_check = dotara_otp_lock_check()
    if (lock_check==1) then
        Universal:ReportDataToStationAndPDCA('WirelessPowerTx OTP-Locked', 1, '', 0, 1)
        return
    else
        Universal:ReportDataToStationAndPDCA('WirelessPowerTx OTP-Locked', 0, '', 0, 1)
    end
    
    -- Burn OTP if the OTP FW space is still empty
    row_available = get_free_otp_row_fw(141,141)
    if (row_available==141) then
        -- Report that OTP FW sectors are still empty
        Universal:ReportDataToStationAndPDCA('WirelessPowerTx OTP-Space Available', 1, '', 0, 1)
        -- Load TX firmware
        local fw_mode = 'tx'
        tx_fw_version = SetupDotara(fw_mode)
        Universal:ReportDataToStationAndPDCA('WirelessPowerTx OTP-TX Version', tonumber(tx_fw_version), '', nil, nil)
        -- Turn boost on to 9V
        set_boost(9000)
        -- Execute the OTP update and verification
        Shell("c26 exec otp update")
        -- Report burn and verification success
        local otp_update_status = Last.Output
        local burn_complete = string.match(otp_update_status, 'OTP FW successfully burned to DotaraLC')
        local burn_verified = string.match(otp_update_status, 'OTP FW read back check successfully completed')
        if burn_complete ~= nil then
            Universal:ReportDataToStationAndPDCA('WirelessPowerTx OTP-Burned', 1, '', 1, 1)
        else
            Universal:ReportDataToStationAndPDCA('WirelessPowerTx OTP-Burned', 0, '', 1, 1)
        end
        if burn_verified ~= nil then
            Universal:ReportDataToStationAndPDCA('WirelessPowerTx OTP-Verified', 1, '', 1, 1)
        else
            Universal:ReportDataToStationAndPDCA('WirelessPowerTx OTP-Verified', 0, '', 1, 1)
        end
        -- Turn boost off
        set_boost(0)
    else
        Universal:ReportDataToStationAndPDCA('WirelessPowerTx OTP-Space Available', 0, '', 0, 1)
    end
    
    -- Check that DotaraLC was not reset during the OTP burn process
    dotara_hw_status = DotaraRead32(registers.SYSSAVE_SAVE_HW_STATUS)
    PrintString('SYSSAVE_SAVE_HW_STATUS: ' .. dotara_hw_status)
    dotara_hw_status = bit32.band(dotara_hw_status,0x1)
    if (tonumber(dotara_hw_status)==1) then
        PrintString("SYSSAVE_SAVE_HW_STATUS suggests DotaraLC may have been reset during OTP burn")
    end

    -- Verify that OTP can be loaded and that FW version is correct
    local fw_mode = 'otp'
    otp_fw_version = SetupDotara(fw_mode)
    Universal:ReportDataToStationAndPDCA('WirelessPowerTx OTP-OTP Version', tonumber(otp_fw_version), '', otp_fw_version_expected_min, otp_fw_version_expected_max)

    -- Cleanup dotara status after running test. Set it back up in rx and test out trampoline functionality
    local tramp_fw = SetupDotara('rx_trampoline')
    Universal:ReportDataToStationAndPDCA('WirelessPowerTx OTP-Trampoline', tonumber(tramp_fw), '', 0, 0xFFFFFFFF)
end

---------------------------------------------------------
-- Function for burning lock SWD in OTP.
function DotaraBurnOTPSWDLock()
        --[[
            This function will burn the w-command in OTP to lock the SWD lock bit on prod-fused units only.
        --]]
            require "Burnin"
            local force_swd_lock = false
            if GlobalArguments ~= nil then
                force_swd_lock = GlobalArguments.Force_SWD_Lock or force_swd_lock
            end
            
            Shell("soc -p production-mode")
            local prod_fuse = tonumber(string.match(Last.Output, "production%-mode:%s+([%d]+)"))
            Universal:ReportDataToStationAndPDCA('WirelessPowerTx ProdFused-Status', prod_fuse, '', 0, 1)
            if (prod_fuse ~= 0 or force_swd_lock) then
                PrintString('We made it past the prod fuse check')
                local free_row, data = get_free_otp_row_fw(77,140)
                local burn = true
                
                -- Check to see if the w-command is already written
                for i=1,#data do
                    local val1 = tonumber(data[i][1])
                    local val2 = tonumber(data[i][2])
                    if (val1==bit32.bor(registers.GPIO_GPIO5_GPIO4_IOCTRL,0x1) and val2==0x80000000) then
                        burn=false
                        break
                    end
                end
                
                -- Proceed to burn w-command if flag is true
                if (burn==true) then 
                    local w_commands = {free_row, bit32.bor(registers.GPIO_GPIO5_GPIO4_IOCTRL,0x1), 0x80000000}
                    -- Load TX firmware
                    local fw_mode = 'tx'
                    tx_fw_version = SetupDotara(fw_mode)
                    set_boost(9000)
                    Shell("c26 exec otp write "..w_commands[1].." "..w_commands[2].." "..w_commands[3])
                    Shell('wait 100')
                    set_boost(0)
        
                    local read_back_value = read_otp_range_fw(free_row,1)
                    if (tonumber(read_back_value[1][1])==w_commands[2] and tonumber(read_back_value[1][2])==w_commands[3]) then
                        print("SWD Lock w-command successful")
                        Universal:ReportDataToStationAndPDCA('WirelessPowerTx SWDLock-Written', 1, '', 0, 1)
                        Universal:ReportDataToStationAndPDCA('WirelessPowerTx SWDLock-Status', 1, '', 0, 1)
                    else
                        print("SWD Lock w-command read/write failed")
                        Universal:ReportDataToStationAndPDCA('WirelessPowerTx SWDLock-Written', 0, '', 0, 1)
                        Universal:ReportDataToStationAndPDCA('WirelessPowerTx SWDLock-Status', 0, '', 0, 1)
                    end
                else
                    print("SWD Lock w-command is already burned. Skip")
                    Universal:ReportDataToStationAndPDCA('WirelessPowerTx SWDLock-Written', 0, '', 0, 1)
                    Universal:ReportDataToStationAndPDCA('WirelessPowerTx SWDLock-Status', 1, '', 0, 1)
                end
            else
                print("This is not a prod-fused unit. Skip SWD Lock")
                Universal:ReportDataToStationAndPDCA('WirelessPowerTx SWDLock-Written', 0, '', 0, 1)
                Universal:ReportDataToStationAndPDCA('WirelessPowerTx SWDLock-Status', 0, '', 0, 1)
            end

end

---------------------------------------------------------
-- Function for locking OTP Memory (rows 11 and 12)
function DotaraLockOTP()
    
    require "Burnin"

    local force_OTP_lock = false    
    local status_ok
    local num_rows
    local val0
    local val1
    local row
    local otp_fw_version_expected_min = tonumber('0x30007')
    local otp_fw_version_expected_max = tonumber('0x30007')
    
    local function write_lock_bits()
        fw_setBitMask(registers.RECT_RECTBOOTCTRL,0x00000010)
        DotaraReg_Wr(registers.OTP_OTPCNFG,0x2c)

        configure_otp_clock_fw(6)

        DotaraReg_Wr(registers.OTP_OTPPWR,0x20)
        DotaraReg_Wr(registers.OTP_OTPPROGMODECTRL,0x1)
        DotaraReg_Wr(registers.OTP_OTPPWR,0x28)

        status_ok = check_otp_status_write_fw()

        if (status_ok == 1) then
            DotaraReg_Wr(registers.OTP_OTPADDR,0x0)
            DotaraReg_Wr(registers.OTP_OTPWDATA1,0xf)
            DotaraReg_Wr(registers.OTP_OTPWDATA2,0x0)
            DotaraReg_Wr(registers.OTP_OTPWDATA3,0x0)
            DotaraReg_Wr(registers.OTP_OTPCTRL,0x102)

            idle_check_status_fw()

            for _,value in ipairs({4,8,0xd}) do
                DotaraReg_Wr(registers.OTP_OTPWDATA1,value)
                DotaraReg_Wr(registers.OTP_OTPCTRL,0x102)

                idle_check_status_fw()

            end

            -- write lock bits
            otp_lock_burn_to_row_fw(11,0xFFFFFFFF)
            otp_lock_burn_to_row_fw(12,0xFFFFFFFF)

            --clean up
            DotaraReg_Wr(registers.OTP_OTPCTRL,0x103)
            idle_check_status_fw()

            DotaraReg_Wr(registers.OTP_OTPPWR,0x20)
            DotaraReg_Wr(registers.OTP_OTPPROGMODECTRL,0x0)
            DotaraReg_Wr(registers.OTP_OTPPWR,0x0)
            
        else
        
            print('Bad OTP Status')
            
        end
            
    end
    
    local force_OTP_lock = false
    if GlobalArguments ~= nil then
        force_OTP_lock = GlobalArguments.Force_OTP_Lock or force_OTP_lock
    end
    
    -- Check if unit is prod-fused or not
    Shell("soc -p production-mode")
    local prod_fuse = tonumber(string.match(Last.Output, "production%-mode:%s+([%d]+)"))
    Universal:ReportDataToStationAndPDCA('WirelessPowerTx ProdFused-Status', prod_fuse, '', 0, 1)

    
    --check crc result for FCT, QT0, and Cal data
    crc_result = DotaraCRCCheck()
    Universal:ReportDataToStationAndPDCA('WirelessPowerTx OTPLock-CRCCheck', crc_result, '', 1, 1)

    -- Load OTP FW and read version
    local fw_mode = 'otp'
    otp_fw_version = SetupDotara(fw_mode)
    Universal:ReportDataToStationAndPDCA('WirelessPowerTx OTPLock-OTP Version', tonumber(otp_fw_version), '', otp_fw_version_expected_min, otp_fw_version_expected_max)
    otp_fw_version_check = (otp_fw_version_expected_min <= tonumber(otp_fw_version)) and  (tonumber(otp_fw_version) <= otp_fw_version_expected_max)
    
    -- Load TX firmware
    local fw_mode = 'tx'
    tx_fw_version = SetupDotara(fw_mode)

    -- Need to run DotaraInitTest first
    -- check if OTP has already been locked already
    lock_check = dotara_otp_lock_check()
    
    if (lock_check==1) or (not crc_result) or (not otp_fw_version_check) then
        
        Universal:ReportDataToStationAndPDCA('WirelessPowerTx OTPLock-Burned', 0, '', 0, 1)
        Universal:ReportDataToStationAndPDCA('WirelessPowerTx OTPLock-Status', lock_check, '', 0, 1)

    else -- Lock OTP routine if forced or prod-fused
        
        if (prod_fuse ~= 0 or force_OTP_lock==true) then
            
            set_boost(9000)
            write_lock_bits()
            set_boost(0)
        end 
        
        lock_check = dotara_otp_lock_check()
        Universal:ReportDataToStationAndPDCA('WirelessPowerTx OTPLock-Burned', lock_check, '', 0, 1)
        Universal:ReportDataToStationAndPDCA('WirelessPowerTx OTPLock-Status', lock_check, '', 0, 1)
        
    end
    
    -- Report final test results:
    -- Prod fused unit
    if (prod_fuse~=0 and lock_check==1 and crc_result==1 and otp_fw_version_check==true) then
    
        print("Prod Fused: Execution of DotaraLockOTP Test PASSED! OTP is now locked.")
        Universal:ReportDataToStationAndPDCA('WirelessPowerTx OTPLock-Success', 1, '', 1, 1)
    -- Dev Fused unit   
    elseif (prod_fuse==0 and crc_result==1 and otp_fw_version_check==true) then
    
        print("Dev Fused: Execution of DotaraLockOTP Test PASSED!")
        if (lock_check==1) then
            print("OTP was either forced to lock or was locked previously.")
        else
            print("But OTP is still unlocked.")
        end
        Universal:ReportDataToStationAndPDCA('WirelessPowerTx OTPLock-Success', 1, '', 1, 1)
    
    -- Test failed
    else
    
        print("Execution of DotaraLockOTP Test FAILED!")
        print("Reasons could inlcude: lock_check failed, CRC check failed, OTPFW version check failed")
        Universal:ReportDataToStationAndPDCA('WirelessPowerTx OTPLock-Success', 0, '', 1, 1)
    end
        
    
    -- Adding Dotara Cleanup to leave FW in RX mode for use in future tests
    DotaraCleanup()
end

--Function to check if OTP data written in FCT and QT0 are still in tact
function DotaraCRCCheck()

    require "Burnin"

    local start_row = 77
    local end_row = 140
    local FCT_data_size = 11*2 + 1 -- 11 rows of data with 2 words in each row
    local otp_size = end_row - start_row +1
    local m_command_row_index = 0
    local size_block
    local data

    -- Load TX firmware
    local fw_mode = 'tx'
    tx_fw_version = SetupDotara(fw_mode)

    local otp_read_data = read_otp_range_fw(start_row,otp_size)

    

    local function get_OTP_data(address)
        data = {}
        local i=1
        while (i <= otp_size) do
            local val1 = tonumber(otp_read_data[i][1])
            local val2 = tonumber(otp_read_data[i][2])
            if (bit32.band(val1,0x3) == 0x2 and bit32.rshift(val1,16)~=0 and val2==address) then
                size_block = bit32.rshift(val1,16)
                m_command_row_index = i
                i = i + (size_block+1)
        
            else
                i = i+1
            end
        end

        if (m_command_row_index==0) then
            --print_otp_range_fw(start_row,end_row-start_row+1)
            PrintString("\nFCT Msg: FCT calibration M-command not found in OTP!")
            return -1 -- -1 indicates no FCT calibration found
        end

        for i=1,size_block do
            local val1 = otp_read_data[m_command_row_index+i][1]
            local val2 = otp_read_data[m_command_row_index+i][2]
            table.insert(data,val1)
            table.insert(data,val2)
        end
    
    end

    local address = 0x127EC0
    get_OTP_data(address)
        
    --Split into FCT constants and QT0 constants
    --FCT
    local data_FCT = {}
    for i=1,FCT_data_size do
        table.insert(data_FCT,data[i])
    end
    FCT_CRC = tonumber(bit32.rshift(data_FCT[#data_FCT],16)) -- last entry in the table is the CRC value
    data_FCT[#data_FCT] = bit32.band(data_FCT[#data_FCT],0xFFFF)

    
    --QT0
    local data_QT0 = {}
    for i=FCT_data_size+1,(#data-1) do
        table.insert(data_QT0,data[i])
    end
    QT0_CRC = tonumber(bit32.rshift(data_QT0[#data_QT0],16)) -- last entry in the table is the CRC value
    data_QT0[#data_QT0] = bit32.band(data_QT0[#data_QT0],0xFFFF)
    
    
    calculated_FCT_CRC = generate_CRC(data_FCT,2)
    print("FCT_CRC = 0x".. hex(FCT_CRC))
    
    calculated_QT0_CRC = generate_CRC(data_QT0,2)
    print("QT0_CRC = 0x".. hex(QT0_CRC))
    print("")
    
    local address = 0x127F68
    get_OTP_data(address)
    
    
    table.remove(data,#data)
    CAL_CRC = table.remove(data,#data)
    CAL_CRC = bit32.band(CAL_CRC,0xFFFF)
    
    calculated_CAL_CRC = generate_CRC(data,4)
    print("CAL_CRC = 0x"..hex(CAL_CRC))
    
    if (FCT_CRC==calculated_FCT_CRC) and (QT0_CRC==calculated_QT0_CRC) and (CAL_CRC==calculated_CAL_CRC) then
        print("CRC Check PASSED!")
        Universal:ReportDataToStationAndPDCA('WirelessPowerTx CRC-Check', 1, '', 1, 1)
        return 1 -- this is the result of the CRC check
    else
        print("CRC Check FAILED!")
        Universal:ReportDataToStationAndPDCA('WirelessPowerTx CRC-Check', 0, '', 1, 1)
        return 0 -- this is the result of the CRC check
    end
    
end

function generate_CRC(inData, cummbytes)
    --[[
    Function that calculates s CRC 16. The polynomial is described as following:
    x^16+x^12+x^5+ 1
    
    inData is the data array of 4 bytes each {0x10000000, 0x20000000, 0x30000000, .....}
    --]]
    PrintString("#dotara_generate_CRC\n")
    
    local cummBytes = cummbytes or 4
    
    local inCRC = 0xFFFF
    
    local byteData = {}
    for i=1,#inData do
        local a = bit32.band(inData[i],0xFF)
        table.insert(byteData,a)
        local b = bit32.rshift(inData[i],8)
        a = bit32.band(b,0xFF)
        table.insert(byteData,a)
        b = bit32.rshift(inData[i],16)
        a = bit32.band(b,0xFF)
        table.insert(byteData,a)
        b = bit32.rshift(inData[i],24)
        a = bit32.band(b,0xFF)
        table.insert(byteData,a)
    end
    
    -- Remove extra 0s if needed
    local remainder = cummBytes%4
    while (remainder>0) do
        table.remove(byteData)
        remainder = remainder-1
    end
    
    print("byteData Size: "..#byteData)
    for i=1,#byteData do
        --print("0x"..string.format("%02x", byteData[i]))
        io.write(string.format("%02x", byteData[i]))
    end
    print("")
    
    
    for i=1,#byteData do
        inCRC = bit32.bor(bit32.rshift(inCRC,8), bit32.lshift(inCRC,8))
        inCRC = bit32.bxor(inCRC, byteData[i])
        inCRC = bit32.bxor(inCRC, bit32.rshift(bit32.band(inCRC,0xFF),4))
        inCRC = bit32.bxor(inCRC, bit32.lshift(inCRC,12))
        inCRC = bit32.bxor(inCRC, bit32.lshift(bit32.band(inCRC,0xFF),5))
        inCRC = bit32.band(inCRC,0xFFFF)
    end
    print("Calculated CRC: 0x"..hex(inCRC))
    return inCRC
end

---------------------------------------------------------
-- Function for testing CRC and WCh0 values check
function DotaraSyscfgTest()
    require "Burnin"

    -- smokey --run Wildfire --test DotaraSyscfgTest LogBehavior=ConsoleOnly ResultsBehavior=NoFile ControlBitAccess=ReadOnly BrickRequired=None DisplayBehavior=NoDisplay
    -- Since not checking consumption, we do not need to boot up Dotara at the start
    -- -- Reset Dotara
    -- pcall(Shell, 'baseband --off')
    -- pcall(Shell, 'smc write WAFC 0x6 0 0 0')
    -- Shell('wait 100')
    -- pcall(Shell, 'smc write WAFC 0x6 0 1 0')
    -- Shell('wait 500')
    -- -- Load RX fw 
    -- local fw_vers = SetupDotara('rx')

    -- Read WCh0 sysconfig key
    PrintString('*********************************************************')
    PrintString('Read WCh0 sysconfig values')
    PrintString('*********************************************************')
    local WCh0SysCfgKey = sysCFG_read('WCh0', 36)

    -- Check number of pairs match
    if WCh0SysCfgKey.numPairs==36 then
        Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-Sysconfig WCh0', 1, '', 1, 1)
    else
        Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-Sysconfig WCh0', 0, '', 1, 1)
    end

    -- Check CRC
    local crc_calc = syscfg_gen_CRC(WCh0SysCfgKey)
    if crc_calc == WCh0SysCfgKey.calibrationPairs[36].data then
        Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-Sysconfig Valid_CRC', 1, '', 1, 1)
    else
        Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-Sysconfig Valid_CRC', 0, '', 1, 1)
    end

    -- SMC fw update required before able to test consumption of calibration.
    -- For now just confirming presence of calibration and valid CRC instead
    -- -- Convert calibration to real values
     local hflpp = {}
     local lpp = {}
     lpp.full_drive={}
     local rac = {}
     hflpp.f = WCh0SysCfgKey.calibrationPairs[1].data + WCh0SysCfgKey.calibrationPairs[2].data*(2^16)
     lpp.full_drive.f = WCh0SysCfgKey.calibrationPairs[3].data + WCh0SysCfgKey.calibrationPairs[4].data*(2^16)
     hflpp.Q = WCh0SysCfgKey.calibrationPairs[7].data/1e3
     lpp.full_drive.Q = WCh0SysCfgKey.calibrationPairs[8].data/1e3
     rac.R = WCh0SysCfgKey.calibrationPairs[10].data/1e3
     lpp.R = WCh0SysCfgKey.calibrationPairs[11].data/1e3
     hflpp.L = WCh0SysCfgKey.calibrationPairs[13].data/1e9 + WCh0SysCfgKey.calibrationPairs[14].data*(2^16)/1e9
     lpp.L = WCh0SysCfgKey.calibrationPairs[15].data/1e9 + WCh0SysCfgKey.calibrationPairs[16].data*(2^16)/1e9
     hflpp.C = WCh0SysCfgKey.calibrationPairs[19].data/1e12 + WCh0SysCfgKey.calibrationPairs[20].data/1e12*(2^16)
     lpp.C = WCh0SysCfgKey.calibrationPairs[21].data/1e12 + WCh0SysCfgKey.calibrationPairs[22].data/1e12*(2^16)
     rac.R_coil = WCh0SysCfgKey.calibrationPairs[23].data/1e4
     local flex_resistance = WCh0SysCfgKey.calibrationPairs[24].data/1e3
     local arcas_R_FD = WCh0SysCfgKey.calibrationPairs[25].data/1e3
     local ironman_R_FD = WCh0SysCfgKey.calibrationPairs[26].data/1e3
     local arcas_R_QD = WCh0SysCfgKey.calibrationPairs[27].data/1e3
     local ironman_R_QD = WCh0SysCfgKey.calibrationPairs[28].data/1e3
     local T_Bat = WCh0SysCfgKey.calibrationPairs[29].data/10
     local T_Rect = WCh0SysCfgKey.calibrationPairs[30].data/10
     local T_NTC = WCh0SysCfgKey.calibrationPairs[31].data/10
     local qt0_ver_syscfg = WCh0SysCfgKey.calibrationPairs[32].data
     local Q_EPP = bit32.band(0xFF, WCh0SysCfgKey.calibrationPairs[33].data)
     local f_EPP = bit32.rshift(bit32.band(0xFF00, WCh0SysCfgKey.calibrationPairs[33].data),8) + bit32.lshift(WCh0SysCfgKey.calibrationPairs[34].data,16)
     local OTP_loaded = WCh0SysCfgKey.calibrationPairs[35].data

    -- -- Pass through limits 
     PrintString('*********************************************************')
     PrintString('Run sysconfig values through wide limits')
     PrintString('*********************************************************')
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-HFLPP Q',  hflpp.Q, nil, 9, 16)
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-LPP_174nF Q_FD', lpp.full_drive.Q, nil, 7, 15)
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-HFLPP f',  hflpp.f, 'Hz', 330000, 400000)
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-LPP_174nF f', lpp.full_drive.f, 'Hz', 100000, 150000)
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-RAC R_sys',  rac.R, 'Ohm', 0.4, 1.7) -- Too wide revise
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-LPP_174nF R', lpp.R, 'Ohm', 0.4, 1.1) -- Too wide revise
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-HFLPP L',  hflpp.L, 'H', 8.0e-6, 11.0e-6)
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-LPP_174nF L', lpp.L, 'H', 8.0e-6, 11.0e-6)
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-LPP_174nF C', lpp.C, 'F', 130.0e-9, 210.0e-9)
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-HFLPP C',  hflpp.C, 'F', 15.0e-9, 24.0e-9)
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-RAC R_coil',  rac.R_coil, 'Ohm', 0.4, 1.5) -- Too wide revise
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-RAC R_flex',  flex_resistance, 'Ohm', 10.0e-3, 200.0e-3)
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-RAC arcas_R_FD',  arcas_R_FD, 'Ohm', 0, 2) -- Pull in LSL for RPP Rsys once QT0 updates flow through line
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-RAC ironman_R_FD',  ironman_R_FD, 'Ohm', 0, 4)
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-RAC arcas_R_QD',  arcas_R_QD, 'Ohm', 0, 2)
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-RAC ironman_R_QD',  ironman_R_QD, 'Ohm', 0, 4)
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-RAC T_Rect', T_Rect, 'degC', 10, 100)
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-RAC T_NTC', T_NTC, 'degC', 10, 100)
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-RAC T_Bat', T_Bat, 'degC', 10, 70)
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-Qi Q', Q_EPP, '', 30, 30)
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-Qi f', f_EPP, 'Hz', 0, 180000)
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-QT0 ver', qt0_ver_syscfg, '', qt0_ver_syscfg, qt0_ver_syscfg)
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-QT0 loaded', OTP_loaded, '', 0x4567, 0x4567)
   
end

---------------------------------------------------------
-- Function for testing Dotara Sysconfig consumptions / loading of sysconfig to Dotara SRAM
function DotaraSyscfgTestSRAM()
    require "Burnin"

    -- smokey --run Wildfire --test DotaraSyscfgTest LogBehavior=ConsoleOnly ResultsBehavior=NoFile ControlBitAccess=ReadOnly BrickRequired=None DisplayBehavior=NoDisplay
    -- Since not checking consumption, we do not need to boot up Dotara at the start
    -- -- Reset Dotara
    -- pcall(Shell, 'baseband --off')
    -- pcall(Shell, 'smc write WAFC 0x6 0 0 0')
    -- Shell('wait 100')
    -- pcall(Shell, 'smc write WAFC 0x6 0 1 0')
    -- Shell('wait 500')
    -- -- Load RX fw 
    -- local fw_vers = SetupDotara('rx')

    -- Read WCh0 sysconfig key
    PrintString('*********************************************************')
    PrintString('Read WCh0 sysconfig values')
    PrintString('*********************************************************')
    local WCh0SysCfgKey = sysCFG_read('WCh0', 36)

    -- Check number of pairs match
    if WCh0SysCfgKey.numPairs==36 then
        Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-Sysconfig WCh0', 1, '', 1, 1)
    else
        Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-Sysconfig WCh0', 0, '', 1, 1)
    end

    -- Check CRC
    local crc_calc = syscfg_gen_CRC(WCh0SysCfgKey)
    if crc_calc == WCh0SysCfgKey.calibrationPairs[36].data then
        Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-Sysconfig Valid_CRC', 1, '', 1, 1)
    else
        Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-Sysconfig Valid_CRC', 0, '', 1, 1)
    end

    -- SMC fw update required before able to test consumption of calibration.
    -- For now just confirming presence of calibration and valid CRC instead
    -- -- Convert calibration to real values
     local hflpp = {}
     local lpp = {}
     lpp.full_drive={}
     local rac = {}
     hflpp.f = WCh0SysCfgKey.calibrationPairs[1].data + WCh0SysCfgKey.calibrationPairs[2].data*(2^16)
     lpp.full_drive.f = WCh0SysCfgKey.calibrationPairs[3].data + WCh0SysCfgKey.calibrationPairs[4].data*(2^16)
     hflpp.Q = WCh0SysCfgKey.calibrationPairs[7].data/1e3
     lpp.full_drive.Q = WCh0SysCfgKey.calibrationPairs[8].data/1e3
     rac.R = WCh0SysCfgKey.calibrationPairs[10].data/1e3
     lpp.R = WCh0SysCfgKey.calibrationPairs[11].data/1e3
     hflpp.L = WCh0SysCfgKey.calibrationPairs[13].data/1e9 + WCh0SysCfgKey.calibrationPairs[14].data*(2^16)/1e9
     lpp.L = WCh0SysCfgKey.calibrationPairs[15].data/1e9 + WCh0SysCfgKey.calibrationPairs[16].data*(2^16)/1e9
     hflpp.C = WCh0SysCfgKey.calibrationPairs[19].data/1e12 + WCh0SysCfgKey.calibrationPairs[20].data/1e12*(2^16)
     lpp.C = WCh0SysCfgKey.calibrationPairs[21].data/1e12 + WCh0SysCfgKey.calibrationPairs[22].data/1e12*(2^16)
     rac.R_coil = WCh0SysCfgKey.calibrationPairs[23].data/1e4
     local flex_resistance = WCh0SysCfgKey.calibrationPairs[24].data/1e3
     local arcas_R_FD = WCh0SysCfgKey.calibrationPairs[25].data/1e3
     local ironman_R_FD = WCh0SysCfgKey.calibrationPairs[26].data/1e3
     local arcas_R_QD = WCh0SysCfgKey.calibrationPairs[27].data/1e3
     local ironman_R_QD = WCh0SysCfgKey.calibrationPairs[28].data/1e3
     local T_Bat = WCh0SysCfgKey.calibrationPairs[29].data/10
     local T_Rect = WCh0SysCfgKey.calibrationPairs[30].data/10
     local T_NTC = WCh0SysCfgKey.calibrationPairs[31].data/10
     local qt0_ver_syscfg = WCh0SysCfgKey.calibrationPairs[32].data
     local Q_EPP = bit32.band(0xFF, WCh0SysCfgKey.calibrationPairs[33].data)
     local f_EPP = bit32.rshift(bit32.band(0xFF00, WCh0SysCfgKey.calibrationPairs[33].data),8) + bit32.lshift(WCh0SysCfgKey.calibrationPairs[34].data,16)
     local OTP_loaded = WCh0SysCfgKey.calibrationPairs[35].data

    -- -- Pass through limits 
     PrintString('*********************************************************')
     PrintString('Run sysconfig values through wide limits')
     PrintString('*********************************************************')
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-HFLPP Q',  hflpp.Q, nil, 9, 16)
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-LPP_174nF Q_FD', lpp.full_drive.Q, nil, 7, 15)
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-HFLPP f',  hflpp.f, 'Hz', 330000, 400000)
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-LPP_174nF f', lpp.full_drive.f, 'Hz', 100000, 150000)
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-RAC R_sys',  rac.R, 'Ohm', 0.4, 1.7) -- Too wide revise
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-LPP_174nF R', lpp.R, 'Ohm', 0.4, 1.1) -- Too wide revise
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-HFLPP L',  hflpp.L, 'H', 8.0e-6, 11.0e-6)
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-LPP_174nF L', lpp.L, 'H', 8.0e-6, 11.0e-6)
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-LPP_174nF C', lpp.C, 'F', 130.0e-9, 210.0e-9)
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-HFLPP C',  hflpp.C, 'F', 15.0e-9, 24.0e-9)
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-RAC R_coil',  rac.R_coil, 'Ohm', 0.4, 1.5) -- Too wide revise
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-RAC R_flex',  flex_resistance, 'Ohm', 10.0e-3, 200.0e-3)
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-RAC arcas_R_FD',  arcas_R_FD, 'Ohm', 0, 2) -- Pull in LSL for RPP Rsys once QT0 updates flow through line
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-RAC ironman_R_FD',  ironman_R_FD, 'Ohm', 0, 4)
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-RAC arcas_R_QD',  arcas_R_QD, 'Ohm', 0, 2)
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-RAC ironman_R_QD',  ironman_R_QD, 'Ohm', 0, 4)
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-RAC T_Rect', T_Rect, 'degC', 10, 100)
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-RAC T_NTC', T_NTC, 'degC', 10, 100)
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-RAC T_Bat', T_Bat, 'degC', 10, 70)
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-Qi Q', Q_EPP, '', 30, 30)
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-Qi f', f_EPP, 'Hz', 0, 180000)
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-QT0 ver', qt0_ver_syscfg, '', qt0_ver_syscfg, qt0_ver_syscfg)
     Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-QT0 loaded', OTP_loaded, '', 0x4567, 0x4567)

    -- -- Read loaded SRAM and compare to sysconfig
     local QT0_length = 36*2
     local QT0_words = QT0_length/4
     local QT0_SRAM = DotaraRead32(0x127F1C, QT0_length, QT0_words)
     local sram_matches_sysconfig = true
     PrintString('*********************************************************')
     PrintString('Compare calibration loaded into SRAM with Sysconfig')
     PrintString('*********************************************************')
     PrintString('Format = Syconfig value, SRAM value')
     for i=1,QT0_words do
         local cal_pair = ((i-1)*2 + 1)
         PrintString('calibration pair ' .. cal_pair .. ': ' .. WCh0SysCfgKey.calibrationPairs[cal_pair].data .. ', ' .. bit32.band(0xFFFF,QT0_SRAM[i]))
         if WCh0SysCfgKey.calibrationPairs[cal_pair].data~=bit32.band(0xFFFF,QT0_SRAM[i]) then
             sram_matches_sysconfig=false
         end
         cal_pair = ((i-1)*2 + 2)
         PrintString('calibration pair ' .. cal_pair .. ': ' .. WCh0SysCfgKey.calibrationPairs[cal_pair].data .. ', ' .. bit32.band(0xFFFF,bit32.rshift(QT0_SRAM[i],16)))
         if WCh0SysCfgKey.calibrationPairs[cal_pair].data~=bit32.band(0xFFFF,bit32.rshift(QT0_SRAM[i],16)) then
             sram_matches_sysconfig=false
         end
     end
     -- Report all match
     if sram_matches_sysconfig then
         Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-Sysconfig Consumed', 1, '', 1, 1)
     else
         Universal:ReportDataToStationAndPDCA('WirelessPowerTx ObjectDetect-Sysconfig Consumed', 0, '', 1, 1)
     end
    
end


return Dotara