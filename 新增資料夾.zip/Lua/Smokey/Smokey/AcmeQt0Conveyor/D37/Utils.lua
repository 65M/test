local Utils = {}

function Utils.WaitForHandelingTime()
    Shell ("nvram --get boot-args")
    bootargs = Last.Output:match("boot%-args = (.+)")
    print ("ACME:: dumping all bootargs: ", bootargs)
    if (bootargs:find("hflppWait")) then
        Pre, Post = bootargs:match("(.*)hflppWait%=(.*)")
        bootargs = (Pre or "") .. (Post or "")
        waitCmd = "wait "..Post
        print("ACME:: found hflppWait, waitCmd: ", waitCmd)
        Shell(waitCmd)
    else 
        Shell("wait 12000")
    end
end

function Utils.WaitForPowerButtonPressed()
    Shell("button -h -t 1000000")
    if (string.find(Last.Output, "PASS") == nil) then
        return -1
    else
        return 1
    end
end

function Utils.WaitForVolumeDownButtonPressed()
    Shell("button -d -t 1000")
    if (string.find(Last.Output, "PASS") == nil) then
        return -1
    else
        return 1
    end
end

function Utils.WaitForVolumeUpButtonPressed()
    Shell("button -u -t 1000000")
    if (string.find(Last.Output, "PASS") == nil) then
        return -1
    else
        return 1
    end
end

function Utils.RebootToNonUI()
    pcall(Shell,'nvram --set boot-command fsboot')
    pcall(Shell,'nvram --save')
    Shell("reset")
end

function Utils.DisplayText(text, type)
    local displayCMD = "displaytext -f l -c white -b cyan  -t '" .. text .."'"

    if type == "PASS" then 
        displayCMD = "displaytext -f l -c white -b green  -t '" .. text .."'"
    elseif type == "FAIL" then
        displayCMD = "displaytext -f l -c white -b red  -t '" .. text .."'"
    end
    
    Shell(displayCMD)
    Shell("wait 2000")
end

function Utils.file_exists(name)
    local f=io.open(name,"r")
    if f~=nil then io.close(f) return true else return false end
 end

function Utils.GetFileExtension(url)
    return url:match("^.+(%..+)$")
end

function Utils.AppendFilenameWithTimestamp(filePath)
    if helpers.file_exists(filePath) then
        date = os.date('%Y-%m-%d_%H:%M:%S')
        -- print("date:" .. date)
        fileExtension = helpers.GetFileExtension(filePath)
        print("ACME:: fileExtension: " .. fileExtension)
        newFileName = filePath:gsub(fileExtension, "-" .. date .. fileExtension)
        print("ACME:: new filename: " .. newFileName)

        -- NOTE: using 'mv' to rename files gives an error status: unsupported
        -- so we're using 'cp' to make a copy of the file with the new name and then
        -- using 'rm' to delete the original PDCA.plist file.
        -- The mv implementation calls into the APFS driver to let it do the actual move.  The APFS driver does not support this use case (specifically, when subdirs paths are involved), so it eventually sends back  the UNSUPPORTED error.
        Shell("cp " .. filePath .. " " .. newFileName)
        pcall(Shell,"rm -q " .. filePath)
        return true
    else
        print("ACME:: file doesn't exist")
        return false
    end
end

function Utils.runAFunctionIfPossible(fn)
    local retries = 0
    local maxTries = 3
    local lastFailedResult
    local didRetried = false
    while (retries < maxTries) do
        Utils.opsLog("About to run the function with retry ", retries)
        local success, result = pcall(fn)
        if success then
            Utils.opsLog("Successfully ran the function")
            return success, result, didRetried
        else
            Utils.opsLog("Failed to run the function")
            didRetried = true
            lastFailedResult = result
            retries = retries + 1
            Utils.DisplayText("Retrying"..retries)
            Utils.opsLog("Error from the last run:", result)
        end
    end
    Utils.DisplayText("FAILED", "FAIL")
    Shell("wait 120000")
    return false, lastFailedResult, true
end

function Utils.opsLog(message, ...)
    local printResult = "c[_]"..os.date('%Y-%m-%d %H:%M:%S')..", MSG: "..message.." "
    local vararg = {...}
    for i,v in ipairs(vararg) do
        printResult = printResult .. tostring(v) .. "\t"
    end
    print(printResult)
end

return Utils
