-- AcousticCal: Burnin Acoustic Calibration scripts for D83,D84, D37 and D38
-- Authors: Navneet Gandhi/Adrian Tregonning/Bill Jahn/Ziheng Chen/Bovey Zheng
--
-- Comprised of two tests:
-- 1. Speaker RDC Calibration
-- 2. T&S Parameter estimation

local AL = require "AcousticsLib"
require 'torch'
local dsp = require "TorchDSP"
require 'Burnin'

-- Some variables global to all tests
local gGlobalsInitialized = false
local gUnitType
local gTMSpeakersParams
local gHSSpeakersParams
local gSampleRate
local gWaveFilesPath
local gOutputFilesPath
local gAcousticCalOutputFilePrefix
local gVMONFS
local gIMONFS
local gRepairFlag                           -- Repair Center Flag: indicates AcousticCal is being run on repair line
local gTSReporting = true					-- Flag for calculating TS params for syscfg/Insight reporting (disabled for MP)

function InitGlobals()

	if(not gGlobalsInitialized) then

		gUnitType = PlatformInfo("PlatformName")

		gTMSpeakersParams = {}
		-- gTMSpeakersParams["TopSpeaker"] = {}
		-- gTMSpeakersParams["TopSpeaker"].group = "TopModuleSpeakers"
		-- gTMSpeakersParams["TopSpeaker"].PDCAPrefix = "TSPK_"                   -- All PDCA keys for this speaker will be prefixed with..
		-- gTMSpeakersParams["TopSpeaker"].PrettyName = "Top Speaker"
		-- gTMSpeakersParams["TopSpeaker"].DiagsSpeakerName = "topspeaker"        -- Speaker name used by diags commands
		-- gTMSpeakersParams["TopSpeaker"].KeyOrder = 1                      	   -- Deterimines the order in which speaker data is written in the SpPT and SpPH key.
		-- gTMSpeakersParams["TopSpeaker"].TSEnabled = true
		-- gTMSpeakersParams["TopSpeaker"].IDName = "TopS"
		-- gTMSpeakersParams["TopSpeaker"].IDCode = "0x546F7053"

		gHSSpeakersParams = {}
		gHSSpeakersParams["BotSpeaker"] = {}
		gHSSpeakersParams["BotSpeaker"].group = "HousingSpeakers"
		gHSSpeakersParams["BotSpeaker"].PDCAPrefix = "BSPK_"
		gHSSpeakersParams["BotSpeaker"].PrettyName = "Bottom Speaker"
		gHSSpeakersParams["BotSpeaker"].DiagsSpeakerName = "botspeaker"
		gHSSpeakersParams["BotSpeaker"].KeyOrder = 1
		gHSSpeakersParams["BotSpeaker"].TSEnabled = true
		gHSSpeakersParams["BotSpeaker"].IDName = "BotS"
		gHSSpeakersParams["BotSpeaker"].IDCode = "0x426F7453"

		gHSSpeakersParams["TopSpeaker"] = {}
		gHSSpeakersParams["TopSpeaker"].group = "HousingSpeakers"
		gHSSpeakersParams["TopSpeaker"].PDCAPrefix = "TSPK_"                   -- All PDCA keys for this speaker will be prefixed with..
		gHSSpeakersParams["TopSpeaker"].PrettyName = "Top Speaker"
		gHSSpeakersParams["TopSpeaker"].DiagsSpeakerName = "topspeaker"        -- Speaker name used by diags commands
		gHSSpeakersParams["TopSpeaker"].KeyOrder = 2                      	   -- Deterimines the order in which speaker data is written in the SpPT and SpPH key.
		gHSSpeakersParams["TopSpeaker"].TSEnabled = true
		gHSSpeakersParams["TopSpeaker"].IDName = "TopS"
		gHSSpeakersParams["TopSpeaker"].IDCode = "0x546F7053"

		-- For the purposes of this script, RF variants are equivalent.
		if (string.match(gUnitType, "D83")) then
			gUnitType = "D83"
			gHSSpeakersParams["TopSpeaker"].RDC_Temp_slope = 0.033482
			gHSSpeakersParams["BotSpeaker"].RDC_Temp_slope = 0.02898

			gHSSpeakersParams["TopSpeaker"].ERS_20_low = 9.0
			gHSSpeakersParams["TopSpeaker"].ERS_20_high = 9.8

			gHSSpeakersParams["BotSpeaker"].ERS_20_low = 9.86
			gHSSpeakersParams["BotSpeaker"].ERS_20_high = 10.66

			gHSSpeakersParams["TopSpeaker"].PcmVol = -24
			gHSSpeakersParams["BotSpeaker"].PcmVol = -24

		elseif (string.match(gUnitType, "D84")) then
			gUnitType = "D84"
			gHSSpeakersParams["TopSpeaker"].RDC_Temp_slope = 0.03194
			gHSSpeakersParams["BotSpeaker"].RDC_Temp_slope = 0.035251

			gHSSpeakersParams["TopSpeaker"].ERS_20_low = 9.8
			gHSSpeakersParams["TopSpeaker"].ERS_20_high = 10.6

			gHSSpeakersParams["BotSpeaker"].ERS_20_low = 9.85
			gHSSpeakersParams["BotSpeaker"].ERS_20_high = 10.65

			gHSSpeakersParams["TopSpeaker"].PcmVol = -24
			gHSSpeakersParams["BotSpeaker"].PcmVol = -24

		elseif (string.match(gUnitType, "D37")) then
			gUnitType = "D37"
			gHSSpeakersParams["TopSpeaker"].RDC_Temp_slope =  0.038101
			gHSSpeakersParams["BotSpeaker"].RDC_Temp_slope = 0.027944

			gHSSpeakersParams["TopSpeaker"].ERS_20_low = 9.6
			gHSSpeakersParams["TopSpeaker"].ERS_20_high = 10.4

			gHSSpeakersParams["BotSpeaker"].ERS_20_low = 8.1
			gHSSpeakersParams["BotSpeaker"].ERS_20_high = 8.9

			gHSSpeakersParams["TopSpeaker"].PcmVol = -24
			gHSSpeakersParams["BotSpeaker"].PcmVol = -24 

		elseif (string.match(gUnitType, "D38")) then
			gUnitType = "D38"
			gHSSpeakersParams["TopSpeaker"].RDC_Temp_slope =  0.03298
			gHSSpeakersParams["BotSpeaker"].RDC_Temp_slope = 0.034137

			gHSSpeakersParams["TopSpeaker"].ERS_20_low = 9.0
			gHSSpeakersParams["TopSpeaker"].ERS_20_high = 9.8

			gHSSpeakersParams["BotSpeaker"].ERS_20_low = 9.35
			gHSSpeakersParams["BotSpeaker"].ERS_20_high = 10.15

			gHSSpeakersParams["TopSpeaker"].PcmVol = -24
			gHSSpeakersParams["BotSpeaker"].PcmVol = -24

		else
			error("Unable to identify device type!")
		end

		PrintString("UNIT TYPE: " .. gUnitType)

		gWaveFilesPath = "nandfs:\\AppleInternal\\Diags\\AudioTests\\" .. gUnitType .. "\\"

		gOutputFilesPath = "nandfs:\\AppleInternal\\Diags\\Logs\\Smokey\\AcousticCal\\"

		gAcousticCalOutputFilePrefix = "ACALOUT_" 						-- Output file prefix for wave files written to the device in AcousticCal
		gSampleRate = 48000

		gVMONFS = 12300					-- VMON ADC FS multiplier
		gIMONFS = 1680 					-- IMON ADC FS multiplier

		if tonumber(GlobalArguments.RC) == 1 then
			gRepairFlag = 1
		else
			gRepairFlag = 0
		end

		gGlobalsInitialized = true
	end
end

--Move system to an idle state
function IdleState()
	Shell "soc --set 'perfstate cpu 0'"
	-- Shell "bl -l" --Command not available for P1

	-- Turn off mesa since it comes into EFI with rails powered up
	-- Shell "touch --sel mesa --on"  --Command not available for P1
	-- Shell "touch --sel mesa --off" --Command not available for P1
end

function WaitSetTime()
	WaitForSeconds(600)	--Wait a set time of 10 mins for D5x
end

function RamlogInit()
	Shell "ramlog --on 10"
	Shell "consolerouter -a -d ramlog -s smc.debug.notifications,system.debug.debug,charger"
end

function RunAllTests()

	local startTime = os.time()
	local Passed
	local ErrMsg

	InitGlobals()

	if (gRepairFlag == 1) then
		PrintString("Executing RC AcousticCal")
	else
		PrintString("Executing FATP AcousticCal")
	end

	-- RamlogInit()
	-- Allow unit to detect VBUS <rdar://problem/32096629> D2X - AcousticCal - VBUS not detected
	Shell "wait 3000"
	Shell "display --off"
	Shell "soc --set 'perfstate soc 0'"
	Shell "soc --set 'perfstate dcs 0'"
	Shell "soc --set 'perfstate cpu 0'"
	Shell "soc --set 'perfstate gpu 0'"
	Shell "soc --set 'perfstate ane 0'"

	Shell "baseband --off"
	Shell "touch --off"
	Shell "wifi --off"
	Shell "bluetooth --off"
	Shell "camisp --exit"
	-- Bovey: Turnoff for data collection
	-- Passed, ErrMsg = SetChargeWithLogs(100)
	-- if not Passed then
	-- 	error(ErrMsg)
	-- end
	Shell "charge --status"
--[[ %Move after Speaker Calibration
	if(string.match(gUnitType,"D37")) then		
		-- RDC_TDEV_DOE(21, 5)  --Step up the gain setting from -26 to -6. 
	--	RDC_TDEV_DOE(7, 5) --Step up the gain setting from -26 to -20 by step 1
	--	RDC_TDEV_DOE2(4, 5) --Step up the gain setting from -18 to -12 by step 2
		RDC_TDEV_DOE3(-26)
		RDC_TDEV_DOE3(-25)
		RDC_TDEV_DOE3(-24)
		RDC_TDEV_DOE3(-23)
		RDC_TDEV_DOE3(-22)
		RDC_TDEV_DOE3(-21)
		RDC_TDEV_DOE3(-20)
		RDC_TDEV_DOE3(-18)
		RDC_TDEV_DOE3(-16)
		RDC_TDEV_DOE3(-14)
		RDC_TDEV_DOE3(-12)
		RDC_TDEV_DOE3(-9)
		RDC_TDEV_DOE3(-6.625)
	end
--]]
	-- RDC_TDEV_DOE(50, 30) -- 50 iterations, 30s apart (total 25 mins)
	-- Change to 40 iterations to collect the data for D5x EVT mini build
	WaitSetTime() -- D5x set as 10mins					-- Same as D5x

	local TMSpeakerAllParams = {}
	local HSSpeakerAllParams = {}

	if (gRepairFlag == 1) then
		RunAllTestsRC(TMSpeakerAllParams, HSSpeakerAllParams)
	else
		RunAllTestsFATP(TMSpeakerAllParams, HSSpeakerAllParams)
	end

		-- Declare SpTS key values and write SpTS key

	local KeyVersion = 2
	local numBytesPerSpeaker = 22  -- Bytes of data structure (TS+4CC) per speaker
	local numTMSpeakers = 0
	local numHSSpeakers = 2

	-- Formatting syscfg key values into SpPH (For D6x)
--  local SpPTString = string.format("syscfg addbyte SpPT %02X 00 %02X %02X", KeyVersion, numBytesPerSpeaker, numTMSpeakers)
	local SpPHString = string.format("syscfg addbyte SpPH %02X 00 %02X %02X", KeyVersion, numBytesPerSpeaker, numHSSpeakers)

--	SpPTString = SpPTString .. GetSpeakerTSHexString(gTMSpeakersParams, TMSpeakerAllParams, "SpPT")
	SpPHString = SpPHString .. GetSpeakerTSHexString(gHSSpeakersParams, HSSpeakerAllParams, "SpPH")

	-- Turn on after checksum domain has been enabled in the new key
--	SpPTString = SpPTString .. GetCheckSumHexString(string.sub(SpPTString, 21))
	SpPHString = SpPHString .. GetCheckSumHexString(string.sub(SpPHString, 21))

--	print(SpPTString)
	print(SpPHString)

--	Shell(SpPTString)
	Shell(SpPHString)

	--Shell(syscfgString)

--	if(string.match(gUnitType,"D37")) then		
		-- RDC_TDEV_DOE(21, 5)  --Step up the gain setting from -26 to -6. 
	--	RDC_TDEV_DOE(7, 5) --Step up the gain setting from -26 to -20 by step 1
	--	RDC_TDEV_DOE2(4, 5) --Step up the gain setting from -18 to -12 by step 2
	--	RDC_TDEV_DOE3(-26)
	--	RDC_TDEV_DOE3(-25)
	--	RDC_TDEV_DOE3(-24)
	--	RDC_TDEV_DOE3(-23)
	--	RDC_TDEV_DOE3(-22)
	--	RDC_TDEV_DOE3(-21)
	--	RDC_TDEV_DOE3(-20)
	--	RDC_TDEV_DOE3(-18)
	--	RDC_TDEV_DOE3(-16)
	--	RDC_TDEV_DOE3(-14)
	--	RDC_TDEV_DOE3(-12)
	--	RDC_TDEV_DOE3(-9)
	--	RDC_TDEV_DOE3(-6.625)
	--	RDC_TDEV_DOE3(-5.5)
--	end

-- New added for D38 EVT RDC DOEs
--	if(string.match(gUnitType, "D38")) then
--		PreHeat()
--		WaitSetTime()
--		PostRDCCalibration()

--	elseif(string.match(gUnitType, "D84")) then
--		PreHeat2(-2.25) --4.85Vrms
--		WaitSetTime()
--		PostRDCCalibration()

--	elseif(string.match(gUnitType, "D37")) then
--		PreHeat2(-3.25) --4.3Vrms
--		WaitSetTime()
--		PostRDCCalibration()

--	elseif(string.match(gUnitType, "D83")) then
--		PreHeat2(-3.35) --4.2Vrms
--		WaitSetTime()
--		PostRDCCalibration()		

--	elseif
--		RDC_TDEV_DOE3(-23)
--		RDC_TDEV_DOE3(-22)
--		RDC_TDEV_DOE3(-21)
--		RDC_TDEV_DOE3(-20)
--		RDC_TDEV_DOE3(-18)
--		RDC_TDEV_DOE3(-16)
--		RDC_TDEV_DOE3(-14)
--		RDC_TDEV_DOE3(-12)
--		RDC_TDEV_DOE3(-9)
--		RDC_TDEV_DOE3(-6.625)
--		RDC_TDEV_DOE3(-5.5)
--	end

	Shell "soc --set 'perfstate cpu 4'"

	-- <rdar://problem/40033532> Tracking Radar: AcousticCal: charge --set 1000 --force
	-- Don't error out of the test here, the cable might have been unplugged
	-- Passed, ErrMsg = SetChargeWithLogs(1000, nil, true, true)
	Shell "charge --status"
	Shell "device -k GasGauge -p"
	Shell "display --on"

	print("AcousticCal TOTAL TEST TIME: " .. (os.time() - startTime)/60 .. " minutes")

end

function RunAllTestsFATP(TMSpeakerAllParams, HSSpeakerAllParams)

	local startTime = os.time()

	TMSpeakerAllParams["RDCParams"], HSSpeakerAllParams["RDCParams"] = RDCCalibration()
	print("RDC END TIME: " .. (os.time() - startTime)/60 .. " minutes")
	Shell "soc --set 'perfstate cpu 5'"
	TMSpeakerAllParams["TSParams"], HSSpeakerAllParams["TSParams"] = TSCalibration()
	print("TS END TIME: " .. (os.time() - startTime)/60 .. " minutes")

end

function RunAllTestsRC(TMSpeakerAllParams, HSSpeakerAllParams)

	local startTime = os.time()

	TMSpeakerAllParams["RDCParams"], HSSpeakerAllParams["RDCParams"] = RDCCalibration()
	print("RDC END TIME: " .. (os.time() - startTime)/60 .. " minutes")
	Shell "soc --set 'perfstate cpu 5'"

end

function GetSpeakerTSHexString(gSpeakerParams, AllParams, KeyName)

	local SpeakerOrderInKey = {}

	local speakerCount = 0
	for speakerName, speakerParams in pairs(gSpeakerParams) do
		assert(SpeakerOrderInKey[speakerParams.KeyOrder] == nil, "Duplicate KeyOrder found!")
		SpeakerOrderInKey[speakerParams.KeyOrder] = speakerName
		speakerCount = speakerCount + 1
	end

	local returnString = ""

	PrintString("\n\nPreparing parameters for " .. KeyName .. " :")
	for n = 1, #SpeakerOrderInKey do

		speakerName = SpeakerOrderInKey[n]

		local TwoByteValues = {}

		PushTwoByteValue(KeyName, TwoByteValues, AllParams, "TSParams", speakerName, "f0", 10)
		PushTwoByteValue(KeyName, TwoByteValues, AllParams, "TSParams", speakerName, "Qts", 1000)
		PushTwoByteValue(KeyName, TwoByteValues, AllParams, "RDCParams", speakerName, "RDC", 1000)
		PushTwoByteValue(KeyName, TwoByteValues, AllParams, "RDCParams", speakerName, "RDCTemp", 100)
		PushTwoByteValue(KeyName, TwoByteValues, AllParams, "TSParams", speakerName, "Le", 100000000)
		PushTwoByteValue(KeyName, TwoByteValues, AllParams, "TSParams", speakerName, "Kms", 1)
		PushTwoByteValue(KeyName, TwoByteValues, AllParams, "TSParams", speakerName, "Mms", 10000000)
		PushTwoByteValue(KeyName, TwoByteValues, AllParams, "TSParams", speakerName, "Bl", 10000)
		PushTwoByteValue(KeyName, TwoByteValues, AllParams, "TSParams", speakerName, "Rms", 1000)

		assert(#TwoByteValues == 9 , "D6X programs parameter must have 9 bytes TS values per speaker")

		for n = 1, #TwoByteValues do
			-- if (n % 2 == 1) then returnString = returnString .. " 0x" end
			local TwoByteValueString = string.format("%04X", TwoByteValues[n])
			returnString = returnString .. string.format(" %s %s", string.sub(TwoByteValueString, 3, 4), string.sub(TwoByteValueString, 1, 2))  -- Convert to Little-endian
		end

		local speakerIDCode = gSpeakerParams[speakerName].IDCode

		returnString = returnString .. string.format(" %s %s %s %s", string.sub(speakerIDCode, 9, 10), string.sub(speakerIDCode, 7, 8), string.sub(speakerIDCode, 5, 6), string.sub(speakerIDCode, 3, 4))

	end

	return returnString
end

function PushTwoByteValue(Keyname, Array, MeasuredParams, ParameterSetName, SpeakerName, ParameterName, Scaling)

	assert(Array ~= nil and MeasuredParams ~= nil
			and ParameterSetName ~= nil and SpeakerName ~= nil and
			ParameterName ~= nil and Scaling ~= nil,
			"Invalid parameter supplied to PushTwoByteValue")

	local valueFound = true;

	if MeasuredParams[ParameterSetName] == nil then
		PrintString("WARNING: Parameter set " .. ParameterSetName .. " is missing for all speakers! Writing 0s to SpTS.")
		valueFound = false
	elseif MeasuredParams[ParameterSetName][SpeakerName] == nil then
		PrintString("WARNING: parameter set " .. ParameterSetName .. " does not exist for " .. SpeakerName .. ". Writing 0s to SpTS.")
		valueFound = false
	elseif MeasuredParams[ParameterSetName][SpeakerName][ParameterName] == nil then
		PrintString("WARNING: ParameterName " .. ParameterName .. " not found for " .. SpeakerName .. ". Writing 0 value to SpTS key.")
		valueFound = false
	end

	local valueWritten = 0
	if valueFound then
		val = MeasuredParams[ParameterSetName][SpeakerName][ParameterName] * Scaling
		local valueInRange = not (val < 0 or val > 2^16-1 or val ~= val or val == 1/0 or val == -1/0)
		valueWritten = valueInRange and val or 0

		local outOfRangeMessage = valueInRange and "" or "(out of range)"
		PrintString(string.format("%s[%s][%s] = %f %s | Wrote to %s: %d (0x%04x)",
			ParameterSetName, SpeakerName, ParameterName, val, outOfRangeMessage, KeyName, valueWritten, valueWritten))
	else
		valueWritten = 0
		PrintString(string.format("%s[%s][%s] not found. Writing 0x0000.", ParameterSetName, SpeakerName, ParameterName))
	end

	table.insert(Array, valueWritten)
end

function GetCheckSumHexString(InputString)
	local sum = 0;
	for byteHex in string.gmatch(InputString, "%S+") do
		-- PrintString("byteHex: " .. byteHex)
		sum = sum + tonumber(byteHex, 16)
		-- PrintString("sum: " .. sum)
	end
	local checkSumString = string.format("%04X", 65536 - (sum % 65536))
	return string.format(" %s %s", string.sub(checkSumString, 3, 4), string.sub(checkSumString, 1, 2))
end

function FiniteOrZero(Number)
	if (Number ~= Number or Number == 1/0 or Number == -1/0) then
		return 0
	else
		return Number
	end
end

function GetPMUTemperatures()
	local tempsInC = {}

	Shell "temperature --dev pmu"
	for key, value in Last.Output:gmatch("(T.-)%c*%s*Instant: (%-*%d+%.?%d*)") do
		tempsInC[key] = tonumber(value)
	end

	return tempsInC
end

-- Gaussian smoothing function
function gaussian_smooth(sig, width)
	width = math.floor(width)

	local sigma_width  = width/12.0
	local sigma2_width = sigma_width*sigma_width
	local two_sigma2_width = 2*sigma2_width

	local retval = {}

	-- Prepare coefficients to avoid transcendental functions in the main loop
	local scale = 1
	local coeffs = {}

	coeffs[width + 1] = 1;

	for j = 2, width + 1, 1 do
		local v = math.exp(-j*j/two_sigma2_width)
		scale = scale + (2*v)
		coeffs[width + j] = v
		coeffs[width + 2 - j] = v
	end

	-- correct coefficients by scale value to avoid unnecessary divisions in the main loop
	for j = 1, #coeffs do
		coeffs[j] = coeffs[j] / scale
	end

	-- Pad start/end of signal with start/end value for convolution
	local start_val = sig[1]
	local end_val = sig[#sig]
	local padded_sig = {}

	for i = 1, width, 1 do
		padded_sig[i] = start_val
	end
	for i = 1, #sig, 1 do
		padded_sig[width + i] = sig[i]
	end
	local len_pad = #padded_sig
	for i = 1, width, 1 do
		-- print(len_pad + i)
		padded_sig[len_pad + i] = end_val
	end

	for i = width+1, #padded_sig - width, 1 do
		local acum = 0
		for j = -width, width, 1 do
			acum = acum + coeffs[j+width+1] * padded_sig[i+j]
		end
		retval[i-width] = acum
	end

	return retval

end

-- I'm porting last years TS algorithm for P1
function compute_TS(smoothZ, Z, freqZ, SearchParams, PDCAPrefix)

	-- Ze(f) = Re + Le*s + Bl^2/Zm(f) -> Electrical impedance seen from L19 IV sense
	-- Zm(f) = s*Mms + Rms + Kms/s -> Mechanical impedance seen in the mechanical domain
	-- s = j*2*pi*f
	-- Re is resistance
	-- Le is inductance
	-- Bl is force factor
	-- Mms is mechanical mass (incl acoustic load)
	-- Rms is mechanical damping (incl acoustic load)
	-- Kms is mechanical stiffness (incl acoustic load)

	local retval = {}
	retval.mag = smoothZ

	--Assumed Bl for our TS calculations
	retval.Bl = SearchParams.Bl

	SearchParams.f_low_Q_1 = SearchParams.fmin_rdc
	SearchParams.f_high_Q_1 = 1200
	SearchParams.f_low_Q_2 = SearchParams.fmin_le
	SearchParams.f_high_Q_2 = SearchParams.fmax_le

	--Calculate the remaining "SearchParams" min and max values based on SearchParams
	local i = 1
	while freqZ[i] <= SearchParams.fmin_rdc do i = i + 1 end
   	SearchParams.frdc_ind1 = i

	i = 1
	while freqZ[i] <= SearchParams.fmax_rdc do i = i + 1 end
	SearchParams.frdc_ind2 = i

	i = 1
	while freqZ[i] <= SearchParams.fmin_f0 do i = i + 1 end
	SearchParams.fmin_ind = i - 1

	i = 1
	while freqZ[i] <= SearchParams.fmax_f0 do i = i + 1 end
	SearchParams.fmax_ind = i - 1

	i = 1
	while freqZ[i] <= SearchParams.fmin_le do i = i + 1 end
	SearchParams.fle_ind1 = i - 1

	i = 1
	while freqZ[i] <= SearchParams.fmax_le do i = i + 1 end
	SearchParams.fle_ind2 = i - 1

	i = 1
	while freqZ[i] <= SearchParams.f_low_Q_1 do i = i + 1 end
	SearchParams.f_low_Q_1_ind = i - 1

	i = 1
	while freqZ[i] <= SearchParams.f_high_Q_1 do i = i + 1 end
	SearchParams.f_high_Q_1_ind = i - 1

	i = 1
	while freqZ[i] <= SearchParams.f_low_Q_2 do i = i + 1 end
	SearchParams.f_low_Q_2_ind = i - 1

	i = 1
	while freqZ[i] <= SearchParams.f_high_Q_2 do i = i + 1 end
	SearchParams.f_high_Q_2_ind = i - 1

	--Find Rdc by taking the average resistance over a range of low frequency points in the impedance vector
    --Using the un-smoothed impedance curve for this calculation. Seems to be more accurate in the low freq range

	-- print('Indices', SearchParams.fmin_ind, SearchParams.fmax_ind)
	print("Calculating Rdc")
	local Rdc = 0
	for i = SearchParams.frdc_ind1, SearchParams.frdc_ind2 do
        Rdc = Rdc + Z[i]
    end

    retval.r_dc = Rdc/(SearchParams.frdc_ind2 - SearchParams.frdc_ind1 + 1)

	print("Calculating f0, Zmax")
	--calculate F0, Impedance max (Zmax)
    local max = 0
    local res_ind

    for i = SearchParams.fmin_ind, SearchParams.fmax_ind do
        if math.abs(retval.mag[i]) > max then
            max = retval.mag[i]
            res_ind = i
        end
    end

    retval.max_mag = math.abs(retval.mag[res_ind])		--impedance max magnitude to be reported
    retval.f0 = freqZ[res_ind]							--f0 to be reported


    local rc = retval.max_mag/retval.r_dc				--rc is Zmax/Rdc ratio

	--calculate index for f1 in F0 and Q calculations
    local f1_ind
    for i = SearchParams.fmin_ind, res_ind, 1 do
        if math.abs(retval.mag[i]) <= math.sqrt(rc)*retval.r_dc then
            f1_ind = i
        end
    end

	if f1_ind == nil then
		PrintString("Cannot calculate f0 - invalid f1 value")
		ReportData(PDCAPrefix .. "Invalid_f1", 1, "mV",-0.5,0.5)
	end

    --calculate index for f2 in F0 and Q calculation
    local f2_ind

	-- print('sqrt(rc)*r_dc', math.sqrt(rc)*retval.r_dc)
	PrintString('sqrt(rc)*r_dc = '.. tostring(math.sqrt(rc)*retval.r_dc))

	for i =	res_ind, SearchParams.fmax_ind, 1 do
		-- print(i, retval.mag[i])
        if math.abs(retval.mag[i]) >= math.sqrt(rc)*retval.r_dc then
            f2_ind = i
        else
			break			-- modification to handle noise around the fmax_ind frequency
		end
    end

	-- print('f2_ind', f2_ind)
	if f2_ind == nil then
		PrintString("Cannot calculate f0 - invalid f2 value")
		ReportData(PDCAPrefix .. "Invalid_f2", 1, "mV",-0.5,0.5)

	end

	if f1_ind == nil or f2_ind == nil then
		retval.f0 = 0
		retval.Qms = 0
		retval.Qes = 0
		retval.Qts = 0
		retval.Rms = 0
		retval.Mms = 0
		retval.Kms = 0
		retval.Le = 0
	else
		PrintString( "f1_ind = ".. tostring(f1_ind).. ", f2_ind = ".. tostring(f2_ind))

		local f1 = freqZ[f1_ind]
		local f2 = freqZ[f2_ind]

		retval.f0 = math.sqrt(f1*f2)

		--calculate Qms = (f0 * sqrt(Zmax/Rdc)) / (f2 - f1)
		retval.Qms = (retval.f0*math.sqrt(rc)) / (f2 - f1)						--Mechanical Q
		retval.Qes = retval.Qms / (rc - 1)										--Electrical Q
		retval.Qts = retval.Qms / rc											--Total Q to be reported

		--calculate Rms (mechanical damping)
		retval.Rms = math.pow(SearchParams.Bl,2) / (retval.max_mag - retval.r_dc)   --Rms to be reported

		--calculate Mms (moving mass)
		retval.Mms = retval.Qts * (retval.Rms + (math.pow(SearchParams.Bl, 2) / retval.r_dc)) / (2 * math.pi * retval.f0)

		--calculate Kms (Stiffness factor)
		retval.Kms = math.pow(2 * math.pi * retval.f0, 2) * retval.Mms;

		--calculate Le
		local A, B = {}, {}
		for i = 0, (SearchParams.fle_ind2 - SearchParams.fle_ind1 - 1), 1 do
			table.insert(B, math.pow(retval.mag[i + SearchParams.fle_ind1 - 1], 2) - math.pow(retval.r_dc, 2));
			table.insert(A, math.pow(2 * math.pi * freqZ[i + SearchParams.fle_ind1 - 1], 2));
		end

		-- If vectors A and B are the same size, for the matrix product and calculate Le
		-- Le = sqrt(inv(A'*A))*A'*B
		if (#A == #B) then
			-- calculate A'* A
			local AsquareSum = 0
			for i = 1, #A do
				AsquareSum = AsquareSum + math.pow(A[i],2)
			end

			--Get inverse of A'* A
			AsquareSum = 1/AsquareSum

			-- inv(A'* A) * A'
			for i = 1, #A, 1 do
				A[i] = A[i] * AsquareSum
			end

			--(inv(A'* A) * A') * B
			local temp2 = 0
			for i = 1, #A, 1 do
				temp2 = temp2 + (A[i] * B[i])
			end
			retval.Le = math.sqrt(temp2)
		end
	end

	return retval

end

function TS_fit_check(retval, Z, freqZ, SearchParams)
	-- s = j * 2 * pi * ImpedanceFrequency
    -- Zm_mod = s.*h.Mms  + h.Rms + h.Kms./s;
    -- Ze_mod = h.Re + SearchParams.Bl^2./Zm_mod + h.Le.*s;   This is the modeled impedance curve

    -- Create a vector of complex objects
	local s, Ze_model, Zm_model = {}, {}, {}

	local temp
	-- Create s vector
    for i = 1, #freqZ do
        s[i] = 2.0 * math.pi * freqZ[i] * AL.Complex(0, 1)
    end

    -- Create Zm_model vector
	local temp1, temp2, temp3
	local Mms_cpx = AL.Complex(retval.Mms, 0)
	local Rms_cpx = AL.Complex(retval.Rms, 0)
	local Kms_cpx = AL.Complex(retval.Kms, 0)
	local Le_cpx = AL.Complex(retval.Le, 0)
	local r_dc_cpx = AL.Complex(retval.r_dc, 0)
	local Bl_sq_cpx = AL.Complex(math.pow(retval.Bl, 2), 0)

	print("Calculating Zm")
    for i = 1, #s do
		table.insert(Zm_model, s[i] * Mms_cpx + Rms_cpx + (Kms_cpx / s[i]))
    end

    -- Create Ze_model vector
	print("Calculating Ze")
	for i = 1, #s do
        table.insert(Ze_model, r_dc_cpx + Bl_sq_cpx / Zm_model[i] + s[i]*Le_cpx)
    end

    -- Begin calculating error. Find the delta between measured impedance and modeled impedance.
    local E, E2 = {}, {}
	local P, P2 = {}, {}

	for i = SearchParams.f_low_Q_1_ind, SearchParams.f_high_Q_1_ind, 1 do
        table.insert(E, math.abs(retval.mag[i]) - Ze_model[i]:Abs())
    end

    for i = SearchParams.f_low_Q_2_ind, SearchParams.f_high_Q_2_ind, 1 do
        table.insert(E2, math.abs(retval.mag[i]) - Ze_model[i]:Abs())
    end

    for i = SearchParams.f_low_Q_1_ind, SearchParams.f_high_Q_1_ind, 1 do
        table.insert(P, math.abs(retval.mag[i]))
    end

    for i = SearchParams.f_low_Q_2_ind, SearchParams.f_high_Q_2_ind, 1 do
        table.insert(P2, math.abs(retval.mag[i]))
    end

    -- Calculate sum of squares
    local SumOfSquaresE, SumOfSquaresP = 0, 0

    for i = 1, #E, 1 do
		SumOfSquaresE = SumOfSquaresE + math.pow(E[i],2)
    end

    for i = 1, #E2, 1 do
        SumOfSquaresE = SumOfSquaresE + math.pow(E2[i],2)
    end

	for i = 1, #P, 1 do
        SumOfSquaresP = SumOfSquaresP + math.pow(P[i],2)
    end

    for i = 1, #P2, 1 do
        SumOfSquaresP = SumOfSquaresP + math.pow(P2[i],2)
    end

	-- print(SumOfSquaresE, SumOfSquaresP)
    retval.error_percent = SumOfSquaresE / SumOfSquaresP * 100 -- error in percent
    if retval.error_percent > 0 then
    	retval.error_dB = 10 * (math.log(SumOfSquaresE / SumOfSquaresP)/math.log(10))		-- no inbuilt log10 function
	else
		retval.error_dB = -9000
	end

	return retval
end

--Function For Determining RDC (CAL)
function RDCCalibration()

	InitGlobals()

	local SpeakerToRDCMap = {}
	local TMSpeakerRDCParams = {}
	local HSSpeakerRDCParams = {}

	SpeakerToRDCMap[gTMSpeakersParams] = TMSpeakerRDCParams
	SpeakerToRDCMap[gHSSpeakersParams] = HSSpeakerRDCParams

	local testNamePrefix = "RDCCAL_"

	for SingleSpeakerParams, RDCParams in pairs(SpeakerToRDCMap) do

		for speakerName, speakerParams in pairs(SingleSpeakerParams) do

			RDCParams[speakerName] = {}

			PrintString("RDC test for speaker: " .. speakerParams.PrettyName)

			local AverageCount = 3

			local allRDCs = {}
			local allTemperaturesTDEV1 = {}
			local allTemperaturesTDEV2 = {}					-- For Data collection only, TDEV1 is still POR as of D2x P2 builds
			local allTemperaturesTDEV3 = {}					-- For Data collection only, TDEV1 is still POR as of D2x P2 builds
			local allTemperaturesTDEV4 = {}					-- For Data collection only, TDEV1 is still POR as of D2x P2 builds
			local allTemperaturesTDEV5 = {}					-- For Data collection only, TDEV1 is still POR as of D2x P2 builds

			local allTemperatures = {}

			local vmonFFTMax, imonFFTMax = 0, 0

			for i=1, AverageCount do

				local tempsInC  = GetPMUTemperatures()

				-- Report all temperatures to PDCA
				for key, value in pairs(tempsInC) do
					if key ~= "TCAL" and key ~= "TBAT" then
						ReportData(testNamePrefix .. speakerParams.PDCAPrefix .. key .. "_iteration" .. tostring(i), tonumber(value), "C", nil,nil)
					end
				end

				-- SetupPlayback(speakerName, "-16")
				-- Bovey: Turnonff the getting now to set the as -24 as POR
				SetupPlayback(SingleSpeakerParams, speakerName, speakerParams.PcmVol)
				-- SetupPlayback(SingleSpeakerParams, speakerName, "-24")
				local vmon, imon = PlayTone(40, 1400, testNamePrefix .. speakerParams.PDCAPrefix .. "ITER" .. i .. ".wav")
				AudioTurnOff()

				local x = os.time()

				vmonFFTMax, imonFFTMax = FindMax(vmon, imon)

				allRDCs[i] = vmonFFTMax / imonFFTMax

				allTemperaturesTDEV1[i] = tempsInC["TDEV1"]
				allTemperaturesTDEV2[i] = tempsInC["TDEV2"]
				allTemperaturesTDEV3[i] = tempsInC["TDEV3"]
				allTemperaturesTDEV4[i] = tempsInC["TDEV4"]
				allTemperaturesTDEV5[i] = tempsInC["TDEV5"]

				PrintString("Iteration " .. i .. " results:")
				PrintString(speakerParams.PrettyName .. " RDC: " .. allRDCs[i])
				PrintString(speakerParams.PrettyName .. " Temperature: " .. allTemperaturesTDEV1[i])
				PrintString(speakerParams.PrettyName .. " VMON FFT Value: " .. vmonFFTMax)
				PrintString(speakerParams.PrettyName .. " IMON FFT Value: " .. imonFFTMax)

				processingTime = os.time() - x

				if processingTime < 8 then
					WaitForSeconds(round(8 - processingTime))
				end
			end

			RDCParams[speakerName].RDC = 0
			RDCParams[speakerName].RDCTemp = 0
			local TDEV2_avg = 0
			local TDEV3_avg = 0
			local TDEV4_avg = 0
			local TDEV5_avg = 0

			for i = 1, AverageCount do
				RDCParams[speakerName].RDC = RDCParams[speakerName].RDC + allRDCs[i]/AverageCount
				RDCParams[speakerName].RDCTemp = RDCParams[speakerName].RDCTemp + allTemperaturesTDEV1[i]/AverageCount
				TDEV2_avg = TDEV2_avg + allTemperaturesTDEV2[i]/AverageCount
				TDEV3_avg = TDEV3_avg + allTemperaturesTDEV3[i]/AverageCount
				TDEV4_avg = TDEV4_avg + allTemperaturesTDEV4[i]/AverageCount
				TDEV5_avg = TDEV5_avg + allTemperaturesTDEV5[i]/AverageCount
			end

			--Range of allowable TDEV2 to TDEV1 variation
			local TDEV2_to_TDEV1_high = 10
			local TDEV2_to_TDEV1_low = -5

			--Sanity check on TDEV1 being something reasonable
			local TDEV_lower = 10
			local TDEV_upper = 50

			local tempsInC  = GetPMUTemperatures()

			PrintString(speakerParams.PrettyName .. " Average RDC " .. RDCParams[speakerName].RDC)
			PrintString(speakerParams.PrettyName .. " TDEV1 Average Temperature " .. RDCParams[speakerName].RDCTemp)
			PrintString(speakerParams.PrettyName .. " TDEV2 Average Temperature " .. TDEV2_avg)
			PrintString(speakerParams.PrettyName .. " TDEV3 Average Temperature " .. TDEV3_avg)
			PrintString(speakerParams.PrettyName .. " TDEV4 Average Temperature " .. TDEV4_avg)
			PrintString(speakerParams.PrettyName .. " TDEV5 Average Temperature " .. TDEV5_avg)

			--Sanity checks
			local ERS_extrapolated_low = speakerParams.ERS_20_low + (allTemperaturesTDEV1[AverageCount]-20)*speakerParams.RDC_Temp_slope
			local ERS_extrapolated_high = speakerParams.ERS_20_high + (allTemperaturesTDEV1[AverageCount]-20)*speakerParams.RDC_Temp_slope

			ReportData(testNamePrefix .. speakerParams.PDCAPrefix .. "RDC_avg", FiniteOrZero(RDCParams[speakerName].RDC), "Ohms",ERS_extrapolated_low , ERS_extrapolated_high)
			ReportData(testNamePrefix .. speakerParams.PDCAPrefix .. "RDCTemp_avg", FiniteOrZero(RDCParams[speakerName].RDCTemp), "C",nil ,nil)
			ReportData(testNamePrefix .. speakerParams.PDCAPrefix .. "TDEV2_avg", TDEV2_avg, "C",nil ,nil)
			ReportData(testNamePrefix .. speakerParams.PDCAPrefix .. "TDEV3_avg", TDEV3_avg, "C",nil ,nil)
			ReportData(testNamePrefix .. speakerParams.PDCAPrefix .. "TDEV4_avg", TDEV4_avg, "C",nil ,nil)
			ReportData(testNamePrefix .. speakerParams.PDCAPrefix .. "TDEV5_avg", TDEV5_avg, "C",nil ,nil)
			ReportData(testNamePrefix .. speakerParams.PDCAPrefix .. "RDC_Extraploated_High_limit", ERS_extrapolated_high, "Ohms", nil,nil)
			ReportData(testNamePrefix .. speakerParams.PDCAPrefix .. "RDC_Extraploated_Low_limit", ERS_extrapolated_low, "Ohms", nil,nil)

			PrintString(speakerParams.PrettyName .. " RDC_Extraploated_High_limit " .. ERS_extrapolated_high)
			PrintString(speakerParams.PrettyName .. " RDC_Extraploated_Low_limit " .. ERS_extrapolated_low)

			--TDEV1 and TDEV2 sanity check (TDEV2-TDEV1)
			ReportData(testNamePrefix .. speakerParams.PDCAPrefix .. "TDEV_to_TDEV_REF_sanity_check", FiniteOrZero(tempsInC["TDEV2"]-tempsInC["TDEV1"]), "C", TDEV2_to_TDEV1_low, TDEV2_to_TDEV1_high)
			ReportData(testNamePrefix .. speakerParams.PDCAPrefix .. "TDEV_sanity_check", FiniteOrZero(allTemperaturesTDEV1[AverageCount]), "C", TDEV_lower, TDEV_upper)

			-- Report last voltage and current values to PDCA
			ReportData(testNamePrefix .. speakerParams.PDCAPrefix .. "Voltage", FiniteOrZero(vmonFFTMax), "mV",nil,nil)
			ReportData(testNamePrefix .. speakerParams.PDCAPrefix .. "Current", FiniteOrZero(imonFFTMax), "mA",nil,nil)

		end

	end

	return TMSpeakerRDCParams, HSSpeakerRDCParams
end

function PostRDCCalibration()

	InitGlobals()

	local SpeakerToRDCMap = {}
	local TMSpeakerRDCParams = {}
	local HSSpeakerRDCParams = {}

	SpeakerToRDCMap[gTMSpeakersParams] = TMSpeakerRDCParams
	SpeakerToRDCMap[gHSSpeakersParams] = HSSpeakerRDCParams

	local testNamePrefix = "POSTRDCCAL_"

	for SingleSpeakerParams, RDCParams in pairs(SpeakerToRDCMap) do

		for speakerName, speakerParams in pairs(SingleSpeakerParams) do

			RDCParams[speakerName] = {}

			PrintString("RDC test for speaker: " .. speakerParams.PrettyName)

			local AverageCount = 3

			local allRDCs = {}
			local allTemperaturesTDEV1 = {}
			local allTemperaturesTDEV2 = {}					-- For Data collection only, TDEV1 is still POR as of D2x P2 builds
			local allTemperaturesTDEV3 = {}					-- For Data collection only, TDEV1 is still POR as of D2x P2 builds
			local allTemperaturesTDEV4 = {}					-- For Data collection only, TDEV1 is still POR as of D2x P2 builds
			local allTemperaturesTDEV5 = {}					-- For Data collection only, TDEV1 is still POR as of D2x P2 builds

			local allTemperatures = {}

			local vmonFFTMax, imonFFTMax = 0, 0

			for i=1, AverageCount do

				local tempsInC  = GetPMUTemperatures()

				-- Report all temperatures to PDCA
				for key, value in pairs(tempsInC) do
					if key ~= "TCAL" and key ~= "TBAT" then
						ReportData(testNamePrefix .. speakerParams.PDCAPrefix .. key .. "_iteration" .. tostring(i), tonumber(value), "C", nil,nil)
					end
				end

				-- SetupPlayback(speakerName, "-16")
				-- Bovey: Turnonff the getting now to set the as -24 as POR
				SetupPlayback(SingleSpeakerParams, speakerName, speakerParams.PcmVol)
				-- SetupPlayback(SingleSpeakerParams, speakerName, "-24")
				local vmon, imon = PlayTone(40, 1400, testNamePrefix .. speakerParams.PDCAPrefix .. "ITER" .. i .. ".wav")
				AudioTurnOff()

				local x = os.time()

				vmonFFTMax, imonFFTMax = FindMax(vmon, imon)

				allRDCs[i] = vmonFFTMax / imonFFTMax

				allTemperaturesTDEV1[i] = tempsInC["TDEV1"]
				allTemperaturesTDEV2[i] = tempsInC["TDEV2"]
				allTemperaturesTDEV3[i] = tempsInC["TDEV3"]
				allTemperaturesTDEV4[i] = tempsInC["TDEV4"]
				allTemperaturesTDEV5[i] = tempsInC["TDEV5"]

				PrintString("Iteration " .. i .. " results:")
				PrintString(speakerParams.PrettyName .. " RDC: " .. allRDCs[i])
				PrintString(speakerParams.PrettyName .. " Temperature: " .. allTemperaturesTDEV1[i])
				PrintString(speakerParams.PrettyName .. " VMON FFT Value: " .. vmonFFTMax)
				PrintString(speakerParams.PrettyName .. " IMON FFT Value: " .. imonFFTMax)

				processingTime = os.time() - x

				if processingTime < 8 then
					WaitForSeconds(round(8 - processingTime))
				end
			end

			RDCParams[speakerName].RDC = 0
			RDCParams[speakerName].RDCTemp = 0
			local TDEV2_avg = 0
			local TDEV3_avg = 0
			local TDEV4_avg = 0
			local TDEV5_avg = 0

			for i = 1, AverageCount do
				RDCParams[speakerName].RDC = RDCParams[speakerName].RDC + allRDCs[i]/AverageCount
				RDCParams[speakerName].RDCTemp = RDCParams[speakerName].RDCTemp + allTemperaturesTDEV1[i]/AverageCount
				TDEV2_avg = TDEV2_avg + allTemperaturesTDEV2[i]/AverageCount
				TDEV3_avg = TDEV3_avg + allTemperaturesTDEV3[i]/AverageCount
				TDEV4_avg = TDEV4_avg + allTemperaturesTDEV4[i]/AverageCount
				TDEV5_avg = TDEV5_avg + allTemperaturesTDEV5[i]/AverageCount
			end

			--Range of allowable TDEV2 to TDEV1 variation
			local TDEV2_to_TDEV1_high = 10
			local TDEV2_to_TDEV1_low = -5

			--Sanity check on TDEV1 being something reasonable
			local TDEV_lower = 10
			local TDEV_upper = 50

			local tempsInC  = GetPMUTemperatures()

			PrintString(speakerParams.PrettyName .. " Average RDC " .. RDCParams[speakerName].RDC)
			PrintString(speakerParams.PrettyName .. " TDEV1 Average Temperature " .. RDCParams[speakerName].RDCTemp)
			PrintString(speakerParams.PrettyName .. " TDEV2 Average Temperature " .. TDEV2_avg)
			PrintString(speakerParams.PrettyName .. " TDEV3 Average Temperature " .. TDEV3_avg)
			PrintString(speakerParams.PrettyName .. " TDEV4 Average Temperature " .. TDEV4_avg)
			PrintString(speakerParams.PrettyName .. " TDEV5 Average Temperature " .. TDEV5_avg)

			--Sanity checks
			local ERS_extrapolated_low = speakerParams.ERS_20_low + (allTemperaturesTDEV1[AverageCount]-20)*speakerParams.RDC_Temp_slope
			local ERS_extrapolated_high = speakerParams.ERS_20_high + (allTemperaturesTDEV1[AverageCount]-20)*speakerParams.RDC_Temp_slope

			ReportData(testNamePrefix .. speakerParams.PDCAPrefix .. "RDC_avg", FiniteOrZero(RDCParams[speakerName].RDC), "Ohms",ERS_extrapolated_low , ERS_extrapolated_high)
			ReportData(testNamePrefix .. speakerParams.PDCAPrefix .. "RDCTemp_avg", FiniteOrZero(RDCParams[speakerName].RDCTemp), "C",nil ,nil)
			ReportData(testNamePrefix .. speakerParams.PDCAPrefix .. "TDEV2_avg", TDEV2_avg, "C",nil ,nil)
			ReportData(testNamePrefix .. speakerParams.PDCAPrefix .. "TDEV3_avg", TDEV3_avg, "C",nil ,nil)
			ReportData(testNamePrefix .. speakerParams.PDCAPrefix .. "TDEV4_avg", TDEV4_avg, "C",nil ,nil)
			ReportData(testNamePrefix .. speakerParams.PDCAPrefix .. "TDEV5_avg", TDEV5_avg, "C",nil ,nil)
			ReportData(testNamePrefix .. speakerParams.PDCAPrefix .. "RDC_Extraploated_High_limit", ERS_extrapolated_high, "Ohms", nil,nil)
			ReportData(testNamePrefix .. speakerParams.PDCAPrefix .. "RDC_Extraploated_Low_limit", ERS_extrapolated_low, "Ohms", nil,nil)

			PrintString(speakerParams.PrettyName .. " RDC_Extraploated_High_limit " .. ERS_extrapolated_high)
			PrintString(speakerParams.PrettyName .. " RDC_Extraploated_Low_limit " .. ERS_extrapolated_low)

			--TDEV1 and TDEV2 sanity check (TDEV2-TDEV1)
			ReportData(testNamePrefix .. speakerParams.PDCAPrefix .. "TDEV_to_TDEV_REF_sanity_check", FiniteOrZero(tempsInC["TDEV2"]-tempsInC["TDEV1"]), "C", TDEV2_to_TDEV1_low, TDEV2_to_TDEV1_high)
			ReportData(testNamePrefix .. speakerParams.PDCAPrefix .. "TDEV_sanity_check", FiniteOrZero(allTemperaturesTDEV1[AverageCount]), "C", TDEV_lower, TDEV_upper)

			-- Report last voltage and current values to PDCA
			ReportData(testNamePrefix .. speakerParams.PDCAPrefix .. "Voltage", FiniteOrZero(vmonFFTMax), "mV",nil,nil)
			ReportData(testNamePrefix .. speakerParams.PDCAPrefix .. "Current", FiniteOrZero(imonFFTMax), "mA",nil,nil)

		end

	end

	return TMSpeakerRDCParams, HSSpeakerRDCParams
end

function RDC_TDEV_DOE(numIterations, waitTime)

	InitGlobals()

	local SpeakerToRDCMap = {}
	local TMSpeakerRDCParams = {}
	local HSSpeakerRDCParams = {}

	SpeakerToRDCMap[gTMSpeakersParams] = TMSpeakerRDCParams
	SpeakerToRDCMap[gHSSpeakersParams] = HSSpeakerRDCParams

	local testNamePrefix = "RDCCAL_DOE_"

	for loop =1, numIterations, 1 do

		local x = os.time()

		PrintString("Iteration_" .. tostring(loop))
		local tempsInC  = GetPMUTemperatures()

		-- Report all temperatures to PDCA
		for key, value in pairs(tempsInC) do
			if key ~= "TCAL" and key ~= "TBAT" then
				ReportData(testNamePrefix .. key .. "_iteration_" .. tostring(loop), tonumber(value), "C", nil,nil)
			end
		end

		-- ****** Turning off RDC measurements and reporting during DOE temperature collection *******
		--Bovey Comment for D37 BotSpeaker only
		for SingleSpeakerParams, RDCParams in pairs(SpeakerToRDCMap) do 
			for speakerName, speakerParams in pairs(SingleSpeakerParams) do
				RDCParams[speakerName] = {}
				if(string.match(speakerName, "BotSpeaker")) then
					
					PrintString(" ")
					PrintString("DOE Temp test for speaker: " .. speakerParams.PrettyName)
					PrintString(" ")

					local RDC = {}
					local allTemperatures = {}
					local vmonFFTMax, imonFFTMax, mag = 0, 0, 0
				
					-- Bovey: DOE for changing the PcmVol
					speakerParams.PcmVol = speakerParams.PcmVol + 1
					-- SetupPlayback(speakerName, "-16")
					SetupPlayback(SingleSpeakerParams, speakerName, speakerParams.PcmVol)
					local vmon, imon = PlayTone(40, 1000, "TDEV_DOE_" .. ".wav")
					AudioTurnOff()

					vmonFFTMax, imonFFTMax = FindMax(vmon, imon)

					RDC = vmonFFTMax / imonFFTMax

					PrintString(speakerParams.PrettyName .. "_iteration_" .. tostring(loop) .. "_RDC: " .. RDC)
					ReportData(testNamePrefix .. speakerParams.PDCAPrefix .. "_iteration_" .. tostring(loop) .. "_RDC", FiniteOrZero(RDC), "Ohms", nil, nil)

					Shell "rtc --get"
					timenow = Last.Output
					PrintString(" ")
					PrintString("Timestamp : " .. timenow)
					PrintString(" ")
					PrintString(" ")
					PrintString(" ")
					PrintString(" ")
					PrintString(" ")

					local itnTime = os.time() - x

					WaitForSeconds(waitTime - itnTime)
				end
			end	
		end

		--[[
		for SingleSpeakerParams, RDCParams in pairs(SpeakerToRDCMap) do

			for speakerName, speakerParams in pairs(SingleSpeakerParams) do

				RDCParams[speakerName] = {}

				PrintString(" ")
				PrintString("DOE Temp test for speaker: " .. speakerParams.PrettyName)
				PrintString(" ")

				local RDC = {}
				local allTemperatures = {}
				local vmonFFTMax, imonFFTMax, mag = 0, 0, 0
			
				-- Bovey: DOE for changing the PcmVol
				speakerParams.PcmVol = speakerParams.PcmVol + 1
				-- SetupPlayback(speakerName, "-16")
				SetupPlayback(SingleSpeakerParams, speakerName, speakerParams.PcmVol)
				local vmon, imon = PlayTone(40, 1000, "TDEV_DOE_" .. ".wav")
	    		AudioTurnOff()

				vmonFFTMax, imonFFTMax = FindMax(vmon, imon)

				RDC = vmonFFTMax / imonFFTMax

				PrintString(speakerParams.PrettyName .. "_iteration_" .. tostring(loop) .. "_RDC: " .. RDC)
				ReportData(testNamePrefix .. speakerParams.PDCAPrefix .. "_iteration_" .. tostring(loop) .. "_RDC", FiniteOrZero(RDC), "Ohms", nil, nil)

			end -- speakerName

		end
		
		Shell "rtc --get"
		timenow = Last.Output
		PrintString(" ")
		PrintString("Timestamp : " .. timenow)
		PrintString(" ")
		PrintString(" ")
		PrintString(" ")
		PrintString(" ")
		PrintString(" ")

		local itnTime = os.time() - x

		WaitForSeconds(waitTime - itnTime)  -- ]] 

	end -- loop

end

--DOE for D37 setp2 step down -18, -16, -14, -12
function RDC_TDEV_DOE2(numIterations, waitTime)

	InitGlobals()

	local SpeakerToRDCMap = {}
	local TMSpeakerRDCParams = {}
	local HSSpeakerRDCParams = {}

	SpeakerToRDCMap[gTMSpeakersParams] = TMSpeakerRDCParams
	SpeakerToRDCMap[gHSSpeakersParams] = HSSpeakerRDCParams

	local testNamePrefix = "RDCCAL_DOE2_"

	for loop =1, numIterations, 1 do

	--	local x = os.time()

		PrintString("Iteration_" .. tostring(loop))
		local tempsInC  = GetPMUTemperatures()

		-- Report all temperatures to PDCA
		for key, value in pairs(tempsInC) do
			if key ~= "TCAL" and key ~= "TBAT" then
				ReportData(testNamePrefix .. key .. "_iteration_" .. tostring(loop), tonumber(value), "C", nil,nil)
			end
		end

		-- ****** Turning off RDC measurements and reporting during DOE temperature collection *******
		--Bovey Comment for D37 BotSpeaker only
		for SingleSpeakerParams, RDCParams in pairs(SpeakerToRDCMap) do 
			for speakerName, speakerParams in pairs(SingleSpeakerParams) do
				RDCParams[speakerName] = {}
				if(string.match(speakerName, "BotSpeaker")) then
					
					PrintString(" ")
					PrintString("DOE Temp test for speaker: " .. speakerParams.PrettyName)
					PrintString(" ")

					local RDC = {}
					local allTemperaturesTDEV1 = {}
					local allTemperatures = {}
					local vmonFFTMax, imonFFTMax, mag = 0, 0, 0
				
					-- Bovey: DOE for changing the PcmVol
					local speakerGain = -20
					speakerGain = speakerGain + 2
					-- SetupPlayback(speakerName, "-16")

					local AverageCount = 3

					for i=1, AverageCount do

						local tempsInC = GetPMUTemperatures()

						SetupPlayback(SingleSpeakerParams, speakerName, speakerGain)
						local vmon, imon = PlayTone(40, 1000, "TDEV_DOE2_" .. ".wav")
						AudioTurnOff()

						local x = os.time()

						vmonFFTMax, imonFFTMax = FindMax(vmon, imon)

						RDC[i] = vmonFFTMax / imonFFTMax

						allTemperaturesTDEV1[i] = tempsInC["TDEV1"]

						PrintString("Iteration " .. i .. " results:")
						PrintString(speakerParams.PrettyName .. " RDC: " .. RDC[i])
					--	PrintString(speakerParams.PrettyName .. " Temperature: " .. allTemperaturesTDEV1[i])

						PrintString(speakerParams.PrettyName .. "_iteration_" .. tostring(i) .. "DOE2_RDC: " .. RDC[i])
						ReportData(testNamePrefix .. speakerParams.PDCAPrefix .. "_iteration_" .. tostring(i) .. "DOE2_RDC", FiniteOrZero(RDC[i]), "Ohms", nil, nil)

						processingTime = os.time() - x

					end

					RDCParams[speakerName].RDC = 0
					RDCParams[speakerName].RDCTemp = 0

					for i=1, AverageCount do
						RDCParams[speakerName].RDC = RDCParams[speakerName].RDC + RDC[i]/AverageCount
						RDCParams[speakerName].RDCTemp = RDCParams[speakerName].RDCTemp + allTemperaturesTDEV1[i]/AverageCount

					end
					
					PrintString(speakerParams.PrettyName .. " Average RDC " .. RDCParams[speakerName].RDC)
					PrintString(speakerParams.PrettyName .. " TDEV1 Average Temperature " .. RDCParams[speakerName].RDCTemp)

					ReportData(testNamePrefix .. speakerParams.PDCAPrefix .. "DOE2_".. tostring(loop) .. "_RDC_avg", FiniteOrZero(RDCParams[speakerName].RDC), "Ohms",nil , nil)
					ReportData(testNamePrefix .. speakerParams.PDCAPrefix .. "DOE2_".. tostring(loop) .. "RDCTemp_avg", FiniteOrZero(RDCParams[speakerName].RDCTemp), "C",nil ,nil)

					Shell "rtc --get"
					timenow = Last.Output
					PrintString(" ")
					PrintString("Timestamp : " .. timenow)
					PrintString(" ")
					PrintString(" ")
					PrintString(" ")
					PrintString(" ")
					PrintString(" ")

					local x = os.time()

					local itnTime = os.time() - x

					WaitForSeconds(waitTime - itnTime)
				end
			end	
		end
	end -- loop

end

--DOE for D37 setp2 step down -18, -16, -14, -12
function RDC_TDEV_DOE3(speakerAmpGain)

	InitGlobals()

	local SpeakerToRDCMap = {}
	local TMSpeakerRDCParams = {}
	local HSSpeakerRDCParams = {}

	SpeakerToRDCMap[gTMSpeakersParams] = TMSpeakerRDCParams
	SpeakerToRDCMap[gHSSpeakersParams] = HSSpeakerRDCParams

	local testNamePrefix = "RDCCAL_DOE_"

	local x = os.time()

	local tempsInC  = GetPMUTemperatures()

	-- Report all temperatures to PDCA
	for key, value in pairs(tempsInC) do
		if key ~= "TCAL" and key ~= "TBAT" then
			ReportData(testNamePrefix .. key .. "_iteration_" .. tostring(loop), tonumber(value), "C", nil,nil)
		end
	end

	-- ****** Turning off RDC measurements and reporting during DOE temperature collection *******
	--Bovey Comment for D37 BotSpeaker only
	for SingleSpeakerParams, RDCParams in pairs(SpeakerToRDCMap) do 
		for speakerName, speakerParams in pairs(SingleSpeakerParams) do
			RDCParams[speakerName] = {}
			if(string.match(speakerName, "BotSpeaker")) then
				
				PrintString(" ")
				PrintString("DOE Temp test for speaker: " .. speakerParams.PrettyName)
				PrintString(" ")

				local RDC = {}
				local allTemperaturesTDEV1 = {}
				local allTemperatures = {}
				local vmonFFTMax, imonFFTMax, mag = 0, 0, 0

				local AverageCount = 3

					for i=1, AverageCount do

						local tempsInC = GetPMUTemperatures()

						SetupPlayback(SingleSpeakerParams, speakerName, speakerAmpGain)
						local vmon, imon = PlayTone(40, 1000, "TDEV_DOE3_" .. ".wav")
						AudioTurnOff()

						local x = os.time()

						vmonFFTMax, imonFFTMax = FindMax(vmon, imon)

						RDC[i] = vmonFFTMax / imonFFTMax

						allTemperaturesTDEV1[i] = tempsInC["TDEV1"]

						PrintString("Iteration " .. i .. " results:")
						PrintString(speakerParams.PrettyName .. " RDC: " .. RDC[i])
					--	PrintString(speakerParams.PrettyName .. " Temperature: " .. allTemperaturesTDEV1[i])

						PrintString(speakerParams.PrettyName .. "_" .. tostring(speakerAmpGain).. "_iteration_" .. tostring(i) .. "DOE3_RDC: " .. RDC[i])
						ReportData(testNamePrefix .. speakerParams.PDCAPrefix .. "_" .. tostring(speakerAmpGain).. "_iteration_" .. tostring(i) .. "DOE3_RDC", FiniteOrZero(RDC[i]), "Ohms", nil, nil)

						processingTime = os.time() - x
						WaitForSeconds(8)

					end

					RDCParams[speakerName].RDC = 0
					RDCParams[speakerName].RDCTemp = 0

					for i=1, AverageCount do
						RDCParams[speakerName].RDC = RDCParams[speakerName].RDC + RDC[i]/AverageCount
						RDCParams[speakerName].RDCTemp = RDCParams[speakerName].RDCTemp + allTemperaturesTDEV1[i]/AverageCount

					end
					
					PrintString(speakerParams.PrettyName .. " Average RDC " .. RDCParams[speakerName].RDC)
					PrintString(speakerParams.PrettyName .. " TDEV1 Average Temperature " .. RDCParams[speakerName].RDCTemp)

					ReportData(testNamePrefix .. speakerParams.PDCAPrefix .. "_".. tostring(speakerAmpGain) .. "_RDC_avg", FiniteOrZero(RDCParams[speakerName].RDC), "Ohms",nil , nil)
					ReportData(testNamePrefix .. speakerParams.PDCAPrefix .. "_".. tostring(speakerAmpGain) .. "_RDCTemp_avg", FiniteOrZero(RDCParams[speakerName].RDCTemp), "C",nil ,nil)
					
					--Adding 8s for each step
				--	WaitForSeconds(8)
			end
		end	
	end	 -- loop

end

function PreHeat() -- PreHeat for BotSpeaker test
	Shell("processaudio --freebufs all")
	Shell("audio --resetblock botspeaker")
	Shell("audio --resetblock socmca")
	Shell("audio --resetblock codec")
	Shell("audio --turnoff topspeaker")
	Shell("audio --turnoff arc")
	Shell("audio --turnoff hallsensor")
	Shell("routeaudio --route --block botspeaker --in spk-i2s --out spk-out")
	Shell("audioreg -b botspeaker -w -a 0x00007230 -d 0x00180000")
	Shell("setvol --block botspeaker --volume pcm-gain --value 16")
	Shell("setvol --block botspeaker --volume pcm-vol --value 2.13")
	Shell("processaudio --readfile FACT_x2.wav")
	Shell("processaudio --pick gain -i process0 --options \"--gain -5\"")
	Shell("playaudio -b socmca -p ap-mca5 --usebuf process1")
end

function PreHeat2(speaker_gain) -- PreHeat for BotSpeaker test
	Shell("processaudio --freebufs all")
	Shell("audio --resetblock botspeaker")
	Shell("audio --resetblock socmca")
	Shell("audio --resetblock codec")
	Shell("audio --turnoff topspeaker")
	Shell("audio --turnoff arc")
	Shell("audio --turnoff hallsensor")
	Shell("routeaudio --route --block botspeaker --in spk-i2s --out spk-out")
	Shell("audioreg -b botspeaker -w -a 0x00007230 -d 0x00180000")
	Shell("setvol --block botspeaker --volume pcm-gain --value 16")
	Shell("setvol --block botspeaker --volume pcm-vol --value " .. speaker_gain)
	Shell("playaudio -b socmca -p ap-mca5 --file 2min_off_20s_100Hz.wav")
end

function TSCalibration()

	InitGlobals()
	-- Bovey: <rdar://83730591>
	local BlValues = {}
	BlValues["D83"] = {TopSpeaker = 1.04, BotSpeaker = 1.35}
	BlValues["D84"] = {TopSpeaker = 1.34, BotSpeaker = 1.58}
	BlValues["D37"] = {TopSpeaker = 1.10, BotSpeaker = 1.26}
	BlValues["D38"] = {TopSpeaker = 1.20, BotSpeaker = 1.34}

	if(gUnitType ~= "D83" and gUnitType ~= "D84" and gUnitType ~= "D37" and gUnitType ~= "D38") then
		error("The diags commands and constants in TSCal are currently valid for D3x projects.")
	end

	local testNamePrefix = "TSCAL_"

	local SpeakerToTSMap = {}
	local TMSpeakerTSParams = {}
	local HSSpeakerTSParams = {}

	SpeakerToTSMap[gTMSpeakersParams] = TMSpeakerTSParams
	SpeakerToTSMap[gHSSpeakersParams] = HSSpeakerTSParams

	for SingleSpeakerParams, TSParams in pairs(SpeakerToTSMap) do

		for speakerName, speakerParams in pairs(SingleSpeakerParams) do

			if speakerParams.TSEnabled then

				local searchParams = {}
				TSParams[speakerName] = {}

				PrintString("TS test for speaker: " .. speakerParams.PrettyName)

				if speakerName == "TopSpeaker" then

					searchParams.fmin_rdc = 25      -- lower freq for rdc search
					searchParams.fmax_rdc = 40      -- upper freq for rdc search
					searchParams.fmin_f0 = 100      -- lower freq for f0 search
					searchParams.fmax_f0 = 2000     -- upper freq for f0 search (was 1000)
					searchParams.fmin_le = 10000    -- lower freq for Le search
					searchParams.fmax_le = 18000    -- upper freq for Le search

				elseif speakerName == "BotSpeaker" then

					searchParams.fmin_rdc = 25     -- lower freq for rdc search
					searchParams.fmax_rdc = 40     -- upper freq for rdc search
					searchParams.fmin_f0 = 200     -- lower freq for f0 search
					searchParams.fmax_f0 = 1500    -- upper freq for f0 search
					searchParams.fmin_le = 10000   -- lower freq for Le search
					searchParams.fmax_le = 18000   -- upper freq for Le search
				else
					PrintString("TSCalibration() is currently only defined for TopSpeaker and BottomSpeaker")
				end

				assert(BlValues[gUnitType] ~= nil, "Bl values absent for " .. gUnitType);
				assert(BlValues[gUnitType][speakerName] ~= nil, "Bl value absent for " .. gUnitType .. " " .. speakerName);

				searchParams.Bl = BlValues[gUnitType][speakerName]

				PrintString(gUnitType .. " " .. speakerName .. " Bl value = " .. searchParams.Bl)
				PrintString("Calculating TS params for " .. speakerName)

				-- SetupPlayback(speakerName, "-16")
				-- SetupPlayback(SingleSpeakerParams, speakerName, speakerParams.PcmVol)
				SetupPlayback(SingleSpeakerParams, speakerName, "-24")
				local vmon, imon = PlayStimulus("sweeptone_24bitpadded_4ch.wav", testNamePrefix .. speakerParams.PDCAPrefix .. ".wav")
				AudioTurnOff()

				for n = 1, 20 do
					vmon[n] = 0
					imon[n] = 0
				end

				-- FFT length must be a power of 2 (required by TorchDSP library)
				local fileLength = #vmon
				local FFTLength = math.pow(2, dsp.extramath.nextpow2(fileLength))

				print("FFT length: " .. FFTLength)


				-- convert vmon and imon from 'table' to 'torch.Tensor' so that we can use it as input of dsp.fft() in TorchDSP library
				vmon = torch.Tensor(vmon)
				imon = torch.Tensor(imon)

				-- zeropadding vmon and imon to FFTlength
				local x = os.time()
				vmon = torch.cat(vmon, torch.zeros(FFTLength - fileLength), 1)
				imon = torch.cat(imon, torch.zeros(FFTLength - fileLength), 1)
				print("Zero-padding took " .. string.format("%.2f", os.time() - x) .. " seconds")

				-- FFT
				local x = os.time()
				local vmonFFT = dsp.fft(vmon)
				local imonFFT = dsp.fft(imon)
				print("FFT took: " .. string.format("%.2f", os.time() - x) .. " seconds")

				local zDenTensor = torch.pow(imonFFT[{{}, 1}], 2) + torch.pow(imonFFT[{{}, 2}], 2)
				local zNumTensor1 = torch.cmul(vmonFFT[{{}, 1}], imonFFT[{{}, 1}]) + torch.cmul(vmonFFT[{{}, 2}], imonFFT[{{}, 2}])
				local zNumTensor2 = torch.cmul(vmonFFT[{{}, 2}], imonFFT[{{}, 1}]) - torch.cmul(vmonFFT[{{}, 1}], imonFFT[{{}, 2}])
				local zFFTTensor = torch.cat(torch.cdiv(zNumTensor1, zDenTensor), torch.cdiv(zNumTensor2, zDenTensor), 2)
				local zFFTMagTensor = dsp.complex.abs(zFFTTensor)
				local zFFTFrequenciesTensor = torch.linspace(0, FFTLength-1, FFTLength) * gSampleRate / FFTLength

				zFFT = torch.totable(zFFTTensor)
				zFFTMag = torch.totable(zFFTMagTensor)
				FFTFrequenices = torch.totable(zFFTFrequenciesTensor)

				local x = os.time()

				-- Calculate smoothed impedance curve with Gaussian smoothing
				print("Smoothing impedance curve..")
				local width = 32 * 2 * (#zFFT - 1) / gSampleRate
				local zFFTMagSmoothed = gaussian_smooth(zFFTMag, width)

				print("Smoothing took: " .. string.format("%.2f", os.time() - x) .. " seconds")

				-- AL.WriteCSV(gWaveFilesPath .. testNamePrefix .. speakerParams.PDCAPrefix .. "Impedance.csv", {FFTFrequenices, zFFTMag, zFFTMagSmoothed})

				-- Calculation of TS parameters is disabled for MP.
				if (gTSReporting == true) then
					-- Args: raw and smoothed impedance curves, raw curve, freq. bins, parameters
					TSParams[speakerName] = compute_TS(zFFTMagSmoothed, zFFTMag, FFTFrequenices, searchParams, testNamePrefix .. speakerParams.PDCAPrefix)
					TSParams[speakerName] = TS_fit_check(TSParams[speakerName], zFFTMagSmoothed, FFTFrequenices, searchParams)

					-- Report TS parameters to PDCA
					local upper = nil
					local lower = nil
					for idx, val in pairs(TSParams[speakerName]) do
						upper = nil
						lower = nil
						if idx ~= "mag" then
							local scale
							if idx == "Le" or idx == "Mms" then	-- scale Le/Mms to play nice with DAPT
								scale = 10^6
							else
								scale = 1.0
							end

							PrintString(testNamePrefix .. speakerParams.PDCAPrefix .. idx.. " " .. tostring(val*scale))
							ReportData(testNamePrefix .. speakerParams.PDCAPrefix .. idx, FiniteOrZero(val*scale),"n/a",lower,upper)
						end
					end
				end

				local ReportingFreqs = AL.GetR80Sequence(100, 20000, 40);
				local ReportingFreqsFFTIs = {}

				for n = 1, #ReportingFreqs do
					ReportingFreqsFFTIs[n] = math.floor(ReportingFreqs[n] * FFTLength / gSampleRate)
				end

				-- PF check
				local lowerLimits, upperLimits;
				if gUnitType == "D83" and speakerName == "TopSpeaker" then
					upperLimits = { 11.0513817692545,	11.055991918262,	11.0616020567,	11.0669798443787,	11.0742822438438,	11.081444761003,	11.0902453585547,	11.1022364918637,	11.1144254437456,	11.1276467942436,	11.1441245764385,	11.1575305687626,	11.176258337736,	11.1981219499623,	11.2229441546093,	11.2496064729219,	11.282472537436,	11.3240987711239,	11.3685580211235,	11.4370279156747,	11.4971608470516,	11.5852080063125,	11.6897762464204,	11.8121250523508,	11.9911338972034,	12.1990161222172,	12.4449758620087,	12.7257850981567,	13.0310222094727,	13.4137886354875,	13.7717358956136,	14.0939446184505,	14.1439165314294,	13.9555759895779,	13.5823785904156,	13.1577357046499,	12.6909650573003,	12.3219361859452,	12.0492892734553,	11.8479420183604,	11.6985519928511,	11.565474436049,	11.4717756496365,	11.4011869443209,	11.3430606511122,	11.3044108332376,	11.2762662128504,	11.2564595032394,	11.2562851317111,	11.2803396997928,	11.3334215134443,	11.4294636964634,	11.6032131300047,	11.9667413922486,	12.3862281433437,	12.4566284456163,	12.1034875224425,	11.7729604428313,	11.5994673101708,	11.4806992283383,	11.4153694227089,	11.367442372659,	11.3489209004167,	11.344314288947,	11.3491040237509,	11.3700316076414,	11.3976308802106,	11.4282729386499,	11.469645385587,	11.5194205601502,	11.5744104226913,	11.6432717566385,	11.6966471176354,	11.7907976868681,	11.8651980363442,	11.9378318304643,	12.0518464530585,	12.1681992075177,	12.291149988236,	12.441824926191,	nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil }
					lowerLimits = { 8.55138176925451,	8.55599191826196,	8.5616020567,	8.56697984437867,	8.57428224384377,	8.58144476100302,	8.59024535855466,	8.60223649186375,	8.6144254437456,	8.62764679424361,	8.64412457643847,	8.6575305687626,	8.67625833773601,	8.69812194996226,	8.72294415460935,	8.74960647292188,	8.78247253743604,	8.82409877112393,	8.86855802112351,	8.93702791567466,	8.99716084705162,	9.08520800631248,	9.18977624642037,	9.31212505235083,	9.49113389720344,	9.69901612221721,	9.94497586200874,	10.2257850981567,	10.5310222094727,	10.9137886354875,	11.2717358956136,	11.5939446184505,	11.6439165314294,	11.4555759895779,	11.0823785904156,	10.6577357046499,	10.1909650573003,	9.82193618594524,	9.54928927345534,	9.34794201836045,	9.19855199285114,	9.06547443604899,	8.97177564963649,	8.90118694432087,	8.84306065111215,	8.80441083323765,	8.77626621285036,	8.75645950323936,	8.75628513171111,	8.78033969979281,	8.83342151344434,	8.92946369646337,	9.10321313000471,	9.46674139224856,	9.88622814334372,	9.95662844561627,	9.60348752244251,	9.27296044283126,	9.09946731017075,	8.98069922833828,	8.91536942270885,	8.867442372659,	8.84892090041666,	8.84431428894697,	8.84910402375094,	8.87003160764145,	8.89763088021055,	8.92827293864992,	8.96964538558701,	9.01942056015022,	9.0744104226913,	9.14327175663846,	9.19664711763539,	9.29079768686813,	9.36519803634419,	9.43783183046426,	9.55184645305846,	9.66819920751772,	9.79114998823604,	9.94182492619099,	nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil }
				
				elseif gUnitType == "D83" and speakerName == "BotSpeaker" then
					upperLimits = { 11.8579596099345,	11.8634073776761,	11.8692439341325,	11.8744372854198,	11.8819166204808,	11.8899703316784,	11.8984018201895,	11.9102362640103,	11.9237747206855,	11.9373435183044,	11.9517933702976,	11.9662648755993,	11.9835975835663,	12.0047994909949,	12.0280057288746,	12.0531891913369,	12.0847485701048,	12.1228678103539,	12.1633098898271,	12.2278665793306,	12.2814304921219,	12.3588135542793,	12.4513714788546,	12.5564915810177,	12.7070897326254,	12.8827005708771,	13.090323849533,	13.3328962667847,	13.6062687462828,	13.973356461317,	14.3766004582801,	14.9151916486592,	15.271197700184,	15.6023657833895,	15.7117621172454,	15.5907203968366,	15.199918169452,	14.7037840809159,	14.2267077522725,	13.8178093730906,	13.4886951275609,	13.1794570701625,	12.9456882202666,	12.7740358990093,	12.6242071500606,	12.511154379396,	12.4210969150021,	12.3406842529817,	12.2870249061196,	12.2545942980502,	12.2354351447853,	12.2278510446063,	12.2294467300169,	12.2460627920401,	12.2785870297851,	12.328839624486,	12.4230690934195,	12.6102031091704,	12.8864153105024,	13.0732899091386,	12.9537457437555,	12.7598752791909,	12.6658004087675,	12.6403828335755,	12.6911679979716,	12.8250102517708,	12.9158170545588,	12.8156362220398,	12.7826366256203,	12.8192427975532,	12.8871650038676,	12.9876257285889,	13.0654634599059,	13.1813303532724,	13.2786366113505,	13.374916126103,	13.5005276956748,	13.6280065999236,	13.7693818610013,	13.9049147779409,	nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil }
					lowerLimits = { 9.35795960993448,	9.3634073776761,	9.36924393413249,	9.3744372854198,	9.38191662048085,	9.38997033167838,	9.39840182018949,	9.41023626401027,	9.42377472068546,	9.43734351830441,	9.45179337029763,	9.46626487559928,	9.48359758356626,	9.50479949099493,	9.52800572887458,	9.55318919133685,	9.58474857010484,	9.6228678103539,	9.66330988982706,	9.72786657933063,	9.78143049212188,	9.85881355427925,	9.95137147885464,	10.0564915810177,	10.2070897326254,	10.3827005708771,	10.590323849533,	10.8328962667847,	11.1062687462828,	11.473356461317,	11.8766004582801,	12.4151916486592,	12.771197700184,	13.1023657833895,	13.2117621172454,	13.0907203968366,	12.699918169452,	12.2037840809159,	11.7267077522725,	11.3178093730906,	10.9886951275609,	10.6794570701625,	10.4456882202666,	10.2740358990093,	10.1242071500606,	10.011154379396,	9.92109691500207,	9.84068425298166,	9.78702490611965,	9.7545942980502,	9.73543514478533,	9.72785104460629,	9.72944673001687,	9.74606279204012,	9.77858702978514,	9.82883962448598,	9.92306909341946,	10.1102031091704,	10.3864153105024,	10.5732899091386,	10.4537457437555,	10.2598752791909,	10.1658004087675,	10.1403828335755,	10.1911679979716,	10.3250102517708,	10.4158170545588,	10.3156362220398,	10.2826366256203,	10.3192427975532,	10.3871650038676,	10.4876257285889,	10.5654634599059,	10.6813303532724,	10.7786366113505,	10.874916126103,	11.0005276956748,	11.1280065999236,	11.2693818610013,	11.4049147779409,	nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil }
				
				elseif gUnitType == "D84" and speakerName == "TopSpeaker" then
					upperLimits = { 11.8518931486882,	11.860757878432,	11.8694805409084,	11.8796941903158,	11.8919460539921,	11.904693480394,	11.9202365017195,	11.9401038190483,	11.9616518366406,	11.9848715541584,	12.0103349216358,	12.0359426622657,	12.065285204329,	12.1013245968365,	12.1408316906425,	12.1838544883398,	12.2372378471681,	12.3009942207417,	12.3702202737677,	12.4750234717823,	12.5623769044106,	12.6892175255974,	12.8360838388121,	13.0006932823762,	13.2313733656949,	13.4898578052955,	13.7772317111262,	14.0875319924333,	14.4024210871524,	14.7636759924942,	15.06239503036,	15.2944198221105,	15.3133571991355,	15.1387225908708,	14.8057811963905,	14.4015152969202,	13.9129647721345,	13.4924337084189,	13.1587722101896,	12.8992794389382,	12.7021530371887,	12.5233318788994,	12.3903976300889,	12.2929885146684,	12.2099929557224,	12.1534661393206,	12.1127110565132,	12.0883402006728,	12.0878774326113,	12.1146158680208,	12.1692751862872,	12.2711502757029,	12.4407162141709,	12.7675297204155,	13.2885210212011,	13.9964249763152,	14.5182767640785,	14.0102178395971,	13.2119451079657,	12.6277023545819,	12.4262318555907,	12.3033877871871,	12.258345309107,	12.2460250254959,	12.2592459840015,	12.2876971627932,	12.3256896446209,	12.370122094649,	12.4206560920309,	12.4907918481943,	12.5562719884298,	12.6363702542793,	12.7113591556815,	12.8277541656554,	12.933385683945,	13.0240038547371,	13.1547803657711,	13.2835104319175,	13.4183336519695,	13.5565732383805, nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil}
					lowerLimits = { 9.35189314868816,	9.36075787843203,	9.36948054090844,	9.3796941903158,	9.39194605399208,	9.40469348039404,	9.42023650171948,	9.4401038190483,	9.46165183664063,	9.48487155415839,	9.51033492163578,	9.53594266226574,	9.565285204329,	9.60132459683651,	9.64083169064249,	9.68385448833977,	9.73723784716809,	9.80099422074174,	9.87022027376775,	9.97502347178228,	10.0623769044106,	10.1892175255974,	10.3360838388121,	10.5006932823762,	10.7313733656949,	10.9898578052955,	11.2772317111262,	11.5875319924333,	11.9024210871524,	12.2636759924942,	12.56239503036,	12.7944198221105,	12.8133571991355,	12.6387225908708,	12.3057811963905,	11.9015152969202,	11.4129647721345,	10.9924337084189,	10.6587722101896,	10.3992794389382,	10.2021530371887,	10.0233318788994,	9.89039763008889,	9.79298851466841,	9.70999295572239,	9.6534661393206,	9.61271105651315,	9.5883402006728,	9.58787743261134,	9.61461586802075,	9.66927518628717,	9.77115027570286,	9.94071621417091,	10.2675297204155,	10.7885210212011,	11.4964249763152,	12.0182767640785,	11.5102178395971,	10.7119451079657,	10.1277023545819,	9.92623185559066,	9.80338778718712,	9.75834530910697,	9.74602502549593,	9.75924598400154,	9.78769716279319,	9.82568964462095,	9.87012209464898,	9.92065609203092,	9.99079184819429,	10.0562719884298,	10.1363702542793,	10.2113591556815,	10.3277541656554,	10.433385683945,	10.5240038547371,	10.6547803657711,	10.7835104319175,	10.9183336519695,	11.0565732383805, nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil}
				
				elseif gUnitType == "D84" and speakerName == "BotSpeaker" then
					upperLimits = { 11.961998016309,	11.9698203384618,	11.9786323106253,	11.9877702424475,	11.9991767978072,	12.0108737319027,	12.0246076284653,	12.0428697163717,	12.0630434209037,	12.0851260723994,	12.1077676063792,	12.1319516662492,	12.1597959688912,	12.1931978389594,	12.2314287742489,	12.2719234438108,	12.3218127326459,	12.3814838292727,	12.4463780257904,	12.5430811079161,	12.6215095907965,	12.7364112216146,	12.8650065355747,	13.0056890511699,	13.1987771839385,	13.4100036386524,	13.6457361876893,	13.895951437315,	14.165426179981,	14.4971219684089,	14.833950034323,	15.2667518596186,	15.5628733399538,	15.8846150733744,	16.0788061245233,	16.120309504485,	15.9670684980333,	15.6517470772204,	15.2602123372569,	14.8499681690833,	14.4677956042402,	14.0611560849321,	13.7249710331342,	13.4571764144699,	13.2147069526223,	13.030869571138,	12.8670280878022,	12.721652181784,	12.6202657144009,	12.5504669201647,	12.5054316322279,	12.4802981385414,	12.4660883635321,	12.4633323075093,	12.4767083200773,	12.5058480513725,	12.5654657159261,	12.6845959433052,	12.9085361950643,	13.4172937918638,	13.5797087858301,	13.2113112618807,	12.9064989336223,	12.7702480823632,	12.7413181194773,	12.7930563518118,	12.9139838075374,	13.0768987965414,	13.0800888159022,	13.038567698567,	13.065719588903,	13.1438901091871,	13.2158635593518,	13.3122232120799,	13.4118244846494,	13.5105749892054,	13.6325233484747,	13.7623990663115,	13.886410165884,	13.9870058388147, nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil}
					lowerLimits = { 9.46199801630898,	9.4698203384618,	9.47863231062526,	9.48777024244754,	9.49917679780722,	9.51087373190269,	9.52460762846535,	9.54286971637173,	9.56304342090366,	9.58512607239936,	9.60776760637924,	9.63195166624924,	9.65979596889125,	9.69319783895935,	9.73142877424891,	9.77192344381077,	9.82181273264588,	9.88148382927274,	9.94637802579044,	10.0430811079161,	10.1215095907965,	10.2364112216146,	10.3650065355747,	10.5056890511699,	10.6987771839385,	10.9100036386524,	11.1457361876893,	11.395951437315,	11.665426179981,	11.9971219684089,	12.333950034323,	12.7667518596186,	13.0628733399538,	13.3846150733744,	13.5788061245233,	13.620309504485,	13.4670684980333,	13.1517470772204,	12.7602123372569,	12.3499681690833,	11.9677956042402,	11.5611560849321,	11.2249710331342,	10.9571764144699,	10.7147069526223,	10.530869571138,	10.3670280878022,	10.221652181784,	10.1202657144009,	10.0504669201647,	10.0054316322279,	9.98029813854139,	9.96608836353208,	9.96333230750932,	9.97670832007728,	10.0058480513725,	10.0654657159261,	10.1845959433052,	10.4085361950643,	10.9172937918638,	11.0797087858301,	10.7113112618807,	10.4064989336223,	10.2702480823632,	10.2413181194773,	10.2930563518118,	10.4139838075374,	10.5768987965414,	10.5800888159022,	10.538567698567,	10.565719588903,	10.6438901091871,	10.7158635593518,	10.8122232120799,	10.9118244846494,	11.0105749892054,	11.1325233484747,	11.2623990663115,	11.386410165884,	11.4870058388147, nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil}

				elseif gUnitType == "D37" and speakerName == "TopSpeaker" then
					upperLimits	= { 11.7913407061264,	11.7964382167024,	11.8042912349311,	11.810573758804,	11.8206287939879,	11.8294056848373,	11.8390974999747,	11.8520854286835,	11.8688841741995,	11.8851616276801,	11.9036756417911,	11.9214125334197,	11.9422189758764,	11.9675510289801,	11.9984098565484,	12.0298459342726,	12.0675674573266,	12.1169794898535,	12.1677687566263,	12.2480253238828,	12.3143547894887,	12.4150876777123,	12.5328665575557,	12.6682936714132,	12.866087984056,	13.0938871572614,	13.3652682288103,	13.673611023914,	14.0060476417441,	14.4208782161537,	14.8065796519792,	15.1640968762815,	15.2508769776451,	15.1143363297239,	14.7862756587289,	14.3877605057094,	13.9107026112063,	13.4873998738382,	13.1393188227193,	12.8667513606921,	12.6639772295463,	12.4833732267271,	12.3522212856377,	12.2560385648734,	12.1709451183195,	12.114113494669,	12.0733847519922,	12.0423019833746,	12.0286588759886,	12.0332258540692,	12.0642259662296,	12.1197079322042,	12.209893997753,	12.3926013284867,	12.6838078922794,	13.1598197042623,	13.8982584974438,	14.0832286318525,	13.412663639242,	12.7040815218335,	12.4392931523559,	12.2582905394288,	12.1753288924595,	12.1349612707129,	12.1187771067029,	12.1256751639961,	12.1396483081082,	12.1637034537593,	12.185328296274,	12.2083068878873,	12.2294139841679,	12.2672506329031,	12.3000169759055,	12.3517060738096,	12.4181002092665,	12.4878191445502,	12.5961035306162,	12.7039199662482,	12.7760323057355,	12.8469417474389,	nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil }
					lowerLimits = { 9.29134070612643,	9.29643821670241,	9.30429123493111,	9.31057375880397,	9.3206287939879,	9.32940568483729,	9.33909749997474,	9.35208542868346,	9.36888417419951,	9.38516162768006,	9.40367564179109,	9.42141253341968,	9.44221897587643,	9.46755102898014,	9.49840985654842,	9.52984593427264,	9.56756745732658,	9.61697948985347,	9.66776875662627,	9.74802532388284,	9.81435478948872,	9.91508767771231,	10.0328665575557,	10.1682936714132,	10.366087984056,	10.5938871572614,	10.8652682288103,	11.173611023914,	11.5060476417441,	11.9208782161537,	12.3065796519792,	12.6640968762815,	12.7508769776451,	12.6143363297239,	12.2862756587289,	11.8877605057094,	11.4107026112063,	10.9873998738382,	10.6393188227193,	10.3667513606921,	10.1639772295463,	9.98337322672709,	9.85222128563768,	9.75603856487342,	9.67094511831952,	9.61411349466901,	9.57338475199222,	9.54230198337456,	9.52865887598859,	9.53322585406923,	9.56422596622956,	9.61970793220421,	9.70989399775298,	9.89260132848668,	10.1838078922794,	10.6598197042623,	11.3982584974438,	11.5832286318525,	10.912663639242,	10.2040815218335,	9.9392931523559,	9.75829053942883,	9.67532889245955,	9.63496127071287,	9.61877710670291,	9.62567516399607,	9.63964830810822,	9.66370345375933,	9.68532829627401,	9.70830688788727,	9.72941398416791,	9.76725063290309,	9.80001697590552,	9.85170607380957,	9.91810020926645,	9.98781914455021,	10.0961035306162,	10.2039199662482,	10.2760323057355,	10.3469417474389,	nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil }

			    elseif gUnitType == "D37" and speakerName == "BotSpeaker" then
					upperLimits = { 10.154675732363,	10.1614388972685,	10.1701579939975,	10.1774894694659,	10.1884523066231,	10.1983529977431,	10.2112809672035,	10.2281375862396,	10.2464368927147,	10.2668499328628,	10.2886977754403,	10.3109623910199,	10.3375556895169,	10.3702828848965,	10.4087351784031,	10.4494904202479,	10.4998874802562,	10.5643539617596,	10.6338709750085,	10.7430806342074,	10.8333253294982,	10.9704553966516,	11.1310662184958,	11.3141811952069,	11.573777526099,	11.8574084111599,	12.1683600844919,	12.4926490981699,	12.7938166066702,	13.1115142446222,	13.3423164925374,	13.4756500104384,	13.4382971362053,	13.2447337133365,	12.956740481159,	12.6384685665723,	12.2673466790596,	11.9478844948759,	11.6966718823671,	11.4953520127542,	11.3376083258495,	11.1869987149638,	11.0696034913618,	10.9768017837982,	10.8912099545747,	10.8253138907982,	10.7644913518985,	10.7042869789851,	10.654222730684,	10.6129903147559,	10.5837660737625,	10.5596533309943,	10.5381032883509,	10.5230291946008,	10.5150685356935,	10.5156388549123,	10.5344589440005,	10.5896430941666,	10.6965828734634,	10.9293346329081,	11.0795855869431,	11.1028566664936,	10.9799597234915,	10.8243808439702,	10.7094971509348,	10.6939103919102,	10.7341277158518,	10.8086569194253,	10.8648252596282,	10.8430751030968,	10.8295147102416,	10.8696502539446,	10.9313458021926,	11.0143789269116,	11.1052745125898,	11.20015507849,	11.3230602669744,	11.4431872719395,	11.5721512321974,	11.7034475358107,	nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil }
					lowerLimits	= { 7.65467573236296,	7.66143889726851,	7.67015799399752,	7.67748946946588,	7.6884523066231,	7.69835299774309,	7.71128096720346,	7.72813758623962,	7.74643689271472,	7.76684993286281,	7.78869777544034,	7.81096239101989,	7.83755568951691,	7.87028288489653,	7.90873517840314,	7.94949042024785,	7.99988748025616,	8.06435396175963,	8.13387097500847,	8.2430806342074,	8.33332532949815,	8.47045539665162,	8.63106621849576,	8.81418119520692,	9.07377752609904,	9.35740841115991,	9.66836008449191,	9.9926490981699,	10.2938166066702,	10.6115142446222,	10.8423164925374,	10.9756500104384,	10.9382971362053,	10.7447337133365,	10.456740481159,	10.1384685665723,	9.76734667905959,	9.44788449487594,	9.19667188236713,	8.99535201275423,	8.83760832584951,	8.68699871496385,	8.56960349136176,	8.47680178379815,	8.3912099545747,	8.32531389079823,	8.26449135189854,	8.20428697898514,	8.15422273068403,	8.11299031475589,	8.08376607376254,	8.05965333099431,	8.03810328835092,	8.02302919460076,	8.01506853569347,	8.01563885491226,	8.03445894400047,	8.08964309416664,	8.19658287346344,	8.42933463290809,	8.57958558694314,	8.60285666649362,	8.47995972349146,	8.32438084397021,	8.20949715093483,	8.19391039191023,	8.23412771585179,	8.30865691942532,	8.36482525962823,	8.34307510309683,	8.32951471024164,	8.36965025394456,	8.43134580219262,	8.51437892691156,	8.60527451258975,	8.70015507849005,	8.82306026697444,	8.94318727193949,	9.07215123219737,	9.20344753581074,	nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil }
				elseif gUnitType == "D38" and speakerName == "TopSpeaker" then
					upperLimits	= { 11.1432021289099,	11.1497347293486,	11.1584331764535,	11.1665510167031,	11.1769075953855,	11.1880636500281,	11.2007430006824,	11.2176289238612,	11.2362200701743,	11.2562734220724,	11.2773898087164,	11.2995992077976,	11.3240482263781,	11.3547904327459,	11.3899620928464,	11.4270713570827,	11.4726414295864,	11.5288842199852,	11.5905708188922,	11.6855547488922,	11.7651442250665,	11.8850068375037,	12.0279076664402,	12.1940410562482,	12.4393619277105,	12.7207977569276,	13.0467837324668,	13.4087059835598,	13.7654967657459,	14.1487877186706,	14.3971577543427,	14.4258321800591,	14.235722286455,	13.8212088984195,	13.3565423988626,	12.9321833218464,	12.5133699145643,	12.2064647516544,	11.9869866502363,	11.828485757548,	11.7150896407681,	11.6151720501477,	11.5437011187592,	11.4940406402806,	11.4575563230044,	11.4422588818685,	11.4458323661684,	11.4819683505761,	11.5676672964254,	11.7190579988922,	11.9373542897341,	12.2067960238257,	12.4552568235451,	12.5816925856425,	12.4822987076366,	12.2789684748006,	12.0631384973855,	11.915463415805,	11.8496531737814,	11.8453992760709,	11.8755575772821,	11.8785341646529,	11.7831214479764,	11.6461726621861,	11.5396449092171,	11.5029298140473,	11.5018752630724,	11.5162705053619,	11.5358427430871,	11.5700794818759,	11.6110785574298,	11.6791504078434,	11.7380942063811,	11.8244549457312,	11.9033425273412,	11.9714077331462,	12.0500693175775,	12.1384425331462,	12.242452532777,	12.3546720120089, nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil }
					lowerLimits = { 8.64320212890989,	8.64973472934859,	8.65843317645347,	8.6665510167031,	8.67690759538553,	8.68806365002806,	8.70074300068242,	8.71762892386115,	8.7362200701743,	8.75627342207238,	8.7773898087164,	8.79959920779764,	8.82404822637814,	8.85479043274594,	8.88996209284638,	8.92707135708272,	8.97264142958641,	9.02888421998523,	9.09057081889217,	9.18555474889217,	9.26514422506647,	9.38500683750369,	9.52790766644018,	9.69404105624815,	9.93936192771049,	10.2207977569276,	10.5467837324668,	10.9087059835598,	11.2654967657459,	11.6487877186706,	11.8971577543427,	11.9258321800591,	11.735722286455,	11.3212088984195,	10.8565423988626,	10.4321833218464,	10.0133699145643,	9.70646475165436,	9.48698665023634,	9.32848575754801,	9.2150896407681,	9.11517205014771,	9.04370111875923,	8.99404064028065,	8.95755632300443,	8.94225888186854,	8.94583236616839,	8.98196835057608,	9.0676672964254,	9.21905799889217,	9.43735428973412,	9.7067960238257,	9.95525682354505,	10.0816925856425,	9.98229870763663,	9.77896847480059,	9.56313849738553,	9.41546341580502,	9.34965317378139,	9.3453992760709,	9.37555757728213,	9.37853416465288,	9.28312144797636,	9.14617266218611,	9.03964490921713,	9.00292981404727,	9.00187526307238,	9.01627050536189,	9.03584274308715,	9.07007948187592,	9.11107855742984,	9.17915040784343,	9.23809420638109,	9.32445494573117,	9.40334252734121,	9.47140773314623,	9.55006931757755,	9.63844253314623,	9.74245253277696,	9.85467201200886, nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil }
			    elseif gUnitType == "D38" and speakerName == "BotSpeaker" then
					upperLimits = { 11.5085980846243,	11.5177328697027,	11.527476224753,	11.5381042609852,	11.551262236287,	11.5644048250947,	11.5811579029423,	11.6031876039157,	11.627380779,	11.6536521488166,	11.6814499599852,	11.7111436162722,	11.7440377351331,	11.7848222454734,	11.8299388073373,	11.8784382939349,	11.9387048536834,	12.0090148132396,	12.0849789376775,	12.1955259111243,	12.2856743921598,	12.4133329610651,	12.5530603493491,	12.7046841137278,	12.9081746897189,	13.1229838742899,	13.3563830456361,	13.5979595132249,	13.8408310396598,	14.1259201430917,	14.3855857563166,	14.6555183028698,	14.7779559004734,	14.8193909297929,	14.7314716159024,	14.5431775142012,	14.2299248519675,	13.8827302707396,	13.5545823971598,	13.2646065617899,	13.0204323106065,	12.7859513323521,	12.60427573,	12.4636284869675,	12.3372304569822,	12.2377437259615,	12.1536966500888,	12.0795841219083,	12.0289609778698,	11.9892536898669,	11.9641079550592,	11.9484908446746,	11.9346822430473,	11.923843464645,	11.9159489006805,	11.914815068358,	11.9229328647929,	11.9664224823964,	12.0677363488757,	12.3330879838905,	12.6320881908284,	13.011947859926,	13.0133330505473,	12.7083787485799,	12.3768766760355,	12.2298952249556,	12.2131742993935,	12.2910259881361,	12.4245186113314,	12.4250397895562,	12.2342698586982,	12.1738630822633,	12.2273269568343,	12.2902071999704,	12.3528621543639,	12.4444716398964,	12.567894788284,	12.6975610471598,	12.8275173961686,	12.9583663386391, nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil }
					lowerLimits	= { 9.00859808462426,	9.01773286970266,	9.02747622475296,	9.03810426098521,	9.05126223628698,	9.06440482509467,	9.08115790294231,	9.10318760391568,	9.127380779,	9.15365214881657,	9.18144995998521,	9.21114361627219,	9.24403773513314,	9.28482224547337,	9.32993880733728,	9.37843829393491,	9.43870485368343,	9.50901481323964,	9.58497893767751,	9.69552591112426,	9.78567439215976,	9.91333296106509,	10.0530603493491,	10.2046841137278,	10.4081746897189,	10.6229838742899,	10.8563830456361,	11.0979595132249,	11.3408310396598,	11.6259201430917,	11.8855857563166,	12.1555183028698,	12.2779559004734,	12.3193909297929,	12.2314716159024,	12.0431775142012,	11.7299248519675,	11.3827302707396,	11.0545823971598,	10.7646065617899,	10.5204323106065,	10.2859513323521,	10.10427573,	9.96362848696745,	9.83723045698225,	9.73774372596154,	9.65369665008876,	9.57958412190828,	9.52896097786982,	9.48925368986686,	9.46410795505917,	9.44849084467456,	9.43468224304734,	9.42384346464497,	9.41594890068047,	9.41481506835798,	9.4229328647929,	9.46642248239645,	9.56773634887574,	9.83308798389053,	10.1320881908284,	10.511947859926,	10.5133330505473,	10.2083787485799,	9.8768766760355,	9.72989522495562,	9.71317429939349,	9.79102598813609,	9.92451861133136,	9.92503978955621,	9.73426985869822,	9.67386308226332,	9.72732695683431,	9.79020719997041,	9.8528621543639,	9.94447163989645,	10.067894788284,	10.1975610471598,	10.3275173961686,	10.4583663386391, nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil }
				else
					upperLimits = {  nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil}
					lowerLimits = {  nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil}
				end

				local impedanceLimitsPassed = true

				for n = 1, #ReportingFreqs do
					local curZ = zFFTMagSmoothed[(ReportingFreqsFFTIs[n])]
					if(impedanceLimitsPassed and not AL.IsWithinLimit(curZ, lowerLimits[n], upperLimits[n])) then
						ReportData(testNamePrefix .. speakerParams.PDCAPrefix .. "PROTECTIVE_FILM_REMOVED", 0, 'bool', 0.5, 2);
						PrintString("PROTECTIVE_FILM_REMOVED test failed. Check presence of protective film on device.")
						impedanceLimitsPassed = false
						Shell "display --on"
					end

					ReportData(testNamePrefix .. speakerParams.PDCAPrefix .. "ZRSpectrum@" .. tostring(ReportingFreqs[n]), curZ, 'ohms', lowerLimits[n], upperLimits[n])
				end

				if(impedanceLimitsPassed) then
					PrintString("PROTECTIVE_FILM_REMOVED test passed.")
					ReportData(testNamePrefix .. speakerParams.PDCAPrefix .. "PROTECTIVE_FILM_REMOVED", 1, 'bool', 0.5, 2);
				end

			end

		end

	end

	return TMSpeakerTSParams, HSSpeakerTSParams
end -- TSCalibration()

function round(value)
	return math.floor(value + 0.5)
end

function FindMax(vmon, imon)
	for n = 1, 20 do
		vmon[n] = 0
		imon[n] = 0
	end

	-- Perform FFTs with Torch
	-- FFT length must be a power of 2 (required by TorchDSP library)
	local x = os.time()
	local fileLength = #vmon
	local FFTLength = math.pow(2, dsp.extramath.nextpow2(fileLength))

	print("FFT length: " .. FFTLength)

	-- convert vmon and imon from 'table' to 'torch.Tensor' so that we can use it as input of dsp.fft() in TorchDSP library
	vmon = torch.Tensor(vmon)
	imon = torch.Tensor(imon)

	-- zeropadding vmon and imon to FFTlength
	vmon = torch.cat(vmon, torch.zeros(FFTLength - fileLength), 1)
	imon = torch.cat(imon, torch.zeros(FFTLength - fileLength), 1)

	local vmonFFT = dsp.fft(vmon)
	local imonFFT = dsp.fft(imon)

	local vmonFFTMag = dsp.complex.abs(vmonFFT)
	local imonFFTMag = dsp.complex.abs(imonFFT)

	vmonFFTMax = torch.max(vmonFFTMag)
	imonFFTMax = torch.max(imonFFTMag)

	return vmonFFTMax, imonFFTMax
end

-- 'Index' is the index of the word to be read. (Each word is a 2 byte integer)
-- 'Scaling' is a multiplier applied to the numeric value after its retrived.
function ReadSyscfg(Index, Scaling)

	Shell "syscfg print SpTS"

	if (Last.Output:find("Not Found!") ~= nil) then
		error("Unable to read syscfg SpTS!")
	else
		--version = tonumber(Last.Output:sub(3, 6))

		local int32Number = math.floor((Index-1)/2) + 1;
		local offset = (Index-1) % 2;
		local startCharI = 11*(int32Number-1) + offset * 4 + 3;
		local valueString = Last.Output:sub(startCharI, startCharI + 3);

		return tonumber(valueString, 16) * Scaling;
	end
end

-- rdar://problem/50156388 Update amplifier boot sequence in audio tests
function SetupPlayback(gSpeakerParams, SpeakerName, AmpGain)

	local s = gSpeakerParams[SpeakerName].DiagsSpeakerName

	Shell("audio --resetblock " .. s)
	Shell("audio --resetblock socmca")
	Shell("audio --resetblock codec")
	--Shell("audio --resetblock hallsensor")

	-- Turn off all other speakers
	for curSpeakerName, curSpeakerParams in pairs(gSpeakerParams) do
		if(curSpeakerName ~= SpeakerName) then
			Shell("audio --turnoff " .. curSpeakerParams.DiagsSpeakerName)
		end
	end
	if (gSpeakerParams[SpeakerName].group == "TopModuleSpeakers") then
		for otherSpeakerName, otherSpeakerParams in pairs(gHSSpeakersParams) do
			Shell("audio --turnoff " .. otherSpeakerParams.DiagsSpeakerName)
		end
	else
		for otherSpeakerName, otherSpeakerParams in pairs(gTMSpeakersParams) do
			Shell("audio --turnoff " .. otherSpeakerParams.DiagsSpeakerName)
		end
	end

	Shell("audio --turnoff arc")
	Shell("audio --turnoff hallsensor")
	Shell("routeaudio --route --block " .. s .. " --in spk-i2s --out spk-out")
	Shell("audioparam -b " .. s .. " --set --param enable-mon --value true")
	Shell("audioreg -b " .. s .. " -w -a 0x00007230 -d 0x00180000")
	Shell("setvol --block " .. s .. " --volume pcm-vol --value " .. AmpGain)

end

function I2C(I2CBus, I2CAdd, I2CRegister, I2CValue)
	Shell(string.format("i2c -v %d 0x%02x 0x%02x 0x%02x", I2CBus, I2CAdd, I2CRegister, I2CValue))
end

function PlayStimulus(StimulusFile, MONOutputFile)

	Shell ("processaudio --freebufs all")
	Shell ("loopaudio --block socmca --txport ap-mca5 --rxport ap-mca5 --bitdepth 24 --rate 48000 --channels 4 --file " .. StimulusFile)

	local outputFile = gOutputFilesPath .. MONOutputFile

	-- For some reason processaudio doesn't create the file so we do it..
	local f = assert(io.open(outputFile, "w+"), "Cannot create file " .. outputFile)
	f:close()

	Shell ("processaudio --writebuffer looprx0 --writefile " .. outputFile) -- Writes a 5 channel wave file

	PrintString("Recorded wave saved: " .. outputFile)

	local channels, sampleRate, bitDepth = AL.LoadWave(outputFile, false)

	assert(sampleRate == gSampleRate, "Wrong sample rate found while loading file" .. outputFile)
	assert(bitDepth == 24, "Wrong bit depth found while loading file: " .. outputFile)

	local mVMultiplier = gVMONFS
	local mAMultiplier = gIMONFS

	for n = 1, #channels[1] do
		channels[1][n] = math.floor(channels[1][n] / 2^8) * 2^8
		channels[2][n] = math.floor(channels[2][n] / 2^8) * 2^8
	end

	local VSignalmV = AL.Scale(channels[1], mVMultiplier)
	local ISignalmV = AL.Scale(channels[2], mAMultiplier)

	return VSignalmV, ISignalmV
end

function PlayTone(FrequencyHz, DurationMilliseconds, MONOutputFile)

	ConvoyOutputFile = gAcousticCalOutputFilePrefix .. MONOutputFile

	Shell "processaudio --freebufs all"
	Shell ("loopaudio --block socmca --txport ap-mca5 --rxport ap-mca5 --bitdepth 24 --rate 48000 --channels 4 --len " .. DurationMilliseconds .. " --freq " .. FrequencyHz)

	local outputFile = gOutputFilesPath .. ConvoyOutputFile

	-- For some reason processaudio doesn't create the file so we do it..
	local f = assert(io.open(outputFile, "w+"), "Cannot create file " .. outputFile)
	f:close()

	Shell ("processaudio --writebuffer looprx0 --writefile " .. outputFile)

	local channels, sampleRate, bitDepth = AL.LoadWave(outputFile, false)

	assert(sampleRate == gSampleRate, "Wrong sample rate found while loading file" .. outputFile)
	assert(bitDepth == 24, "Wrong bit depth found while loading file: " .. outputFile)

	local mVMultiplier = gVMONFS
	local mAMultiplier = gIMONFS

	for n = 1, #channels[1] do
		channels[1][n] = math.floor(channels[1][n] / 2^8) * 2^8
		channels[2][n] = math.floor(channels[2][n] / 2^8) * 2^8
	end

	local VSignalmV = AL.Scale(channels[1], mVMultiplier)
	local ISignalmV = AL.Scale(channels[2], mAMultiplier)

	return VSignalmV, ISignalmV
end

function AudioTurnOff()
	Shell("audio --turnoff")
end

function WaitForSeconds(TimeInSeconds)
	PrintString("Waiting " .. TimeInSeconds .. " seconds...")
	Shell ("wait " .. tostring(TimeInSeconds * 1000))
end

-- Legacy: Keep function for Bonfire compatibility
function LogStartTime()
	-- Do nothing
end

