---------------------------------------------------------------------------
-- D84TestItem.
-- D84TestItem lua file for QT0 MP Coverage scripts.

local AllTestItems = {

    NandInfo = {
        {Name = "Model_Number",          SubName = "Info", SpecType = "String", Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = nil,},
        {Name = "FW_Revision",           SubName = "Info", SpecType = "String", Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = nil,},
        {Name = "MSP_Revision",          SubName = "Info", SpecType = "String", Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = nil,},
        {Name = "PRODUCTION_FW_VERSION", SubName = "Info", SpecType = "String", Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = nil,},
        {Name = "VENDOR",                SubName = "Info", SpecType = "Equal",  Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = {"WD", "SanDisk", "Sandisk", "Kioxia", "Toshiba", "Samsung", "Hynix"},},
        {Name = "Cell_Type",             SubName = "Info", SpecType = "String", Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = nil,},
        {Name = "Capacity",              SubName = "Info", SpecType = "Equal",  Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = {"128GB", "256GB", "512GB", "1024GB", "1TB"},},
        {Name = "Die_Name",              SubName = "Info", SpecType = "String", Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = nil,},
        {Name = "CHIP_ID",               SubName = "Info", SpecType = "String", Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = nil,},
        {Name = "UID",                   SubName = "Info", SpecType = "Equal",  Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = {"Pass"},},
    },

    NandId = {
        {Name = "ID", SubName = "Info", SpecType = "Equal", Units = nil, LowerLimit = nil, UpperLimit = nil,  EqualTable = {},},
    },

    NandControllerUID = {
        {Name = "Controller_UID", SubName = "Info", SpecType = "String", Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = nil,},
    },

    BatteryPropertyInfo = GetBatteryTestItem("BatteryPropertyInfo"),
    BatteryWRA          = GetBatteryTestItem("BatteryWRA"),
    BatteryCellVendor   = GetBatteryTestItem("BatteryCellVendor"),
    VeridianDataCheck   = GetBatteryTestItem("VeridianDataCheck"),

    Touch = {
        {Name = "Load_Firmware", SubName = "LoadFW", SpecType = "Equal", Units = nil, LowerLimit = nil, UpperLimit = nil,  EqualTable = {"OK"},},
    },
}

function GetTestItemTableFun(testitemname)
	return AllTestItems[testitemname]
end