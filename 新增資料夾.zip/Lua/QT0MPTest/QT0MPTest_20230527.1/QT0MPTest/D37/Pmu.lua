---------------------------------------------------------------------------
-- Pmu.
-- This file contains PMU and Cpmu releted tests.

local ProductName = PlatformInfo('PlatformName')

-- Soc Leakage map between limit and value
local gSOCLeakageBin = {

    [1] = {Value = 0.5, Min = 0,      Max = 40250.001,   Units = nil},
    [2] = {Value = 0.6, Min = 40251,  Max = 48300.001,   Units = nil},
    [3] = {Value = 0.7, Min = 48301,  Max = 56350.001,   Units = nil},
    [4] = {Value = 0.8, Min = 56351,  Max = 64400.001,   Units = nil},
    [5] = {Value = 0.9, Min = 64401,  Max = 72450.001,   Units = nil},
    [6] = {Value = 1.0, Min = 72451,  Max = 80500.001,   Units = nil},
    [7] = {Value = 1.3, Min = 80501,  Max = 104650.001,  Units = nil},
    [8] = {Value = 1.5, Min = 104651, Max = 120750.001,  Units = nil},
    [9] = {Value = 2,   Min = 120751, Max = 10E30,       Units = nil},
}

-- Pmu Adc GND Offset Table
local GNDOffSetTable = {
    ["D83"] = {"amuxa7_gnd", "amuxb2_div_strobe_boost_out", "amuxb5_gnd"},
    ["D84"] = {"amuxa7_gnd", "amuxb2_div_strobe_boost_out", "amuxb5_gnd"},
    ["D37"] = {"amuxa3_gnd", "amuxa5_gnd", "amuxa7_gnd", "amuxb4_gnd"},
    ["D38"] = {"amuxa3_gnd", "amuxa5_gnd", "amuxa7_gnd", "amuxb4_gnd"},
}

-- Panel ID Vendor Define
local PanelIDVendorLUT = {
    [0x00] = "UNKNOWN",
    [0x01] = "SDC",
    [0x02] = "LGD",
    [0x03] = "BOE",
}

-- Panel Bus & Address Define
local TOUCH_EEPROM_I2C_BUS = 3
local TOUCH_EEPROM_I2C_ADDRESS = 0x51
local PANEL_ID_VENDOR_OFFSET = 0xEB9
local PANEL_ID_CONFIG_OFFSET = 0xEBA
local Front_ID, Back_ID, Device_ID

-- Pmu Ovp Check
function PmuOvpCheckPre()

    local RegisterOutput, ResultTemp

    -- Select pmu
    Shell("reg select pmu")

    -- Read reg 0x1000
    Shell("reg read 0x1000 1")

    RegisterOutput = string.match(Last.Output,"0x%x+%s*=>%s*(0x%x+)")
    ResultTemp = bit32.band(RegisterOutput, 0x10)

    -- Report Data to station
    QT_ReportItemTestResult("PMUOverVoltageCheck", "PMU_OVP_Check_pre", ResultTemp)

end

function Cpmu_Device_ID()

   Shell("camisp --find")
   Shell("reg select cpmu")
   Shell("reg read 0x4020 1")
   -- match Cpmu Back ID
   Back_ID = Last.Output:match("=> 0x(%x+)")

   Shell("reg read 0x4024 1")
   -- match Cpmu Front ID
   Front_ID = Last.Output:match("=> (0x%x+)")

   -- Get Cpmu Device ID
   if (Front_ID ~= nil) and (Back_ID ~= nil) then
      Device_ID = Front_ID .. Back_ID
   else
      Device_ID = nil
      PrintString("Error!Cpmu Device Front ID or Back ID is a nil value.")
   end

   -- Report Data to station
   QT_ReportItemTestResult("CpmuDeviceID", "Cpmu_Device_ID", Device_ID)

   if ProductName == "D83" or ProductName == "D84" then
      Shell("reg select cpmu2")
      Shell("reg read 0x4020 1")
      -- match Cpmu2 Back ID
      Back_ID = Last.Output:match("=> 0x(%x+)")

      Shell("reg read 0x4024 1")
      -- match Cpmu2 Front ID
      Front_ID = Last.Output:match("=> (0x%x+)")

      -- Get Cpmu2 Device ID
      if (Front_ID ~= nil) and (Back_ID ~= nil) then
         Device_ID = Front_ID .. Back_ID
      else
         Device_ID = nil
         PrintString("Error!Cpmu2 Device Front ID or Back ID is a nil value.")
      end

      QT_ReportItemTestResult("CpmuDeviceID", "Cpmu2_Device_ID", Device_ID)
   end

   Shell("camisp --exit")

end

-- OV Monitor detected
function OvEventRpf0()

    local ErrorCode, OvResult, TriggerValue

    -- Read OvMonitor.log file
    Shell("cat Logs:\\MobileMediaFactoryLogs\\LogCollector\\FactoryDebug\\OvMonitor.log")

    -- Checking the OV trigger value
    TriggerValue = tonumber(string.match(Last.Output, "Value%s-=%s-([%d]+)"))

    -- Report Data to station
    QT_ReportItemTestResult("PMUInfo", "OV_EVENT_RPF0", TriggerValue)

end

-- Soc Type Check
function SocTypeCheck()

    local SocRevision, DramMemVendor
    --This command only used on D83/D84
    if ProductName == "D83" or ProductName == "D84" then
        Shell("charge --set 500")
    end

    -- soc Property List
    Shell("soc -p")

    -- Soc Revision List
    SocRevision = string.match(Last.Output, "revision:%s+(%a+%d+)")

    -- Report Data to station
    QT_ReportItemTestResult("PMUInfo", "Soc_Type", SocRevision)

    -- Dram Memory Vendor List
    DramMemVendor = string.match(Last.Output, "dram%-memory%-vendor:%s-([%w]+)")

    -- Report Data to station
    QT_ReportItemTestResult("PMUInfo", "Dram_Memory_Vendor", DramMemVendor)

end

-- Soc Leakage Bin Check
function SocLeakageBin()

    local SocIoLeakage

    Shell ("soc -l")

    SocIoLeakage = tonumber(string.match(Last.Output,"soc%-io%-leakage%-bin%-fuse:%s-([%d]+)"))
    for i, SocLeakage in ipairs(gSOCLeakageBin) do
        if (SocIoLeakage >= SocLeakage.Min) and (SocIoLeakage <= SocLeakage.Max) then
            -- Report Data to station
            QT_ReportItemTestResult("PMUInfo", "SOC_LEAKAGE_BIN", SocLeakage.Value)
            QT_ReportItemAttribute("SOC_LEAKAGE_BIN", SocLeakage.Value)
            break
        else
            if i == #gSOCLeakageBin then
                -- Report nil to station
                QT_ReportItemTestResult("PMUInfo", "SOC_LEAKAGE_BIN", nil)
                QT_ReportItemAttribute("SOC_LEAKAGE_BIN", nil)
            end
        end
    end
end

-- Buck Check
local function BuckCheck()

    local MatchStr, Measured, TestResult, BuckCheckTemp, BuckCheckValueTemp
    local SubBucksCheckBuckNumMax = 14

    Shell ("pmu --execute buckcheck 5 -c 64")
    PmuBuck5Output = Last.Output

    for i = 1, SubBucksCheckBuckNumMax do
        MatchStr = string.format("buck%d:([^%%c]*)", i - 1)
        Check = string.match(PmuBuck5Output, MatchStr)

        BuckCheckTemp = "BuckCheck" .. tonumber(i-1)
        BuckCheckValueTemp = BuckCheckTemp .. "_Value"

        if Check ~= nil then
            TestResult = string.match(Check, "%% : ([%d%a]+)")
            Measured = tonumber(string.match(Check, "measured ([%-%d%a%.]+) mV"))
        else
            PrintString(string.format("Failed to get buck%d", i-1))
            TestResult = nil
            Measured = nil
        end
        -- Report Data to station
        QT_ReportItemTestResult("PMUBuckCheck", BuckCheckTemp, TestResult)
        QT_ReportItemTestResult("PMUBuckCheck", BuckCheckValueTemp, Measured)

    end
end

-- Soc Perfstate Setting
local function SocPerfstateSet()

    local CpuVoltage, GpuVoltage, SoCVoltage
    --D83/D84 Soc Perfstate Setting
    if ProductName == "D83" or ProductName == "D84" then
        Shell ("soc -p get-perf-state")
        Shell ("pmu --execute set --ldo 10 --on")
        Shell ("pmu --execute set --buck 9 --on --vol 1050")
        Shell ('soc -s "perfstate cpu 0"')
        Shell ('soc -s "perfstate gpu 1"')
    --D37/D38 Soc Perfstate Setting
    elseif ProductName == "D37" or ProductName == "D38" then
        Shell ('soc -s "perfstate cpu 5"')
        Shell ('soc -s "perfstate gpu 1"')
        Shell ('soc -s "perfstate soc 1"')
        Shell ('soc -s "perfstate ave 0"')
    end
    Shell ("soc -p get-perf-state")

    -- Report Data to station
    CpuVoltage = tonumber(string.match(Last.Output,"Cpu%s-Voltage%s-:%s-(%d+)"))
    QT_ReportItemTestResult("PMUInfo", "Cpu_Voltage", CpuVoltage)

    -- Report Data to station
    GpuVoltage = tonumber(string.match(Last.Output,"Gpu%s-Voltage%s-:%s-(%d+)"))
    QT_ReportItemTestResult("PMUInfo", "Gpu_Voltage", GpuVoltage)

    -- Report Data to station
    SoCVoltage = tonumber(string.match(Last.Output,"SoC%s-Voltage%s-:%s-(%d+)"))
    QT_ReportItemTestResult("PMUInfo", "SoC_Voltage", SoCVoltage)

end

-- Soc Perfstate Setting and Buck check, need EE to confirm whether the test order of the two functions D83/D84 and D37/D38 is consistent.
function SocPerfstateSetBuckCheck()

    if ProductName == "D83" or ProductName == "D84" then

        BuckCheck()
        SocPerfstateSet()

    elseif ProductName == "D37" or ProductName == "D38" then

        SocPerfstateSet()
        BuckCheck()
    end
end

-- PMU ADC Init
local function PmuADCInit()

    Shell ("baseband --off")
    Shell ("wifi --off")
    Shell ("bluetooth --off")
    --This command only used on D37/D38
    if ProductName == "D37" or ProductName == "D38" then
        Shell ("boardrev")
    end
    Shell ("camisp --find")
    --This command only used on D83/D84
    if ProductName == "D83" or ProductName == "D84" then
        Shell ("reg select cpmu")
    end
    Shell ("camisp --method powerdevice on 0x00FFFFFF")
    Shell ("camisp --method powerdevice on 0x01FFFFFF")
    Shell ("camisp --method powerdevice on 0x02FFFFFF")
    Shell ("camisp --method powerdevice on 0x03FFFFFF")
    Shell ("camisp --method powerdevice on 0x04FFFFFF")
    Shell ("camisp --method powerdevice on 0x05FFFFFF")
    Shell ("touch --on")
    Shell ('touch --set_report "0xf3 0x3a"')
    Shell ("audio --reset")
    --This command only used on D37/D38
    if ProductName == "D37" or ProductName == "D38" then
        Shell ("device -k arrow -e power_off")
    end
    Shell ("device -k arrow -e power_on")
    Shell ("device -k arrow -e reset")
    --This command only used on D83/D84
    if ProductName == "D83" or ProductName == "D84" then
        Shell ("device -k arrow -e power_on")
    end
    Shell ("device -k arrow -e load_firmware")
    Shell ("stockholm --pick primary")
    Shell ("stockholm --on")
    Shell ("stockholm --init")
    Shell ("charge --set 0")
    --This command only used on D37/D38
    if ProductName == "D37" or ProductName == "D38" then
        Shell ("pmu --execute set --ldo 10 --on")
    end
    Shell ("egpio --pick cpmu --pin 4 --write 0")
    Shell ("wait 200")

end

-- PMU ADC CleanUp
local function PmuAdcCleanUp()
    --This command only used on D83/D84
    if ProductName == "D83" or ProductName == "D84" then
        Shell ("device -k arrow -e power_off")
    end
    Shell ("touch --off")
    Shell ("camisp --exit")
    Shell ("audio --turnoff")
    Shell ("stockholm --off")
    Shell ('soc -s "perfstate gpu 0"')

end

-- Get Panel Vendor From Touch EEprom
local function GetPanelVendorFromTouchEeprom()
    Shell("i2c -z 2 -d "..TOUCH_EEPROM_I2C_BUS.." "..TOUCH_EEPROM_I2C_ADDRESS.." "..PANEL_ID_VENDOR_OFFSET.." 1")
    local PanelOutPutValue = tonumber(Last.Output:match("Data:  (0x%d+)"))
    local PanelIDVendor = PanelIDVendorLUT[PanelOutPutValue]
    return PanelIDVendor
end

-- Get the Test item table and then Parse the data according the test name in the item table
-- @parameter InputData : pmu read adc command output
-- @parameter InputItemName : the test item name of PMUAdc related items defined in PmuTestItems.Include PMUAdcIldo16,PMUAdcIldo4,PMUAdcUsbPD,PMUAdcAll
local function PmuAdcDataCheck(InputData, InputItemName)
    -- Get the test item table according to the item name
    local TestTableAdc = GetTestItemTableFun(InputItemName)

    local Sum = 0
    local Time = 0
    local GNDOffSetValue = nil

    if InputItemName == "PMUAdcAll" then
        -- According to ERS, we should pirnt out GND_Offset value in pmu add read all command
        GNDOffSetValue = GNDOffSetTable[ProductName]
        if GNDOffSetValue == nil then
            PrintString("Failed to get data from GNDOffSetTable")
            QT_ReportItemTestResult(InputItemName, "GND_Offset", nil)
        end

        -- According to ERS, different ddrs have different limits for buck4 on D37/D38 platforms
        -- According to ddr's vendor, select correct test spec then insert into 'PMUAdcAll' table
        if ProductName == "D37" or ProductName == "D38" then
            local DramMemVendor
            -- soc Property List
            Shell("soc -p")
            -- Dram Memory Vendor List
            DramMemVendor = string.match(Last.Output, "dram%-memory%-vendor:%s-([%w]+)")
            local BuckDdrTestName = "buck4_pp1v1_vdd2h_ddr_s2_" .. DramMemVendor
            local BuckAllDdrTestItems = GetTestItemTableFun("PMUAdcAllBuckDdrVendor")
            for _, BuckDdrTestSpec in pairs(BuckAllDdrTestItems) do
                if BuckDdrTestName == BuckDdrTestSpec.Name then
                    table.insert(TestTableAdc, 37, BuckDdrTestSpec)
                    break
                end
            end
        end

        -- According to ERS, different panels have different limits for buck9
        -- According to panel's vendor, select correct test spec then insert into 'PMUAdcAll' table
        local PanelIDVendor = GetPanelVendorFromTouchEeprom()
        local BuckPanelTestName = "buck9_pp1vx_display_s2_" .. PanelIDVendor
        local BuckAllPanelTestItems = GetTestItemTableFun("PMUAdcAllBuckPanelVendor")
        for _, BuckPanelTestSpec in pairs(BuckAllPanelTestItems) do
            if BuckPanelTestName == BuckPanelTestSpec.Name then
                table.insert(TestTableAdc, BuckPanelTestSpec)
                break
            end
        end

    end

    for key, entry in pairs(TestTableAdc) do
        local Name = entry.Name
        local  Value = tonumber(string.match(InputData, entry.pattern))
        -- Report Data to station
        QT_ReportItemTestResult(InputItemName, Name, Value)

        -- Get GND_Offset value
        if GNDOffSetValue ~= nil then
            for _, GNDOffSetTableName in pairs(GNDOffSetValue) do
                if GNDOffSetTableName == entry.Name then
                    Sum = Sum + Value
                    Time = Time + 1
                end
            end
        end
    end

    -- Print GND_Offset value for PMUAdcAll
    if GNDOffSetValue ~= nil then
        if (Time == #GNDOffSetValue) then
            QT_ReportItemTestResult("PMUInfo", "GND_Offset", Sum/Time)
        else
            QT_ReportItemTestResult("PMUInfo", "GND_Offset", nil)
            PrintString("Failed to calculate GND Offset value")
        end

    end

end

-- PMU ADC
function PmuAdc()

    local PmuReadadcIldo16Output, PmuReadadcAllOutput, PmuReadadcIldo4Output, ChargeBrickidOutput

    -- Init Pmu Adc
    PmuADCInit()

    pcall (Shell, "event -s enter-bg-quiesce")
    pcall (Shell, "pmu --readadc ildo16 --avg 10")
    PmuReadadcIldo16Output = Last.Output
    pcall (Shell, "event -s leave-bg-quiesce")
    PmuAdcDataCheck(PmuReadadcIldo16Output, "PMUAdcIldo16")

    pcall (Shell, "event -s enter-bg-quiesce")
    pcall (Shell, "pmu --readadc all --avg 4")
    PmuReadadcAllOutput = Last.Output
    pcall (Shell, "event -s leave-bg-quiesce")
    PmuAdcDataCheck(PmuReadadcAllOutput, "PMUAdcAll")

    pcall (Shell, "event -s enter-bg-quiesce")
    pcall (Shell, "pmu --readadc ildo4 --stats 64")
    PmuReadadcIldo4Output = Last.Output
    pcall (Shell, "event -s leave-bg-quiesce")
    PmuAdcDataCheck(PmuReadadcIldo4Output, "PMUAdcIldo4")

    pcall (Shell, "event -s enter-bg-quiesce")
    pcall (Shell, "charge --brickid")
    ChargeBrickidOutput = Last.Output
    pcall (Shell, "event -s leave-bg-quiesce")
    PmuAdcDataCheck(ChargeBrickidOutput, "PMUAdcUsbPD")

    --Clean Up Pmu Adc
    PmuAdcCleanUp()

end