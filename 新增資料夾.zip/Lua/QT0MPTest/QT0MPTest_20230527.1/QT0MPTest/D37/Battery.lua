---------------------------------------------------------------------------
-- BatteryTestSuite. 
-- rdar://107923433 (D37 QT0 MP Battery related test coverage smokey bring up)
-- rdar://105820673 (D83 QT0 MP Battery related test coverage smokey bring up)
-- This file contains Battery related tests, structures and functions.
require("BatteryERS"..PlatformInfo("PlatformName"))

local BatteryPropertyInfoList = {
    Cell_ID_Check              = {Pattern = "%s+cell%-id: \"(%d+)",                 Value = nil, OutputType = "String",},
    Cell_ID                    = {Pattern = "%s+cell%-id: \"(%d+)",                 Value = nil, OutputType = "Number",},
    Pack_EEEE_Code             = {Pattern = "%s*pack%-sn: \"(%w+)",                 Value = nil, OutputType = "String",},
    GG_Type                    = {Pattern = "%s+device%-name: \"(%a+)",             Value = nil, OutputType = "String",},
    Lifetime_Min_Voltage       = {Pattern = "%s+lt%-min%-voltage: \"(%d+.%d)",      Value = nil, OutputType = "Number",},
    Lifetime_Max_Voltage       = {Pattern = "%s+lt%-max%-voltage: \"(%d+.%d)",      Value = nil, OutputType = "Number",},
    Battery_Present            = {Pattern = "%s+voltage: \"(%d+)",                  Value = nil, OutputType = "Number",},
    Current                    = {Pattern = "%s+current: \"(%-*%d+)",               Value = nil, OutputType = "Number",},
    BMF_Firmware_Version_Check = {Pattern = "%s+fw%-version: \"(%d+)",              Value = nil, OutputType = "Number",},
    BMF_Firmware_Version       = {Pattern = "%s+fw%-version: \"(%d+)",              Value = nil, OutputType = "Number",},
    Config_ID_Check            = {Pattern = "%s+config%-id: \"(%d+)",               Value = nil, OutputType = "Number",},
    Config_ID                  = {Pattern = "%s+config%-id: \"(%d+)",               Value = nil, OutputType = "Number",},
    DNVD1_Version_Check        = {Pattern = "dnvd%-sector1%-id: \"(%d+)",           Value = nil, OutputType = "Number",},
    DNVD1_Version              = {Pattern = "dnvd%-sector1%-id: \"(%d+)",           Value = nil, OutputType = "Number",},
    DNVD2_Version_Check        = {Pattern = "dnvd%-sector2%-id: \"(%d+)",           Value = nil, OutputType = "Number",},
    DNVD2_Version              = {Pattern = "dnvd%-sector2%-id: \"(%d+)",           Value = nil, OutputType = "Number",},
    Lifetime_Min_Temp          = {Pattern = "lt%-min%-temperature: \"(%-*%d+.%d+)", Value = nil, OutputType = "Number",},
    Lifetime_Max_Temp          = {Pattern = "lt%-max%-temperature: \"(%-*%d+.%d+)", Value = nil, OutputType = "Number",},
    Remaining_Capacity         = {Pattern = "remaining%-capacity: \"(%d+)",         Value = nil, OutputType = "Number",},
    Cycle_Count                = {Pattern = "cycle%-count: \"(%d+)",                Value = nil, OutputType = "Number",},
    Qmax_Capacity              = {Pattern = "qmax%-capacity: \"(%d+)",              Value = nil, OutputType = "Number",},
    Design_Capacity            = {Pattern = "design%-capacity: \"(%d+)",            Value = nil, OutputType = "Number",},
    Nominal_Capacity           = {Pattern = "nominal%-capacity: \"(%d+)",           Value = nil, OutputType = "Number",},
    Charge_Percentage          = {Pattern = "charge%-percentage: \"(%d+)",          Value = nil, OutputType = "Number",},
}

-- Log the test paramter to PDCA file and console
local function PrintResult(TestName, SubList)
    if SubList.OutputType == "String" then
        QT_ReportItemTestResult("BatteryPropertyInfo", TestName, SubList.Value)
    end
    if SubList.OutputType == "Number" then
        QT_ReportItemTestResult("BatteryPropertyInfo", TestName, tonumber(SubList.Value))
    end
end

-- Update Battery Pack_EEEE_Code, Config_ID_Check, DNVD1_Version_Check, DNVD2_Version_Check limits based on CellID refered ERS table
local function UpdateBatPropInfoBasedOnERS(BatERSTab)
    for key,value in pairs(BatERSTab) do
       for _,SubList in pairs(GetTestItemTableFun("BatteryPropertyInfo")) do
            if key == SubList.Name then
                if SubList.SpecType == "Range" then
                    SubList.LowerLimit = value
                    SubList.UpperLimit = value
                elseif SubList.SpecType == "Equal" then
                    for _,v in pairs(value) do
                        table.insert(SubList.EqualTable, v)
                    end
                end
                break
            end
        end
    end
end

local function ReturnCycleCountIndex(CycleCount)
    local index
    if tonumber(CycleCount) < 2 then
        index = 1
    else
        index = 2
    end
    return index
end

local function UpdateLimitBaseOnCycleCount(BatteryTestItem, TestItemName, LimitList)
    for _,v in pairs(GetBatteryTestItem(BatteryTestItem)) do
        if v.Name == TestItemName then
            v.LowerLimit = LimitList.LowerLimit
            v.UpperLimit = LimitList.UpperLimit
            break
        end
    end
end

-- Item51: Battery_Property_Info
function BatteryPropertyInfo()
    Shell("device -k GasGauge -p")

    local index = ReturnCycleCountIndex(Last.Output:match("cycle%-count: \"(%d+)"))
    UpdateLimitBaseOnCycleCount("BatteryPropertyInfo", "Qmax_Capacity", GetQmaxCheck(index))
    UpdateBatPropInfoBasedOnERS(GetBatteryDataList(Last.Output:match("%s+cell%-id: \"(%d+)")))

    for TestName,SubList in pairs(BatteryPropertyInfoList) do
        SubList.Value = string.match(Last.Output, SubList.Pattern)
        if TestName == "Pack_EEEE_Code" then
            SubList.Value = string.sub(SubList.Value, -7)
        end
        PrintResult(TestName, SubList)
    end
    QT_ReportItemAttribute("BATT_FW_VERSION", BatteryPropertyInfoList["BMF_Firmware_Version"].Value)
end

-- Item54: Battery_WRA
function BatteryWRA()
    Shell("smc fread BR0W")
    
    local index = ReturnCycleCountIndex(BatteryPropertyInfoList["Cycle_Count"].Value)
    UpdateLimitBaseOnCycleCount("BatteryWRA", "WRA", GetWRaCheck(index))
    QT_ReportItemTestResult("BatteryWRA", "WRA", tonumber(Last.Output:match("BR0W = (%d+)")))
end

-- Item55: Battery_Cell_Vendor
function BatteryCellVendor()
    local CellVendor, PackConfig
    local CellIDTemp = BatteryPropertyInfoList["Cell_ID"].Value
    PackConfig = GetBatteryDataList(CellIDTemp).PackConfig
    CellVendor = GetBatteryDataList(CellIDTemp).CellVendor
    QT_ReportItemTestResult("BatteryCellVendor", "Cell_Vendor", CellVendor)
    QT_ReportItemTestResult("BatteryCellVendor", "Pack_Config", PackConfig)
end

-- Item56: Veridian_Data_Check
function VeridianDataCheck()
    local VeridianDataCheckTemp = ""
    
    Shell("i2c -x -d 10 0xb 0xA6 33 multiple")
    for Data in string.gmatch(Last.Output, "%d+%w+:%s+([%w ]+)%c+") do
        VeridianDataCheckTemp = VeridianDataCheckTemp..Data
    end
    VeridianDataCheck = string.gsub(VeridianDataCheckTemp, '^[%s]*([^%s].*[^%s])[%s]*$', "%1")
    QT_ReportItemTestResult("VeridianDataCheck", "Veridian_Data_Check", VeridianDataCheck)
end