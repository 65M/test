-- Compass/Compass2.
-- Compass/Compass2 Related Functions and Tests.

-- rdar://96808021 (D37/D8x Jarvis FATP ERS Tracking)
local ProdName = PlatformInfo("PlatformName")
gRotationMatrix = {
    ["D83"] = {
        { 0.4674, -0.8841, 0 },
        { 0.8841, 0.4674,  0 },
        {      0,      0,  1 },
    },
    ["D84"] = {
        { 0.4681, -0.8837, 0 },
        { 0.8837,  0.4681, 0 },
        {      0,       0, 1 },
    },
    ["D37"] = {
        { 0.8506, -0.5258, 0 },
        { -0.5258, 0.8506, 0 },
        {      0,       0, -1 },
    },
    ["D38"] = {
        { -0.7344, -0.6787, 0 },
        { -0.6787, 0.7344, 0 },
        {      0,       0, -1 },
    },
}

-- Verify Compass type
function CompassType()
    Shell("sensor --listsensors")
end

-- Compass connection test
function CompassConnectCheck()
    local ConnectCheck = ""

    Shell("sensor --sel compass --init")
    Shell("sensor --sel compass --exectest remag")
    Shell("sensor --sel compass --conntest")

    ConnectCheck = Last.Output:match("test%-result:%s*(%w+)")

    QT_ReportItemTestResult("CompassTestSuite", "Compass_Connect_Test", ConnectCheck)
end

-- Check Compass Chip ID
function CompassChipID()
    local ChipID = ""

    Shell("sensor --sel compass --get chip_id")
    ChipID = Last.Output:match("chip_id = 0x(%d+)")

    QT_ReportItemTestResult("CompassTestSuite", "Compass_ID_Magpie", ChipID)
end

-- Read and print the Compass Register
function CompassRegisterTest()
    Shell("sensorreg --sel compass --read 0x00 17")
    for RegName, RegValue in Last.Output:gmatch("0x(%w+)%s*=%s*0x(%w+)") do
        QT_ReportItemTestResult("CompassTestSuite", "Compass_Register_0x" .. RegName, tonumber(RegValue, 16))
    end
end

-- Jarvis(Compass2) connection test, ChipID and RevID checking
function JarvisConnectCheck()
    local MaguariConfiguaration = ""
    local JarvisChipID = 0
    local JarvisRevID = 0

    if (ProdName == "D37") or (ProdName == "D38") then
        Shell("sensor --listsensors")
        MaguariConfiguaration = Last.Output:match("Description: (%u*)%s%w*%sCompass%s%(Maguari%)")
        QT_ReportItemTestResult("JarvisTest", "Maguari_Configuaration", MaguariConfiguaration)

        Shell("sensorreg -s compass2 -r 0x01")
        JarvisChipID = Last.Output:match("0x01 = 0x(%w+)")
        QT_ReportItemTestResult("JarvisTest", "QT_Jarvis_ChipID", tonumber(JarvisChipID, 16))

        Shell("sensorreg -s compass2 -r 0x02")
        JarvisRevID = Last.Output:match("0x02 = 0x(%w+)")
        QT_ReportItemTestResult("JarvisTest", "QT_Jarvis_RevID", tonumber(JarvisRevID, 16))

        Shell("sensor --sel compass2 --init")
        Shell("sensor --sel compass2 --conntest")
    end
end

-- Jarvis(Compass2) related test
function JarvisTest()
    local JarvisODR = 0
    local Temperature = 0
    local RawAvg = {}
    local JarvisAvg = {}
    local StdDev = {}
    local RotationMatrix = gRotationMatrix[ProdName]

    if (ProdName == "D83") or (ProdName == "D84") then
        Shell("sensor --sel compass2 --init")
    end

    -- Capture 100 samples along with stats
    Shell("sensor --sel compass2 --set rate 100 --sample 100 --stats")

    JarvisODR = tonumber(Last.Output:match("calculated odr:%s*([%.%d]+)%s*Hz"))
    QT_ReportItemTestResult("JarvisTest", "QT_Jarvis_ODR", JarvisODR)

    RawAvg.X, RawAvg.Y, RawAvg.Z, Temperature = Last.Output:match('average:%s*X = (-?%d+.%d+), Y = (-?%d+.%d+), Z = (-?%d+.%d+), T = (-?%d+.%d+)')
    StdDev.X, StdDev.Y, StdDev.Z = Last.Output:match('std%-dev:%s*X = (-?%d+.%d+), Y = (-?%d+.%d+), Z = (-?%d+.%d+)')

    -- Matrix multiplication of RotationMatrix * [RawAvgX, RawAvgY, RawAvgZ]:
    JarvisAvg.X = RotationMatrix[1][1] * tonumber(RawAvg.X) +
                  RotationMatrix[1][2] * tonumber(RawAvg.Y) +
                  RotationMatrix[1][3] * tonumber(RawAvg.Z)
    JarvisAvg.Y = RotationMatrix[2][1] * tonumber(RawAvg.X) +
                  RotationMatrix[2][2] * tonumber(RawAvg.Y) +
                  RotationMatrix[2][3] * tonumber(RawAvg.Z)
    JarvisAvg.Z = RotationMatrix[3][1] * tonumber(RawAvg.X) +
                  RotationMatrix[3][2] * tonumber(RawAvg.Y) +
                  RotationMatrix[3][3] * tonumber(RawAvg.Z)

    -- Calculate magnitude:
    JarvisAvgBm = math.sqrt(math.pow(tonumber(JarvisAvg.X),2) + math.pow(tonumber(JarvisAvg.Y),2) + math.pow(tonumber(JarvisAvg.Z),2))
    
    QT_ReportItemTestResult("JarvisTest", "QT_Jarvis_Average_X", tonumber(JarvisAvg.X))
    QT_ReportItemTestResult("JarvisTest", "QT_Jarvis_Average_Y", tonumber(JarvisAvg.Y))
    QT_ReportItemTestResult("JarvisTest", "QT_Jarvis_Average_Z", tonumber(JarvisAvg.Z))
    QT_ReportItemTestResult("JarvisTest", "QT_Jarvis_Average_Bm", JarvisAvgBm)
    QT_ReportItemTestResult("JarvisTest", "QT_Jarvis_Temp", tonumber(Temperature))
    QT_ReportItemTestResult("JarvisTest", "QT_Jarvis_Std_X", tonumber(StdDev.X))
    QT_ReportItemTestResult("JarvisTest", "QT_Jarvis_Std_Y", tonumber(StdDev.Y))
    QT_ReportItemTestResult("JarvisTest", "QT_Jarvis_Std_Z", tonumber(StdDev.Z))
end