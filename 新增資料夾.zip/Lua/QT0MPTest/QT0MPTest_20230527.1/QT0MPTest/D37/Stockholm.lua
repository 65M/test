---------------------------------------------------------------------------
-- Stockholm.
-- This file contains NFC releted tests.

--Item52: SH_NFC2_Fury_Test
function SHNFC2FuryTest()
    Shell ("stockholm --pick secondary")
    Shell("stockholm --on")
    Shell("stockholm --init")
    Shell("stockholm --properties hardware-version")

    QT_ReportItemTestResult("StockholmInfo", "SH_NFC2_Fury_Test", Last.Output:match("hardware%-version:%s*(%a+)"))

    Shell("stockholm --off")
end

--Item53: Stockholm_Firmware_Check
function StockholmFirmwareCheck()
    Shell("stockholm --pick primary")
    Shell("stockholm --on")
    Shell("stockholm --init")
    Shell("stockholm --properties")

    QT_ReportItemTestResult("StockholmInfo", "Stockholm_Firmware_Check", Last.Output:match("OK"))
end

--Item54: Stockholm_LowPower_Check
function StockholmLowPowerCheck()
    local DataCheck,DataDoubleCheck

    Shell("stockholm --send_cmd \"20 03 03 01 A0 FC\"")
    DataCheck = Last.Output:match("OK")
    Shell("stockholm --send_cmd \"20 03 03 01 A0 07\"")
    DataDoubleCheck =Last.Output:match("OK")

    QT_ReportItemTestResult("StockholmInfo", "Stockholm_Low_Power_Check", DataCheck.."_"..DataDoubleCheck)

    Shell("stockholm --off")
end
