---------------------------------------------------------------------------
-- D83TestItemSpec.
-- Lua file for Spec of QT0 MP TestItem.
local ProductName = PlatformInfo("PlatformName")
require("BatteryERS"..ProductName)
local AllCamNVMMap = require("CameraNVMMap"..ProductName)
local PmuTestItem = require("PmuLimit" .. ProductName)

-- Format of a ’Test' in QT’s test item: Test Name: [Technology Tag | CoverageTag(SubName) | SubSubTestName], eg:Test Name: ["PressureSensor" | "Info" | "Sensor_ID"]
-- AllTestItems :            Include limit specs of QT test items
-- @descript                 Use this table to define all the QT test name info and it's limit spec
-- @element Name :           Unique identifier for a test of QT item in script,it is the input of parameter ‘TestName’ in QT_ReportItemTestResult(TestItemName, TestName, Value)
--                           If SubSubTestName of AllTestItems is not set or is nil, will take it as QT's SubSubTestName，see QT_ReportItemTestResult()
-- @element SubName :        It is CoverageTag(SubName) of QT.This element can not be nil value.
-- @element SubSubTestName : It is SubSubTestName of QT.Default we don’t need to set this.When it is nil value,will take the value of ‘Name’ as QT's SubSubTestName
--                           So,if want to change QT's SubSubTestName, we can just set/modify this element and we don't need to update element 'Name'.
-- @element SpecType:        According to QT's spec type, have 4 types，about it's limit check,we can see QT_ReportItemTestResult()
--      Range:     value is digital, can set the element Units, LowerLimit, UpperLimit
--      Length:    value is digital, limit spec is set with EqualTable.
--      String:    value is string, no limit to check(if input value is nil, QT_ReportItemTestResult() will report limit check failure）
--      Equal:     value is string, limit spec is set with EqualTable
--      MatchFail: value is string, limit spec is set with EqualTable, if input value match with the value in EqualTable,
--                 QT_ReportItemTestResult() will report over limit failure
local AllTestItems = {

    PressureTestSuite = {
        {Name = "Pressure_Connect_Test",   SubName = "ConnectivityTest",     SpecType = "Range",    Units = nil,    LowerLimit = 1,         UpperLimit = 1,         EqualTable = nil,},
        {Name = "Pressure_Vendor_Name",    SubName = "Info",                 SpecType = "String",   Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
        {Name = "Sensor_ID",               SubName = "Info",                 SpecType = "Range",    Units = nil,    LowerLimit = 8.0,       UpperLimit = 8.0,       EqualTable = nil,},
        {Name = "press_average",           SubName = "SensorData",           SpecType = "Range",    Units = nil,    LowerLimit = 90000,     UpperLimit = 110000,    EqualTable = nil,},
        {Name = "press_max",               SubName = "SensorData",           SpecType = "Range",    Units = nil,    LowerLimit = 90000,     UpperLimit = 110000,    EqualTable = nil,},
        {Name = "press_min",               SubName = "SensorData",           SpecType = "Range",    Units = nil,    LowerLimit = 90000,     UpperLimit = 110000,    EqualTable = nil,},
        {Name = "range",                   SubName = "SensorData",           SpecType = "Range",    Units = nil,    LowerLimit = 0.001,     UpperLimit = 200,       EqualTable = nil,},
        {Name = "temp_average",            SubName = "SensorData",           SpecType = "Range",    Units = nil,    LowerLimit = 15,        UpperLimit = 45,        EqualTable = nil,},
        {Name = "press_std",               SubName = "SensorData",           SpecType = "Range",    Units = nil,    LowerLimit = 0.001,     UpperLimit = 4,         EqualTable = nil,},
        {Name = "temp_std",                SubName = "SensorData",           SpecType = "Range",    Units = nil,    LowerLimit = 0,         UpperLimit = 0.175,     EqualTable = nil,},
        {Name = "odr",                     SubName = "SensorData",           SpecType = "Range",    Units = nil,    LowerLimit = 27,        UpperLimit = 33,        EqualTable = nil,},
        {Name = "Manu_ID",                 SubName = "Info",                 SpecType = "Range",    Units = nil,    LowerLimit = 228,       UpperLimit = 228,       EqualTable = nil,},
        {Name = "Chip_ID",                 SubName = "Info",                 SpecType = "Range",    Units = nil,    LowerLimit = 52,        UpperLimit = 52,        EqualTable = nil,},
        {Name = "Rev_ID",                  SubName = "Info",                 SpecType = "Range",    Units = nil,    LowerLimit = 0,         UpperLimit = 16,        EqualTable = nil,},
        {Name = "Trim_ID",                 SubName = "Info",                 SpecType = "Range",    Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
        {Name = "MPN_ID",                  SubName = "Info",                 SpecType = "Range",    Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
        {Name = "Pressure_SN",             SubName = "Info",                 SpecType = "String",   Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
        {Name = "ASIC_selfTest_100Kpa",    SubName = "SelfTest",             SpecType = "Range",    Units = nil,    LowerLimit = 95000,     UpperLimit = 105000,    EqualTable = nil,},
        {Name = "ASIC_selfTest_90Kpa",     SubName = "SelfTest",             SpecType = "Range",    Units = nil,    LowerLimit = 85000,     UpperLimit = 95000,     EqualTable = nil,},
        {Name = "ASIC_sensitivity",        SubName = "SelfTest",             SpecType = "Range",    Units = nil,    LowerLimit = -300000,   UpperLimit = 300000,    EqualTable = nil,},
    },

    AudioInfo = {
        {Name = "Sakonnet_ID",       SubName = "Info", SpecType = "Range", Units = nil, LowerLimit = 19, UpperLimit = 19, EqualTable = nil,},
        {Name = "Sakonnet_Revision", SubName = "Info", SpecType = "Range", Units = nil, LowerLimit = 3,  UpperLimit = 3,  EqualTable = nil,},
    },

    PMUOverVoltageCheck = {
        {Name = "PMU_OVP_Check_pre", SubName = "OverVoltageCheck", SpecType = "Range", Units = nil, LowerLimit = 0, UpperLimit = 0, EqualTable = nil,},
    },

    StockholmInfo = {
        {Name = "Stockholm_Low_Power_Check", SubName = "NFC", SpecType = "Equal", Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable ={"OK_OK"}},
        {Name = "SH_NFC2_Fury_Test",         SubName = "NFC", SpecType = "Equal", Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable ={"BA"}},
        {Name = "Stockholm_Firmware_Check",  SubName = "NFC", SpecType = "Equal", Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable ={"OK"}},
    },

    ProxInit = {
        {Name = "INIT_TEST",  SubName = "Initialization", SpecType = "Equal", Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable ={"OK"}},
        {Name = "QT_CONNTEST",  SubName = "ConnectivityTest", SpecType = "Equal", Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable ={"PASS"}},
    },

    ProxModuleSn = {
        {Name = "MODULE_SN",  SubName = "Info", SpecType = "String", Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable =nil},
    },

    ProxNvmDump = {
        {Name = "OTP1_AMBIENT_WINDOW_DURATION",    SubName = "Info", SpecType = "Range", Units = nil, LowerLimit = 7 , UpperLimit = 7 , EqualTable = nil,},
        {Name = "OTP1_RANGING_WINDOW_MULTIPLE",    SubName = "Info", SpecType = "Range", Units = nil, LowerLimit = 1 , UpperLimit = 1 , EqualTable = nil,},
        {Name = "TIMEOUT_OVERALL_PERIOD_CLIP_MSB", SubName = "Info", SpecType = "Range", Units = nil, LowerLimit = 37, UpperLimit = 37, EqualTable = nil,},
        {Name = "BLANKING_TIME_MSB",               SubName = "Info", SpecType = "Range", Units = nil, LowerLimit = 1 , UpperLimit = 1 , EqualTable = nil,},
        {Name = "TIMEOUT_OVERALL_PERIOD_CLIP_LSB", SubName = "Info", SpecType = "Range", Units = nil, LowerLimit = 13, UpperLimit = 13, EqualTable = nil,},
        {Name = "BLANKING_TIME_LSB",               SubName = "Info", SpecType = "Range", Units = nil, LowerLimit = 45, UpperLimit = 45, EqualTable = nil,},
        {Name = "INTEGRATION_THRESHOLD",           SubName = "Info", SpecType = "Range", Units = nil, LowerLimit = 55, UpperLimit = 55, EqualTable = nil,},
        {Name = "OTP_USER_LOCK",                   SubName = "Info", SpecType = "Range", Units = nil, LowerLimit = 3 , UpperLimit = 3 , EqualTable = nil,},
        {Name = "OCP_AVG_TRIP",                    SubName = "Info", SpecType = "Range", Units = nil, LowerLimit = 40, UpperLimit = 49, EqualTable = nil,},
        {Name = "PERSIS_WITHIN_BIST",              SubName = "Info", SpecType = "Range", Units = nil, LowerLimit = 7 , UpperLimit = 7 , EqualTable = nil,},
        {Name = "PERSIS_OVER_MULTIPLE_BIST",       SubName = "Info", SpecType = "Range", Units = nil, LowerLimit = 5 , UpperLimit = 5 , EqualTable = nil,},
        {Name = "VCSEL_PERIOD",                    SubName = "Info", SpecType = "Range", Units = nil, LowerLimit = 2 , UpperLimit = 2 , EqualTable = nil,},
        {Name = "VCSEL_CLK_MODE_OTP",              SubName = "Info", SpecType = "Range", Units = nil, LowerLimit = 2 , UpperLimit = 2 , EqualTable = nil,},
        {Name = "VCSEL_START",                     SubName = "Info", SpecType = "Range", Units = nil, LowerLimit = 5 , UpperLimit = 5 , EqualTable = nil,},
        {Name = "VCSEL_DELAY",                     SubName = "Info", SpecType = "Range", Units = nil, LowerLimit = 0 , UpperLimit = 0 , EqualTable = nil,},
        {Name = "VCSEL_STOP",                      SubName = "Info", SpecType = "Range", Units = nil, LowerLimit = 1 , UpperLimit = 1 , EqualTable = nil,},
        {Name = "OTP0_AMBIENT_WINDOW_DURATION",    SubName = "Info", SpecType = "Range", Units = nil, LowerLimit = 9 , UpperLimit = 9 , EqualTable = nil,},
        {Name = "OTP0_RANGING_WINDOW_MULTIPLE",    SubName = "Info", SpecType = "Range", Units = nil, LowerLimit = 2 , UpperLimit = 2 , EqualTable = nil,},
        {Name = "VCSEL_CLIP",                      SubName = "Info", SpecType = "Range", Units = nil, LowerLimit = 50, UpperLimit = 50, EqualTable = nil,},
        {Name = "BYPASS_LOW_TEMP",                 SubName = "Info", SpecType = "Range", Units = nil, LowerLimit = 0 , UpperLimit = 0 , EqualTable = nil,},
        {Name = "BYPASS_OCP",                      SubName = "Info", SpecType = "Range", Units = nil, LowerLimit = 0 , UpperLimit = 0 , EqualTable = nil,},
        {Name = "BYPASS_WDG",                      SubName = "Info", SpecType = "Range", Units = nil, LowerLimit = 0 , UpperLimit = 0 , EqualTable = nil,},
        {Name = "BYPASS_CC",                       SubName = "Info", SpecType = "Range", Units = nil, LowerLimit = 0 , UpperLimit = 0 , EqualTable = nil,},
        {Name = "AVDD_SW_DISABLE",                 SubName = "Info", SpecType = "Range", Units = nil, LowerLimit = 0 , UpperLimit = 0 , EqualTable = nil,},
        {Name = "OTP_VENDOR_LOCK",                 SubName = "Info", SpecType = "Range", Units = nil, LowerLimit = 3 , UpperLimit = 3 , EqualTable = nil,},
    },

    NandInfo = {
        {Name = "Model_Number",          SubName = "Info", SpecType = "String", Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = nil,},
        {Name = "FW_Revision",           SubName = "Info", SpecType = "String", Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = nil,},
        {Name = "MSP_Revision",          SubName = "Info", SpecType = "String", Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = nil,},
        {Name = "PRODUCTION_FW_VERSION", SubName = "Info", SpecType = "String", Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = nil,},
        {Name = "VENDOR",                SubName = "Info", SpecType = "Equal",  Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = {"WD", "SanDisk", "Sandisk", "Kioxia", "Toshiba", "Samsung", "Hynix"},},
        {Name = "Cell_Type",             SubName = "Info", SpecType = "String", Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = nil,},
        {Name = "Capacity",              SubName = "Info", SpecType = "Equal",  Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = {"128GB", "256GB", "512GB", "1024GB", "1TB"},},
        {Name = "Die_Name",              SubName = "Info", SpecType = "String", Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = nil,},
        {Name = "CHIP_ID",               SubName = "Info", SpecType = "String", Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = nil,},
        {Name = "UID",                   SubName = "Info", SpecType = "Equal",  Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = {"Pass"},},
    },

    NandId = {
        {Name = "ID", SubName = "Info", SpecType = "Equal", Units = nil, LowerLimit = nil, UpperLimit = nil,  EqualTable = {},},
    },

    NandControllerUID = {
        {Name = "Controller_UID", SubName = "Info", SpecType = "String", Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = nil,},
    },

    DisplayTestStuite = {
        {Name = "Read_Panel_ID",                SubName = "Status",              SpecType = "String",   Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = nil,},
        {Name = "LCM_Vendor_Name",              SubName = "Info",                SpecType = "Equal",    Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = {"SDC", "LGD"},},
        {Name = "DIC_Vendor_ID",                SubName = "Info",                SpecType = "Equal",    Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = {},},
        {Name = "Read_Panel_OUI_Decimal_Check", SubName = "Status",              SpecType = "Equal",    Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = {"4346", "4859"},},
        {Name = "Read_Panel_OUI_Decimal",       SubName = "Info",                SpecType = "Range",    Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = nil,},
        {Name = "Read_Touch_SIP_SN",            SubName = "Info",                SpecType = "Length",   Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = {26},},
        {Name = "LCM_MP9_Temp",                 SubName = "Temperature",         SpecType = "Range",    Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = nil,},
        {Name = "LCM_10nit_W51_LL_R_ideal",     SubName = "OpticalMeasurements", SpecType = "Range",    Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = nil,},
        {Name = "LCM_10nit_W51_LL_G_ideal",     SubName = "OpticalMeasurements", SpecType = "Range",    Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = nil,},
        {Name = "LCM_MP9_FFR_Frequency",        SubName = "FrequencyCheck",      SpecType = "Range",    Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = nil,},
        {Name = "LCM_ACVRR",                    SubName = "OpticalMeasurements", SpecType = "Range",    Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = nil,},
        {Name = "PMIC_Version_Check",           SubName = "Info",                SpecType = "Range",    Units = nil, LowerLimit = 97,  UpperLimit = 97,  EqualTable = nil,},
    },

    HiddNouUIOnTime = {
        {Name = "Hidd_Nonui_On_Time_EFI",   SubName = "Status", SpecType = "Range",  Units = nil, LowerLimit = nil, UpperLimit = 288000, EqualTable = nil,},
        {Name = "Hidd_Nonui_On_Time_NonUI", SubName = "Status", SpecType = "Range",  Units = nil, LowerLimit = nil, UpperLimit = 288000, Equaltable = nil,},
        {Name = "CG_ON_TotalTime",          SubName = "Info",   SpecType = "Range",  Units = nil, LowerLimit = nil, UpperLimit = nil,    EqualTable = nil,},
    },

    Front_CAMInfo       =   AllCamNVMMap.Front,
    SphinxTX_CAMInfo    =   AllCamNVMMap.SphinxTX,
    SphinxRX_CAMInfo    =   AllCamNVMMap.SphinxRX,
    Back_CAMInfo        =   AllCamNVMMap.Back,
    Back1_CAMInfo       =   AllCamNVMMap.Back1,
    Back2_CAMInfo       =   AllCamNVMMap.Back2,
    Peridot_CAMInfo     =   AllCamNVMMap.Peridot,
    PMUInfo                   =     PmuTestItem.PMUInfo,
    PMUBuckCheck              =     PmuTestItem.PMUBuckCheck,
    PMUAdcIldo16              =     PmuTestItem.PMUAdcIldo16,
    PMUAdcIldo4               =     PmuTestItem.PMUAdcIldo4,
    PMUAdcUsbPD               =     PmuTestItem.PMUAdcUsbPD,
    PMUAdcAllBuckPanelVendor  =     PmuTestItem.PMUAdcAllBuckPanelVendor,
    PMUAdcAll                 =     PmuTestItem.PMUAdcAll,
    BatteryPropertyInfo = GetBatteryTestItem("BatteryPropertyInfo"),
    BatteryWRA          = GetBatteryTestItem("BatteryWRA"),
    BatteryCellVendor   = GetBatteryTestItem("BatteryCellVendor"),
    VeridianDataCheck   = GetBatteryTestItem("VeridianDataCheck"),

    Accel = {
        {Name = "accel_init",                       SubName = "Initialization",         SpecType = "Range",     Units = nil,    LowerLimit = 0,         UpperLimit = 0,         EqualTable = nil,},
        {Name = "accel2_init",                      SubName = "Initialization",         SpecType = "Range",     Units = nil,    LowerLimit = 0,         UpperLimit = 0,         EqualTable = nil,},
        {Name = "accel_connectivity",               SubName = "ConnectivityTest",       SpecType = "Range",     Units = nil,    LowerLimit = 0,         UpperLimit = 0,         EqualTable = nil,},
        {Name = "accel2_connectivity",              SubName = "ConnectivityTest",       SpecType = "Range",     Units = nil,    LowerLimit = 0,         UpperLimit = 0,         EqualTable = nil,},
        {Name = "accel_selftest",                   SubName = "SensorCheckTest",        SpecType = "Range",     Units = nil,    LowerLimit = 0,         UpperLimit = 0,         EqualTable = nil,},
        {Name = "accel_selftest_sd_x",              SubName = "SensorCheckTest",        SpecType = "Range",     Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
        {Name = "accel_selftest_sd_y",              SubName = "SensorCheckTest",        SpecType = "Range",     Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
        {Name = "accel_selftest_sd_z",              SubName = "SensorCheckTest",        SpecType = "Range",     Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
        {Name = "accel_selftest_bd_x",              SubName = "SensorCheckTest",        SpecType = "Range",     Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
        {Name = "accel_selftest_bd_y",              SubName = "SensorCheckTest",        SpecType = "Range",     Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
        {Name = "accel_selftest_bd_z",              SubName = "SensorCheckTest",        SpecType = "Range",     Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
        {Name = "accel2_selftest",                  SubName = "SensorCheckTest",        SpecType = "Range",     Units = nil,    LowerLimit = 0,         UpperLimit = 0,         EqualTable = nil,},
        {Name = "accel2_selftest_sd_x",             SubName = "SensorCheckTest",        SpecType = "Range",     Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
        {Name = "accel2_selftest_sd_y",             SubName = "SensorCheckTest",        SpecType = "Range",     Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
        {Name = "accel2_selftest_sd_z",             SubName = "SensorCheckTest",        SpecType = "Range",     Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
        {Name = "accel2_selftest_bd_x",             SubName = "SensorCheckTest",        SpecType = "Range",     Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
        {Name = "accel2_selftest_bd_y",             SubName = "SensorCheckTest",        SpecType = "Range",     Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
        {Name = "accel2_selftest_bd_z",             SubName = "SensorCheckTest",        SpecType = "Range",     Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
        {Name = "accel_set_rate",                   SubName = "Initialization",         SpecType = "Range",     Units = nil,    LowerLimit = 0,         UpperLimit = 0,         EqualTable = nil,},
        {Name = "accel_set_bw",                     SubName = "Initialization",         SpecType = "Range",     Units = nil,    LowerLimit = 0,         UpperLimit = 0,         EqualTable = nil,},
        {Name = "accel2_set_bw",                    SubName = "Initialization",         SpecType = "Range",     Units = nil,    LowerLimit = 0,         UpperLimit = 0,         EqualTable = nil,},
        {Name = "accel_set_dymanic_range",          SubName = "Initialization",         SpecType = "Range",     Units = nil,    LowerLimit = 0,         UpperLimit = 0,         EqualTable = nil,},
        {Name = "accel/accel2/gyro_init",           SubName = "Initialization",         SpecType = "Range",     Units = nil,    LowerLimit = 0,         UpperLimit = 0,         EqualTable = nil,},
        {Name = "accel_set_rate_gyro",              SubName = "Initialization",         SpecType = "Range",     Units = nil,    LowerLimit = 0,         UpperLimit = 0,         EqualTable = nil,},
        {Name = "accel2_normal_average_x",          SubName = "Offset",                 SpecType = "Range",     Units = nil,    LowerLimit = -3,        UpperLimit = 3,         EqualTable = nil,},
        {Name = "accel2_normal_average_y",          SubName = "Offset",                 SpecType = "Range",     Units = nil,    LowerLimit = -3,        UpperLimit = 3,         EqualTable = nil,},
        {Name = "accel2_normal_average_z_eSIM",     SubName = "Offset",                 SpecType = "Range",     Units = nil,    LowerLimit = -4,        UpperLimit = 2,         EqualTable = nil,},
        {Name = "accel2_normal_average_z_pSIM",     SubName = "Offset",                 SpecType = "Range",     Units = nil,    LowerLimit = -2,        UpperLimit = 4,         EqualTable = nil,},
        {Name = "accel2_normal_std_x",              SubName = "Noise",                  SpecType = "Range",     Units = nil,    LowerLimit = 0.00001,   UpperLimit = 0.2,       EqualTable = nil,},
        {Name = "accel2_normal_std_y",              SubName = "Noise",                  SpecType = "Range",     Units = nil,    LowerLimit = 0.00001,   UpperLimit = 0.2,       EqualTable = nil,},
        {Name = "accel2_normal_std_z",              SubName = "Noise",                  SpecType = "Range",     Units = nil,    LowerLimit = 0.00001,   UpperLimit = 0.2,       EqualTable = nil,},
        {Name = "accel2_normal_odr",                SubName = "OutputRate",             SpecType = "Range",     Units = nil,    LowerLimit = 2880,      UpperLimit = 3520,      EqualTable = nil,},
        {Name = "accel_normal_average_x",           SubName = "Offset",                 SpecType = "Range",     Units = nil,    LowerLimit = -1.5,      UpperLimit = 1.5,       EqualTable = nil,},
        {Name = "accel_normal_average_y",           SubName = "Offset",                 SpecType = "Range",     Units = nil,    LowerLimit = -1.5,      UpperLimit = 1.5,       EqualTable = nil,},
        {Name = "accel_normal_average_z_eSIM",      SubName = "Offset",                 SpecType = "Range",     Units = nil,    LowerLimit = -1.5,      UpperLimit = 0.5,       EqualTable = nil,},
        {Name = "accel_normal_average_z_pSIM",      SubName = "Offset",                 SpecType = "Range",     Units = nil,    LowerLimit = -0.5,      UpperLimit = 1.5,       EqualTable = nil,},
        {Name = "accel_normal_odr",                 SubName = "OutputRate",             SpecType = "Range",     Units = nil,    LowerLimit = 1440,      UpperLimit = 1760,      EqualTable = nil,},
        {Name = "accel_set_dymanic_range2",         SubName = "Initialization",         SpecType = "Range",     Units = nil,    LowerLimit = 0,         UpperLimit = 0,         EqualTable = nil,},
    },

    Gyro = {
        {Name = "inertial_sensor_serial_id",        SubName = "Info",                   SpecType = "String",    Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,       ToAttribute = true,},
        {Name = "gyro_connectivity",                SubName = "ConnectivityTest",       SpecType = "Range",     Units = nil,    LowerLimit = 0,         UpperLimit = 0,         EqualTable = nil,},
        {Name = "gyro_selftest",                    SubName = "SensorCheckTest",        SpecType = "Range",     Units = nil,    LowerLimit = 0,         UpperLimit = 0,         EqualTable = nil,},
        {Name = "gyro_quad_x",                      SubName = "SensorCheckTest",        SpecType = "Range",     Units = nil,    LowerLimit = -2000,     UpperLimit = 2000,      EqualTable = nil,},
        {Name = "gyro_quad_y",                      SubName = "SensorCheckTest",        SpecType = "Range",     Units = nil,    LowerLimit = -1000,     UpperLimit = 1000,      EqualTable = nil,},
        {Name = "gyro_quad_z",                      SubName = "SensorCheckTest",        SpecType = "Range",     Units = nil,    LowerLimit = -1000,     UpperLimit = 1000,      EqualTable = nil,},
        {Name = "gyro_t2s",                         SubName = "SensorCheckTest",        SpecType = "Range",     Units = nil,    LowerLimit = 0,         UpperLimit = 0,         EqualTable = nil,},
        {Name = "gyro_t2s_cal_x",                   SubName = "SensorCheckTest",        SpecType = "Range",     Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
        {Name = "gyro_t2s_cal_y",                   SubName = "SensorCheckTest",        SpecType = "Range",     Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
        {Name = "gyro_t2s_cal_z",                   SubName = "SensorCheckTest",        SpecType = "Range",     Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
        {Name = "gyro_t2s_qdiff_x",                 SubName = "SensorCheckTest",        SpecType = "Range",     Units = nil,    LowerLimit = 100,       UpperLimit = 325,       EqualTable = nil,},
        {Name = "gyro_t2s_qdiff_y",                 SubName = "SensorCheckTest",        SpecType = "Range",     Units = nil,    LowerLimit = 80,        UpperLimit = 300,       EqualTable = nil,},
        {Name = "gyro_t2s_qdiff_z",                 SubName = "SensorCheckTest",        SpecType = "Range",     Units = nil,    LowerLimit = 180,       UpperLimit = 410,       EqualTable = nil,},
        {Name = "gyro_t2s_refval_x",                SubName = "SensorCheckTest",        SpecType = "Range",     Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
        {Name = "gyro_t2s_refval_y",                SubName = "SensorCheckTest",        SpecType = "Range",     Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
        {Name = "gyro_t2s_refval_z",                SubName = "SensorCheckTest",        SpecType = "Range",     Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
        {Name = "gyro_drive_freq",                  SubName = "DriveFrequency",         SpecType = "Range",     Units = nil,    LowerLimit = 32,        UpperLimit = 37.55,     EqualTable = nil,},
        {Name = "gyro_vcm",                         SubName = "SensorCheckTest",        SpecType = "Range",     Units = nil,    LowerLimit = -0.05,     UpperLimit = 0.05,      EqualTable = nil,},
        {Name = "accel_set_bw_normal",              SubName = "Initialization",         SpecType = "Range",     Units = nil,    LowerLimit = 0,         UpperLimit = 0,         EqualTable = nil,},
        {Name = "accel2_set_bw_normal",             SubName = "Initialization",         SpecType = "Range",     Units = nil,    LowerLimit = 0,         UpperLimit = 0,         EqualTable = nil,},
        {Name = "gyro_set_rate",                    SubName = "Initialization",         SpecType = "Range",     Units = nil,    LowerLimit = 0,         UpperLimit = 0,         EqualTable = nil,},
        {Name = "accel2_fsr",                       SubName = "FullScale",              SpecType = "Range",     Units = nil,    LowerLimit = 256,       UpperLimit = 256,       EqualTable = nil,},
        {Name = "gyro_normal_average_x",            SubName = "Offset",                 SpecType = "Range",     Units = nil,    LowerLimit = -6,        UpperLimit = 6,         EqualTable = nil,},
        {Name = "gyro_normal_average_y",            SubName = "Offset",                 SpecType = "Range",     Units = nil,    LowerLimit = -6,        UpperLimit = 6,         EqualTable = nil,},
        {Name = "gyro_normal_average_z",            SubName = "Offset",                 SpecType = "Range",     Units = nil,    LowerLimit = -6,        UpperLimit = 6,         EqualTable = nil,},
        {Name = "gyro_normal_std_x",                SubName = "Noise",                  SpecType = "Range",     Units = nil,    LowerLimit = 0.00001,   UpperLimit = 3.5,       EqualTable = nil,},
        {Name = "gyro_normal_std_y",                SubName = "Noise",                  SpecType = "Range",     Units = nil,    LowerLimit = 0.00001,   UpperLimit = 3.5,       EqualTable = nil,},
        {Name = "gyro_normal_std_z",                SubName = "Noise",                  SpecType = "Range",     Units = nil,    LowerLimit = 0.00001,   UpperLimit = 3.5,       EqualTable = nil,},
        {Name = "gyro_normal_odr",                  SubName = "OutputRate",             SpecType = "Range",     Units = nil,    LowerLimit = 1440,      UpperLimit = 1760,      EqualTable = nil,},
        {Name = "gyro_normal_temp",                 SubName = "Temperature",            SpecType = "Range",     Units = nil,    LowerLimit = 3,         UpperLimit = 55,        EqualTable = nil,},
    },

    YetiCon = {
        {Name = "Yeti_NTC_Connectivity", SubName = "ConnectivityTest", SpecType = "Range", Units = nil, LowerLimit = 6, UpperLimit = 13, ToAttribute = nil, EqualTable = nil,}
    },

    AlsInfo = {
        {Name = "INIT",            SubName = "Initialization", SpecType = "Equal",  Units = nil, LowerLimit = nil, UpperLimit = nil, ToAttribute = nil, EqualTable = {"OK"},},
        {Name = "ID_Check",        SubName = "Info",           SpecType = "String", Units = nil, LowerLimit = nil, UpperLimit = nil, ToAttribute = nil, EqualTable = nil,},
        {Name = "INT_N",           SubName = "InterruptCheck", SpecType = "Equal",  Units = nil, LowerLimit = nil, UpperLimit = nil, ToAttribute = nil, EqualTable = {"passed"},}
    },

    CompassTestSuite = {
        {Name = "Compass_Connect_Test",    SubName = "ConnectivityTest",    SpecType = "Equal",    Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = {"passed"},},
        {Name = "Compass_ID_Magpie",       SubName = "Info",                SpecType = "Equal",    Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = {"44"},},
        {Name = "Compass_Register_0x00",   SubName = "Registers",           SpecType = "Range",    Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
        {Name = "Compass_Register_0x01",   SubName = "Registers",           SpecType = "Range",    Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
        {Name = "Compass_Register_0x02",   SubName = "Registers",           SpecType = "Range",    Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
        {Name = "Compass_Register_0x03",   SubName = "Registers",           SpecType = "Range",    Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
        {Name = "Compass_Register_0x04",   SubName = "Registers",           SpecType = "Range",    Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
        {Name = "Compass_Register_0x05",   SubName = "Registers",           SpecType = "Range",    Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
        {Name = "Compass_Register_0x06",   SubName = "Registers",           SpecType = "Range",    Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
        {Name = "Compass_Register_0x07",   SubName = "Registers",           SpecType = "Range",    Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
        {Name = "Compass_Register_0x08",   SubName = "Registers",           SpecType = "Range",    Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
        {Name = "Compass_Register_0x09",   SubName = "Registers",           SpecType = "Range",    Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
        {Name = "Compass_Register_0x0A",   SubName = "Registers",           SpecType = "Range",    Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
        {Name = "Compass_Register_0x0B",   SubName = "Registers",           SpecType = "Range",    Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
        {Name = "Compass_Register_0x0C",   SubName = "Registers",           SpecType = "Range",    Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
        {Name = "Compass_Register_0x0D",   SubName = "Registers",           SpecType = "Range",    Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
        {Name = "Compass_Register_0x0E",   SubName = "Registers",           SpecType = "Range",    Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
        {Name = "Compass_Register_0x0F",   SubName = "Registers",           SpecType = "Range",    Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
        {Name = "Compass_Register_0x10",   SubName = "Registers",           SpecType = "Range",    Units = nil,    LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
    }, 

    JarvisTest = {
        {Name = "QT_Jarvis_ODR",           SubName = "SensorData",          SpecType = "Range",    Units = nil,    LowerLimit = 90,        UpperLimit = 110,       EqualTable = nil,},
        {Name = "QT_Jarvis_Average_X",     SubName = "SensorData",          SpecType = "Range",    Units = nil,    LowerLimit = 4840,      UpperLimit = 7640,      EqualTable = nil,},
        {Name = "QT_Jarvis_Average_Y",     SubName = "SensorData",          SpecType = "Range",    Units = nil,    LowerLimit = -5370,     UpperLimit = -2890,     EqualTable = nil,},
        {Name = "QT_Jarvis_Average_Z",     SubName = "SensorData",          SpecType = "Range",    Units = nil,    LowerLimit = -2460,     UpperLimit = -460,      EqualTable = nil,},
        {Name = "QT_Jarvis_Average_Bm",    SubName = "SensorData",          SpecType = "Range",    Units = nil,    LowerLimit = 6010,      UpperLimit = 9210,      EqualTable = nil,},
        {Name = "QT_Jarvis_Temp",          SubName = "SensorData",          SpecType = "Range",    Units = nil,    LowerLimit = 5,         UpperLimit = 55,        EqualTable = nil,},
        {Name = "QT_Jarvis_Std_X",         SubName = "SensorData",          SpecType = "Range",    Units = nil,    LowerLimit = 0,         UpperLimit = 55,        EqualTable = nil,},
        {Name = "QT_Jarvis_Std_Y",         SubName = "SensorData",          SpecType = "Range",    Units = nil,    LowerLimit = 0,         UpperLimit = 55,        EqualTable = nil,},
        {Name = "QT_Jarvis_Std_Z",         SubName = "SensorData",          SpecType = "Range",    Units = nil,    LowerLimit = 0,         UpperLimit = 55,        EqualTable = nil,},
    },

    CpmuDeviceID = {
        {Name = "Cpmu_Device_ID", SubName = "Info", SpecType = "String", Units = nil, LowerLimit = nil, UpperLimit = nil,  EqualTable = nil,},
        {Name = "Cpmu2_Device_ID", SubName = "Info", SpecType = "String", Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = nil,},
    },
}

function GetTestItemTableFun(TestItemName)
    return AllTestItems[TestItemName]
end
