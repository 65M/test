---------------------------------------------------------
-- ALS_Con
-- Tests related to ALS_Con.

require "Common"

-- Power on als
function ALSInit()
    local AlsPower = ""

    Shell "sensor -s als --init"
    AlsPower =string.gsub(Last.Output:match("([^\n]+)[\n]*$"), "^%c*(.-)%c*$", "%1")
    QT_ReportItemTestResult("AlsInfo", "INIT", tostring(AlsPower))
end

-- Get als chip_id1 and report
function ALSIDCheck()
    local AlsChipID = ""

    Shell "sensor --sel als --get chip_id1"
    AlsChipID = Last.Output:match("chip_id1%s*=%s*(%w+)%c")
    QT_ReportItemTestResult("AlsInfo", "ID_Check", AlsChipID)
end

-- Check als conntest and return result
function ALSInterruptCheck()
    local AlsConResult = ""

    Shell "sensor --sel als --conntest"
    AlsConResult = Last.Output:match("test%-result:%s*(%w+)%c")
    QT_ReportItemTestResult("AlsInfo", "INT_N", AlsConResult)
end