require "Common"

local Universal = require "Universal.14A"

local ProductName = PlatformInfo('PlatformName')

local gSensorSelftestMatchTbl = {
    { Name = "selftest_sd_x",     Pattern = "X StdDevValues: ([%d.]+)",       Value = nil },
    { Name = "selftest_sd_y",     Pattern = "Y StdDevValues: ([%d.]+)",       Value = nil },
    { Name = "selftest_sd_z",     Pattern = "Z StdDevValues: ([%d.]+)",       Value = nil },
    { Name = "selftest_bd_x",     Pattern = "X BiteDiffValues: ([%d.]+)",     Value = nil },
    { Name = "selftest_bd_y",     Pattern = "Y BiteDiffValues: ([%d.]+)",     Value = nil },
    { Name = "selftest_bd_z",     Pattern = "Z BiteDiffValues: ([%d.]+)",     Value = nil },
}

local gGyroQuadMatchTbl ={
    { Name = "gyro_quad_x",     Pattern = "X Residual Quadrature output: ([%-?%d.]+)",       Value = nil },
    { Name = "gyro_quad_y",     Pattern = "Y Residual Quadrature output: ([%-?%d.]+)",       Value = nil },
    { Name = "gyro_quad_z",     Pattern = "Z Residual Quadrature output: ([%-?%d.]+)",       Value = nil },
}

local gGyroTrim2sMatchTbl ={
    { Name = "gyro_t2s_cal_x",          Pattern = " - Gyro Cal X = ([%-?%d.]+)",            Value = nil },
    { Name = "gyro_t2s_cal_y",          Pattern = " - Gyro Cal Y = ([%-?%d.]+)",            Value = nil },
    { Name = "gyro_t2s_cal_z",          Pattern = " - Gyro Cal Z = ([%-?%d.]+)",            Value = nil },
    { Name = "gyro_t2s_qdiff_x",        Pattern = " - Gyro Q%-Diff X = ([%d.]+)",           Value = nil },
    { Name = "gyro_t2s_qdiff_y",        Pattern = " - Gyro Q%-Diff Y = ([%d.]+)",           Value = nil },
    { Name = "gyro_t2s_qdiff_z",        Pattern = " - Gyro Q%-Diff Z = ([%d.]+)",           Value = nil },
    { Name = "gyro_t2s_refval_x",       Pattern = " - Gyro RefVal X = ([%d.]+)",            Value = nil },
    { Name = "gyro_t2s_refval_y",       Pattern = " - Gyro RefVal Y = ([%d.]+)",            Value = nil },
    { Name = "gyro_t2s_refval_z",       Pattern = " - Gyro RefVal Z = ([%d.]+)",            Value = nil },
}

local gAccel2NormalModeMatchTbl = {
    { Name = "accel2_normal_average_x",     Pattern = "average: X = ([%-?%d.]+),",                                  Value = nil },
    { Name = "accel2_normal_average_y",     Pattern = "average: X = [^%s]+, Y = ([%-?%d.]+),",                      Value = nil },
    { Name = "accel2_normal_std_x",         Pattern = "std%-dev: X = ([%d.]+),",                                    Value = nil },
    { Name = "accel2_normal_std_y",         Pattern = "std%-dev: X = [^%s]+, Y = ([%d.]+),",                        Value = nil },
    { Name = "accel2_normal_std_z",         Pattern = "std%-dev: X = [^%s]+, Y = [^%s]+, Z = ([%d.]+),",            Value = nil },
    { Name = "accel2_normal_odr",           Pattern = "calculated odr: ([%d.]+)",                                   Value = nil },
}

local gAccelNormalModeMatchTbl = {
    { Name = "accel_normal_average_x",     Pattern = "average: X = ([%-?%d.]+),",                                       Value = nil },
    { Name = "accel_normal_average_y",     Pattern = "average: X = [^%s]+, Y = ([%-?%d.]+),",                           Value = nil },
    { Name = "accel_normal_odr",           Pattern = "calculated odr: ([%d.]+)",                                        Value = nil },
}

local gGyroMatchTbl = {
    { Name = "gyro_normal_average_x",       Pattern = "average: X = ([%-?%d.]+),",                                      Value = nil },
    { Name = "gyro_normal_average_y",       Pattern = "average: X = [^%s]+, Y = ([%-?%d.]+),",                          Value = nil },
    { Name = "gyro_normal_average_z",       Pattern = "average: X = [^%s]+, Y = [^%s]+, Z = ([%-?%d.]+),",              Value = nil },
    { Name = "gyro_normal_std_x",           Pattern = "std%-dev: X = ([%d.]+),",                                        Value = nil },
    { Name = "gyro_normal_std_y",           Pattern = "std%-dev: X = [^%s]+, Y = ([%d.]+),",                            Value = nil },
    { Name = "gyro_normal_std_z",           Pattern = "std%-dev: X = [^%s]+, Y = [^%s]+, Z = ([%d.]+),",                Value = nil },
    { Name = "gyro_normal_odr",             Pattern = "calculated odr: ([%d.]+)",                                       Value = nil },
    { Name = "gyro_normal_temp",            Pattern = "median: X = [^%s]+, Y = [^%s]+, Z = [^%s]+, T = ([%d.]+)",       Value = nil },
}

local function AccelOffInit()
	Shell("sensor --sel accel,accel2 --turnoff")
	Shell("wait 20")
	Shell("sensor --sel accel,accel2 --init")
	Shell("wait 20")
end

local function GyroOffInit()
	Shell ("sensor --sel gyro --turnoff")
	Shell ("wait 20")
	Shell ("sensor --sel accel,accel2,gyro --init")
end

-- Accel/Accel2 initialization
function AccelInit()
    Shell("sensor --listsensors")
    Shell("sensor --sel accel,accel2 --init")
    AccelInitResult = string.match(Last.Output, "(OK)")
    QT_ReportItemTestResult("Accel", "accel_init", AccelInitResult == "OK" and 0 or 1)
    QT_ReportItemTestResult("Accel", "accel2_init", AccelInitResult == "OK" and 0 or 1)
end

-- Accel connectivity test
function AccelConnect(Sensor)
    local ConnectTestResult = {}

    Shell("wait 20")
    Shell("sensor --sel accel,accel2 --conntest")
    ConnectTestResult = Universal.SplitString(Last.Output, "%c+Executing connectivity test for")
    AccelConnectResult = string.match(ConnectTestResult[1], "test%-result:%s+(passed)")
    QT_ReportItemTestResult("Accel", "accel_connectivity", AccelConnectResult == "passed" and 0 or 1)

    Accel2ConnectResult = string.match(ConnectTestResult[2], "test%-result:%s+(passed)")
    QT_ReportItemTestResult("Accel", "accel2_connectivity", Accel2ConnectResult == "passed" and 0 or 1)
end

-- Accel single sensor self test
local function SensorSingleSelfTest(Sensor, MatchTbl)
    local SensorSelfTestResult = nil

    Shell ("sensor --sel "..Sensor.." --exectest selftest")
    SensorSelfTestResult = string.match(Last.Output, "test%-result:%s+(passed)")

    if Sensor == "gyro" then
        QT_ReportItemTestResult("Gyro", Sensor.."_selftest", SensorSelfTestResult == "passed" and 0 or 1)
    else
        QT_ReportItemTestResult("Accel", Sensor.."_selftest", SensorSelfTestResult == "passed" and 0 or 1)
        for _, SensorSelfItem in ipairs(MatchTbl) do
            QT_ReportItemTestResult("Accel", Sensor .. "_"..SensorSelfItem.Name, tonumber(Last.Output:match(SensorSelfItem.Pattern)))
        end
    end
end

-- Accel self test
function AccelSelfTest()
    AccelOffInit()
    SensorSingleSelfTest("accel", gSensorSelftestMatchTbl)
end

-- Accel2 self test
function Accel2SelfTest()
    Shell("wait 20")
    SensorSingleSelfTest("accel2", gSensorSelftestMatchTbl)
end

-- Set data rate
function SetDataRate()
    Shell ("wait 20")
    Shell ("sensor --sel accel --get")
    Shell ("sensor --sel accel2 --get")
    AccelOffInit()
    Shell ("sensor --sel accel --set rate 1600")
    AccelSetRateResult = string.match(Last.Output, "(OK)")
    QT_ReportItemTestResult("Accel", "accel_set_rate", AccelSetRateResult == "OK" and 0 or 1)
end

-- Accel single sensor bandwidth test
local function AccelSingleBandWidthTest(Sensor, SpecItem, SpecTableName)
    Shell ("sensor --sel "..Sensor.." --set bw 800")
    BandWidthTestResult = string.match(Last.Output, "(OK)")
    QT_ReportItemTestResult(SpecTableName, Sensor.."_"..SpecItem, BandWidthTestResult == "OK" and 0 or 1)
end

--Accel/Accel2 set bandwidth
function AccelSetBandwidth(Args)
    AccelSingleBandWidthTest(Args.Name, "set_bw", "Accel")
end

-- Accel/Accel2 set bandwidth2
function AccelSetBandwidthNormal(Args)
    AccelSingleBandWidthTest(Args.Name, "set_bw_normal", "Gyro")
end

-- Accel set full scale range
local function AccelTimesToSetFullScaleRange(SpecTableName, SpecItem)
    Shell ("sensor --sel accel --set dynamic_range 32")
    SetFullScaleRangeResult = string.match(Last.Output, "(OK)")
    QT_ReportItemTestResult(SpecTableName, SpecItem, SetFullScaleRangeResult == "OK" and 0 or 1)
end

-- Accel set full scale range No.1
function AccelFirstlySetFullScaleRange()
    AccelTimesToSetFullScaleRange("Accel", "accel_set_dymanic_range")
end

-- Accel/Accel2/Gyro_Initialization
function AccelAccel2GyroInitialization()
    Shell ("sensor --sel accel,accel2,gyro --init")
    SnesorInitResult = string.match(Last.Output, "(OK)")
    QT_ReportItemTestResult("Accel", "accel/accel2/gyro_init", SnesorInitResult == "OK" and 0 or 1)
end

-- Gyro serial id
function GyroSerialID()
    local SensorSerialId = ""

    Shell ("wait 200")
    Shell ("sensor --sel gyro --get")
    SensorSerialId = Last.Output:match("serial_id = ([%w_]+)")

    QT_ReportItemTestResult("Gyro", "inertial_sensor_serial_id", SensorSerialId)
    QT_ReportItemAttribute("INERTIAL_SERIAL_ID", SensorSerialId)
end

-- Gyro connectivity
function GyroConnect()
    Shell("wait 200")
    Shell("sensor --sel gyro --conntest")
    GyroConnectResult = Last.Output:match("test%-result:%s+(passed)")
    QT_ReportItemTestResult("Gyro", "gyro_connectivity", GyroConnectResult == "passed" and 0 or 1)
end

-- Gyro self test
function GyroSelfTest()
    GyroOffInit()
    Shell ("wait 200")
    SensorSingleSelfTest("gyro")
end

-- Gyro quadrature test
function GyroQuadrature()
    Shell ("sensor --sel gyro --exectest quad")
    for _, GyroQuadItem in ipairs(gGyroQuadMatchTbl) do
        QT_ReportItemTestResult("Gyro", GyroQuadItem.Name, tonumber(Last.Output:match(GyroQuadItem.Pattern)))
    end
end

-- Gyro trim2 solder
function GyroTrim2Solder()
    local GyroT2sResult = nil

    Shell ("sensor -s gyro -e sensor -s gyro -e selfcal_trim_solder")
    GyroT2sResult = string.match(Last.Output, "test%-result:%s+(passed)")
    QT_ReportItemTestResult("Gyro", "gyro_t2s", GyroT2sResult == "passed" and 0 or 1)

    for _, GyroTrim2sItem in ipairs(gGyroTrim2sMatchTbl) do
        QT_ReportItemTestResult("Gyro", GyroTrim2sItem.Name, tonumber(Last.Output:match(GyroTrim2sItem.Pattern)))
    end
end

-- Gyro drive frequency test
function GyroDriveFrequency()
    Shell ("sensor -s gyro --exectest drive_freq_measurement")
    QT_ReportItemTestResult("Gyro", "gyro_drive_freq", tonumber(Last.Output:match("clk_vel_p = ([%d.]+)")))
end

-- Gyro VCM
function GyroVCM()
    Shell ("sensor -s gyro --exectest vcm")
    QT_ReportItemTestResult("Gyro", "gyro_vcm", tonumber(Last.Output:match("CM Voltage: ([%-?%d.]+)")))
end

-- Single sensor set data rate
local function SensorSingleSetDataRata(Sensor, SpecItem, SpecTableName)
    Shell ("sensor --sel "..Sensor.." --set rate 1600")
    SensorSetRateResult = string.match(Last.Output, "(OK)")
    QT_ReportItemTestResult(SpecTableName, SpecItem, SensorSetRateResult == "OK" and 0 or 1)
end

-- Accel set data rate
function AccelSetDataRate()
    Shell("sensor --sel accel,accel2 --turnoff")
    GyroOffInit()
    Shell ("wait 200")
    SensorSingleSetDataRata("accel", "accel_set_rate_gyro", "Accel")
end

-- Gyro set data rate
function GyroSetDataRate()
    SensorSingleSetDataRata("gyro", "gyro_set_rate", "Gyro")
end

-- Accel set full scale range No.2
function AccelSecondlySetFullScaleRange2()
    AccelTimesToSetFullScaleRange("Accel", "accel_set_dymanic_range2")
end

-- Accel2 FSR
function Accel2FSR()
    Shell ("sensor --sel accel2 --get")
    QT_ReportItemTestResult("Gyro", "accel2_fsr", tonumber(Last.Output:match("dynamic_range = ([%d.]+)")))
end

-- Sensor single normal mode test data report
local function SensorSingleNormalMode(SensorData, MatchTbl, SpecTableName)
    for _, SensorNormalMode in ipairs(MatchTbl) do
        QT_ReportItemTestResult(SpecTableName, SensorNormalMode.Name, tonumber(SensorData:match(SensorNormalMode.Pattern)))
    end
end

-- Accel/Accel2/Gyro normal mode test
function SensorNormalMode()
    local GPIOValue = ""
    local SensorDatas = ""
    local IsD8x = (ProductName == "D83" or ProductName == "D84")

    Shell("sensor --sel accel2 --sample 500ms --stats --quiet")
    SensorDatas = Last.Output
    Shell("sensor --sel accel2 --turnoff")
    if IsD8x then
        Shell ("socgpio --port 0 --pin 98 --get")
        GPIOValue = tonumber(Last.Output:match("SoC GPIO%[0,98%] = ([%d.]+)"))
        QT_ReportItemTestResult("Accel", GPIOValue == 0 and "accel2_normal_average_z_eSIM" or "accel2_normal_average_z_pSIM", tonumber(SensorDatas:match("average: X = [^%s]+, Y = [^%s]+, Z = ([%-?%d.]+),")))
    else
        QT_ReportItemTestResult("Accel", "accel2_normal_average_z", tonumber(SensorDatas:match("average: X = [^%s]+, Y = [^%s]+, Z = ([%-?%d.]+),")))
    end
    SensorSingleNormalMode(SensorDatas, gAccel2NormalModeMatchTbl, "Accel")

    Shell("sensor --sel accel,gyro --sample 500ms --stats --quiet")
    SensorDatas = Universal.SplitString(Last.Output, "%s+%# of samples captured: %d+")
    Shell("sensor --sel accel,gyro --turnoff")
    if IsD8x then
        QT_ReportItemTestResult("Accel", GPIOValue == 0 and "accel_normal_average_z_eSIM" or "accel_normal_average_z_pSIM", tonumber(SensorDatas[2]:match("average: X = [^%s]+, Y = [^%s]+, Z = ([%-?%d.]+),")))
    else
        QT_ReportItemTestResult("Accel", "accel_normal_average_z", tonumber(SensorDatas[2]:match("average: X = [^%s]+, Y = [^%s]+, Z = ([%-?%d.]+),")))
    end
    SensorSingleNormalMode(SensorDatas[2], gAccelNormalModeMatchTbl, "Accel")
    SensorSingleNormalMode(SensorDatas[3], gGyroMatchTbl, "Gyro")
end