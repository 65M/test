---------------------------------------------------------------------------
-- Prox_NVM_Dump.
-- This file contains Prox_NVM_Dump related tests, structures and functions.
-- This table is the rule for calculating the corresponding value of RecordName in the table 'QTProxNVMLimitsTable'.
local ProxNVMMap =
{
    { RecordName = "OTP1_AMBIENT_WINDOW_DURATION",               NVMIndex = "0B",               Bit = "0:3" },
    { RecordName = "OTP1_RANGING_WINDOW_MULTIPLE",               NVMIndex = "0B",               Bit = "5:7" },
    { RecordName = "TIMEOUT_OVERALL_PERIOD_CLIP_MSB",            NVMIndex = "5C",               Bit = "0:7" },
    { RecordName = "BLANKING_TIME_MSB",                          NVMIndex = "5D",               Bit = "0:3" },
    { RecordName = "TIMEOUT_OVERALL_PERIOD_CLIP_LSB",            NVMIndex = "5D",               Bit = "4:7" },
    { RecordName = "BLANKING_TIME_LSB",                          NVMIndex = "5E",               Bit = "0:7" },
    { RecordName = "INTEGRATION_THRESHOLD",                      NVMIndex = "5F",               Bit = "0:7" },
    { RecordName = "OTP_USER_LOCK",                              NVMIndex = "60",               Bit = "0:1" },
    { RecordName = "OCP_AVG_TRIP",                               NVMIndex = "6B",               Bit = "0:7" },
    { RecordName = "PERSIS_WITHIN_BIST",                         NVMIndex = "6C",               Bit = "0:3" },
    { RecordName = "PERSIS_OVER_MULTIPLE_BIST",                  NVMIndex = "6C",               Bit = "4:7" },
    { RecordName = "VCSEL_PERIOD",                               NVMIndex = "6D",               Bit = "0:5" },
    { RecordName = "VCSEL_CLK_MODE_OTP",                         NVMIndex = "6D",               Bit = "6:7" },
    { RecordName = "VCSEL_START",                                NVMIndex = "6E",               Bit = "0:6" },
    { RecordName = "VCSEL_DELAY",                                NVMIndex = "6E",               Bit = "7:7" },
    { RecordName = "VCSEL_STOP",                                 NVMIndex = "6F",               Bit = "0:6" },
    { RecordName = "OTP0_AMBIENT_WINDOW_DURATION",               NVMIndex = "71",               Bit = "0:3" },
    { RecordName = "OTP0_RANGING_WINDOW_MULTIPLE",               NVMIndex = "71",               Bit = "4:6" },
    { RecordName = "VCSEL_CLIP",                                 NVMIndex = "72",               Bit = "0:5" },
    { RecordName = "BYPASS_LOW_TEMP",                            NVMIndex = "75",               Bit = "0:0" },
    { RecordName = "BYPASS_OCP",                                 NVMIndex = "75",               Bit = "1:1" },
    { RecordName = "BYPASS_WDG",                                 NVMIndex = "75",               Bit = "2:2" },
    { RecordName = "BYPASS_CC",                                  NVMIndex = "75",               Bit = "3:3" },
    { RecordName = "AVDD_SW_DISABLE",                            NVMIndex = "75",               Bit = "4:4" },
    { RecordName = "OTP_VENDOR_LOCK",                            NVMIndex = "77",               Bit = "0:1" },
}

-- Initialize prox.
function ProxInit()
    Shell("sensor --sel prox --init")
    QT_ReportItemTestResult("ProxInit", "INIT_TEST", Last.Output:match("OK"))
    Shell("sensor --sel prox --conntest")
    QT_ReportItemTestResult("ProxInit", "QT_CONNTEST", Last.Output:match("PASS"))
end

-- Get prox module sn.
function ProxModuleSn()
    Shell("camisp --pick front1 --on")
    Shell("camisp --sn")
    --Match prox module sn.
    PROX_MODULE_SN = Last.Output:match("Serial Number: (%w+)")
    QT_ReportItemTestResult("ProxModuleSn", "MODULE_SN", PROX_MODULE_SN)
    --Upload the matched prox module sn to the server.
    QT_ReportItemAttribute("PROX_MODULE_SN", PROX_MODULE_SN)
end

-- The data of prox nvm dump will be parsed and stored in a table
-- @param  NVMData      : Table to store prox nvm dump data.
-- @param  NVMDataCheck : Rule table for calculating prox nvm dump data.
local function NvmDumpCheck(NVMData, NVMDataCheck)
    for i = 1, #NVMDataCheck do
        local SpecVal = QT_GetNvmValue(NVMData, NVMDataCheck[i]["NVMIndex"], NVMDataCheck[i]["Bit"])
        QT_ReportItemTestResult("ProxNvmDump", NVMDataCheck[i]["RecordName"], SpecVal)
    end
end

-- Store the value of nvm dump into a table.
-- @param  NvmDumpData : The data of prox nvm dump.
local function CreateNvmRecord(NvmDumpData)
    -- The output format of nvmdump.
    local NvmArr = {}
    local BytePattern = "%x+"
    local NvmType = 16
    local LinePattern = string.rep(" "..BytePattern, NvmType)
    for LineStr in string.gmatch(NvmDumpData, LinePattern) do
        for ByteStr in string.gmatch(LineStr, BytePattern) do
            NvmArr[#NvmArr+1] = '0x'..ByteStr
        end
    end
    NvmDumpCheck(NvmArr, ProxNVMMap)
end

-- Process the output of prox nvm dump.
local function ProxNvmIntegrityCheck()
    Shell("sensor --sel prox --get nvm")
    CreateNvmRecord(Last.Output)
end

function ProxNvmDumpTest()
    ProxNvmIntegrityCheck()
end