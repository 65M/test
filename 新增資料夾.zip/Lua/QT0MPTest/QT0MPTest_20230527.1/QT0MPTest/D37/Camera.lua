-- QT0 Cameras test coverage smokey bring up.
-- rdar://105758510 (D83 QT0 MP FCAM related test coverage smokey bring up)
local Platform = PlatformInfo("PlatformName")
local IsD3y = (Platform == "D37") or (Platform == "D38")

-- [NVM Binary Sequence] = Scanned Barcode Letter
local BARCODE_TABLE = {
    ["000001"] = "0",
    ["000010"] = "1",
    ["000011"] = "2",
    ["000100"] = "3",
    ["000101"] = "4",
    ["000110"] = "5",
    ["000111"] = "6",
    ["001000"] = "7",
    ["001001"] = "8",
    ["010000"] = "9",
    ["010001"] = "A",
    ["010010"] = "B",
    ["010011"] = "C",
    ["010100"] = "D",
    ["010101"] = "E",
    ["010110"] = "F",
    ["010111"] = "G",
    ["011000"] = "H",
    ["011001"] = "I",
    ["100000"] = "J",
    ["100001"] = "K",
    ["100010"] = "L",
    ["100011"] = "M",
    ["100100"] = "N",
    ["100101"] = "O",
    ["100110"] = "P",
    ["100111"] = "Q",
    ["101000"] = "R",
    ["101001"] = "S",
    ["110000"] = "T",
    ["110001"] = "U",
    ["110010"] = "V",
    ["110011"] = "W",
    ["110100"] = "X",
    ["110101"] = "Y",
    ["110110"] = "Z"
}

local BASE34_TABLE = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "J", "K", "L", "M", "N", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"}

local gBlackOffsetCameraConfig = {
    ["D37"] = {
        ["back"]  = {I2cBus = "4", I2cAddr = "0x10"},
        ["back2"] = {I2cBus = "5", I2cAddr = "0x20"},
        ["front"] = {I2cBus = "6", I2cAddr = "0x10"},
    },
    ["D38"] = {
        ["back"]  = {I2cBus = "4", I2cAddr = "0x10"},
        ["back2"] = {I2cBus = "5", I2cAddr = "0x20"},
        ["front"] = {I2cBus = "6", I2cAddr = "0x10"},
    },
    ["D83"] = {
        ["back"]  = {I2cBus = "4", I2cAddr = "0x10"},
        ["back1"] = {I2cBus = "8", I2cAddr = "0x20"},
        ["back2"] = {I2cBus = "5", I2cAddr = "0x10"},
        ["front"] = {I2cBus = "6", I2cAddr = "0x10"},
    },
    ["D84"] = {
        ["back"]  = {I2cBus = "4", I2cAddr = "0x10"},
        ["back1"] = {I2cBus = "8", I2cAddr = "0x20"},
        ["back2"] = {I2cBus = "5", I2cAddr = "0x10"},
        ["front"] = {I2cBus = "6", I2cAddr = "0x10"},
    },
}

local gGuadalupeRegTab = {
    {Name = "SI_REVIDReg",          Addr = "0x70"},
    {Name = "DEVICE_STAT_reg",      Addr = "0x71"},
    {Name = "FLT_STATEReg",         Addr = "0x72"},
    {Name = "FLT_STATUS0Reg",       Addr = "0x73"},
    {Name = "FLT_STATUS1Reg",       Addr = "0x74"},
    {Name = "FLT_STATUS2Reg",       Addr = "0x75"},
    {Name = "FLT_STATUS3Reg",       Addr = "0x76"},
    {Name = "FLT_STATUS4Reg",       Addr = "0x77"},
    {Name = "RECORD0Reg",           Addr = "0x54"},
    {Name = "RECORD1Reg",           Addr = "0x55"},
    {Name = "RECORD2Reg",           Addr = "0x56"},
    {Name = "RECORD3Reg",           Addr = "0x57"},
    {Name = "RECORD4Reg",           Addr = "0x58"},
    {Name = "CONFIG_LOCKReg",       Addr = "0x50"},
    {Name = "BrickEEP",             Addr = "0x51"},
    {Name = "ASIC_CRC0Reg",         Addr = "0x52"},
    {Name = "ASIC_CRC1Reg",         Addr = "0x53"},
}

-- Covert byte to binary string
local function Byte2Bin(n)
    local t = {}

    for i = 3, 0, -1 do
        table.insert(t, math.floor(n / 2^i))
        n = n % 2^i
    end

    return table.concat(t)
end

--===============================================================================================
-- function                 : CameraNVMCheck(NVMDataArray, CamNVMMapIndex)
-- description              : Check all of the NVM test items in CameraNVMMap and report data
-- @param NVMDataArray      : table, record all NVM data from StartAddress 0x0
-- @param CamNVMMapIndex    : string, table index of Camera NVM Map
-- @return                  : Limits checking and report data to station, return key-value pair for all NVM Integrity items
local function CameraNVMCheck(NVMDataArray, CamNVMMapIndex)
    local NVMItems = {}
    local IsNVMValid = false
    local CameraNVMMap = GetTestItemTableFun(CamNVMMapIndex)

    for index, MapItem in ipairs(CameraNVMMap) do
        if MapItem.Index then
            NVMItems[MapItem.Name] = QT_GetNvmValue(NVMDataArray, MapItem.Index, MapItem.Bit)
            if not MapItem.Disable then
                QT_ReportItemTestResult(CamNVMMapIndex, MapItem.Name, NVMItems[MapItem.Name])
            end
        end
    end

    -- Check if NVM dumping data is valid
    for _, v in ipairs(NVMDataArray) do
        if tonumber(v) ~= 0 and tonumber(v) ~= 255 then
            IsNVMValid = true
            break
        end
    end

    QT_ReportItemTestResult(CamNVMMapIndex, CamNVMMapIndex:match("(%w+)_CAMInfo").."_NVM_Dumping_ValidCheck", IsNVMValid and "NoError_NotOnly0xFF_0x0" or "Only0xFF_0x0 in NVM")

    return NVMItems
end

--===============================================================================================
-- function                 : GetNVMData(NVMDumpData)
-- description              : Get camera nvmdump raw data and save in an array
-- @param NVMDumpData       : string, the raw data from cmd 'nvmdump'
-- @return                  : table,  an array contains all the NVM data
local function GetNVMData(NVMDumpData)
    -- The output format of nvmdump is like this:
    -- 0x1808 : 0x70 0xFD 0x67 0xEA 0xBB 0x19 0xD9 0x37
    local CamNVMArr = {}
    local BytePattern = "0x%x+"
    local LinePattern = string.rep(" "..BytePattern, 8)

    for LineStr in string.gmatch(NVMDumpData, LinePattern) do
        for ByteStr in string.gmatch(LineStr, BytePattern) do
            table.insert(CamNVMArr, ByteStr)
        end
    end

    return CamNVMArr
end

--===============================================================================================
-- function                 : Hex2Base34(Value, Length)
-- description              : Convert hex value into base-34 numbers
-- @param Value             : string, hex value of NVM SN, 17 digits SN shall be divided into three parts: PPPYWW, DSSSS and EEEERX
-- @param Lenth             : number, lenth of NVM SN that needs to be decoded
-- @return                  : string, unique serial number of camera(base-34)
local function Hex2Base34(Value, Length)
    local Output = '' 
    local INTVal = tonumber("0x"..Value)

    for i = 1, Length do
        Output = BASE34_TABLE[(INTVal%34)+1]..Output
        INTVal = math.modf(INTVal / 34)
    end

    return Output
end

--===============================================================================================
-- function                 : GetFront_NVMSN(NVMValueTab)
-- description              : Decoding function for FCAM, decode 7E barcode binary sequence from the NVM
--      Get 14 bytes (34F:35C) buildInfo_SN_Barcode7E from NVM table and convert to binary digits (112 digits, 14 * 8).
--      Each 6 binary digit maps to 1 barcode letter (Total 18 letters, 108 digits, 18 * 6).
--      After combining 18 letters, it is SN_Barcode7E.
-- e.g.
--      NVM value:
--          ...
--          0x348 : 0x52 0x40 0x0 0x16 0x8 0x10 0x80 0xD2
--          0x350 : 0x9C 0xC4 0x14 0x20 0xC1 0x07 0x61 0x11
--          0x358 : 0x0C 0x41 0x42 0x18 0x60 0x20 0x1 0x21
--          ...
--      Input: tabInput (Base - 16, 14 bytes):
--          D29CC41420C10761110C41421860
--      SN_Barcode7E_fromNVM_binary (112 digits):
--          1101001010011100110001000001010000100000110000010000011101100001000100010000110001000001010000100001100001100000
--      SN_Barcode7E_fromNVM_binary_108 (108 digits):
--          110100101001110011000100000101000010000011000001000001110110000100010001000011000100000101000010000110000110
--      SN_Barcode7E_Letter (18 letters):
--          110100 (X), 101001 (S), 110011(W), ...
--      Output: SN_Barcode7E (Base - 36, 18 letters):
--          XSW341200Z3A234155
-- @param NVMValueTab                   : table, contains the value of SN_Barcode7E (Base - 16) from NVM value (Addr: 34F:35C)
-- @return                              : string, SN_Barcode7E (Base - 36)
local function GetFront_NVMSN(NVMValueTab)
    local SN_Barcode7E_FromNVM_Hex = NVMValueTab["Front_SN_Barcode7E"]
    local SN_Barcode7E_FromNVM_Binary = ""
    local SN_Barcode7E = ""

    for i = 1, #SN_Barcode7E_FromNVM_Hex do
        SN_Barcode7E_FromNVM_Hex_Digit = string.sub(SN_Barcode7E_FromNVM_Hex, i, i)
        SN_Barcode7E_FromNVM_Binary_Digit = Byte2Bin("0x"..SN_Barcode7E_FromNVM_Hex_Digit)
        SN_Barcode7E_FromNVM_Binary = SN_Barcode7E_FromNVM_Binary..SN_Barcode7E_FromNVM_Binary_Digit
    end

    SN_Barcode7E_FromNVM_Binary_Len = #SN_Barcode7E_FromNVM_Binary / 6
    SN_Barcode7E_FromNVM_Binary_Len = SN_Barcode7E_FromNVM_Binary_Len - SN_Barcode7E_FromNVM_Binary_Len % 1 - 1  -- Get integer part
    
    for i = 0, SN_Barcode7E_FromNVM_Binary_Len do
        SN_Barcode7E_FromNVM_Binary_6 = string.sub(SN_Barcode7E_FromNVM_Binary, i * 6 + 1, i * 6 + 6)
        SN_Barcode7E_Letter = BARCODE_TABLE[tostring(SN_Barcode7E_FromNVM_Binary_6)]
        SN_Barcode7E = SN_Barcode7E..SN_Barcode7E_Letter
    end

    return SN_Barcode7E
end

--===============================================================================================
-- function                 : GetRCAM_NVMSN(NVMValueTab, RearCameraLoc)
-- description              : Get NVM EXTENDED SN from NVM for RCAMs
-- @param NVMValueTab       : table, comtains RCAMs NVM value of AA-LL
-- @param BackNum           : string, index of RCAM
-- @return                  : string, EXTENDED SN for RCAMs
local function GetRCAM_NVMSN(NVMValueTab, RearCameraLoc)
    local RCAM_SN = ""
    local NVM_SN = {"AA","BB","CC","FF","GG","HH","II","JJ","KK","LL"}

    for _, v in ipairs(NVM_SN) do
        RCAM_SN = RCAM_SN .. (tonumber(NVMValueTab[RearCameraLoc.."_"..v]) == 0 and "00" or NVMValueTab[RearCameraLoc.."_"..v])
    end

    return RCAM_SN
end

--===============================================================================================
-- function                 : GetSphinx_NVMSN(NVMValueTab)
-- description              : Decode Sphinx SN from NVM
-- @param NVMValueTab       : table, contains hex value of Sphinx NVM SN, 17 digits SN shall be divided into three parts: PPPYWW, DSSSS and EEEERX
-- @return                  : string, unique serial number of camera(base-34)
local function GetSphinx_NVMSN(NVMValueTab)
    local PPPYWW =  NVMValueTab["PPPYWW"]
    local DSSSS =  NVMValueTab["DSSSS"]
    local EEEERX =  NVMValueTab["EEEERX"]

    PPPYWW = Hex2Base34(PPPYWW, 6)
    DSSSS = Hex2Base34(DSSSS, 5)
    EEEERX = Hex2Base34(EEEERX, 6)

    return PPPYWW..DSSSS..EEEERX
end

--===============================================================================================
-- function                 : GetBlackLevelOffsetValue(Sensor)
-- description              : Black Level Offset Calculation function
-- @param SensorName        : back/back1/back2
-- @return                  : number, BlackLevelOffsetValue
local function GetBlackLevelOffsetValue(Sensor)
    Shell("wait 200")
    Shell("camisp --ae off")
    Shell("wait 200")
    -- Sets exposure to 33ms and analog gain to 8x, so this is an alternative to writing to 0x0149 = 0xE0
    Shell("camisp --i2cwrite " .. gBlackOffsetCameraConfig[Platform][Sensor].I2cBus .. " " .. gBlackOffsetCameraConfig[Platform][Sensor].I2cAddr .. " 0x0149 2 1 0xE0")
    Shell("wait 200")
    -- Do 2-byte read of BLO
    Shell("camisp --i2cread " .. gBlackOffsetCameraConfig[Platform][Sensor].I2cBus .. " " .. gBlackOffsetCameraConfig[Platform][Sensor].I2cAddr .. " 0x0400 2 2")
    local BlackOffSetValue = Last.Output:match("%c+(0x%x+)%c")
    local SigBit = bit32.extract(tonumber(BlackOffSetValue), 7, 1)     -- signBit = 0x0400[15]
    local MsbBits = bit32.extract(tonumber(BlackOffSetValue), 0, 7)     -- msb = 0x0400[14:8]
    local LsbBits = bit32.extract(tonumber(BlackOffSetValue), 8, 8)     -- lsb = 0x0401[7:0]
    -- BLO = BlackLevelOffset = [(-1*Sign*2^15) + hex2dec(MSB)*2^8 + hex2dec(LSB)] / 32
    local BlackLevelOffsetValue = (-1*SigBit*32768 + MsbBits*256 + LsbBits)/32.0

    Shell("camisp --stream off")
    return BlackLevelOffsetValue
end

-- FCAM Faraday driver test
local function FaradayDriverTest()
    Shell("camisp --i2cread 6 0x59 0x06 1 2")
    Shell("camisp --i2cwrite 6 0x59 0x06 1 2 0x0004") -- Write 0x06 with 0x0004 to clear status register
    Shell("camisp --i2cread 6 0x59 0x06 1 2")

    Shell("camisp --i2cwrite 6 0x59 0x03 1 2 0x0F82") -- Standby mode configration: set to 120mA full scale
    Shell("camisp --i2cread 6 0x59 0x03 1 2")

    Shell("camisp --i2cwrite 6 0x59 0x04 1 2 0x0043") -- control parameter
    Shell("camisp --i2cread 6 0x59 0x04 1 2")

    Shell("camisp --i2cwrite 6 0x59 0x02 1 2 0x0001") -- Standby to Active mode
    Shell("camisp --i2cread 6 0x59 0x02 1 2")

    Shell("camisp --i2cread 6 0x59 0x00 1 2") -- read out chip id
    QT_ReportItemTestResult("Front_CAMInfo", "FCAM_Faraday_Driver_ChipID", Last.Output:match("RunI2cRead 0x%x+\r\n%s*(0x%x+)"))
    Shell("camisp --i2cread 6 0x59 0x01 1 2") -- read out rev id
    QT_ReportItemTestResult("Front_CAMInfo", "Chip_Rev_check", Last.Output:match("RunI2cRead 0x%x+\r\n%s*(0x%x+)"))
    Shell("camisp --i2cread 6 0x59 0x06 1 2") -- read out status register
    QT_ReportItemTestResult("Front_CAMInfo", "Status_check", Last.Output:match("RunI2cRead 0x%x+\r\n%s*(0x%x+)"))
end

-- Gudatlupe NVM dump
local function GuadalupeNVMDump()
    require "Burnin"
    local GuadalupeI2cBus = "7"
    local GuadalupeI2cAddr = "0x64"

    for _, Reg in ipairs(gGuadalupeRegTab) do
        Shell("camisp --i2cread " .. GuadalupeI2cBus .. " " .. GuadalupeI2cAddr .. " ".. Reg.Addr .. " 1 1")
        QT_ReportItemTestResult("SphinxRX_CAMInfo", Reg.Name, ExtractCamI2COutput(1))
    end
end

-- Camera front test
function CameraFront()
    local NVMMapIndex = "Front_CAMInfo"

    -- Item142: Pick_Front
    Shell("camisp --exit --find --pick front")
    QT_ReportItemTestResult(NVMMapIndex, "Pick_Front", Last.Output:match("Pass") or "Pick Front missing")
    Shell("camisp --on")

    -- Item143: Front_NVM_Dumping
    Shell("camisp --nvmdump")
    local NVM_Items = CameraNVMCheck(GetNVMData(Last.Output), NVMMapIndex)

    -- Item144: Read_Front_SN_From_NVM
    QT_ReportItemTestResult(NVMMapIndex, "Read_Front_SN_From_NVM", GetFront_NVMSN(NVM_Items))

    -- Item146: Read_Front_SN_From_Diag
    Shell("camisp --sn")
    QT_ReportItemTestResult(NVMMapIndex, "Read_Front_SN_From_Diag", Last.Output:match("Serial Number: (%w+)"))

    -- Item147: Front_ID
    Shell("camisp --id")
    QT_ReportItemTestResult(NVMMapIndex, "Front_ID", Last.Output:match("0x%x+"))

    -- Item148: Front_Stream
    Shell("camisp --stream on")
    QT_ReportItemTestResult(NVMMapIndex, "Front_Stream", Last.Output:match("Pass") or "Fail")
    -- D37 Item145: FCAM_Faraday_Driver_ChipID + Item146: Front_BlackLevelOffset_Value
    if IsD3y then
        FaradayDriverTest()
        QT_ReportItemTestResult(NVMMapIndex, "Front_BlackLevelOffset_Value", GetBlackLevelOffsetValue('front'))
    end
    -- Item149: Dli_Front
    Shell("camisp --dli")
    QT_ReportItemTestResult(NVMMapIndex, "Dli_Front", Last.Output:match("Pass") or "Fail")

    Shell("camisp --exit")
end

-- Camera Sphinx test
function CameraSphinx()
    local NVMMapIndexTX = "SphinxTX_CAMInfo"
    local NVMMapIndexRX = "SphinxRX_CAMInfo"

    -- Item150: Pick_Front1
    Shell("camisp --exit --find --pick front1")
    QT_ReportItemTestResult(NVMMapIndexTX, "Pick_Front1", Last.Output:match("Pass") or "Pick Front1 missing")
    Shell("camisp --on")

    -- Item151: SphinxTX_NVM_Dumping
    Shell("camisp --nvmdump romeo")
    local NVM_ItemsTX = CameraNVMCheck(GetNVMData(Last.Output), NVMMapIndexTX)

    -- Item152: Read_Sphinx_SN_From_TXNVM
    QT_ReportItemTestResult(NVMMapIndexTX, "Read_Sphinx_SN_From_TXNVM", GetSphinx_NVMSN(NVM_ItemsTX))

    -- Item153: SphinxRX_NVM_Dumping
    Shell("camisp --nvmdump")
    local NVM_ItemsRX = CameraNVMCheck(GetNVMData(Last.Output), NVMMapIndexRX)

    -- Item154: Read_Sphinx_SN_From_RXNVM
    QT_ReportItemTestResult(NVMMapIndexRX, "Read_Sphinx_SN_From_RXNVM", GetSphinx_NVMSN(NVM_ItemsRX))

    -- Item156: Read_Sphinx_SN_From_Diag
    Shell("camisp --sn")
    QT_ReportItemTestResult(NVMMapIndexRX, "Read_Sphinx_SN_From_Diag", Last.Output:match("Serial Number: (%w+)"))

    -- Item157: Front1_ID
    Shell("camisp --id")
    QT_ReportItemTestResult(NVMMapIndexRX, "Front1_ID", Last.Output:match("0x%x+"))

    -- Item158: Regulus_EEPROM
    Shell("camisp --nvmdump regulus")
    QT_ReportItemTestResult(NVMMapIndexRX, "Regulus_EEPROM", Last.Output:match("Pass") or "Fail")

    -- Item159: Front1_Stream
    Shell("camisp --stream on")
    QT_ReportItemTestResult(NVMMapIndexRX, "Front1_Stream", Last.Output:match("Pass") or "Fail")

    -- Item160: Dli_Front1
    Shell("camisp --dli")
    QT_ReportItemTestResult(NVMMapIndexRX, "Dli_Front1", Last.Output:match("Pass") or "Fail")

    -- Item163: Guadalupe_NVM_dump
    Shell("camisp --pick front1 --on")
    GuadalupeNVMDump()

    -- Item164: GPIO_NUB_FROM_FDEPTH_B2B_DETECT
    local SphinxGpioPin = IsD3y and 19 or 17
    Shell("socgpio --port 5 --pin " .. SphinxGpioPin .. " --get")
    QT_ReportItemTestResult(NVMMapIndexRX, "GPIO_NUB_FROM_FDEPTH_B2B_DETECT", tonumber(Last.Output:match("SoC GPIO[%w%p]+%s-%=%s-(%d)")))
    Shell("camisp --exit")
end

-- Rear Cameras Test Function, Args should be back/back1/back2
function RearCamera(Args)
    local Sensor = Args.Name
    local UpperName = Sensor:gsub("^%l", string.upper)
    local NVMMapIndex = UpperName.."_CAMInfo"

    if IsD3y and Sensor == "back1" then
        return
    end

    -- Item165: Pick_Back
    Shell("camisp --exit --find --pick "..Sensor)
    QT_ReportItemTestResult(NVMMapIndex, "Pick_"..UpperName, Last.Output:match("Pass") or "Pick "..UpperName.." missing")
    Shell("camisp --on")

    -- Item166: Read_Back_SN
    Shell("camisp --sn")
    local CameraSN = Last.Output:match("Serial Number: (%w+)")
    QT_ReportItemTestResult(NVMMapIndex, "Read_"..UpperName.."_SN", CameraSN)

    -- Item167: Compare_Back_SN_With_SFC/Item176: Add_Back1_NVM_Barcode_Attribute
    QT_ReportItemAttribute(string.upper(Sensor).."_NVM_BARCODE", CameraSN)

    -- Item168: Back_NVM_Dumping
    Shell("camisp --nvmdump")
    local NVM_Items = CameraNVMCheck(GetNVMData(Last.Output), NVMMapIndex)

    -- Item169: BACK_NVM_EXTENDED_SN
    QT_ReportItemTestResult(NVMMapIndex, string.upper(Sensor).."_NVM_EXTENDED_SN", CameraSN.."+"..GetRCAM_NVMSN(NVM_Items, UpperName))
    QT_ReportItemAttribute(string.upper(Sensor).."_NVM_EXTENDED_SN", CameraSN.."+"..GetRCAM_NVMSN(NVM_Items, UpperName))

    -- Item170: Back_ID
    Shell("camisp --id")
    QT_ReportItemTestResult(NVMMapIndex, UpperName.."_ID", Last.Output:match("0x%x+"))

    -- Item171: Back_Stream
    Shell("camisp --stream on")
    QT_ReportItemTestResult(NVMMapIndex, UpperName.."_Stream", Last.Output:match("Pass") or "Fail")

    -- Item172: Back_BlackLevelOffset_Value
    QT_ReportItemTestResult(NVMMapIndex, UpperName.."_BlackLevelOffset_Value", GetBlackLevelOffsetValue(Sensor))

    -- Item173: Dli_Back
    Shell("camisp --dli")
    QT_ReportItemTestResult(NVMMapIndex, "Dli_"..UpperName, Last.Output:match("Pass") or "Fail")

    Shell("camisp --exit")
end

-- Camera peridot test
function CameraPeridot()
    if IsD3y then
        return
    end

    local NVMMapIndex = "Peridot_CAMInfo"
    -- Item192: Pick_Back3
    Shell("camisp --exit --find --pick back3")
    QT_ReportItemTestResult(NVMMapIndex, "Pick_Back3", Last.Output:match("Pass") or "Pick Back3 missing")
    Shell("camisp --on")

    -- Item193: Read_Peridot_Camera_SN
    Shell("camisp --sn")
    QT_ReportItemTestResult(NVMMapIndex, "Read_Peridot_Camera_SN", Last.Output:match("Serial Number: (%w+)"))

    -- Item195: PeridotNvmIntegrityCheck
    Shell("camisp --nvmdump quark")
    local PeridotNVMItems = CameraNVMCheck(GetNVMData(Last.Output), NVMMapIndex)

    -- Item196: Peridot_Config
    local CameraDOEString = PeridotNVMItems.Peridot_Camera_DOE == 0 and "" or BASE34_TABLE[PeridotNVMItems.Peridot_Camera_DOE + 1]
    local PeridotConfig = "C" .. string.format("%02x", PeridotNVMItems.Peridot_Camera_Build) .. string.format("%02x", PeridotNVMItems.Peridot_Camera_Config) .. CameraDOEString
    QT_ReportItemTestResult(NVMMapIndex, "Peridot_Config", PeridotConfig)
    QT_ReportItemAttribute("PERIDOT_CONFIG", PeridotConfig)

    -- Item197: Peridot_ID
    Shell("camisp --id")
    QT_ReportItemTestResult(NVMMapIndex, "Peridot_ID", Last.Output:match("0x%x+"))

    -- Item198: Peridot_Stream
    Shell("camisp --method settofbuiltinsequence 5 8 0 0 0 0")
    Shell("wait 300")
    Shell("camisp --stream on")
    QT_ReportItemTestResult(NVMMapIndex, "Peridot_Stream", Last.Output:match("Pass") or "Fail")
    Shell("wait 300")
    Shell("camisp --stream off")
    Shell("camisp --exit")
end
