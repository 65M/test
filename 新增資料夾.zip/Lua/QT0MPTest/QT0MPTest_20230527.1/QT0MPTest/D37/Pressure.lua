require "Common"
require "Burnin"

local ProdName = PlatformInfo("PlatformName")
local Mod = 10000
local HEX_STEP = 8
local HEX_MOD = 0xFFFFFFFF + 1

local PressureSampleMatchTbl = {
    { Name = "press_average",   Pattern = "average: pressure = ([%d.]+),",                                              DataGain = 1000,    },
    { Name = "press_max",       Pattern = "max: pressure = ([%d.]+),",                                                  DataGain = 1000,    },
    { Name = "press_min",       Pattern = "min: pressure = ([%d.]+),",                                                  DataGain = 1000,    },
    { Name = "range",           Pattern = "range: pressure = ([%d.]+),",                                                DataGain = 1000,    },
    { Name = "temp_average",    Pattern = "average%s*:%s*pressure%s*=%s*[%d%.]*,%s*temp%s*=%s*([%d%.]*)[\r\n]*",        DataGain = 1,  },
    { Name = "press_std",       Pattern = "std%-dev: pressure = ([%d.]+),",                                             DataGain = 1000,    },
    { Name = "temp_std",        Pattern = "std%-dev%s*:%s*pressure%s*=%s*[%d%.]*,%s*temp%s*=%s*([%d%.]*)[\r\n]*",       DataGain = 1,  },
    { Name = "odr",             Pattern = "calculated%s*odr%s*:%s*([%d,%.]*)Hz",                                        DataGain = 1,  },
}

local gPRIDsMatchTbl = {
    Manu_ID = { Pattern = "0x00%s*=%s*0x(%w%w)", Value = nil },
    Chip_ID = { Pattern = "0x01%s*=%s*0x(%w%w)", Value = nil },
    Rev_ID  = { Pattern = "0x02%s*=%s*0x(%w%w)", Value = nil },
    Trim_ID = { Pattern = "0x03%s*=%s*0x(%w%w)", Value = nil },
    MPN_ID  = { Pattern = "0x04%s*=%s*0x(%w%w)", Value = nil },
}

local gPRSNsMatchTbl = {
    { Name = "Waf_Lot_Id3",  Pattern = "0x23 => 0x(%w%w)%w%w", Value = nil },
    { Name = "Waf_Lot_Id2",  Pattern = "0x23 => 0x%w%w(%w%w)", Value = nil },
    { Name = "Waf_Lot_Id1",  Pattern = "0x22 => 0x(%w%w)%w%w", Value = nil },
    { Name = "Waf_Lot_Id0",  Pattern = "0x22 => 0x%w%w(%w%w)", Value = nil },
    { Name = "Asic_Coord_Y", Pattern = "0x21 => 0x(%w%w)%w%w", Value = nil },
    { Name = "Asic_Coord_X", Pattern = "0x21 => 0x%w%w(%w%w)", Value = nil },
} 

-- Create table for big integer data
function BigInt_Create(DataStr)
    local ArrayCount = math.floor(#DataStr/4)
    local DataTbl = {}
    local StartIndex = 1

    if DataStr["BitInt"] == true then
        return DataStr
    end

    DataTbl["BitInt"] = true

    if #DataStr%4 ~= 0 then
        DataTbl[ArrayCount + 1] = tonumber(string.sub(DataStr, 1, #DataStr%4), 10)
        StartIndex = #DataStr%4 + 1 
    end

    for i = ArrayCount, 1, -1 do
        DataTbl[i] = tonumber(string.sub(DataStr, StartIndex,  StartIndex + 3), 10)
        StartIndex = StartIndex + 4 
    end

    return DataTbl
end

-- Big integer data add
function BigInt_Add(DataStr1, DataStr2)
    local DataTbl1 = BigInt_Create(DataStr1)
    local DataTbl2 = BigInt_Create(DataStr2)
    local SumResult = BigInt_Create("0")
    local CarryFlag = 0

    for i = 1, math.max(#DataTbl1, #DataTbl2) do
        CarryFlag = CarryFlag + (DataTbl1[i] or 0) + (DataTbl2[i] or 0)
        SumResult[i], CarryFlag = CarryFlag%Mod, math.floor(CarryFlag/Mod)
    end

    while CarryFlag ~= 0 do
        SumResult[#SumResult + 1], CarryFlag = CarryFlag%Mod, math.floor(CarryFlag/Mod)
    end

    return SumResult
end

-- Big integer data multiple
function BigInt_Mul(DataStr1, DataStr2)
    local DataTbl1 = BigInt_Create(DataStr1)
    local DataTbl2 = BigInt_Create(DataStr2)
    local ProductResult = BigInt_Create("0")
    local CarryFlag = 0

    for i = 1, #DataTbl1 do
        for j = 1, #DataTbl2 do
            CarryFlag = CarryFlag + (ProductResult[i + j - 1] or 0) + DataTbl1[i] * DataTbl2[j]
            ProductResult[i + j - 1] = CarryFlag % Mod
            CarryFlag = math.floor(CarryFlag / Mod)
        end
        if CarryFlag ~= 0 then
            ProductResult[i + #DataTbl2] = CarryFlag + (ProductResult[i + #DataTbl2] or 0)
            CarryFlag = 0
        end
    end

    return ProductResult
end

-- Convert hex string to table based on step
local function Hex2Tbl(HexStr)
    assert(type(HexStr) == "string")
    local HexTbl = {}
    local Index = 0

    HexStr = string.gsub(HexStr, '^[%s0xX]*([^%s].*[^%s])[%s]*$', "%1")
    repeat
        Index = Index + 1
        local StartIndex = #HexStr - HEX_STEP * Index + 1
        local EndIndex = #HexStr - HEX_STEP * Index + HEX_STEP
        
        StartIndex = StartIndex < 1 and 1 or StartIndex
        HexTbl[Index] = string.sub(HexStr,  StartIndex, EndIndex)
    until (Index * HEX_STEP > #HexStr)
    
    return HexTbl
end

-- Convert big integer data from hex to decimal
local function Hex2Decimal(HexStr)
    local DataValue = "0"
    local TempValue = "0"

    HexTbl = Hex2Tbl(HexStr)

    for Index, Data in ipairs(HexTbl) do

        TempValue = tostring(tonumber("0x" .. string.gsub(Data, '^[%s]*([^%s].*[^%s])[%s]*$', "%1")))
        for i = 2, Index do
            TempValue = BigInt_Mul(TempValue, tostring(tonumber(HEX_MOD)))
        end
        DataValue = BigInt_Add(DataValue, TempValue)
    end

    return DataValue
end

-- Concat the big integer from table to string
local function GetResult(DataTbl)
    local ValueTbl = {DataTbl[#DataTbl]}

    for i=#DataTbl-1, 1, -1 do
        table.insert(ValueTbl, string.format("%04d", DataTbl[i]))
    end

    return table.concat(ValueTbl, "")
end

-- Pressure connect test
function PRConntest()
    local TestValue = 0

    Shell("sensor --sel pressure --init")
    Shell("sensor --sel pressure --conntest")
    if Last.Output:match("test%-result:%s(%w+)%c") == "passed" then
        TestValue = 1
    end

    QT_ReportItemTestResult("PressureTestSuite", "Pressure_Connect_Test", TestValue)
end

-- Check Pressure vendor
function PRVendorCheck()
    local PRSensorID = 0
    local AvailableSensors = GetAvailableSensors()
    local VendorName = ""

    if (AvailableSensors["pressure"].Description:match("Meru") ~= nil) then
        PRSensorID = 8.0
    end

    VendorName = AvailableSensors["pressure"].Description:match("Description: ([%w]+).*Pressure%s")

    QT_ReportItemTestResult("PressureTestSuite", "Pressure_Vendor_Name", VendorName)
    QT_ReportItemTestResult("PressureTestSuite", "Sensor_ID", PRSensorID)
end

-- Pressure sample test
function PressureTest()
    Shell("sensor --sel pressure --init")
    Shell("sensor -s pressure --sample 2000ms --stats")

    for _, SampleItem in ipairs(PressureSampleMatchTbl) do
        QT_ReportItemTestResult("PressureTestSuite", SampleItem.Name, SampleItem.DataGain*tonumber(Last.Output:match(SampleItem.Pattern)))
    end
end

-- Pressure dump
function PR_Dumping()
    Shell("sensorreg -s pressure --dump")

    for Name, IDItem in pairs(gPRIDsMatchTbl) do
        IDItem.Value = Last.Output:match(IDItem.Pattern)
        QT_ReportItemTestResult("PressureTestSuite", Name, tonumber(IDItem.Value, 16))
    end
end

-- Get meru sn
function GetMeruSN()
    local HexMeruSN = ""

    Shell("sensor -s pressure -e nvm_read --testopts '0x21 3'")
    for Index, SNItem in ipairs(gPRSNsMatchTbl) do
        HexMeruSN = HexMeruSN .. Last.Output:match(SNItem.Pattern)
    end
    HexMeruSN = "0x"..gPRIDsMatchTbl["Manu_ID"].Value..gPRIDsMatchTbl["Chip_ID"].Value..gPRIDsMatchTbl["Rev_ID"].Value..HexMeruSN
    DecMeruSN = GetResult(Hex2Decimal(HexMeruSN))

    QT_ReportItemTestResult("PressureTestSuite", "Pressure_SN", DecMeruSN)
    QT_ReportItemAttribute("PRESSURE_SN", DecMeruSN)
end

-- Sensitivity error collected with ASIC self test mode
function PR_ASIC_selfTest()
    local ASIC_selfTest_100Kpa = ""
    local ASIC_selfTest_90Kpa = ""
    local ASIC_sensitivity = ""

    Shell("sensorreg -s pressure --write 0x12 0x03")
    Shell("sensor -s pressure --sample 30 --stats")
    ASIC_selfTest_100Kpa = Last.Output:match("average: pressure = ([%d.]+),")
    QT_ReportItemTestResult("PressureTestSuite", "ASIC_selfTest_100Kpa", 1000*tonumber(ASIC_selfTest_100Kpa))

    Shell("sensorreg -s pressure --write 0x12 0x02")
    Shell("sensor -s pressure --sample 30 --stats")
    ASIC_selfTest_90Kpa = Last.Output:match("average: pressure = ([%d.]+),")
    ASIC_sensitivity = ((ASIC_selfTest_100Kpa)/100.0-(ASIC_selfTest_90Kpa)/90.0)*(ASIC_selfTest_100Kpa)/((ASIC_selfTest_100Kpa)-(ASIC_selfTest_90Kpa))

    QT_ReportItemTestResult("PressureTestSuite", "ASIC_selfTest_90Kpa", 1000*tonumber(ASIC_selfTest_90Kpa))
    QT_ReportItemTestResult("PressureTestSuite", "ASIC_sensitivity", ASIC_sensitivity)

-- Reset sensor to turn off ASIC self test
    Shell("sensor --sel pressure --init")
end