-- BatteryERS base on D38 CRB battery ERS(2023/04/19).

-- BatteryERS
-- Data of BatteryERS are used to update BatteryPropertyInfo & BatteryCellVendor test item.
-- All data come from the ERS corresponding to the build stage of the corresponding project.
-- key of sub list bases on different Cell ID;
-- Pack_EEEE_Code bases on PACK EEEE code with same Cell ID and it must be a table;
-- Config_ID_Check bases on Config ID and its type is number;
-- DNVD1_Version_Check bases on DNVD1 ID and its type is number;
-- DNVD2_Version_Check bases on DNVD2 ID and its type is number;
-- PackConfig bases on Pack Config with same Cell ID and its type is string;
-- CellVendor bases on Cell Vendor and its type is string;

local BatteryERS = {
    ["1014342617"] = {
            Pack_EEEE_Code = {"00006U0", "00006GG", "000036R"},
            Config_ID_Check = 301018,
            DNVD1_Version_Check = 301011,
            DNVD2_Version_Check = 301016,
            PackConfig = "DEDCDGDNDPDBDKDLDM",
            CellVendor = "ATL",
    },

    ["1014493227"] = {
            Pack_EEEE_Code = {"000036P", "000036Q"},
            Config_ID_Check = 307011,
            DNVD1_Version_Check = 307006,
            DNVD2_Version_Check = 307009,
            PackConfig = "DADFDHDDDODQ",
            CellVendor = "LGES",
    },
}

function GetBatteryDataList(DataList)
    return BatteryERS[DataList]
end

local QmaxCheck = {
    [1] = {LowerLimit = 4246, UpperLimit = 5370}, -- Cycle count < 2
    [2] = {LowerLimit = 4158, UpperLimit = 5370}, -- Cycle count >= 2
}

function GetQmaxCheck(Index)
    return QmaxCheck[Index]
end

local WRaCheck = {
    [1] = {LowerLimit = 16, UpperLimit = 172}, -- Cycle count < 2
    [2] = {LowerLimit = 16, UpperLimit = 344}, -- Cycle count >= 2
}

function GetWRaCheck(Index)
    return WRaCheck[Index]
end

local BatteryTestItem = {}
BatteryTestItem.BatteryPropertyInfo = {
    {Name = "Cell_ID_Check",              SubName = "Info",  SpecType = "Equal", Units = nil, LowerLimit = nil,       UpperLimit = nil,       EqualTable = {"1013672617", "1014493227"},},
    {Name = "Cell_ID",                    SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
    {Name = "GG_Type",                    SubName = "Info",  SpecType = "Equal", Units = nil, LowerLimit = nil,       UpperLimit = nil,       EqualTable = {"Veridian"},},
    {Name = "Lifetime_Min_Voltage",       SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = 2335,      UpperLimit = 4495,      EqualTable = nil,},
    {Name = "Lifetime_Max_Voltage",       SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = 2335,      UpperLimit = 4495,      EqualTable = nil,},
    {Name = "Battery_Present",            SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = 3400,      UpperLimit = 4470,      EqualTable = nil,},
    {Name = "Current",                    SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
    {Name = "BMF_Firmware_Version_Check", SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = 109080021, UpperLimit = 109080021, EqualTable = nil,},
    {Name = "BMF_Firmware_Version",       SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
    {Name = "Config_ID",                  SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
    {Name = "DNVD1_Version",              SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
    {Name = "DNVD2_Version",              SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
    {Name = "Lifetime_Min_Temp",          SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = -20,       UpperLimit = 70,        EqualTable = nil,},
    {Name = "Lifetime_Max_Temp",          SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = -20,       UpperLimit = 70,        EqualTable = nil,},
    {Name = "Remaining_Capacity",         SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
    {Name = "Cycle_Count",                SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = 0,         UpperLimit = 5,         EqualTable = nil,},
    {Name = "Qmax_Capacity",              SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},  -- default value, need to update LowerLimit & UpperLimit based on Cycle count.
    {Name = "Design_Capacity",            SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
    {Name = "Nominal_Capacity",           SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = 4139,      UpperLimit = 4618,      EqualTable = nil,},
    {Name = "Charge_Percentage",          SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
    {Name = "Pack_EEEE_Code",             SubName = "Info",  SpecType = "Equal", Units = nil, LowerLimit = nil,       UpperLimit = nil,       EqualTable = {}, }, -- default value, need to update EqualTable based on Cell ID.
    {Name = "Config_ID_Check",            SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,}, -- default value, need to update LowerLimit & UpperLimit based on Cell ID.
    {Name = "DNVD1_Version_Check",        SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,}, -- default value, need to update LowerLimit & UpperLimit based on Cell ID.
    {Name = "DNVD2_Version_Check",        SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,}, -- default value, need to update LowerLimit & UpperLimit based on Cell ID.
}

BatteryTestItem.BatteryWRA = {
    {Name = "WRA", SubName = "Info",SpecType = "Range", Units = nil, LowerLimit = nil, UpperLimit = nil,  EqualTable = nil,}, -- default value, need to update LowerLimit & UpperLimit based on Cycle count.
}

BatteryTestItem.BatteryCellVendor = {
    {Name = "Cell_Vendor", SubName = "Info", SpecType = "Equal", Units = nil, LowerLimit = nil, UpperLimit = nil,  EqualTable = {"ATL", "LGES"},},
    {Name = "Pack_Config", SubName = "Info", SpecType = "Equal", Units = nil, LowerLimit = nil, UpperLimit = nil,  EqualTable = {"DEDCDGDNDPDBDKDLDM", "DADFDHDDDODQ"},},
}

BatteryTestItem.VeridianDataCheck = {
    {Name = "Veridian_Data_Check", SubName = "Status", SpecType = "Equal", Units = nil, LowerLimit = nil, UpperLimit = nil,
    EqualTable = {"20 00 00 00 00 55 CE AC E0 A3 EE 5C 7F FF 20 45 6E 90 84 6C 4A 37 E2 23 C0 A4 F4 A4 93 55 55 55 55"},},
}

function GetBatteryTestItem(TestItemName)
    return BatteryTestItem[TestItemName]
end