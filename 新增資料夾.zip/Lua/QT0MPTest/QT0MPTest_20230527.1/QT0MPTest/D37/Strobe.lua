---------------------------------------------------------
--  Yeti.
--  Tests related to Yeti.

require "Common"

-- Start ISP FW and LM3567 IC power on
local function StrobeSuiteSetup()
    -- Camisp Setup in a separate baseline function
    Shell "strobe -c LM3567 --power on"
end

local function StrobeSuiteOn()
    -- Movie model turn on
    Shell "strobe -c LM3567 -s led1 --mode Movie on"
    Shell "strobe -c LM3567 -s led2 --mode Movie on"
    Shell "strobe -c LM3567 -s led3 --mode Movie on"
    Shell "strobe -c LM3567 -s led4 --mode Movie on"
    Shell "strobe --write 0x0D 0x41"

    -- Turn the LED bright lowest
    Shell "strobe -c LM3567 -s led1 --set TorchCurrent 0"
    Shell "strobe -c LM3567 -s led2 --set TorchCurrent 0"
    Shell "strobe -c LM3567 -s led3 --set TorchCurrent 0"
    Shell "strobe -c LM3567 -s led4 --set TorchCurrent 0"

    -- Turn all led on
    Shell "strobe --write 0x01 0x1f"
    Shell "wait 100"
end

-- Make sure the LED and LED model is off 
local function StrobeSuiteOff()
    -- Turn all led off
    Shell "strobe -c LM3567 -s led1 --set LedEnable off"
    Shell "strobe -c LM3567 -s led2 --set LedEnable off"
    Shell "strobe -c LM3567 -s led3 --set LedEnable off"
    Shell "strobe -c LM3567 -s led4 --set LedEnable off"
end

-- Power off IC and LED
local function StrobeSuiteCleanup()
    -- Power off LM3567
    Shell "strobe -c LM3567 --power off"
end

function YetiNTCConnectivity()
    -- Be used to compare with correct value 6~13
    local ConValue = 0

    StrobeSuiteSetup()

    StrobeSuiteOff()

    StrobeSuiteOn()

    -- Read reg of Yeti to ensure Yeti is connect
    Shell "strobe --read 0x10"
    ConValue = tonumber(Last.Output:match("Reg%s*%w+:%s*(%w+)%c"), 16)
    QT_ReportItemTestResult("YetiCon", "Yeti_NTC_Connectivity", ConValue)

    StrobeSuiteCleanup()
end