---------------------------------------------------------------------------
-- Common.
-- This file contains common functions.

Universal = require 'Universal.14A'
local ProdName = PlatformInfo("PlatformName")
local TestItemSpecPath = ProdName.."TestItemSpec"
require(TestItemSpecPath)

-- Only process SpecType with string(default).
local function ReportStringData(TestName, Value)
    local ErrorMsg = "Error! The value of "..TestName.." is nil.(string to expect!)"
    
    PrintString("Hark, Station! Behold the data I present you!")
    if Value ~= nil then 
        ReportData(TestName, 1)
        PrintString(TestName..","..tostring(Value)..",string,default,nil")
    else
        ReportData(TestName, 0, nil, nil, nil, ErrorMsg)
        PrintString(TestName..",,string,default,nil")
    end 
end

-- Check whether the value is in the table.
local function CheckEqual(Value, EqualTable)
    for _,v in ipairs(EqualTable) do
        if Value == v then
            return true
        end
    end
    return false
end

-- Only process SpecType with equal
local function ReportEqualData(TestName, Value, EqualTable)
    local LimitStr = ""

    for i = 1,#EqualTable do
        LimitStr = LimitStr..tostring(EqualTable[i])
        if i ~= #EqualTable then
            LimitStr = LimitStr.."|"
        end
    end

    local ErrorMsg = "Error! The value of "..TestName.." is not equal to the Test Spec."
    local Result = CheckEqual(Value, EqualTable)

    PrintString("Hark, Station! Behold the data I present you!")
    if Result == false or Value == nil then
        ReportData(TestName, 0, nil, nil, nil, ErrorMsg)
    else
        ReportData(TestName, 1)
    end
    PrintString(TestName..","..tostring(Value)..",string,equal,"..LimitStr)
end

local function ReportLengthData(TestName, Value, EqualTable)
    local Length = #Value
    local LimitStr = ""

    for i = 1,#EqualTable do
        LimitStr = LimitStr..tostring(EqualTable[i])
        if i ~= #EqualTable then
            LimitStr = LimitStr.."|"
        end
    end

    local ErrorMsg = "Error! The value'length of "..TestName.." is not equal to the Test Spec."
    local Result = CheckEqual(Length, EqualTable)

    PrintString("Hark, Station! Behold the data I present you!")
    if Result == false or Value == nil then
        ReportData(TestName, 0, nil, nil, nil, ErrorMsg)
    else
        ReportData(TestName, 1)
    end
    PrintString(TestName..","..tostring(Value)..",string,length,"..LimitStr)
end

local function ReportMatchFailData(TestName, Value, EqualTable)
    local LimitStr = ""

    for i = 1,#EqualTable do
        LimitStr = LimitStr..tostring(EqualTable[i])
        if i ~= #EqualTable then
            LimitStr = LimitStr.."|"
        end
    end

    local ErrorMsgMatchFail = "Match Fail! The value of "..TestName.." is equal to the Test Spec."
    local ErrorMsgNil = "Error! The value of "..TestName.." is nil."
    local Result = CheckEqual(Value, EqualTable)

    PrintString("Hark, Station! Behold the data I present you!")
    if Result == false and Value ~= nil then
        ReportData(TestName, 1)
    end
    if Value == nil then
        ReportData(TestName, 0, nil, nil, nil, ErrorMsgNil)
    end
    if Result and Value ~= nil then
        ReportData(TestName, 0, nil, nil, nil, ErrorMsgMatchFail)
    end
    PrintString(TestName..","..tostring(Value)..",string,match_fail,"..LimitStr)
end

-- Only process SpecType with range.
local function ReportRangeData(TestName, Value, Units, LowerLimit, UpperLimit)
    local Result = false
    local ErrorMsg = "Error! The value of "..TestName.." is nil or not a number. It is a "..type(Value)

    if tonumber(Value) == nil then
        ReportData(TestName, 0, nil, nil, nil, ErrorMsg)
        PrintString("Hark, Station! Behold the data I present you!")
        PrintString(TestName..",nil,"..tostring(Units)..","..tostring(LowerLimit)..","..tostring(UpperLimit))
    else
        Universal:ReportDataToStationAndPDCA(TestName, Value, Units, LowerLimit, UpperLimit)
    end
end

-- According to the spec defined in AllTestItems, check the input Value with spec, print out the result
-- Print format should meet to QT0 station's require, Printing Format:
--   Range Type:  QTTestName,Value,Unit,LowerLimit,UpperLimit, eg:  Info_SOC_LEAKAGE_BIN,0.8,nil,0.5,2
--   String Type: QTTestName,Value,’string’,‘default’,’nil’, eg: Info_Soc_Type,B0,string,default,nil
--   Length Type: QTTestName,Value,’string’,‘length’,LimitSpec, eg: Info_Read_Touch_SIP_SN,FYJ25066009UCC03SE1760101D,string,length,26
--   Equal Type:  QTTestName,Value,’string’,‘equal’,LimitSpec, eg:Info_Pack_EEEE_Code,00005X3,string,equal,00005X3|00005X4|00005Z0
--   Match_fail Type: QTTestName,Value,’string’,‘match_fail’,LimitSpec,
--                    eg:Currently we don’t have this type in smokey, keep this type for QT station.
-- QTTestName = QTSubName_QTSubSubTestName, about detail, please see code and comments in function for var 'QTTestName'
-- @param TestItemName : The element name of AllTestItems in XXTestItemSpec.lua
-- @param TestName     : the value of AllTestItems[TestItemName][TestName], such as "Sakonnet_ID”(AudioInfo.Name)
-- @param Value        : the Value will be compared to the limit spec which was selected by ‘TestItemName’ and ‘TestName’
function QT_ReportItemTestResult(TestItemName, TestName, Value)
    local TestTable = GetTestItemTableFun(TestItemName)
    local IsGetTestName = false
    local QTSubName, QTSubSubTestName, QTTestName

    for _,v in ipairs(TestTable) do
        if TestName == v.Name then
            IsGetTestName = true

            if v.SubName == nil or v.Name == nil then
                error("Unable to get the SubName or Name of "..TestItemName.."/"..TestItemSpecPath..".lua; It is nil.")
            end

            QTSubName = v.SubName

            -- Update QTSubSubTestName.If v.SubSubTestName is nil, we take v.Name(TestName) as it's string
            if v.SubSubTestName == nil then
                QTSubSubTestName = v.Name
            else
                QTSubSubTestName = v.SubSubTestName
            end

            -- If QTSubName is "", will take QTSubSubTestName as QTTestName
            -- Else, we combine QTSubName_QTSubSubTestName as QTTestName and will print out QTTestName for QT station.
            if #tostring(QTSubName) == 0 then
                QTTestName = tostring(QTSubSubTestName)
            else
                QTTestName = tostring(QTSubName).."_"..tostring(QTSubSubTestName)
            end

            assert(#QTTestName <= 48 , "Insight allows a maximum of 48 characters for Test.")
            
            if v.SpecType == "String" then
                ReportStringData(QTTestName, Value)
                break
            elseif v.SpecType == "Length" then
                ReportLengthData(QTTestName, Value, v.EqualTable)
                break
            elseif v.SpecType == "Equal" then
                ReportEqualData(QTTestName, Value, v.EqualTable)
                break
            elseif v.SpecType == "MatchFail" then
                ReportMatchFailData(QTTestName, Value, v.EqualTable)
                break
            elseif v.SpecType == "Range" then
                ReportRangeData(QTTestName, Value, v.Units, v.LowerLimit, v.UpperLimit)
                break
            else
                error("Unable to get the SpecType of "..tostring(v.Name).." in "..TestItemName.."/"..TestItemSpecPath..".lua")
            end
        end    
    end

    if IsGetTestName == false then
        error("Unable to get the TestName : "..tostring(TestName).." in "..TestItemName.."/"..TestItemSpecPath..".lua")
    end
end

-- Report the attribute value and print out,then QT overlay can catch the output and upload it to Insight when overlay run smokey script.
function QT_ReportItemAttribute(AttributeName, AttributeValue)
    if AttributeValue ~= nil then
        PrintString("(RX ==> Attribute):".."["..AttributeName.."]=["..tostring(AttributeValue).."]")
        ReportAttribute(AttributeName, AttributeValue)
    else
        PrintString("(RX ==> Attribute):".."["..AttributeName.."]=[nil]")
    end
end

-- According to the rules of the table 'ProxNVMMap', parse the data of prox nvm dump and store it in a table.
-- @param  NVMArray : Table to store prox nvm dump data.
-- @param  Address  : Register Address to store the required prox nvm dump data.
-- @param  Bit     : The bits required after the Address data is converted to binary bits.
-- @return : Return parsed data.
function QT_GetNvmValue(NVMArray, Address, Bit)
    local AddressArray, StartByte, EndByte
    local BitArray, StartBit, EndBit
    local Result = ''
    local Step = 0

    if Address == "" then
        return "0"
    end

    assert(Bit == '' or Bit:match(":"), "Bit format is not correct")
    AddressArray = Universal.SplitString(Address, ":")
    StartByte = tonumber(AddressArray[1], 16)
    EndByte = (AddressArray[2] == nil) and tonumber(Address, 16) or tonumber(AddressArray[2], 16)
    Step = (EndByte >= StartByte) and 1 or -1

    for i = StartByte, EndByte, Step do
        Result = Result..string.format("%02x", NVMArray[i + 1])
    end

    if (Bit == '') then
        return Result
    else
        BitArray = Universal.SplitString(Bit, ":")
        StartBit = tonumber(BitArray[1])
        EndBit = tonumber(BitArray[2])
        assert(StartBit <= EndBit,  "StartBit big then EndBit")
        return bit32.extract(tonumber("0x"..Result), StartBit, EndBit - StartBit + 1)
    end
end