---------------------------------------------------------------------------
-- Audio.
-- This file contains Audio tests.
---------------------------------------------------------------------------

-- Verify I2C comms with Sakonnet by reading back Device ID
function SakonnetId()

    local SakonnetChipId, SakonnetChipIdDecimal

    -- Read the device ID from Sakonnet
    Shell("i2c -x -d 7 0x08 0x0 1")

    SakonnetChipId = string.match(Last.Output, "00000000:%s+(%x+)")
    SakonnetChipIdDecimal = tonumber(SakonnetChipId, 16)

    -- Report Data to station
    QT_ReportItemTestResult("AudioInfo", "Sakonnet_ID", SakonnetChipIdDecimal)
    QT_ReportItemAttribute("SAK_CHIP_ID", SakonnetChipIdDecimal)

end

-- Verify I2C comms with Sakonnet by reading back Device Rev
function SakonnetRevision()

    local SakonnetChipRev, SakonnetChipRevDecimal

    -- Read the device Rev from Sakonnet
    Shell("i2c -x -d 7 0x08 0x01 1")

    SakonnetChipRev = string.match(Last.Output, "00000001:%s+(%x+)")
    SakonnetChipRevDecimal = tonumber(SakonnetChipRev, 16)

    -- Report Data to station
    QT_ReportItemTestResult("AudioInfo", "Sakonnet_Revision", SakonnetChipRevDecimal)
    QT_ReportItemAttribute("SAK_CHIP_REV", SakonnetChipRevDecimal)

end