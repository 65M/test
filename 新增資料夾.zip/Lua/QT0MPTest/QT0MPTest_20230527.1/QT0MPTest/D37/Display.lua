require "Common"

local PlatName = PlatformInfo("PlatformName")
local gIsD3x = (PlatName == "D37") or (PlatName == "D38")
local gIsD8x = (PlatName == "D83") or (PlatName == "D84")
local gDisplayEFITime = nil

local LCMNameTable = {
    [0x61] = "BOE",
    [0x62] = "BOE",
    [0x99] = "LGD",
    [0xEE] = "SDC",
    [0xE8] = "SDC",
    [0x00] = "UNKNOWN",
}

local DICIdTable = {
    ["LGD"] = {"0x31","0x32"},
    ["SDC"] = {"0x38","0x3A"},
    ["UNKNOWN"] = {"UNKNOWN"},
}

-- Save Reg 0x0000 vaule as Read_Panel_ID
function ReadPanelID()
    local LCMType = 0
    local DICId = 0
    local DisplayData = {}
    local DisplayDataStr = ''
    local DICIdLimitSpec = 0

    Shell("display --on")

    if (gIsD3x) then
        Shell("mipi -r 0x14 0xb1")
        LCMType = tonumber(Last.Output:match("0x%x+ (0x%x+)"))
        DisplayData = Last.Output:gmatch(" 0x(%w+)")
    else
        Shell("dptx --auxwrite dpcd 0x4e0 0xB2 0")
        Shell("dptx --auxwrite dpcd 0x4f0 0x00")
        Shell("dptx --auxwrite dpcd 0x4e0 0xB1 0")
        Shell("dptx --auxread dpcd 0x4f0 16")

        LCMType = tonumber(Last.Output:match("0x0000: 0x%x+ (0x%x+)"))
        DICId = Last.Output:match("0x0000: 0x%x+ 0x%x+ 0x%x+ (0x%x+)")
        DisplayData = Last.Output:gmatch(" 0x(%x+)")

        Shell("dptx --auxwrite dpcd 0x4e0 0xB2 0")
        Shell("dptx --auxwrite dpcd 0x4f0 0xFF")
    end

    for Data in DisplayData do
        DisplayDataStr = DisplayDataStr..tostring(Data)..' '
    end
    DisplayDataStr = DisplayDataStr:match("^(.-)%s*$")

    QT_ReportItemTestResult("DisplayTestStuite", "Read_Panel_ID", DisplayDataStr)
    QT_ReportItemAttribute("PANEL_ID", DisplayDataStr)

    -- 2nd byte of dptx --auxread dpcd 0x4f0 16 cmd returned Reg 0x0000
    -- Reg 0x0000 is 0x99, LCM_Vendor_Name is LGD; if it is 0xEE, LCM_Vendor_Name is SDC.
    QT_ReportItemTestResult("DisplayTestStuite", "LCM_Vendor_Name", LCMNameTable[LCMType])
    QT_ReportItemAttribute("LCM_VENDOR_NAME", LCMNameTable[LCMType])

    -- DIC_Vendor_ID is 4th byte of dptx --auxread dpcd 0x4f0 16 cmd returned Reg 0x0000
    -- If LCM_Vendor_Name is LGD, DIC_Vendor_ID spec should be 0x31 or 0x32.
    -- If LCM_Vendor_Name is SDC, it should be 0x38 or 0x3A.
    if (gIsD8x) then
        if DICIdTable[LCMNameTable[LCMType]] == nil then
            DICIdLimitSpec = DICIdTable["UNKNOWN"]
        else
            DICIdLimitSpec = DICIdTable[LCMNameTable[LCMType]]
        end

        for _,v in ipairs(GetTestItemTableFun("DisplayTestStuite")) do
            if v.Name == "DIC_Vendor_ID" then
                for _,value in ipairs(DICIdTable[LCMNameTable[LCMType]]) do
                    table.insert(v.EqualTable,value)
                end
                break
            end
        end
        QT_ReportItemTestResult("DisplayTestStuite", "DIC_Vendor_ID", DICId)
    end
end

-- Read_Panel_OUI_Decimal
-- Convert cmd retured Hex value to Decimal
-- For example:(RX ==> Dut):dptx --auxread dpcd 0x400 3
-- Aux Data RX:0x0000: 0x00 0x10 0xFA ----> Convert 0x0010FA to 4346
function ReadPanelOUIDecimal()
    local HexData = ''

    if gIsD8x then
        Shell("dptx --auxread dpcd 0x400 3")
        for Data in Last.Output:gmatch("0x(%x+)") do
            HexData = HexData..tostring(Data)
        end

        QT_ReportItemTestResult("DisplayTestStuite", "Read_Panel_OUI_Decimal_Check", tostring(tonumber("0x"..HexData)))
        QT_ReportItemTestResult("DisplayTestStuite", "Read_Panel_OUI_Decimal", tonumber("0x"..HexData))
    end
end

-- Extract String, For example:
------------------------------------------------------------------------------
-- :-) i2c -x -z 2 --devread 3 0x51 0x0644 0x02
-- Reading 2 bytes from register offset 0x644 into 0x5FCF7498, buffer read:
-- Data:
-- 00000644: 0C 58
------------------------------------------------------------------------------
-- LastOutputHex:
-- 00000644: 0C 58
------------------------------------------------------------------------------
-- LastOutputHexSlip: 0C 58
------------------------------------------------------------------------------
local function ExtractStr(LastOutput)
    local LastOutputHex = LastOutput:match("%w+: (.+)[\r\n]*")
    local LastOutputHexSlip = LastOutputHex:gmatch(" (%w+)")

    return LastOutputHexSlip
end

-- Read_Touch_SIP_SN
-- Decode Touch_SIP_SN by converting 26 bytes Hex value to ASCII code
function ReadTouchSIPSN()
    local Length = 0
    local SipSnAscii = ''

    Shell("i2c -x -z 2 --devread 3 0x51 0x40 26")
    for Data in ExtractStr(Last.Output) do
        SipSnAscii = SipSnAscii..string.char(tonumber(Data,16))
    end

    QT_ReportItemTestResult("DisplayTestStuite", "Read_Touch_SIP_SN", SipSnAscii)
    QT_ReportItemAttribute("TOUCH_SIP_SN", SipSnAscii)
end

-- LCM_MP9_Temp
-- Convert 2 bytes Hex value to Decimal, then divided by 100
function LCMMP9Temp()
    local TempData = ''
    local DivisorValue = 100

    Shell("i2c -x -z 2 --devread 3 0x51 0x0644 0x02")
    for Data in ExtractStr(Last.Output) do
        TempData = TempData..Data
    end

    QT_ReportItemTestResult("DisplayTestStuite", "LCM_MP9_Temp", tonumber(TempData,16)/DivisorValue)
    QT_ReportItemAttribute("LCM_MP9_TEMP", tonumber(TempData,16)/DivisorValue)
end

-- LCM_10nit_W51_LL_RG_ideal
-- LCM_10nit_W51_LL_R_ideal: Convert first 4 bytes Hex value to Decimal, then divided by 16777216
-- LCM_10nit_W51_LL_G_ideal: Convert last 4 bytes Hex value to Decimal, then divided by 16777216
function LCM10nitW51LLRGIdeal()
    local Index = 1
    local LCMW51LLR = ''
    local LCMW51LLG = ''
    local DivisorValue = 16777216

    Shell("i2c -x -z 2 --devread 3 0x51 0x0646 0x08")
    for Data in ExtractStr(Last.Output) do
        if Index > 4 then
            LCMW51LLG = LCMW51LLG..Data
        else
            LCMW51LLR = LCMW51LLR..Data
        end
        Index = Index + 1
    end

    QT_ReportItemTestResult("DisplayTestStuite", "LCM_10nit_W51_LL_R_ideal", tonumber(LCMW51LLR,16)/DivisorValue)
    QT_ReportItemAttribute("LCM_10nit_W51_LL_R_ideal", tonumber(LCMW51LLR,16)/DivisorValue)
    QT_ReportItemTestResult("DisplayTestStuite", "LCM_10nit_W51_LL_G_ideal", tonumber(LCMW51LLG,16)/DivisorValue)
    QT_ReportItemAttribute("LCM_10nit_W51_LL_G_ideal", tonumber(LCMW51LLG,16)/DivisorValue)
end

-- LCM_MP9_FFR_Frequency
-- Convert first 4 bytes Hex value to Decimal, then divided by 16777216
function LCMMP9FFRFrequency()
    local Index = 1
    local LCMFrequencyData = ''
    local DivisorValue = 16777216

    Shell("i2c -x -z 2 --devread 3 0x51 0x064E 0x08")
    for Data in ExtractStr(Last.Output) do
        if Index > 4 then
            break
        end
        LCMFrequencyData = LCMFrequencyData..Data
        Index = Index + 1
    end

    QT_ReportItemTestResult("DisplayTestStuite", "LCM_MP9_FFR_Frequency", tonumber(LCMFrequencyData,16)/DivisorValue)
    QT_ReportItemAttribute("LCM_MP9_FFR_Frequency", tonumber(LCMFrequencyData,16)/DivisorValue)
end

-- LCM_ACVRR
-- Convert first 4 bytes Hex value to Decimal, then divided by 16777216
function LCMACVRR()
    local LCMACVRRData = ''
    local DivisorValue = 16777216

    Shell("i2c -x -z 2 --devread 3 0x51 0x0656 0x04")
    for Data in ExtractStr(Last.Output) do
        LCMACVRRData = LCMACVRRData..Data
    end

    QT_ReportItemTestResult("DisplayTestStuite", "LCM_ACVRR", tonumber(LCMACVRRData,16)/DivisorValue)
    QT_ReportItemAttribute("LCM_ACVRR", tonumber(LCMACVRRData,16)/DivisorValue)
end

-- PMIC_Version_Check
-- Convert first 4 bytes Hex value to Decimal
function PMICVersionCheck()
    local PMICVersion = ''
    local PMICVersionTable = {}

    if gIsD8x then
        Shell("dptx --auxwrite dpcd 0x4e0 0x51 0x00")
        Shell("dptx --auxwrite dpcd 0x4f4 0xff 0x56 0x04")
    else
        Shell("bl --nits 650")
    end

    Shell("pattern --fill 0x000000")
    Shell("i2c -x -d 11 0x0 0xc 1")
    for Data in ExtractStr(Last.Output) do
        PMICVersion = PMICVersion..Data
    end

    QT_ReportItemTestResult("DisplayTestStuite", "PMIC_Version_Check", tostring(tonumber(PMICVersion,16)))
end

-- Get hidd_nonui on_time EFI
function HiddNouUIOnTimeEFI()
    Shell("display --off")
    Shell("nvram --get display_EFI")
    gDisplayEFITime = Last.Output:match("display_EFI%s-=%s-(%d+)")

    QT_ReportItemTestResult("HiddNouUIOnTime", "Hidd_Nonui_On_Time_EFI", tonumber(gDisplayEFITime)) 
end

-- Get hidd_nonui on_time NonUI
function HiddNouUIOnTimeNonUI()
    local DisplayNonUITime = nil

    Shell("nvram --get display_nonUI")
    DisplayNonUITime = Last.Output:match("display_nonUI%s-=%s-(%d+)")
    QT_ReportItemTestResult("HiddNouUIOnTime", "Hidd_Nonui_On_Time_NonUI", tonumber(DisplayNonUITime))

    Shell("i2c -x -z 2 -d 3 0x51 0x3982 192")
    Shell("display --on")

    QT_ReportItemTestResult("HiddNouUIOnTime", "CG_ON_TotalTime", tonumber(gDisplayEFITime + DisplayNonUITime))
end