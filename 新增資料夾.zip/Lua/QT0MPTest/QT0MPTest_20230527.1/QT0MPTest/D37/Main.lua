---------------------------------------------------------------------------
-- Main.
-- Main lua file for QT0 MP Coverage test scripts.

require "Common"
require "Audio"
require "Pmu"
require "Stockholm"
require "Prox"
require "Nand"
require "Camera"
require "Display"
require "Battery"
require "Scarif"
require "Pressure"
require "ALS"
require "Strobe"
require "Compass"