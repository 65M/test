---------------------------------------------------------------------------
-- Display
-- This file contains Display related tests, structures and functions.

require "Common"

local function SetEqualTable(Name, Table)
    for _, item in ipairs(GetTestItemTableFun("Display")) do
        if item.Name == Name then
            item.EqualTable = Table
            break
        end
    end
end

function ReadPanelId()
    local PanelID
    local LCMVendorName
    local DICVendorID
    local PanelIDStr = ''
    local LCMVendor = ''

    Shell("display --on")
    Shell("mipi -r 0x14 0xb1")

    -- D84
    -- Shell("dptx --auxwrite dpcd 0x4e0 0xB2 0")
    -- Shell("dptx --auxwrite dpcd 0x4f0 0x00")
    -- Shell("dptx --auxwrite dpcd 0x4e0 0xB1 0")
    -- Shell("dptx --auxread dpcd 0x4f0 16")

    -- D84
    -- LCM_Vendor_Name is 2nd byte of dptx --auxread dpcd 0x4f0 16 cmd returned Reg 0x0000
    -- DIC_Vendor_ID is 4th byte of dptx --auxread dpcd 0x4f0 16 cmd returned Reg 0x0000
    -- PanelID = Last.Output:match("0x0000: (.-)\n"):gmatch(("0x(%x+)"))
    -- LCMVendorName, DICVendorID = Last.Output:match("0x0000: 0x%x+ (0x%x+) 0x%x+ (0x%x+)")

    -- D84
    -- Shell("dptx --auxwrite dpcd 0x4e0 0xB2 0")
    -- Shell("dptx --auxwrite dpcd 0x4f0 0xFF")

    -- D37
    -- LCM_Vendor_Name is 2nd byte of dptx --auxread dpcd 0x4f0 16 cmd returned Reg 0x0000
    -- DIC_Vendor_ID is 4th byte of dptx --auxread dpcd 0x4f0 16 cmd returned Reg 0x0000
    PanelID = Last.Output:gmatch(("0x(%x+)"))
    LCMVendorName, DICVendorID = Last.Output:match("0x%x+ (0x%x+) 0x%x+ (0x%x+)")

    -- Panel ID
    for Value in PanelID do
        PanelIDStr = PanelIDStr..Value..' '
    end
    PanelIDStr = PanelIDStr:match("^(.-)%s*$")

    -- If LCMVendorData is 0x99, LCM_Vendor_Name is LGD; if it is 0xEE, LCM_Vendor_Name is SDC.
    -- If LCM_Vendor_Name is LGD, DIC_Vendor_ID spec should be 0x31 or 0x32.
    -- If LCM_Vendor_Name is SDC, DIC_Vendor_ID spec should be 0x38 or 0x3A.
    if LCMVendorName == "0x99" then
        LCMVendor = "LGD"
        SetEqualTable("DIC_Vendor_ID", {"0x31", "0x32"})
    elseif LCMVendorName == "0xEE" or LCMVendorName == "0xE8" then
        LCMVendor = "SDC"
        SetEqualTable("DIC_Vendor_ID", {"0x38", "0x3A"})
    else
        LCMVendor = "UNKNOWN"
        SetEqualTable("DIC_Vendor_ID", {"UNKNOWN"})
    end

    QT_ReportItemTestResult("Display", "Read_Panel_ID", PanelIDStr)
    QT_ReportItemAttribute("PANEL_ID", PanelIDStr)
    QT_ReportItemTestResult("Display", "LCM_Vendor_Name", LCMVendor)
    QT_ReportItemAttribute("LCM_Vendor_Name", LCMVendor)
    QT_ReportItemTestResult("Display", "DIC_Vendor_ID", DICVendorID)
    QT_ReportItemAttribute("DIC_Vendor_ID", DICVendorID)
end

-- function ReadPanelOUIDecimal()
--     local Result = ''

--     Shell("dptx --auxread dpcd 0x400 3")
--     for Value in Last.Output:match("0x0000: (.-)\n"):gmatch(("0x(%x+)")) do
--         Result = Result..Value
--     end

--     QT_ReportItemTestResult("Display", "Read_Panel_OUI_Decimal_Check", tonumber("0x"..Result))
--     QT_ReportItemTestResult("Display", "Read_Panel_OUI_Decimal", tonumber("0x"..Result))
-- end

function ReadTouchSIPSN()
    local Result = ''

    Shell("i2c -x -z 2 --devread 3 0x51 0x40 26")

    -- Decode Touch_SIP_SN by converting 26 bytes Hex value to ASCII code
    for Value in Last.Output:match("Data: \n*(.+)"):gmatch(" (%x+)") do
        Result = Result..string.format("%c", tonumber("0x"..Value))
    end

    QT_ReportItemTestResult("Display", "Read_Touch_SIP_SN", Result)
    QT_ReportItemAttribute("Read_Touch_SIP_SN", Result)
end

function LCMMP9Temp()
    local Result = ''

    Shell("i2c -x -z 2 --devread 3 0x51 0x0644 0x02")

    -- Convert cmd retured Hex value to Decimal
    for Value in Last.Output:match("Data: \n*(.+)"):gmatch(" (%x+)") do
        Result = Result..Value
    end

    -- Convert 2 bytes Hex value to Decimal, then divided by 100
    QT_ReportItemTestResult("Display", "LCM_MP9_Temp", tonumber("0x"..Result) / 100.0)
    QT_ReportItemAttribute("LCM_MP9_Temp", tonumber("0x"..Result) / 100.0)
end

function LCM10nitW51LLRGideal()
    local Result = ''
    local RIdeal = nil
    local LIdeal = nil

    Shell("i2c -x -z 2 --devread 3 0x51 0x0646 0x08")
    for Value in Last.Output:match("Data: \n*(.+)"):gmatch(" (%x+)") do
        Result = Result..Value
    end

    -- LCM_10nit_W51_LL_R_ideal: Convert first 4 bytes Hex value to Decimal, then divided by 16777216
    -- LCM_10nit_W51_LL_G_ideal: Convert last 4 bytes Hex value to Decimal, then divided by 16777216
    RIdeal = tonumber("0x"..string.sub(Result, 1, 8)) / 16777216
    LIdeal = tonumber("0x"..string.sub(Result, -8)) / 16777216

    QT_ReportItemTestResult("Display", "LCM_10nit_W51_LL_R_ideal", RIdeal)
    QT_ReportItemAttribute("LCM_10nit_W51_LL_G_ideal", RIdeal)
    QT_ReportItemTestResult("Display", "LCM_10nit_W51_LL_G_ideal", LIdeal)
    QT_ReportItemAttribute("LCM_10nit_W51_LL_G_ideal", LIdeal)
end

function LCMMP9FFRFrequency()
    local Result = ''

    Shell("i2c -x -z 2 --devread 3 0x51 0x064E 0x08")
    for Value in Last.Output:match("Data: \n*(.+)"):gmatch(" (%x+)") do
        Result = Result..Value
    end

    -- Convert first 4 bytes Hex value to Decimal, then divided by 16777216
    QT_ReportItemTestResult("Display", "LCM_MP9_FFR_Frequency", tonumber("0x"..string.sub(Result, 1, 8)) / 16777216)
    QT_ReportItemAttribute("LCM_MP9_FFR_Frequency", tonumber("0x"..string.sub(Result, 1, 8)) / 16777216)
end

function LCMACVRR()
    local Result = ''

    Shell("i2c -x -z 2 --devread 3 0x51 0x0656 0x04")
    for Value in Last.Output:match("Data: \n*(.+)"):gmatch(" (%x+)") do
        Result = Result..Value
    end

    -- Convert first 4 bytes Hex value to Decimal, then divided by 16777216
    QT_ReportItemTestResult("Display", "LCM_ACVRR", tonumber("0x"..string.sub(Result, 1, 8)) / 16777216)
    QT_ReportItemAttribute("LCM_ACVRR", tonumber("0x"..string.sub(Result, 1, 8)) / 16777216)
end

function CheckPMICVersion()
    -- D84
    -- Shell("dptx --auxwrite dpcd 0x4e0 0x51 0x00")
    -- Shell("dptx --auxwrite dpcd 0x4f4 0xff 0x56 0x04")

    Shell("bl --nits 650")
    Shell("Pattern --fill 0x000000")
    Shell("i2c -x -d 11 0x0 0xc 1")

    QT_ReportItemTestResult("Display", "PMIC_Version_Check", tonumber("0x"..Last.Output:match("%x+: (%x+)")))
end