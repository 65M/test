---------------------------------------------------------------------------
-- Nand.
-- This file contains Nand related tests, structures and functions.

local ProNameTemp = (PlatformInfo("PlatformName") == "D37" or PlatformInfo("PlatformName") == "D38") and "D3y" or "D8x"

local WD_SanDisk_Sandisk = {
    D3y = {
            {capacity = "128GB",  nandid = "0x0000E47603983E45", nandSize = "0x07735940", diename = nil },
            {capacity = "256GB",  nandid = "0x0000E47603983E45", nandSize = "0x0EE6B280", diename = nil },
            {capacity = "512GB",  nandid = "0x0000E47603983E45", nandSize = "0x1DCD6500", diename = nil },
        },
    D8x = {
            {capacity = "128GB",  nandid = "0x0000E47603983E45", nandSize = "0x07735940", diename = nil },
            {capacity = "256GB",  nandid = "0x0000E47603983E45", nandSize = "0x0EE6B280", diename = nil },
            {capacity = "512GB",  nandid = "0x0000E47603983E45", nandSize = "0x1DCD6500", diename = nil },
        },
}

local Kioxia_Toshiba = {
    D3y = {
            {capacity = "128GB",  nandid = "0x0000E47603983E98", nandSize = "0x07735940", diename = nil },
            {capacity = "256GB",  nandid = "0x0000E47603983E98", nandSize = "0x0EE6B280", diename = nil },
            {capacity = "512GB",  nandid = "0x0000E47603983E98", nandSize = "0x1DCD6500", diename = nil },
        },
    D8x = {
            {capacity = "128GB",  nandid = "0x0000E47603983E98", nandSize = "0x07735940", diename = nil },
            {capacity = "256GB",  nandid = "0x0000E47603983E98", nandSize = "0x0EE6B280", diename = nil },
            {capacity = "512GB",  nandid = "0x0000E47603983E98", nandSize = "0x1DCD6500", diename = nil },
            {capacity = "1TB",    nandid = "0x0000E57A03A84898", nandSize = "0x3B9ACA00", diename = nil },
        },
}

local Samsung = {
    D3y = {
            {capacity = "128GB",  nandid = "0x0000CD84AF985EEC", nandSize = "0x07735940", diename = nil },
            {capacity = "256GB",  nandid = "0x0000CD84AF985EEC", nandSize = "0x0EE6B280", diename = nil },
            {capacity = "512GB",  nandid = "0x0000CD84AF985EEC", nandSize = "0x1DCD6500", diename = nil },
        },
    D8x = {
            {capacity = "512GB",  nandid = "0x0000CD84AF985EEC", nandSize = "0x1DCD6500", diename = nil },
        },
}

local Hynix = {
    D3y = {
            {capacity = "128GB",  nandid = "0x0000C2000B287EAD", nandSize = "0x07735940", diename = nil },
            {capacity = "256GB",  nandid = "0x0000C2000B287EAD", nandSize = "0x0EE6B280", diename = nil },
            {capacity = "512GB",  nandid = "0x0000C2000B287EAD", nandSize = "0x1DCD6500", diename = nil },
        },
    D8x = {
            {capacity = "128GB",  nandid = "0x0000C2000B287EAD", nandSize = "0x07735940", diename = nil },
            {capacity = "256GB",  nandid = "0x0000C2000B287EAD", nandSize = "0x0EE6B280", diename = nil },
            {capacity = "512GB",  nandid = "0x0000C2000B287EAD", nandSize = "0x1DCD6500", diename = nil },
            {capacity = "1TB",    nandid = "0x0000C2000B297EAD", nandSize = "0x3B9ACA00", diename = "3d_v7" },
            {capacity = "1TB",    nandid = "0x0000D2003B297EAD", nandSize = "0x3B9ACA00", diename = "3d_v8" },
        },
}

local GetNandIDList = {
    {Name = "WD",       Value = WD_SanDisk_Sandisk[ProNameTemp],},
    {Name = "SanDisk",  Value = WD_SanDisk_Sandisk[ProNameTemp],},
    {Name = "Sandisk",  Value = WD_SanDisk_Sandisk[ProNameTemp],},
    {Name = "Kioxia",   Value = Kioxia_Toshiba[ProNameTemp],},
    {Name = "Toshiba",  Value = Kioxia_Toshiba[ProNameTemp],},
    {Name = "Samsung",  Value = Samsung[ProNameTemp],},
    {Name = "Hynix",    Value = Hynix[ProNameTemp],},
}

local NandIdentifyTestList = {
    Model_Number = {Pattern = " Model number%s*: (%u+%s+%u+%s+%w+)", Value = nil, AttributeName = "NAND Model Number",},
    FW_Revision  = {Pattern = " Firmware version%s*: ([^%s]+)",      Value = nil, AttributeName = "NAND FW Revision", },
    MSP_Revision = {Pattern = " MSP revision%s*: ([^%s]+)",          Value = nil, AttributeName = "NAND MSP Revision",},
}

local NANDInfoToolTestList = {
    PRODUCTION_FW_VERSION = {Pattern = "Prod FW Version:%s*([^%s]+)", Value = nil, AttributeName = "NAND PRODUCTION FW VERSION",},
    VENDOR                = {Pattern = "Vendor:%s*(%a+)",             Value = nil, AttributeName = "NAND Vendor",               },
    Cell_Type             = {Pattern = "Cell Type:%s*(%a+)",          Value = nil, AttributeName = "NAND Cell Type",            },
    Capacity              = {Pattern = "Capacity:%s*(%w+)",           Value = nil, AttributeName = "NAND Capacity",             },
    Die_Name              = {Pattern = "Die Name:%s*([^%s]+)",        Value = nil, AttributeName = "NAND Die Name",             },
    CHIP_ID               = {Pattern = "Chip ID:%s*(%w+)",            Value = nil, AttributeName = nil,                         },
}

local function PrintResult(TestName, SubList)
    QT_ReportItemTestResult("NandInfo", TestName, SubList.Value)
    if SubList.AttributeName ~= nil then
        QT_ReportItemAttribute(SubList.AttributeName, SubList.Value)
    end
end

-- Item17: NAND_Info
function NandInfo()
    Shell("nand --get Identify")
    for TestName,SubList in pairs(NandIdentifyTestList) do
        SubList.Value = string.match(Last.Output, SubList.Pattern)
        PrintResult(TestName, SubList)
    end

    Shell("NANDInfoTool")
    for TestName,SubList in pairs(NANDInfoToolTestList) do
        SubList.Value = string.match(Last.Output, SubList.Pattern)
        PrintResult(TestName, SubList)
    end

    Shell("nanduid")
    local UID = Last.Output:match("Result:%s*(%a+)")
    QT_ReportItemTestResult("NandInfo", "UID", UID)

    for line in string.gmatch(Last.Output, "[^\r\n]+") do
        local Index1, Index2, Value
        Index1, Index2, Value = line:match("MSP 0 CH (%d) Die (%d):%s*([%w%s]+)%s")
        if Value ~= nil then
            QT_ReportItemAttribute("NANDUID_MSP0_CH"..Index1.."_DIE"..Index2, Value)
        end
    end
end

-- Item18: NAND_ID
function NandID()
    local NandIDTable = {}
    local NandCapacityTemp, NandIDTemp, NandID
    local DieNameTemp = NANDInfoToolTestList["Die_Name"].Value:match("tlc_(%w+_%w+)_")
    local NandVendorTemp = NANDInfoToolTestList["VENDOR"].Value

    if NANDInfoToolTestList["Capacity"].Value == "1024GB" then
        NandCapacityTemp = "1TB"
    else
        NandCapacityTemp = NANDInfoToolTestList["Capacity"].Value
    end

    Shell("nandcsid")

    NandID = Last.Output:match("FCE0%s*=%s*(%w+)")
    for _,v in pairs(GetNandIDList) do
        if NandVendorTemp == v.Name then
            NandIDTable = v.Value
        end
    end

    for _,v in ipairs(NandIDTable) do
        if NandCapacityTemp == v.capacity then
            if v.diename and DieNameTemp == v.diename then
                NandIDTemp = v.nandid
                break
            end
            if NandVendorTemp ~= "Hynix" or NandCapacityTemp ~= "1TB" then
                NandIDTemp = v.nandid
                break
            end
        end
    end

    GetTestItemTableFun("NandId")[1].Name = GetTestItemTableFun("NandId")[1].Name.."_"..NandVendorTemp
    table.insert(GetTestItemTableFun("NandId")[1].EqualTable, NandIDTemp)

    QT_ReportItemTestResult("NandId", "ID_"..NandVendorTemp, NandID)
    QT_ReportItemAttribute("NAND ID", NandID)
end

-- Item19: NAND_Controller_UID
function NandControllerUID()
    local Controller_UID

    Shell("ASPTool --controller_uid")
    Controller_UID = Last.Output:match("%[0%]%s*controller_uid%s*(%w+)")
    QT_ReportItemTestResult("NandControllerUID", "Controller_UID", Controller_UID)
    QT_ReportItemAttribute("NAND Controller UID", Controller_UID)
end

-- Item20: Nand_Debug_Log
function NandDebugLog()
    Shell("upy nandfs:AppleInternal\\Diags\\Python\\lib\\test\\storage_nand.py -d")
    Shell("nand --debugread 0xA06")
    Shell("ASPTool --mspBootInfo")
end
