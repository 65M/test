---------------------------------------------------------------------------
-- D84TestItem.
-- D84TestItem lua file for QT0 MP Coverage scripts.
local ProductName = PlatformInfo("PlatformName")
require("BatteryERS"..ProductName)
require("CameraTestSpec"..ProductName)

local AllTestItems = {

    NandInfo = {
        {Name = "Model_Number",          SubName = "Info", SpecType = "String", Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = nil,},
        {Name = "FW_Revision",           SubName = "Info", SpecType = "String", Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = nil,},
        {Name = "MSP_Revision",          SubName = "Info", SpecType = "String", Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = nil,},
        {Name = "PRODUCTION_FW_VERSION", SubName = "Info", SpecType = "String", Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = nil,},
        {Name = "VENDOR",                SubName = "Info", SpecType = "Equal",  Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = {"WD", "SanDisk", "Sandisk", "Kioxia", "Toshiba", "Samsung", "Hynix"},},
        {Name = "Cell_Type",             SubName = "Info", SpecType = "String", Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = nil,},
        {Name = "Capacity",              SubName = "Info", SpecType = "Equal",  Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = {"128GB", "256GB", "512GB", "1024GB", "1TB"},},
        {Name = "Die_Name",              SubName = "Info", SpecType = "String", Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = nil,},
        {Name = "CHIP_ID",               SubName = "Info", SpecType = "String", Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = nil,},
        {Name = "UID",                   SubName = "Info", SpecType = "Equal",  Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = {"Pass"},},
    },

    NandId = {
        {Name = "ID", SubName = "Info", SpecType = "Equal", Units = nil, LowerLimit = nil, UpperLimit = nil,  EqualTable = {},},
    },

    NandControllerUID = {
        {Name = "Controller_UID", SubName = "Info", SpecType = "String", Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = nil,},
    },

    BatteryPropertyInfo = GetBatteryTestItem("BatteryPropertyInfo"),
    BatteryWRA          = GetBatteryTestItem("BatteryWRA"),
    BatteryCellVendor   = GetBatteryTestItem("BatteryCellVendor"),
    VeridianDataCheck   = GetBatteryTestItem("VeridianDataCheck"),

    Touch = {
        {Name = "Load_Firmware", SubName = "LoadFW", SpecType = "Equal", Units = nil, LowerLimit = nil, UpperLimit = nil,  EqualTable = {"OK"},},
    },

    Display = {
        {Name = "Read_Panel_ID",                SubName = "Status",                 SpecType = "String",    Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = nil,},
        {Name = "LCM_Vendor_Name",              SubName = "Info",                   SpecType = "Equal",     Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = {"LGD", "SDC"},},
        {Name = "DIC_Vendor_ID",                SubName = "Info",                   SpecType = "Equal",     Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = nil,},
        {Name = "Read_Panel_OUI_Decimal_Check", SubName = "Status",                 SpecType = "Equal",     Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = {4346, 4859},},
        {Name = "Read_Panel_OUI_Decimal",       SubName = "Info",                   SpecType = "Range",     Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = nil,},
        {Name = "Read_Touch_SIP_SN",            SubName = "Info",                   SpecType = "Length",    Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = {26},},
        {Name = "LCM_MP9_Temp",                 SubName = "Temperature",            SpecType = "Range",     Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = nil,},
        {Name = "LCM_10nit_W51_LL_R_ideal",     SubName = "OpticalMeasurements",    SpecType = "Range",     Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = nil,},
        {Name = "LCM_10nit_W51_LL_G_ideal",     SubName = "OpticalMeasurements",    SpecType = "Range",     Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = nil,},
        {Name = "LCM_MP9_FFR_Frequency",        SubName = "FrequencyCheck",         SpecType = "Range",     Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = nil,},
        {Name = "LCM_ACVRR",                    SubName = "OpticalMeasurements",    SpecType = "Range",     Units = nil, LowerLimit = nil, UpperLimit = nil, EqualTable = nil,},
        {Name = "PMIC_Version_Check",           SubName = "Info",                   SpecType = "Range",     Units = nil, LowerLimit = 97,  UpperLimit = 97,  EqualTable = nil,},
    },

    Front_CAMInfo    = GetCameraTestItemTable("Front"),
    SphinxTx_CAMInfo = GetCameraTestItemTable("SphinxTx"),
    SphinxRx_CAMInfo = GetCameraTestItemTable("SphinxRx"),
    Back_CAMInfo     = GetCameraTestItemTable("Back"),
    Back1_CAMInfo    = GetCameraTestItemTable("Back1"),
    Back2_CAMInfo    = GetCameraTestItemTable("Back2"),
    Peridot_CAMInfo  = GetCameraTestItemTable("Peridot"),
}

function GetTestItemTableFun(testitemname)
	return AllTestItems[testitemname]
end