---------------------------------------------------------------------------
-- Touch
-- This file contains Touch related tests, structures and functions.

require "Common"

function TouchLoadFW()
    Shell("touch --off")
    Shell("touch --on")
    Shell("touch --load_firmware")
    QT_ReportItemTestResult("Touch", "Load_Firmware", string.match(Last.Output, "OK"))
end