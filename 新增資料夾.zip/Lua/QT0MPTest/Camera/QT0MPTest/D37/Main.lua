---------------------------------------------------------------------------
-- Main.
-- Main lua file for QT0 MP Coverage scripts.

require "Nand"
require "Battery"
require "Touch"
require "Display"
require "Camera"

require "Common"
