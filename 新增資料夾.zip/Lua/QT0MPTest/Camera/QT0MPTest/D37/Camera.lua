---------------------------------------------------------------------------
-- Camera
-- This file contains Camera related tests, structures and functions.

local Platform = PlatformInfo("PlatformName")
local IsD3y = (Platform == "D37") or (Platform == "D38")
require "bit32"

local BarcodeTable = {
    ["000001"] = "0",
    ["000010"] = "1",
    ["000011"] = "2",
    ["000100"] = "3",
    ["000101"] = "4",
    ["000110"] = "5",
    ["000111"] = "6",
    ["001000"] = "7",
    ["001001"] = "8",
    ["010000"] = "9",
    ["010001"] = "A",
    ["010010"] = "B",
    ["010011"] = "C",
    ["010100"] = "D",
    ["010101"] = "E",
    ["010110"] = "F",
    ["010111"] = "G",
    ["011000"] = "H",
    ["011001"] = "I",
    ["100000"] = "J",
    ["100001"] = "K",
    ["100010"] = "L",
    ["100011"] = "M",
    ["100100"] = "N",
    ["100101"] = "O",
    ["100110"] = "P",
    ["100111"] = "Q",
    ["101000"] = "R",
    ["101001"] = "S",
    ["110000"] = "T",
    ["110001"] = "U",
    ["110010"] = "V",
    ["110011"] = "W",
    ["110100"] = "X",
    ["110101"] = "Y",
    ["110110"] = "Z",
}

local Base34Table = {
    "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G",
    "H", "J", "K", "L", "M", "N", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z",
}

local BlackOffsetCfg = {
    ["Back"]  = {I2cBus = "4", I2cAddr = "0x10"},
    ["Back1"] = {I2cBus = "8", I2cAddr = "0x20"},
    ["Back2"] = {I2cBus = "5", I2cAddr = "0x10"},
    ["Front"] = {I2cBus = "6", I2cAddr = "0x10"},
}

-- @param Value : A number
-- @return : String of Binary
local function ToBinary(Value)
    local BinaryStr = ""

    if Value == 0 or Value == 1 then
        return BinaryStr..(Value % 2)
    end

    return ToBinary(math.modf(Value / 2))..BinaryStr..(Value % 2)
end

-- @param Value : A number
-- @return : String of Base34
local function ToBase34(Value)
    local Base34Str = ""

    if Value < 34 then
        return Base34Str..Base34Table[Value % 34 + 1]
    end

    return ToBase34(math.modf(Value / 34))..Base34Str..Base34Table[Value % 34 + 1]
end

local function HexStrToBarcodeStr(HexStr)
    local BinaryStr, BarcodeStr = "", ""

    -- Convert to binary string
    for v in string.upper(HexStr:gsub("0x", "")):gmatch("%x") do
        BinaryStr = BinaryStr..string.format("%04d", ToBinary(tonumber("0x"..v)))
    end

    -- Convert to barcode string
    for v in BinaryStr:gmatch("[01][01][01][01][01][01]") do
        BarcodeStr = BarcodeStr..BarcodeTable[v]
    end

    return BarcodeStr
end

local function GetRegData(NVMDatas, Addr, Num, IsLittleEndian)
    local BaseAddr = string.format("0x%X", Addr - Addr % 8)
    local Offset = Addr - tonumber(BaseAddr)
    local RegData = ""

    for Data in NVMDatas:match(BaseAddr.." :"..string.rep(" 0x%x+", Offset).."(.+)"):gmatch(" (0x%x+)") do
        if Num == 0 then
            return "0x"..RegData
        end

        Data = string.format("%02x", Data)
        RegData = IsLittleEndian and Data..RegData or RegData..Data
        Addr = Addr + 1
        Num  = Num - 1
    end
end

local function ExtractData(Data, High, Low)
    return bit32.band(bit32.rshift(Data, Low), (2 ^ (High - Low + 1) - 1))
end

function GetNVMMapValue(NVMDatas, MapTable)
    local High = tonumber(MapTable.Bits:match("(.+):"))
    local Low  = tonumber(MapTable.Bits:match(":(.+)"))
    local NumOfBytes = math.modf(High / 8) + 1
    -- print("High, Low, NumOfBytes = "..High, Low, NumOfBytes)
    local RegData = GetRegData(NVMDatas, MapTable.Addr, NumOfBytes, MapTable.IsLittleEndian)
    -- print("RegData = "..RegData)
    -- print(MapTable.Name.." value = "..ExtractData(tonumber(RegData), High, Low))

    return MapTable.Disable and RegData or ExtractData(tonumber(RegData), High, Low)
end

local function ReadFrontSN(NVMDatas)
    local SN_Barcode7E = GetCameraTestItemTable("Front", "Front_SN_Barcode7E")

    -- print("FrontSNFromNVM = "..HexStrToBarcodeStr(GetNVMMapValue(NVMDatas, SN_Barcode7E)))
    return HexStrToBarcodeStr(GetNVMMapValue(NVMDatas, SN_Barcode7E))
end

-- Item : "SphinxTx"/"SphinxRx"
local function ReadSphinxSN(NVMDatas, Item)
    local PPPYWW = GetCameraTestItemTable(Item, "PPPYWW")
    local DSSSS  = GetCameraTestItemTable(Item, "DSSSS")
    local EEEERX = GetCameraTestItemTable(Item, "EEEERX")

    PPPYWW = ToBase34(tonumber(GetNVMMapValue(NVMDatas, PPPYWW)))
    DSSSS  = ToBase34(tonumber(GetNVMMapValue(NVMDatas, DSSSS)))
    EEEERX = ToBase34(tonumber(GetNVMMapValue(NVMDatas, EEEERX)))

    -- print("ReadSNFromNVM "..Item.." = "..PPPYWW..DSSSS..EEEERX)
    return PPPYWW..DSSSS..EEEERX
end

-- Item : "Back"/"Back1"/"Back2"
local function ReadRCamSN(NVMDatas, Item)
    local RCamSN = ""
    local SNIndex = {"AA", "BB", "CC", "FF", "GG", "HH", "II", "JJ", "KK", "LL"}

    for _, v in ipairs(SNIndex) do
        local Table = GetCameraTestItemTable(Item, Item.."_"..v)
        if Table == nil then
            RCamSN = RCamSN.."00"
        else
            RCamSN = RCamSN..GetNVMMapValue(NVMDatas, Table):gsub("0x", "")
        end
    end

    -- print("ReadSNFromNVM "..Item.." = "..RCamSN)
    return RCamSN
end

local function NVMDumpingValidCheck(NVMDatas)
    for Data in NVMDatas:gsub("NVM Data .-\n+", ""):gmatch(" (0x%x+)") do
        if tonumber(Data) ~= 0 and tonumber(Data) ~= 0xFF then
            return true
        end
    end

    return false
end

local function NVMDumping(NVMDatas, Item)
    for _, v in pairs(GetCameraTestItemTable(Item)) do
        if v.Addr ~= nil and v.Disable ~= true then
            QT_ReportItemTestResult(Item.."_CAMInfo", v.Name, GetNVMMapValue(NVMDatas, v))
        end
    end

    local IsValid = NVMDumpingValidCheck(NVMDatas) and "NoError_NotOnly0xFF_0x0" or "Only0xFF_0x0 in NVM"
    QT_ReportItemTestResult(Item.."_CAMInfo", Item.."_NVM_Dumping_ValidCheck", IsValid)
end

local function GetBlackLevelOffsetValue(Item)
    Shell("wait 200")
    Shell("camisp --ae off")
    Shell("wait 200")

    local Bus  = BlackOffsetCfg[Item].I2cBus
    local Addr = BlackOffsetCfg[Item].I2cAddr
    Shell("camisp --i2cwrite "..Bus.." "..Addr.." 0x0149 2 1 0xE0")
    Shell("wait 200")
    Shell("camisp --i2cread "..Bus.." "..Addr.." 0x0400 2 2")

    local RegData = tonumber(Last.Output:match("\n(0x[%x%X]-)\n"))
    local SignBit = ExtractData(RegData, 7, 7)              -- signBit = 0x0400[15]
    local Msb     = ExtractData(RegData, 6, 0)              -- msb = 0x0400[14:8]
    local Lsb     = ExtractData(RegData, 15, 8)             -- lsb = 0x0401[7:0]

    Shell("camisp --stream off")

    return (-1 * SignBit * 2^15 + Msb * 2^8 + Lsb) / 32
end

local function GetPeridotConfig(NVMDatas)
    local Build  = GetNVMMapValue(NVMDatas, GetCameraTestItemTable("Peridot", "Peridot_Camera_Build"))
    local Config = GetNVMMapValue(NVMDatas, GetCameraTestItemTable("Peridot", "Peridot_Camera_Config"))
    local DOE    = GetNVMMapValue(NVMDatas, GetCameraTestItemTable("Peridot", "Peridot_Camera_DOE"))

    local DOEStr = tonumber(DOE) == 0 and "" or Base34Table[DOE + 1]

    return "C"..string.format("%02x", Build)..string.format("%02x", Config)..DOEStr
end

function FrontTest()
    local NVMMapIndex = "Front_CAMInfo"

    -- Pick_Front
    Shell("camisp --exit --find --pick front")
    QT_ReportItemTestResult(NVMMapIndex, "Pick_Front", Last.Output:match("Pass"))
    Shell("camisp --on")

    -- Front_NVM_Dumping
    Shell("camisp --nvmdump")
    NVMDumping(Last.Output, "Front")

    -- Read_Front_SN_From_NVM
    QT_ReportItemTestResult(NVMMapIndex, "Read_Front_SN_From_NVM", ReadFrontSN(Last.Output))

    -- Read_Front_SN_From_Diag
    Shell("camisp --sn")
    QT_ReportItemTestResult(NVMMapIndex, "Read_Front_SN_From_Diag", Last.Output:match("Serial Number:%s*(.-)\n"))

    -- Front_ID
    Shell("camisp --id")
    QT_ReportItemTestResult(NVMMapIndex, "Front_ID", Last.Output:match("RunGetId%s*(.-)\n"))

    -- Front_Stream
    Shell("camisp --stream on")
    QT_ReportItemTestResult(NVMMapIndex, "Front_Stream", Last.Output:match("Pass"))

    -- Dli_Front
    Shell("camisp --dli")
    QT_ReportItemTestResult(NVMMapIndex, "Dli_Front", Last.Output:match("Pass"))
end

function SphinxTest()
    local NVMMapIndexTX = "SphinxTx_CAMInfo"
    local NVMMapIndexRX = "SphinxRx_CAMInfo"

    -- Pick_Front1
    Shell("camisp --exit --find --pick front1")
    QT_ReportItemTestResult(NVMMapIndexTX, "Pick_Front1", Last.Output:match("Pass"))
    Shell("camisp --on")

    -- SphinxTx_NVM_Dumping
    Shell("camisp --nvmdump romeo")
    NVMDumping(Last.Output, "SphinxTx")

    -- Read_Sphinx_SN_From_TXNVM
    QT_ReportItemTestResult(NVMMapIndexTX, "Read_Sphinx_SN_From_TXNVM", ReadSphinxSN(Last.Output, "SphinxTx"))

    -- SphinxRX_NVM_Dumping
    Shell("camisp --nvmdump")
    NVMDumping(Last.Output, "SphinxRx")

    -- Read_Sphinx_SN_From_RXNVM
    QT_ReportItemTestResult(NVMMapIndexRX, "Read_Sphinx_SN_From_RXNVM", ReadSphinxSN(Last.Output, "SphinxRx"))

    -- Read_Sphinx_SN_From_Diag
    Shell("camisp --sn")
    QT_ReportItemTestResult(NVMMapIndexRX, "Read_Sphinx_SN_From_Diag", Last.Output:match("Serial Number:%s*(.-)\n"))

    -- Front1_ID
    Shell("camisp --id")
    QT_ReportItemTestResult(NVMMapIndexRX, "Front1_ID", Last.Output:match("RunGetId%s*(.-)\n"))

    -- Regulus_EEPROM
    Shell("camisp --nvmdump regulus")
    QT_ReportItemTestResult(NVMMapIndexRX, "Regulus_EEPROM", Last.Output:match("Pass"))

    -- Front1_Stream
    Shell("camisp --stream on")
    QT_ReportItemTestResult(NVMMapIndexRX, "Front1_Stream", Last.Output:match("Pass"))

    -- Dli_Front1
    Shell("camisp --dli")
    QT_ReportItemTestResult(NVMMapIndexRX, "Dli_Front1", Last.Output:match("Pass"))

    -- GPIO_NUB_FROM_FDEPTH_B2B_DETECT
    local Pin = IsD3y and 19 or 17
    Shell("socgpio --port 5 --pin "..Pin.." --get")
    QT_ReportItemTestResult(NVMMapIndexRX, "GPIO_NUB_FROM_FDEPTH_B2B_DETECT", Last.Output:match("SoC GPIO%[5,"..Pin.."%]%s*=%s*(.-)\n"))
    Shell("camisp --exit")
end

-- Arg : "Back"/"Back1"/"Back2"
function RCAMTest(Args)
    local Item = Args.Name
    local NVMMapIndex = Item.."_CAMInfo"

    if IsD3y and Item == "Back1" then
        return
    end

    -- Pick_Back
    Shell("camisp --exit --find --pick "..Item:lower())
    QT_ReportItemTestResult(NVMMapIndex, "Pick_"..Item, Last.Output:match("Pass"))
    Shell("camisp --on")

    -- Read_Back_SN
    Shell("camisp --sn")
    local CameraSN = Last.Output:match("Serial Number:%s*(.-)\n")
    QT_ReportItemTestResult(NVMMapIndex, "Read_"..Item.."_SN", CameraSN)

    -- Compare_Back_SN_With_SFC
    -- Add_Back1_NVM_Barcode_Attribute
    QT_ReportItemAttribute(Item:upper().."_NVM_BARCODE", CameraSN)

    -- Back_NVM_Dumping
    Shell("camisp --nvmdump")
    NVMDumping(Last.Output, Item)

    -- BACK_NVM_EXTENDED_SN
    local ExtendedSN = CameraSN.."+"..ReadRCamSN(Last.Output, Item)
    QT_ReportItemTestResult(NVMMapIndex, Item:upper().."_NVM_EXTENDED_SN", ExtendedSN)
    QT_ReportItemAttribute(Item:upper().."_NVM_EXTENDED_SN", ExtendedSN)

    -- Back_ID
    Shell("camisp --id")
    QT_ReportItemTestResult(NVMMapIndex, Item.."_ID", Last.Output:match("RunGetId%s*(.-)\n"))

    -- Back_Stream
    -- Shell("camisp --setoismode position")
    Shell("camisp --stream on")
    QT_ReportItemTestResult(NVMMapIndex, Item.."_Stream", Last.Output:match("Pass"))

    -- Back_BlackLevelOffset_Value
    QT_ReportItemTestResult(NVMMapIndex, Item.."_BlackLevelOffset_Value", GetBlackLevelOffsetValue(Item))

    -- Dli_Back
    Shell("camisp --dli")
    QT_ReportItemTestResult(NVMMapIndex, "Dli_"..Item, Last.Output:match("Pass"))
    Shell("camisp --exit")
end

function PeridotTest()
    if IsD3y then
        return
    end

    local NVMMapIndex = "Peridot_CAMInfo"

    -- Pick_Back3
    Shell("camisp --exit --find --pick back3")
    QT_ReportItemTestResult(NVMMapIndex, "Pick_Back3", Last.Output:match("Pass"))
    Shell("camisp --on 2 0 10")

    -- Read_Peridot_Camera_SN
    Shell("camisp --sn")
    -- local CameraSN = Last.Output:match("Serial Number:%s*(.-)\n")
    QT_ReportItemTestResult(NVMMapIndex, "Read_Peridot_Camera_SN", Last.Output:match("Serial Number:%s*(.-)\n"))

    -- PeridotNvmIntegrityCheck
    Shell("camisp --nvmdump quark")
    QT_ReportItemTestResult(NVMMapIndex, "Read_Peridot_Camera_SN", GetPeridotConfig(Last.Output))

    -- Peridot_ID
    Shell("camisp --id")
    QT_ReportItemTestResult(NVMMapIndex, "Peridot_ID", Last.Output:match("RunGetId%s*(.-)\n"))

    -- Peridot_Stream
    Shell("camisp --method settofbuiltinsequence 5 8 0 0 0 0")
    Shell("wait 300")
    Shell("camisp --stream on")
    QT_ReportItemTestResult(NVMMapIndex, "Peridot_Stream", Last.Output:match("Pass") or "Fail")
    Shell("wait 300")
    Shell("camisp --stream off")
    Shell("camisp --exit")
end