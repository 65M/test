---------------------------------------------------------------------------
-- D38TestItem.
-- D38TestItem lua file for QT0 MP Coverage scripts.

local AllTestItems = {


}

function GetTestItemTableFun(testitemname)
	return AllTestItems[testitemname]
end