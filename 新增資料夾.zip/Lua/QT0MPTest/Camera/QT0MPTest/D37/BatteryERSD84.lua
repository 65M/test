-- BatteryERS base on D84 EVT battery ERS.

-- BatteryERS
-- Data of BatteryERS are used to update BatteryPropertyInfo & BatteryCellVendor test item.
-- All data come from the ERS corresponding to the build stage of the corresponding project.
-- key of sub list bases on different Cell ID;
-- Pack_EEEE_Code bases on PACK EEEE code with same Cell ID and it must be a table;
-- Config_ID_Check bases on Config ID and its type is number;
-- DNVD1_Version_Check bases on DNVD1 ID and its type is number;
-- DNVD2_Version_Check bases on DNVD2 ID and its type is number;
-- PackConfig bases on Pack Config with same Cell ID and its type is string;
-- CellVendor bases on Cell Vendor and its type is string;

local BatteryERS = {
    ["1013822014"] = {
            Pack_EEEE_Code = {"00005YY"},
            Config_ID_Check = 314001,
            DNVD1_Version_Check = 314001,
            DNVD2_Version_Check = 314001,
            PackConfig = "PN",
            CellVendor = "ATL",
    },

    ["1014383227"] = {
            Pack_EEEE_Code = {"00005X6", "00005X5", "00005Z1", "00006TS"},
            Config_ID_Check = 309004,
            DNVD1_Version_Check = 309001,
            DNVD2_Version_Check = 309003,
            PackConfig = "PB_PD_PJ_PT",
            CellVendor = "LGES",
    },

    ["1014192024"] = {
            Pack_EEEE_Code = {"00005YZ"},
            Config_ID_Check = 315001,
            DNVD1_Version_Check = 315001,
            DNVD2_Version_Check = 315001,
            PackConfig = "PO",
            CellVendor = "LGES",
    },

    ["1014443227"] = {
            Pack_EEEE_Code = {"00005X7"},
            Config_ID_Check = 310003,
            DNVD1_Version_Check = 310001,
            DNVD2_Version_Check = 310003,
            PackConfig = "PK",
            CellVendor = "LGES",
    },

    ["1014393217"] = {
            Pack_EEEE_Code = {"00005X3", "00005X4", "00005Z0"},
            Config_ID_Check = 308004,
            DNVD1_Version_Check = 308001,
            DNVD2_Version_Check = 308003,
            PackConfig = "PA_PC_PI",
            CellVendor = "ATL",
    },
}

function GetBatteryDataList(DataList)
    return BatteryERS[DataList]
end

local BatteryTestItem = {}
BatteryTestItem.BatteryPropertyInfo = {
    {Name = "Cell_ID_Check",              SubName = "Info",  SpecType = "Equal", Units = nil, LowerLimit = nil,       UpperLimit = nil,       EqualTable = {"1014393217", "1013822014", "1014383227", "1014192024", "1014443227"},},
    {Name = "Cell_ID",                    SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
    {Name = "GG_Type",                    SubName = "Info",  SpecType = "Equal", Units = nil, LowerLimit = nil,       UpperLimit = nil,       EqualTable = {"Veridian"},},
    {Name = "Lifetime_Min_Voltage",       SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = 2335,      UpperLimit = 4495,      EqualTable = nil,},
    {Name = "Lifetime_Max_Voltage",       SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = 2335,      UpperLimit = 4495,      EqualTable = nil,},
    {Name = "Battery_Present",            SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = 3400,      UpperLimit = 4480,      EqualTable = nil,},
    {Name = "Current",                    SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
    {Name = "BMF_Firmware_Version_Check", SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = 109080015, UpperLimit = 109080015, EqualTable = nil,},
    {Name = "BMF_Firmware_Version",       SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
    {Name = "Config_ID",                  SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
    {Name = "DNVD1_Version",              SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
    {Name = "DNVD2_Version",              SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
    {Name = "Lifetime_Min_Temp",          SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = -20,       UpperLimit = 70,        EqualTable = nil,},
    {Name = "Lifetime_Max_Temp",          SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = -20,       UpperLimit = 70,        EqualTable = nil,},
    {Name = "Remaining_Capacity",         SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
    {Name = "Cycle_Count",                SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = 0,         UpperLimit = 5,         EqualTable = nil,},
    {Name = "Qmax_Capacity_High_2Count",  SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = 4326,      UpperLimit = 5379,      EqualTable = nil,},
    {Name = "Design_Capacity",            SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
    {Name = "Nominal_Capacity",           SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = 4175,      UpperLimit = 4659,      EqualTable = nil,},
    {Name = "Charge_Percentage",          SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,},
    {Name = "Pack_EEEE_Code",             SubName = "Info",  SpecType = "Equal", Units = nil, LowerLimit = nil,       UpperLimit = nil,       EqualTable = {}, }, -- default value, need to update EqualTable based on Cell ID.
    {Name = "Config_ID_Check",            SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,}, -- default value, need to update LowerLimit & UpperLimit based on Cell ID.
    {Name = "DNVD1_Version_Check",        SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,}, -- default value, need to update LowerLimit & UpperLimit based on Cell ID.
    {Name = "DNVD2_Version_Check",        SubName = "Info",  SpecType = "Range", Units = nil, LowerLimit = nil,       UpperLimit = nil,       EqualTable = nil,}, -- default value, need to update LowerLimit & UpperLimit based on Cell ID.
}

BatteryTestItem.BatteryWRA = {
    {Name = "WRa_High_2Count", SubName = "Info",SpecType = "Range", Units = nil, LowerLimit = 13, UpperLimit = 309,  EqualTable = nil,},
}

BatteryTestItem.BatteryCellVendor = {
    {Name = "Cell_Vendor", SubName = "Info", SpecType = "Equal", Units = nil, LowerLimit = nil, UpperLimit = nil,  EqualTable = {"ATL", "LGES"},},
    {Name = "Pack_Config", SubName = "Info", SpecType = "Equal", Units = nil, LowerLimit = nil, UpperLimit = nil,  EqualTable = {"PA_PC_PI", "PN", "PB_PD_PJ_PT", "PO", "PK"},},
}

BatteryTestItem.eridianDataCheck = {
    {Name = "Veridian_Data_Check", SubName = "Status", SpecType = "Equal", Units = nil, LowerLimit = nil, UpperLimit = nil,
    EqualTable = {"20 00 00 00 00 55 CE AC E0 A3 EE 5C 7F FF 20 45 6E 90 84 6C 4A 37 E2 23 C0 A4 F4 A4 93 55 55 55 55"},},
}

function GetBatteryTestItem(TestItemName)
    return BatteryTestItem[TestItemName]
end