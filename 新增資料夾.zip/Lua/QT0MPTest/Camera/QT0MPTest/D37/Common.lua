---------------------------------------------------------------------------
-- Common.
-- This file contains common functions.

Universal = require 'Universal.14A'
local ProdName = PlatformInfo("PlatformName")
local TestItemSpecPath = ProdName.."TestItemSpec"
require(TestItemSpecPath)

-- Only process SpecType with string(default).
local function ReportStringData(TestName, Value)
    local ErrorMsg = "Error! The value of "..TestName.." is nil.(string to expect!)"
    
    PrintString("Hark, Station! Behold the data I present you!")
    if Value ~= nil then 
        ReportData(TestName, 1)
        PrintString(TestName..","..tostring(Value)..",string,default,nil")
    else
        ReportData(TestName, 0, nil, nil, nil, ErrorMsg)
        PrintString(TestName..",,string,default,nil")
    end 
end

-- Check whether the value is in the table.
local function CheckEqual(Value, EqualTable)
    for _,v in ipairs(EqualTable) do
        if Value == v then
            return true
        end
    end
    return false
end

-- Only process SpecType with equal
local function ReportEqualData(TestName, Value, EqualTable)
    local LimitStr = ""

    for i = 1,#EqualTable do
        LimitStr = LimitStr..tostring(EqualTable[i])
        if i ~= #EqualTable then
            LimitStr = LimitStr.."|"
        end
    end

    local ErrorMsg = "Error! The value of "..TestName.." is not equal to the Test Spec."
    local Result = CheckEqual(Value, EqualTable)

    PrintString("Hark, Station! Behold the data I present you!")
    if Result == false or Value == nil then
        ReportData(TestName, 0, nil, nil, nil, ErrorMsg)
    else
        ReportData(TestName, 1)
    end
    PrintString(TestName..","..tostring(Value)..",string,equal,"..LimitStr)
end

local function ReportLengthData(TestName, Value, EqualTable)
    local Length = #Value
    local LimitStr = ""

    for i = 1,#EqualTable do
        LimitStr = LimitStr..tostring(EqualTable[i])
        if i ~= #EqualTable then
            LimitStr = LimitStr.."|"
        end
    end

    local ErrorMsg = "Error! The value'length of "..TestName.." is not equal to the Test Spec."
    local Result = CheckEqual(Length, EqualTable)

    PrintString("Hark, Station! Behold the data I present you!")
    if Result == false or Value == nil then
        ReportData(TestName, 0, nil, nil, nil, ErrorMsg)
    else
        ReportData(TestName, 1)
    end
    PrintString(TestName..","..tostring(Value)..",string,length,"..LimitStr)
end

local function ReportMatchFailData(TestName, Value, EqualTable)
    local LimitStr = ""

    for i = 1,#EqualTable do
        LimitStr = LimitStr..tostring(EqualTable[i])
        if i ~= #EqualTable then
            LimitStr = LimitStr.."|"
        end
    end

    local ErrorMsgMatchFail = "Match Fail! The value of "..TestName.." is equal to the Test Spec."
    local ErrorMsgNil = "Error! The value of "..TestName.." is nil."
    local Result = CheckEqual(Value, EqualTable)

    PrintString("Hark, Station! Behold the data I present you!")
    if Result == false and Value ~= nil then
        ReportData(TestName, 1)
    end
    if Value == nil then
        ReportData(TestName, 0, nil, nil, nil, ErrorMsgNil)
    end
    if Result and Value ~= nil then
        ReportData(TestName, 0, nil, nil, nil, ErrorMsgMatchFail)
    end
    PrintString(TestName..","..tostring(Value)..",string,match_fail,"..LimitStr)
end

-- Only process SpecType with range.
local function ReportRangeData(TestName, Value, Units, LowerLimit, UpperLimit)
    local Result = false
    local ErrorMsg = "Error! The value of "..TestName.." is nil or not a number. It is a "..type(Value)

    if tonumber(Value) == nil then
        ReportData(TestName, 0, nil, nil, nil, ErrorMsg)
        PrintString("Hark, Station! Behold the data I present you!")
        PrintString(TestName..",nil,"..tostring(Units)..","..tostring(LowerLimit)..","..tostring(UpperLimit))
    else
        Universal:ReportDataToStationAndPDCA(TestName, Value, Units, LowerLimit, UpperLimit)
    end
end

function QT_ReportItemTestResult(TestItemName, TestName, Value)
    local TestTable = GetTestItemTableFun(TestItemName)
    local IsGetTestName = false

    for _,v in ipairs(TestTable) do
        local TestNameTemp = tostring(v.SubName).."_"..tostring(v.Name)

        assert(#TestNameTemp <= 48 , "Insight allows a maximum of 48 characters for Test.")
        if v.SubName == nil or v.Name == nil then
            error("Unable to get the SubName or Name of "..TestItemName.."/"..TestItemSpecPath..".lua; It is nil.")
        end

        if TestName == v.Name then
            IsGetTestName = true
            if v.SpecType == "String" then
                ReportStringData(TestNameTemp, Value)
                break
            elseif v.SpecType == "Length" then
                ReportLengthData(TestNameTemp, Value, v.EqualTable)
                break
            elseif v.SpecType == "Equal" then
                ReportEqualData(TestNameTemp, Value, v.EqualTable)
                break
            elseif v.SpecType == "MatchFail" then
                ReportMatchFailData(TestNameTemp, Value, v.EqualTable)
                break
            elseif v.SpecType == "Range" then
                ReportRangeData(TestNameTemp, Value, v.Units, v.LowerLimit, v.UpperLimit)
                break
            else
                error("Unable to get the SpecType of "..tostring(v.Name).." in "..TestItemName.."/"..TestItemSpecPath..".lua")
            end
        end    
    end

    if IsGetTestName == false then
        error("Unable to get the TestName : "..tostring(TestName).." in "..TestItemName.."/"..TestItemSpecPath..".lua")
    end
end

function QT_ReportItemAttribute(AttributeName, AttributeValue)
    if AttributeValue ~= nil then
        PrintString("(RX ==> Attribute):".."["..AttributeName.."]=["..tostring(AttributeValue).."]")
        ReportAttribute(AttributeName, AttributeValue)
    else
        PrintString("(RX ==> Attribute):".."["..AttributeName.."]=[nil]")
    end
end

-- According to the rules of the table 'ProxNVMMap', parse the data of prox nvm dump and store it in a table.
-- @param  NVMArray : Table to store prox nvm dump data.
-- @param  Address  : Register Address to store the required prox nvm dump data.
-- @param  Bit     : The bits required after the Address data is converted to binary bits.
-- @return : Return parsed data.
function QT_GetNvmValue(NVMArray, Address, Bit)

    if Address == "" then
        return "0"
    end

    local AddressArr, StartAdd, EndAdd
    local BitArr, StartBit, EndBit
    local Result = ''

    if Bit == '' or Bit:match(":") then
        if Address:match(":") then
            AddressArr = Universal.SplitString(Address, ":")
            StartAdd = tonumber(AddressArr[1],16)
            EndAdd = tonumber(AddressArr[2],16)
        else
            StartAdd = tonumber(Address,16)
            EndAdd = tonumber(Address,16)
        end
        if Bit:match(":") then
            BitArr = Universal.SplitString(Bit, ":")
            StartBit = tonumber(BitArr[1])
            EndBit = tonumber(BitArr[2])
            if StartBit > EndBit then
                print ("error StartBit big then EndBit")
            end
        end
        if EndAdd >= StartAdd then
            for i = StartAdd, EndAdd do
                local Value = string.gsub(NVMArray[i + 1], "0x", "")
                if string.len(Value) == 1 then
                    Value = '0'..Value
                end
                Result = Result..Value
            end
            if Bit == '' then
                return Result
            else
                return bit32.band(bit32.rshift(tonumber("0x"..Result),StartBit), (2^(EndBit-StartBit+1)-1))
            end
        else
            for i = StartAdd,EndAdd,-1 do
                local Value = string.gsub(NVMArray[i + 1], "0x", "")
                if string.len(Value) ==1 then
                    Value = '0'..Value
                end
                Result = Result..Value
            end
            if Bit == '' then
                return Result
            else
                return bit32.band(bit32.rshift(tonumber("0x"..Result),StartBit), (2^(EndBit-StartBit+1)-1))
            end
        end
    end
end