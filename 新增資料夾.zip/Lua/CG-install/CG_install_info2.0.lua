
-- 打开文件
fileLog = io.open("./device.txt", "r")
fileCSV = io.open("./CG_Install_CommandsList2.0.csv", "w")


fileCSV:write("Index,")
fileCSV:write("Item,")
fileCSV:write("Command,")
fileCSV:write("Log,")
fileCSV:write("Comments")
fileCSV:write("\n")

dividingLine = "=================================================================================="
logFilterWords = {dividingLine, "Item", "TX ==> ", "RX ==> ", "Test Name: ", "Test Pattern:", "Test Spec:", 
					"Test Value:", "Test Result:", "Overall Test Time:", "Overall Test Result:", ":-)"} 

function isLogLine(line)
	for i = 1, #logFilterWords do
		if (string.find(line, logFilterWords[i], 1, true)) then
			return false
		end
	end

	return true
end

function writeCSV()
	if (itemIndex == nil) then 
		return
	end

	if (CMD == nil) then
		CMD = "/"
	end
	
	if (LOG == nil) then
		LOG = "/"
	end

	-- 将item的name,CMD和LOG写入CSV
	print("itemIndex = "..itemIndex)
	print("itemName = "..itemName)
	print("CMD = "..CMD)
	print("LOG = "..LOG)
	fileCSV:write(itemIndex..",")
	fileCSV:write(itemName..",")
	fileCSV:write("\""..CMD.."\",")
	fileCSV:write("\""..LOG.."\",")
	fileCSV:write("\n")

	itemIndex = nil
	itemName = nil
	CMD = nil
	LOG = nil
end

for line in io.lines("./device.txt") do
	-- item line
	local index1 = string.find(line, "Item")
	if (index1 ~= nil) then
		-- 匹配itemIndex
		local index2 = string.find(line, ":")
		itemIndex = string.sub(line, index1 + string.len("Item"), index2 - 1)

		-- 匹配itemName
		itemName = string.gsub(string.sub(line, index2 + 2), "=", "")

		CMD = nil
		LOG = nil
	end

	-- cmd line
	local cmdIndex = string.find(line, "(TX ==> Dut)")
	if (cmdIndex ~= nil) then
		-- 匹配cmd
		local cmd = string.sub(line, cmdIndex + string.len("(TX ==> Dut)"))
		cmd = string.gsub(cmd, "\"", "\"\"")

		if (CMD == nil) then
			CMD = cmd
		else
			CMD = CMD.."\n"..cmd
		end
	end

	-- log line
	if (isLogLine(line)) then
		-- 匹配log
		local log = string.gsub(line, "\"", "\"\"")

		if (LOG == nil) then
			LOG = log
		else
			LOG = LOG.."\n"..log
		end
	end

	-- end line
	if (string.find(line, dividingLine)) then
		writeCSV()
	end
end

writeCSV()

-- 关闭打开的文件
fileLog:close()
fileCSV:close()
