function CreatBigInt(val)
    local BigInt = {
        single = "+",
        data = '',
    }

    if type(val) ~= "string" and type(val) ~= "number" then
        return nil
    end

    if tostring(val):sub(1, 1) == "-" then
        BigInt.single = "-"
        BigInt.data = tostring(val):sub(2)
    else
        BigInt.data = tostring(val)
    end

    return BigInt
end

local function _BigIntAdd(val1, val2, carryBit, result)
    if val1 == nil and val2 == nil then
        return carryBit == 0 and result or "1"..result
    end

    if val1 == nil then val1 = 0 end
    if val2 == nil then val2 = 0 end

    local strVal1, strVal2 = tostring(val1), tostring(val2)
    local len1, len2 = #strVal1, #strVal2
    local onesPlace1 = tonumber(strVal1:sub(len1))
    local onesPlace2 = tonumber(strVal2:sub(len2))
    result = math.modf((onesPlace1 + onesPlace2 + carryBit) % 10)..result
    carryBit = math.modf((onesPlace1 + onesPlace2 + carryBit) / 10)

    return _BigIntAdd(strVal1:match("(.+)%d"), strVal2:match("(.+)%d"), carryBit, result)
end

function BigIntAdd(val1, val2)
    if val1.single == "-" or val2.singel == "-" then
        return nil
    end

    return _BigIntAdd(val1.data, val2.data, 0, "")
end

print(BigIntAdd(CreatBigInt("1645648945619789"), CreatBigInt("111111964498974949847897979879798794986469846849794849849849879849498498489494")))
